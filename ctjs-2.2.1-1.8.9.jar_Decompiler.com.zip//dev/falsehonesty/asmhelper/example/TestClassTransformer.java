package dev.falsehonesty.asmhelper.example;

import dev.falsehonesty.asmhelper.BaseClassTransformer;
import dev.falsehonesty.asmhelper.dsl.At;
import dev.falsehonesty.asmhelper.dsl.InjectionPoint;
import dev.falsehonesty.asmhelper.dsl.Method;
import dev.falsehonesty.asmhelper.dsl.instructions.Descriptor;
import dev.falsehonesty.asmhelper.dsl.instructions.InsnListBuilder;
import dev.falsehonesty.asmhelper.dsl.instructions.JumpCondition;
import dev.falsehonesty.asmhelper.dsl.writers.InjectWriter;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u001f\n\u0002\u0010\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010#\u001a\u00020$H\u0002J\b\u0010%\u001a\u00020$H\u0002J\b\u0010&\u001a\u00020$H\u0002J\b\u0010'\u001a\u00020$H\u0002J\b\u0010(\u001a\u00020$H\u0002J\b\u0010)\u001a\u00020$H\u0002J\b\u0010*\u001a\u00020$H\u0016R\u0014\u0010\u0003\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0014\u0010\u0007\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0006R\u0014\u0010\t\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u0006R\u0014\u0010\u000b\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u0006R\u0014\u0010\r\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u0006R\u0014\u0010\u000f\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0006R\u0014\u0010\u0011\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0006R\u0014\u0010\u0013\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0006R\u0014\u0010\u0015\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0006R\u0014\u0010\u0017\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0006R\u0014\u0010\u0019\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0006R\u0014\u0010\u001b\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0006R\u0014\u0010\u001d\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0006R\u0014\u0010\u001f\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u0006R\u0014\u0010!\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u0006¨\u0006+"},
   d2 = {"Ldev/falsehonesty/asmhelper/example/TestClassTransformer;", "Ldev/falsehonesty/asmhelper/BaseClassTransformer;", "()V", "CANCELLABLE_EVENT", "", "getCANCELLABLE_EVENT", "()Ljava/lang/String;", "CLIENT_LISTENER", "getCLIENT_LISTENER", "CRASH_REPORT_CATEGORY", "getCRASH_REPORT_CATEGORY", "EFFECT_RENDERER", "getEFFECT_RENDERER", "ENTITY", "getENTITY", "ENTITY_FX", "getENTITY_FX", "ENTITY_ITEM", "getENTITY_ITEM", "ENTITY_PLAYER", "getENTITY_PLAYER", "FILE", "getFILE", "FRAME_BUFFER", "getFRAME_BUFFER", "ICHAT_COMPONENT", "getICHAT_COMPONENT", "INVENTORY_PLAYER", "getINVENTORY_PLAYER", "ITEM_STACK", "getITEM_STACK", "PACKET", "getPACKET", "TRIGGER_TYPE", "getTRIGGER_TYPE", "injectCountField", "", "injectCountPrint", "injectDrawSplashScreen", "injectEntityPlayer", "injectPrintInGameLoop", "injectSuper", "makeTransformers", "AsmHelper1.8.9"}
)
public final class TestClassTransformer extends BaseClassTransformer {
   @NotNull
   private final String CANCELLABLE_EVENT = "com/chattriggers/ctjs/minecraft/listeners/CancellableEvent";
   @NotNull
   private final String CLIENT_LISTENER = "com/chattriggers/ctjs/minecraft/listeners/ClientListener";
   @NotNull
   private final String CRASH_REPORT_CATEGORY = "net/minecraft/crash/CrashReportCategory";
   @NotNull
   private final String EFFECT_RENDERER = "net/minecraft/client/particle/EffectRenderer";
   @NotNull
   private final String ENTITY = "net/minecraft/entity/Entity";
   @NotNull
   private final String ENTITY_FX = "net/minecraft/client/particle/EntityFX";
   @NotNull
   private final String ENTITY_ITEM = "net/minecraft/entity/item/EntityItem";
   @NotNull
   private final String ENTITY_PLAYER = "net/minecraft/entity/player/EntityPlayer";
   @NotNull
   private final String FILE = "java/io/File";
   @NotNull
   private final String FRAME_BUFFER = "net/minecraft/client/shader/Framebuffer";
   @NotNull
   private final String ICHAT_COMPONENT = "net/minecraft/util/IChatComponent";
   @NotNull
   private final String INVENTORY_PLAYER = "net/minecraft/entity/player/InventoryPlayer";
   @NotNull
   private final String ITEM_STACK = "net/minecraft/item/ItemStack";
   @NotNull
   private final String PACKET = "net/minecraft/network/Packet";
   @NotNull
   private final String TRIGGER_TYPE = "com/chattriggers/ctjs/triggers/TriggerType";

   @NotNull
   public final String getCANCELLABLE_EVENT() {
      return this.CANCELLABLE_EVENT;
   }

   @NotNull
   public final String getCLIENT_LISTENER() {
      return this.CLIENT_LISTENER;
   }

   @NotNull
   public final String getCRASH_REPORT_CATEGORY() {
      return this.CRASH_REPORT_CATEGORY;
   }

   @NotNull
   public final String getEFFECT_RENDERER() {
      return this.EFFECT_RENDERER;
   }

   @NotNull
   public final String getENTITY() {
      return this.ENTITY;
   }

   @NotNull
   public final String getENTITY_FX() {
      return this.ENTITY_FX;
   }

   @NotNull
   public final String getENTITY_ITEM() {
      return this.ENTITY_ITEM;
   }

   @NotNull
   public final String getENTITY_PLAYER() {
      return this.ENTITY_PLAYER;
   }

   @NotNull
   public final String getFILE() {
      return this.FILE;
   }

   @NotNull
   public final String getFRAME_BUFFER() {
      return this.FRAME_BUFFER;
   }

   @NotNull
   public final String getICHAT_COMPONENT() {
      return this.ICHAT_COMPONENT;
   }

   @NotNull
   public final String getINVENTORY_PLAYER() {
      return this.INVENTORY_PLAYER;
   }

   @NotNull
   public final String getITEM_STACK() {
      return this.ITEM_STACK;
   }

   @NotNull
   public final String getPACKET() {
      return this.PACKET;
   }

   @NotNull
   public final String getTRIGGER_TYPE() {
      return this.TRIGGER_TYPE;
   }

   public void makeTransformers() {
      this.injectCountField();
      this.injectCountPrint();
      this.injectEntityPlayer();
      this.injectPrintInGameLoop();
   }

   private final void injectCountPrint() {
      Method.inject((Function1)null.INSTANCE);
   }

   private final void injectCountField() {
      Method.applyField((Function1)null.INSTANCE);
   }

   private final void injectEntityPlayer() {
      Method.inject((Function1)(new Function1<InjectWriter.Builder, Unit>() {
         public final void invoke(@NotNull InjectWriter.Builder $this$inject) {
            Intrinsics.checkNotNullParameter($this$inject, "$this$inject");
            $this$inject.setClassName(TestClassTransformer.this.getENTITY_PLAYER());
            $this$inject.setMethodName("dropOneItem");
            $this$inject.setMethodDesc("(Z)L" + TestClassTransformer.this.getENTITY_ITEM() + ';');
            $this$inject.setAt(new At((InjectionPoint)(new InjectionPoint.INVOKE(new Descriptor(TestClassTransformer.this.getINVENTORY_PLAYER(), "getCurrentItem", "()L" + TestClassTransformer.this.getITEM_STACK() + ';'), 0)), false, 2, 2, (DefaultConstructorMarker)null));
            $this$inject.setFieldMaps(MapsKt.mapOf(TuplesKt.to("inventory", "field_71071_by")));
            Pair[] var2 = new Pair[]{TuplesKt.to("getCurrentItem", "func_70448_g"), TuplesKt.to("func_71040_bB", "dropOneItem"), TuplesKt.to("func_70448_g", "getCurrentItem")};
            $this$inject.setMethodMaps(MapsKt.mapOf(var2));
            $this$inject.insnList((Function1)(new Function1<InsnListBuilder, Unit>() {
               public final void invoke(@NotNull InsnListBuilder $this$insnList) {
                  Intrinsics.checkNotNullParameter($this$insnList, "$this$insnList");
                  $this$insnList.invokeKObjectFunction(TestClassTransformer.this.getCLIENT_LISTENER(), "onDropItem", "(L" + TestClassTransformer.this.getENTITY_PLAYER() + ";L" + TestClassTransformer.this.getITEM_STACK() + ";)Z", (Function1)(new Function1<InsnListBuilder, Unit>() {
                     public final void invoke(@NotNull InsnListBuilder $this$invokeKObjectFunction) {
                        Intrinsics.checkNotNullParameter($this$invokeKObjectFunction, "$this$invokeKObjectFunction");
                        $this$invokeKObjectFunction.aload(0);
                        $this$invokeKObjectFunction.getLocalField(TestClassTransformer.this.getENTITY_PLAYER(), "inventory", 'L' + TestClassTransformer.this.getINVENTORY_PLAYER() + ';');
                        InsnListBuilder.invokeVirtual$default($this$invokeKObjectFunction, TestClassTransformer.this.getINVENTORY_PLAYER(), "getCurrentItem", "()L" + TestClassTransformer.this.getITEM_STACK() + ';', (Function1)null, 8, (Object)null);
                     }
                  }));
                  JumpCondition[] var2 = new JumpCondition[]{JumpCondition.FALSE};
                  $this$insnList.ifClause(var2, (Function1)null.INSTANCE);
               }
            }));
         }
      }));
   }

   private final void injectSuper() {
      Method.inject((Function1)null.INSTANCE);
   }

   private final void injectDrawSplashScreen() {
      Method.overwrite((Function1)null.INSTANCE);
   }

   private final void injectPrintInGameLoop() {
      Method.inject((Function1)null.INSTANCE);
   }
}
