package dev.falsehonesty.asmhelper.example;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Lambda;

@Metadata(
   mv = {1, 5, 1},
   k = 3,
   xi = 48,
   d1 = {"\u0000\u0004\n\u0002\b\u000b\u0010\u0000\u001a\u0002H\u0001\"\u0006\b\u0000\u0010\u0001\u0018\u0001\"\u0004\b\u0001\u0010\u0002\"\u0004\b\u0002\u0010\u0003\"\u0004\b\u0003\u0010\u0004\"\u0004\b\u0004\u0010\u00052\u0006\u0010\u0006\u001a\u0002H\u00022\u0006\u0010\u0007\u001a\u0002H\u00032\u0006\u0010\b\u001a\u0002H\u00042\u0006\u0010\t\u001a\u0002H\u0005H\n¨\u0006\n"},
   d2 = {"<anonymous>", "R", "P1", "P2", "P3", "P4", "<anonymous parameter 0>", "<anonymous parameter 1>", "<anonymous parameter 2>", "<anonymous parameter 3>", "dev/falsehonesty/asmhelper/dsl/code/CodeBlock$shadowMethod$5"}
)
public final class TestClassTransformer$injectCountPrint$1$1$invoke$$inlined$shadowMethod$default$1 extends Lambda implements Function4<Integer, Integer, Integer, Integer, Unit> {
   public TestClassTransformer$injectCountPrint$1$1$invoke$$inlined$shadowMethod$default$1() {
      super(4);
   }

   public final Unit invoke(Integer $noName_0, Integer $noName_1, Integer $noName_2, Integer $noName_3) {
      Object var10000 = null;
      throw new NullPointerException("null cannot be cast to non-null type kotlin.Unit");
   }
}
