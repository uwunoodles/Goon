package dev.falsehonesty.asmhelper;

import dev.falsehonesty.asmhelper.dsl.AsmWriter;
import dev.falsehonesty.asmhelper.printing.LogLevel;
import dev.falsehonesty.asmhelper.printing.PrintingKt;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.io.ByteStreamsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.minecraft.launchwrapper.IClassTransformer;
import net.minecraft.launchwrapper.LaunchClassLoader;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.tree.ClassNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\b&\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0005\u001a\u00020\u0006H\u0004J\u0010\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0002J\b\u0010\u000b\u001a\u00020\u0006H&J\b\u0010\f\u001a\u00020\u0006H\u0002J\u0010\u0010\f\u001a\u00020\u00062\u0006\u0010\r\u001a\u00020\u000eH\u0014J(\u0010\u000f\u001a\u0004\u0018\u00010\b2\b\u0010\t\u001a\u0004\u0018\u00010\n2\b\u0010\u0010\u001a\u0004\u0018\u00010\n2\b\u0010\u0011\u001a\u0004\u0018\u00010\bH\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0012"},
   d2 = {"Ldev/falsehonesty/asmhelper/BaseClassTransformer;", "Lnet/minecraft/launchwrapper/IClassTransformer;", "()V", "calledSetup", "", "debugClassLoading", "", "loadClassResource", "", "name", "", "makeTransformers", "setup", "classLoader", "Lnet/minecraft/launchwrapper/LaunchClassLoader;", "transform", "transformedName", "basicClass", "AsmHelper1.8.9"}
)
public abstract class BaseClassTransformer implements IClassTransformer {
   private boolean calledSetup;

   public abstract void makeTransformers();

   private final void setup() {
      ClassLoader var2 = this.getClass().getClassLoader();
      if (var2 == null) {
         throw new NullPointerException("null cannot be cast to non-null type net.minecraft.launchwrapper.LaunchClassLoader");
      } else {
         LaunchClassLoader classLoader = (LaunchClassLoader)var2;
         classLoader.addTransformerExclusion("kotlin.");
         classLoader.addTransformerExclusion("dev.falsehonesty.asmhelper.");
         classLoader.addTransformerExclusion("org.objenesis.");
         classLoader.addTransformerExclusion(this.getClass().getName());
         this.setup(classLoader);
         this.makeTransformers();
      }
   }

   protected final void debugClassLoading() {
      System.setProperty("legacy.debugClassLoading", "true");
      System.setProperty("legacy.debugClassLoadingSave", "true");
   }

   protected void setup(@NotNull LaunchClassLoader classLoader) {
      Intrinsics.checkNotNullParameter(classLoader, "classLoader");
   }

   @Nullable
   public byte[] transform(@Nullable String name, @Nullable String transformedName, @Nullable byte[] basicClass) {
      if (basicClass == null) {
         return null;
      } else {
         if (!this.calledSetup) {
            this.setup();
            this.calledSetup = true;
         }

         Map var5 = AsmHelper.INSTANCE.getClassReplacers();
         boolean $i$f$filter = false;
         String var4 = (String)var5.get(transformedName);
         boolean $i$f$filterTo;
         boolean var21;
         if (var4 != null) {
            $i$f$filter = false;
            var21 = false;
            $i$f$filterTo = false;
            PrintingKt.log$default("Completely replacing " + transformedName + " with data from " + var4 + '.', (LogLevel)null, 2, (Object)null);
            return this.loadClassResource(var4);
         } else {
            Iterable $this$filter$iv = (Iterable)AsmHelper.INSTANCE.getAsmWriters();
            $i$f$filter = false;
            Collection destination$iv$iv = (Collection)(new ArrayList());
            $i$f$filterTo = false;
            Iterator var10 = $this$filter$iv.iterator();

            while(var10.hasNext()) {
               Object element$iv$iv = var10.next();
               AsmWriter it = (AsmWriter)element$iv$iv;
               int var13 = false;
               if (Intrinsics.areEqual(StringsKt.replace$default(it.getClassName(), '/', '.', false, 4, (Object)null), transformedName)) {
                  destination$iv$iv.add(element$iv$iv);
               }
            }

            Collection var17 = (Collection)((List)destination$iv$iv);
            $i$f$filter = false;
            if (var17.isEmpty()) {
               var21 = false;
               return basicClass;
            } else {
               List writers = (List)var17;
               PrintingKt.log$default(Intrinsics.stringPlus("Transforming class ", transformedName), (LogLevel)null, 2, (Object)null);
               ClassReader classReader = new ClassReader(basicClass);
               ClassNode classNode = new ClassNode();
               classReader.accept((ClassVisitor)classNode, 4);
               classNode.version = 52;
               Iterable $this$forEach$iv = (Iterable)writers;
               int $i$f$forEach = false;
               Iterator var23 = $this$forEach$iv.iterator();

               while(var23.hasNext()) {
                  Object element$iv = var23.next();
                  AsmWriter it = (AsmWriter)element$iv;
                  int var26 = false;
                  PrintingKt.log$default("Applying AsmWriter " + it + " to class " + transformedName, (LogLevel)null, 2, (Object)null);
                  it.transform(classNode);
               }

               ClassWriter classWriter = new ClassWriter(3);

               try {
                  classNode.accept((ClassVisitor)classWriter);
               } catch (Throwable var14) {
                  PrintingKt.getLogger().error("Exception when transforming " + transformedName + " : " + var14.getClass().getSimpleName(), var14);
               }

               return classWriter.toByteArray();
            }
         }
      }
   }

   private final byte[] loadClassResource(String name) {
      InputStream var2 = this.getClass().getClassLoader().getResourceAsStream(name);
      Intrinsics.checkNotNullExpressionValue(var2, "this::class.java.classLoader.getResourceAsStream(name)");
      return ByteStreamsKt.readBytes(var2);
   }
}
