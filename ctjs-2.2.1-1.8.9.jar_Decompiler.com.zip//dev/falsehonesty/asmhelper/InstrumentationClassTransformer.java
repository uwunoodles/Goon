package dev.falsehonesty.asmhelper;

import dev.falsehonesty.asmhelper.dsl.AsmWriter;
import dev.falsehonesty.asmhelper.printing.LogLevel;
import dev.falsehonesty.asmhelper.printing.PrintingKt;
import java.io.InputStream;
import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.io.ByteStreamsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.tree.ClassNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b&\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0002J\b\u0010\t\u001a\u00020\nH&J\b\u0010\u000b\u001a\u00020\nH\u0002J@\u0010\f\u001a\u0004\u0018\u00010\u00062\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\b2\f\u0010\u0010\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u00132\b\u0010\u0014\u001a\u0004\u0018\u00010\u0006H\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0015"},
   d2 = {"Ldev/falsehonesty/asmhelper/InstrumentationClassTransformer;", "Ljava/lang/instrument/ClassFileTransformer;", "()V", "calledSetup", "", "loadClassResource", "", "name", "", "makeTransformers", "", "setup", "transform", "classLoader", "Ljava/lang/ClassLoader;", "className", "p2", "Ljava/lang/Class;", "p3", "Ljava/security/ProtectionDomain;", "basicClass", "AsmHelper1.8.9"}
)
public abstract class InstrumentationClassTransformer implements ClassFileTransformer {
   private boolean calledSetup;

   private final void setup() {
      this.makeTransformers();
   }

   public abstract void makeTransformers();

   @Nullable
   public byte[] transform(@Nullable ClassLoader classLoader, @Nullable String className, @Nullable Class<?> p2, @Nullable ProtectionDomain p3, @Nullable byte[] basicClass) {
      if (basicClass != null && className != null) {
         if (!StringsKt.startsWith$default(className, "kotlin.", false, 2, (Object)null) && !StringsKt.startsWith$default(className, "dev.falsehonesty.asmhelper.", false, 2, (Object)null)) {
            String var6 = this.getClass().getName();
            Intrinsics.checkNotNullExpressionValue(var6, "this.javaClass.name");
            if (!StringsKt.startsWith$default(className, var6, false, 2, (Object)null)) {
               if (!this.calledSetup) {
                  this.setup();
                  this.calledSetup = true;
               }

               var6 = (String)AsmHelper.INSTANCE.getClassReplacers().get(className);
               boolean $i$f$filter;
               boolean $i$f$filterTo;
               boolean var22;
               if (var6 != null) {
                  $i$f$filter = false;
                  var22 = false;
                  $i$f$filterTo = false;
                  PrintingKt.log$default("Completely replacing " + className + " with data from " + var6 + '.', (LogLevel)null, 2, (Object)null);
                  return this.loadClassResource(var6);
               }

               Iterable $this$filter$iv = (Iterable)AsmHelper.INSTANCE.getAsmWriters();
               $i$f$filter = false;
               Collection destination$iv$iv = (Collection)(new ArrayList());
               $i$f$filterTo = false;
               Iterator var12 = $this$filter$iv.iterator();

               while(var12.hasNext()) {
                  Object element$iv$iv = var12.next();
                  AsmWriter it = (AsmWriter)element$iv$iv;
                  int var15 = false;
                  if (Intrinsics.areEqual(StringsKt.replace$default(it.getClassName(), '/', '.', false, 4, (Object)null), className)) {
                     destination$iv$iv.add(element$iv$iv);
                  }
               }

               Collection var18 = (Collection)((List)destination$iv$iv);
               $i$f$filter = false;
               if (var18.isEmpty()) {
                  var22 = false;
                  return basicClass;
               }

               List writers = (List)var18;
               PrintingKt.log$default(Intrinsics.stringPlus("Transforming class ", className), (LogLevel)null, 2, (Object)null);
               ClassReader classReader = new ClassReader(basicClass);
               ClassNode classNode = new ClassNode();
               classReader.accept((ClassVisitor)classNode, 8);
               Iterable $this$forEach$iv = (Iterable)writers;
               int $i$f$forEach = false;
               Iterator var24 = $this$forEach$iv.iterator();

               while(var24.hasNext()) {
                  Object element$iv = var24.next();
                  AsmWriter it = (AsmWriter)element$iv;
                  int var27 = false;
                  PrintingKt.log$default("Applying AsmWriter " + it + " to class " + className, (LogLevel)null, 2, (Object)null);
                  it.transform(classNode);
               }

               ClassWriter classWriter = new ClassWriter(3);

               try {
                  classNode.accept((ClassVisitor)classWriter);
               } catch (Throwable var16) {
                  PrintingKt.log$default("Exception when transforming " + className + " : " + var16.getClass().getSimpleName(), (LogLevel)null, 2, (Object)null);
                  var16.printStackTrace();
               }

               return classWriter.toByteArray();
            }
         }

         return basicClass;
      } else {
         return null;
      }
   }

   private final byte[] loadClassResource(String name) {
      InputStream var2 = this.getClass().getClassLoader().getResourceAsStream(name);
      Intrinsics.checkNotNullExpressionValue(var2, "this::class.java.classLoader.getResourceAsStream(name)");
      return ByteStreamsKt.readBytes(var2);
   }
}
