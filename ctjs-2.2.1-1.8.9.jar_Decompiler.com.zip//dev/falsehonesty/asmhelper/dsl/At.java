package dev.falsehonesty.asmhelper.dsl;

import dev.falsehonesty.asmhelper.AsmHelper;
import dev.falsehonesty.asmhelper.dsl.instructions.Descriptor;
import dev.falsehonesty.asmhelper.remapping.Remapper;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.sequences.SequencesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u000e\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0007HÆ\u0003J'\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00052\b\u0010\u0014\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\u0014\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00170\u00162\u0006\u0010\u0018\u001a\u00020\u0019J\t\u0010\u001a\u001a\u00020\u0007HÖ\u0001J\t\u0010\u001b\u001a\u00020\u001cHÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e¨\u0006\u001d"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/At;", "", "value", "Ldev/falsehonesty/asmhelper/dsl/InjectionPoint;", "before", "", "shift", "", "(Ldev/falsehonesty/asmhelper/dsl/InjectionPoint;ZI)V", "getBefore", "()Z", "getShift", "()I", "getValue", "()Ldev/falsehonesty/asmhelper/dsl/InjectionPoint;", "component1", "component2", "component3", "copy", "equals", "other", "getTargetedNodes", "", "Lorg/objectweb/asm/tree/AbstractInsnNode;", "method", "Lorg/objectweb/asm/tree/MethodNode;", "hashCode", "toString", "", "AsmHelper1.8.9"}
)
public final class At {
   @NotNull
   private final InjectionPoint value;
   private final boolean before;
   private final int shift;

   public At(@NotNull InjectionPoint value, boolean before, int shift) {
      Intrinsics.checkNotNullParameter(value, "value");
      super();
      this.value = value;
      this.before = before;
      this.shift = shift;
   }

   // $FF: synthetic method
   public At(InjectionPoint var1, boolean var2, int var3, int var4, DefaultConstructorMarker var5) {
      if ((var4 & 2) != 0) {
         var2 = true;
      }

      if ((var4 & 4) != 0) {
         var3 = 0;
      }

      this(var1, var2, var3);
   }

   @NotNull
   public final InjectionPoint getValue() {
      return this.value;
   }

   public final boolean getBefore() {
      return this.before;
   }

   public final int getShift() {
      return this.shift;
   }

   @NotNull
   public final List<AbstractInsnNode> getTargetedNodes(@NotNull MethodNode method) {
      Intrinsics.checkNotNullParameter(method, "method");
      InjectionPoint var2 = this.value;
      List var10000;
      if (var2 instanceof InjectionPoint.HEAD) {
         var10000 = CollectionsKt.listOf(method.instructions.getFirst());
      } else if (var2 instanceof InjectionPoint.TAIL) {
         var10000 = CollectionsKt.listOf(method.instructions.getLast().getPrevious());
      } else {
         ListIterator var3;
         boolean $i$f$filter;
         boolean var5;
         Collection destination$iv$iv;
         boolean $i$f$filterTo;
         Iterator var8;
         Object element$iv$iv;
         AbstractInsnNode it;
         boolean var11;
         Iterable $this$filter$iv;
         List var18;
         if (var2 instanceof InjectionPoint.RETURN) {
            var3 = method.instructions.iterator();
            Intrinsics.checkNotNullExpressionValue(var3, "method.instructions.iterator()");
            $this$filter$iv = (Iterable)SequencesKt.toList(SequencesKt.asSequence((Iterator)var3));
            $i$f$filter = false;
            destination$iv$iv = (Collection)(new ArrayList());
            $i$f$filterTo = false;
            var8 = $this$filter$iv.iterator();

            while(var8.hasNext()) {
               element$iv$iv = var8.next();
               it = (AbstractInsnNode)element$iv$iv;
               var11 = false;
               int var12 = it.getOpcode();
               if (172 <= var12 ? var12 <= 177 : false) {
                  destination$iv$iv.add(element$iv$iv);
               }
            }

            var18 = (List)destination$iv$iv;
            $i$f$filter = false;
            var5 = false;
            $i$f$filterTo = false;
            var10000 = ((InjectionPoint.RETURN)this.getValue()).getOrdinal() != null ? CollectionsKt.listOf(var18.get(((InjectionPoint.RETURN)this.getValue()).getOrdinal())) : var18;
         } else if (var2 instanceof InjectionPoint.INVOKE) {
            var3 = method.instructions.iterator();
            Intrinsics.checkNotNullExpressionValue(var3, "method.instructions.iterator()");
            $this$filter$iv = (Iterable)SequencesKt.toList(SequencesKt.asSequence((Iterator)var3));
            $i$f$filter = false;
            destination$iv$iv = (Collection)(new ArrayList());
            $i$f$filterTo = false;
            var8 = $this$filter$iv.iterator();

            while(var8.hasNext()) {
               element$iv$iv = var8.next();
               it = (AbstractInsnNode)element$iv$iv;
               var11 = false;
               Descriptor descriptor = ((InjectionPoint.INVOKE)this.getValue()).getDescriptor();
               boolean var21;
               if (!(it instanceof MethodInsnNode)) {
                  var21 = false;
               } else {
                  Remapper var20 = AsmHelper.INSTANCE.getRemapper();
                  String remappedDesc = ((MethodInsnNode)it).owner;
                  Intrinsics.checkNotNullExpressionValue(remappedDesc, "it.owner");
                  String var10001 = remappedDesc;
                  remappedDesc = ((MethodInsnNode)it).name;
                  Intrinsics.checkNotNullExpressionValue(remappedDesc, "it.name");
                  String var10002 = remappedDesc;
                  remappedDesc = ((MethodInsnNode)it).desc;
                  Intrinsics.checkNotNullExpressionValue(remappedDesc, "it.desc");
                  String remappedName = var20.remapMethodName(var10001, var10002, remappedDesc);
                  var20 = AsmHelper.INSTANCE.getRemapper();
                  String remappedClassName = ((MethodInsnNode)it).desc;
                  Intrinsics.checkNotNullExpressionValue(remappedClassName, "it.desc");
                  remappedDesc = var20.remapDesc(remappedClassName);
                  var20 = AsmHelper.INSTANCE.getRemapper();
                  String var16 = ((MethodInsnNode)it).owner;
                  Intrinsics.checkNotNullExpressionValue(var16, "it.owner");
                  remappedClassName = var20.remapClassName(var16);
                  var21 = Intrinsics.areEqual(remappedClassName, descriptor.getOwner()) && (Intrinsics.areEqual(remappedName, descriptor.getName()) || Intrinsics.areEqual(AsmHelper.INSTANCE.getMethodMaps$AsmHelper1_8_9().get(remappedName), descriptor.getName()) || Intrinsics.areEqual(AsmHelper.INSTANCE.getMethodMaps$AsmHelper1_8_9().get(descriptor.getName()), remappedName)) && Intrinsics.areEqual(remappedDesc, descriptor.getDesc());
               }

               if (var21) {
                  destination$iv$iv.add(element$iv$iv);
               }
            }

            var18 = (List)destination$iv$iv;
            $i$f$filter = false;
            var5 = false;
            $i$f$filterTo = false;
            var10000 = ((InjectionPoint.INVOKE)this.getValue()).getOrdinal() != null ? (((InjectionPoint.INVOKE)this.getValue()).getOrdinal() >= var18.size() ? CollectionsKt.emptyList() : CollectionsKt.listOf(var18.get(((InjectionPoint.INVOKE)this.getValue()).getOrdinal()))) : var18;
         } else {
            if (!(var2 instanceof InjectionPoint.CUSTOM)) {
               throw new NoWhenBranchMatchedException();
            }

            var10000 = (List)((InjectionPoint.CUSTOM)this.value).getFinder().invoke(method);
         }
      }

      return var10000;
   }

   @NotNull
   public final InjectionPoint component1() {
      return this.value;
   }

   public final boolean component2() {
      return this.before;
   }

   public final int component3() {
      return this.shift;
   }

   @NotNull
   public final At copy(@NotNull InjectionPoint value, boolean before, int shift) {
      Intrinsics.checkNotNullParameter(value, "value");
      return new At(value, before, shift);
   }

   // $FF: synthetic method
   public static At copy$default(At var0, InjectionPoint var1, boolean var2, int var3, int var4, Object var5) {
      if ((var4 & 1) != 0) {
         var1 = var0.value;
      }

      if ((var4 & 2) != 0) {
         var2 = var0.before;
      }

      if ((var4 & 4) != 0) {
         var3 = var0.shift;
      }

      return var0.copy(var1, var2, var3);
   }

   @NotNull
   public String toString() {
      return "At(value=" + this.value + ", before=" + this.before + ", shift=" + this.shift + ')';
   }

   public int hashCode() {
      int result = this.value.hashCode();
      int var10000 = result * 31;
      byte var10001 = this.before;
      if (var10001 != 0) {
         var10001 = 1;
      }

      result = var10000 + var10001;
      result = result * 31 + Integer.hashCode(this.shift);
      return result;
   }

   public boolean equals(@Nullable Object other) {
      if (this == other) {
         return true;
      } else if (!(other instanceof At)) {
         return false;
      } else {
         At var2 = (At)other;
         if (!Intrinsics.areEqual(this.value, var2.value)) {
            return false;
         } else if (this.before != var2.before) {
            return false;
         } else {
            return this.shift == var2.shift;
         }
      }
   }
}
