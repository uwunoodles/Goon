package dev.falsehonesty.asmhelper.dsl.instructions;

import dev.falsehonesty.asmhelper.AsmHelper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Map.Entry;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.IntIterator;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntRange;
import kotlin.sequences.SequencesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.IntInsnNode;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.LookupSwitchInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.MultiANewArrayInsnNode;
import org.objectweb.asm.tree.TableSwitchInsnNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000²\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\"\n\u0002\u0010\u0006\n\u0002\b\u0018\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0002\b(\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b%\b\u0016\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0006\u0010\u0011\u001a\u00020\u0000J\u0006\u0010\u0012\u001a\u00020\u0000J\u0006\u0010\u0013\u001a\u00020\u0000J\u000e\u0010\u0014\u001a\u00020\u00002\u0006\u0010\u0015\u001a\u00020\u0006J\u000e\u0010\u0016\u001a\u00020\u00002\u0006\u0010\u0017\u001a\u00020\u0018J\u0006\u0010\u0019\u001a\u00020\u0000J/\u0010\u001a\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\u00062\u0006\u0010\u0017\u001a\u00020\u00182\u0017\u0010\u001c\u001a\u0013\u0012\u0004\u0012\u00020\u001e\u0012\u0004\u0012\u00020\u001f0\u001d¢\u0006\u0002\b J\u0006\u0010!\u001a\u00020\u0000J\u0006\u0010\"\u001a\u00020#J\u000e\u0010\"\u001a\u00020\u00002\u0006\u0010\u0015\u001a\u00020\u0006J\u0006\u0010$\u001a\u00020\u0000J\u0006\u0010%\u001a\u00020\u0000J\u0006\u0010&\u001a\u00020\u0000J\u000e\u0010'\u001a\u00020\u00002\u0006\u0010(\u001a\u00020\u0006J\u0017\u0010)\u001a\u00020\u00002\n\b\u0002\u0010*\u001a\u0004\u0018\u00010\u0006¢\u0006\u0002\u0010+J\u0006\u0010,\u001a\u00020\fJ\u0006\u0010-\u001a\u00020\u0000J\u0006\u0010.\u001a\u00020\u0000J\u000e\u0010/\u001a\u00020\u00002\u0006\u00100\u001a\u00020\u0018J\u0017\u00101\u001a\u00020\u00002\n\b\u0002\u0010*\u001a\u0004\u0018\u00010\u0006¢\u0006\u0002\u0010+J3\u00102\u001a\u00020\u00002\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u00103\u001a\u00020\u00182\u0019\b\u0002\u00104\u001a\u0013\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f0\u001d¢\u0006\u0002\b H\u0007J\u0006\u00105\u001a\u00020\u0000J\u0006\u00106\u001a\u00020\u0000J\u0006\u00107\u001a\u00020\u0000J\u0006\u00108\u001a\u00020\u0000J\u0006\u00109\u001a\u00020\u0000J\u0006\u0010:\u001a\u00020\u0000J\u0006\u0010;\u001a\u00020\u0000J\u0006\u0010<\u001a\u00020\u0000J\u0006\u0010=\u001a\u00020\u0000J\u0006\u0010>\u001a\u00020\u0000J\u0006\u0010?\u001a\u00020\u0000J\u000e\u0010@\u001a\u00020\u00002\u0006\u0010\u0015\u001a\u00020\u0006J\u0006\u0010A\u001a\u00020\u0000J\u0006\u0010B\u001a\u00020\u0000J\u0017\u0010C\u001a\u00020\u00002\n\b\u0002\u0010*\u001a\u0004\u0018\u00010\u0006¢\u0006\u0002\u0010+J\u000e\u0010D\u001a\u00020\u00002\u0006\u0010E\u001a\u00020FJ\u0006\u0010G\u001a\u00020\u0000J\u0006\u0010H\u001a\u00020\u0000J\u0006\u0010I\u001a\u00020#J\u000e\u0010I\u001a\u00020\u00002\u0006\u0010\u0015\u001a\u00020\u0006J\u0006\u0010J\u001a\u00020\u0000J\u0006\u0010K\u001a\u00020\u0000J\u0006\u0010L\u001a\u00020\u0000J\u0006\u0010M\u001a\u00020\u0000J\u0006\u0010N\u001a\u00020\u0000J\u0006\u0010O\u001a\u00020\u0000J\u0006\u0010P\u001a\u00020\u0000J\u0006\u0010Q\u001a\u00020\u0000J\u0006\u0010R\u001a\u00020\u0000J\u0006\u0010S\u001a\u00020\u0000J\u0006\u0010T\u001a\u00020\u0000J\u0006\u0010U\u001a\u00020\u0000J\u0006\u0010V\u001a\u00020\u0000J\u0006\u0010W\u001a\u00020\u0000J\u0006\u0010X\u001a\u00020\u0000J\u0006\u0010Y\u001a\u00020\u0000J\u0006\u0010Z\u001a\u00020\u0000J\u0006\u0010[\u001a\u00020\u0000J\u0006\u0010\\\u001a\u00020\u0000J\u0016\u0010]\u001a\u00020\u00002\u0006\u0010^\u001a\u00020_2\u0006\u0010`\u001a\u00020aJ&\u0010]\u001a\u00020\u00002\u0006\u0010^\u001a\u00020_2\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u0018J\u0013\u0010e\u001a\u00070f¢\u0006\u0002\bg2\u0006\u0010h\u001a\u00020\u0006J\u000e\u0010i\u001a\u00020\u00002\u0006\u0010\u0015\u001a\u00020\u0006J\u000e\u0010j\u001a\u00020\u00002\u0006\u0010E\u001a\u00020kJ\u0006\u0010l\u001a\u00020\u0000J\u0006\u0010m\u001a\u00020\u0000J\u0017\u0010n\u001a\u00020\u00002\n\b\u0002\u0010*\u001a\u0004\u0018\u00010\u0006¢\u0006\u0002\u0010+J\u0006\u0010o\u001a\u00020\u0000J\u0006\u0010p\u001a\u00020\u0000J\u0006\u0010q\u001a\u00020#J\u000e\u0010q\u001a\u00020\u00002\u0006\u0010\u0015\u001a\u00020\u0006J\u0006\u0010r\u001a\u00020\u0000J\u001e\u0010s\u001a\u00020\u00002\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u0018J\u000e\u0010t\u001a\u00020\u00002\u0006\u0010u\u001a\u00020\u0018J\u000e\u0010v\u001a\u00020\u00002\u0006\u0010`\u001a\u00020aJ\u001e\u0010v\u001a\u00020\u00002\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u0018J\u001e\u0010w\u001a\u00020\u00002\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u0018J&\u0010x\u001a\u00020y2\u0006\u0010z\u001a\u00020\u00062\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u0018J\u0006\u0010{\u001a\u00020\u0000J\u0006\u0010|\u001a\u00020\u0000J\u0006\u0010}\u001a\u00020\u0000J\u0006\u0010~\u001a\u00020\u0000J\u0006\u0010\u007f\u001a\u00020\u0000J\u0007\u0010\u0080\u0001\u001a\u00020\u0000J\u0007\u0010\u0081\u0001\u001a\u00020\u0000J\u0007\u0010\u0082\u0001\u001a\u00020\u0000J\u0007\u0010\u0083\u0001\u001a\u00020\u0000J\u0007\u0010\u0084\u0001\u001a\u00020\u0000J\u0007\u0010\u0085\u0001\u001a\u00020\u0000J\u0007\u0010\u0086\u0001\u001a\u00020\u0000J\u0007\u0010\u0087\u0001\u001a\u00020\u0000J\u0007\u0010\u0088\u0001\u001a\u00020\u0000J\u0007\u0010\u0089\u0001\u001a\u00020\u0000J\u0007\u0010\u008a\u0001\u001a\u00020\u0000J\u0007\u0010\u008b\u0001\u001a\u00020\u0000J\u0007\u0010\u008c\u0001\u001a\u00020\u0000J>\u0010\u008d\u0001\u001a\u00020\u00002\u0016\u0010\u008e\u0001\u001a\f\u0012\u0007\b\u0001\u0012\u00030\u0090\u00010\u008f\u0001\"\u00030\u0090\u00012\u0017\u0010\u001c\u001a\u0013\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f0\u001d¢\u0006\u0002\b ¢\u0006\u0003\u0010\u0091\u0001J@\u0010\u0092\u0001\u001a\u00020\u00002\u0016\u0010\u008e\u0001\u001a\f\u0012\u0007\b\u0001\u0012\u00030\u0090\u00010\u008f\u0001\"\u00030\u0090\u00012\u0019\u0010\u0093\u0001\u001a\u0014\u0012\u0005\u0012\u00030\u0094\u0001\u0012\u0004\u0012\u00020\u001f0\u001d¢\u0006\u0002\b ¢\u0006\u0003\u0010\u0091\u0001J\u0007\u0010\u0095\u0001\u001a\u00020\u0000J\u000f\u0010\u0096\u0001\u001a\u00020\u00002\u0006\u0010(\u001a\u00020\u0006J\u0007\u0010\u0097\u0001\u001a\u00020\u0000J\u0007\u0010\u0098\u0001\u001a\u00020\u0000J\u0018\u0010\u0099\u0001\u001a\u00020\u00002\n\b\u0002\u0010*\u001a\u0004\u0018\u00010\u0006¢\u0006\u0002\u0010+J\u0010\u0010\u009a\u0001\u001a\u00020\u00002\u0007\u0010\u009b\u0001\u001a\u00020\fJ\u0019\u0010\u009c\u0001\u001a\u00020\u00002\b\u0010\u009d\u0001\u001a\u00030\u009e\u0001H\u0000¢\u0006\u0003\b\u009f\u0001J\u0010\u0010 \u0001\u001a\u00020\u00002\u0007\u0010¡\u0001\u001a\u00020\u0018J\u000f\u0010¢\u0001\u001a\u00020\u00002\u0006\u0010E\u001a\u00020\u0006J8\u0010£\u0001\u001a\u00020\u00002\u0007\u00100\u001a\u00030¤\u00012\u0006\u0010`\u001a\u00020a2\u001c\b\u0002\u0010¥\u0001\u001a\u0015\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f\u0018\u00010\u001d¢\u0006\u0002\b H\u0007JH\u0010£\u0001\u001a\u00020\u00002\u0007\u00100\u001a\u00030¤\u00012\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u00182\u001c\b\u0002\u0010¥\u0001\u001a\u0015\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f\u0018\u00010\u001d¢\u0006\u0002\b H\u0007Jf\u0010¦\u0001\u001a\u00020\u00002\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u00182\u0007\u0010§\u0001\u001a\u00020y2\u0016\u0010¨\u0001\u001a\f\u0012\u0007\b\u0001\u0012\u00030©\u00010\u008f\u0001\"\u00030©\u00012\u001c\b\u0002\u0010¥\u0001\u001a\u0015\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f\u0018\u00010\u001d¢\u0006\u0002\b H\u0007¢\u0006\u0003\u0010ª\u0001J?\u0010«\u0001\u001a\u00020\u00002\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u00182\u001c\b\u0002\u0010¥\u0001\u001a\u0015\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f\u0018\u00010\u001d¢\u0006\u0002\b H\u0007JA\u0010¬\u0001\u001a\u00020\u00002\u0006\u0010u\u001a\u00020\u00182\u0007\u0010\u00ad\u0001\u001a\u00020\u00182\u0007\u0010®\u0001\u001a\u00020\u00182\u001c\b\u0002\u0010¥\u0001\u001a\u0015\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f\u0018\u00010\u001d¢\u0006\u0002\b H\u0007J?\u0010¯\u0001\u001a\u00020\u00002\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u00182\u001c\b\u0002\u0010¥\u0001\u001a\u0015\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f\u0018\u00010\u001d¢\u0006\u0002\b H\u0007J?\u0010°\u0001\u001a\u00020\u00002\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u00182\u001c\b\u0002\u0010¥\u0001\u001a\u0015\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f\u0018\u00010\u001d¢\u0006\u0002\b H\u0007J?\u0010±\u0001\u001a\u00020\u00002\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u00182\u001c\b\u0002\u0010¥\u0001\u001a\u0015\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f\u0018\u00010\u001d¢\u0006\u0002\b H\u0007J\u0007\u0010²\u0001\u001a\u00020\u0000J\u0007\u0010³\u0001\u001a\u00020\u0000J\u0007\u0010´\u0001\u001a\u00020\u0000J\u0007\u0010µ\u0001\u001a\u00020\u0000J\u0007\u0010¶\u0001\u001a\u00020\u0000J\u0007\u0010·\u0001\u001a\u00020#J\u000f\u0010·\u0001\u001a\u00020\u00002\u0006\u0010(\u001a\u00020\u0006J\u0007\u0010¸\u0001\u001a\u00020\u0000J\u0007\u0010¹\u0001\u001a\u00020\u0000J\u0007\u0010º\u0001\u001a\u00020\u0000J\u001a\u0010»\u0001\u001a\u00020\u00002\b\u0010¼\u0001\u001a\u00030\u0090\u00012\u0007\u0010½\u0001\u001a\u00020fJ\u0007\u0010¾\u0001\u001a\u00020\u0000J\u0007\u0010¿\u0001\u001a\u00020\u0000J\u0007\u0010À\u0001\u001a\u00020\u0000J\u0007\u0010Á\u0001\u001a\u00020\u0000J\u0007\u0010Â\u0001\u001a\u00020\u0000J\u0007\u0010Ã\u0001\u001a\u00020\u0000J\u0007\u0010Ä\u0001\u001a\u00020\u0000J\u0007\u0010Å\u0001\u001a\u00020\u0000J\u0007\u0010Æ\u0001\u001a\u00020\u0000J\u0007\u0010Ç\u0001\u001a\u00020\u0000J\u0011\u0010È\u0001\u001a\u00020\u00002\b\u0010É\u0001\u001a\u00030©\u0001J\u0007\u0010Ê\u0001\u001a\u00020\u0000J\u000f\u0010Ë\u0001\u001a\u00020\u00002\u0006\u0010(\u001a\u00020\u0006J\u0007\u0010Ì\u0001\u001a\u00020\u0000J\u0007\u0010Í\u0001\u001a\u00020\u0000J\u0018\u0010Î\u0001\u001a\u00020\u00002\n\b\u0002\u0010*\u001a\u0004\u0018\u00010\u0006¢\u0006\u0002\u0010+J\u0010\u0010Ï\u0001\u001a\u00020\u00002\u0007\u0010Ð\u0001\u001a\u00020#J\u0010\u0010Ñ\u0001\u001a\u00020\u00002\u0007\u0010E\u001a\u00030Ò\u0001J\"\u0010Ó\u0001\u001a\u00020\u001f2\u0019\u0010\u0093\u0001\u001a\u0014\u0012\u0005\u0012\u00030Ô\u0001\u0012\u0004\u0012\u00020\u001f0\u001d¢\u0006\u0002\b J\u0007\u0010Õ\u0001\u001a\u00020\u0000J\u0007\u0010Ö\u0001\u001a\u00020\u0000J\u0007\u0010×\u0001\u001a\u00020\u0000J\u0007\u0010Ø\u0001\u001a\u00020\u0000J\u0007\u0010Ù\u0001\u001a\u00020\u0000J\u0007\u0010Ú\u0001\u001a\u00020#J\u000f\u0010Ú\u0001\u001a\u00020\u00002\u0006\u0010(\u001a\u00020\u0006J\u0007\u0010Û\u0001\u001a\u00020\u0000J\u0007\u0010Ü\u0001\u001a\u00020\u0000J\u0007\u0010Ý\u0001\u001a\u00020\u0000J\u0007\u0010Þ\u0001\u001a\u00020fJ\u0007\u0010ß\u0001\u001a\u00020\u0000J\u0007\u0010à\u0001\u001a\u00020\u0000J\u0007\u0010á\u0001\u001a\u00020\u0000J\u0018\u0010â\u0001\u001a\u00020\u00002\u0006\u0010`\u001a\u00020\u00182\u0007\u0010ã\u0001\u001a\u00020\u0006J\u000f\u0010ä\u0001\u001a\u00020\u00002\u0006\u0010\u0017\u001a\u00020\u0018J!\u0010å\u0001\u001a\u00020\u00002\u0006\u00100\u001a\u00020\u00062\n\b\u0002\u0010*\u001a\u0004\u0018\u00010\u0006¢\u0006\u0003\u0010æ\u0001J\u0007\u0010ç\u0001\u001a\u00020\u0000J\u0010\u0010è\u0001\u001a\u00020\u00002\u0007\u0010½\u0001\u001a\u00020fJ\u0007\u0010é\u0001\u001a\u00020\u0000J\u0007\u0010ê\u0001\u001a\u00020\u0000J\u001f\u0010ë\u0001\u001a\u00020\u00002\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u0018J\u001f\u0010ì\u0001\u001a\u00020\u00002\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u0018J\u0007\u0010í\u0001\u001a\u00020\u0000J\u0007\u0010î\u0001\u001a\u00020\u0000J)\u0010ï\u0001\u001a\u00020\u00002\u0006\u0010`\u001a\u00020a2\u0018\u0010ð\u0001\u001a\u0013\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f0\u001d¢\u0006\u0002\b J9\u0010ï\u0001\u001a\u00020\u00002\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u00182\u0018\u0010ð\u0001\u001a\u0013\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f0\u001d¢\u0006\u0002\b J\u000f\u0010ñ\u0001\u001a\u00020\u00002\u0006\u0010(\u001a\u00020\u0006J\u0018\u0010ò\u0001\u001a\u00020\u00002\n\b\u0002\u0010*\u001a\u0004\u0018\u00010\u0006¢\u0006\u0002\u0010+J\u0007\u0010ó\u0001\u001a\u00020\u0000J \u0010ô\u0001\u001a\u00020\u00002\u0017\u0010\u001c\u001a\u0013\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f0\u001d¢\u0006\u0002\b J\"\u0010õ\u0001\u001a\u00020\u001f2\u0019\u0010\u0093\u0001\u001a\u0014\u0012\u0005\u0012\u00030Ô\u0001\u0012\u0004\u0012\u00020\u001f0\u001d¢\u0006\u0002\b J)\u0010ö\u0001\u001a\u00020\u00002\u0006\u0010`\u001a\u00020a2\u0018\u0010÷\u0001\u001a\u0013\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f0\u001d¢\u0006\u0002\b J9\u0010ö\u0001\u001a\u00020\u00002\u0006\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u00182\u0006\u0010d\u001a\u00020\u00182\u0018\u0010÷\u0001\u001a\u0013\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u001f0\u001d¢\u0006\u0002\b J\u0018\u0010ø\u0001\u001a\u00020\u00002\n\b\u0002\u0010*\u001a\u0004\u0018\u00010\u0006¢\u0006\u0002\u0010+R\u001a\u0010\u0005\u001a\u00020\u0006X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR\u0011\u0010\u000b\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010¨\u0006ù\u0001"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/instructions/InsnListBuilder;", "Lorg/objectweb/asm/Opcodes;", "toInjectInto", "Lorg/objectweb/asm/tree/MethodNode;", "(Lorg/objectweb/asm/tree/MethodNode;)V", "currentLocalIndex", "", "getCurrentLocalIndex", "()I", "setCurrentLocalIndex", "(I)V", "insnList", "Lorg/objectweb/asm/tree/InsnList;", "getInsnList", "()Lorg/objectweb/asm/tree/InsnList;", "getToInjectInto", "()Lorg/objectweb/asm/tree/MethodNode;", "aaload", "aastore", "aconst_null", "aload", "index", "anewarray", "className", "", "areturn", "array", "size", "code", "Lkotlin/Function1;", "Ldev/falsehonesty/asmhelper/dsl/instructions/ArrayBuilder;", "", "Lkotlin/ExtensionFunctionType;", "arraylength", "astore", "Ldev/falsehonesty/asmhelper/dsl/instructions/Local;", "athrow", "baload", "bastore", "bipush", "value", "bnewarray", "length", "(Ljava/lang/Integer;)Ldev/falsehonesty/asmhelper/dsl/instructions/InsnListBuilder;", "build", "caload", "castore", "checkcast", "type", "cnewarray", "createInstance", "constructorDescription", "parameters", "d2f", "d2i", "d2l", "dadd", "daload", "dastore", "dcmpg", "dcmpl", "dconst_0", "dconst_1", "ddiv", "dload", "dmul", "dneg", "dnewarray", "double", "number", "", "drem", "dreturn", "dstore", "dsub", "dup", "dup2", "dup2_x1", "dup2_x2", "dup_x1", "dup_x2", "f2d", "f2i", "f2l", "fadd", "faload", "fastore", "fcmpg", "fcmpl", "fconst_0", "fconst_1", "fconst_2", "fdiv", "field", "action", "Ldev/falsehonesty/asmhelper/dsl/instructions/FieldAction;", "descriptor", "Ldev/falsehonesty/asmhelper/dsl/instructions/Descriptor;", "owner", "name", "desc", "findLabel", "Lorg/objectweb/asm/tree/LabelNode;", "Lkotlin/internal/NoInfer;", "n", "fload", "float", "", "fmul", "fneg", "fnewarray", "frem", "freturn", "fstore", "fsub", "getField", "getKObjectInstance", "objectClassName", "getLocalField", "getStatic", "handle", "Lorg/objectweb/asm/Handle;", "tag", "i2b", "i2c", "i2d", "i2f", "i2l", "i2s", "iadd", "iaload", "iand", "iastore", "iconst_0", "iconst_1", "iconst_2", "iconst_3", "iconst_4", "iconst_5", "iconst_m1", "idiv", "ifClause", "conditions", "", "Ldev/falsehonesty/asmhelper/dsl/instructions/JumpCondition;", "([Ldev/falsehonesty/asmhelper/dsl/instructions/JumpCondition;Lkotlin/jvm/functions/Function1;)Ldev/falsehonesty/asmhelper/dsl/instructions/InsnListBuilder;", "ifElseClause", "builder", "Ldev/falsehonesty/asmhelper/dsl/instructions/IfElseBuilder;", "iinc", "iload", "imul", "ineg", "inewarray", "insertInsns", "list", "insn", "node", "Lorg/objectweb/asm/tree/AbstractInsnNode;", "insn$AsmHelper1_8_9", "instanceof", "clazzName", "int", "invoke", "Ldev/falsehonesty/asmhelper/dsl/instructions/InvokeType;", "arguments", "invokeDynamic", "bootstrapMethod", "bootstrapConstantArgs", "", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/objectweb/asm/Handle;[Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)Ldev/falsehonesty/asmhelper/dsl/instructions/InsnListBuilder;", "invokeInterface", "invokeKObjectFunction", "methodName", "methodDesc", "invokeSpecial", "invokeStatic", "invokeVirtual", "ior", "irem", "ireturn", "ishl", "ishr", "istore", "isub", "iushr", "ixor", "jump", "condition", "label", "l2d", "l2f", "l2i", "ladd", "laload", "land", "lastore", "lcmp", "lconst_0", "lconst_1", "ldc", "constant", "ldiv", "lload", "lmul", "lneg", "lnewarray", "load", "local", "long", "", "lookupswitch", "Ldev/falsehonesty/asmhelper/dsl/instructions/SwitchBuilder;", "lor", "lrem", "lreturn", "lshl", "lshr", "lstore", "lsub", "lushr", "lxor", "makeLabel", "methodReturn", "monitorenter", "monitorexit", "multianewarray", "dimensions", "new", "newarray", "(ILjava/lang/Integer;)Ldev/falsehonesty/asmhelper/dsl/instructions/InsnListBuilder;", "nop", "placeLabel", "pop", "pop2", "putField", "putStatic", "saload", "sastore", "setLocalField", "newValue", "sipush", "snewarray", "swap", "synchronized", "tableswitch", "updateLocalField", "updater", "znewarray", "AsmHelper1.8.9"}
)
public class InsnListBuilder implements Opcodes {
   @NotNull
   private final MethodNode toInjectInto;
   @NotNull
   private final InsnList insnList;
   private int currentLocalIndex;

   public InsnListBuilder(@NotNull MethodNode toInjectInto) {
      Intrinsics.checkNotNullParameter(toInjectInto, "toInjectInto");
      super();
      this.toInjectInto = toInjectInto;
      this.insnList = new InsnList();
      this.currentLocalIndex = this.toInjectInto.maxLocals;
   }

   @NotNull
   public final MethodNode getToInjectInto() {
      return this.toInjectInto;
   }

   @NotNull
   public final InsnList getInsnList() {
      return this.insnList;
   }

   public final int getCurrentLocalIndex() {
      return this.currentLocalIndex;
   }

   public final void setCurrentLocalIndex(int var1) {
      this.currentLocalIndex = var1;
   }

   @NotNull
   public final InsnListBuilder aaload() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$aaload_u24lambda_u2d0 = (InsnListBuilder)this;
      int var5 = false;
      $this$aaload_u24lambda_u2d0.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(50)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder aastore() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$aastore_u24lambda_u2d1 = (InsnListBuilder)this;
      int var5 = false;
      $this$aastore_u24lambda_u2d1.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(83)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder aconst_null() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$aconst_null_u24lambda_u2d2 = (InsnListBuilder)this;
      int var5 = false;
      $this$aconst_null_u24lambda_u2d2.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(1)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder aload(int index) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$aload_u24lambda_u2d3 = (InsnListBuilder)this;
      int var6 = false;
      $this$aload_u24lambda_u2d3.insn$AsmHelper1_8_9((AbstractInsnNode)(new VarInsnNode(25, index)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder anewarray(@NotNull String className) {
      Intrinsics.checkNotNullParameter(className, "className");
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$anewarray_u24lambda_u2d4 = (InsnListBuilder)this;
      int var6 = false;
      $this$anewarray_u24lambda_u2d4.insn$AsmHelper1_8_9((AbstractInsnNode)(new TypeInsnNode(189, className)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder areturn() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$areturn_u24lambda_u2d5 = (InsnListBuilder)this;
      int var5 = false;
      $this$areturn_u24lambda_u2d5.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(176)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder arraylength() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$arraylength_u24lambda_u2d6 = (InsnListBuilder)this;
      int var5 = false;
      $this$arraylength_u24lambda_u2d6.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(190)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder astore(int index) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$astore_u24lambda_u2d7 = (InsnListBuilder)this;
      int var6 = false;
      $this$astore_u24lambda_u2d7.insn$AsmHelper1_8_9((AbstractInsnNode)(new VarInsnNode(58, index)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder athrow() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$athrow_u24lambda_u2d8 = (InsnListBuilder)this;
      int var5 = false;
      $this$athrow_u24lambda_u2d8.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(191)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder baload() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$baload_u24lambda_u2d9 = (InsnListBuilder)this;
      int var5 = false;
      $this$baload_u24lambda_u2d9.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(51)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder bastore() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$bastore_u24lambda_u2d10 = (InsnListBuilder)this;
      int var5 = false;
      $this$bastore_u24lambda_u2d10.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(51)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder bipush(int value) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$bipush_u24lambda_u2d11 = (InsnListBuilder)this;
      int var6 = false;
      $this$bipush_u24lambda_u2d11.insn$AsmHelper1_8_9((AbstractInsnNode)(new IntInsnNode(16, value)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder bnewarray(@Nullable Integer length) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$bnewarray_u24lambda_u2d12 = (InsnListBuilder)this;
      int var6 = false;
      $this$bnewarray_u24lambda_u2d12.newarray(8, length);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder bnewarray$default(InsnListBuilder var0, Integer var1, int var2, Object var3) {
      if (var3 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: bnewarray");
      } else {
         if ((var2 & 1) != 0) {
            var1 = null;
         }

         return var0.bnewarray(var1);
      }
   }

   @NotNull
   public final InsnListBuilder caload() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$caload_u24lambda_u2d13 = (InsnListBuilder)this;
      int var5 = false;
      $this$caload_u24lambda_u2d13.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(52)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder castore() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$castore_u24lambda_u2d14 = (InsnListBuilder)this;
      int var5 = false;
      $this$castore_u24lambda_u2d14.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(52)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder checkcast(@NotNull String type) {
      Intrinsics.checkNotNullParameter(type, "type");
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$checkcast_u24lambda_u2d15 = (InsnListBuilder)this;
      int var6 = false;
      $this$checkcast_u24lambda_u2d15.insn$AsmHelper1_8_9((AbstractInsnNode)(new TypeInsnNode(192, type)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder cnewarray(@Nullable Integer length) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$cnewarray_u24lambda_u2d16 = (InsnListBuilder)this;
      int var6 = false;
      $this$cnewarray_u24lambda_u2d16.newarray(5, length);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder cnewarray$default(InsnListBuilder var0, Integer var1, int var2, Object var3) {
      if (var3 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: cnewarray");
      } else {
         if ((var2 & 1) != 0) {
            var1 = null;
         }

         return var0.cnewarray(var1);
      }
   }

   @NotNull
   public final InsnListBuilder d2f() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$d2f_u24lambda_u2d17 = (InsnListBuilder)this;
      int var5 = false;
      $this$d2f_u24lambda_u2d17.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(144)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder d2i() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$d2i_u24lambda_u2d18 = (InsnListBuilder)this;
      int var5 = false;
      $this$d2i_u24lambda_u2d18.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(142)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder d2l() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$d2l_u24lambda_u2d19 = (InsnListBuilder)this;
      int var5 = false;
      $this$d2l_u24lambda_u2d19.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(143)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dadd() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dadd_u24lambda_u2d20 = (InsnListBuilder)this;
      int var5 = false;
      $this$dadd_u24lambda_u2d20.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(99)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder daload() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$daload_u24lambda_u2d21 = (InsnListBuilder)this;
      int var5 = false;
      $this$daload_u24lambda_u2d21.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(49)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dastore() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dastore_u24lambda_u2d22 = (InsnListBuilder)this;
      int var5 = false;
      $this$dastore_u24lambda_u2d22.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(49)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dcmpg() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dcmpg_u24lambda_u2d23 = (InsnListBuilder)this;
      int var5 = false;
      $this$dcmpg_u24lambda_u2d23.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(152)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dcmpl() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dcmpl_u24lambda_u2d24 = (InsnListBuilder)this;
      int var5 = false;
      $this$dcmpl_u24lambda_u2d24.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(151)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dconst_0() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dconst_0_u24lambda_u2d25 = (InsnListBuilder)this;
      int var5 = false;
      $this$dconst_0_u24lambda_u2d25.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(14)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dconst_1() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dconst_1_u24lambda_u2d26 = (InsnListBuilder)this;
      int var5 = false;
      $this$dconst_1_u24lambda_u2d26.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(15)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder ddiv() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$ddiv_u24lambda_u2d27 = (InsnListBuilder)this;
      int var5 = false;
      $this$ddiv_u24lambda_u2d27.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(111)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dload(int index) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$dload_u24lambda_u2d28 = (InsnListBuilder)this;
      int var6 = false;
      $this$dload_u24lambda_u2d28.insn$AsmHelper1_8_9((AbstractInsnNode)(new VarInsnNode(24, index)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dmul() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dmul_u24lambda_u2d29 = (InsnListBuilder)this;
      int var5 = false;
      $this$dmul_u24lambda_u2d29.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(107)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dneg() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dneg_u24lambda_u2d30 = (InsnListBuilder)this;
      int var5 = false;
      $this$dneg_u24lambda_u2d30.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(119)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dnewarray(@Nullable Integer length) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$dnewarray_u24lambda_u2d31 = (InsnListBuilder)this;
      int var6 = false;
      $this$dnewarray_u24lambda_u2d31.newarray(7, length);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder dnewarray$default(InsnListBuilder var0, Integer var1, int var2, Object var3) {
      if (var3 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: dnewarray");
      } else {
         if ((var2 & 1) != 0) {
            var1 = null;
         }

         return var0.dnewarray(var1);
      }
   }

   @NotNull
   public final InsnListBuilder drem() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$drem_u24lambda_u2d32 = (InsnListBuilder)this;
      int var5 = false;
      $this$drem_u24lambda_u2d32.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(115)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dreturn() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dreturn_u24lambda_u2d33 = (InsnListBuilder)this;
      int var5 = false;
      $this$dreturn_u24lambda_u2d33.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(175)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dstore(int index) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$dstore_u24lambda_u2d34 = (InsnListBuilder)this;
      int var6 = false;
      $this$dstore_u24lambda_u2d34.insn$AsmHelper1_8_9((AbstractInsnNode)(new VarInsnNode(57, index)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dsub() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dsub_u24lambda_u2d35 = (InsnListBuilder)this;
      int var5 = false;
      $this$dsub_u24lambda_u2d35.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(103)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dup() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dup_u24lambda_u2d36 = (InsnListBuilder)this;
      int var5 = false;
      $this$dup_u24lambda_u2d36.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(89)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dup_x1() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dup_x1_u24lambda_u2d37 = (InsnListBuilder)this;
      int var5 = false;
      $this$dup_x1_u24lambda_u2d37.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(90)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dup_x2() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dup_x2_u24lambda_u2d38 = (InsnListBuilder)this;
      int var5 = false;
      $this$dup_x2_u24lambda_u2d38.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(91)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dup2() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dup2_u24lambda_u2d39 = (InsnListBuilder)this;
      int var5 = false;
      $this$dup2_u24lambda_u2d39.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(92)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dup2_x1() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dup2_x1_u24lambda_u2d40 = (InsnListBuilder)this;
      int var5 = false;
      $this$dup2_x1_u24lambda_u2d40.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(93)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder dup2_x2() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$dup2_x2_u24lambda_u2d41 = (InsnListBuilder)this;
      int var5 = false;
      $this$dup2_x2_u24lambda_u2d41.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(94)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder f2d() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$f2d_u24lambda_u2d42 = (InsnListBuilder)this;
      int var5 = false;
      $this$f2d_u24lambda_u2d42.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(141)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder f2i() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$f2i_u24lambda_u2d43 = (InsnListBuilder)this;
      int var5 = false;
      $this$f2i_u24lambda_u2d43.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(139)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder f2l() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$f2l_u24lambda_u2d44 = (InsnListBuilder)this;
      int var5 = false;
      $this$f2l_u24lambda_u2d44.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(140)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fadd() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$fadd_u24lambda_u2d45 = (InsnListBuilder)this;
      int var5 = false;
      $this$fadd_u24lambda_u2d45.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(98)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder faload() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$faload_u24lambda_u2d46 = (InsnListBuilder)this;
      int var5 = false;
      $this$faload_u24lambda_u2d46.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(48)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fastore() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$fastore_u24lambda_u2d47 = (InsnListBuilder)this;
      int var5 = false;
      $this$fastore_u24lambda_u2d47.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(48)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fcmpg() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$fcmpg_u24lambda_u2d48 = (InsnListBuilder)this;
      int var5 = false;
      $this$fcmpg_u24lambda_u2d48.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(150)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fcmpl() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$fcmpl_u24lambda_u2d49 = (InsnListBuilder)this;
      int var5 = false;
      $this$fcmpl_u24lambda_u2d49.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(149)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fconst_0() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$fconst_0_u24lambda_u2d50 = (InsnListBuilder)this;
      int var5 = false;
      $this$fconst_0_u24lambda_u2d50.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(11)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fconst_1() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$fconst_1_u24lambda_u2d51 = (InsnListBuilder)this;
      int var5 = false;
      $this$fconst_1_u24lambda_u2d51.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(12)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fconst_2() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$fconst_2_u24lambda_u2d52 = (InsnListBuilder)this;
      int var5 = false;
      $this$fconst_2_u24lambda_u2d52.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(13)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fdiv() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$fdiv_u24lambda_u2d53 = (InsnListBuilder)this;
      int var5 = false;
      $this$fdiv_u24lambda_u2d53.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(110)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fload(int index) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$fload_u24lambda_u2d54 = (InsnListBuilder)this;
      int var6 = false;
      $this$fload_u24lambda_u2d54.insn$AsmHelper1_8_9((AbstractInsnNode)(new VarInsnNode(23, index)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fmul() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$fmul_u24lambda_u2d55 = (InsnListBuilder)this;
      int var5 = false;
      $this$fmul_u24lambda_u2d55.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(106)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fneg() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$fneg_u24lambda_u2d56 = (InsnListBuilder)this;
      int var5 = false;
      $this$fneg_u24lambda_u2d56.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(118)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fnewarray(@Nullable Integer length) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$fnewarray_u24lambda_u2d57 = (InsnListBuilder)this;
      int var6 = false;
      $this$fnewarray_u24lambda_u2d57.newarray(6, length);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder fnewarray$default(InsnListBuilder var0, Integer var1, int var2, Object var3) {
      if (var3 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: fnewarray");
      } else {
         if ((var2 & 1) != 0) {
            var1 = null;
         }

         return var0.fnewarray(var1);
      }
   }

   @NotNull
   public final InsnListBuilder frem() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$frem_u24lambda_u2d58 = (InsnListBuilder)this;
      int var5 = false;
      $this$frem_u24lambda_u2d58.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(114)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder freturn() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$freturn_u24lambda_u2d59 = (InsnListBuilder)this;
      int var5 = false;
      $this$freturn_u24lambda_u2d59.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(174)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fstore(int index) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$fstore_u24lambda_u2d60 = (InsnListBuilder)this;
      int var6 = false;
      $this$fstore_u24lambda_u2d60.insn$AsmHelper1_8_9((AbstractInsnNode)(new VarInsnNode(56, index)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder fsub() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$fsub_u24lambda_u2d61 = (InsnListBuilder)this;
      int var5 = false;
      $this$fsub_u24lambda_u2d61.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(102)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder i2b() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$i2b_u24lambda_u2d62 = (InsnListBuilder)this;
      int var5 = false;
      $this$i2b_u24lambda_u2d62.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(145)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder i2c() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$i2c_u24lambda_u2d63 = (InsnListBuilder)this;
      int var5 = false;
      $this$i2c_u24lambda_u2d63.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(146)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder i2d() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$i2d_u24lambda_u2d64 = (InsnListBuilder)this;
      int var5 = false;
      $this$i2d_u24lambda_u2d64.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(135)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder i2f() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$i2f_u24lambda_u2d65 = (InsnListBuilder)this;
      int var5 = false;
      $this$i2f_u24lambda_u2d65.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(134)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder i2l() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$i2l_u24lambda_u2d66 = (InsnListBuilder)this;
      int var5 = false;
      $this$i2l_u24lambda_u2d66.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(133)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder i2s() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$i2s_u24lambda_u2d67 = (InsnListBuilder)this;
      int var5 = false;
      $this$i2s_u24lambda_u2d67.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(147)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iadd() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$iadd_u24lambda_u2d68 = (InsnListBuilder)this;
      int var5 = false;
      $this$iadd_u24lambda_u2d68.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(96)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iaload() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$iaload_u24lambda_u2d69 = (InsnListBuilder)this;
      int var5 = false;
      $this$iaload_u24lambda_u2d69.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(46)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iand() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$iand_u24lambda_u2d70 = (InsnListBuilder)this;
      int var5 = false;
      $this$iand_u24lambda_u2d70.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(126)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iastore() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$iastore_u24lambda_u2d71 = (InsnListBuilder)this;
      int var5 = false;
      $this$iastore_u24lambda_u2d71.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(79)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iconst_m1() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$iconst_m1_u24lambda_u2d72 = (InsnListBuilder)this;
      int var5 = false;
      $this$iconst_m1_u24lambda_u2d72.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(2)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iconst_0() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$iconst_0_u24lambda_u2d73 = (InsnListBuilder)this;
      int var5 = false;
      $this$iconst_0_u24lambda_u2d73.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(3)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iconst_1() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$iconst_1_u24lambda_u2d74 = (InsnListBuilder)this;
      int var5 = false;
      $this$iconst_1_u24lambda_u2d74.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(4)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iconst_2() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$iconst_2_u24lambda_u2d75 = (InsnListBuilder)this;
      int var5 = false;
      $this$iconst_2_u24lambda_u2d75.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(5)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iconst_3() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$iconst_3_u24lambda_u2d76 = (InsnListBuilder)this;
      int var5 = false;
      $this$iconst_3_u24lambda_u2d76.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(6)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iconst_4() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$iconst_4_u24lambda_u2d77 = (InsnListBuilder)this;
      int var5 = false;
      $this$iconst_4_u24lambda_u2d77.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(7)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iconst_5() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$iconst_5_u24lambda_u2d78 = (InsnListBuilder)this;
      int var5 = false;
      $this$iconst_5_u24lambda_u2d78.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(8)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder idiv() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$idiv_u24lambda_u2d79 = (InsnListBuilder)this;
      int var5 = false;
      $this$idiv_u24lambda_u2d79.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(108)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iinc() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$iinc_u24lambda_u2d80 = (InsnListBuilder)this;
      int var5 = false;
      $this$iinc_u24lambda_u2d80.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(132)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iload(int value) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$iload_u24lambda_u2d81 = (InsnListBuilder)this;
      int var6 = false;
      $this$iload_u24lambda_u2d81.insn$AsmHelper1_8_9((AbstractInsnNode)(new VarInsnNode(21, value)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder imul() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$imul_u24lambda_u2d82 = (InsnListBuilder)this;
      int var5 = false;
      $this$imul_u24lambda_u2d82.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(104)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder ineg() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$ineg_u24lambda_u2d83 = (InsnListBuilder)this;
      int var5 = false;
      $this$ineg_u24lambda_u2d83.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(116)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder inewarray(@Nullable Integer length) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$inewarray_u24lambda_u2d84 = (InsnListBuilder)this;
      int var6 = false;
      $this$inewarray_u24lambda_u2d84.newarray(10, length);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder inewarray$default(InsnListBuilder var0, Integer var1, int var2, Object var3) {
      if (var3 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: inewarray");
      } else {
         if ((var2 & 1) != 0) {
            var1 = null;
         }

         return var0.inewarray(var1);
      }
   }

   @NotNull
   public final InsnListBuilder instanceof(@NotNull String clazzName) {
      Intrinsics.checkNotNullParameter(clazzName, "clazzName");
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$instanceof_u24lambda_u2d85 = (InsnListBuilder)this;
      int var6 = false;
      $this$instanceof_u24lambda_u2d85.insn$AsmHelper1_8_9((AbstractInsnNode)(new TypeInsnNode(193, clazzName)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder ior() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$ior_u24lambda_u2d86 = (InsnListBuilder)this;
      int var5 = false;
      $this$ior_u24lambda_u2d86.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(128)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder irem() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$irem_u24lambda_u2d87 = (InsnListBuilder)this;
      int var5 = false;
      $this$irem_u24lambda_u2d87.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(112)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder ireturn() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$ireturn_u24lambda_u2d88 = (InsnListBuilder)this;
      int var5 = false;
      $this$ireturn_u24lambda_u2d88.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(172)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder ishl() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$ishl_u24lambda_u2d89 = (InsnListBuilder)this;
      int var5 = false;
      $this$ishl_u24lambda_u2d89.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(120)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder ishr() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$ishr_u24lambda_u2d90 = (InsnListBuilder)this;
      int var5 = false;
      $this$ishr_u24lambda_u2d90.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(122)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder istore(int value) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$istore_u24lambda_u2d91 = (InsnListBuilder)this;
      int var6 = false;
      $this$istore_u24lambda_u2d91.insn$AsmHelper1_8_9((AbstractInsnNode)(new VarInsnNode(54, value)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder isub() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$isub_u24lambda_u2d92 = (InsnListBuilder)this;
      int var5 = false;
      $this$isub_u24lambda_u2d92.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(100)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder iushr() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$iushr_u24lambda_u2d93 = (InsnListBuilder)this;
      int var5 = false;
      $this$iushr_u24lambda_u2d93.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(124)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder ixor() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$ixor_u24lambda_u2d94 = (InsnListBuilder)this;
      int var5 = false;
      $this$ixor_u24lambda_u2d94.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(130)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder l2d() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$l2d_u24lambda_u2d95 = (InsnListBuilder)this;
      int var5 = false;
      $this$l2d_u24lambda_u2d95.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(138)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder l2f() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$l2f_u24lambda_u2d96 = (InsnListBuilder)this;
      int var5 = false;
      $this$l2f_u24lambda_u2d96.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(137)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder l2i() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$l2i_u24lambda_u2d97 = (InsnListBuilder)this;
      int var5 = false;
      $this$l2i_u24lambda_u2d97.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(136)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder ladd() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$ladd_u24lambda_u2d98 = (InsnListBuilder)this;
      int var5 = false;
      $this$ladd_u24lambda_u2d98.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(97)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder laload() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$laload_u24lambda_u2d99 = (InsnListBuilder)this;
      int var5 = false;
      $this$laload_u24lambda_u2d99.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(47)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder land() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$land_u24lambda_u2d100 = (InsnListBuilder)this;
      int var5 = false;
      $this$land_u24lambda_u2d100.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(127)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lastore() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lastore_u24lambda_u2d101 = (InsnListBuilder)this;
      int var5 = false;
      $this$lastore_u24lambda_u2d101.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(80)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lcmp() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lcmp_u24lambda_u2d102 = (InsnListBuilder)this;
      int var5 = false;
      $this$lcmp_u24lambda_u2d102.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(148)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lconst_0() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lconst_0_u24lambda_u2d103 = (InsnListBuilder)this;
      int var5 = false;
      $this$lconst_0_u24lambda_u2d103.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(9)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lconst_1() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lconst_1_u24lambda_u2d104 = (InsnListBuilder)this;
      int var5 = false;
      $this$lconst_1_u24lambda_u2d104.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(10)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder ldc(@NotNull Object constant) {
      Intrinsics.checkNotNullParameter(constant, "constant");
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$ldc_u24lambda_u2d105 = (InsnListBuilder)this;
      int var6 = false;
      $this$ldc_u24lambda_u2d105.insn$AsmHelper1_8_9((AbstractInsnNode)(new LdcInsnNode(constant)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder ldiv() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$ldiv_u24lambda_u2d106 = (InsnListBuilder)this;
      int var5 = false;
      $this$ldiv_u24lambda_u2d106.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(109)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lload(int value) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$lload_u24lambda_u2d107 = (InsnListBuilder)this;
      int var6 = false;
      $this$lload_u24lambda_u2d107.insn$AsmHelper1_8_9((AbstractInsnNode)(new VarInsnNode(22, value)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lmul() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lmul_u24lambda_u2d108 = (InsnListBuilder)this;
      int var5 = false;
      $this$lmul_u24lambda_u2d108.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(105)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lneg() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lneg_u24lambda_u2d109 = (InsnListBuilder)this;
      int var5 = false;
      $this$lneg_u24lambda_u2d109.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(117)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lnewarray(@Nullable Integer length) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$lnewarray_u24lambda_u2d110 = (InsnListBuilder)this;
      int var6 = false;
      $this$lnewarray_u24lambda_u2d110.newarray(11, length);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder lnewarray$default(InsnListBuilder var0, Integer var1, int var2, Object var3) {
      if (var3 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: lnewarray");
      } else {
         if ((var2 & 1) != 0) {
            var1 = null;
         }

         return var0.lnewarray(var1);
      }
   }

   @NotNull
   public final InsnListBuilder lor() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lor_u24lambda_u2d111 = (InsnListBuilder)this;
      int var5 = false;
      $this$lor_u24lambda_u2d111.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(129)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lrem() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lrem_u24lambda_u2d112 = (InsnListBuilder)this;
      int var5 = false;
      $this$lrem_u24lambda_u2d112.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(113)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lreturn() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lreturn_u24lambda_u2d113 = (InsnListBuilder)this;
      int var5 = false;
      $this$lreturn_u24lambda_u2d113.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(173)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lshl() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lshl_u24lambda_u2d114 = (InsnListBuilder)this;
      int var5 = false;
      $this$lshl_u24lambda_u2d114.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(121)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lshr() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lshr_u24lambda_u2d115 = (InsnListBuilder)this;
      int var5 = false;
      $this$lshr_u24lambda_u2d115.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(123)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lstore(int value) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$lstore_u24lambda_u2d116 = (InsnListBuilder)this;
      int var6 = false;
      $this$lstore_u24lambda_u2d116.insn$AsmHelper1_8_9((AbstractInsnNode)(new VarInsnNode(55, value)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lsub() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lsub_u24lambda_u2d117 = (InsnListBuilder)this;
      int var5 = false;
      $this$lsub_u24lambda_u2d117.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(101)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lushr() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lushr_u24lambda_u2d118 = (InsnListBuilder)this;
      int var5 = false;
      $this$lushr_u24lambda_u2d118.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(125)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder lxor() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$lxor_u24lambda_u2d119 = (InsnListBuilder)this;
      int var5 = false;
      $this$lxor_u24lambda_u2d119.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(131)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder monitorenter() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$monitorenter_u24lambda_u2d120 = (InsnListBuilder)this;
      int var5 = false;
      $this$monitorenter_u24lambda_u2d120.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(194)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder monitorexit() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$monitorexit_u24lambda_u2d121 = (InsnListBuilder)this;
      int var5 = false;
      $this$monitorexit_u24lambda_u2d121.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(195)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder multianewarray(@NotNull String descriptor, int dimensions) {
      Intrinsics.checkNotNullParameter(descriptor, "descriptor");
      boolean var4 = false;
      boolean var5 = false;
      InsnListBuilder $this$multianewarray_u24lambda_u2d122 = (InsnListBuilder)this;
      int var7 = false;
      $this$multianewarray_u24lambda_u2d122.insn$AsmHelper1_8_9((AbstractInsnNode)(new MultiANewArrayInsnNode(descriptor, dimensions)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder new(@NotNull String className) {
      Intrinsics.checkNotNullParameter(className, "className");
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$new_u24lambda_u2d123 = (InsnListBuilder)this;
      int var6 = false;
      $this$new_u24lambda_u2d123.insn$AsmHelper1_8_9((AbstractInsnNode)(new TypeInsnNode(187, className)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder newarray(int type, @Nullable Integer length) {
      boolean var4 = false;
      boolean var5 = false;
      InsnListBuilder $this$newarray_u24lambda_u2d124 = (InsnListBuilder)this;
      int var7 = false;
      if (length != null) {
         $this$newarray_u24lambda_u2d124.ldc(length);
      }

      $this$newarray_u24lambda_u2d124.insn$AsmHelper1_8_9((AbstractInsnNode)(new IntInsnNode(188, type)));
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder newarray$default(InsnListBuilder var0, int var1, Integer var2, int var3, Object var4) {
      if (var4 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: newarray");
      } else {
         if ((var3 & 2) != 0) {
            var2 = null;
         }

         return var0.newarray(var1, var2);
      }
   }

   @NotNull
   public final InsnListBuilder nop() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$nop_u24lambda_u2d125 = (InsnListBuilder)this;
      int var5 = false;
      $this$nop_u24lambda_u2d125.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(0)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder pop() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$pop_u24lambda_u2d126 = (InsnListBuilder)this;
      int var5 = false;
      $this$pop_u24lambda_u2d126.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(87)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder pop2() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$pop2_u24lambda_u2d127 = (InsnListBuilder)this;
      int var5 = false;
      $this$pop2_u24lambda_u2d127.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(88)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder methodReturn() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$methodReturn_u24lambda_u2d128 = (InsnListBuilder)this;
      int var5 = false;
      $this$methodReturn_u24lambda_u2d128.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(177)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder saload() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$saload_u24lambda_u2d129 = (InsnListBuilder)this;
      int var5 = false;
      $this$saload_u24lambda_u2d129.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(53)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder sastore() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$sastore_u24lambda_u2d130 = (InsnListBuilder)this;
      int var5 = false;
      $this$sastore_u24lambda_u2d130.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(86)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder sipush(int value) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$sipush_u24lambda_u2d131 = (InsnListBuilder)this;
      int var6 = false;
      $this$sipush_u24lambda_u2d131.insn$AsmHelper1_8_9((AbstractInsnNode)(new IntInsnNode(17, value)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder snewarray(@Nullable Integer length) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$snewarray_u24lambda_u2d132 = (InsnListBuilder)this;
      int var6 = false;
      $this$snewarray_u24lambda_u2d132.newarray(9, length);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder snewarray$default(InsnListBuilder var0, Integer var1, int var2, Object var3) {
      if (var3 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: snewarray");
      } else {
         if ((var2 & 1) != 0) {
            var1 = null;
         }

         return var0.snewarray(var1);
      }
   }

   @NotNull
   public final InsnListBuilder swap() {
      boolean var2 = false;
      boolean var3 = false;
      InsnListBuilder $this$swap_u24lambda_u2d133 = (InsnListBuilder)this;
      int var5 = false;
      $this$swap_u24lambda_u2d133.insn$AsmHelper1_8_9((AbstractInsnNode)(new InsnNode(95)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder znewarray(@Nullable Integer length) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$znewarray_u24lambda_u2d134 = (InsnListBuilder)this;
      int var6 = false;
      $this$znewarray_u24lambda_u2d134.newarray(4, length);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder znewarray$default(InsnListBuilder var0, Integer var1, int var2, Object var3) {
      if (var3 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: znewarray");
      } else {
         if ((var2 & 1) != 0) {
            var1 = null;
         }

         return var0.znewarray(var1);
      }
   }

   @NotNull
   public final LabelNode makeLabel() {
      return new LabelNode();
   }

   @NotNull
   public final LabelNode findLabel(int n) {
      ListIterator var2 = this.toInjectInto.instructions.iterator();
      Intrinsics.checkNotNullExpressionValue(var2, "toInjectInto.instructions\n        .iterator()");
      Iterable $this$sortedBy$iv = (Iterable)SequencesKt.toList(SequencesKt.asSequence((Iterator)var2));
      int $i$f$sortedBy = false;
      Collection destination$iv$iv = (Collection)(new ArrayList());
      int $i$f$filterIsInstanceTo = false;
      Iterator var7 = $this$sortedBy$iv.iterator();

      while(var7.hasNext()) {
         Object element$iv$iv = var7.next();
         if (element$iv$iv instanceof LabelNode) {
            destination$iv$iv.add(element$iv$iv);
         }
      }

      $this$sortedBy$iv = (Iterable)((List)destination$iv$iv);
      $i$f$sortedBy = false;
      boolean var4 = false;
      List var10 = CollectionsKt.sortedWith($this$sortedBy$iv, (Comparator)(new InsnListBuilder$findLabel$$inlined$sortedBy$1()));
      $i$f$sortedBy = false;
      return (LabelNode)var10.get(n);
   }

   @NotNull
   public final InsnListBuilder placeLabel(@NotNull LabelNode label) {
      Intrinsics.checkNotNullParameter(label, "label");
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$placeLabel_u24lambda_u2d136 = (InsnListBuilder)this;
      int var6 = false;
      $this$placeLabel_u24lambda_u2d136.insn$AsmHelper1_8_9((AbstractInsnNode)label);
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder jump(@NotNull JumpCondition condition, @NotNull LabelNode label) {
      Intrinsics.checkNotNullParameter(condition, "condition");
      Intrinsics.checkNotNullParameter(label, "label");
      boolean var4 = false;
      boolean var5 = false;
      InsnListBuilder $this$jump_u24lambda_u2d137 = (InsnListBuilder)this;
      int var7 = false;
      $this$jump_u24lambda_u2d137.insn$AsmHelper1_8_9((AbstractInsnNode)(new JumpInsnNode(condition.getOpcode(), label)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder array(int size, @NotNull String className, @NotNull Function1<? super ArrayBuilder, Unit> code) {
      Intrinsics.checkNotNullParameter(className, "className");
      Intrinsics.checkNotNullParameter(code, "code");
      boolean var5 = false;
      boolean var6 = false;
      InsnListBuilder $this$array_u24lambda_u2d138 = (InsnListBuilder)this;
      int var8 = false;
      $this$array_u24lambda_u2d138.int(size);
      $this$array_u24lambda_u2d138.anewarray(className);
      ArrayBuilder array = new ArrayBuilder($this$array_u24lambda_u2d138);
      code.invoke(array);
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder getKObjectInstance(@NotNull String objectClassName) {
      Intrinsics.checkNotNullParameter(objectClassName, "objectClassName");
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$getKObjectInstance_u24lambda_u2d139 = (InsnListBuilder)this;
      int var6 = false;
      $this$getKObjectInstance_u24lambda_u2d139.field(FieldAction.GET_STATIC, objectClassName, "INSTANCE", 'L' + objectClassName + ';');
      return (InsnListBuilder)this;
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invokeKObjectFunction(@NotNull String objectClassName, @NotNull String methodName, @NotNull String methodDesc, @Nullable Function1<? super InsnListBuilder, Unit> arguments) {
      Intrinsics.checkNotNullParameter(objectClassName, "objectClassName");
      Intrinsics.checkNotNullParameter(methodName, "methodName");
      Intrinsics.checkNotNullParameter(methodDesc, "methodDesc");
      boolean var6 = false;
      boolean var7 = false;
      InsnListBuilder $this$invokeKObjectFunction_u24lambda_u2d140 = (InsnListBuilder)this;
      int var9 = false;
      $this$invokeKObjectFunction_u24lambda_u2d140.getKObjectInstance(objectClassName);
      $this$invokeKObjectFunction_u24lambda_u2d140.invoke(InvokeType.VIRTUAL, objectClassName, methodName, methodDesc, arguments);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder invokeKObjectFunction$default(InsnListBuilder var0, String var1, String var2, String var3, Function1 var4, int var5, Object var6) {
      if (var6 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: invokeKObjectFunction");
      } else {
         if ((var5 & 8) != 0) {
            var4 = null;
         }

         return var0.invokeKObjectFunction(var1, var2, var3, var4);
      }
   }

   @NotNull
   public final InsnListBuilder int(int number) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$int_u24lambda_u2d141 = (InsnListBuilder)this;
      int var6 = false;
      if (number == -1) {
         $this$int_u24lambda_u2d141.iconst_m1();
      } else if (number == 0) {
         $this$int_u24lambda_u2d141.iconst_0();
      } else if (number == 1) {
         $this$int_u24lambda_u2d141.iconst_1();
      } else if (number == 2) {
         $this$int_u24lambda_u2d141.iconst_2();
      } else if (number == 3) {
         $this$int_u24lambda_u2d141.iconst_3();
      } else if (number == 4) {
         $this$int_u24lambda_u2d141.iconst_4();
      } else if (number == 5) {
         $this$int_u24lambda_u2d141.iconst_5();
      } else if (6 <= number ? number <= 127 : false) {
         $this$int_u24lambda_u2d141.bipush(number);
      } else if (-127 <= number ? number <= -2 : false) {
         $this$int_u24lambda_u2d141.bipush(number);
      } else if (128 <= number ? number <= 32768 : false) {
         $this$int_u24lambda_u2d141.sipush(number);
      } else if (-32768 <= number ? number <= -128 : false) {
         $this$int_u24lambda_u2d141.sipush(number);
      } else {
         $this$int_u24lambda_u2d141.ldc(number);
      }

      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder double(double number) {
      boolean var4 = false;
      boolean var5 = false;
      InsnListBuilder $this$double_u24lambda_u2d142 = (InsnListBuilder)this;
      int var7 = false;
      if (number == 0.0D) {
         $this$double_u24lambda_u2d142.dconst_0();
      } else if (number == 1.0D) {
         $this$double_u24lambda_u2d142.dconst_1();
      } else {
         $this$double_u24lambda_u2d142.ldc(number);
      }

      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder float(float number) {
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$float_u24lambda_u2d143 = (InsnListBuilder)this;
      int var6 = false;
      if (number == 0.0F) {
         $this$float_u24lambda_u2d143.fconst_0();
      } else if (number == 1.0F) {
         $this$float_u24lambda_u2d143.fconst_1();
      } else if (number == 2.0F) {
         $this$float_u24lambda_u2d143.fconst_2();
      } else {
         $this$float_u24lambda_u2d143.ldc(number);
      }

      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder long(long number) {
      boolean var4 = false;
      boolean var5 = false;
      InsnListBuilder $this$long_u24lambda_u2d144 = (InsnListBuilder)this;
      int var7 = false;
      if (number == 0L) {
         $this$long_u24lambda_u2d144.lconst_0();
      } else if (number == 1L) {
         $this$long_u24lambda_u2d144.lconst_1();
      } else {
         $this$long_u24lambda_u2d144.ldc(number);
      }

      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder synchronized(@NotNull Function1<? super InsnListBuilder, Unit> code) {
      Intrinsics.checkNotNullParameter(code, "code");
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$synchronized_u24lambda_u2d145 = (InsnListBuilder)this;
      int var6 = false;
      $this$synchronized_u24lambda_u2d145.dup();
      Local syncObj = $this$synchronized_u24lambda_u2d145.astore();
      $this$synchronized_u24lambda_u2d145.monitorenter();
      code.invoke($this$synchronized_u24lambda_u2d145);
      $this$synchronized_u24lambda_u2d145.load(syncObj);
      $this$synchronized_u24lambda_u2d145.monitorexit();
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder ifClause(@NotNull JumpCondition[] conditions, @NotNull Function1<? super InsnListBuilder, Unit> code) {
      Intrinsics.checkNotNullParameter(conditions, "conditions");
      Intrinsics.checkNotNullParameter(code, "code");
      boolean var4 = false;
      boolean var5 = false;
      InsnListBuilder $this$ifClause_u24lambda_u2d146 = (InsnListBuilder)this;
      int var7 = false;
      LabelNode label = $this$ifClause_u24lambda_u2d146.makeLabel();
      JumpCondition[] var9 = conditions;
      int var10 = 0;
      int var11 = conditions.length;

      while(var10 < var11) {
         JumpCondition condition = var9[var10];
         ++var10;
         $this$ifClause_u24lambda_u2d146.jump(condition, label);
      }

      code.invoke($this$ifClause_u24lambda_u2d146);
      $this$ifClause_u24lambda_u2d146.placeLabel(label);
      return (InsnListBuilder)this;
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder createInstance(@NotNull String className, @NotNull String constructorDescription, @NotNull Function1<? super InsnListBuilder, Unit> parameters) {
      Intrinsics.checkNotNullParameter(className, "className");
      Intrinsics.checkNotNullParameter(constructorDescription, "constructorDescription");
      Intrinsics.checkNotNullParameter(parameters, "parameters");
      boolean var5 = false;
      boolean var6 = false;
      InsnListBuilder $this$createInstance_u24lambda_u2d147 = (InsnListBuilder)this;
      int var8 = false;
      $this$createInstance_u24lambda_u2d147.new(className);
      $this$createInstance_u24lambda_u2d147.dup();
      parameters.invoke($this$createInstance_u24lambda_u2d147);
      invoke$default($this$createInstance_u24lambda_u2d147, InvokeType.SPECIAL, className, "<init>", constructorDescription, (Function1)null, 16, (Object)null);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder createInstance$default(InsnListBuilder var0, String var1, String var2, Function1 var3, int var4, Object var5) {
      if (var5 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: createInstance");
      } else {
         if ((var4 & 4) != 0) {
            var3 = (Function1)null.INSTANCE;
         }

         return var0.createInstance(var1, var2, var3);
      }
   }

   @NotNull
   public final InsnListBuilder ifElseClause(@NotNull JumpCondition[] conditions, @NotNull Function1<? super IfElseBuilder, Unit> builder) {
      Intrinsics.checkNotNullParameter(conditions, "conditions");
      Intrinsics.checkNotNullParameter(builder, "builder");
      boolean var4 = false;
      boolean var5 = false;
      InsnListBuilder $this$ifElseClause_u24lambda_u2d148 = (InsnListBuilder)this;
      int var7 = false;
      IfElseBuilder ifElse = new IfElseBuilder($this$ifElseClause_u24lambda_u2d148.getToInjectInto());
      builder.invoke(ifElse);
      LabelNode ifLabel = $this$ifElseClause_u24lambda_u2d148.makeLabel();
      LabelNode endLabel = $this$ifElseClause_u24lambda_u2d148.makeLabel();
      JumpCondition[] var11 = conditions;
      int var12 = 0;
      int var13 = conditions.length;

      while(var12 < var13) {
         JumpCondition cond = var11[var12];
         ++var12;
         $this$ifElseClause_u24lambda_u2d148.jump(cond, ifLabel);
      }

      $this$ifElseClause_u24lambda_u2d148.insertInsns(ifElse.getElseCode());
      $this$ifElseClause_u24lambda_u2d148.jump(JumpCondition.GOTO, endLabel);
      $this$ifElseClause_u24lambda_u2d148.placeLabel(ifLabel);
      $this$ifElseClause_u24lambda_u2d148.insertInsns(ifElse.getIfCode());
      $this$ifElseClause_u24lambda_u2d148.placeLabel(endLabel);
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder getStatic(@NotNull String owner, @NotNull String name, @NotNull String desc) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      boolean var5 = false;
      boolean var6 = false;
      InsnListBuilder $this$getStatic_u24lambda_u2d149 = (InsnListBuilder)this;
      int var8 = false;
      $this$getStatic_u24lambda_u2d149.field(FieldAction.GET_STATIC, owner, name, desc);
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder getField(@NotNull String owner, @NotNull String name, @NotNull String desc) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      boolean var5 = false;
      boolean var6 = false;
      InsnListBuilder $this$getField_u24lambda_u2d150 = (InsnListBuilder)this;
      int var8 = false;
      $this$getField_u24lambda_u2d150.field(FieldAction.GET_FIELD, owner, name, desc);
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder putStatic(@NotNull String owner, @NotNull String name, @NotNull String desc) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      boolean var5 = false;
      boolean var6 = false;
      InsnListBuilder $this$putStatic_u24lambda_u2d151 = (InsnListBuilder)this;
      int var8 = false;
      $this$putStatic_u24lambda_u2d151.field(FieldAction.PUT_STATIC, owner, name, desc);
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder putField(@NotNull String owner, @NotNull String name, @NotNull String desc) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      boolean var5 = false;
      boolean var6 = false;
      InsnListBuilder $this$putField_u24lambda_u2d152 = (InsnListBuilder)this;
      int var8 = false;
      $this$putField_u24lambda_u2d152.field(FieldAction.PUT_FIELD, owner, name, desc);
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder field(@NotNull FieldAction action, @NotNull Descriptor descriptor) {
      Intrinsics.checkNotNullParameter(action, "action");
      Intrinsics.checkNotNullParameter(descriptor, "descriptor");
      return this.field(action, descriptor.getOwner(), descriptor.getName(), descriptor.getDesc());
   }

   @NotNull
   public final InsnListBuilder field(@NotNull FieldAction action, @NotNull String owner, @NotNull String name, @NotNull String desc) {
      Intrinsics.checkNotNullParameter(action, "action");
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      boolean var6 = false;
      boolean var7 = false;
      InsnListBuilder $this$field_u24lambda_u2d153 = (InsnListBuilder)this;
      int var9 = false;
      String realName = AsmHelper.INSTANCE.getRemapper().mapFieldAccess(name);
      $this$field_u24lambda_u2d153.getInsnList().add((AbstractInsnNode)(new FieldInsnNode(action.getOpcode(), owner, realName, desc)));
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder getLocalField(@NotNull Descriptor descriptor) {
      Intrinsics.checkNotNullParameter(descriptor, "descriptor");
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$getLocalField_u24lambda_u2d154 = (InsnListBuilder)this;
      int var6 = false;
      $this$getLocalField_u24lambda_u2d154.aload(0);
      $this$getLocalField_u24lambda_u2d154.field(FieldAction.GET_FIELD, descriptor);
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder updateLocalField(@NotNull Descriptor descriptor, @NotNull Function1<? super InsnListBuilder, Unit> updater) {
      Intrinsics.checkNotNullParameter(descriptor, "descriptor");
      Intrinsics.checkNotNullParameter(updater, "updater");
      boolean var4 = false;
      boolean var5 = false;
      InsnListBuilder $this$updateLocalField_u24lambda_u2d155 = (InsnListBuilder)this;
      int var7 = false;
      $this$updateLocalField_u24lambda_u2d155.aload(0);
      $this$updateLocalField_u24lambda_u2d155.getLocalField(descriptor);
      updater.invoke($this$updateLocalField_u24lambda_u2d155);
      $this$updateLocalField_u24lambda_u2d155.field(FieldAction.PUT_FIELD, descriptor);
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder setLocalField(@NotNull Descriptor descriptor, @NotNull Function1<? super InsnListBuilder, Unit> newValue) {
      Intrinsics.checkNotNullParameter(descriptor, "descriptor");
      Intrinsics.checkNotNullParameter(newValue, "newValue");
      boolean var4 = false;
      boolean var5 = false;
      InsnListBuilder $this$setLocalField_u24lambda_u2d156 = (InsnListBuilder)this;
      int var7 = false;
      $this$setLocalField_u24lambda_u2d156.aload(0);
      newValue.invoke($this$setLocalField_u24lambda_u2d156);
      $this$setLocalField_u24lambda_u2d156.field(FieldAction.PUT_FIELD, descriptor);
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder getLocalField(@NotNull String owner, @NotNull String name, @NotNull String desc) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      boolean var5 = false;
      boolean var6 = false;
      InsnListBuilder $this$getLocalField_u24lambda_u2d157 = (InsnListBuilder)this;
      int var8 = false;
      $this$getLocalField_u24lambda_u2d157.aload(0);
      $this$getLocalField_u24lambda_u2d157.field(FieldAction.GET_FIELD, owner, name, desc);
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder updateLocalField(@NotNull String owner, @NotNull String name, @NotNull String desc, @NotNull Function1<? super InsnListBuilder, Unit> updater) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      Intrinsics.checkNotNullParameter(updater, "updater");
      boolean var6 = false;
      boolean var7 = false;
      InsnListBuilder $this$updateLocalField_u24lambda_u2d158 = (InsnListBuilder)this;
      int var9 = false;
      $this$updateLocalField_u24lambda_u2d158.aload(0);
      $this$updateLocalField_u24lambda_u2d158.getLocalField(owner, name, desc);
      updater.invoke($this$updateLocalField_u24lambda_u2d158);
      $this$updateLocalField_u24lambda_u2d158.field(FieldAction.PUT_FIELD, owner, name, desc);
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder setLocalField(@NotNull String owner, @NotNull String name, @NotNull String desc, @NotNull Function1<? super InsnListBuilder, Unit> newValue) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      Intrinsics.checkNotNullParameter(newValue, "newValue");
      boolean var6 = false;
      boolean var7 = false;
      InsnListBuilder $this$setLocalField_u24lambda_u2d159 = (InsnListBuilder)this;
      int var9 = false;
      $this$setLocalField_u24lambda_u2d159.aload(0);
      newValue.invoke($this$setLocalField_u24lambda_u2d159);
      $this$setLocalField_u24lambda_u2d159.field(FieldAction.PUT_FIELD, owner, name, desc);
      return (InsnListBuilder)this;
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invoke(@NotNull InvokeType type, @NotNull Descriptor descriptor, @Nullable Function1<? super InsnListBuilder, Unit> arguments) {
      Intrinsics.checkNotNullParameter(type, "type");
      Intrinsics.checkNotNullParameter(descriptor, "descriptor");
      return this.invoke(type, descriptor.getOwner(), descriptor.getName(), descriptor.getDesc(), arguments);
   }

   // $FF: synthetic method
   public static InsnListBuilder invoke$default(InsnListBuilder var0, InvokeType var1, Descriptor var2, Function1 var3, int var4, Object var5) {
      if (var5 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: invoke");
      } else {
         if ((var4 & 4) != 0) {
            var3 = null;
         }

         return var0.invoke(var1, var2, var3);
      }
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invokeStatic(@NotNull String owner, @NotNull String name, @NotNull String desc, @Nullable Function1<? super InsnListBuilder, Unit> arguments) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      boolean var6 = false;
      boolean var7 = false;
      InsnListBuilder $this$invokeStatic_u24lambda_u2d160 = (InsnListBuilder)this;
      int var9 = false;
      $this$invokeStatic_u24lambda_u2d160.invoke(InvokeType.STATIC, owner, name, desc, arguments);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder invokeStatic$default(InsnListBuilder var0, String var1, String var2, String var3, Function1 var4, int var5, Object var6) {
      if (var6 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: invokeStatic");
      } else {
         if ((var5 & 8) != 0) {
            var4 = null;
         }

         return var0.invokeStatic(var1, var2, var3, var4);
      }
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invokeVirtual(@NotNull String owner, @NotNull String name, @NotNull String desc, @Nullable Function1<? super InsnListBuilder, Unit> arguments) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      boolean var6 = false;
      boolean var7 = false;
      InsnListBuilder $this$invokeVirtual_u24lambda_u2d161 = (InsnListBuilder)this;
      int var9 = false;
      $this$invokeVirtual_u24lambda_u2d161.invoke(InvokeType.VIRTUAL, owner, name, desc, arguments);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder invokeVirtual$default(InsnListBuilder var0, String var1, String var2, String var3, Function1 var4, int var5, Object var6) {
      if (var6 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: invokeVirtual");
      } else {
         if ((var5 & 8) != 0) {
            var4 = null;
         }

         return var0.invokeVirtual(var1, var2, var3, var4);
      }
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invokeSpecial(@NotNull String owner, @NotNull String name, @NotNull String desc, @Nullable Function1<? super InsnListBuilder, Unit> arguments) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      boolean var6 = false;
      boolean var7 = false;
      InsnListBuilder $this$invokeSpecial_u24lambda_u2d162 = (InsnListBuilder)this;
      int var9 = false;
      $this$invokeSpecial_u24lambda_u2d162.invoke(InvokeType.SPECIAL, owner, name, desc, arguments);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder invokeSpecial$default(InsnListBuilder var0, String var1, String var2, String var3, Function1 var4, int var5, Object var6) {
      if (var6 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: invokeSpecial");
      } else {
         if ((var5 & 8) != 0) {
            var4 = null;
         }

         return var0.invokeSpecial(var1, var2, var3, var4);
      }
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invokeInterface(@NotNull String owner, @NotNull String name, @NotNull String desc, @Nullable Function1<? super InsnListBuilder, Unit> arguments) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      boolean var6 = false;
      boolean var7 = false;
      InsnListBuilder $this$invokeInterface_u24lambda_u2d163 = (InsnListBuilder)this;
      int var9 = false;
      $this$invokeInterface_u24lambda_u2d163.invoke(InvokeType.INTERFACE, owner, name, desc, arguments);
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder invokeInterface$default(InsnListBuilder var0, String var1, String var2, String var3, Function1 var4, int var5, Object var6) {
      if (var6 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: invokeInterface");
      } else {
         if ((var5 & 8) != 0) {
            var4 = null;
         }

         return var0.invokeInterface(var1, var2, var3, var4);
      }
   }

   @NotNull
   public final Handle handle(int tag, @NotNull String owner, @NotNull String name, @NotNull String desc) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      String realName = AsmHelper.INSTANCE.getRemapper().mapInvocation(name);
      return new Handle(tag, owner, realName, desc);
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invokeDynamic(@NotNull String owner, @NotNull String name, @NotNull String desc, @NotNull Handle bootstrapMethod, @NotNull Object[] bootstrapConstantArgs, @Nullable Function1<? super InsnListBuilder, Unit> arguments) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      Intrinsics.checkNotNullParameter(bootstrapMethod, "bootstrapMethod");
      Intrinsics.checkNotNullParameter(bootstrapConstantArgs, "bootstrapConstantArgs");
      boolean var8 = false;
      boolean var9 = false;
      InsnListBuilder $this$invokeDynamic_u24lambda_u2d164 = (InsnListBuilder)this;
      int var11 = false;
      String realName = AsmHelper.INSTANCE.getRemapper().mapInvocation(name);
      if (arguments != null) {
         InsnListBuilder insns = new InsnListBuilder($this$invokeDynamic_u24lambda_u2d164.getToInjectInto());
         arguments.invoke(insns);
         $this$invokeDynamic_u24lambda_u2d164.getInsnList().add(insns.build());
      }

      $this$invokeDynamic_u24lambda_u2d164.getInsnList().add((AbstractInsnNode)(new InvokeDynamicInsnNode(realName, desc, bootstrapMethod, Arrays.copyOf(bootstrapConstantArgs, bootstrapConstantArgs.length))));
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder invokeDynamic$default(InsnListBuilder var0, String var1, String var2, String var3, Handle var4, Object[] var5, Function1 var6, int var7, Object var8) {
      if (var8 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: invokeDynamic");
      } else {
         if ((var7 & 32) != 0) {
            var6 = null;
         }

         return var0.invokeDynamic(var1, var2, var3, var4, var5, var6);
      }
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invoke(@NotNull InvokeType type, @NotNull String owner, @NotNull String name, @NotNull String desc, @Nullable Function1<? super InsnListBuilder, Unit> arguments) {
      Intrinsics.checkNotNullParameter(type, "type");
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      boolean var7 = false;
      boolean var8 = false;
      InsnListBuilder $this$invoke_u24lambda_u2d165 = (InsnListBuilder)this;
      int var10 = false;
      String realName = AsmHelper.INSTANCE.getRemapper().mapInvocation(name);
      if (arguments != null) {
         InsnListBuilder insns = new InsnListBuilder($this$invoke_u24lambda_u2d165.getToInjectInto());
         arguments.invoke(insns);
         $this$invoke_u24lambda_u2d165.getInsnList().add(insns.build());
      }

      $this$invoke_u24lambda_u2d165.getInsnList().add((AbstractInsnNode)(new MethodInsnNode(type.getOpcode(), owner, realName, desc, type == InvokeType.INTERFACE)));
      return (InsnListBuilder)this;
   }

   // $FF: synthetic method
   public static InsnListBuilder invoke$default(InsnListBuilder var0, InvokeType var1, String var2, String var3, String var4, Function1 var5, int var6, Object var7) {
      if (var7 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: invoke");
      } else {
         if ((var6 & 16) != 0) {
            var5 = null;
         }

         return var0.invoke(var1, var2, var3, var4, var5);
      }
   }

   public final void tableswitch(@NotNull Function1<? super SwitchBuilder, Unit> builder) {
      Intrinsics.checkNotNullParameter(builder, "builder");
      SwitchBuilder var3 = new SwitchBuilder();
      boolean var4 = false;
      boolean $i$f$any = false;
      builder.invoke(var3);
      SwitchBuilder tableBuilder = var3;
      List cases = var3.getCases$AsmHelper1_8_9();
      if (cases.isEmpty()) {
         throw new IllegalStateException("tableswitch builder must have at least one case.");
      } else {
         Iterable $this$groupBy$iv = (Iterable)cases;
         $i$f$any = false;
         Map destination$iv$iv = (Map)(new LinkedHashMap());
         int $i$f$map = false;
         Iterator var9 = $this$groupBy$iv.iterator();

         boolean $i$f$getOrPut;
         Object element$iv$iv;
         while(var9.hasNext()) {
            Object element$iv$iv = var9.next();
            SwitchBuilder.Case it = (SwitchBuilder.Case)element$iv$iv;
            int var12 = false;
            Object key$iv$iv = it.getIndex();
            $i$f$getOrPut = false;
            element$iv$iv = destination$iv$iv.get(key$iv$iv);
            Object var10000;
            if (element$iv$iv == null) {
               int var17 = false;
               Object answer$iv$iv$iv = (List)(new ArrayList());
               destination$iv$iv.put(key$iv$iv, answer$iv$iv$iv);
               var10000 = answer$iv$iv$iv;
            } else {
               var10000 = element$iv$iv;
            }

            List list$iv$iv = (List)var10000;
            list$iv$iv.add(element$iv$iv);
         }

         $i$f$any = false;
         boolean var31;
         Iterator var33;
         boolean $i$f$forEach;
         boolean var61;
         if (destination$iv$iv.isEmpty()) {
            var61 = false;
         } else {
            label137: {
               Map var6 = destination$iv$iv;
               var31 = false;
               var33 = var6.entrySet().iterator();

               while(var33.hasNext()) {
                  Entry element$iv = (Entry)var33.next();
                  $i$f$forEach = false;
                  if (((List)element$iv.getValue()).size() != 1) {
                     var61 = true;
                     break label137;
                  }
               }

               var61 = false;
            }
         }

         if (var61) {
            throw new IllegalStateException("tableswitch builder cannot contain duplicate cases.");
         } else {
            Iterable var26 = (Iterable)cases;
            boolean var27 = false;
            Iterator var32 = var26.iterator();
            if (!var32.hasNext()) {
               throw (Throwable)(new NoSuchElementException());
            } else {
               SwitchBuilder.Case it = (SwitchBuilder.Case)var32.next();
               int var39 = false;
               int var37 = it.getIndex();

               SwitchBuilder.Case it;
               boolean var41;
               int var42;
               while(var32.hasNext()) {
                  it = (SwitchBuilder.Case)var32.next();
                  var41 = false;
                  var42 = it.getIndex();
                  if (var37 > var42) {
                     var37 = var42;
                  }
               }

               int min = var37;
               Iterable var29 = (Iterable)cases;
               var31 = false;
               var33 = var29.iterator();
               if (!var33.hasNext()) {
                  throw (Throwable)(new NoSuchElementException());
               } else {
                  it = (SwitchBuilder.Case)var33.next();
                  var41 = false;
                  var42 = it.getIndex();

                  while(var33.hasNext()) {
                     SwitchBuilder.Case it = (SwitchBuilder.Case)var33.next();
                     $i$f$forEach = false;
                     int var46 = it.getIndex();
                     if (var42 < var46) {
                        var42 = var46;
                     }
                  }

                  int max = var42;
                  Iterable $this$map$iv = (Iterable)(new IntRange(min, var42));
                  $i$f$map = false;
                  Collection $this$toTypedArray$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
                  $i$f$forEach = false;
                  Iterator var51 = $this$map$iv.iterator();

                  while(var51.hasNext()) {
                     int item$iv$iv = ((IntIterator)var51).nextInt();
                     $i$f$getOrPut = false;
                     LabelNode var22 = this.makeLabel();
                     $this$toTypedArray$iv.add(var22);
                  }

                  List labels = (List)$this$toTypedArray$iv;
                  LabelNode defaultLabel = this.makeLabel();
                  LabelNode endLabel = this.makeLabel();
                  TableSwitchInsnNode var10001 = new TableSwitchInsnNode;
                  $this$toTypedArray$iv = (Collection)labels;
                  $i$f$forEach = false;
                  Object[] var10006 = $this$toTypedArray$iv.toArray(new LabelNode[0]);
                  if (var10006 == null) {
                     throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
                  } else {
                     LabelNode[] var49 = (LabelNode[])var10006;
                     var10001.<init>(min, max, defaultLabel, (LabelNode[])Arrays.copyOf(var49, var49.length));
                     this.insn$AsmHelper1_8_9((AbstractInsnNode)var10001);
                     var41 = false;
                     List usedLabels = (List)(new ArrayList());
                     Iterable $this$forEach$iv = (Iterable)cases;
                     $i$f$forEach = false;
                     var51 = $this$forEach$iv.iterator();

                     Object element$iv;
                     while(var51.hasNext()) {
                        element$iv = var51.next();
                        SwitchBuilder.Case var14 = (SwitchBuilder.Case)element$iv;
                        $i$f$getOrPut = false;
                        LabelNode label = (LabelNode)labels.get(var14.getIndex() - min);
                        usedLabels.add(label);
                        this.placeLabel(label);
                        Function1 var18 = var14.getBuilder();
                        boolean var19 = false;
                        boolean var20 = false;
                        var18.invoke(this);
                        if (!var14.getFallthrough()) {
                           this.jump(JumpCondition.GOTO, endLabel);
                        }
                     }

                     this.placeLabel(defaultLabel);
                     $this$forEach$iv = (Iterable)labels;
                     $i$f$forEach = false;
                     Collection destination$iv$iv = (Collection)(new ArrayList());
                     int $i$f$filterTo = false;
                     Iterator var59 = $this$forEach$iv.iterator();

                     while(var59.hasNext()) {
                        element$iv$iv = var59.next();
                        LabelNode it = (LabelNode)element$iv$iv;
                        int var64 = false;
                        if (!usedLabels.contains(it)) {
                           destination$iv$iv.add(element$iv$iv);
                        }
                     }

                     $this$forEach$iv = (Iterable)((List)destination$iv$iv);
                     $i$f$forEach = false;
                     var51 = $this$forEach$iv.iterator();

                     while(var51.hasNext()) {
                        element$iv = var51.next();
                        LabelNode it = (LabelNode)element$iv;
                        $i$f$getOrPut = false;
                        this.placeLabel(it);
                     }

                     Function1 var55 = tableBuilder.getDefaultCase$AsmHelper1_8_9();
                     if (var55 != null) {
                        var55.invoke(this);
                     }

                     this.placeLabel(endLabel);
                  }
               }
            }
         }
      }
   }

   public final void lookupswitch(@NotNull Function1<? super SwitchBuilder, Unit> builder) {
      Intrinsics.checkNotNullParameter(builder, "builder");
      SwitchBuilder var3 = new SwitchBuilder();
      boolean var4 = false;
      boolean $i$f$any = false;
      builder.invoke(var3);
      List cases = var3.getCases$AsmHelper1_8_9();
      if (cases.isEmpty()) {
         throw new IllegalStateException("lookupswitch builder must have at least one case.");
      } else {
         Iterable $this$groupBy$iv = (Iterable)cases;
         $i$f$any = false;
         Map destination$iv$iv = (Map)(new LinkedHashMap());
         int $i$f$forEachIndexed = false;
         Iterator var9 = $this$groupBy$iv.iterator();

         boolean $i$f$getOrPut;
         while(var9.hasNext()) {
            Object element$iv$iv = var9.next();
            SwitchBuilder.Case it = (SwitchBuilder.Case)element$iv$iv;
            int var12 = false;
            Object key$iv$iv = it.getIndex();
            $i$f$getOrPut = false;
            Object value$iv$iv$iv = destination$iv$iv.get(key$iv$iv);
            Object var10000;
            if (value$iv$iv$iv == null) {
               int var17 = false;
               Object answer$iv$iv$iv = (List)(new ArrayList());
               destination$iv$iv.put(key$iv$iv, answer$iv$iv$iv);
               var10000 = answer$iv$iv$iv;
            } else {
               var10000 = value$iv$iv$iv;
            }

            List list$iv$iv = (List)var10000;
            list$iv$iv.add(element$iv$iv);
         }

         $i$f$any = false;
         boolean $i$f$mapTo;
         boolean var58;
         if (destination$iv$iv.isEmpty()) {
            var58 = false;
         } else {
            label93: {
               boolean var38 = false;
               Iterator var41 = destination$iv$iv.entrySet().iterator();

               while(var41.hasNext()) {
                  Entry element$iv = (Entry)var41.next();
                  $i$f$mapTo = false;
                  if (((List)element$iv.getValue()).size() != 1) {
                     var58 = true;
                     break label93;
                  }
               }

               var58 = false;
            }
         }

         if (var58) {
            throw new IllegalStateException("lookupswitch builder cannot contain duplicate cases.");
         } else {
            Iterable $this$map$iv = (Iterable)CollectionsKt.getIndices((Collection)cases);
            int $i$f$map = false;
            Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
            int $i$f$mapTo = false;
            Iterator var47 = $this$map$iv.iterator();

            boolean var55;
            while(var47.hasNext()) {
               int item$iv$iv = ((IntIterator)var47).nextInt();
               var55 = false;
               LabelNode var23 = this.makeLabel();
               destination$iv$iv.add(var23);
            }

            List labels = (List)destination$iv$iv;
            LabelNode defaultLabel = this.makeLabel();
            LabelNode endLabel = this.makeLabel();
            Iterable $this$forEachIndexed$iv = (Iterable)cases;
            $i$f$forEachIndexed = false;
            Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$forEachIndexed$iv, 10)));
            $i$f$mapTo = false;
            Iterator var52 = $this$forEachIndexed$iv.iterator();

            SwitchBuilder.Case it;
            while(var52.hasNext()) {
               Object item$iv$iv = var52.next();
               it = (SwitchBuilder.Case)item$iv$iv;
               $i$f$getOrPut = false;
               Integer var27 = it.getIndex();
               destination$iv$iv.add(var27);
            }

            List var26 = (List)destination$iv$iv;
            int[] var10002 = CollectionsKt.toIntArray((Collection)var26);
            Collection $this$toTypedArray$iv = (Collection)labels;
            $i$f$forEachIndexed = false;
            Object[] var10003 = $this$toTypedArray$iv.toArray(new LabelNode[0]);
            if (var10003 == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
            } else {
               LabelNode[] var28 = (LabelNode[])var10003;
               int[] var29 = var10002;
               this.insn$AsmHelper1_8_9((AbstractInsnNode)(new LookupSwitchInsnNode(defaultLabel, var29, var28)));
               $this$forEachIndexed$iv = (Iterable)cases;
               $i$f$forEachIndexed = false;
               int index$iv = 0;
               var47 = $this$forEachIndexed$iv.iterator();

               while(var47.hasNext()) {
                  Object item$iv = var47.next();
                  int var54 = index$iv++;
                  var55 = false;
                  if (var54 < 0) {
                     CollectionsKt.throwIndexOverflow();
                  }

                  it = (SwitchBuilder.Case)item$iv;
                  int var57 = false;
                  LabelNode label = (LabelNode)labels.get(var54);
                  this.placeLabel(label);
                  Function1 var19 = it.getBuilder();
                  boolean var20 = false;
                  boolean var21 = false;
                  var19.invoke(this);
                  if (!it.getFallthrough()) {
                     this.jump(JumpCondition.GOTO, endLabel);
                  }
               }

               this.placeLabel(defaultLabel);
               Function1 var43 = var3.getDefaultCase$AsmHelper1_8_9();
               if (var43 != null) {
                  var43.invoke(this);
               }

               this.placeLabel(endLabel);
            }
         }
      }
   }

   @NotNull
   public final Local astore() {
      this.astore(this.currentLocalIndex);
      int var2 = this.currentLocalIndex++;
      return new Local(var2, LocalType.OBJECT);
   }

   @NotNull
   public final Local fstore() {
      this.fstore(this.currentLocalIndex);
      int var2 = this.currentLocalIndex++;
      return new Local(var2, LocalType.FLOAT);
   }

   @NotNull
   public final Local istore() {
      this.istore(this.currentLocalIndex);
      int var2 = this.currentLocalIndex++;
      return new Local(var2, LocalType.INT);
   }

   @NotNull
   public final Local dstore() {
      this.dstore(this.currentLocalIndex);
      int var2 = this.currentLocalIndex++;
      return new Local(var2, LocalType.DOUBLE);
   }

   @NotNull
   public final Local lstore() {
      this.lstore(this.currentLocalIndex);
      int var2 = this.currentLocalIndex++;
      return new Local(var2, LocalType.LONG);
   }

   @NotNull
   public final InsnListBuilder load(@NotNull Local local) {
      Intrinsics.checkNotNullParameter(local, "local");
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$load_u24lambda_u2d179 = (InsnListBuilder)this;
      int var6 = false;
      LocalType var7 = local.getType();
      int var8 = InsnListBuilder.WhenMappings.$EnumSwitchMapping$0[var7.ordinal()];
      switch(var8) {
      case 1:
         $this$load_u24lambda_u2d179.aload(local.getIndex());
         break;
      case 2:
         $this$load_u24lambda_u2d179.fload(local.getIndex());
         break;
      case 3:
         $this$load_u24lambda_u2d179.iload(local.getIndex());
         break;
      case 4:
         $this$load_u24lambda_u2d179.dload(local.getIndex());
         break;
      case 5:
         $this$load_u24lambda_u2d179.lload(local.getIndex());
      }

      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnListBuilder insertInsns(@NotNull InsnList list) {
      Intrinsics.checkNotNullParameter(list, "list");
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$insertInsns_u24lambda_u2d180 = (InsnListBuilder)this;
      int var6 = false;
      $this$insertInsns_u24lambda_u2d180.getInsnList().add(list);
      return (InsnListBuilder)this;
   }

   @NotNull
   public final InsnList build() {
      return this.insnList;
   }

   @NotNull
   public final InsnListBuilder insn$AsmHelper1_8_9(@NotNull AbstractInsnNode node) {
      Intrinsics.checkNotNullParameter(node, "node");
      boolean var3 = false;
      boolean var4 = false;
      InsnListBuilder $this$insn_u24lambda_u2d181 = (InsnListBuilder)this;
      int var6 = false;
      $this$insn_u24lambda_u2d181.getInsnList().add(node);
      return (InsnListBuilder)this;
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invokeKObjectFunction(@NotNull String objectClassName, @NotNull String methodName, @NotNull String methodDesc) {
      Intrinsics.checkNotNullParameter(objectClassName, "objectClassName");
      Intrinsics.checkNotNullParameter(methodName, "methodName");
      Intrinsics.checkNotNullParameter(methodDesc, "methodDesc");
      return invokeKObjectFunction$default(this, objectClassName, methodName, methodDesc, (Function1)null, 8, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder createInstance(@NotNull String className, @NotNull String constructorDescription) {
      Intrinsics.checkNotNullParameter(className, "className");
      Intrinsics.checkNotNullParameter(constructorDescription, "constructorDescription");
      return createInstance$default(this, className, constructorDescription, (Function1)null, 4, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invoke(@NotNull InvokeType type, @NotNull Descriptor descriptor) {
      Intrinsics.checkNotNullParameter(type, "type");
      Intrinsics.checkNotNullParameter(descriptor, "descriptor");
      return invoke$default(this, type, descriptor, (Function1)null, 4, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invokeStatic(@NotNull String owner, @NotNull String name, @NotNull String desc) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      return invokeStatic$default(this, owner, name, desc, (Function1)null, 8, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invokeVirtual(@NotNull String owner, @NotNull String name, @NotNull String desc) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      return invokeVirtual$default(this, owner, name, desc, (Function1)null, 8, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invokeSpecial(@NotNull String owner, @NotNull String name, @NotNull String desc) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      return invokeSpecial$default(this, owner, name, desc, (Function1)null, 8, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invokeInterface(@NotNull String owner, @NotNull String name, @NotNull String desc) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      return invokeInterface$default(this, owner, name, desc, (Function1)null, 8, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invokeDynamic(@NotNull String owner, @NotNull String name, @NotNull String desc, @NotNull Handle bootstrapMethod, @NotNull Object... bootstrapConstantArgs) {
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      Intrinsics.checkNotNullParameter(bootstrapMethod, "bootstrapMethod");
      Intrinsics.checkNotNullParameter(bootstrapConstantArgs, "bootstrapConstantArgs");
      return invokeDynamic$default(this, owner, name, desc, bootstrapMethod, bootstrapConstantArgs, (Function1)null, 32, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final InsnListBuilder invoke(@NotNull InvokeType type, @NotNull String owner, @NotNull String name, @NotNull String desc) {
      Intrinsics.checkNotNullParameter(type, "type");
      Intrinsics.checkNotNullParameter(owner, "owner");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(desc, "desc");
      return invoke$default(this, type, owner, name, desc, (Function1)null, 16, (Object)null);
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 5, 1},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[LocalType.values().length];
         var0[LocalType.OBJECT.ordinal()] = 1;
         var0[LocalType.FLOAT.ordinal()] = 2;
         var0[LocalType.INT.ordinal()] = 3;
         var0[LocalType.DOUBLE.ordinal()] = 4;
         var0[LocalType.LONG.ordinal()] = 5;
         $EnumSwitchMapping$0 = var0;
      }
   }
}
