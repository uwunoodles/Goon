package dev.falsehonesty.asmhelper.dsl.instructions;

import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\u0018\u00002\u00020\u0001:\u0001\u0018B\u0005¢\u0006\u0002\u0010\u0002J1\u0010\u0011\u001a\u00020\u000b2\u0006\u0010\u0012\u001a\u00020\u00132\b\b\u0002\u0010\u0014\u001a\u00020\u00152\u0017\u0010\u0016\u001a\u0013\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b0\t¢\u0006\u0002\b\fJ\u001f\u0010\u0017\u001a\u00020\u000b2\u0017\u0010\u0016\u001a\u0013\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b0\t¢\u0006\u0002\b\fR\u001a\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R-\u0010\b\u001a\u0015\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\t¢\u0006\u0002\b\fX\u0080\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010¨\u0006\u0019"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/instructions/SwitchBuilder;", "", "()V", "cases", "", "Ldev/falsehonesty/asmhelper/dsl/instructions/SwitchBuilder$Case;", "getCases$AsmHelper1_8_9", "()Ljava/util/List;", "defaultCase", "Lkotlin/Function1;", "Ldev/falsehonesty/asmhelper/dsl/instructions/InsnListBuilder;", "", "Lkotlin/ExtensionFunctionType;", "getDefaultCase$AsmHelper1_8_9", "()Lkotlin/jvm/functions/Function1;", "setDefaultCase$AsmHelper1_8_9", "(Lkotlin/jvm/functions/Function1;)V", "case", "index", "", "fallthrough", "", "builder", "default", "Case", "AsmHelper1.8.9"}
)
public final class SwitchBuilder {
   @NotNull
   private final List<SwitchBuilder.Case> cases;
   @Nullable
   private Function1<? super InsnListBuilder, Unit> defaultCase;

   public SwitchBuilder() {
      boolean var1 = false;
      this.cases = (List)(new ArrayList());
   }

   @NotNull
   public final List<SwitchBuilder.Case> getCases$AsmHelper1_8_9() {
      return this.cases;
   }

   @Nullable
   public final Function1<InsnListBuilder, Unit> getDefaultCase$AsmHelper1_8_9() {
      return this.defaultCase;
   }

   public final void setDefaultCase$AsmHelper1_8_9(@Nullable Function1<? super InsnListBuilder, Unit> var1) {
      this.defaultCase = var1;
   }

   public final void case(int index, boolean fallthrough, @NotNull Function1<? super InsnListBuilder, Unit> builder) {
      Intrinsics.checkNotNullParameter(builder, "builder");
      this.cases.add(new SwitchBuilder.Case(index, fallthrough, builder));
   }

   // $FF: synthetic method
   public static void case$default(SwitchBuilder var0, int var1, boolean var2, Function1 var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = false;
      }

      var0.case(var1, var2, var3);
   }

   public final void default(@NotNull Function1<? super InsnListBuilder, Unit> builder) {
      Intrinsics.checkNotNullParameter(builder, "builder");
      this.defaultCase = builder;
   }

   @Metadata(
      mv = {1, 5, 1},
      k = 1,
      xi = 48,
      d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B.\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0017\u0010\u0006\u001a\u0013\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007¢\u0006\u0002\b\n¢\u0006\u0002\u0010\u000bJ\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0005HÆ\u0003J\u001a\u0010\u0014\u001a\u0013\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007¢\u0006\u0002\b\nHÆ\u0003J8\u0010\u0015\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\u0019\b\u0002\u0010\u0006\u001a\u0013\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007¢\u0006\u0002\b\nHÆ\u0001J\u0013\u0010\u0016\u001a\u00020\u00052\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0019\u001a\u00020\u001aHÖ\u0001R\"\u0010\u0006\u001a\u0013\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007¢\u0006\u0002\b\n¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u001b"},
      d2 = {"Ldev/falsehonesty/asmhelper/dsl/instructions/SwitchBuilder$Case;", "", "index", "", "fallthrough", "", "builder", "Lkotlin/Function1;", "Ldev/falsehonesty/asmhelper/dsl/instructions/InsnListBuilder;", "", "Lkotlin/ExtensionFunctionType;", "(IZLkotlin/jvm/functions/Function1;)V", "getBuilder", "()Lkotlin/jvm/functions/Function1;", "getFallthrough", "()Z", "getIndex", "()I", "component1", "component2", "component3", "copy", "equals", "other", "hashCode", "toString", "", "AsmHelper1.8.9"}
   )
   public static final class Case {
      private final int index;
      private final boolean fallthrough;
      @NotNull
      private final Function1<InsnListBuilder, Unit> builder;

      public Case(int index, boolean fallthrough, @NotNull Function1<? super InsnListBuilder, Unit> builder) {
         Intrinsics.checkNotNullParameter(builder, "builder");
         super();
         this.index = index;
         this.fallthrough = fallthrough;
         this.builder = builder;
      }

      public final int getIndex() {
         return this.index;
      }

      public final boolean getFallthrough() {
         return this.fallthrough;
      }

      @NotNull
      public final Function1<InsnListBuilder, Unit> getBuilder() {
         return this.builder;
      }

      public final int component1() {
         return this.index;
      }

      public final boolean component2() {
         return this.fallthrough;
      }

      @NotNull
      public final Function1<InsnListBuilder, Unit> component3() {
         return this.builder;
      }

      @NotNull
      public final SwitchBuilder.Case copy(int index, boolean fallthrough, @NotNull Function1<? super InsnListBuilder, Unit> builder) {
         Intrinsics.checkNotNullParameter(builder, "builder");
         return new SwitchBuilder.Case(index, fallthrough, builder);
      }

      // $FF: synthetic method
      public static SwitchBuilder.Case copy$default(SwitchBuilder.Case var0, int var1, boolean var2, Function1 var3, int var4, Object var5) {
         if ((var4 & 1) != 0) {
            var1 = var0.index;
         }

         if ((var4 & 2) != 0) {
            var2 = var0.fallthrough;
         }

         if ((var4 & 4) != 0) {
            var3 = var0.builder;
         }

         return var0.copy(var1, var2, var3);
      }

      @NotNull
      public String toString() {
         return "Case(index=" + this.index + ", fallthrough=" + this.fallthrough + ", builder=" + this.builder + ')';
      }

      public int hashCode() {
         int result = Integer.hashCode(this.index);
         int var10000 = result * 31;
         byte var10001 = this.fallthrough;
         if (var10001 != 0) {
            var10001 = 1;
         }

         result = var10000 + var10001;
         result = result * 31 + this.builder.hashCode();
         return result;
      }

      public boolean equals(@Nullable Object other) {
         if (this == other) {
            return true;
         } else if (!(other instanceof SwitchBuilder.Case)) {
            return false;
         } else {
            SwitchBuilder.Case var2 = (SwitchBuilder.Case)other;
            if (this.index != var2.index) {
               return false;
            } else if (this.fallthrough != var2.fallthrough) {
               return false;
            } else {
               return Intrinsics.areEqual(this.builder, var2.builder);
            }
         }
      }
   }
}
