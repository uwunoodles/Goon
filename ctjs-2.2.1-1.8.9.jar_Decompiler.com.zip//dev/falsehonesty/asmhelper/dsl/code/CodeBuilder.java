package dev.falsehonesty.asmhelper.dsl.code;

import dev.falsehonesty.asmhelper.dsl.code.modifiers.Modifier;
import dev.falsehonesty.asmhelper.printing.PrettyprintingKt;
import dev.falsehonesty.asmhelper.printing.PrintingKt;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b&\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\f\u001a\u00020\rH\u0004J\u0006\u0010\u000e\u001a\u00020\u000fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0018\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\bX¦\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000b¨\u0006\u0010"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/CodeBuilder;", "", "codeClassNode", "Lorg/objectweb/asm/tree/ClassNode;", "(Lorg/objectweb/asm/tree/ClassNode;)V", "getCodeClassNode", "()Lorg/objectweb/asm/tree/ClassNode;", "modifiers", "", "Ldev/falsehonesty/asmhelper/dsl/code/modifiers/Modifier;", "getModifiers", "()Ljava/util/List;", "getMethodNode", "Lorg/objectweb/asm/tree/MethodNode;", "transformToInstructions", "Lorg/objectweb/asm/tree/InsnList;", "AsmHelper1.8.9"}
)
public abstract class CodeBuilder {
   @NotNull
   private final ClassNode codeClassNode;

   public CodeBuilder(@NotNull ClassNode codeClassNode) {
      Intrinsics.checkNotNullParameter(codeClassNode, "codeClassNode");
      super();
      this.codeClassNode = codeClassNode;
   }

   @NotNull
   public final ClassNode getCodeClassNode() {
      return this.codeClassNode;
   }

   @NotNull
   public abstract List<Modifier> getModifiers();

   @NotNull
   protected final MethodNode getMethodNode() {
      List var1 = this.codeClassNode.methods;
      Intrinsics.checkNotNullExpressionValue(var1, "codeClassNode.methods");
      Iterable var9 = (Iterable)var1;
      boolean var2 = false;
      boolean var4 = false;
      Iterator var5 = var9.iterator();

      Object var10000;
      while(true) {
         if (!var5.hasNext()) {
            var10000 = null;
            break;
         }

         Object var6 = var5.next();
         MethodNode it = (MethodNode)var6;
         int var8 = false;
         if (Intrinsics.areEqual(it.name, "invoke") && Intrinsics.areEqual(it.desc, "()V")) {
            var10000 = var6;
            break;
         }
      }

      Intrinsics.checkNotNull(var10000);
      return (MethodNode)var10000;
   }

   @NotNull
   public final InsnList transformToInstructions() {
      InsnList instructions = this.getMethodNode().instructions;
      PrintingKt.verbose(Intrinsics.stringPlus("Transforming code class ", this.codeClassNode.name));
      PrintingKt.verbose("Initial instruction list:");
      Intrinsics.checkNotNullExpressionValue(instructions, "instructions");
      PrintingKt.verbose(Intrinsics.stringPlus("\n", PrettyprintingKt.prettyString(instructions)));
      PrintingKt.verbose("-----------------");
      Iterable $this$forEach$iv = (Iterable)this.getModifiers();
      int $i$f$forEach = false;
      Iterator var4 = $this$forEach$iv.iterator();

      while(var4.hasNext()) {
         Object element$iv = var4.next();
         Modifier it = (Modifier)element$iv;
         int var7 = false;
         PrintingKt.verbose(Intrinsics.stringPlus("Running cycle ", it));
         PrintingKt.verbose("-----------------");
         it.modify(instructions);
         PrintingKt.verbose("-----------------");
         PrintingKt.verbose(Intrinsics.stringPlus("After cycle ", it));
         PrintingKt.verbose(Intrinsics.stringPlus("\n", PrettyprintingKt.prettyString(instructions)));
      }

      return instructions;
   }
}
