package dev.falsehonesty.asmhelper.dsl.code.modifiers;

import dev.falsehonesty.asmhelper.dsl.instructions.InsnListBuilder;
import dev.falsehonesty.asmhelper.printing.PrettyprintingKt;
import dev.falsehonesty.asmhelper.printing.PrintingKt;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0010\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0016J\u0018\u0010\u000b\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\nH\u0002R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u000e"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/modifiers/AsmBlockModifier;", "Ldev/falsehonesty/asmhelper/dsl/code/modifiers/Modifier;", "targetMethodNode", "Lorg/objectweb/asm/tree/MethodNode;", "(Lorg/objectweb/asm/tree/MethodNode;)V", "getTargetMethodNode", "()Lorg/objectweb/asm/tree/MethodNode;", "modify", "", "instructions", "Lorg/objectweb/asm/tree/InsnList;", "modifyAsmBlock", "node", "Lorg/objectweb/asm/tree/MethodInsnNode;", "AsmHelper1.8.9"}
)
public final class AsmBlockModifier extends Modifier {
   @NotNull
   private final MethodNode targetMethodNode;

   public AsmBlockModifier(@NotNull MethodNode targetMethodNode) {
      Intrinsics.checkNotNullParameter(targetMethodNode, "targetMethodNode");
      super();
      this.targetMethodNode = targetMethodNode;
   }

   @NotNull
   public final MethodNode getTargetMethodNode() {
      return this.targetMethodNode;
   }

   public void modify(@NotNull InsnList instructions) {
      Intrinsics.checkNotNullParameter(instructions, "instructions");
      ListIterator var2 = instructions.iterator();

      while(var2.hasNext()) {
         AbstractInsnNode node = (AbstractInsnNode)var2.next();
         if (node instanceof MethodInsnNode && ((MethodInsnNode)node).getOpcode() == 182 && Intrinsics.areEqual(((MethodInsnNode)node).name, "asm") && Intrinsics.areEqual(((MethodInsnNode)node).owner, "dev/falsehonesty/asmhelper/dsl/code/CodeBlock$Companion")) {
            this.modifyAsmBlock((MethodInsnNode)node, instructions);
         }
      }

   }

   private final void modifyAsmBlock(MethodInsnNode node, InsnList instructions) {
      AbstractInsnNode lambdaValue = node.getPrevious().getPrevious();
      if (!(lambdaValue instanceof FieldInsnNode)) {
         if (lambdaValue instanceof MethodInsnNode) {
            throw new IllegalArgumentException("Inline asm blocks can't capture locals");
         } else {
            throw new IllegalStateException(lambdaValue + " isn't expected");
         }
      } else {
         String bytecodeClassName = ((FieldInsnNode)lambdaValue).owner;
         Intrinsics.checkNotNullExpressionValue(bytecodeClassName, "bytecodeClassName");
         Class bytecodeClass = Class.forName(StringsKt.replace$default(bytecodeClassName, "/", ".", false, 4, (Object)null));
         Constructor[] var6 = bytecodeClass.getDeclaredConstructors();
         Intrinsics.checkNotNullExpressionValue(var6, "bytecodeClass.declaredConstructors");
         Constructor constr = (Constructor)ArraysKt.first((Object[])var6);
         constr.setAccessible(true);
         Object asmLambda = constr.newInstance();
         Method[] var8 = bytecodeClass.getDeclaredMethods();
         Intrinsics.checkNotNullExpressionValue(var8, "bytecodeClass.declaredMethods");
         Object[] $this$first$iv = (Object[])var8;
         boolean var9 = false;
         Object[] var10 = $this$first$iv;
         int var11 = $this$first$iv.length;

         for(int var12 = 0; var12 < var11; ++var12) {
            Object element$iv;
            boolean var15;
            boolean var10000;
            label46: {
               element$iv = var10[var12];
               Method it = (Method)element$iv;
               var15 = false;
               if (it.getParameters().length == 1) {
                  Parameter[] var16 = it.getParameters();
                  Intrinsics.checkNotNullExpressionValue(var16, "it.parameters");
                  if (Intrinsics.areEqual(((Parameter)ArraysKt.first((Object[])var16)).getType(), InsnListBuilder.class)) {
                     var10000 = true;
                     break label46;
                  }
               }

               var10000 = false;
            }

            if (var10000) {
               Method invokeMethod = (Method)element$iv;
               invokeMethod.setAccessible(true);
               InsnListBuilder builder = new InsnListBuilder(this.targetMethodNode);
               Object[] var22 = new Object[]{builder};
               invokeMethod.invoke(asmLambda, var22);
               InsnList insns = builder.build();
               AbstractInsnNode var24 = node.getPrevious();
               Intrinsics.checkNotNullExpressionValue(var24, "node.previous");
               PrintingKt.verbose(Intrinsics.stringPlus("- ", PrettyprintingKt.prettyString(var24)));
               instructions.remove(node.getPrevious());
               var24 = node.getPrevious();
               Intrinsics.checkNotNullExpressionValue(var24, "node.previous");
               PrintingKt.verbose(Intrinsics.stringPlus("- ", PrettyprintingKt.prettyString(var24)));
               instructions.remove(node.getPrevious());
               PrintingKt.verbose(Intrinsics.stringPlus("- ", PrettyprintingKt.prettyString((AbstractInsnNode)node)));
               CharSequence var31 = (CharSequence)PrettyprintingKt.prettyString(insns);
               String[] var25 = new String[]{"\n"};
               Iterable $this$forEach$iv = (Iterable)StringsKt.split$default(var31, var25, false, 0, 6, (Object)null);
               boolean var27 = false;
               Iterator var28 = $this$forEach$iv.iterator();

               while(var28.hasNext()) {
                  element$iv = var28.next();
                  String it = (String)element$iv;
                  var15 = false;
                  CharSequence var30 = (CharSequence)it;
                  boolean var17 = false;
                  if (!StringsKt.isBlank(var30)) {
                     PrintingKt.verbose(Intrinsics.stringPlus("+ ", it));
                  }
               }

               instructions.insertBefore((AbstractInsnNode)node, insns);
               instructions.remove((AbstractInsnNode)node);
               return;
            }
         }

         throw (Throwable)(new NoSuchElementException("Array contains no element matching the predicate."));
      }
   }
}
