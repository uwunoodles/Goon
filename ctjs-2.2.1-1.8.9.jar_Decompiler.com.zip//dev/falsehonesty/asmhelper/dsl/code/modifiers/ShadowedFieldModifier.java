package dev.falsehonesty.asmhelper.dsl.code.modifiers;

import dev.falsehonesty.asmhelper.AsmHelper;
import dev.falsehonesty.asmhelper.printing.PrettyprintingKt;
import dev.falsehonesty.asmhelper.printing.PrintingKt;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J \u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0003H\u0016R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\u0010"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/modifiers/ShadowedFieldModifier;", "Ldev/falsehonesty/asmhelper/dsl/code/modifiers/ShadowedModifier;", "codeBlockClass", "", "targetClassNode", "Lorg/objectweb/asm/tree/ClassNode;", "(Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)V", "getTargetClassNode", "()Lorg/objectweb/asm/tree/ClassNode;", "modifyFieldNode", "", "instructions", "Lorg/objectweb/asm/tree/InsnList;", "node", "Lorg/objectweb/asm/tree/FieldInsnNode;", "shadowedName", "AsmHelper1.8.9"}
)
public final class ShadowedFieldModifier extends ShadowedModifier {
   @NotNull
   private final ClassNode targetClassNode;

   public ShadowedFieldModifier(@NotNull String codeBlockClass, @NotNull ClassNode targetClassNode) {
      Intrinsics.checkNotNullParameter(codeBlockClass, "codeBlockClass");
      Intrinsics.checkNotNullParameter(targetClassNode, "targetClassNode");
      super(codeBlockClass);
      this.targetClassNode = targetClassNode;
   }

   @NotNull
   public final ClassNode getTargetClassNode() {
      return this.targetClassNode;
   }

   public void modifyFieldNode(@NotNull InsnList instructions, @NotNull FieldInsnNode node, @NotNull String shadowedName) {
      Intrinsics.checkNotNullParameter(instructions, "instructions");
      Intrinsics.checkNotNullParameter(node, "node");
      Intrinsics.checkNotNullParameter(shadowedName, "shadowedName");
      PrintingKt.verbose("Any fields referencing the code block class at this point must be a normal field.");
      String var5 = PrettyprintingKt.prettyString((AbstractInsnNode)node);
      boolean var6 = false;
      if (var5 == null) {
         throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
      } else {
         String prevString = StringsKt.trim((CharSequence)var5).toString();
         node.owner = this.targetClassNode.name;
         node.name = AsmHelper.INSTANCE.getRemapper().mapFieldAccess(shadowedName);
         StringBuilder var10000 = (new StringBuilder()).append(prevString).append(" --> ");
         var5 = PrettyprintingKt.prettyString((AbstractInsnNode)node);
         var6 = false;
         if (var5 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
         } else {
            PrintingKt.verbose(var10000.append(StringsKt.trim((CharSequence)var5).toString()).toString());
         }
      }
   }
}
