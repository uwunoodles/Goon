package dev.falsehonesty.asmhelper.dsl.code.modifiers;

import dev.falsehonesty.asmhelper.printing.PrettyprintingKt;
import dev.falsehonesty.asmhelper.printing.PrintingKt;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.VarInsnNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J \u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u0003H\u0016¨\u0006\f"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/modifiers/ShadowedLocalModifier;", "Ldev/falsehonesty/asmhelper/dsl/code/modifiers/ShadowedModifier;", "codeBlockClass", "", "(Ljava/lang/String;)V", "modifyFieldNode", "", "instructions", "Lorg/objectweb/asm/tree/InsnList;", "node", "Lorg/objectweb/asm/tree/FieldInsnNode;", "shadowedName", "AsmHelper1.8.9"}
)
public final class ShadowedLocalModifier extends ShadowedModifier {
   public ShadowedLocalModifier(@NotNull String codeBlockClass) {
      Intrinsics.checkNotNullParameter(codeBlockClass, "codeBlockClass");
      super(codeBlockClass);
   }

   public void modifyFieldNode(@NotNull InsnList instructions, @NotNull FieldInsnNode node, @NotNull String shadowedName) {
      Intrinsics.checkNotNullParameter(instructions, "instructions");
      Intrinsics.checkNotNullParameter(node, "node");
      Intrinsics.checkNotNullParameter(shadowedName, "shadowedName");
      CharSequence var4 = (CharSequence)shadowedName;
      String var5 = "local\\d+";
      boolean var6 = false;
      Regex var11 = new Regex(var5);
      var6 = false;
      if (var11.matches(var4)) {
         int var13 = "local".length();
         boolean var7 = false;
         String var10000 = shadowedName.substring(var13);
         Intrinsics.checkNotNullExpressionValue(var10000, "(this as java.lang.String).substring(startIndex)");
         var5 = var10000;
         var6 = false;
         int localNumber = Integer.parseInt(var5);
         PrintingKt.verbose(Intrinsics.stringPlus("Found shadowed local referencing local ", localNumber));
         AbstractInsnNode prev = node.getPrevious();
         if (!(prev instanceof VarInsnNode)) {
            return;
         }

         String prevString;
         byte opcode;
         byte var17;
         if (node.getOpcode() == 180) {
            label88: {
               prevString = node.desc;
               if (prevString != null) {
                  switch(prevString.hashCode()) {
                  case 66:
                     if (prevString.equals("B")) {
                        var17 = 21;
                        break label88;
                     }
                     break;
                  case 67:
                     if (prevString.equals("C")) {
                        var17 = 21;
                        break label88;
                     }
                     break;
                  case 68:
                     if (prevString.equals("D")) {
                        var17 = 24;
                        break label88;
                     }
                     break;
                  case 70:
                     if (prevString.equals("F")) {
                        var17 = 23;
                        break label88;
                     }
                     break;
                  case 73:
                     if (prevString.equals("I")) {
                        var17 = 21;
                        break label88;
                     }
                     break;
                  case 76:
                     if (prevString.equals("L")) {
                        var17 = 22;
                        break label88;
                     }
                     break;
                  case 83:
                     if (prevString.equals("S")) {
                        var17 = 21;
                        break label88;
                     }
                     break;
                  case 90:
                     if (prevString.equals("Z")) {
                        var17 = 21;
                        break label88;
                     }
                  }
               }

               var17 = 25;
            }

            opcode = var17;
            String var8 = PrettyprintingKt.prettyString(prev);
            boolean var9 = false;
            if (var8 == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }

            prevString = StringsKt.trim((CharSequence)var8).toString();
            ((VarInsnNode)prev).var = localNumber;
            ((VarInsnNode)prev).setOpcode(opcode);
            AbstractInsnNode var16 = ((VarInsnNode)prev).getPrevious();
            Intrinsics.checkNotNullExpressionValue(var16, "prev.previous");
            PrintingKt.verbose(PrettyprintingKt.prettyString(var16));
            StringBuilder var18 = (new StringBuilder()).append(prevString).append(" --> ");
            var8 = PrettyprintingKt.prettyString(prev);
            var9 = false;
            if (var8 == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }

            PrintingKt.verbose(var18.append(StringsKt.trim((CharSequence)var8).toString()).toString());
            PrintingKt.verbose(Intrinsics.stringPlus("- ", PrettyprintingKt.prettyString((AbstractInsnNode)node)));
            instructions.remove((AbstractInsnNode)node);
         } else if (node.getOpcode() == 181) {
            label103: {
               prevString = node.desc;
               if (prevString != null) {
                  switch(prevString.hashCode()) {
                  case 66:
                     if (prevString.equals("B")) {
                        var17 = 54;
                        break label103;
                     }
                     break;
                  case 67:
                     if (prevString.equals("C")) {
                        var17 = 54;
                        break label103;
                     }
                     break;
                  case 68:
                     if (prevString.equals("D")) {
                        var17 = 57;
                        break label103;
                     }
                     break;
                  case 70:
                     if (prevString.equals("F")) {
                        var17 = 56;
                        break label103;
                     }
                     break;
                  case 73:
                     if (prevString.equals("I")) {
                        var17 = 54;
                        break label103;
                     }
                     break;
                  case 76:
                     if (prevString.equals("L")) {
                        var17 = 55;
                        break label103;
                     }
                     break;
                  case 83:
                     if (prevString.equals("S")) {
                        var17 = 54;
                        break label103;
                     }
                     break;
                  case 90:
                     if (prevString.equals("Z")) {
                        var17 = 54;
                        break label103;
                     }
                  }
               }

               var17 = 58;
            }

            opcode = var17;
            instructions.insert((AbstractInsnNode)node, (AbstractInsnNode)(new VarInsnNode(opcode, localNumber)));
            instructions.remove((AbstractInsnNode)node);
         }
      }

   }
}
