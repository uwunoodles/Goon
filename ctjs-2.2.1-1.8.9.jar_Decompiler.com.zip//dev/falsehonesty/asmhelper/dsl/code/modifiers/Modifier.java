package dev.falsehonesty.asmhelper.dsl.code.modifiers;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.analysis.BasicInterpreter;
import org.objectweb.asm.tree.analysis.BasicValue;
import org.objectweb.asm.tree.analysis.Frame;
import org.objectweb.asm.tree.analysis.Interpreter;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b&\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J&\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u00042\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0004J\u0010\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fH&J\u0010\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0011H\u0004¨\u0006\u0013"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/modifiers/Modifier;", "", "()V", "getAnalyzedFrame", "Lorg/objectweb/asm/tree/analysis/Frame;", "Lorg/objectweb/asm/tree/analysis/BasicValue;", "node", "Lorg/objectweb/asm/tree/AbstractInsnNode;", "methodNode", "Lorg/objectweb/asm/tree/MethodNode;", "className", "", "modify", "", "instructions", "Lorg/objectweb/asm/tree/InsnList;", "wrappedTypeToPrimitive", "Lorg/objectweb/asm/Type;", "type", "AsmHelper1.8.9"}
)
public abstract class Modifier {
   public abstract void modify(@NotNull InsnList var1);

   @NotNull
   protected final Type wrappedTypeToPrimitive(@NotNull Type type) {
      Intrinsics.checkNotNullParameter(type, "type");
      String var2 = type.getDescriptor();
      Type var10000;
      if (var2 != null) {
         Type var3;
         switch(var2.hashCode()) {
         case -1405192707:
            if (var2.equals("Ljava/lang/Integer;")) {
               var3 = Type.INT_TYPE;
               Intrinsics.checkNotNullExpressionValue(var3, "INT_TYPE");
               var10000 = var3;
               return var10000;
            }
            break;
         case 30795859:
            if (var2.equals("Ljava/lang/Boolean;")) {
               var3 = Type.BOOLEAN_TYPE;
               Intrinsics.checkNotNullExpressionValue(var3, "BOOLEAN_TYPE");
               var10000 = var3;
               return var10000;
            }
            break;
         case 811419466:
            if (var2.equals("Ljava/lang/Double;")) {
               var3 = Type.DOUBLE_TYPE;
               Intrinsics.checkNotNullExpressionValue(var3, "DOUBLE_TYPE");
               var10000 = var3;
               return var10000;
            }
            break;
         case 1388882290:
            if (var2.equals("Ljava/lang/Character;")) {
               var3 = Type.CHAR_TYPE;
               Intrinsics.checkNotNullExpressionValue(var3, "CHAR_TYPE");
               var10000 = var3;
               return var10000;
            }
            break;
         case 1604503711:
            if (var2.equals("Ljava/lang/Float;")) {
               var3 = Type.FLOAT_TYPE;
               Intrinsics.checkNotNullExpressionValue(var3, "FLOAT_TYPE");
               var10000 = var3;
               return var10000;
            }
            break;
         case 1849571571:
            if (var2.equals("Ljava/lang/Byte;")) {
               var3 = Type.BYTE_TYPE;
               Intrinsics.checkNotNullExpressionValue(var3, "BYTE_TYPE");
               var10000 = var3;
               return var10000;
            }
            break;
         case 1858503167:
            if (var2.equals("Ljava/lang/Long;")) {
               var3 = Type.LONG_TYPE;
               Intrinsics.checkNotNullExpressionValue(var3, "LONG_TYPE");
               var10000 = var3;
               return var10000;
            }
            break;
         case 1973004927:
            if (var2.equals("Ljava/lang/Short;")) {
               var3 = Type.SHORT_TYPE;
               Intrinsics.checkNotNullExpressionValue(var3, "SHORT_TYPE");
               var10000 = var3;
               return var10000;
            }
         }
      }

      var10000 = type;
      return var10000;
   }

   @NotNull
   protected final Frame<BasicValue> getAnalyzedFrame(@NotNull AbstractInsnNode node, @NotNull MethodNode methodNode, @NotNull String className) {
      Intrinsics.checkNotNullParameter(node, "node");
      Intrinsics.checkNotNullParameter(methodNode, "methodNode");
      Intrinsics.checkNotNullParameter(className, "className");
      org.objectweb.asm.tree.analysis.Analyzer analyzer = new org.objectweb.asm.tree.analysis.Analyzer((Interpreter)(new BasicInterpreter()));
      analyzer.analyze(className, methodNode);
      int i = -1;
      Frame[] var7 = analyzer.getFrames();
      Intrinsics.checkNotNullExpressionValue(var7, "analyzer.frames");
      Frame[] var6 = var7;
      int var11 = 0;
      int var8 = var7.length;

      Frame frame;
      do {
         if (var11 >= var8) {
            throw new IllegalArgumentException("Node " + node + " not found in analyzed method " + className + '.' + methodNode.name + '.');
         }

         frame = var6[var11];
         ++var11;
         ++i;
      } while(methodNode.instructions.get(i) != node);

      Intrinsics.checkNotNullExpressionValue(frame, "frame");
      return frame;
   }
}
