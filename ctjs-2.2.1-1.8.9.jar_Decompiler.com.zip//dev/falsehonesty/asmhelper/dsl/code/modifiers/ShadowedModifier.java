package dev.falsehonesty.asmhelper.dsl.code.modifiers;

import java.util.ListIterator;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b&\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0010\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0016J \u0010\u000b\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u0003H&R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u000f"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/modifiers/ShadowedModifier;", "Ldev/falsehonesty/asmhelper/dsl/code/modifiers/Modifier;", "codeBlockClass", "", "(Ljava/lang/String;)V", "getCodeBlockClass", "()Ljava/lang/String;", "modify", "", "instructions", "Lorg/objectweb/asm/tree/InsnList;", "modifyFieldNode", "node", "Lorg/objectweb/asm/tree/FieldInsnNode;", "shadowedName", "AsmHelper1.8.9"}
)
public abstract class ShadowedModifier extends Modifier {
   @NotNull
   private final String codeBlockClass;

   public ShadowedModifier(@NotNull String codeBlockClass) {
      Intrinsics.checkNotNullParameter(codeBlockClass, "codeBlockClass");
      super();
      this.codeBlockClass = codeBlockClass;
   }

   @NotNull
   public final String getCodeBlockClass() {
      return this.codeBlockClass;
   }

   public void modify(@NotNull InsnList instructions) {
      Intrinsics.checkNotNullParameter(instructions, "instructions");
      ListIterator var2 = instructions.iterator();

      while(var2.hasNext()) {
         AbstractInsnNode node = (AbstractInsnNode)var2.next();
         if (node instanceof FieldInsnNode && Intrinsics.areEqual(((FieldInsnNode)node).owner, this.codeBlockClass)) {
            FieldInsnNode var10002 = (FieldInsnNode)node;
            String var4 = ((FieldInsnNode)node).name;
            Intrinsics.checkNotNullExpressionValue(var4, "node.name");
            byte var5 = 1;
            boolean var6 = false;
            String var10003 = var4.substring(var5);
            Intrinsics.checkNotNullExpressionValue(var10003, "(this as java.lang.String).substring(startIndex)");
            this.modifyFieldNode(instructions, var10002, var10003);
         }
      }

   }

   public abstract void modifyFieldNode(@NotNull InsnList var1, @NotNull FieldInsnNode var2, @NotNull String var3);
}
