package dev.falsehonesty.asmhelper.dsl.code.modifiers;

import java.util.ListIterator;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0016¨\u0006\u0007"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/modifiers/RemoveReturnModifier;", "Ldev/falsehonesty/asmhelper/dsl/code/modifiers/Modifier;", "()V", "modify", "", "instructions", "Lorg/objectweb/asm/tree/InsnList;", "AsmHelper1.8.9"}
)
public final class RemoveReturnModifier extends Modifier {
   public void modify(@NotNull InsnList instructions) {
      Intrinsics.checkNotNullParameter(instructions, "instructions");
      ListIterator var2 = instructions.iterator();

      while(var2.hasNext()) {
         AbstractInsnNode node = (AbstractInsnNode)var2.next();
         if (node.getOpcode() == 177) {
            instructions.remove(node);
         }
      }

   }
}
