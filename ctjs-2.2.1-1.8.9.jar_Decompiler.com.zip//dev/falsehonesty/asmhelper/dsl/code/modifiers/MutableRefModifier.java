package dev.falsehonesty.asmhelper.dsl.code.modifiers;

import dev.falsehonesty.asmhelper.printing.PrintingKt;
import java.util.Deque;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u0018\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000eH\u0002J\u0012\u0010\u0010\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0011\u001a\u00020\u0005H\u0002J\"\u0010\u0012\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0013\u001a\u00020\u000e2\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0011\u001a\u00020\u0005H\u0002J\u0010\u0010\u0016\u001a\u00020\f2\u0006\u0010\u0014\u001a\u00020\u0015H\u0016J\"\u0010\u0017\u001a\u00020\f2\u0006\u0010\u0018\u001a\u00020\u000e2\u0006\u0010\u0014\u001a\u00020\u00152\b\u0010\u0019\u001a\u0004\u0018\u00010\u000eH\u0002R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u001a"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/modifiers/MutableRefModifier;", "Ldev/falsehonesty/asmhelper/dsl/code/modifiers/Modifier;", "codeBlockMethodNode", "Lorg/objectweb/asm/tree/MethodNode;", "codeBlockClass", "", "(Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/String;)V", "getCodeBlockClass", "()Ljava/lang/String;", "getCodeBlockMethodNode", "()Lorg/objectweb/asm/tree/MethodNode;", "copyReadWrite", "", "to", "Lorg/objectweb/asm/tree/FieldInsnNode;", "from", "getDescriptorForRefType", "refType", "locateRefWrite", "node", "instructions", "Lorg/objectweb/asm/tree/InsnList;", "modify", "modifyRead", "readNode", "writeNode", "AsmHelper1.8.9"}
)
public final class MutableRefModifier extends Modifier {
   @NotNull
   private final MethodNode codeBlockMethodNode;
   @NotNull
   private final String codeBlockClass;

   public MutableRefModifier(@NotNull MethodNode codeBlockMethodNode, @NotNull String codeBlockClass) {
      Intrinsics.checkNotNullParameter(codeBlockMethodNode, "codeBlockMethodNode");
      Intrinsics.checkNotNullParameter(codeBlockClass, "codeBlockClass");
      super();
      this.codeBlockMethodNode = codeBlockMethodNode;
      this.codeBlockClass = codeBlockClass;
   }

   @NotNull
   public final MethodNode getCodeBlockMethodNode() {
      return this.codeBlockMethodNode;
   }

   @NotNull
   public final String getCodeBlockClass() {
      return this.codeBlockClass;
   }

   public void modify(@NotNull InsnList instructions) {
      Intrinsics.checkNotNullParameter(instructions, "instructions");
      AbstractInsnNode node = instructions.getFirst();

      while(true) {
         String var3;
         do {
            do {
               do {
                  if (node.getNext() == null) {
                     return;
                  }

                  node = node.getNext();
               } while(!(node instanceof FieldInsnNode));
            } while(!Intrinsics.areEqual(((FieldInsnNode)node).owner, this.codeBlockClass));

            var3 = ((FieldInsnNode)node).desc;
            Intrinsics.checkNotNullExpressionValue(var3, "node.desc");
         } while(!StringsKt.startsWith$default(var3, "Lkotlin/jvm/internal/Ref$", false, 2, (Object)null));

         AbstractInsnNode next = ((FieldInsnNode)node).getNext();

         int allowedActions;
         for(allowedActions = 1; next.getOpcode() == 89; ++allowedActions) {
            instructions.remove(next);
            instructions.insertBefore(node, next);
            next = ((FieldInsnNode)node).getNext();
         }

         String var6 = ((FieldInsnNode)node).desc;
         Intrinsics.checkNotNullExpressionValue(var6, "node.desc");
         byte var7 = 1;
         int var8 = ((FieldInsnNode)node).desc.length() - 1;
         boolean var9 = false;
         String var10000 = var6.substring(var7, var8);
         Intrinsics.checkNotNullExpressionValue(var10000, "(this as java.lang.Strin…ing(startIndex, endIndex)");
         String refType = var10000;
         FieldInsnNode writeNode = this.locateRefWrite((FieldInsnNode)node, instructions, refType);
         String descriptor = ((FieldInsnNode)node).desc;
         Intrinsics.checkNotNullExpressionValue(descriptor, "node.desc");
         if (StringsKt.contains$default((CharSequence)descriptor, (CharSequence)refType, false, 2, (Object)null)) {
            var10000 = this.getDescriptorForRefType(refType);
            Intrinsics.checkNotNull(var10000);
            descriptor = var10000;
            ((FieldInsnNode)node).desc = descriptor;
         }

         boolean hasRead = false;
         if (next.getOpcode() == 180) {
            if (next == null) {
               throw new NullPointerException("null cannot be cast to non-null type org.objectweb.asm.tree.FieldInsnNode");
            }

            if (Intrinsics.areEqual(((FieldInsnNode)next).owner, refType)) {
               hasRead = true;
               Intrinsics.checkNotNullExpressionValue(next, "next");
               this.modifyRead((FieldInsnNode)next, instructions, writeNode);
               allowedActions += -1;
            }
         }

         if (allowedActions > 0) {
            if (writeNode == null) {
               PrintingKt.getLogger().error(Intrinsics.stringPlus("Couldn't locate write node for ", node));
               return;
            }

            this.copyReadWrite(writeNode, (FieldInsnNode)node);
            AbstractInsnNode prev = writeNode.getNext();
            if (prev != null) {
               if (prev.getOpcode() == 180 && Intrinsics.areEqual(((FieldInsnNode)prev).owner, refType) && allowedActions > 0) {
                  this.copyReadWrite((FieldInsnNode)prev, (FieldInsnNode)node);
                  hasRead = true;
               }

               if (!hasRead) {
                  prev = ((FieldInsnNode)node).getPrevious();
                  if (prev.getOpcode() == 25 && prev instanceof VarInsnNode) {
                     String var10 = ((FieldInsnNode)node).name;
                     Intrinsics.checkNotNullExpressionValue(var10, "node.name");
                     byte var11 = 1;
                     boolean var12 = false;
                     var10000 = var10.substring(var11);
                     Intrinsics.checkNotNullExpressionValue(var10000, "(this as java.lang.String).substring(startIndex)");
                     CharSequence var18 = (CharSequence)var10000;
                     String var19 = "local\\d+";
                     var12 = false;
                     Regex var20 = new Regex(var19);
                     var12 = false;
                     if (var20.matches(var18)) {
                        instructions.remove(prev);
                     }
                  }

                  instructions.remove(node);
               }
            }
         }
      }
   }

   private final void modifyRead(FieldInsnNode readNode, InsnList instructions, FieldInsnNode writeNode) {
      if (Intrinsics.areEqual(readNode.owner, "kotlin/jvm/internal/Ref$ObjectRef")) {
         AbstractInsnNode cast = readNode.getNext();
         if (cast instanceof TypeInsnNode && ((TypeInsnNode)cast).getOpcode() == 192) {
            AbstractInsnNode var5 = readNode.getPrevious();
            if (var5 == null) {
               throw new NullPointerException("null cannot be cast to non-null type org.objectweb.asm.tree.FieldInsnNode");
            }

            ((FieldInsnNode)var5).desc = ((TypeInsnNode)cast).desc;
            instructions.remove(cast);
         }
      }

      instructions.remove((AbstractInsnNode)readNode);
   }

   private final String getDescriptorForRefType(String refType) {
      String var10000;
      switch(refType.hashCode()) {
      case -2099914172:
         if (refType.equals("IntRef")) {
            var10000 = "I";
            return var10000;
         }
         break;
      case -1891271363:
         if (refType.equals("CharRef")) {
            var10000 = "C";
            return var10000;
         }
         break;
      case -277873001:
         if (refType.equals("ShortRef")) {
            var10000 = "S";
            return var10000;
         }
         break;
      case 514359476:
         if (refType.equals("ObjectRef")) {
            var10000 = "Ljava/lang/Object;";
            return var10000;
         }
         break;
      case 1197803234:
         if (refType.equals("DoubleRef")) {
            var10000 = "D";
            return var10000;
         }
         break;
      case 1380081515:
         if (refType.equals("BooleanRef")) {
            var10000 = "Z";
            return var10000;
         }
         break;
      case 2013376599:
         if (refType.equals("LongRef")) {
            var10000 = "L";
            return var10000;
         }
         break;
      case 2020047435:
         if (refType.equals("ByteRef")) {
            var10000 = "B";
            return var10000;
         }
         break;
      case 2074743991:
         if (refType.equals("FloatRef")) {
            var10000 = "F";
            return var10000;
         }
      }

      var10000 = null;
      return var10000;
   }

   private final FieldInsnNode locateRefWrite(FieldInsnNode node, InsnList instructions, String refType) {
      Analyzer analyzer = new Analyzer(instructions, this.codeBlockMethodNode);
      AbstractInsnNode currentNode = (AbstractInsnNode)node;

      while(currentNode.getNext() != null) {
         AbstractInsnNode var6 = currentNode.getNext();
         Intrinsics.checkNotNullExpressionValue(var6, "currentNode.next");
         currentNode = var6;
         if (var6 instanceof FieldInsnNode && ((FieldInsnNode)var6).getOpcode() == 181 && Intrinsics.areEqual(((FieldInsnNode)var6).owner, refType)) {
            Deque analyzed = analyzer.analyze((AbstractInsnNode)node, var6);
            if (analyzed.size() == 1) {
               String var10000 = ((Type)analyzed.getFirst()).getDescriptor();
               byte var8 = 24;
               boolean var9 = false;
               if (refType == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
               }

               String var10002 = refType.substring(var8);
               Intrinsics.checkNotNullExpressionValue(var10002, "(this as java.lang.String).substring(startIndex)");
               if (Intrinsics.areEqual(var10000, this.getDescriptorForRefType(var10002))) {
                  return (FieldInsnNode)currentNode;
               }
            }

            if (analyzed.size() == 2) {
               String var7 = ((Type)analyzed.getLast()).getDescriptor();
               Intrinsics.checkNotNullExpressionValue(var7, "analyzed.last.descriptor");
               if (StringsKt.contains$default((CharSequence)var7, (CharSequence)refType, false, 2, (Object)null)) {
                  if (Intrinsics.areEqual(refType, "kotlin/jvm/internal/Ref$ObjectRef")) {
                     node.desc = ((Type)analyzed.getFirst()).getDescriptor();
                  }

                  return (FieldInsnNode)currentNode;
               }
            }
         }
      }

      return null;
   }

   private final void copyReadWrite(FieldInsnNode to, FieldInsnNode from) {
      to.owner = from.owner;
      to.name = from.name;
      to.desc = from.desc;
   }
}
