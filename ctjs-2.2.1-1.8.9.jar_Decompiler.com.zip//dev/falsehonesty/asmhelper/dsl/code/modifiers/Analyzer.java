package dev.falsehonesty.asmhelper.dsl.code.modifiers;

import dev.falsehonesty.asmhelper.printing.PrettyprintingKt;
import dev.falsehonesty.asmhelper.printing.PrintingKt;
import java.util.ArrayDeque;
import java.util.Deque;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.IntInsnNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.LocalVariableNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u001c\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\f2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0011"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/modifiers/Analyzer;", "", "instructions", "Lorg/objectweb/asm/tree/InsnList;", "methodNode", "Lorg/objectweb/asm/tree/MethodNode;", "(Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/tree/MethodNode;)V", "getInstructions", "()Lorg/objectweb/asm/tree/InsnList;", "getMethodNode", "()Lorg/objectweb/asm/tree/MethodNode;", "analyze", "Ljava/util/Deque;", "Lorg/objectweb/asm/Type;", "startInsn", "Lorg/objectweb/asm/tree/AbstractInsnNode;", "endInsn", "AsmHelper1.8.9"}
)
public final class Analyzer {
   @NotNull
   private final InsnList instructions;
   @NotNull
   private final MethodNode methodNode;

   public Analyzer(@NotNull InsnList instructions, @NotNull MethodNode methodNode) {
      Intrinsics.checkNotNullParameter(instructions, "instructions");
      Intrinsics.checkNotNullParameter(methodNode, "methodNode");
      super();
      this.instructions = instructions;
      this.methodNode = methodNode;
   }

   @NotNull
   public final InsnList getInstructions() {
      return this.instructions;
   }

   @NotNull
   public final MethodNode getMethodNode() {
      return this.methodNode;
   }

   @NotNull
   public final Deque<Type> analyze(@NotNull AbstractInsnNode startInsn, @NotNull AbstractInsnNode endInsn) {
      Intrinsics.checkNotNullParameter(startInsn, "startInsn");
      Intrinsics.checkNotNullParameter(endInsn, "endInsn");
      ArrayDeque stack = new ArrayDeque();

      AbstractInsnNode var5;
      for(AbstractInsnNode node = startInsn; !Intrinsics.areEqual(node, endInsn); node = var5) {
         PrintingKt.verbose(Intrinsics.stringPlus("Analyzing ", PrettyprintingKt.prettyString(node)));
         int var6;
         if (!(node instanceof MethodInsnNode)) {
            if (node instanceof VarInsnNode) {
               if (((VarInsnNode)node).getOpcode() <= 53) {
                  stack.push(Type.getObjectType(((LocalVariableNode)this.methodNode.localVariables.get(((VarInsnNode)node).var)).desc));
               } else {
                  stack.pop();
               }
            } else if (node instanceof FieldInsnNode) {
               var6 = ((FieldInsnNode)node).getOpcode();
               switch(var6) {
               case 178:
                  stack.push(Type.getType(((FieldInsnNode)node).desc));
                  break;
               case 179:
                  stack.pop();
                  break;
               case 180:
                  stack.poll();
                  stack.push(Type.getType(((FieldInsnNode)node).desc));
                  break;
               case 181:
                  stack.poll();
                  stack.pop();
               }
            } else if (node instanceof IntInsnNode) {
               stack.push(Type.INT_TYPE);
            } else if (node instanceof LdcInsnNode) {
               Object var13 = ((LdcInsnNode)node).cst;
               if (var13 instanceof String) {
                  String var14 = String.class.getName();
                  Intrinsics.checkNotNullExpressionValue(var14, "String::class.java.name");
                  stack.push(Type.getObjectType(StringsKt.replace$default(var14, ".", "/", false, 4, (Object)null)));
               } else if (var13 instanceof Integer) {
                  stack.push(Type.INT_TYPE);
               } else if (var13 instanceof Long) {
                  stack.push(Type.LONG_TYPE);
               } else if (var13 instanceof Double) {
                  stack.push(Type.DOUBLE_TYPE);
               } else if (var13 instanceof Float) {
                  stack.push(Type.FLOAT_TYPE);
               } else if (var13 instanceof Type) {
                  Object var15 = ((LdcInsnNode)node).cst;
                  if (var15 == null) {
                     throw new NullPointerException("null cannot be cast to non-null type org.objectweb.asm.Type");
                  }

                  stack.push((Type)var15);
               }
            } else if (node instanceof InsnNode) {
               var6 = ((InsnNode)node).getOpcode();
               if (2 <= var6 ? var6 <= 8 : false) {
                  stack.push(Type.INT_TYPE);
               } else if (9 <= var6 ? var6 <= 10 : false) {
                  stack.push(Type.LONG_TYPE);
               } else if (11 <= var6 ? var6 <= 13 : false) {
                  stack.push(Type.FLOAT_TYPE);
               } else if (14 <= var6 ? var6 <= 15 : false) {
                  stack.push(Type.DOUBLE_TYPE);
               } else if (96 <= var6 ? var6 <= 115 : false) {
                  stack.pop();
               } else if (var6 == 89) {
                  stack.push(stack.peek());
               }
            } else if (node instanceof TypeInsnNode) {
               var6 = ((TypeInsnNode)node).getOpcode();
               switch(var6) {
               case 187:
                  stack.push(Type.getObjectType(((TypeInsnNode)node).desc));
                  break;
               case 192:
                  stack.pop();
                  stack.push(Type.getObjectType(((TypeInsnNode)node).desc));
               }
            }
         } else {
            var6 = Type.getArgumentTypes(((MethodInsnNode)node).desc).length;
            boolean var7 = false;
            boolean var8 = false;
            int var16 = 0;

            for(int var9 = var6; var16 < var9; ++var16) {
               int var11 = false;
               PrintingKt.verbose("Popping " + stack.poll() + " off the stack because it is an argument");
            }

            if (((MethodInsnNode)node).getOpcode() != 184) {
               PrintingKt.verbose(Intrinsics.stringPlus("Popping receiver ", stack.poll()));
            }

            Type returnType = Type.getReturnType(((MethodInsnNode)node).desc);
            if (!Intrinsics.areEqual(returnType, Type.VOID_TYPE)) {
               stack.push(returnType);
            }

            PrintingKt.verbose(Intrinsics.stringPlus("Pushed return type ", returnType));
         }

         PrintingKt.verbose(Intrinsics.stringPlus("Stack after analyzation frame looks like ", stack));
         var5 = node.getNext();
         Intrinsics.checkNotNullExpressionValue(var5, "node.next");
      }

      return (Deque)stack;
   }
}
