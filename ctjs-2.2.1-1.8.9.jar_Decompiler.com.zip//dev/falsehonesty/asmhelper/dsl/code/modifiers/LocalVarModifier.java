package dev.falsehonesty.asmhelper.dsl.code.modifiers;

import dev.falsehonesty.asmhelper.printing.PrettyprintingKt;
import dev.falsehonesty.asmhelper.printing.PrintingKt;
import java.util.ListIterator;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0010\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0016R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u000b"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/modifiers/LocalVarModifier;", "Ldev/falsehonesty/asmhelper/dsl/code/modifiers/Modifier;", "targetMethodNode", "Lorg/objectweb/asm/tree/MethodNode;", "(Lorg/objectweb/asm/tree/MethodNode;)V", "getTargetMethodNode", "()Lorg/objectweb/asm/tree/MethodNode;", "modify", "", "instructions", "Lorg/objectweb/asm/tree/InsnList;", "AsmHelper1.8.9"}
)
public final class LocalVarModifier extends Modifier {
   @NotNull
   private final MethodNode targetMethodNode;

   public LocalVarModifier(@NotNull MethodNode targetMethodNode) {
      Intrinsics.checkNotNullParameter(targetMethodNode, "targetMethodNode");
      super();
      this.targetMethodNode = targetMethodNode;
   }

   @NotNull
   public final MethodNode getTargetMethodNode() {
      return this.targetMethodNode;
   }

   public void modify(@NotNull InsnList instructions) {
      Intrinsics.checkNotNullParameter(instructions, "instructions");
      ListIterator var2 = instructions.iterator();

      while(var2.hasNext()) {
         AbstractInsnNode node = (AbstractInsnNode)var2.next();
         if (node instanceof VarInsnNode && ((VarInsnNode)node).var != 0) {
            String var5 = PrettyprintingKt.prettyString(node);
            boolean var6 = false;
            if (var5 == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }

            String before = StringsKt.trim((CharSequence)var5).toString();
            VarInsnNode var7 = (VarInsnNode)node;
            var7.var += this.targetMethodNode.maxLocals - 1;
            StringBuilder var10000 = (new StringBuilder()).append(before).append(" --> ");
            var5 = PrettyprintingKt.prettyString(node);
            var6 = false;
            if (var5 == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            }

            PrintingKt.verbose(var10000.append(StringsKt.trim((CharSequence)var5).toString()).toString());
         }
      }

   }
}
