package dev.falsehonesty.asmhelper.dsl.code.modifiers;

import dev.falsehonesty.asmhelper.AsmHelper;
import dev.falsehonesty.asmhelper.printing.PrettyprintingKt;
import dev.falsehonesty.asmhelper.printing.PrintingKt;
import java.util.Arrays;
import java.util.Deque;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ \u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0003H\u0002J \u0010\u0014\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0003H\u0016R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\f¨\u0006\u0015"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/modifiers/ShadowedMethodModifier;", "Ldev/falsehonesty/asmhelper/dsl/code/modifiers/ShadowedModifier;", "codeBlockClass", "", "targetClassNode", "Lorg/objectweb/asm/tree/ClassNode;", "codeBlockMethod", "Lorg/objectweb/asm/tree/MethodNode;", "(Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)V", "getCodeBlockMethod", "()Lorg/objectweb/asm/tree/MethodNode;", "getTargetClassNode", "()Lorg/objectweb/asm/tree/ClassNode;", "manipulateShadowedMethodCall", "", "instructions", "Lorg/objectweb/asm/tree/InsnList;", "node", "Lorg/objectweb/asm/tree/FieldInsnNode;", "shadowedName", "modifyFieldNode", "AsmHelper1.8.9"}
)
public final class ShadowedMethodModifier extends ShadowedModifier {
   @NotNull
   private final ClassNode targetClassNode;
   @NotNull
   private final MethodNode codeBlockMethod;

   public ShadowedMethodModifier(@NotNull String codeBlockClass, @NotNull ClassNode targetClassNode, @NotNull MethodNode codeBlockMethod) {
      Intrinsics.checkNotNullParameter(codeBlockClass, "codeBlockClass");
      Intrinsics.checkNotNullParameter(targetClassNode, "targetClassNode");
      Intrinsics.checkNotNullParameter(codeBlockMethod, "codeBlockMethod");
      super(codeBlockClass);
      this.targetClassNode = targetClassNode;
      this.codeBlockMethod = codeBlockMethod;
   }

   @NotNull
   public final ClassNode getTargetClassNode() {
      return this.targetClassNode;
   }

   @NotNull
   public final MethodNode getCodeBlockMethod() {
      return this.codeBlockMethod;
   }

   public void modifyFieldNode(@NotNull InsnList instructions, @NotNull FieldInsnNode node, @NotNull String shadowedName) {
      Intrinsics.checkNotNullParameter(instructions, "instructions");
      Intrinsics.checkNotNullParameter(node, "node");
      Intrinsics.checkNotNullParameter(shadowedName, "shadowedName");
      String var4 = node.desc;
      Intrinsics.checkNotNullExpressionValue(var4, "node.desc");
      if (StringsKt.contains$default((CharSequence)var4, (CharSequence)"kotlin/jvm/functions/", false, 2, (Object)null)) {
         this.manipulateShadowedMethodCall(instructions, node, shadowedName);
      }
   }

   private final void manipulateShadowedMethodCall(InsnList instructions, FieldInsnNode node, String shadowedName) {
      PrintingKt.verbose(Intrinsics.stringPlus(PrettyprintingKt.prettyString((AbstractInsnNode)node), " looks to be a shadowed method. Transforming now..."));
      AbstractInsnNode searchNode = node.getNext();
      MethodInsnNode finalCall = null;

      while(true) {
         while(true) {
            String var6;
            if (searchNode instanceof MethodInsnNode && ((MethodInsnNode)searchNode).itf && Intrinsics.areEqual(((MethodInsnNode)searchNode).name, "invoke")) {
               var6 = node.desc;
               Intrinsics.checkNotNullExpressionValue(var6, "node.desc");
               byte var7 = 1;
               int var8 = node.desc.length() - 1;
               boolean var9 = false;
               String var10000 = var6.substring(var7, var8);
               Intrinsics.checkNotNullExpressionValue(var10000, "(this as java.lang.Strin…ing(startIndex, endIndex)");
               if (Intrinsics.areEqual(var10000, ((MethodInsnNode)searchNode).owner)) {
                  finalCall = (MethodInsnNode)searchNode;
                  int numberOfArguments = Type.getArgumentTypes(finalCall.desc).length;
                  Analyzer var35 = new Analyzer(instructions, this.codeBlockMethod);
                  AbstractInsnNode var25 = node.getNext();
                  Intrinsics.checkNotNullExpressionValue(var25, "node.next");
                  Deque analyzedFrame = var35.analyze(var25, (AbstractInsnNode)finalCall);
                  Type[] argumentTypes = new Type[numberOfArguments];
                  var9 = false;
                  boolean var10 = false;
                  int var28 = 0;

                  for(int var11 = numberOfArguments; var28 < var11; ++var28) {
                     int var13 = false;
                     argumentTypes[var28] = (Type)analyzedFrame.pop();
                  }

                  ArraysKt.reverse(argumentTypes);
                  PrintingKt.verbose(Intrinsics.stringPlus("Theoretically, the stack would look like this when the method is called: ", ArraysKt.toList(argumentTypes)));
                  PrintingKt.verbose("We want the top " + numberOfArguments + " from it.");
                  AbstractInsnNode returnTypeIndicator = finalCall.getNext();
                  Type var36;
                  if (returnTypeIndicator instanceof TypeInsnNode) {
                     Type rawType = Type.getObjectType(((TypeInsnNode)returnTypeIndicator).desc);
                     Intrinsics.checkNotNullExpressionValue(rawType, "rawType");
                     var36 = this.wrappedTypeToPrimitive(rawType);
                  } else {
                     var36 = Type.VOID_TYPE;
                  }

                  Type returnType = var36;
                  PrintingKt.verbose(Intrinsics.stringPlus("The return type is believed to be ", returnType));
                  String syntheticMethodDesc = Type.getMethodDescriptor(returnType, (Type[])Arrays.copyOf(argumentTypes, argumentTypes.length));
                  PrintingKt.verbose(Intrinsics.stringPlus("Synthetic method description has been formed: ", syntheticMethodDesc));
                  String mappedMethodName;
                  byte var15;
                  boolean var16;
                  String methodName;
                  MethodInsnNode var37;
                  if (StringsKt.startsWith$default(shadowedName, "super", false, 2, (Object)null)) {
                     var15 = 5;
                     var16 = false;
                     if (shadowedName == null) {
                        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                     }

                     var10000 = shadowedName.substring(var15);
                     Intrinsics.checkNotNullExpressionValue(var10000, "(this as java.lang.String).substring(startIndex)");
                     mappedMethodName = var10000;
                     boolean var34 = false;
                     var16 = false;
                     int var18 = false;
                     if (StringsKt.startsWith$default(mappedMethodName, "_", false, 2, (Object)null)) {
                        byte var20 = 1;
                        boolean var21 = false;
                        if (mappedMethodName == null) {
                           throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }

                        var10000 = mappedMethodName.substring(var20);
                        Intrinsics.checkNotNullExpressionValue(var10000, "(this as java.lang.String).substring(startIndex)");
                     } else {
                        var10000 = StringsKt.decapitalize(mappedMethodName);
                     }

                     methodName = var10000;
                     mappedMethodName = AsmHelper.INSTANCE.getRemapper().mapInvocation(methodName);
                     var37 = new MethodInsnNode(183, this.targetClassNode.superName, mappedMethodName, syntheticMethodDesc, false);
                  } else {
                     if (StringsKt.startsWith$default(shadowedName, "_super", false, 2, (Object)null)) {
                        var15 = 1;
                        var16 = false;
                        if (shadowedName == null) {
                           throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                        }

                        var10000 = shadowedName.substring(var15);
                        Intrinsics.checkNotNullExpressionValue(var10000, "(this as java.lang.String).substring(startIndex)");
                     } else {
                        var10000 = shadowedName;
                     }

                     methodName = var10000;
                     mappedMethodName = AsmHelper.INSTANCE.getRemapper().mapInvocation(methodName);
                     var37 = new MethodInsnNode(182, this.targetClassNode.name, mappedMethodName, syntheticMethodDesc, false);
                  }

                  MethodInsnNode methodCall = var37;
                  PrintingKt.verbose(Intrinsics.stringPlus("- ", PrettyprintingKt.prettyString((AbstractInsnNode)node)));
                  instructions.remove((AbstractInsnNode)node);
                  instructions.insertBefore((AbstractInsnNode)finalCall, (AbstractInsnNode)methodCall);
                  instructions.remove((AbstractInsnNode)finalCall);
                  PrintingKt.verbose(Intrinsics.stringPlus("- ", PrettyprintingKt.prettyString((AbstractInsnNode)finalCall)));
                  PrintingKt.verbose(Intrinsics.stringPlus("+ ", PrettyprintingKt.prettyString((AbstractInsnNode)methodCall)));
                  AbstractInsnNode possibleWrapperToPrim = returnTypeIndicator.getNext();
                  Intrinsics.checkNotNullExpressionValue(returnTypeIndicator, "returnTypeIndicator");
                  PrintingKt.verbose(Intrinsics.stringPlus("- ", PrettyprintingKt.prettyString(returnTypeIndicator)));
                  instructions.remove(returnTypeIndicator);
                  if (possibleWrapperToPrim instanceof MethodInsnNode) {
                     mappedMethodName = ((MethodInsnNode)possibleWrapperToPrim).owner;
                     Intrinsics.checkNotNullExpressionValue(mappedMethodName, "possibleWrapperToPrim.owner");
                     if (StringsKt.startsWith$default(mappedMethodName, "java/lang/", false, 2, (Object)null)) {
                        mappedMethodName = ((MethodInsnNode)possibleWrapperToPrim).name;
                        Intrinsics.checkNotNullExpressionValue(mappedMethodName, "possibleWrapperToPrim.name");
                        if (StringsKt.endsWith$default(mappedMethodName, "Value", false, 2, (Object)null)) {
                           mappedMethodName = ((MethodInsnNode)possibleWrapperToPrim).desc;
                           Intrinsics.checkNotNullExpressionValue(mappedMethodName, "possibleWrapperToPrim.desc");
                           if (StringsKt.startsWith$default(mappedMethodName, "()", false, 2, (Object)null)) {
                              PrintingKt.verbose(Intrinsics.stringPlus("- ", PrettyprintingKt.prettyString(possibleWrapperToPrim)));
                              instructions.remove(possibleWrapperToPrim);
                           }
                        }
                     }
                  }

                  return;
               }
            }

            if (searchNode instanceof MethodInsnNode) {
               var6 = ((MethodInsnNode)searchNode).owner;
               Intrinsics.checkNotNullExpressionValue(var6, "searchNode.owner");
               if (StringsKt.startsWith$default(var6, "java/lang", false, 2, (Object)null) && Intrinsics.areEqual(((MethodInsnNode)searchNode).name, "valueOf")) {
                  PrintingKt.verbose("Found primitive -> wrapper call, likely an artifact from Kotlin's boxing, so let's toss it.");
                  PrintingKt.verbose(PrettyprintingKt.prettyString(searchNode));
                  AbstractInsnNode tmp = ((MethodInsnNode)searchNode).getNext();
                  instructions.remove(searchNode);
                  searchNode = tmp;
                  continue;
               }
            }

            searchNode = searchNode.getNext();
         }
      }
   }
}
