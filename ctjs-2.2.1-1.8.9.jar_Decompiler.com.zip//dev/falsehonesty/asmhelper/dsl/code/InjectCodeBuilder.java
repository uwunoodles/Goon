package dev.falsehonesty.asmhelper.dsl.code;

import dev.falsehonesty.asmhelper.dsl.code.modifiers.AsmBlockModifier;
import dev.falsehonesty.asmhelper.dsl.code.modifiers.CodeBlockShortcutModifier;
import dev.falsehonesty.asmhelper.dsl.code.modifiers.LocalVarModifier;
import dev.falsehonesty.asmhelper.dsl.code.modifiers.Modifier;
import dev.falsehonesty.asmhelper.dsl.code.modifiers.MutableRefModifier;
import dev.falsehonesty.asmhelper.dsl.code.modifiers.RemoveReturnModifier;
import dev.falsehonesty.asmhelper.dsl.code.modifiers.ShadowedFieldModifier;
import dev.falsehonesty.asmhelper.dsl.code.modifiers.ShadowedLocalModifier;
import dev.falsehonesty.asmhelper.dsl.code.modifiers.ShadowedMethodModifier;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007R\u001a\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\f¨\u0006\r"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/InjectCodeBuilder;", "Ldev/falsehonesty/asmhelper/dsl/code/CodeBuilder;", "codeClassNode", "Lorg/objectweb/asm/tree/ClassNode;", "targetClassNode", "targetMethodNode", "Lorg/objectweb/asm/tree/MethodNode;", "(Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)V", "modifiers", "", "Ldev/falsehonesty/asmhelper/dsl/code/modifiers/Modifier;", "getModifiers", "()Ljava/util/List;", "AsmHelper1.8.9"}
)
public final class InjectCodeBuilder extends CodeBuilder {
   @NotNull
   private final List<Modifier> modifiers;

   public InjectCodeBuilder(@NotNull ClassNode codeClassNode, @NotNull ClassNode targetClassNode, @NotNull MethodNode targetMethodNode) {
      Intrinsics.checkNotNullParameter(codeClassNode, "codeClassNode");
      Intrinsics.checkNotNullParameter(targetClassNode, "targetClassNode");
      Intrinsics.checkNotNullParameter(targetMethodNode, "targetMethodNode");
      super(codeClassNode);
      Modifier[] var4 = new Modifier[8];
      var4[0] = (Modifier)(new RemoveReturnModifier());
      var4[1] = (Modifier)(new CodeBlockShortcutModifier());
      MethodNode var10005 = this.getMethodNode();
      String var5 = codeClassNode.name;
      Intrinsics.checkNotNullExpressionValue(var5, "codeClassNode.name");
      var4[2] = (Modifier)(new MutableRefModifier(var10005, var5));
      var4[3] = (Modifier)(new LocalVarModifier(targetMethodNode));
      var4[4] = (Modifier)(new AsmBlockModifier(targetMethodNode));
      var5 = codeClassNode.name;
      Intrinsics.checkNotNullExpressionValue(var5, "codeClassNode.name");
      var4[5] = (Modifier)(new ShadowedMethodModifier(var5, targetClassNode, this.getMethodNode()));
      var5 = codeClassNode.name;
      Intrinsics.checkNotNullExpressionValue(var5, "codeClassNode.name");
      var4[6] = (Modifier)(new ShadowedLocalModifier(var5));
      var5 = codeClassNode.name;
      Intrinsics.checkNotNullExpressionValue(var5, "codeClassNode.name");
      var4[7] = (Modifier)(new ShadowedFieldModifier(var5, targetClassNode));
      this.modifiers = CollectionsKt.listOf(var4);
   }

   @NotNull
   public List<Modifier> getModifiers() {
      return this.modifiers;
   }
}
