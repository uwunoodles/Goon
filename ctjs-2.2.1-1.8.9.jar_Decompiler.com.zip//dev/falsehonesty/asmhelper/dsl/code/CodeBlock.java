package dev.falsehonesty.asmhelper.dsl.code;

import dev.falsehonesty.asmhelper.dsl.instructions.InsnListBuilder;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function10;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.functions.Function6;
import kotlin.jvm.functions.Function7;
import kotlin.jvm.functions.Function8;
import kotlin.jvm.functions.Function9;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000h\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u0000 42\u00020\u0001:\u00014B\u0005¢\u0006\u0002\u0010\u0002J\u0014\u0010\u0003\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00040\u0005J\u0016\u0010\u0006\u001a\u0002H\u0007\"\u0006\b\u0000\u0010\u0007\u0018\u0001H\u0086\b¢\u0006\u0002\u0010\bJ\u0016\u0010\t\u001a\u0002H\u0007\"\u0006\b\u0000\u0010\u0007\u0018\u0001H\u0086\b¢\u0006\u0002\u0010\bJ\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u0002H\u000b0\u0005\"\u0006\b\u0000\u0010\u000b\u0018\u0001H\u0086\bJ4\u0010\n\u001a\u000e\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u000b0\f\"\u0006\b\u0000\u0010\u000b\u0018\u0001\"\u0004\b\u0001\u0010\r2\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u0001H\rH\u0086\b¢\u0006\u0002\u0010\u000fJL\u0010\n\u001a\u0014\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u0011\u0012\u0004\u0012\u0002H\u000b0\u0010\"\u0006\b\u0000\u0010\u000b\u0018\u0001\"\u0004\b\u0001\u0010\r\"\u0004\b\u0002\u0010\u00112\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u0001H\r2\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u0001H\u0011H\u0086\b¢\u0006\u0002\u0010\u0013Jd\u0010\n\u001a\u001a\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u0011\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002H\u000b0\u0014\"\u0006\b\u0000\u0010\u000b\u0018\u0001\"\u0004\b\u0001\u0010\r\"\u0004\b\u0002\u0010\u0011\"\u0004\b\u0003\u0010\u00152\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u0001H\r2\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u0001H\u00112\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u0001H\u0015H\u0086\b¢\u0006\u0002\u0010\u0017J|\u0010\n\u001a \u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u0011\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002H\u0019\u0012\u0004\u0012\u0002H\u000b0\u0018\"\u0006\b\u0000\u0010\u000b\u0018\u0001\"\u0004\b\u0001\u0010\r\"\u0004\b\u0002\u0010\u0011\"\u0004\b\u0003\u0010\u0015\"\u0004\b\u0004\u0010\u00192\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u0001H\r2\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u0001H\u00112\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u0001H\u00152\n\b\u0002\u0010\u001a\u001a\u0004\u0018\u0001H\u0019H\u0086\b¢\u0006\u0002\u0010\u001bJ\u0094\u0001\u0010\n\u001a&\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u0011\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002H\u0019\u0012\u0004\u0012\u0002H\u001d\u0012\u0004\u0012\u0002H\u000b0\u001c\"\u0006\b\u0000\u0010\u000b\u0018\u0001\"\u0004\b\u0001\u0010\r\"\u0004\b\u0002\u0010\u0011\"\u0004\b\u0003\u0010\u0015\"\u0004\b\u0004\u0010\u0019\"\u0004\b\u0005\u0010\u001d2\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u0001H\r2\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u0001H\u00112\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u0001H\u00152\n\b\u0002\u0010\u001a\u001a\u0004\u0018\u0001H\u00192\n\b\u0002\u0010\u001e\u001a\u0004\u0018\u0001H\u001dH\u0086\b¢\u0006\u0002\u0010\u001fJ¬\u0001\u0010\n\u001a,\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u0011\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002H\u0019\u0012\u0004\u0012\u0002H\u001d\u0012\u0004\u0012\u0002H!\u0012\u0004\u0012\u0002H\u000b0 \"\u0006\b\u0000\u0010\u000b\u0018\u0001\"\u0004\b\u0001\u0010\r\"\u0004\b\u0002\u0010\u0011\"\u0004\b\u0003\u0010\u0015\"\u0004\b\u0004\u0010\u0019\"\u0004\b\u0005\u0010\u001d\"\u0004\b\u0006\u0010!2\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u0001H\r2\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u0001H\u00112\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u0001H\u00152\n\b\u0002\u0010\u001a\u001a\u0004\u0018\u0001H\u00192\n\b\u0002\u0010\u001e\u001a\u0004\u0018\u0001H\u001d2\n\b\u0002\u0010\"\u001a\u0004\u0018\u0001H!H\u0086\b¢\u0006\u0002\u0010#JÄ\u0001\u0010\n\u001a2\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u0011\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002H\u0019\u0012\u0004\u0012\u0002H\u001d\u0012\u0004\u0012\u0002H!\u0012\u0004\u0012\u0002H%\u0012\u0004\u0012\u0002H\u000b0$\"\u0006\b\u0000\u0010\u000b\u0018\u0001\"\u0004\b\u0001\u0010\r\"\u0004\b\u0002\u0010\u0011\"\u0004\b\u0003\u0010\u0015\"\u0004\b\u0004\u0010\u0019\"\u0004\b\u0005\u0010\u001d\"\u0004\b\u0006\u0010!\"\u0004\b\u0007\u0010%2\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u0001H\r2\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u0001H\u00112\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u0001H\u00152\n\b\u0002\u0010\u001a\u001a\u0004\u0018\u0001H\u00192\n\b\u0002\u0010\u001e\u001a\u0004\u0018\u0001H\u001d2\n\b\u0002\u0010\"\u001a\u0004\u0018\u0001H!2\n\b\u0002\u0010&\u001a\u0004\u0018\u0001H%H\u0086\b¢\u0006\u0002\u0010'JÜ\u0001\u0010\n\u001a8\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u0011\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002H\u0019\u0012\u0004\u0012\u0002H\u001d\u0012\u0004\u0012\u0002H!\u0012\u0004\u0012\u0002H%\u0012\u0004\u0012\u0002H)\u0012\u0004\u0012\u0002H\u000b0(\"\u0006\b\u0000\u0010\u000b\u0018\u0001\"\u0004\b\u0001\u0010\r\"\u0004\b\u0002\u0010\u0011\"\u0004\b\u0003\u0010\u0015\"\u0004\b\u0004\u0010\u0019\"\u0004\b\u0005\u0010\u001d\"\u0004\b\u0006\u0010!\"\u0004\b\u0007\u0010%\"\u0004\b\b\u0010)2\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u0001H\r2\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u0001H\u00112\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u0001H\u00152\n\b\u0002\u0010\u001a\u001a\u0004\u0018\u0001H\u00192\n\b\u0002\u0010\u001e\u001a\u0004\u0018\u0001H\u001d2\n\b\u0002\u0010\"\u001a\u0004\u0018\u0001H!2\n\b\u0002\u0010&\u001a\u0004\u0018\u0001H%2\n\b\u0002\u0010*\u001a\u0004\u0018\u0001H)H\u0086\b¢\u0006\u0002\u0010+Jô\u0001\u0010\n\u001a>\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u0011\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002H\u0019\u0012\u0004\u0012\u0002H\u001d\u0012\u0004\u0012\u0002H!\u0012\u0004\u0012\u0002H%\u0012\u0004\u0012\u0002H)\u0012\u0004\u0012\u0002H-\u0012\u0004\u0012\u0002H\u000b0,\"\u0006\b\u0000\u0010\u000b\u0018\u0001\"\u0004\b\u0001\u0010\r\"\u0004\b\u0002\u0010\u0011\"\u0004\b\u0003\u0010\u0015\"\u0004\b\u0004\u0010\u0019\"\u0004\b\u0005\u0010\u001d\"\u0004\b\u0006\u0010!\"\u0004\b\u0007\u0010%\"\u0004\b\b\u0010)\"\u0004\b\t\u0010-2\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u0001H\r2\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u0001H\u00112\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u0001H\u00152\n\b\u0002\u0010\u001a\u001a\u0004\u0018\u0001H\u00192\n\b\u0002\u0010\u001e\u001a\u0004\u0018\u0001H\u001d2\n\b\u0002\u0010\"\u001a\u0004\u0018\u0001H!2\n\b\u0002\u0010&\u001a\u0004\u0018\u0001H%2\n\b\u0002\u0010*\u001a\u0004\u0018\u0001H)2\n\b\u0002\u0010.\u001a\u0004\u0018\u0001H-H\u0086\b¢\u0006\u0002\u0010/J\u008c\u0002\u0010\n\u001aD\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u0011\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002H\u0019\u0012\u0004\u0012\u0002H\u001d\u0012\u0004\u0012\u0002H!\u0012\u0004\u0012\u0002H%\u0012\u0004\u0012\u0002H)\u0012\u0004\u0012\u0002H-\u0012\u0004\u0012\u0002H1\u0012\u0004\u0012\u0002H\u000b00\"\u0006\b\u0000\u0010\u000b\u0018\u0001\"\u0004\b\u0001\u0010\r\"\u0004\b\u0002\u0010\u0011\"\u0004\b\u0003\u0010\u0015\"\u0004\b\u0004\u0010\u0019\"\u0004\b\u0005\u0010\u001d\"\u0004\b\u0006\u0010!\"\u0004\b\u0007\u0010%\"\u0004\b\b\u0010)\"\u0004\b\t\u0010-\"\u0004\b\n\u001012\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u0001H\r2\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u0001H\u00112\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u0001H\u00152\n\b\u0002\u0010\u001a\u001a\u0004\u0018\u0001H\u00192\n\b\u0002\u0010\u001e\u001a\u0004\u0018\u0001H\u001d2\n\b\u0002\u0010\"\u001a\u0004\u0018\u0001H!2\n\b\u0002\u0010&\u001a\u0004\u0018\u0001H%2\n\b\u0002\u0010*\u001a\u0004\u0018\u0001H)2\n\b\u0002\u0010.\u001a\u0004\u0018\u0001H-2\n\b\u0002\u00102\u001a\u0004\u0018\u0001H1H\u0086\b¢\u0006\u0002\u00103¨\u00065"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/CodeBlock;", "", "()V", "code", "", "Lkotlin/Function0;", "shadowField", "T", "()Ljava/lang/Object;", "shadowLocal", "shadowMethod", "R", "Lkotlin/Function1;", "P1", "p1", "(Ljava/lang/Object;)Lkotlin/jvm/functions/Function1;", "Lkotlin/Function2;", "P2", "p2", "(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/jvm/functions/Function2;", "Lkotlin/Function3;", "P3", "p3", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/jvm/functions/Function3;", "Lkotlin/Function4;", "P4", "p4", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/jvm/functions/Function4;", "Lkotlin/Function5;", "P5", "p5", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/jvm/functions/Function5;", "Lkotlin/Function6;", "P6", "p6", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/jvm/functions/Function6;", "Lkotlin/Function7;", "P7", "p7", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/jvm/functions/Function7;", "Lkotlin/Function8;", "P8", "p8", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/jvm/functions/Function8;", "Lkotlin/Function9;", "P9", "p9", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/jvm/functions/Function9;", "Lkotlin/Function10;", "P10", "p10", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/jvm/functions/Function10;", "Companion", "AsmHelper1.8.9"}
)
public final class CodeBlock {
   @NotNull
   public static final CodeBlock.Companion Companion = new CodeBlock.Companion((DefaultConstructorMarker)null);

   public final void code(@NotNull Function0<Unit> code) {
      Intrinsics.checkNotNullParameter(code, "code");
   }

   // $FF: synthetic method
   public final <T> T shadowField() {
      int $i$f$shadowField = false;
      Intrinsics.reifiedOperationMarker(1, "T");
      return (Object)null;
   }

   // $FF: synthetic method
   public final <T> T shadowLocal() {
      int $i$f$shadowLocal = false;
      Intrinsics.reifiedOperationMarker(1, "T");
      return (Object)null;
   }

   // $FF: synthetic method
   public final <R> Function0<R> shadowMethod() {
      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function0)(new Function0<R>() {
         public final R invoke() {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public final <R, P1> Function1<P1, R> shadowMethod(P1 p1) {
      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function1)(new Function1<P1, R>() {
         public final R invoke(P1 it) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public static Function1 shadowMethod$default(CodeBlock var0, Object p1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         p1 = null;
      }

      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function1)(new Function1<P1, R>() {
         public final R invoke(P1 it) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public final <R, P1, P2> Function2<P1, P2, R> shadowMethod(P1 p1, P2 p2) {
      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function2)(new Function2<P1, P2, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public static Function2 shadowMethod$default(CodeBlock var0, Object p1, Object p2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         p1 = null;
      }

      if ((var3 & 2) != 0) {
         p2 = null;
      }

      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function2)(new Function2<P1, P2, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public final <R, P1, P2, P3> Function3<P1, P2, P3, R> shadowMethod(P1 p1, P2 p2, P3 p3) {
      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function3)(new Function3<P1, P2, P3, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public static Function3 shadowMethod$default(CodeBlock var0, Object p1, Object p2, Object p3, int var4, Object var5) {
      if ((var4 & 1) != 0) {
         p1 = null;
      }

      if ((var4 & 2) != 0) {
         p2 = null;
      }

      if ((var4 & 4) != 0) {
         p3 = null;
      }

      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function3)(new Function3<P1, P2, P3, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public final <R, P1, P2, P3, P4> Function4<P1, P2, P3, P4, R> shadowMethod(P1 p1, P2 p2, P3 p3, P4 p4) {
      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function4)(new Function4<P1, P2, P3, P4, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public static Function4 shadowMethod$default(CodeBlock var0, Object p1, Object p2, Object p3, Object p4, int var5, Object var6) {
      if ((var5 & 1) != 0) {
         p1 = null;
      }

      if ((var5 & 2) != 0) {
         p2 = null;
      }

      if ((var5 & 4) != 0) {
         p3 = null;
      }

      if ((var5 & 8) != 0) {
         p4 = null;
      }

      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function4)(new Function4<P1, P2, P3, P4, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public final <R, P1, P2, P3, P4, P5> Function5<P1, P2, P3, P4, P5, R> shadowMethod(P1 p1, P2 p2, P3 p3, P4 p4, P5 p5) {
      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function5)(new Function5<P1, P2, P3, P4, P5, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3, P5 $noName_4) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public static Function5 shadowMethod$default(CodeBlock var0, Object p1, Object p2, Object p3, Object p4, Object p5, int var6, Object var7) {
      if ((var6 & 1) != 0) {
         p1 = null;
      }

      if ((var6 & 2) != 0) {
         p2 = null;
      }

      if ((var6 & 4) != 0) {
         p3 = null;
      }

      if ((var6 & 8) != 0) {
         p4 = null;
      }

      if ((var6 & 16) != 0) {
         p5 = null;
      }

      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function5)(new Function5<P1, P2, P3, P4, P5, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3, P5 $noName_4) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public final <R, P1, P2, P3, P4, P5, P6> Function6<P1, P2, P3, P4, P5, P6, R> shadowMethod(P1 p1, P2 p2, P3 p3, P4 p4, P5 p5, P6 p6) {
      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function6)(new Function6<P1, P2, P3, P4, P5, P6, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3, P5 $noName_4, P6 $noName_5) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public static Function6 shadowMethod$default(CodeBlock var0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, int var7, Object var8) {
      if ((var7 & 1) != 0) {
         p1 = null;
      }

      if ((var7 & 2) != 0) {
         p2 = null;
      }

      if ((var7 & 4) != 0) {
         p3 = null;
      }

      if ((var7 & 8) != 0) {
         p4 = null;
      }

      if ((var7 & 16) != 0) {
         p5 = null;
      }

      if ((var7 & 32) != 0) {
         p6 = null;
      }

      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function6)(new Function6<P1, P2, P3, P4, P5, P6, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3, P5 $noName_4, P6 $noName_5) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public final <R, P1, P2, P3, P4, P5, P6, P7> Function7<P1, P2, P3, P4, P5, P6, P7, R> shadowMethod(P1 p1, P2 p2, P3 p3, P4 p4, P5 p5, P6 p6, P7 p7) {
      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function7)(new Function7<P1, P2, P3, P4, P5, P6, P7, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3, P5 $noName_4, P6 $noName_5, P7 $noName_6) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public static Function7 shadowMethod$default(CodeBlock var0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, int var8, Object var9) {
      if ((var8 & 1) != 0) {
         p1 = null;
      }

      if ((var8 & 2) != 0) {
         p2 = null;
      }

      if ((var8 & 4) != 0) {
         p3 = null;
      }

      if ((var8 & 8) != 0) {
         p4 = null;
      }

      if ((var8 & 16) != 0) {
         p5 = null;
      }

      if ((var8 & 32) != 0) {
         p6 = null;
      }

      if ((var8 & 64) != 0) {
         p7 = null;
      }

      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function7)(new Function7<P1, P2, P3, P4, P5, P6, P7, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3, P5 $noName_4, P6 $noName_5, P7 $noName_6) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public final <R, P1, P2, P3, P4, P5, P6, P7, P8> Function8<P1, P2, P3, P4, P5, P6, P7, P8, R> shadowMethod(P1 p1, P2 p2, P3 p3, P4 p4, P5 p5, P6 p6, P7 p7, P8 p8) {
      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function8)(new Function8<P1, P2, P3, P4, P5, P6, P7, P8, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3, P5 $noName_4, P6 $noName_5, P7 $noName_6, P8 $noName_7) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public static Function8 shadowMethod$default(CodeBlock var0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, int var9, Object var10) {
      if ((var9 & 1) != 0) {
         p1 = null;
      }

      if ((var9 & 2) != 0) {
         p2 = null;
      }

      if ((var9 & 4) != 0) {
         p3 = null;
      }

      if ((var9 & 8) != 0) {
         p4 = null;
      }

      if ((var9 & 16) != 0) {
         p5 = null;
      }

      if ((var9 & 32) != 0) {
         p6 = null;
      }

      if ((var9 & 64) != 0) {
         p7 = null;
      }

      if ((var9 & 128) != 0) {
         p8 = null;
      }

      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function8)(new Function8<P1, P2, P3, P4, P5, P6, P7, P8, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3, P5 $noName_4, P6 $noName_5, P7 $noName_6, P8 $noName_7) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public final <R, P1, P2, P3, P4, P5, P6, P7, P8, P9> Function9<P1, P2, P3, P4, P5, P6, P7, P8, P9, R> shadowMethod(P1 p1, P2 p2, P3 p3, P4 p4, P5 p5, P6 p6, P7 p7, P8 p8, P9 p9) {
      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function9)(new Function9<P1, P2, P3, P4, P5, P6, P7, P8, P9, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3, P5 $noName_4, P6 $noName_5, P7 $noName_6, P8 $noName_7, P9 $noName_8) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public static Function9 shadowMethod$default(CodeBlock var0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9, int var10, Object var11) {
      if ((var10 & 1) != 0) {
         p1 = null;
      }

      if ((var10 & 2) != 0) {
         p2 = null;
      }

      if ((var10 & 4) != 0) {
         p3 = null;
      }

      if ((var10 & 8) != 0) {
         p4 = null;
      }

      if ((var10 & 16) != 0) {
         p5 = null;
      }

      if ((var10 & 32) != 0) {
         p6 = null;
      }

      if ((var10 & 64) != 0) {
         p7 = null;
      }

      if ((var10 & 128) != 0) {
         p8 = null;
      }

      if ((var10 & 256) != 0) {
         p9 = null;
      }

      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function9)(new Function9<P1, P2, P3, P4, P5, P6, P7, P8, P9, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3, P5 $noName_4, P6 $noName_5, P7 $noName_6, P8 $noName_7, P9 $noName_8) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public final <R, P1, P2, P3, P4, P5, P6, P7, P8, P9, P10> Function10<P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, R> shadowMethod(P1 p1, P2 p2, P3 p3, P4 p4, P5 p5, P6 p6, P7 p7, P8 p8, P9 p9, P10 p10) {
      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function10)(new Function10<P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3, P5 $noName_4, P6 $noName_5, P7 $noName_6, P8 $noName_7, P9 $noName_8, P10 $noName_9) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   // $FF: synthetic method
   public static Function10 shadowMethod$default(CodeBlock var0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9, Object p10, int var11, Object var12) {
      if ((var11 & 1) != 0) {
         p1 = null;
      }

      if ((var11 & 2) != 0) {
         p2 = null;
      }

      if ((var11 & 4) != 0) {
         p3 = null;
      }

      if ((var11 & 8) != 0) {
         p4 = null;
      }

      if ((var11 & 16) != 0) {
         p5 = null;
      }

      if ((var11 & 32) != 0) {
         p6 = null;
      }

      if ((var11 & 64) != 0) {
         p7 = null;
      }

      if ((var11 & 128) != 0) {
         p8 = null;
      }

      if ((var11 & 256) != 0) {
         p9 = null;
      }

      if ((var11 & 512) != 0) {
         p10 = null;
      }

      int $i$f$shadowMethod = false;
      Intrinsics.needClassReification();
      return (Function10)(new Function10<P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, R>() {
         public final R invoke(P1 $noName_0, P2 $noName_1, P3 $noName_2, P4 $noName_3, P5 $noName_4, P6 $noName_5, P7 $noName_6, P8 $noName_7, P9 $noName_8, P10 $noName_9) {
            Intrinsics.reifiedOperationMarker(1, "R");
            return (Object)null;
         }
      });
   }

   @Metadata(
      mv = {1, 5, 1},
      k = 1,
      xi = 48,
      d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0001J\u001f\u0010\u0006\u001a\u00020\u00042\u0017\u0010\u0007\u001a\u0013\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u00040\b¢\u0006\u0002\b\nJ\u000e\u0010\u000b\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\rJ\u000e\u0010\u000e\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\u000fJ\u000e\u0010\u0010\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\u0011J\u000e\u0010\u0012\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\u0013J\u0006\u0010\u0014\u001a\u00020\u0004¨\u0006\u0015"},
      d2 = {"Ldev/falsehonesty/asmhelper/dsl/code/CodeBlock$Companion;", "", "()V", "aReturn", "", "obj", "asm", "bytecode", "Lkotlin/Function1;", "Ldev/falsehonesty/asmhelper/dsl/instructions/InsnListBuilder;", "Lkotlin/ExtensionFunctionType;", "dReturn", "num", "", "fReturn", "", "iReturn", "", "lReturn", "", "methodReturn", "AsmHelper1.8.9"}
   )
   public static final class Companion {
      private Companion() {
      }

      public final void methodReturn() {
      }

      public final void aReturn(@Nullable Object obj) {
      }

      public final void iReturn(int num) {
      }

      public final void lReturn(long num) {
      }

      public final void fReturn(float num) {
      }

      public final void dReturn(double num) {
      }

      public final void asm(@NotNull Function1<? super InsnListBuilder, Unit> bytecode) {
         Intrinsics.checkNotNullParameter(bytecode, "bytecode");
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
