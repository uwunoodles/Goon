package dev.falsehonesty.asmhelper.dsl.writers;

import dev.falsehonesty.asmhelper.AsmHelper;
import dev.falsehonesty.asmhelper.dsl.AsmWriter;
import dev.falsehonesty.asmhelper.dsl.At;
import dev.falsehonesty.asmhelper.dsl.code.CodeBlock;
import dev.falsehonesty.asmhelper.dsl.instructions.InsnListBuilder;
import dev.falsehonesty.asmhelper.printing.PrettyprintingKt;
import dev.falsehonesty.asmhelper.printing.PrintingKt;
import dev.falsehonesty.asmhelper.remapping.Remapper;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001:\u0001\u001eBr\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0019\u0010\b\u001a\u0015\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\t¢\u0006\u0002\b\f\u0012\b\u0010\r\u001a\u0004\u0018\u00010\u0003\u0012\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u000f\u0012\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u000f¢\u0006\u0002\u0010\u0011J\u0018\u0010\u0012\u001a\u00020\u000b2\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J \u0010\u0017\u001a\u00020\u000b2\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001bH\u0002J\b\u0010\u001c\u001a\u00020\u0003H\u0016J\u0010\u0010\u001d\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u0016H\u0016R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R!\u0010\b\u001a\u0015\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\t¢\u0006\u0002\b\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001f"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/writers/InjectWriter;", "Ldev/falsehonesty/asmhelper/dsl/AsmWriter;", "className", "", "methodName", "methodDesc", "at", "Ldev/falsehonesty/asmhelper/dsl/At;", "insnListBuilder", "Lkotlin/Function1;", "Ldev/falsehonesty/asmhelper/dsl/instructions/InsnListBuilder;", "", "Lkotlin/ExtensionFunctionType;", "codeBlockClassName", "fieldMaps", "", "methodMaps", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ldev/falsehonesty/asmhelper/dsl/At;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)V", "injectInsnList", "method", "Lorg/objectweb/asm/tree/MethodNode;", "classNode", "Lorg/objectweb/asm/tree/ClassNode;", "insertToNode", "node", "Lorg/objectweb/asm/tree/AbstractInsnNode;", "insnList", "Lorg/objectweb/asm/tree/InsnList;", "toString", "transform", "Builder", "AsmHelper1.8.9"}
)
public final class InjectWriter extends AsmWriter {
   @NotNull
   private final String methodName;
   @NotNull
   private final String methodDesc;
   @NotNull
   private final At at;
   @Nullable
   private final Function1<InsnListBuilder, Unit> insnListBuilder;
   @Nullable
   private final String codeBlockClassName;
   @NotNull
   private final Map<String, String> fieldMaps;
   @NotNull
   private final Map<String, String> methodMaps;

   public InjectWriter(@NotNull String className, @NotNull String methodName, @NotNull String methodDesc, @NotNull At at, @Nullable Function1<? super InsnListBuilder, Unit> insnListBuilder, @Nullable String codeBlockClassName, @NotNull Map<String, String> fieldMaps, @NotNull Map<String, String> methodMaps) {
      Intrinsics.checkNotNullParameter(className, "className");
      Intrinsics.checkNotNullParameter(methodName, "methodName");
      Intrinsics.checkNotNullParameter(methodDesc, "methodDesc");
      Intrinsics.checkNotNullParameter(at, "at");
      Intrinsics.checkNotNullParameter(fieldMaps, "fieldMaps");
      Intrinsics.checkNotNullParameter(methodMaps, "methodMaps");
      super(className);
      this.methodName = methodName;
      this.methodDesc = methodDesc;
      this.at = at;
      this.insnListBuilder = insnListBuilder;
      this.codeBlockClassName = codeBlockClassName;
      this.fieldMaps = fieldMaps;
      this.methodMaps = methodMaps;
   }

   public void transform(@NotNull ClassNode classNode) {
      Intrinsics.checkNotNullParameter(classNode, "classNode");
      AsmHelper.INSTANCE.setFieldMaps$AsmHelper1_8_9(this.fieldMaps);
      AsmHelper.INSTANCE.setMethodMaps$AsmHelper1_8_9(this.methodMaps);
      List var4 = classNode.methods;
      Intrinsics.checkNotNullExpressionValue(var4, "classNode.methods");
      Iterable var15 = (Iterable)var4;
      boolean var5 = false;
      boolean var7 = false;
      Iterator var8 = var15.iterator();

      Object var17;
      while(true) {
         if (!var8.hasNext()) {
            var17 = null;
            break;
         }

         Object var9 = var8.next();
         MethodNode it = (MethodNode)var9;
         int var11 = false;
         Remapper var10000 = AsmHelper.INSTANCE.getRemapper();
         String remappedDesc = classNode.name;
         Intrinsics.checkNotNullExpressionValue(remappedDesc, "classNode.name");
         String var10001 = remappedDesc;
         remappedDesc = it.name;
         Intrinsics.checkNotNullExpressionValue(remappedDesc, "it.name");
         String var10002 = remappedDesc;
         remappedDesc = it.desc;
         Intrinsics.checkNotNullExpressionValue(remappedDesc, "it.desc");
         String remapped = var10000.remapMethodName(var10001, var10002, remappedDesc);
         var10000 = AsmHelper.INSTANCE.getRemapper();
         String var14 = it.desc;
         Intrinsics.checkNotNullExpressionValue(var14, "it.desc");
         remappedDesc = var10000.remapDesc(var14);
         if (Intrinsics.areEqual(remappedDesc, this.methodDesc) && (Intrinsics.areEqual(remapped, this.methodName) || Intrinsics.areEqual(this.methodMaps.get(remapped), this.methodName))) {
            var17 = var9;
            break;
         }
      }

      MethodNode var3 = (MethodNode)var17;
      Unit var18;
      if (var3 == null) {
         var18 = null;
      } else {
         var5 = false;
         boolean var6 = false;
         int var16 = false;
         this.injectInsnList(var3, classNode);
         var18 = Unit.INSTANCE;
      }

      Unit var2 = var18;
      if (var2 == null) {
         PrintingKt.getLogger().error(Intrinsics.stringPlus("No methods found for target ", this.methodName));
      }

   }

   private final void injectInsnList(MethodNode method, ClassNode classNode) {
      List nodes = this.at.getTargetedNodes(method);
      InsnList var5 = this.transformToInstructions(this.insnListBuilder, this.codeBlockClassName, method, classNode);
      if (var5 != null) {
         InsnList instructions = var5;
         if (nodes.isEmpty()) {
            PrintingKt.getLogger().error(Intrinsics.stringPlus("Couldn't find any matching nodes for ", this));
         } else {
            PrintingKt.verbose(this + " matched the following " + nodes.size() + " targets");
         }

         Iterable $this$forEachIndexed$iv = (Iterable)nodes;
         int $i$f$forEachIndexed = false;
         int index$iv = 0;
         Iterator var8 = $this$forEachIndexed$iv.iterator();

         while(var8.hasNext()) {
            Object item$iv = var8.next();
            int var10 = index$iv++;
            boolean var11 = false;
            if (var10 < 0) {
               CollectionsKt.throwIndexOverflow();
            }

            AbstractInsnNode node = (AbstractInsnNode)item$iv;
            int var14 = false;
            PrintingKt.verbose(var10 + ".    " + PrettyprintingKt.prettyString(node));
            this.insertToNode(method, node, instructions);
         }

      }
   }

   private final void insertToNode(MethodNode method, AbstractInsnNode node, InsnList insnList) {
      Object target = null;
      target = node;
      int var5;
      boolean var6;
      boolean var7;
      int var8;
      boolean var10;
      AbstractInsnNode var11;
      int var12;
      if (this.at.getShift() < 0) {
         var5 = -this.at.getShift();
         var6 = false;
         var7 = false;
         var12 = 0;

         for(var8 = var5; var12 < var8; ++var12) {
            var10 = false;
            var11 = target.getPrevious();
            Intrinsics.checkNotNullExpressionValue(var11, "target.previous");
            target = var11;
         }
      } else if (this.at.getShift() > 0) {
         var5 = this.at.getShift();
         var6 = false;
         var7 = false;
         var12 = 0;

         for(var8 = var5; var12 < var8; ++var12) {
            var10 = false;
            var11 = target.getNext();
            Intrinsics.checkNotNullExpressionValue(var11, "target.next");
            target = var11;
         }
      }

      if (this.at.getBefore()) {
         method.instructions.insertBefore(target, insnList);
      } else {
         method.instructions.insert(target, insnList);
      }

   }

   @NotNull
   public String toString() {
      return "InjectWriter{className=" + this.getClassName() + ", methodName=" + this.methodName + ", methodDesc=" + this.methodDesc + ", at=" + this.at + '}';
   }

   @Metadata(
      mv = {1, 5, 1},
      k = 1,
      xi = 48,
      d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010$\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0006\u0010$\u001a\u00020%J\u001f\u0010&\u001a\u00020\u00192\u0017\u0010'\u001a\u0013\u0012\u0004\u0012\u00020(\u0012\u0004\u0012\u00020\u00190\u0017¢\u0006\u0002\b\u001aJ\u001f\u0010)\u001a\u00020\u00192\u0017\u0010*\u001a\u0013\u0012\u0004\u0012\u00020\u0018\u0012\u0004\u0012\u00020\u00190\u0017¢\u0006\u0002\b\u001aR\u001a\u0010\u0003\u001a\u00020\u0004X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\nX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u0010\u0010\u000f\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R&\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n0\u0011X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R!\u0010\u0016\u001a\u0015\u0012\u0004\u0012\u00020\u0018\u0012\u0004\u0012\u00020\u0019\u0018\u00010\u0017¢\u0006\u0002\b\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u001b\u001a\u00020\nX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\f\"\u0004\b\u001d\u0010\u000eR&\u0010\u001e\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n0\u0011X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010\u0013\"\u0004\b \u0010\u0015R\u001a\u0010!\u001a\u00020\nX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\"\u0010\f\"\u0004\b#\u0010\u000e¨\u0006+"},
      d2 = {"Ldev/falsehonesty/asmhelper/dsl/writers/InjectWriter$Builder;", "Ldev/falsehonesty/asmhelper/dsl/AsmWriter$AsmWriterBuilder;", "()V", "at", "Ldev/falsehonesty/asmhelper/dsl/At;", "getAt", "()Ldev/falsehonesty/asmhelper/dsl/At;", "setAt", "(Ldev/falsehonesty/asmhelper/dsl/At;)V", "className", "", "getClassName", "()Ljava/lang/String;", "setClassName", "(Ljava/lang/String;)V", "codeBlockClassName", "fieldMaps", "", "getFieldMaps", "()Ljava/util/Map;", "setFieldMaps", "(Ljava/util/Map;)V", "insnListBuilder", "Lkotlin/Function1;", "Ldev/falsehonesty/asmhelper/dsl/instructions/InsnListBuilder;", "", "Lkotlin/ExtensionFunctionType;", "methodDesc", "getMethodDesc", "setMethodDesc", "methodMaps", "getMethodMaps", "setMethodMaps", "methodName", "getMethodName", "setMethodName", "build", "Ldev/falsehonesty/asmhelper/dsl/AsmWriter;", "codeBlock", "code", "Ldev/falsehonesty/asmhelper/dsl/code/CodeBlock;", "insnList", "config", "AsmHelper1.8.9"}
   )
   public static final class Builder extends AsmWriter.AsmWriterBuilder {
      public String className;
      public String methodName;
      public String methodDesc;
      public At at;
      @Nullable
      private Function1<? super InsnListBuilder, Unit> insnListBuilder;
      @Nullable
      private String codeBlockClassName;
      @NotNull
      private Map<String, String> fieldMaps;
      @NotNull
      private Map<String, String> methodMaps;

      public Builder() {
         boolean var1 = false;
         this.fieldMaps = MapsKt.emptyMap();
         var1 = false;
         this.methodMaps = MapsKt.emptyMap();
      }

      @NotNull
      public final String getClassName() {
         String var1 = this.className;
         if (var1 != null) {
            return var1;
         } else {
            Intrinsics.throwUninitializedPropertyAccessException("className");
            throw null;
         }
      }

      public final void setClassName(@NotNull String var1) {
         Intrinsics.checkNotNullParameter(var1, "<set-?>");
         this.className = var1;
      }

      @NotNull
      public final String getMethodName() {
         String var1 = this.methodName;
         if (var1 != null) {
            return var1;
         } else {
            Intrinsics.throwUninitializedPropertyAccessException("methodName");
            throw null;
         }
      }

      public final void setMethodName(@NotNull String var1) {
         Intrinsics.checkNotNullParameter(var1, "<set-?>");
         this.methodName = var1;
      }

      @NotNull
      public final String getMethodDesc() {
         String var1 = this.methodDesc;
         if (var1 != null) {
            return var1;
         } else {
            Intrinsics.throwUninitializedPropertyAccessException("methodDesc");
            throw null;
         }
      }

      public final void setMethodDesc(@NotNull String var1) {
         Intrinsics.checkNotNullParameter(var1, "<set-?>");
         this.methodDesc = var1;
      }

      @NotNull
      public final At getAt() {
         At var1 = this.at;
         if (var1 != null) {
            return var1;
         } else {
            Intrinsics.throwUninitializedPropertyAccessException("at");
            throw null;
         }
      }

      public final void setAt(@NotNull At var1) {
         Intrinsics.checkNotNullParameter(var1, "<set-?>");
         this.at = var1;
      }

      @NotNull
      public final Map<String, String> getFieldMaps() {
         return this.fieldMaps;
      }

      public final void setFieldMaps(@NotNull Map<String, String> var1) {
         Intrinsics.checkNotNullParameter(var1, "<set-?>");
         this.fieldMaps = var1;
      }

      @NotNull
      public final Map<String, String> getMethodMaps() {
         return this.methodMaps;
      }

      public final void setMethodMaps(@NotNull Map<String, String> var1) {
         Intrinsics.checkNotNullParameter(var1, "<set-?>");
         this.methodMaps = var1;
      }

      @NotNull
      public final AsmWriter build() throws IllegalStateException {
         return (AsmWriter)(new InjectWriter(this.getClassName(), this.getMethodName(), this.getMethodDesc(), this.getAt(), this.insnListBuilder, this.codeBlockClassName, this.fieldMaps, this.methodMaps));
      }

      public final void insnList(@NotNull Function1<? super InsnListBuilder, Unit> config) {
         Intrinsics.checkNotNullParameter(config, "config");
         this.insnListBuilder = config;
      }

      public final void codeBlock(@NotNull Function1<? super CodeBlock, Unit> code) {
         Intrinsics.checkNotNullParameter(code, "code");
         this.codeBlockClassName = Intrinsics.stringPlus(code.getClass().getName(), "$1");
      }
   }
}
