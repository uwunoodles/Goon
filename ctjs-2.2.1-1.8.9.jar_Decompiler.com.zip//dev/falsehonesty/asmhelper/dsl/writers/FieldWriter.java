package dev.falsehonesty.asmhelper.dsl.writers;

import dev.falsehonesty.asmhelper.dsl.AsmWriter;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0011B5\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t¢\u0006\u0002\u0010\u000bJ\b\u0010\f\u001a\u00020\u0003H\u0016J\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0012"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/writers/FieldWriter;", "Ldev/falsehonesty/asmhelper/dsl/AsmWriter;", "className", "", "fieldName", "fieldDesc", "initialValue", "", "accessTypes", "", "Ldev/falsehonesty/asmhelper/dsl/writers/AccessType;", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;Ljava/util/List;)V", "toString", "transform", "", "classNode", "Lorg/objectweb/asm/tree/ClassNode;", "Builder", "AsmHelper1.8.9"}
)
public final class FieldWriter extends AsmWriter {
   @NotNull
   private final String fieldName;
   @NotNull
   private final String fieldDesc;
   @Nullable
   private final Object initialValue;
   @NotNull
   private final List<AccessType> accessTypes;

   public FieldWriter(@NotNull String className, @NotNull String fieldName, @NotNull String fieldDesc, @Nullable Object initialValue, @NotNull List<? extends AccessType> accessTypes) {
      Intrinsics.checkNotNullParameter(className, "className");
      Intrinsics.checkNotNullParameter(fieldName, "fieldName");
      Intrinsics.checkNotNullParameter(fieldDesc, "fieldDesc");
      Intrinsics.checkNotNullParameter(accessTypes, "accessTypes");
      super(className);
      this.fieldName = fieldName;
      this.fieldDesc = fieldDesc;
      this.initialValue = initialValue;
      this.accessTypes = accessTypes;
   }

   public void transform(@NotNull ClassNode classNode) {
      Intrinsics.checkNotNullParameter(classNode, "classNode");
      Iterable $this$fold$iv = (Iterable)this.accessTypes;
      int initial$iv = 0;
      List var11 = classNode.fields;
      int $i$f$fold = false;
      int accumulator$iv = initial$iv;

      AccessType accessType;
      for(Iterator var6 = $this$fold$iv.iterator(); var6.hasNext(); accumulator$iv |= accessType.getOpcode()) {
         Object element$iv = var6.next();
         accessType = (AccessType)element$iv;
         int var10 = false;
      }

      Object var15 = this.initialValue;
      Object var16 = null;
      String var17 = this.fieldDesc;
      String var18 = this.fieldName;
      var11.add(new FieldNode(accumulator$iv, var18, var17, (String)var16, var15));
   }

   @NotNull
   public String toString() {
      return "FieldWriter{className=" + this.getClassName() + ", fieldName=" + this.fieldName + '}';
   }

   @Metadata(
      mv = {1, 5, 1},
      k = 1,
      xi = 48,
      d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u000b\n\u0002\u0010\u0000\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0006\u0010\u001c\u001a\u00020\u001dR \u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001c\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u001c\u0010\u0010\u001a\u0004\u0018\u00010\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\r\"\u0004\b\u0012\u0010\u000fR\u001c\u0010\u0013\u001a\u0004\u0018\u00010\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\r\"\u0004\b\u0015\u0010\u000fR\u001c\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0019\"\u0004\b\u001a\u0010\u001b¨\u0006\u001e"},
      d2 = {"Ldev/falsehonesty/asmhelper/dsl/writers/FieldWriter$Builder;", "Ldev/falsehonesty/asmhelper/dsl/AsmWriter$AsmWriterBuilder;", "()V", "accessTypes", "", "Ldev/falsehonesty/asmhelper/dsl/writers/AccessType;", "getAccessTypes", "()Ljava/util/List;", "setAccessTypes", "(Ljava/util/List;)V", "className", "", "getClassName", "()Ljava/lang/String;", "setClassName", "(Ljava/lang/String;)V", "fieldDesc", "getFieldDesc", "setFieldDesc", "fieldName", "getFieldName", "setFieldName", "initialValue", "", "getInitialValue", "()Ljava/lang/Object;", "setInitialValue", "(Ljava/lang/Object;)V", "build", "Ldev/falsehonesty/asmhelper/dsl/AsmWriter;", "AsmHelper1.8.9"}
   )
   public static final class Builder extends AsmWriter.AsmWriterBuilder {
      @Nullable
      private String className;
      @NotNull
      private List<? extends AccessType> accessTypes;
      @Nullable
      private String fieldName;
      @Nullable
      private String fieldDesc;
      @Nullable
      private Object initialValue;

      public Builder() {
         boolean var1 = false;
         this.accessTypes = CollectionsKt.emptyList();
      }

      @Nullable
      public final String getClassName() {
         return this.className;
      }

      public final void setClassName(@Nullable String var1) {
         this.className = var1;
      }

      @NotNull
      public final List<AccessType> getAccessTypes() {
         return this.accessTypes;
      }

      public final void setAccessTypes(@NotNull List<? extends AccessType> var1) {
         Intrinsics.checkNotNullParameter(var1, "<set-?>");
         this.accessTypes = var1;
      }

      @Nullable
      public final String getFieldName() {
         return this.fieldName;
      }

      public final void setFieldName(@Nullable String var1) {
         this.fieldName = var1;
      }

      @Nullable
      public final String getFieldDesc() {
         return this.fieldDesc;
      }

      public final void setFieldDesc(@Nullable String var1) {
         this.fieldDesc = var1;
      }

      @Nullable
      public final Object getInitialValue() {
         return this.initialValue;
      }

      public final void setInitialValue(@Nullable Object var1) {
         this.initialValue = var1;
      }

      @NotNull
      public final AsmWriter build() throws IllegalStateException {
         FieldWriter var10000 = new FieldWriter;
         String var1 = this.className;
         if (var1 == null) {
            throw new IllegalStateException("className must not be null");
         } else {
            String var10002 = var1;
            var1 = this.fieldName;
            if (var1 == null) {
               throw new IllegalStateException("fieldName must not be null");
            } else {
               String var10003 = var1;
               var1 = this.fieldDesc;
               if (var1 == null) {
                  throw new IllegalStateException("fieldDesc must not be null");
               } else {
                  var10000.<init>(var10002, var10003, var1, this.initialValue, this.accessTypes);
                  return (AsmWriter)var10000;
               }
            }
         }
      }
   }
}
