package dev.falsehonesty.asmhelper.dsl.writers;

import dev.falsehonesty.asmhelper.AsmHelper;
import dev.falsehonesty.asmhelper.dsl.AsmWriter;
import dev.falsehonesty.asmhelper.dsl.At;
import dev.falsehonesty.asmhelper.remapping.Remapper;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010$\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0015BA\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0012\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u000b¢\u0006\u0002\u0010\fJ\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\b\u0010\u0011\u001a\u00020\u0003H\u0016J\u0010\u0010\u0012\u001a\u00020\u000e2\u0006\u0010\u0013\u001a\u00020\u0014H\u0016R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0016"},
   d2 = {"Ldev/falsehonesty/asmhelper/dsl/writers/RemoveWriter;", "Ldev/falsehonesty/asmhelper/dsl/AsmWriter;", "className", "", "methodName", "methodDesc", "at", "Ldev/falsehonesty/asmhelper/dsl/At;", "numberToRemove", "", "methodMaps", "", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ldev/falsehonesty/asmhelper/dsl/At;ILjava/util/Map;)V", "removeInsns", "", "method", "Lorg/objectweb/asm/tree/MethodNode;", "toString", "transform", "classNode", "Lorg/objectweb/asm/tree/ClassNode;", "Builder", "AsmHelper1.8.9"}
)
public final class RemoveWriter extends AsmWriter {
   @NotNull
   private final String methodName;
   @NotNull
   private final String methodDesc;
   @NotNull
   private final At at;
   private final int numberToRemove;
   @NotNull
   private final Map<String, String> methodMaps;

   public RemoveWriter(@NotNull String className, @NotNull String methodName, @NotNull String methodDesc, @NotNull At at, int numberToRemove, @NotNull Map<String, String> methodMaps) {
      Intrinsics.checkNotNullParameter(className, "className");
      Intrinsics.checkNotNullParameter(methodName, "methodName");
      Intrinsics.checkNotNullParameter(methodDesc, "methodDesc");
      Intrinsics.checkNotNullParameter(at, "at");
      Intrinsics.checkNotNullParameter(methodMaps, "methodMaps");
      super(className);
      this.methodName = methodName;
      this.methodDesc = methodDesc;
      this.at = at;
      this.numberToRemove = numberToRemove;
      this.methodMaps = methodMaps;
   }

   public void transform(@NotNull ClassNode classNode) {
      Intrinsics.checkNotNullParameter(classNode, "classNode");
      List var3 = classNode.methods;
      Intrinsics.checkNotNullExpressionValue(var3, "classNode.methods");
      Iterable var14 = (Iterable)var3;
      boolean var4 = false;
      boolean var6 = false;
      Iterator var7 = var14.iterator();

      Object var16;
      while(true) {
         if (!var7.hasNext()) {
            var16 = null;
            break;
         }

         Object var8 = var7.next();
         MethodNode it = (MethodNode)var8;
         int var10 = false;
         Remapper var10000 = AsmHelper.INSTANCE.getRemapper();
         String remappedDesc = classNode.name;
         Intrinsics.checkNotNullExpressionValue(remappedDesc, "classNode.name");
         String var10001 = remappedDesc;
         remappedDesc = it.name;
         Intrinsics.checkNotNullExpressionValue(remappedDesc, "it.name");
         String var10002 = remappedDesc;
         remappedDesc = it.desc;
         Intrinsics.checkNotNullExpressionValue(remappedDesc, "it.desc");
         String remapped = var10000.remapMethodName(var10001, var10002, remappedDesc);
         var10000 = AsmHelper.INSTANCE.getRemapper();
         String var13 = it.desc;
         Intrinsics.checkNotNullExpressionValue(var13, "it.desc");
         remappedDesc = var10000.remapDesc(var13);
         if (Intrinsics.areEqual(remappedDesc, this.methodDesc) && (Intrinsics.areEqual(remapped, this.methodName) || Intrinsics.areEqual(this.methodMaps.get(remapped), this.methodName))) {
            var16 = var8;
            break;
         }
      }

      MethodNode var2 = (MethodNode)var16;
      if (var2 != null) {
         var4 = false;
         boolean var5 = false;
         int var15 = false;
         this.removeInsns(var2);
      }

   }

   private final void removeInsns(MethodNode method) {
      List nodes = this.at.getTargetedNodes(method);
      Iterable $this$forEach$iv = (Iterable)nodes;
      int $i$f$forEach = false;
      Iterator var5 = $this$forEach$iv.iterator();

      while(true) {
         while(var5.hasNext()) {
            Object element$iv = var5.next();
            AbstractInsnNode node = (AbstractInsnNode)element$iv;
            int var8 = false;
            Object toDelete = null;
            toDelete = node;
            int var10;
            boolean var11;
            boolean var12;
            int var13;
            boolean var15;
            AbstractInsnNode tmpNode;
            int var18;
            if (this.at.getShift() < 0) {
               var10 = -this.at.getShift();
               var11 = false;
               var12 = false;
               var18 = 0;

               for(var13 = var10; var18 < var13; ++var18) {
                  var15 = false;
                  tmpNode = toDelete.getPrevious();
                  Intrinsics.checkNotNullExpressionValue(tmpNode, "toDelete.previous");
                  toDelete = tmpNode;
               }
            } else if (this.at.getShift() > 0) {
               var10 = this.at.getShift();
               var11 = false;
               var12 = false;
               var18 = 0;

               for(var13 = var10; var18 < var13; ++var18) {
                  var15 = false;
                  tmpNode = toDelete.getNext();
                  Intrinsics.checkNotNullExpressionValue(tmpNode, "toDelete.next");
                  toDelete = tmpNode;
               }
            }

            var10 = this.numberToRemove;
            var11 = false;
            var12 = false;
            var18 = 0;

            for(var13 = var10; var18 < var13; ++var18) {
               var15 = false;
               tmpNode = toDelete.getNext();
               method.instructions.remove(toDelete);
               if (tmpNode == null) {
                  break;
               }

               toDelete = tmpNode;
            }
         }

         return;
      }
   }

   @NotNull
   public String toString() {
      return "RemoveWriter{className=" + this.getClassName() + ",at=" + this.at + ",numToRem=" + this.numberToRemove + '}';
   }

   @Metadata(
      mv = {1, 5, 1},
      k = 1,
      xi = 48,
      d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0010$\n\u0002\b\b\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0006\u0010!\u001a\u00020\"R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001c\u0010\t\u001a\u0004\u0018\u00010\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u001c\u0010\u000f\u001a\u0004\u0018\u00010\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\f\"\u0004\b\u0011\u0010\u000eR&\u0010\u0012\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n0\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u001c\u0010\u0018\u001a\u0004\u0018\u00010\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\f\"\u0004\b\u001a\u0010\u000eR\u001a\u0010\u001b\u001a\u00020\u001cX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u001e\"\u0004\b\u001f\u0010 ¨\u0006#"},
      d2 = {"Ldev/falsehonesty/asmhelper/dsl/writers/RemoveWriter$Builder;", "Ldev/falsehonesty/asmhelper/dsl/AsmWriter$AsmWriterBuilder;", "()V", "at", "Ldev/falsehonesty/asmhelper/dsl/At;", "getAt", "()Ldev/falsehonesty/asmhelper/dsl/At;", "setAt", "(Ldev/falsehonesty/asmhelper/dsl/At;)V", "className", "", "getClassName", "()Ljava/lang/String;", "setClassName", "(Ljava/lang/String;)V", "methodDesc", "getMethodDesc", "setMethodDesc", "methodMaps", "", "getMethodMaps", "()Ljava/util/Map;", "setMethodMaps", "(Ljava/util/Map;)V", "methodName", "getMethodName", "setMethodName", "numberToRemove", "", "getNumberToRemove", "()I", "setNumberToRemove", "(I)V", "build", "Ldev/falsehonesty/asmhelper/dsl/AsmWriter;", "AsmHelper1.8.9"}
   )
   public static final class Builder extends AsmWriter.AsmWriterBuilder {
      @Nullable
      private String className;
      @Nullable
      private String methodName;
      @Nullable
      private String methodDesc;
      @Nullable
      private At at;
      private int numberToRemove = 1;
      @NotNull
      private Map<String, String> methodMaps;

      public Builder() {
         boolean var1 = false;
         this.methodMaps = MapsKt.emptyMap();
      }

      @Nullable
      public final String getClassName() {
         return this.className;
      }

      public final void setClassName(@Nullable String var1) {
         this.className = var1;
      }

      @Nullable
      public final String getMethodName() {
         return this.methodName;
      }

      public final void setMethodName(@Nullable String var1) {
         this.methodName = var1;
      }

      @Nullable
      public final String getMethodDesc() {
         return this.methodDesc;
      }

      public final void setMethodDesc(@Nullable String var1) {
         this.methodDesc = var1;
      }

      @Nullable
      public final At getAt() {
         return this.at;
      }

      public final void setAt(@Nullable At var1) {
         this.at = var1;
      }

      public final int getNumberToRemove() {
         return this.numberToRemove;
      }

      public final void setNumberToRemove(int var1) {
         this.numberToRemove = var1;
      }

      @NotNull
      public final Map<String, String> getMethodMaps() {
         return this.methodMaps;
      }

      public final void setMethodMaps(@NotNull Map<String, String> var1) {
         Intrinsics.checkNotNullParameter(var1, "<set-?>");
         this.methodMaps = var1;
      }

      @NotNull
      public final AsmWriter build() throws IllegalStateException {
         RemoveWriter var10000 = new RemoveWriter;
         String var1 = this.className;
         if (var1 == null) {
            throw new IllegalStateException("className must NOT be null.");
         } else {
            String var10002 = var1;
            var1 = this.methodName;
            if (var1 == null) {
               throw new IllegalStateException("methodName must NOT be null.");
            } else {
               String var10003 = var1;
               var1 = this.methodDesc;
               if (var1 == null) {
                  throw new IllegalStateException("methodDesc must NOT be null.");
               } else {
                  String var10004 = var1;
                  At var2 = this.at;
                  if (var2 == null) {
                     throw new IllegalStateException("at must NOT be null.");
                  } else {
                     var10000.<init>(var10002, var10003, var10004, var2, this.numberToRemove, this.methodMaps);
                     return (AsmWriter)var10000;
                  }
               }
            }
         }
      }
   }
}
