package dev.falsehonesty.asmhelper.printing;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Iterator;
import java.util.ListIterator;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.util.Printer;
import org.objectweb.asm.util.Textifier;
import org.objectweb.asm.util.TraceMethodVisitor;

@Metadata(
   mv = {1, 5, 1},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u001a\b\u0010\u0004\u001a\u00020\u0005H\u0002\u001a\n\u0010\u0006\u001a\u00020\u0005*\u00020\u0007\u001a\n\u0010\u0006\u001a\u00020\u0005*\u00020\b\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\t"},
   d2 = {"methodTracer", "Lorg/objectweb/asm/util/TraceMethodVisitor;", "textifier", "Lorg/objectweb/asm/util/Textifier;", "textifierToString", "", "prettyString", "Lorg/objectweb/asm/tree/AbstractInsnNode;", "Lorg/objectweb/asm/tree/InsnList;", "AsmHelper1.8.9"}
)
public final class PrettyprintingKt {
   @NotNull
   private static final Textifier textifier = new Textifier();
   @NotNull
   private static final TraceMethodVisitor methodTracer;

   @NotNull
   public static final String prettyString(@NotNull InsnList $this$prettyString) {
      Intrinsics.checkNotNullParameter($this$prettyString, "<this>");
      ListIterator var1 = $this$prettyString.iterator();
      Intrinsics.checkNotNullExpressionValue(var1, "iterator()");
      Iterator $this$forEach$iv = (Iterator)var1;
      int $i$f$forEach = false;
      boolean var4 = false;
      Iterator var5 = $this$forEach$iv;

      while(var5.hasNext()) {
         Object element$iv = var5.next();
         AbstractInsnNode it = (AbstractInsnNode)element$iv;
         int var8 = false;
         it.accept((MethodVisitor)methodTracer);
      }

      return textifierToString();
   }

   @NotNull
   public static final String prettyString(@NotNull AbstractInsnNode $this$prettyString) {
      Intrinsics.checkNotNullParameter($this$prettyString, "<this>");
      $this$prettyString.accept((MethodVisitor)methodTracer);
      String var1 = textifierToString();
      boolean var2 = false;
      if (var1 == null) {
         throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
      } else {
         return StringsKt.trim((CharSequence)var1).toString();
      }
   }

   private static final String textifierToString() {
      StringWriter stringWriter = new StringWriter();
      textifier.print(new PrintWriter((Writer)stringWriter));
      textifier.getText().clear();
      String var1 = stringWriter.toString();
      Intrinsics.checkNotNullExpressionValue(var1, "stringWriter.toString()");
      return var1;
   }

   static {
      methodTracer = new TraceMethodVisitor((Printer)textifier);
   }
}
