package dev.falsehonesty.asmhelper.printing;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.LabelNode;

@Metadata(
   mv = {1, 5, 1},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001a\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u001a\n\u0010\u0000\u001a\u00020\u0001*\u00020\u0002\u001a\u001b\u0010\u0003\u001a\u0013\u0012\t\u0012\u00070\u0005¢\u0006\u0002\b\u0006\u0012\u0004\u0012\u00020\u00050\u0004*\u00020\u0002¨\u0006\u0007"},
   d2 = {"clone", "", "Lorg/objectweb/asm/tree/InsnList;", "cloneLabels", "", "Lorg/objectweb/asm/tree/LabelNode;", "Lkotlin/internal/NoInfer;", "AsmHelper1.8.9"}
)
public final class CloningKt {
   public static final void clone(@NotNull InsnList $this$clone) {
      Intrinsics.checkNotNullParameter($this$clone, "<this>");
      InsnList var1 = new InsnList();
      boolean var2 = false;
      boolean var3 = false;
      InsnList list = var1;
      int var5 = false;
      Map labels = cloneLabels($this$clone);
      ListIterator var7 = $this$clone.iterator();
      Intrinsics.checkNotNullExpressionValue(var7, "this.iterator()");
      Iterator $this$forEach$iv = (Iterator)var7;
      int $i$f$forEach = false;
      boolean var10 = false;
      Iterator var11 = $this$forEach$iv;

      while(var11.hasNext()) {
         Object element$iv = var11.next();
         AbstractInsnNode it = (AbstractInsnNode)element$iv;
         int var14 = false;
         list.add(it.clone(labels));
      }

   }

   @NotNull
   public static final Map<LabelNode, LabelNode> cloneLabels(@NotNull InsnList $this$cloneLabels) {
      Intrinsics.checkNotNullParameter($this$cloneLabels, "<this>");
      AbstractInsnNode[] var1 = $this$cloneLabels.toArray();
      Intrinsics.checkNotNullExpressionValue(var1, "toArray()");
      Iterable $this$associateWith$iv = (Iterable)ArraysKt.toList((Object[])var1);
      int $i$f$associateWith = false;
      Collection destination$iv$iv = (Collection)(new ArrayList());
      int $i$f$associateWithTo = false;
      Iterator var6 = $this$associateWith$iv.iterator();

      Object element$iv$iv;
      while(var6.hasNext()) {
         element$iv$iv = var6.next();
         if (element$iv$iv instanceof LabelNode) {
            destination$iv$iv.add(element$iv$iv);
         }
      }

      $this$associateWith$iv = (Iterable)((List)destination$iv$iv);
      $i$f$associateWith = false;
      LinkedHashMap result$iv = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault($this$associateWith$iv, 10)), 16));
      $i$f$associateWithTo = false;
      var6 = $this$associateWith$iv.iterator();

      while(var6.hasNext()) {
         element$iv$iv = var6.next();
         Map var10000 = (Map)result$iv;
         LabelNode it = (LabelNode)element$iv$iv;
         Map var10 = var10000;
         int var9 = false;
         LabelNode var12 = new LabelNode();
         var10.put(element$iv$iv, var12);
      }

      return (Map)result$iv;
   }
}
