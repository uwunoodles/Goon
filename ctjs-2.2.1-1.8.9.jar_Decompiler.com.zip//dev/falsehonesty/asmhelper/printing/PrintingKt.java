package dev.falsehonesty.asmhelper.printing;

import dev.falsehonesty.asmhelper.AsmHelper;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 5, 1},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0018\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t\u001a\u000e\u0010\n\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u000b"},
   d2 = {"logger", "Lorg/apache/logging/log4j/Logger;", "getLogger", "()Lorg/apache/logging/log4j/Logger;", "log", "", "message", "", "level", "Ldev/falsehonesty/asmhelper/printing/LogLevel;", "verbose", "AsmHelper1.8.9"}
)
public final class PrintingKt {
   @NotNull
   private static final Logger logger;

   @NotNull
   public static final Logger getLogger() {
      return logger;
   }

   public static final void log(@NotNull String message, @NotNull LogLevel level) {
      Intrinsics.checkNotNullParameter(message, "message");
      Intrinsics.checkNotNullParameter(level, "level");
      if (level == LogLevel.NORMAL || AsmHelper.INSTANCE.getVerbose()) {
         logger.info(message);
      }

   }

   // $FF: synthetic method
   public static void log$default(String var0, LogLevel var1, int var2, Object var3) {
      if ((var2 & 2) != 0) {
         var1 = LogLevel.NORMAL;
      }

      log(var0, var1);
   }

   public static final void verbose(@NotNull String message) {
      Intrinsics.checkNotNullParameter(message, "message");
      log(message, LogLevel.VERBOSE);
   }

   static {
      Logger var10000 = LogManager.getLogger("AsmHelper");
      Intrinsics.checkNotNull(var10000);
      logger = var10000;
   }
}
