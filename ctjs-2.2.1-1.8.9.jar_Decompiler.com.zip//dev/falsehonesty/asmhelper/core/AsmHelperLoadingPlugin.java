package dev.falsehonesty.asmhelper.core;

import dev.falsehonesty.asmhelper.AsmHelper;
import dev.falsehonesty.asmhelper.ClassTransformationService;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ServiceLoader;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010%\n\u0002\u0010\u0000\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0013\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004H\u0016¢\u0006\u0002\u0010\u0006J\n\u0010\u0007\u001a\u0004\u0018\u00010\u0005H\u0016J\n\u0010\b\u001a\u0004\u0018\u00010\u0005H\u0016J\n\u0010\t\u001a\u0004\u0018\u00010\u0005H\u0016J\u001e\u0010\n\u001a\u00020\u000b2\u0014\u0010\f\u001a\u0010\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000e\u0018\u00010\rH\u0016¨\u0006\u000f"},
   d2 = {"Ldev/falsehonesty/asmhelper/core/AsmHelperLoadingPlugin;", "Lnet/minecraftforge/fml/relauncher/IFMLLoadingPlugin;", "()V", "getASMTransformerClass", "", "", "()[Ljava/lang/String;", "getAccessTransformerClass", "getModContainerClass", "getSetupClass", "injectData", "", "data", "", "", "AsmHelper1.8.9"}
)
public final class AsmHelperLoadingPlugin implements IFMLLoadingPlugin {
   @NotNull
   public String[] getASMTransformerClass() {
      ServiceLoader var1 = AsmHelper.INSTANCE.getServiceLoader$AsmHelper1_8_9();
      Intrinsics.checkNotNullExpressionValue(var1, "AsmHelper.serviceLoader");
      Iterable $this$flatMap$iv = (Iterable)var1;
      int $i$f$toTypedArray = false;
      Collection destination$iv$iv = (Collection)(new ArrayList());
      int $i$f$flatMapTo = false;
      Iterator var6 = $this$flatMap$iv.iterator();

      while(var6.hasNext()) {
         Object element$iv$iv = var6.next();
         ClassTransformationService it = (ClassTransformationService)element$iv$iv;
         int var9 = false;
         Iterable list$iv$iv = (Iterable)it.transformerClasses();
         CollectionsKt.addAll(destination$iv$iv, list$iv$iv);
      }

      Collection $this$toTypedArray$iv = (Collection)((List)destination$iv$iv);
      $i$f$toTypedArray = false;
      Object[] var10000 = $this$toTypedArray$iv.toArray(new String[0]);
      if (var10000 == null) {
         throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
      } else {
         return (String[])var10000;
      }
   }

   @Nullable
   public String getModContainerClass() {
      return null;
   }

   @Nullable
   public String getSetupClass() {
      return null;
   }

   public void injectData(@Nullable Map<String, Object> data) {
   }

   @Nullable
   public String getAccessTransformerClass() {
      return null;
   }
}
