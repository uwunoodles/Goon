package dev.falsehonesty.asmhelper.remapping;

import dev.falsehonesty.asmhelper.dsl.instructions.Descriptor;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0006\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0003H\u0016J\u0010\u0010\u0005\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0003H\u0016J\u0010\u0010\u0007\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\u0003H&J\u0010\u0010\t\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u0003H&J\u0010\u0010\u000b\u001a\u00020\u00032\u0006\u0010\f\u001a\u00020\rH&J \u0010\u000b\u001a\u00020\u00032\u0006\u0010\u000e\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u0003H\u0016J\u0010\u0010\u0010\u001a\u00020\u00032\u0006\u0010\u0011\u001a\u00020\rH&J \u0010\u0010\u001a\u00020\u00032\u0006\u0010\u000e\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0012\u001a\u00020\u0003H\u0016¨\u0006\u0013"},
   d2 = {"Ldev/falsehonesty/asmhelper/remapping/Remapper;", "", "mapFieldAccess", "", "fieldName", "mapInvocation", "methodName", "remapClassName", "className", "remapDesc", "desc", "remapFieldName", "fieldDescriptor", "Ldev/falsehonesty/asmhelper/dsl/instructions/Descriptor;", "owner", "fieldDesc", "remapMethodName", "methodDescriptor", "methodDesc", "AsmHelper1.8.9"}
)
public interface Remapper {
   @NotNull
   String remapClassName(@NotNull String var1);

   @NotNull
   String remapMethodName(@NotNull String var1, @NotNull String var2, @NotNull String var3);

   @NotNull
   String remapMethodName(@NotNull Descriptor var1);

   @NotNull
   String remapFieldName(@NotNull String var1, @NotNull String var2, @NotNull String var3);

   @NotNull
   String remapFieldName(@NotNull Descriptor var1);

   @NotNull
   String remapDesc(@NotNull String var1);

   @NotNull
   String mapInvocation(@NotNull String var1);

   @NotNull
   String mapFieldAccess(@NotNull String var1);

   @Metadata(
      mv = {1, 5, 1},
      k = 3,
      xi = 48
   )
   public static final class DefaultImpls {
      @NotNull
      public static String remapMethodName(@NotNull Remapper var0, @NotNull String owner, @NotNull String methodName, @NotNull String methodDesc) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(owner, "owner");
         Intrinsics.checkNotNullParameter(methodName, "methodName");
         Intrinsics.checkNotNullParameter(methodDesc, "methodDesc");
         return var0.remapMethodName(new Descriptor(owner, methodName, methodDesc));
      }

      @NotNull
      public static String remapFieldName(@NotNull Remapper var0, @NotNull String owner, @NotNull String fieldName, @NotNull String fieldDesc) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(owner, "owner");
         Intrinsics.checkNotNullParameter(fieldName, "fieldName");
         Intrinsics.checkNotNullParameter(fieldDesc, "fieldDesc");
         return var0.remapFieldName(new Descriptor(owner, fieldName, fieldDesc));
      }

      @NotNull
      public static String mapInvocation(@NotNull Remapper var0, @NotNull String methodName) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(methodName, "methodName");
         return methodName;
      }

      @NotNull
      public static String mapFieldAccess(@NotNull Remapper var0, @NotNull String fieldName) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(fieldName, "fieldName");
         return fieldName;
      }
   }
}
