package dev.falsehonesty.asmhelper.remapping;

import dev.falsehonesty.asmhelper.dsl.instructions.Descriptor;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.NotImplementedError;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010%\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u0005H\u0016J\u0010\u0010\u000b\u001a\u00020\u00052\u0006\u0010\f\u001a\u00020\u0005H\u0016J\u0010\u0010\r\u001a\u00020\u00052\u0006\u0010\u000e\u001a\u00020\u0007H\u0016J\u0010\u0010\u000f\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\u0007H\u0016R\u001a\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00070\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00070\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0011"},
   d2 = {"Ldev/falsehonesty/asmhelper/remapping/NotchRemapper;", "Ldev/falsehonesty/asmhelper/remapping/Remapper;", "()V", "classMappings", "", "", "fieldMappings", "Ldev/falsehonesty/asmhelper/dsl/instructions/Descriptor;", "methodMappings", "remapClassName", "className", "remapDesc", "desc", "remapFieldName", "fieldDescriptor", "remapMethodName", "methodDescriptor", "AsmHelper1.8.9"}
)
public final class NotchRemapper implements Remapper {
   @NotNull
   private final Map<String, String> classMappings;
   @NotNull
   private final Map<Descriptor, Descriptor> fieldMappings;
   @NotNull
   private final Map<Descriptor, Descriptor> methodMappings;

   public NotchRemapper() {
      boolean var1 = false;
      this.classMappings = (Map)(new LinkedHashMap());
      var1 = false;
      this.fieldMappings = (Map)(new LinkedHashMap());
      var1 = false;
      this.methodMappings = (Map)(new LinkedHashMap());
      URL var2 = this.getClass().getResource("/mcp-notch.srg");
      Intrinsics.checkNotNullExpressionValue(var2, "javaClass.getResource(\"/mcp-notch.srg\")");
      Charset var3 = Charsets.UTF_8;
      boolean var4 = false;
      byte[] var5 = TextStreamsKt.readBytes(var2);
      boolean var6 = false;
      boolean var7 = false;
      String mappings = new String(var5, var3);
      CharSequence var10000 = (CharSequence)mappings;
      String[] var20 = new String[]{"\n"};
      Iterable $this$forEach$iv = (Iterable)StringsKt.split$default(var10000, var20, false, 0, 6, (Object)null);
      int $i$f$forEach = false;
      Iterator var23 = $this$forEach$iv.iterator();

      while(var23.hasNext()) {
         Object element$iv = var23.next();
         String it = (String)element$iv;
         var7 = false;
         String[] var8;
         byte var9;
         boolean var10;
         List var11;
         boolean var12;
         String deobf;
         String obf;
         String var46;
         if (StringsKt.startsWith$default(it, "CL: ", false, 2, (Object)null)) {
            var9 = 4;
            var10 = false;
            if (it == null) {
               throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }

            var46 = it.substring(var9);
            Intrinsics.checkNotNullExpressionValue(var46, "(this as java.lang.String).substring(startIndex)");
            var10000 = (CharSequence)var46;
            var8 = new String[]{" "};
            var11 = StringsKt.split$default(var10000, var8, false, 0, 6, (Object)null);
            var10 = false;
            deobf = (String)var11.get(0);
            var12 = false;
            obf = (String)var11.get(1);
            Map var28 = this.classMappings;
            var12 = false;
            var28.put(deobf, obf);
         } else {
            boolean var16;
            String var10002;
            String var10003;
            boolean var36;
            int var39;
            Descriptor var47;
            if (StringsKt.startsWith$default(it, "FD: ", false, 2, (Object)null)) {
               var9 = 4;
               var10 = false;
               if (it == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
               }

               var46 = it.substring(var9);
               Intrinsics.checkNotNullExpressionValue(var46, "(this as java.lang.String).substring(startIndex)");
               var10000 = (CharSequence)var46;
               var8 = new String[]{" "};
               var11 = StringsKt.split$default(var10000, var8, false, 0, 6, (Object)null);
               var10 = false;
               deobf = (String)var11.get(0);
               var12 = false;
               obf = (String)var11.get(1);
               var47 = new Descriptor;
               byte var13 = 0;
               int var14 = StringsKt.lastIndexOf$default((CharSequence)deobf, "/", 0, false, 6, (Object)null);
               boolean var15 = false;
               if (deobf == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
               }

               var10002 = deobf.substring(var13, var14);
               Intrinsics.checkNotNullExpressionValue(var10002, "(this as java.lang.Strin…ing(startIndex, endIndex)");
               int var32 = StringsKt.lastIndexOf$default((CharSequence)deobf, "/", 0, false, 6, (Object)null) + 1;
               var36 = false;
               if (deobf == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
               }

               var10003 = deobf.substring(var32);
               Intrinsics.checkNotNullExpressionValue(var10003, "(this as java.lang.String).substring(startIndex)");
               var47.<init>(var10002, var10003, "");
               Descriptor deobfDescriptor = var47;
               var47 = new Descriptor;
               byte var38 = 0;
               var39 = StringsKt.lastIndexOf$default((CharSequence)obf, "/", 0, false, 6, (Object)null);
               var16 = false;
               if (obf == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
               }

               var10002 = obf.substring(var38, var39);
               Intrinsics.checkNotNullExpressionValue(var10002, "(this as java.lang.Strin…ing(startIndex, endIndex)");
               var14 = StringsKt.lastIndexOf$default((CharSequence)obf, "/", 0, false, 6, (Object)null) + 1;
               var15 = false;
               if (obf == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
               }

               var10003 = obf.substring(var14);
               Intrinsics.checkNotNullExpressionValue(var10003, "(this as java.lang.String).substring(startIndex)");
               var47.<init>(var10002, var10003, "");
               Descriptor obfDescriptor = var47;
               Map var34 = this.fieldMappings;
               var36 = false;
               var34.put(deobfDescriptor, obfDescriptor);
            } else if (StringsKt.startsWith$default(it, "MD: ", false, 2, (Object)null)) {
               var9 = 4;
               var10 = false;
               if (it == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
               }

               var46 = it.substring(var9);
               Intrinsics.checkNotNullExpressionValue(var46, "(this as java.lang.String).substring(startIndex)");
               var10000 = (CharSequence)var46;
               var8 = new String[]{" "};
               var11 = StringsKt.split$default(var10000, var8, false, 0, 6, (Object)null);
               var10 = false;
               deobf = (String)var11.get(0);
               var12 = false;
               obf = (String)var11.get(1);
               boolean var35 = false;
               String obf = (String)var11.get(2);
               var36 = false;
               String obfDesc = (String)var11.get(3);
               var47 = new Descriptor;
               byte var40 = 0;
               int var42 = StringsKt.lastIndexOf$default((CharSequence)deobf, "/", 0, false, 6, (Object)null);
               boolean var17 = false;
               if (deobf == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
               }

               var10002 = deobf.substring(var40, var42);
               Intrinsics.checkNotNullExpressionValue(var10002, "(this as java.lang.Strin…ing(startIndex, endIndex)");
               var39 = StringsKt.lastIndexOf$default((CharSequence)deobf, "/", 0, false, 6, (Object)null) + 1;
               var16 = false;
               if (deobf == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
               }

               var10003 = deobf.substring(var39);
               Intrinsics.checkNotNullExpressionValue(var10003, "(this as java.lang.String).substring(startIndex)");
               var47.<init>(var10002, var10003, obf);
               Descriptor deobfDescriptor = var47;
               var47 = new Descriptor;
               byte var44 = 0;
               int var45 = StringsKt.lastIndexOf$default((CharSequence)obf, "/", 0, false, 6, (Object)null);
               boolean var18 = false;
               if (obf == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
               }

               var10002 = obf.substring(var44, var45);
               Intrinsics.checkNotNullExpressionValue(var10002, "(this as java.lang.Strin…ing(startIndex, endIndex)");
               var42 = StringsKt.lastIndexOf$default((CharSequence)obf, "/", 0, false, 6, (Object)null) + 1;
               var17 = false;
               if (obf == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
               }

               var10003 = obf.substring(var42);
               Intrinsics.checkNotNullExpressionValue(var10003, "(this as java.lang.String).substring(startIndex)");
               var47.<init>(var10002, var10003, obfDesc);
               Descriptor obfDescriptor = var47;
               Map var43 = this.methodMappings;
               var16 = false;
               var43.put(deobfDescriptor, obfDescriptor);
            }
         }
      }

   }

   @NotNull
   public String remapClassName(@NotNull String className) {
      Intrinsics.checkNotNullParameter(className, "className");
      String var2 = (String)this.classMappings.get(className);
      return var2 == null ? className : var2;
   }

   @NotNull
   public String remapMethodName(@NotNull Descriptor methodDescriptor) {
      Intrinsics.checkNotNullParameter(methodDescriptor, "methodDescriptor");
      Descriptor var3 = (Descriptor)this.methodMappings.get(methodDescriptor);
      String var2 = var3 == null ? null : var3.getName();
      return var2 == null ? methodDescriptor.getName() : var2;
   }

   @NotNull
   public String remapFieldName(@NotNull Descriptor fieldDescriptor) {
      Intrinsics.checkNotNullParameter(fieldDescriptor, "fieldDescriptor");
      Descriptor var3 = (Descriptor)this.fieldMappings.get(Descriptor.copy$default(fieldDescriptor, (String)null, (String)null, "", 3, (Object)null));
      String var2 = var3 == null ? null : var3.getName();
      return var2 == null ? fieldDescriptor.getName() : var2;
   }

   @NotNull
   public String remapDesc(@NotNull String desc) {
      Intrinsics.checkNotNullParameter(desc, "desc");
      String var2 = "Not yet implemented";
      boolean var3 = false;
      throw (Throwable)(new NotImplementedError("An operation is not implemented: " + var2));
   }

   @NotNull
   public String mapFieldAccess(@NotNull String fieldName) {
      return Remapper.DefaultImpls.mapFieldAccess(this, fieldName);
   }

   @NotNull
   public String mapInvocation(@NotNull String methodName) {
      return Remapper.DefaultImpls.mapInvocation(this, methodName);
   }

   @NotNull
   public String remapFieldName(@NotNull String owner, @NotNull String fieldName, @NotNull String fieldDesc) {
      return Remapper.DefaultImpls.remapFieldName(this, owner, fieldName, fieldDesc);
   }

   @NotNull
   public String remapMethodName(@NotNull String owner, @NotNull String methodName, @NotNull String methodDesc) {
      return Remapper.DefaultImpls.remapMethodName(this, owner, methodName, methodDesc);
   }
}
