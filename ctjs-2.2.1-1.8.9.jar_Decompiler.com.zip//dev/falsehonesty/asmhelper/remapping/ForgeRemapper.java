package dev.falsehonesty.asmhelper.remapping;

import dev.falsehonesty.asmhelper.AsmHelper;
import dev.falsehonesty.asmhelper.dsl.instructions.Descriptor;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraftforge.fml.common.asm.transformers.deobf.FMLDeobfuscatingRemapper;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004H\u0016J\u0010\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0004H\u0016J\u0010\u0010\b\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\u0004H\u0016J\u0010\u0010\n\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\u0004H\u0016J\u0010\u0010\f\u001a\u00020\u00042\u0006\u0010\r\u001a\u00020\u000eH\u0016J\u0010\u0010\u000f\u001a\u00020\u00042\u0006\u0010\u0010\u001a\u00020\u000eH\u0016¨\u0006\u0011"},
   d2 = {"Ldev/falsehonesty/asmhelper/remapping/ForgeRemapper;", "Ldev/falsehonesty/asmhelper/remapping/Remapper;", "()V", "mapFieldAccess", "", "fieldName", "mapInvocation", "methodName", "remapClassName", "className", "remapDesc", "desc", "remapFieldName", "fieldDescriptor", "Ldev/falsehonesty/asmhelper/dsl/instructions/Descriptor;", "remapMethodName", "methodDescriptor", "AsmHelper1.8.9"}
)
public final class ForgeRemapper implements Remapper {
   @NotNull
   public String remapClassName(@NotNull String className) {
      Intrinsics.checkNotNullParameter(className, "className");
      String var2 = FMLDeobfuscatingRemapper.INSTANCE.map(className);
      Intrinsics.checkNotNullExpressionValue(var2, "INSTANCE.map(className)");
      return var2;
   }

   @NotNull
   public String remapMethodName(@NotNull Descriptor methodDescriptor) {
      Intrinsics.checkNotNullParameter(methodDescriptor, "methodDescriptor");
      String var2 = FMLDeobfuscatingRemapper.INSTANCE.mapMethodName(methodDescriptor.getOwner(), methodDescriptor.getName(), methodDescriptor.getDesc());
      Intrinsics.checkNotNullExpressionValue(var2, "INSTANCE.mapMethodName(\n            methodDescriptor.owner,\n            methodDescriptor.name,\n            methodDescriptor.desc\n        )");
      return var2;
   }

   @NotNull
   public String remapFieldName(@NotNull Descriptor fieldDescriptor) {
      Intrinsics.checkNotNullParameter(fieldDescriptor, "fieldDescriptor");
      String var2 = FMLDeobfuscatingRemapper.INSTANCE.mapFieldName(fieldDescriptor.getOwner(), fieldDescriptor.getName(), fieldDescriptor.getDesc());
      Intrinsics.checkNotNullExpressionValue(var2, "INSTANCE.mapFieldName(\n            fieldDescriptor.owner,\n            fieldDescriptor.name,\n            fieldDescriptor.desc\n        )");
      return var2;
   }

   @NotNull
   public String mapInvocation(@NotNull String methodName) {
      Intrinsics.checkNotNullParameter(methodName, "methodName");
      return (String)AsmHelper.INSTANCE.getMethodMaps$AsmHelper1_8_9().getOrDefault(methodName, methodName);
   }

   @NotNull
   public String mapFieldAccess(@NotNull String fieldName) {
      Intrinsics.checkNotNullParameter(fieldName, "fieldName");
      return (String)AsmHelper.INSTANCE.getFieldMaps$AsmHelper1_8_9().getOrDefault(fieldName, fieldName);
   }

   @NotNull
   public String remapDesc(@NotNull String desc) {
      Intrinsics.checkNotNullParameter(desc, "desc");
      String var2 = FMLDeobfuscatingRemapper.INSTANCE.mapMethodDesc(desc);
      Intrinsics.checkNotNullExpressionValue(var2, "INSTANCE.mapMethodDesc(desc)");
      return var2;
   }

   @NotNull
   public String remapFieldName(@NotNull String owner, @NotNull String fieldName, @NotNull String fieldDesc) {
      return Remapper.DefaultImpls.remapFieldName(this, owner, fieldName, fieldDesc);
   }

   @NotNull
   public String remapMethodName(@NotNull String owner, @NotNull String methodName, @NotNull String methodDesc) {
      return Remapper.DefaultImpls.remapMethodName(this, owner, methodName, methodDesc);
   }
}
