package dev.falsehonesty.asmhelper.remapping;

import dev.falsehonesty.asmhelper.dsl.instructions.Descriptor;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 5, 1},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004H\u0016J\u0010\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0004H\u0016J\u0010\u0010\b\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\nH\u0016J\u0010\u0010\u000b\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\nH\u0016¨\u0006\r"},
   d2 = {"Ldev/falsehonesty/asmhelper/remapping/DeobfRemapper;", "Ldev/falsehonesty/asmhelper/remapping/Remapper;", "()V", "remapClassName", "", "className", "remapDesc", "desc", "remapFieldName", "fieldDescriptor", "Ldev/falsehonesty/asmhelper/dsl/instructions/Descriptor;", "remapMethodName", "methodDescriptor", "AsmHelper1.8.9"}
)
public final class DeobfRemapper implements Remapper {
   @NotNull
   public String remapClassName(@NotNull String className) {
      Intrinsics.checkNotNullParameter(className, "className");
      return className;
   }

   @NotNull
   public String remapMethodName(@NotNull Descriptor methodDescriptor) {
      Intrinsics.checkNotNullParameter(methodDescriptor, "methodDescriptor");
      return methodDescriptor.getName();
   }

   @NotNull
   public String remapFieldName(@NotNull Descriptor fieldDescriptor) {
      Intrinsics.checkNotNullParameter(fieldDescriptor, "fieldDescriptor");
      return fieldDescriptor.getName();
   }

   @NotNull
   public String remapDesc(@NotNull String desc) {
      Intrinsics.checkNotNullParameter(desc, "desc");
      return desc;
   }

   @NotNull
   public String mapFieldAccess(@NotNull String fieldName) {
      return Remapper.DefaultImpls.mapFieldAccess(this, fieldName);
   }

   @NotNull
   public String mapInvocation(@NotNull String methodName) {
      return Remapper.DefaultImpls.mapInvocation(this, methodName);
   }

   @NotNull
   public String remapFieldName(@NotNull String owner, @NotNull String fieldName, @NotNull String fieldDesc) {
      return Remapper.DefaultImpls.remapFieldName(this, owner, fieldName, fieldDesc);
   }

   @NotNull
   public String remapMethodName(@NotNull String owner, @NotNull String methodName, @NotNull String methodDesc) {
      return Remapper.DefaultImpls.remapMethodName(this, owner, methodName, methodDesc);
   }
}
