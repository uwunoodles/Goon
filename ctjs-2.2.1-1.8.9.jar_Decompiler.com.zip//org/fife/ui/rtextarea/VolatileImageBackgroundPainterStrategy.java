package org.fife.ui.rtextarea;

import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.awt.image.VolatileImage;

public class VolatileImageBackgroundPainterStrategy extends ImageBackgroundPainterStrategy {
   private VolatileImage bgImage;

   public VolatileImageBackgroundPainterStrategy(RTextAreaBase ta) {
      super(ta);
   }

   protected void paintImage(Graphics g, int x, int y) {
      if (this.bgImage != null) {
         do {
            int rc = this.bgImage.validate((GraphicsConfiguration)null);
            if (rc == 1) {
               this.renderImage(this.bgImage.getWidth(), this.bgImage.getHeight(), this.getScalingHint());
            }

            g.drawImage(this.bgImage, x, y, (ImageObserver)null);
         } while(this.bgImage.contentsLost());
      }

   }

   private void renderImage(int width, int height, int hint) {
      Image master = this.getMasterImage();
      if (master == null) {
         this.bgImage = null;
      } else {
         do {
            Image i = master.getScaledInstance(width, height, hint);
            this.tracker.addImage(i, 1);

            label123: {
               try {
                  this.tracker.waitForID(1);
                  break label123;
               } catch (InterruptedException var19) {
                  var19.printStackTrace();
                  this.bgImage = null;
               } finally {
                  this.tracker.removeImage(i, 1);
               }

               return;
            }

            this.bgImage.getGraphics().drawImage(i, 0, 0, (ImageObserver)null);
            this.tracker.addImage(this.bgImage, 0);

            try {
               this.tracker.waitForID(0);
               continue;
            } catch (InterruptedException var17) {
               var17.printStackTrace();
               this.bgImage = null;
            } finally {
               this.tracker.removeImage(this.bgImage, 0);
            }

            return;
         } while(this.bgImage.contentsLost());
      }

   }

   protected void rescaleImage(int width, int height, int hint) {
      this.bgImage = this.getRTextAreaBase().createVolatileImage(width, height);
      if (this.bgImage != null) {
         this.renderImage(width, height, hint);
      }

   }
}
