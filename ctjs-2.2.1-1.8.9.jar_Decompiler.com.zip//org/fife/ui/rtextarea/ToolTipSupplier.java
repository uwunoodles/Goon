package org.fife.ui.rtextarea;

import java.awt.event.MouseEvent;

public interface ToolTipSupplier {
   String getToolTipText(RTextArea var1, MouseEvent var2);
}
