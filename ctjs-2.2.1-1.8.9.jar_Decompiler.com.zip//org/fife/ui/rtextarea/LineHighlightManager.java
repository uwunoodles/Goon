package org.fife.ui.rtextarea;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import javax.swing.text.BadLocationException;
import javax.swing.text.Position;

class LineHighlightManager {
   private RTextArea textArea;
   private List<LineHighlightManager.LineHighlightInfo> lineHighlights;
   private LineHighlightManager.LineHighlightInfoComparator comparator;

   LineHighlightManager(RTextArea textArea) {
      this.textArea = textArea;
      this.comparator = new LineHighlightManager.LineHighlightInfoComparator();
   }

   public Object addLineHighlight(int line, Color color) throws BadLocationException {
      int offs = this.textArea.getLineStartOffset(line);
      LineHighlightManager.LineHighlightInfo lhi = new LineHighlightManager.LineHighlightInfo(this.textArea.getDocument().createPosition(offs), color);
      if (this.lineHighlights == null) {
         this.lineHighlights = new ArrayList(1);
      }

      int index = Collections.binarySearch(this.lineHighlights, lhi, this.comparator);
      if (index < 0) {
         index = -(index + 1);
      }

      this.lineHighlights.add(index, lhi);
      this.repaintLine(lhi);
      return lhi;
   }

   protected List<Object> getCurrentLineHighlightTags() {
      return (List)(this.lineHighlights == null ? Collections.emptyList() : new ArrayList(this.lineHighlights));
   }

   protected int getLineHighlightCount() {
      return this.lineHighlights == null ? 0 : this.lineHighlights.size();
   }

   public void paintLineHighlights(Graphics g) {
      int count = this.lineHighlights == null ? 0 : this.lineHighlights.size();
      if (count > 0) {
         int docLen = this.textArea.getDocument().getLength();
         Rectangle vr = this.textArea.getVisibleRect();
         int lineHeight = this.textArea.getLineHeight();

         try {
            for(int i = 0; i < count; ++i) {
               LineHighlightManager.LineHighlightInfo lhi = (LineHighlightManager.LineHighlightInfo)this.lineHighlights.get(i);
               int offs = lhi.getOffset();
               if (offs >= 0 && offs <= docLen) {
                  int y = this.textArea.yForLineContaining(offs);
                  if (y > vr.y - lineHeight) {
                     if (y >= vr.y + vr.height) {
                        break;
                     }

                     g.setColor(lhi.getColor());
                     g.fillRect(0, y, this.textArea.getWidth(), lineHeight);
                  }
               }
            }
         } catch (BadLocationException var10) {
            var10.printStackTrace();
         }
      }

   }

   public void removeAllLineHighlights() {
      if (this.lineHighlights != null) {
         this.lineHighlights.clear();
         this.textArea.repaint();
      }

   }

   public void removeLineHighlight(Object tag) {
      if (tag instanceof LineHighlightManager.LineHighlightInfo) {
         this.lineHighlights.remove(tag);
         this.repaintLine((LineHighlightManager.LineHighlightInfo)tag);
      }

   }

   private void repaintLine(LineHighlightManager.LineHighlightInfo lhi) {
      int offs = lhi.getOffset();
      if (offs >= 0 && offs <= this.textArea.getDocument().getLength()) {
         try {
            int y = this.textArea.yForLineContaining(offs);
            if (y > -1) {
               this.textArea.repaint(0, y, this.textArea.getWidth(), this.textArea.getLineHeight());
            }
         } catch (BadLocationException var4) {
            var4.printStackTrace();
         }
      }

   }

   private static class LineHighlightInfoComparator implements Comparator<LineHighlightManager.LineHighlightInfo> {
      private LineHighlightInfoComparator() {
      }

      public int compare(LineHighlightManager.LineHighlightInfo lhi1, LineHighlightManager.LineHighlightInfo lhi2) {
         if (lhi1.getOffset() < lhi2.getOffset()) {
            return -1;
         } else {
            return lhi1.getOffset() == lhi2.getOffset() ? 0 : 1;
         }
      }

      // $FF: synthetic method
      LineHighlightInfoComparator(Object x0) {
         this();
      }
   }

   private static class LineHighlightInfo {
      private Position offs;
      private Color color;

      LineHighlightInfo(Position offs, Color c) {
         this.offs = offs;
         this.color = c;
      }

      public boolean equals(Object other) {
         if (!(other instanceof LineHighlightManager.LineHighlightInfo)) {
            return false;
         } else {
            LineHighlightManager.LineHighlightInfo lhi2 = (LineHighlightManager.LineHighlightInfo)other;
            return this.getOffset() == lhi2.getOffset() && Objects.equals(this.getColor(), lhi2.getColor());
         }
      }

      public Color getColor() {
         return this.color;
      }

      public int getOffset() {
         return this.offs.getOffset();
      }

      public int hashCode() {
         return this.getOffset();
      }
   }
}
