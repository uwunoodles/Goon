package org.fife.ui.rtextarea;

import java.util.ResourceBundle;
import javax.swing.Action;
import javax.swing.UIManager;
import javax.swing.event.UndoableEditEvent;
import javax.swing.undo.CompoundEdit;
import javax.swing.undo.UndoManager;
import javax.swing.undo.UndoableEdit;

public class RUndoManager extends UndoManager {
   private RUndoManager.RCompoundEdit compoundEdit;
   private RTextArea textArea;
   private int lastOffset;
   private String cantUndoText;
   private String cantRedoText;
   private int internalAtomicEditDepth;
   private static final String MSG = "org.fife.ui.rtextarea.RTextArea";

   public RUndoManager(RTextArea textArea) {
      this.textArea = textArea;
      ResourceBundle msg = ResourceBundle.getBundle("org.fife.ui.rtextarea.RTextArea");
      this.cantUndoText = msg.getString("Action.CantUndo.Name");
      this.cantRedoText = msg.getString("Action.CantRedo.Name");
   }

   public void beginInternalAtomicEdit() {
      if (++this.internalAtomicEditDepth == 1) {
         if (this.compoundEdit != null) {
            this.compoundEdit.end();
         }

         this.compoundEdit = new RUndoManager.RCompoundEdit();
      }

   }

   public void endInternalAtomicEdit() {
      if (this.internalAtomicEditDepth > 0 && --this.internalAtomicEditDepth == 0) {
         this.addEdit(this.compoundEdit);
         this.compoundEdit.end();
         this.compoundEdit = null;
         this.updateActions();
      }

   }

   public String getCantRedoText() {
      return this.cantRedoText;
   }

   public String getCantUndoText() {
      return this.cantUndoText;
   }

   public void redo() {
      super.redo();
      this.updateActions();
   }

   private RUndoManager.RCompoundEdit startCompoundEdit(UndoableEdit edit) {
      this.lastOffset = this.textArea.getCaretPosition();
      this.compoundEdit = new RUndoManager.RCompoundEdit();
      this.compoundEdit.addEdit(edit);
      this.addEdit(this.compoundEdit);
      return this.compoundEdit;
   }

   public void undo() {
      super.undo();
      this.updateActions();
   }

   public void undoableEditHappened(UndoableEditEvent e) {
      if (this.compoundEdit == null) {
         this.compoundEdit = this.startCompoundEdit(e.getEdit());
         this.updateActions();
      } else if (this.internalAtomicEditDepth > 0) {
         this.compoundEdit.addEdit(e.getEdit());
      } else {
         int diff = this.textArea.getCaretPosition() - this.lastOffset;
         if (Math.abs(diff) <= 1) {
            this.compoundEdit.addEdit(e.getEdit());
            this.lastOffset += diff;
         } else {
            this.compoundEdit.end();
            this.compoundEdit = this.startCompoundEdit(e.getEdit());
         }
      }
   }

   public void updateActions() {
      Action a = RTextArea.getAction(6);
      String text;
      if (this.canUndo()) {
         a.setEnabled(true);
         text = this.getUndoPresentationName();
         a.putValue("Name", text);
         a.putValue("ShortDescription", text);
      } else if (a.isEnabled()) {
         a.setEnabled(false);
         text = this.cantUndoText;
         a.putValue("Name", text);
         a.putValue("ShortDescription", text);
      }

      a = RTextArea.getAction(4);
      if (this.canRedo()) {
         a.setEnabled(true);
         text = this.getRedoPresentationName();
         a.putValue("Name", text);
         a.putValue("ShortDescription", text);
      } else if (a.isEnabled()) {
         a.setEnabled(false);
         text = this.cantRedoText;
         a.putValue("Name", text);
         a.putValue("ShortDescription", text);
      }

   }

   class RCompoundEdit extends CompoundEdit {
      public String getUndoPresentationName() {
         return UIManager.getString("AbstractUndoableEdit.undoText");
      }

      public String getRedoPresentationName() {
         return UIManager.getString("AbstractUndoableEdit.redoText");
      }

      public boolean isInProgress() {
         return false;
      }

      public void undo() {
         if (RUndoManager.this.compoundEdit != null) {
            RUndoManager.this.compoundEdit.end();
         }

         super.undo();
         RUndoManager.this.compoundEdit = null;
      }
   }
}
