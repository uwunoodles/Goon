package org.fife.ui.rtextarea;

import java.awt.Graphics;
import java.awt.Rectangle;

public interface BackgroundPainterStrategy {
   void paint(Graphics var1, Rectangle var2);
}
