package org.fife.ui.rtextarea;

public enum CaretStyle {
   VERTICAL_LINE_STYLE,
   UNDERLINE_STYLE,
   BLOCK_STYLE,
   BLOCK_BORDER_STYLE,
   THICK_VERTICAL_LINE_STYLE;
}
