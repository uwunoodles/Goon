package org.fife.ui.rtextarea;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.im.InputContext;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringBufferInputStream;
import java.io.StringReader;
import javax.swing.JComponent;
import javax.swing.TransferHandler;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent;
import javax.swing.text.Position;

public class RTATextTransferHandler extends TransferHandler {
   private JTextComponent exportComp;
   private boolean shouldRemove;
   private int p0;
   private int p1;
   private boolean withinSameComponent;

   protected DataFlavor getImportFlavor(DataFlavor[] flavors, JTextComponent c) {
      DataFlavor refFlavor = null;
      DataFlavor stringFlavor = null;
      DataFlavor[] var5 = flavors;
      int var6 = flavors.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         DataFlavor flavor = var5[var7];
         String mime = flavor.getMimeType();
         if (mime.startsWith("text/plain")) {
            return flavor;
         }

         if (refFlavor == null && mime.startsWith("application/x-java-jvm-local-objectref") && flavor.getRepresentationClass() == String.class) {
            refFlavor = flavor;
         } else if (stringFlavor == null && flavor.equals(DataFlavor.stringFlavor)) {
            stringFlavor = flavor;
         }
      }

      if (refFlavor != null) {
         return refFlavor;
      } else if (stringFlavor != null) {
         return stringFlavor;
      } else {
         return null;
      }
   }

   protected void handleReaderImport(Reader in, JTextComponent c) throws IOException {
      char[] buff = new char[1024];
      boolean lastWasCR = false;
      StringBuilder sbuff = null;

      int nch;
      while((nch = in.read(buff, 0, buff.length)) != -1) {
         if (sbuff == null) {
            sbuff = new StringBuilder(nch);
         }

         int last = 0;

         for(int counter = 0; counter < nch; ++counter) {
            switch(buff[counter]) {
            case '\n':
               if (lastWasCR) {
                  if (counter > last + 1) {
                     sbuff.append(buff, last, counter - last - 1);
                  }

                  lastWasCR = false;
                  last = counter;
               }
               break;
            case '\r':
               if (lastWasCR) {
                  if (counter == 0) {
                     sbuff.append('\n');
                  } else {
                     buff[counter - 1] = '\n';
                  }
               } else {
                  lastWasCR = true;
               }
               break;
            default:
               if (lastWasCR) {
                  if (counter == 0) {
                     sbuff.append('\n');
                  } else {
                     buff[counter - 1] = '\n';
                  }

                  lastWasCR = false;
               }
            }
         }

         if (last < nch) {
            if (lastWasCR) {
               if (last < nch - 1) {
                  sbuff.append(buff, last, nch - last - 1);
               }
            } else {
               sbuff.append(buff, last, nch - last);
            }
         }
      }

      if (this.withinSameComponent) {
         ((RTextArea)c).beginAtomicEdit();
      }

      if (lastWasCR) {
         sbuff.append('\n');
      }

      c.replaceSelection(sbuff != null ? sbuff.toString() : "");
   }

   public int getSourceActions(JComponent c) {
      return ((JTextComponent)c).isEditable() ? 3 : 1;
   }

   protected Transferable createTransferable(JComponent comp) {
      this.exportComp = (JTextComponent)comp;
      this.shouldRemove = true;
      this.p0 = this.exportComp.getSelectionStart();
      this.p1 = this.exportComp.getSelectionEnd();
      return this.p0 != this.p1 ? new RTATextTransferHandler.TextTransferable(this.exportComp, this.p0, this.p1) : null;
   }

   protected void exportDone(JComponent source, Transferable data, int action) {
      if (this.shouldRemove && action == 2) {
         RTATextTransferHandler.TextTransferable t = (RTATextTransferHandler.TextTransferable)data;
         t.removeText();
         if (this.withinSameComponent) {
            ((RTextArea)source).endAtomicEdit();
            this.withinSameComponent = false;
         }
      }

      this.exportComp = null;
      if (data instanceof RTATextTransferHandler.TextTransferable) {
         ClipboardHistory.get().add(((RTATextTransferHandler.TextTransferable)data).getPlainData());
      }

   }

   public boolean importData(JComponent comp, Transferable t) {
      JTextComponent c = (JTextComponent)comp;
      this.withinSameComponent = c == this.exportComp;
      if (this.withinSameComponent && c.getCaretPosition() >= this.p0 && c.getCaretPosition() <= this.p1) {
         this.shouldRemove = false;
         return true;
      } else {
         boolean imported = false;
         DataFlavor importFlavor = this.getImportFlavor(t.getTransferDataFlavors(), c);
         if (importFlavor != null) {
            try {
               InputContext ic = c.getInputContext();
               if (ic != null) {
                  ic.endComposition();
               }

               Reader r = importFlavor.getReaderForText(t);
               this.handleReaderImport(r, c);
               imported = true;
            } catch (IOException | UnsupportedFlavorException var8) {
               var8.printStackTrace();
            }
         }

         return imported;
      }
   }

   public boolean canImport(JComponent comp, DataFlavor[] flavors) {
      JTextComponent c = (JTextComponent)comp;
      if (c.isEditable() && c.isEnabled()) {
         return this.getImportFlavor(flavors, c) != null;
      } else {
         return false;
      }
   }

   static class TextTransferable implements Transferable {
      private Position p0;
      private Position p1;
      private JTextComponent c;
      protected String plainData;
      private static DataFlavor[] stringFlavors;
      private static DataFlavor[] plainFlavors;

      TextTransferable(JTextComponent c, int start, int end) {
         this.c = c;
         Document doc = c.getDocument();

         try {
            this.p0 = doc.createPosition(start);
            this.p1 = doc.createPosition(end);
            this.plainData = c.getSelectedText();
         } catch (BadLocationException var6) {
         }

      }

      protected String getPlainData() {
         return this.plainData;
      }

      public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
         String data;
         if (this.isPlainFlavor(flavor)) {
            data = this.getPlainData();
            data = data == null ? "" : data;
            if (String.class.equals(flavor.getRepresentationClass())) {
               return data;
            }

            if (Reader.class.equals(flavor.getRepresentationClass())) {
               return new StringReader(data);
            }

            if (InputStream.class.equals(flavor.getRepresentationClass())) {
               return new StringBufferInputStream(data);
            }
         } else if (this.isStringFlavor(flavor)) {
            data = this.getPlainData();
            data = data == null ? "" : data;
            return data;
         }

         throw new UnsupportedFlavorException(flavor);
      }

      public DataFlavor[] getTransferDataFlavors() {
         int plainCount = this.isPlainSupported() ? plainFlavors.length : 0;
         int stringCount = this.isPlainSupported() ? stringFlavors.length : 0;
         int totalCount = plainCount + stringCount;
         DataFlavor[] flavors = new DataFlavor[totalCount];
         int pos = 0;
         if (plainCount > 0) {
            System.arraycopy(plainFlavors, 0, flavors, pos, plainCount);
            pos += plainCount;
         }

         if (stringCount > 0) {
            System.arraycopy(stringFlavors, 0, flavors, pos, stringCount);
         }

         return flavors;
      }

      public boolean isDataFlavorSupported(DataFlavor flavor) {
         DataFlavor[] flavors = this.getTransferDataFlavors();
         DataFlavor[] var3 = flavors;
         int var4 = flavors.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            DataFlavor dataFlavor = var3[var5];
            if (dataFlavor.equals(flavor)) {
               return true;
            }
         }

         return false;
      }

      protected boolean isPlainFlavor(DataFlavor flavor) {
         DataFlavor[] flavors = plainFlavors;
         DataFlavor[] var3 = flavors;
         int var4 = flavors.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            DataFlavor dataFlavor = var3[var5];
            if (dataFlavor.equals(flavor)) {
               return true;
            }
         }

         return false;
      }

      protected boolean isPlainSupported() {
         return this.plainData != null;
      }

      protected boolean isStringFlavor(DataFlavor flavor) {
         DataFlavor[] flavors = stringFlavors;
         DataFlavor[] var3 = flavors;
         int var4 = flavors.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            DataFlavor dataFlavor = var3[var5];
            if (dataFlavor.equals(flavor)) {
               return true;
            }
         }

         return false;
      }

      void removeText() {
         if (this.p0 != null && this.p1 != null && this.p0.getOffset() != this.p1.getOffset()) {
            try {
               Document doc = this.c.getDocument();
               doc.remove(this.p0.getOffset(), this.p1.getOffset() - this.p0.getOffset());
            } catch (BadLocationException var2) {
            }
         }

      }

      static {
         try {
            plainFlavors = new DataFlavor[3];
            plainFlavors[0] = new DataFlavor("text/plain;class=java.lang.String");
            plainFlavors[1] = new DataFlavor("text/plain;class=java.io.Reader");
            plainFlavors[2] = new DataFlavor("text/plain;charset=unicode;class=java.io.InputStream");
            stringFlavors = new DataFlavor[2];
            stringFlavors[0] = new DataFlavor("application/x-java-jvm-local-objectref;class=java.lang.String");
            stringFlavors[1] = DataFlavor.stringFlavor;
         } catch (ClassNotFoundException var1) {
            System.err.println("Error initializing org.fife.ui.RTATextTransferHandler");
         }

      }
   }
}
