package org.fife.ui.rtextarea;

import javax.swing.text.BadLocationException;
import javax.swing.text.GapContent;
import javax.swing.text.PlainDocument;

public class RDocument extends PlainDocument {
   public RDocument() {
      super(new RDocument.RGapContent());
   }

   public char charAt(int offset) throws BadLocationException {
      return ((RDocument.RGapContent)this.getContent()).charAt(offset);
   }

   private static class RGapContent extends GapContent {
      private RGapContent() {
      }

      public char charAt(int offset) throws BadLocationException {
         if (offset >= 0 && offset < this.length()) {
            int g0 = this.getGapStart();
            char[] array = (char[])((char[])this.getArray());
            return offset < g0 ? array[offset] : array[this.getGapEnd() + offset - g0];
         } else {
            throw new BadLocationException("Invalid offset", offset);
         }
      }

      // $FF: synthetic method
      RGapContent(Object x0) {
         this();
      }
   }
}
