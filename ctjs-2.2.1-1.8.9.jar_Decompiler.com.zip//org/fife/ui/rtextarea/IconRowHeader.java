package org.fife.ui.rtextarea;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.Icon;
import javax.swing.JPanel;
import javax.swing.ToolTipManager;
import javax.swing.UIManager;
import javax.swing.event.DocumentEvent;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.Position;
import javax.swing.text.View;

public class IconRowHeader extends AbstractGutterComponent implements MouseListener {
   protected List<IconRowHeader.GutterIconImpl> trackingIcons;
   protected int width;
   private boolean bookmarkingEnabled;
   private Icon bookmarkIcon;
   protected Rectangle visibleRect;
   protected Insets textAreaInsets;
   protected int activeLineRangeStart;
   protected int activeLineRangeEnd;
   private Color activeLineRangeColor;
   private boolean inheritsGutterBackground;

   public IconRowHeader(RTextArea textArea) {
      super(textArea);
   }

   public GutterIconInfo addOffsetTrackingIcon(int offs, Icon icon) throws BadLocationException {
      return this.addOffsetTrackingIcon(offs, icon, (String)null);
   }

   public GutterIconInfo addOffsetTrackingIcon(int offs, Icon icon, String tip) throws BadLocationException {
      if (offs >= 0 && offs <= this.textArea.getDocument().getLength()) {
         Position pos = this.textArea.getDocument().createPosition(offs);
         IconRowHeader.GutterIconImpl ti = new IconRowHeader.GutterIconImpl(icon, pos, tip);
         if (this.trackingIcons == null) {
            this.trackingIcons = new ArrayList(1);
         }

         int index = Collections.binarySearch(this.trackingIcons, ti);
         if (index < 0) {
            index = -(index + 1);
         }

         this.trackingIcons.add(index, ti);
         this.repaint();
         return ti;
      } else {
         throw new BadLocationException("Offset " + offs + " not in " + "required range of 0-" + this.textArea.getDocument().getLength(), offs);
      }
   }

   public void clearActiveLineRange() {
      if (this.activeLineRangeStart != -1 || this.activeLineRangeEnd != -1) {
         this.activeLineRangeStart = this.activeLineRangeEnd = -1;
         this.repaint();
      }

   }

   public Color getActiveLineRangeColor() {
      return this.activeLineRangeColor;
   }

   public Icon getBookmarkIcon() {
      return this.bookmarkIcon;
   }

   public GutterIconInfo[] getBookmarks() {
      List<GutterIconInfo> retVal = new ArrayList(1);
      if (this.trackingIcons != null) {
         for(int i = 0; i < this.trackingIcons.size(); ++i) {
            IconRowHeader.GutterIconImpl ti = this.getTrackingIcon(i);
            if (ti.getIcon() == this.bookmarkIcon) {
               retVal.add(ti);
            }
         }
      }

      GutterIconInfo[] array = new GutterIconInfo[retVal.size()];
      return (GutterIconInfo[])retVal.toArray(array);
   }

   void handleDocumentEvent(DocumentEvent e) {
      int newLineCount = this.textArea.getLineCount();
      if (newLineCount != this.currentLineCount) {
         this.currentLineCount = newLineCount;
         this.repaint();
      }

   }

   public Dimension getPreferredSize() {
      int h = this.textArea != null ? this.textArea.getHeight() : 100;
      return new Dimension(this.width, h);
   }

   public String getToolTipText(MouseEvent e) {
      try {
         int line = this.viewToModelLine(e.getPoint());
         if (line > -1) {
            GutterIconInfo[] infos = this.getTrackingIcons(line);
            if (infos.length > 0) {
               return infos[infos.length - 1].getToolTip();
            }
         }
      } catch (BadLocationException var4) {
         var4.printStackTrace();
      }

      return null;
   }

   protected IconRowHeader.GutterIconImpl getTrackingIcon(int index) {
      return (IconRowHeader.GutterIconImpl)this.trackingIcons.get(index);
   }

   public GutterIconInfo[] getTrackingIcons(int line) throws BadLocationException {
      List<GutterIconInfo> retVal = new ArrayList(1);
      if (this.trackingIcons != null) {
         int start = this.textArea.getLineStartOffset(line);
         int end = this.textArea.getLineEndOffset(line);
         if (line == this.textArea.getLineCount() - 1) {
            ++end;
         }

         for(int i = 0; i < this.trackingIcons.size(); ++i) {
            IconRowHeader.GutterIconImpl ti = this.getTrackingIcon(i);
            int offs = ti.getMarkedOffset();
            if (offs >= start && offs < end) {
               retVal.add(ti);
            } else if (offs >= end) {
               break;
            }
         }
      }

      GutterIconInfo[] array = new GutterIconInfo[retVal.size()];
      return (GutterIconInfo[])retVal.toArray(array);
   }

   protected void init() {
      super.init();
      this.visibleRect = new Rectangle();
      this.width = 16;
      this.addMouseListener(this);
      this.activeLineRangeStart = this.activeLineRangeEnd = -1;
      this.setActiveLineRangeColor((Color)null);
      this.updateBackground();
      ToolTipManager.sharedInstance().registerComponent(this);
   }

   public boolean isBookmarkingEnabled() {
      return this.bookmarkingEnabled;
   }

   void lineHeightsChanged() {
      this.repaint();
   }

   public void mouseClicked(MouseEvent e) {
   }

   public void mouseEntered(MouseEvent e) {
   }

   public void mouseExited(MouseEvent e) {
   }

   public void mousePressed(MouseEvent e) {
      if (this.bookmarkingEnabled && this.bookmarkIcon != null) {
         try {
            int line = this.viewToModelLine(e.getPoint());
            if (line > -1) {
               this.toggleBookmark(line);
            }
         } catch (BadLocationException var3) {
            var3.printStackTrace();
         }
      }

   }

   public void mouseReleased(MouseEvent e) {
   }

   protected void paintComponent(Graphics g) {
      if (this.textArea != null) {
         this.visibleRect = g.getClipBounds(this.visibleRect);
         if (this.visibleRect == null) {
            this.visibleRect = this.getVisibleRect();
         }

         if (this.visibleRect != null) {
            this.paintBackgroundImpl(g, this.visibleRect);
            if (this.textArea.getLineWrap()) {
               this.paintComponentWrapped(g);
            } else {
               Document doc = this.textArea.getDocument();
               Element root = doc.getDefaultRootElement();
               this.textAreaInsets = this.textArea.getInsets(this.textAreaInsets);
               if (this.visibleRect.y < this.textAreaInsets.top) {
                  Rectangle var10000 = this.visibleRect;
                  var10000.height -= this.textAreaInsets.top - this.visibleRect.y;
                  this.visibleRect.y = this.textAreaInsets.top;
               }

               int cellHeight = this.textArea.getLineHeight();
               int topLine = (this.visibleRect.y - this.textAreaInsets.top) / cellHeight;
               int bottomLine = Math.min(topLine + this.visibleRect.height / cellHeight + 1, root.getElementCount());
               int y = topLine * cellHeight + this.textAreaInsets.top;
               int lastLine;
               int y1;
               int y2;
               int line;
               int y2;
               if (this.activeLineRangeStart >= topLine && this.activeLineRangeStart <= bottomLine || this.activeLineRangeEnd >= topLine && this.activeLineRangeEnd <= bottomLine || this.activeLineRangeStart <= topLine && this.activeLineRangeEnd >= bottomLine) {
                  g.setColor(this.activeLineRangeColor);
                  lastLine = Math.max(this.activeLineRangeStart, topLine);
                  y1 = lastLine * cellHeight + this.textAreaInsets.top;
                  int lastLine = Math.min(this.activeLineRangeEnd, bottomLine);
                  y2 = (lastLine + 1) * cellHeight + this.textAreaInsets.top - 1;

                  int i;
                  for(line = y1; line <= y2; line += 2) {
                     i = Math.min(y2, line + this.getWidth());
                     y2 = i - line;
                     g.drawLine(0, line, y2, i);
                  }

                  for(i = 2; i < this.getWidth(); i += 2) {
                     y2 = y1 + this.getWidth() - i;
                     g.drawLine(i, y1, this.getWidth(), y2);
                  }

                  if (lastLine == this.activeLineRangeStart) {
                     g.drawLine(0, y1, this.getWidth(), y1);
                  }

                  if (lastLine == this.activeLineRangeEnd) {
                     g.drawLine(0, y2, this.getWidth(), y2);
                  }
               }

               if (this.trackingIcons != null) {
                  lastLine = bottomLine;

                  for(y1 = this.trackingIcons.size() - 1; y1 >= 0; --y1) {
                     GutterIconInfo ti = this.getTrackingIcon(y1);
                     y2 = ti.getMarkedOffset();
                     if (y2 >= 0 && y2 <= doc.getLength()) {
                        line = root.getElementIndex(y2);
                        if (line <= lastLine && line >= topLine) {
                           Icon icon = ti.getIcon();
                           if (icon != null) {
                              y2 = y + (line - topLine) * cellHeight;
                              y2 += (cellHeight - icon.getIconHeight()) / 2;
                              ti.getIcon().paintIcon(this, g, 0, y2);
                              lastLine = line - 1;
                           }
                        } else if (line < topLine) {
                           break;
                        }
                     }
                  }
               }

            }
         }
      }
   }

   protected void paintBackgroundImpl(Graphics g, Rectangle visibleRect) {
      Color bg = this.getBackground();
      if (this.inheritsGutterBackground && this.getGutter() != null) {
         bg = this.getGutter().getBackground();
      }

      g.setColor(bg);
      g.fillRect(0, visibleRect.y, this.width, visibleRect.height);
   }

   private void paintComponentWrapped(Graphics g) {
      RTextAreaUI ui = (RTextAreaUI)this.textArea.getUI();
      View v = ui.getRootView(this.textArea).getView(0);
      Document doc = this.textArea.getDocument();
      Element root = doc.getDefaultRootElement();
      int lineCount = root.getElementCount();
      int topPosition = this.textArea.viewToModel(new Point(this.visibleRect.x, this.visibleRect.y));
      int topLine = root.getElementIndex(topPosition);
      Rectangle visibleEditorRect = ui.getVisibleEditorRect();
      Rectangle r = getChildViewBounds(v, topLine, visibleEditorRect);
      int y = r.y;
      int visibleBottom = this.visibleRect.y + this.visibleRect.height;
      int currentIcon = -1;
      int cellHeight;
      IconRowHeader.GutterIconImpl toPaint;
      int y2;
      if (this.trackingIcons != null) {
         for(cellHeight = 0; cellHeight < this.trackingIcons.size(); ++cellHeight) {
            toPaint = this.getTrackingIcon(cellHeight);
            int offs = toPaint.getMarkedOffset();
            if (offs >= 0 && offs <= doc.getLength()) {
               y2 = root.getElementIndex(offs);
               if (y2 >= topLine) {
                  currentIcon = cellHeight;
                  break;
               }
            }
         }
      }

      g.setColor(this.getForeground());
      cellHeight = this.textArea.getLineHeight();

      while(y < visibleBottom) {
         r = getChildViewBounds(v, topLine, visibleEditorRect);
         if (currentIcon > -1) {
            for(toPaint = null; currentIcon < this.trackingIcons.size(); ++currentIcon) {
               IconRowHeader.GutterIconImpl ti = this.getTrackingIcon(currentIcon);
               y2 = ti.getMarkedOffset();
               if (y2 >= 0 && y2 <= doc.getLength()) {
                  int line = root.getElementIndex(y2);
                  if (line == topLine) {
                     toPaint = ti;
                  } else if (line > topLine) {
                     break;
                  }
               }
            }

            if (toPaint != null) {
               Icon icon = toPaint.getIcon();
               if (icon != null) {
                  y2 = y + (cellHeight - icon.getIconHeight()) / 2;
                  icon.paintIcon(this, g, 0, y2);
               }
            }
         }

         y += r.height;
         ++topLine;
         if (topLine >= lineCount) {
            break;
         }
      }

   }

   public void removeTrackingIcon(GutterIconInfo tag) {
      if (this.trackingIcons != null && this.trackingIcons.remove(tag)) {
         this.repaint();
      }

   }

   public void removeAllTrackingIcons() {
      if (this.trackingIcons != null && this.trackingIcons.size() > 0) {
         this.trackingIcons.clear();
         this.repaint();
      }

   }

   private void removeBookmarkTrackingIcons() {
      if (this.trackingIcons != null) {
         this.trackingIcons.removeIf((ti) -> {
            return ti.getIcon() == this.bookmarkIcon;
         });
      }

   }

   public void setActiveLineRange(int startLine, int endLine) {
      if (startLine != this.activeLineRangeStart || endLine != this.activeLineRangeEnd) {
         this.activeLineRangeStart = startLine;
         this.activeLineRangeEnd = endLine;
         this.repaint();
      }

   }

   public void setActiveLineRangeColor(Color color) {
      if (color == null) {
         color = Gutter.DEFAULT_ACTIVE_LINE_RANGE_COLOR;
      }

      if (!color.equals(this.activeLineRangeColor)) {
         this.activeLineRangeColor = color;
         this.repaint();
      }

   }

   public void setBookmarkIcon(Icon icon) {
      this.removeBookmarkTrackingIcons();
      this.bookmarkIcon = icon;
      this.repaint();
   }

   public void setBookmarkingEnabled(boolean enabled) {
      if (enabled != this.bookmarkingEnabled) {
         this.bookmarkingEnabled = enabled;
         if (!enabled) {
            this.removeBookmarkTrackingIcons();
         }

         this.repaint();
      }

   }

   public void setInheritsGutterBackground(boolean inherits) {
      if (inherits != this.inheritsGutterBackground) {
         this.inheritsGutterBackground = inherits;
         this.repaint();
      }

   }

   public void setTextArea(RTextArea textArea) {
      this.removeAllTrackingIcons();
      super.setTextArea(textArea);
   }

   public boolean toggleBookmark(int line) throws BadLocationException {
      if (this.isBookmarkingEnabled() && this.getBookmarkIcon() != null) {
         GutterIconInfo[] icons = this.getTrackingIcons(line);
         if (icons.length == 0) {
            int offs = this.textArea.getLineStartOffset(line);
            this.addOffsetTrackingIcon(offs, this.bookmarkIcon);
            return true;
         } else {
            boolean found = false;
            GutterIconInfo[] var4 = icons;
            int var5 = icons.length;

            for(int var6 = 0; var6 < var5; ++var6) {
               GutterIconInfo icon = var4[var6];
               if (icon.getIcon() == this.bookmarkIcon) {
                  this.removeTrackingIcon(icon);
                  found = true;
               }
            }

            if (!found) {
               int offs = this.textArea.getLineStartOffset(line);
               this.addOffsetTrackingIcon(offs, this.bookmarkIcon);
            }

            return !found;
         }
      } else {
         return false;
      }
   }

   private void updateBackground() {
      Color bg = UIManager.getColor("Panel.background");
      if (bg == null) {
         bg = (new JPanel()).getBackground();
      }

      this.setBackground(bg);
   }

   public void updateUI() {
      super.updateUI();
      this.updateBackground();
   }

   private int viewToModelLine(Point p) throws BadLocationException {
      int offs = this.textArea.viewToModel(p);
      return offs > -1 ? this.textArea.getLineOfOffset(offs) : -1;
   }

   private static class GutterIconImpl implements GutterIconInfo, Comparable<GutterIconInfo> {
      private Icon icon;
      private Position pos;
      private String toolTip;

      GutterIconImpl(Icon icon, Position pos, String toolTip) {
         this.icon = icon;
         this.pos = pos;
         this.toolTip = toolTip;
      }

      public int compareTo(GutterIconInfo other) {
         return other != null ? this.pos.getOffset() - other.getMarkedOffset() : -1;
      }

      public boolean equals(Object o) {
         return o == this;
      }

      public Icon getIcon() {
         return this.icon;
      }

      public int getMarkedOffset() {
         return this.pos.getOffset();
      }

      public String getToolTip() {
         return this.toolTip;
      }

      public int hashCode() {
         return this.icon.hashCode();
      }
   }
}
