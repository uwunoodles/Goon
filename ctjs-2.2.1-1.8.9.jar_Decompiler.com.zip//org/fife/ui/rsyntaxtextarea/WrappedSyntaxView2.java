package org.fife.ui.rsyntaxtextarea;

import javax.swing.text.Element;

public class WrappedSyntaxView2 {
   public WrappedSyntaxView2(Element root) {
   }
}
