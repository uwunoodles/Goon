package org.fife.ui.rsyntaxtextarea;

import javax.swing.text.Segment;

public abstract class AbstractJFlexTokenMaker extends TokenMakerBase {
   protected Segment s;
   protected int start;
   protected int offsetShift;

   public abstract void yybegin(int var1);

   protected void yybegin(int state, int languageIndex) {
      this.yybegin(state);
      this.setLanguageIndex(languageIndex);
   }
}
