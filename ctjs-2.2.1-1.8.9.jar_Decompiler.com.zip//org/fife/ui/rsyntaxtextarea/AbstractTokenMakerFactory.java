package org.fife.ui.rsyntaxtextarea;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public abstract class AbstractTokenMakerFactory extends TokenMakerFactory {
   private Map<String, Object> tokenMakerMap = new HashMap();

   protected AbstractTokenMakerFactory() {
      this.initTokenMakerMap();
   }

   protected TokenMaker getTokenMakerImpl(String key) {
      AbstractTokenMakerFactory.TokenMakerCreator tmc = (AbstractTokenMakerFactory.TokenMakerCreator)this.tokenMakerMap.get(key);
      if (tmc != null) {
         try {
            return tmc.create();
         } catch (RuntimeException var4) {
            throw var4;
         } catch (Exception var5) {
            var5.printStackTrace();
         }
      }

      return null;
   }

   protected abstract void initTokenMakerMap();

   public Set<String> keySet() {
      return this.tokenMakerMap.keySet();
   }

   public void putMapping(String key, String className) {
      this.putMapping(key, className, (ClassLoader)null);
   }

   public void putMapping(String key, String className, ClassLoader cl) {
      this.tokenMakerMap.put(key, new AbstractTokenMakerFactory.TokenMakerCreator(className, cl));
   }

   private static class TokenMakerCreator {
      private String className;
      private ClassLoader cl;

      public TokenMakerCreator(String className, ClassLoader cl) {
         this.className = className;
         this.cl = cl != null ? cl : this.getClass().getClassLoader();
      }

      public TokenMaker create() throws Exception {
         return (TokenMaker)Class.forName(this.className, true, this.cl).newInstance();
      }
   }
}
