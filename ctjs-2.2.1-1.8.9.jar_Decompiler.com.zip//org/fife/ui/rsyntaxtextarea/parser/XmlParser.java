package org.fife.ui.rsyntaxtextarea.parser;

import java.io.IOException;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.fife.io.DocumentReader;
import org.fife.ui.rsyntaxtextarea.RSyntaxDocument;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

public class XmlParser extends AbstractParser {
   private SAXParserFactory spf;
   private DefaultParseResult result;
   private EntityResolver entityResolver;

   public XmlParser() {
      this((EntityResolver)null);
   }

   public XmlParser(EntityResolver resolver) {
      this.entityResolver = resolver;
      this.result = new DefaultParseResult(this);

      try {
         this.spf = SAXParserFactory.newInstance();
      } catch (FactoryConfigurationError var3) {
         var3.printStackTrace();
      }

   }

   public boolean isValidating() {
      return this.spf.isValidating();
   }

   public ParseResult parse(RSyntaxDocument doc, String style) {
      this.result.clearNotices();
      Element root = doc.getDefaultRootElement();
      this.result.setParsedLines(0, root.getElementCount() - 1);
      if (this.spf != null && doc.getLength() != 0) {
         try {
            SAXParser sp = this.spf.newSAXParser();
            XmlParser.Handler handler = new XmlParser.Handler(doc);
            DocumentReader r = new DocumentReader(doc);
            InputSource input = new InputSource(r);
            sp.parse(input, handler);
            r.close();
         } catch (SAXParseException var8) {
         } catch (Exception var9) {
            this.result.addNotice(new DefaultParserNotice(this, "Error parsing XML: " + var9.getMessage(), 0, -1, -1));
         }

         return this.result;
      } else {
         return this.result;
      }
   }

   public void setValidating(boolean validating) {
      this.spf.setValidating(validating);
   }

   private final class Handler extends DefaultHandler {
      private Document doc;

      private Handler(Document doc) {
         this.doc = doc;
      }

      private void doError(SAXParseException e, ParserNotice.Level level) {
         int line = e.getLineNumber() - 1;
         Element root = this.doc.getDefaultRootElement();
         Element elem = root.getElement(line);
         int offs = elem.getStartOffset();
         int len = elem.getEndOffset() - offs;
         if (line == root.getElementCount() - 1) {
            ++len;
         }

         DefaultParserNotice pn = new DefaultParserNotice(XmlParser.this, e.getMessage(), line, offs, len);
         pn.setLevel(level);
         XmlParser.this.result.addNotice(pn);
      }

      public void error(SAXParseException e) {
         this.doError(e, ParserNotice.Level.ERROR);
      }

      public void fatalError(SAXParseException e) {
         this.doError(e, ParserNotice.Level.ERROR);
      }

      public InputSource resolveEntity(String publicId, String systemId) throws IOException, SAXException {
         return XmlParser.this.entityResolver != null ? XmlParser.this.entityResolver.resolveEntity(publicId, systemId) : super.resolveEntity(publicId, systemId);
      }

      public void warning(SAXParseException e) {
         this.doError(e, ParserNotice.Level.WARNING);
      }

      // $FF: synthetic method
      Handler(Document x1, Object x2) {
         this(x1);
      }
   }
}
