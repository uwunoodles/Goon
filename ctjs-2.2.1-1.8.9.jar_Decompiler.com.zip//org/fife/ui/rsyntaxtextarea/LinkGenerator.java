package org.fife.ui.rsyntaxtextarea;

public interface LinkGenerator {
   LinkGeneratorResult isLinkAtOffset(RSyntaxTextArea var1, int var2);
}
