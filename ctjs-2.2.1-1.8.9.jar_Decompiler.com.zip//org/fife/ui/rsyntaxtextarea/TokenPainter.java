package org.fife.ui.rsyntaxtextarea;

import java.awt.Graphics2D;
import javax.swing.text.TabExpander;

interface TokenPainter {
   float paint(Token var1, Graphics2D var2, float var3, float var4, RSyntaxTextArea var5, TabExpander var6);

   float paint(Token var1, Graphics2D var2, float var3, float var4, RSyntaxTextArea var5, TabExpander var6, float var7);

   float paint(Token var1, Graphics2D var2, float var3, float var4, RSyntaxTextArea var5, TabExpander var6, float var7, boolean var8);

   float paintSelected(Token var1, Graphics2D var2, float var3, float var4, RSyntaxTextArea var5, TabExpander var6, boolean var7);

   float paintSelected(Token var1, Graphics2D var2, float var3, float var4, RSyntaxTextArea var5, TabExpander var6, float var7, boolean var8);
}
