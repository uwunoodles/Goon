package org.fife.ui.rsyntaxtextarea.templates;

public abstract class AbstractCodeTemplate implements CodeTemplate {
   private String id;

   public AbstractCodeTemplate() {
   }

   public AbstractCodeTemplate(String id) {
      this.setID(id);
   }

   public Object clone() {
      try {
         return super.clone();
      } catch (CloneNotSupportedException var2) {
         throw new InternalError("CodeTemplate implementation not Cloneable: " + this.getClass().getName());
      }
   }

   public int compareTo(CodeTemplate o) {
      return o == null ? -1 : this.getID().compareTo(o.getID());
   }

   public boolean equals(Object obj) {
      if (obj instanceof CodeTemplate) {
         return this.compareTo((CodeTemplate)obj) == 0;
      } else {
         return false;
      }
   }

   public String getID() {
      return this.id;
   }

   public int hashCode() {
      return this.id.hashCode();
   }

   public void setID(String id) {
      if (id == null) {
         throw new IllegalArgumentException("id cannot be null");
      } else {
         this.id = id;
      }
   }
}
