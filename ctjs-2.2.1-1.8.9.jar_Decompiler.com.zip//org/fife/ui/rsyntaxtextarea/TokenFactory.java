package org.fife.ui.rsyntaxtextarea;

import javax.swing.text.Segment;

interface TokenFactory {
   TokenImpl createToken();

   TokenImpl createToken(Segment var1, int var2, int var3, int var4, int var5);

   TokenImpl createToken(char[] var1, int var2, int var3, int var4, int var5);

   void resetAllTokens();
}
