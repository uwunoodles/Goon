package org.fife.ui.rsyntaxtextarea;

import java.security.AccessControlException;
import java.util.Set;
import org.fife.ui.rsyntaxtextarea.modes.PlainTextTokenMaker;

public abstract class TokenMakerFactory {
   public static final String PROPERTY_DEFAULT_TOKEN_MAKER_FACTORY = "TokenMakerFactory";
   private static TokenMakerFactory DEFAULT_INSTANCE;

   public static synchronized TokenMakerFactory getDefaultInstance() {
      if (DEFAULT_INSTANCE == null) {
         String clazz;
         try {
            clazz = System.getProperty("TokenMakerFactory");
         } catch (AccessControlException var4) {
            clazz = null;
         }

         if (clazz == null) {
            clazz = "org.fife.ui.rsyntaxtextarea.DefaultTokenMakerFactory";
         }

         try {
            DEFAULT_INSTANCE = (TokenMakerFactory)Class.forName(clazz).getDeclaredConstructor().newInstance();
         } catch (RuntimeException var2) {
            throw var2;
         } catch (Exception var3) {
            var3.printStackTrace();
            throw new InternalError("Cannot find TokenMakerFactory: " + clazz);
         }
      }

      return DEFAULT_INSTANCE;
   }

   public final TokenMaker getTokenMaker(String key) {
      TokenMaker tm = this.getTokenMakerImpl(key);
      if (tm == null) {
         tm = new PlainTextTokenMaker();
      }

      return (TokenMaker)tm;
   }

   protected abstract TokenMaker getTokenMakerImpl(String var1);

   public abstract Set<String> keySet();

   public static synchronized void setDefaultInstance(TokenMakerFactory tmf) {
      if (tmf == null) {
         throw new IllegalArgumentException("tmf cannot be null");
      } else {
         DEFAULT_INSTANCE = tmf;
      }
   }
}
