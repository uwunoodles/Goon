package org.fife.ui.rsyntaxtextarea;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentEvent.ElementChange;
import javax.swing.event.DocumentEvent.EventType;
import javax.swing.text.BadLocationException;
import javax.swing.text.Element;
import javax.swing.text.TabExpander;
import javax.swing.text.View;
import javax.swing.text.ViewFactory;
import javax.swing.text.Position.Bias;
import org.fife.ui.rsyntaxtextarea.folding.Fold;
import org.fife.ui.rsyntaxtextarea.folding.FoldManager;

public class SyntaxView extends View implements TabExpander, TokenOrientedView, RSTAView {
   private Font font;
   private FontMetrics metrics;
   private Element longLine;
   private float longLineWidth;
   private int tabSize;
   private int tabBase;
   private RSyntaxTextArea host;
   private int lineHeight = 0;
   private int ascent;
   private int clipStart;
   private int clipEnd;
   private TokenImpl tempToken = new TokenImpl();

   public SyntaxView(Element elem) {
      super(elem);
   }

   void calculateLongestLine() {
      Component c = this.getContainer();
      this.font = c.getFont();
      this.metrics = c.getFontMetrics(this.font);
      this.tabSize = this.getTabSize() * this.metrics.charWidth(' ');
      Element lines = this.getElement();
      int n = lines.getElementCount();

      for(int i = 0; i < n; ++i) {
         Element line = lines.getElement(i);
         float w = this.getLineWidth(i);
         if (w > this.longLineWidth) {
            this.longLineWidth = w;
            this.longLine = line;
         }
      }

   }

   public void changedUpdate(DocumentEvent changes, Shape a, ViewFactory f) {
      this.updateDamage(changes, a, f);
   }

   protected void damageLineRange(int line0, int line1, Shape a, Component host) {
      if (a != null) {
         Rectangle area0 = this.lineToRect(a, line0);
         Rectangle area1 = this.lineToRect(a, line1);
         if (area0 != null && area1 != null) {
            Rectangle dmg = area0.union(area1);
            host.repaint(dmg.x, dmg.y, dmg.width, dmg.height);
         } else {
            host.repaint();
         }
      }

   }

   private float drawLine(TokenPainter painter, Token token, Graphics2D g, float x, float y, int line) {
      float nextX = x;

      for(boolean paintBG = this.host.getPaintTokenBackgrounds(line, y); token != null && token.isPaintable() && nextX < (float)this.clipEnd; token = token.getNextToken()) {
         nextX = painter.paint(token, g, nextX, y, this.host, this, (float)this.clipStart, paintBG);
      }

      if (this.host.getEOLMarkersVisible()) {
         g.setColor(this.host.getForegroundForTokenType(21));
         g.setFont(this.host.getFontForTokenType(21));
         g.drawString("¶", nextX, y);
      }

      return nextX;
   }

   private float drawLineWithSelection(TokenPainter painter, Token token, Graphics2D g, float x, float y, int selStart, int selEnd) {
      float nextX = x;

      for(boolean useSTC = this.host.getUseSelectedTextColor(); token != null && ((Token)token).isPaintable() && nextX < (float)this.clipEnd; token = ((Token)token).getNextToken()) {
         if (((Token)token).containsPosition(selStart)) {
            if (selStart > ((Token)token).getOffset()) {
               this.tempToken.copyFrom((Token)token);
               this.tempToken.textCount = selStart - this.tempToken.getOffset();
               nextX = painter.paint(this.tempToken, g, nextX, y, this.host, this, (float)this.clipStart);
               this.tempToken.textCount = ((Token)token).length();
               this.tempToken.makeStartAt(selStart);
               token = new TokenImpl(this.tempToken);
            }

            int tokenLen = ((Token)token).length();
            int selCount = Math.min(tokenLen, selEnd - ((Token)token).getOffset());
            if (selCount == tokenLen) {
               nextX = painter.paintSelected((Token)token, g, nextX, y, this.host, this, (float)this.clipStart, useSTC);
            } else {
               this.tempToken.copyFrom((Token)token);
               this.tempToken.textCount = selCount;
               nextX = painter.paintSelected(this.tempToken, g, nextX, y, this.host, this, (float)this.clipStart, useSTC);
               this.tempToken.textCount = ((Token)token).length();
               this.tempToken.makeStartAt(((Token)token).getOffset() + selCount);
               token = this.tempToken;
               nextX = painter.paint((Token)token, g, nextX, y, this.host, this, (float)this.clipStart);
            }
         } else if (((Token)token).containsPosition(selEnd)) {
            this.tempToken.copyFrom((Token)token);
            this.tempToken.textCount = selEnd - this.tempToken.getOffset();
            nextX = painter.paintSelected(this.tempToken, g, nextX, y, this.host, this, (float)this.clipStart, useSTC);
            this.tempToken.textCount = ((Token)token).length();
            this.tempToken.makeStartAt(selEnd);
            token = this.tempToken;
            nextX = painter.paint((Token)token, g, nextX, y, this.host, this, (float)this.clipStart);
         } else if (((Token)token).getOffset() >= selStart && ((Token)token).getEndOffset() <= selEnd) {
            nextX = painter.paintSelected((Token)token, g, nextX, y, this.host, this, (float)this.clipStart, useSTC);
         } else {
            nextX = painter.paint((Token)token, g, nextX, y, this.host, this, (float)this.clipStart);
         }
      }

      if (this.host.getEOLMarkersVisible()) {
         g.setColor(this.host.getForegroundForTokenType(21));
         g.setFont(this.host.getFontForTokenType(21));
         g.drawString("¶", nextX, y);
      }

      return nextX;
   }

   private float getLineWidth(int lineNumber) {
      Token tokenList = ((RSyntaxDocument)this.getDocument()).getTokenListForLine(lineNumber);
      return RSyntaxUtilities.getTokenListWidth(tokenList, (RSyntaxTextArea)this.getContainer(), this);
   }

   public int getNextVisualPositionFrom(int pos, Bias b, Shape a, int direction, Bias[] biasRet) throws BadLocationException {
      return RSyntaxUtilities.getNextVisualPositionFrom(pos, b, a, direction, biasRet, this);
   }

   public float getPreferredSpan(int axis) {
      this.updateMetrics();
      switch(axis) {
      case 0:
         float span = this.longLineWidth + (float)this.getRhsCorrection();
         if (this.host.getEOLMarkersVisible()) {
            span += (float)this.metrics.charWidth('¶');
         }

         return span;
      case 1:
         this.lineHeight = this.host != null ? this.host.getLineHeight() : this.lineHeight;
         int visibleLineCount = this.getElement().getElementCount();
         if (this.host.isCodeFoldingEnabled()) {
            visibleLineCount -= this.host.getFoldManager().getHiddenLineCount();
         }

         return (float)visibleLineCount * (float)this.lineHeight;
      default:
         throw new IllegalArgumentException("Invalid axis: " + axis);
      }
   }

   private int getRhsCorrection() {
      int rhsCorrection = 10;
      if (this.host != null) {
         rhsCorrection = this.host.getRightHandSideCorrection();
      }

      return rhsCorrection;
   }

   private int getTabSize() {
      Integer i = (Integer)this.getDocument().getProperty("tabSize");
      int size = i != null ? i : 5;
      return size;
   }

   public Token getTokenListForPhysicalLineAbove(int offset) {
      RSyntaxDocument document = (RSyntaxDocument)this.getDocument();
      Element map = document.getDefaultRootElement();
      int line = map.getElementIndex(offset);
      FoldManager fm = this.host.getFoldManager();
      if (fm == null) {
         --line;
         if (line >= 0) {
            return document.getTokenListForLine(line);
         }
      } else {
         line = fm.getVisibleLineAbove(line);
         if (line >= 0) {
            return document.getTokenListForLine(line);
         }
      }

      return null;
   }

   public Token getTokenListForPhysicalLineBelow(int offset) {
      RSyntaxDocument document = (RSyntaxDocument)this.getDocument();
      Element map = document.getDefaultRootElement();
      int lineCount = map.getElementCount();
      int line = map.getElementIndex(offset);
      if (!this.host.isCodeFoldingEnabled()) {
         if (line < lineCount - 1) {
            return document.getTokenListForLine(line + 1);
         }
      } else {
         FoldManager fm = this.host.getFoldManager();
         line = fm.getVisibleLineBelow(line);
         if (line >= 0 && line < lineCount) {
            return document.getTokenListForLine(line);
         }
      }

      return null;
   }

   public void insertUpdate(DocumentEvent changes, Shape a, ViewFactory f) {
      this.updateDamage(changes, a, f);
   }

   protected Rectangle lineToRect(Shape a, int line) {
      Rectangle r = null;
      this.updateMetrics();
      if (this.metrics != null) {
         Rectangle alloc = a.getBounds();
         this.lineHeight = this.host != null ? this.host.getLineHeight() : this.lineHeight;
         if (this.host != null && this.host.isCodeFoldingEnabled()) {
            FoldManager fm = this.host.getFoldManager();
            int hiddenCount = fm.getHiddenLineCountAbove(line);
            line -= hiddenCount;
         }

         r = new Rectangle(alloc.x, alloc.y + line * this.lineHeight, alloc.width, this.lineHeight);
      }

      return r;
   }

   public Shape modelToView(int pos, Shape a, Bias b) throws BadLocationException {
      Element map = this.getElement();
      RSyntaxDocument doc = (RSyntaxDocument)this.getDocument();
      int lineIndex = map.getElementIndex(pos);
      Token tokenList = doc.getTokenListForLine(lineIndex);
      Rectangle lineArea = this.lineToRect(a, lineIndex);
      this.tabBase = lineArea.x;
      lineArea = tokenList.listOffsetToView((RSyntaxTextArea)this.getContainer(), this, pos, this.tabBase, lineArea);
      return lineArea;
   }

   public Shape modelToView(int p0, Bias b0, int p1, Bias b1, Shape a) throws BadLocationException {
      Shape s0 = this.modelToView(p0, a, b0);
      Object s1;
      Rectangle r0;
      if (p1 == this.getEndOffset()) {
         try {
            s1 = this.modelToView(p1, a, b1);
         } catch (BadLocationException var11) {
            s1 = null;
         }

         if (s1 == null) {
            r0 = a instanceof Rectangle ? (Rectangle)a : a.getBounds();
            s1 = new Rectangle(r0.x + r0.width - 1, r0.y, 1, r0.height);
         }
      } else {
         s1 = this.modelToView(p1, a, b1);
      }

      r0 = s0 instanceof Rectangle ? (Rectangle)s0 : s0.getBounds();
      Rectangle r1 = s1 instanceof Rectangle ? (Rectangle)s1 : ((Shape)s1).getBounds();
      if (r0.y != r1.y) {
         Rectangle alloc = a instanceof Rectangle ? (Rectangle)a : a.getBounds();
         r0.x = alloc.x;
         r0.width = alloc.width;
      }

      r0.add(r1);
      if (p1 > p0) {
         r0.width -= r1.width;
      }

      return r0;
   }

   public float nextTabStop(float x, int tabOffset) {
      if (this.tabSize == 0) {
         return x;
      } else {
         int ntabs = ((int)x - this.tabBase) / this.tabSize;
         return (float)this.tabBase + ((float)ntabs + 1.0F) * (float)this.tabSize;
      }
   }

   public void paint(Graphics g, Shape a) {
      RSyntaxDocument document = (RSyntaxDocument)this.getDocument();
      Rectangle alloc = a.getBounds();
      this.tabBase = alloc.x;
      this.host = (RSyntaxTextArea)this.getContainer();
      Rectangle clip = g.getClipBounds();
      this.clipStart = clip.x;
      this.clipEnd = this.clipStart + clip.width;
      this.lineHeight = this.host.getLineHeight();
      this.ascent = this.host.getMaxAscent();
      int heightAbove = clip.y - alloc.y;
      int linesAbove = Math.max(0, heightAbove / this.lineHeight);
      FoldManager fm = this.host.getFoldManager();
      linesAbove += fm.getHiddenLineCountAbove(linesAbove, true);
      Rectangle lineArea = this.lineToRect(a, linesAbove);
      int y = lineArea.y + this.ascent;
      int x = lineArea.x;
      Element map = this.getElement();
      int lineCount = map.getElementCount();
      int selStart = this.host.getSelectionStart();
      int selEnd = this.host.getSelectionEnd();
      RSyntaxTextAreaHighlighter h = (RSyntaxTextAreaHighlighter)this.host.getHighlighter();
      Graphics2D g2d = (Graphics2D)g;
      TokenPainter painter = this.host.getTokenPainter();

      for(int line = linesAbove; y < clip.y + clip.height + this.ascent && line < lineCount; ++line) {
         Fold fold = fm.getFoldForLine(line);
         Element lineElement = map.getElement(line);
         int startOffset = lineElement.getStartOffset();
         int endOffset = lineElement.getEndOffset() - 1;
         h.paintLayeredHighlights(g2d, startOffset, endOffset, a, this.host, this);
         Token token = document.getTokenListForLine(line);
         if (selStart != selEnd && startOffset < selEnd && endOffset >= selStart) {
            this.drawLineWithSelection(painter, token, g2d, (float)x, (float)y, selStart, selEnd);
         } else {
            this.drawLine(painter, token, g2d, (float)x, (float)y, line);
         }

         h.paintParserHighlights(g2d, startOffset, endOffset, a, this.host, this);
         if (fold != null && fold.isCollapsed()) {
            Color c = RSyntaxUtilities.getFoldedLineBottomColor(this.host);
            if (c != null) {
               g.setColor(c);
               g.drawLine(x, y + this.lineHeight - this.ascent - 1, this.host.getWidth(), y + this.lineHeight - this.ascent - 1);
            }

            do {
               int hiddenLineCount = fold.getLineCount();
               if (hiddenLineCount == 0) {
                  break;
               }

               line += hiddenLineCount;
               fold = fm.getFoldForLine(line);
            } while(fold != null && fold.isCollapsed());
         }

         y += this.lineHeight;
      }

   }

   private boolean possiblyUpdateLongLine(Element line, int lineNumber) {
      float w = this.getLineWidth(lineNumber);
      if (w > this.longLineWidth) {
         this.longLineWidth = w;
         this.longLine = line;
         return true;
      } else {
         return false;
      }
   }

   public void removeUpdate(DocumentEvent changes, Shape a, ViewFactory f) {
      this.updateDamage(changes, a, f);
   }

   public void setSize(float width, float height) {
      super.setSize(width, height);
      this.updateMetrics();
   }

   protected void updateDamage(DocumentEvent changes, Shape a, ViewFactory f) {
      Component host = this.getContainer();
      this.updateMetrics();
      Element elem = this.getElement();
      ElementChange ec = changes.getChange(elem);
      Element[] added = ec != null ? ec.getChildrenAdded() : null;
      Element[] removed = ec != null ? ec.getChildrenRemoved() : null;
      int addedAt;
      int line;
      if (added != null && added.length > 0 || removed != null && removed.length > 0) {
         if (added != null) {
            addedAt = ec.getIndex();

            for(line = 0; line < added.length; ++line) {
               this.possiblyUpdateLongLine(added[line], addedAt + line);
            }
         }

         if (removed != null) {
            Element[] var14 = removed;
            line = removed.length;

            for(int var15 = 0; var15 < line; ++var15) {
               Element element = var14[var15];
               if (element == this.longLine) {
                  this.longLineWidth = -1.0F;
                  this.calculateLongestLine();
                  break;
               }
            }
         }

         this.preferenceChanged((View)null, true, true);
         host.repaint();
      } else if (changes.getType() == EventType.CHANGE) {
         addedAt = changes.getOffset();
         line = changes.getLength();
         this.damageLineRange(addedAt, line, a, host);
      } else {
         Element map = this.getElement();
         line = map.getElementIndex(changes.getOffset());
         this.damageLineRange(line, line, a, host);
         if (changes.getType() == EventType.INSERT) {
            Element e = map.getElement(line);
            if (e == this.longLine) {
               this.longLineWidth = this.getLineWidth(line);
               this.preferenceChanged((View)null, true, false);
            } else if (this.possiblyUpdateLongLine(e, line)) {
               this.preferenceChanged((View)null, true, false);
            }
         } else if (changes.getType() == EventType.REMOVE && map.getElement(line) == this.longLine) {
            this.longLineWidth = -1.0F;
            this.calculateLongestLine();
            this.preferenceChanged((View)null, true, false);
         }
      }

   }

   private void updateMetrics() {
      this.host = (RSyntaxTextArea)this.getContainer();
      Font f = this.host.getFont();
      if (this.font != f) {
         this.calculateLongestLine();
      }

   }

   public int viewToModel(float fx, float fy, Shape a, Bias[] bias) {
      bias[0] = Bias.Forward;
      Rectangle alloc = a.getBounds();
      RSyntaxDocument doc = (RSyntaxDocument)this.getDocument();
      int x = (int)fx;
      int y = (int)fy;
      if (y < alloc.y) {
         return this.getStartOffset();
      } else if (y > alloc.y + alloc.height) {
         return this.host.getLastVisibleOffset();
      } else {
         Element map = doc.getDefaultRootElement();
         this.lineHeight = this.host.getLineHeight();
         int lineIndex = Math.abs((y - alloc.y) / this.lineHeight);
         FoldManager fm = this.host.getFoldManager();
         lineIndex += fm.getHiddenLineCountAbove(lineIndex, true);
         if (lineIndex >= map.getElementCount()) {
            return this.host.getLastVisibleOffset();
         } else {
            Element line = map.getElement(lineIndex);
            if (x < alloc.x) {
               return line.getStartOffset();
            } else if (x > alloc.x + alloc.width) {
               return line.getEndOffset() - 1;
            } else {
               int p0 = line.getStartOffset();
               Token tokenList = doc.getTokenListForLine(lineIndex);
               this.tabBase = alloc.x;
               int offs = tokenList.getListOffset((RSyntaxTextArea)this.getContainer(), this, (float)this.tabBase, (float)x);
               return offs != -1 ? offs : p0;
            }
         }
      }
   }

   public int yForLine(Rectangle alloc, int line) throws BadLocationException {
      this.updateMetrics();
      if (this.metrics != null) {
         this.lineHeight = this.host != null ? this.host.getLineHeight() : this.lineHeight;
         if (this.host != null) {
            FoldManager fm = this.host.getFoldManager();
            if (!fm.isLineHidden(line)) {
               line -= fm.getHiddenLineCountAbove(line);
               return alloc.y + line * this.lineHeight;
            }
         }
      }

      return -1;
   }

   public int yForLineContaining(Rectangle alloc, int offs) throws BadLocationException {
      Element map = this.getElement();
      int line = map.getElementIndex(offs);
      return this.yForLine(alloc, line);
   }
}
