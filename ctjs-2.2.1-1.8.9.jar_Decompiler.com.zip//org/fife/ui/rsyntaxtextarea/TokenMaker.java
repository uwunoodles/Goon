package org.fife.ui.rsyntaxtextarea;

import javax.swing.Action;
import javax.swing.text.Segment;

public interface TokenMaker {
   void addNullToken();

   void addToken(char[] var1, int var2, int var3, int var4, int var5);

   int getClosestStandardTokenTypeForInternalType(int var1);

   boolean getCurlyBracesDenoteCodeBlocks(int var1);

   int getLastTokenTypeOnLine(Segment var1, int var2);

   String[] getLineCommentStartAndEnd(int var1);

   Action getInsertBreakAction();

   boolean getMarkOccurrencesOfTokenType(int var1);

   OccurrenceMarker getOccurrenceMarker();

   boolean getShouldIndentNextLineAfter(Token var1);

   Token getTokenList(Segment var1, int var2, int var3);

   boolean isIdentifierChar(int var1, char var2);

   boolean isMarkupLanguage();
}
