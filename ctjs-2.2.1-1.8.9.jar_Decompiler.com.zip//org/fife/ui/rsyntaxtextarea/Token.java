package org.fife.ui.rsyntaxtextarea;

import java.awt.Rectangle;
import javax.swing.text.TabExpander;

public interface Token extends TokenTypes {
   StringBuilder appendHTMLRepresentation(StringBuilder var1, RSyntaxTextArea var2, boolean var3);

   StringBuilder appendHTMLRepresentation(StringBuilder var1, RSyntaxTextArea var2, boolean var3, boolean var4);

   char charAt(int var1);

   boolean containsPosition(int var1);

   int documentToToken(int var1);

   boolean endsWith(char[] var1);

   int getEndOffset();

   String getHTMLRepresentation(RSyntaxTextArea var1);

   int getLanguageIndex();

   Token getLastNonCommentNonWhitespaceToken();

   Token getLastPaintableToken();

   String getLexeme();

   int getListOffset(RSyntaxTextArea var1, TabExpander var2, float var3, float var4);

   Token getNextToken();

   int getOffset();

   int getOffsetBeforeX(RSyntaxTextArea var1, TabExpander var2, float var3, float var4);

   char[] getTextArray();

   int getTextOffset();

   int getType();

   float getWidth(RSyntaxTextArea var1, TabExpander var2, float var3);

   float getWidthUpTo(int var1, RSyntaxTextArea var2, TabExpander var3, float var4);

   boolean is(char[] var1);

   boolean is(int var1, char[] var2);

   boolean is(int var1, String var2);

   boolean isComment();

   boolean isCommentOrWhitespace();

   boolean isHyperlink();

   boolean isIdentifier();

   boolean isLeftCurly();

   boolean isRightCurly();

   boolean isPaintable();

   boolean isSingleChar(char var1);

   boolean isSingleChar(int var1, char var2);

   boolean isWhitespace();

   int length();

   Rectangle listOffsetToView(RSyntaxTextArea var1, TabExpander var2, int var3, int var4, Rectangle var5);

   void setHyperlink(boolean var1);

   void setLanguageIndex(int var1);

   void setType(int var1);

   boolean startsWith(char[] var1);

   int tokenToDocument(int var1);
}
