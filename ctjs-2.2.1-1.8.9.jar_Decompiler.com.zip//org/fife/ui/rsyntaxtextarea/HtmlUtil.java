package org.fife.ui.rsyntaxtextarea;

import java.awt.Color;

public final class HtmlUtil {
   private HtmlUtil() {
   }

   public static String escapeForHtml(String s, String newlineReplacement, boolean inPreBlock) {
      if (s == null) {
         return null;
      } else {
         if (newlineReplacement == null) {
            newlineReplacement = "";
         }

         String tabString = inPreBlock ? "    " : "&nbsp;&nbsp;&nbsp;&nbsp;";
         boolean lastWasSpace = false;
         StringBuilder sb = new StringBuilder();

         for(int i = 0; i < s.length(); ++i) {
            char ch = s.charAt(i);
            switch(ch) {
            case '\t':
               sb.append(tabString);
               lastWasSpace = true;
               break;
            case '\n':
               sb.append(newlineReplacement);
               lastWasSpace = false;
               break;
            case ' ':
               if (!inPreBlock && lastWasSpace) {
                  sb.append("&nbsp;");
               } else {
                  sb.append(' ');
               }

               lastWasSpace = true;
               break;
            case '"':
               sb.append("&#34;");
               lastWasSpace = false;
               break;
            case '&':
               sb.append("&amp;");
               lastWasSpace = false;
               break;
            case '\'':
               sb.append("&#39;");
               lastWasSpace = false;
               break;
            case '/':
               sb.append("&#47;");
               lastWasSpace = false;
               break;
            case '<':
               sb.append("&lt;");
               lastWasSpace = false;
               break;
            case '>':
               sb.append("&gt;");
               lastWasSpace = false;
               break;
            default:
               sb.append(ch);
               lastWasSpace = false;
            }
         }

         return sb.toString();
      }
   }

   public static String getHexString(Color c) {
      if (c == null) {
         return null;
      } else {
         StringBuilder sb = new StringBuilder("#");
         int r = c.getRed();
         if (r < 16) {
            sb.append('0');
         }

         sb.append(Integer.toHexString(r));
         int g = c.getGreen();
         if (g < 16) {
            sb.append('0');
         }

         sb.append(Integer.toHexString(g));
         int b = c.getBlue();
         if (b < 16) {
            sb.append('0');
         }

         sb.append(Integer.toHexString(b));
         return sb.toString();
      }
   }

   public static String getTextAsHtml(RSyntaxTextArea textArea, int start, int end) {
      StringBuilder sb = (new StringBuilder("<pre style='")).append("font-family: \"").append(textArea.getFont().getFamily()).append("\", courier;");
      if (textArea.getBackground() != null) {
         sb.append(" background: ").append(getHexString(textArea.getBackground())).append("'>");
      }

      Token token = textArea.getTokenListFor(start, end);

      for(Token t = token; t != null; t = t.getNextToken()) {
         if (t.isPaintable()) {
            if (t.isSingleChar('\n')) {
               sb.append("<br>");
            } else {
               sb.append(TokenUtils.tokenToHtml(textArea, t));
            }
         }
      }

      sb.append("</pre>");
      return sb.toString();
   }
}
