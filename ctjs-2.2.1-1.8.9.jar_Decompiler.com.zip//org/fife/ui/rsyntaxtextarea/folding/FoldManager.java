package org.fife.ui.rsyntaxtextarea.folding;

import java.beans.PropertyChangeListener;
import java.util.List;

public interface FoldManager {
   String PROPERTY_FOLDS_UPDATED = "FoldsUpdated";

   void addPropertyChangeListener(PropertyChangeListener var1);

   void clear();

   boolean ensureOffsetNotInClosedFold(int var1);

   Fold getDeepestFoldContaining(int var1);

   Fold getDeepestOpenFoldContaining(int var1);

   Fold getFold(int var1);

   int getFoldCount();

   Fold getFoldForLine(int var1);

   int getHiddenLineCount();

   int getHiddenLineCountAbove(int var1);

   int getHiddenLineCountAbove(int var1, boolean var2);

   int getLastVisibleLine();

   int getVisibleLineAbove(int var1);

   int getVisibleLineBelow(int var1);

   boolean isCodeFoldingEnabled();

   boolean isCodeFoldingSupportedAndEnabled();

   boolean isFoldStartLine(int var1);

   boolean isLineHidden(int var1);

   void removePropertyChangeListener(PropertyChangeListener var1);

   void reparse();

   void setCodeFoldingEnabled(boolean var1);

   void setFolds(List<Fold> var1);
}
