package org.fife.ui.rsyntaxtextarea.folding;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FoldCollapser {
   private List<Integer> typesToCollapse;

   public FoldCollapser() {
      this(1);
   }

   public FoldCollapser(int typeToCollapse) {
      this.typesToCollapse = new ArrayList(3);
      this.addTypeToCollapse(typeToCollapse);
   }

   public void addTypeToCollapse(int typeToCollapse) {
      this.typesToCollapse.add(typeToCollapse);
   }

   public void collapseFolds(FoldManager fm) {
      for(int i = 0; i < fm.getFoldCount(); ++i) {
         Fold fold = fm.getFold(i);
         this.collapseImpl(fold);
      }

   }

   protected void collapseImpl(Fold fold) {
      if (this.getShouldCollapse(fold)) {
         fold.setCollapsed(true);
      }

      for(int i = 0; i < fold.getChildCount(); ++i) {
         this.collapseImpl(fold.getChild(i));
      }

   }

   public boolean getShouldCollapse(Fold fold) {
      int type = fold.getFoldType();
      Iterator var3 = this.typesToCollapse.iterator();

      Integer typeToCollapse;
      do {
         if (!var3.hasNext()) {
            return false;
         }

         typeToCollapse = (Integer)var3.next();
      } while(type != typeToCollapse);

      return true;
   }
}
