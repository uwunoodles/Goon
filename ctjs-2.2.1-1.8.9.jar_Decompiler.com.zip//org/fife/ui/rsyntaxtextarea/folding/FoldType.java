package org.fife.ui.rsyntaxtextarea.folding;

public interface FoldType {
   int CODE = 0;
   int COMMENT = 1;
   int IMPORTS = 2;
   int FOLD_TYPE_USER_DEFINED_MIN = 1000;
}
