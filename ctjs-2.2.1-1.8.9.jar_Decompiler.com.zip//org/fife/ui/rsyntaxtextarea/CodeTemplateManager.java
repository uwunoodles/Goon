package org.fife.ui.rsyntaxtextarea;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Segment;
import org.fife.ui.rsyntaxtextarea.templates.CodeTemplate;

public class CodeTemplateManager {
   private int maxTemplateIDLength;
   private List<CodeTemplate> templates = new ArrayList();
   private Segment s = new Segment();
   private CodeTemplateManager.TemplateComparator comparator = new CodeTemplateManager.TemplateComparator();
   private File directory;

   public synchronized void addTemplate(CodeTemplate template) {
      if (template == null) {
         throw new IllegalArgumentException("template cannot be null");
      } else {
         this.templates.add(template);
         this.sortTemplates();
      }
   }

   public synchronized CodeTemplate getTemplate(RSyntaxTextArea textArea) {
      int caretPos = textArea.getCaretPosition();
      int charsToGet = Math.min(caretPos, this.maxTemplateIDLength);

      try {
         Document doc = textArea.getDocument();
         doc.getText(caretPos - charsToGet, charsToGet, this.s);
         int index = Collections.binarySearch(this.templates, this.s, this.comparator);
         return index >= 0 ? (CodeTemplate)this.templates.get(index) : null;
      } catch (BadLocationException var6) {
         var6.printStackTrace();
         throw new InternalError("Error in CodeTemplateManager");
      }
   }

   private synchronized int getTemplateCount() {
      return this.templates.size();
   }

   public synchronized CodeTemplate[] getTemplates() {
      CodeTemplate[] temp = new CodeTemplate[this.templates.size()];
      return (CodeTemplate[])this.templates.toArray(temp);
   }

   private static boolean isValidChar(char ch) {
      return RSyntaxUtilities.isLetterOrDigit(ch) || ch == '_';
   }

   public synchronized boolean removeTemplate(CodeTemplate template) {
      if (template == null) {
         throw new IllegalArgumentException("template cannot be null");
      } else {
         return this.templates.remove(template);
      }
   }

   public synchronized CodeTemplate removeTemplate(String id) {
      if (id == null) {
         throw new IllegalArgumentException("id cannot be null");
      } else {
         Iterator i = this.templates.iterator();

         CodeTemplate template;
         do {
            if (!i.hasNext()) {
               return null;
            }

            template = (CodeTemplate)i.next();
         } while(!id.equals(template.getID()));

         i.remove();
         return template;
      }
   }

   public synchronized void replaceTemplates(CodeTemplate[] newTemplates) {
      this.templates.clear();
      if (newTemplates != null) {
         Collections.addAll(this.templates, newTemplates);
      }

      this.sortTemplates();
   }

   public synchronized boolean saveTemplates() {
      if (this.templates == null) {
         return true;
      } else if (this.directory != null && this.directory.isDirectory()) {
         File[] oldXMLFiles = this.directory.listFiles(new CodeTemplateManager.XMLFileFilter());
         if (oldXMLFiles == null) {
            return false;
         } else {
            int count = oldXMLFiles.length;
            File[] var3 = oldXMLFiles;
            int var4 = oldXMLFiles.length;

            File xmlFile;
            for(int var5 = 0; var5 < var4; ++var5) {
               xmlFile = var3[var5];
               xmlFile.delete();
            }

            boolean wasSuccessful = true;
            Iterator var10 = this.templates.iterator();

            while(var10.hasNext()) {
               CodeTemplate template = (CodeTemplate)var10.next();
               xmlFile = new File(this.directory, template.getID() + ".xml");

               try {
                  XMLEncoder e = new XMLEncoder(new BufferedOutputStream(new FileOutputStream(xmlFile)));
                  e.writeObject(template);
                  e.close();
               } catch (IOException var8) {
                  var8.printStackTrace();
                  wasSuccessful = false;
               }
            }

            return wasSuccessful;
         }
      } else {
         return false;
      }
   }

   public synchronized int setTemplateDirectory(File dir) {
      if (dir != null && dir.isDirectory()) {
         this.directory = dir;
         File[] files = dir.listFiles(new CodeTemplateManager.XMLFileFilter());
         int newCount = files == null ? 0 : files.length;
         int oldCount = this.templates.size();
         List<CodeTemplate> temp = new ArrayList(oldCount + newCount);
         temp.addAll(this.templates);

         for(int i = 0; i < newCount; ++i) {
            try {
               XMLDecoder d = new XMLDecoder(new BufferedInputStream(new FileInputStream(files[i])));
               Object obj = d.readObject();
               if (!(obj instanceof CodeTemplate)) {
                  d.close();
                  throw new IOException("Not a CodeTemplate: " + files[i].getAbsolutePath());
               }

               temp.add((CodeTemplate)obj);
               d.close();
            } catch (Exception var9) {
               var9.printStackTrace();
            }
         }

         this.templates = temp;
         this.sortTemplates();
         return this.getTemplateCount();
      } else {
         return -1;
      }
   }

   private synchronized void sortTemplates() {
      this.maxTemplateIDLength = 0;
      Iterator i = this.templates.iterator();

      while(true) {
         while(i.hasNext()) {
            CodeTemplate temp = (CodeTemplate)i.next();
            if (temp != null && temp.getID() != null) {
               this.maxTemplateIDLength = Math.max(this.maxTemplateIDLength, temp.getID().length());
            } else {
               i.remove();
            }
         }

         Collections.sort(this.templates);
         return;
      }
   }

   private static class XMLFileFilter implements FileFilter {
      private XMLFileFilter() {
      }

      public boolean accept(File f) {
         return f.getName().toLowerCase().endsWith(".xml");
      }

      // $FF: synthetic method
      XMLFileFilter(Object x0) {
         this();
      }
   }

   private static class TemplateComparator implements Comparator<Object>, Serializable {
      private TemplateComparator() {
      }

      public int compare(Object template, Object segment) {
         CodeTemplate t = (CodeTemplate)template;
         char[] templateArray = t.getID().toCharArray();
         int i = 0;
         int len1 = templateArray.length;
         Segment s = (Segment)segment;
         char[] segArray = s.array;
         int len2 = s.count;

         int j;
         for(j = s.offset + len2 - 1; j >= s.offset && CodeTemplateManager.isValidChar(segArray[j]); --j) {
         }

         ++j;
         int segShift = j - s.offset;
         len2 -= segShift;
         int var12 = Math.min(len1, len2);

         char c1;
         char c2;
         do {
            if (var12-- == 0) {
               return len1 - len2;
            }

            c1 = templateArray[i++];
            c2 = segArray[j++];
         } while(c1 == c2);

         return c1 - c2;
      }

      // $FF: synthetic method
      TemplateComparator(Object x0) {
         this();
      }
   }
}
