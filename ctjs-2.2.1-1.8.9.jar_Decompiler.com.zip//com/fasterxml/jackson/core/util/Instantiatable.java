package com.fasterxml.jackson.core.util;

public interface Instantiatable<T> {
   T createInstance();
}
