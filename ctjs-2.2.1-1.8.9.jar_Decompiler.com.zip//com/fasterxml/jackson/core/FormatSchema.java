package com.fasterxml.jackson.core;

public interface FormatSchema {
   String getSchemaType();
}
