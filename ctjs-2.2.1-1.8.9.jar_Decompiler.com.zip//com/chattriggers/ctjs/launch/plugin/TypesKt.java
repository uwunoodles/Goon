package com.chattriggers.ctjs.launch.plugin;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0013\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0003\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0004\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0005\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0006\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0007\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\b\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\t\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\n\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u000b\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\f\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\r\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u000e\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u000f\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0010\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0011\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0012\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0013\u001a\u00020\u0001X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0014"},
   d2 = {"BLOCK_POS", "", "CANCELLABLE_EVENT", "CLIENT_LISTENER", "CRASH_REPORT_CATEGORY", "EFFECT_RENDERER", "ENTITY", "ENTITY_FX", "ENTITY_ITEM", "ENTITY_PLAYER", "ENUM_FACING", "FILE", "FRAME_BUFFER", "GUI_CONTAINER", "ICHAT_COMPONENT", "INVENTORY_PLAYER", "ITEM_STACK", "PACKET", "TILE_ENTITY", "TRIGGER_TYPE", "ctjs"}
)
public final class TypesKt {
   @NotNull
   public static final String CANCELLABLE_EVENT = "com/chattriggers/ctjs/minecraft/listeners/CancellableEvent";
   @NotNull
   public static final String CLIENT_LISTENER = "com/chattriggers/ctjs/minecraft/listeners/ClientListener";
   @NotNull
   public static final String CRASH_REPORT_CATEGORY = "net/minecraft/crash/CrashReportCategory";
   @NotNull
   public static final String EFFECT_RENDERER = "net/minecraft/client/particle/EffectRenderer";
   @NotNull
   public static final String ENTITY = "net/minecraft/entity/Entity";
   @NotNull
   public static final String ENTITY_FX = "net/minecraft/client/particle/EntityFX";
   @NotNull
   public static final String ENTITY_ITEM = "net/minecraft/entity/item/EntityItem";
   @NotNull
   public static final String ENTITY_PLAYER = "net/minecraft/entity/player/EntityPlayer";
   @NotNull
   public static final String FILE = "java/io/File";
   @NotNull
   public static final String FRAME_BUFFER = "net/minecraft/client/shader/Framebuffer";
   @NotNull
   public static final String ICHAT_COMPONENT = "net/minecraft/util/IChatComponent";
   @NotNull
   public static final String INVENTORY_PLAYER = "net/minecraft/entity/player/InventoryPlayer";
   @NotNull
   public static final String ITEM_STACK = "net/minecraft/item/ItemStack";
   @NotNull
   public static final String PACKET = "net/minecraft/network/Packet";
   @NotNull
   public static final String BLOCK_POS = "net/minecraft/util/BlockPos";
   @NotNull
   public static final String ENUM_FACING = "net/minecraft/util/EnumFacing";
   @NotNull
   public static final String TRIGGER_TYPE = "com/chattriggers/ctjs/triggers/TriggerType";
   @NotNull
   public static final String TILE_ENTITY = "net/minecraft/tileentity/TileEntity";
   @NotNull
   public static final String GUI_CONTAINER = "net/minecraft/client/gui/inventory/GuiContainer";
}
