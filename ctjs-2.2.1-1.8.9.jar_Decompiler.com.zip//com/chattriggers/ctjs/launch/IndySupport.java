package com.chattriggers.ctjs.launch;

import com.chattriggers.ctjs.engine.module.ModuleManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.SwitchPoint;
import java.lang.invoke.MethodHandles.Lookup;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J0\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\nH\u0007J7\u0010\u000f\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\r\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\n2\u000e\u0010\u0012\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00010\u0013H\u0007¢\u0006\u0002\u0010\u0014J\u0006\u0010\u0015\u001a\u00020\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0017"},
   d2 = {"Lcom/chattriggers/ctjs/launch/IndySupport;", "", "()V", "invocationInvalidator", "Ljava/lang/invoke/SwitchPoint;", "bootstrapInvokeJS", "Ljava/lang/invoke/CallSite;", "lookup", "Ljava/lang/invoke/MethodHandles$Lookup;", "name", "", "type", "Ljava/lang/invoke/MethodType;", "moduleName", "functionID", "initInvokeJS", "callSite", "Ljava/lang/invoke/MutableCallSite;", "args", "", "(Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", "invalidateInvocations", "", "ctjs"}
)
public final class IndySupport {
   @NotNull
   public static final IndySupport INSTANCE = new IndySupport();
   @NotNull
   private static SwitchPoint invocationInvalidator = new SwitchPoint();

   private IndySupport() {
   }

   @JvmStatic
   @NotNull
   public static final CallSite bootstrapInvokeJS(@NotNull Lookup lookup, @NotNull String name, @NotNull MethodType type, @NotNull String moduleName, @NotNull String functionID) {
      Intrinsics.checkNotNullParameter(lookup, "lookup");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(type, "type");
      Intrinsics.checkNotNullParameter(moduleName, "moduleName");
      Intrinsics.checkNotNullParameter(functionID, "functionID");
      MutableCallSite callSite = new MutableCallSite(type);
      Class[] var7 = new Class[]{String.class, String.class, Object[].class};
      MethodHandle var10000 = lookup.findStatic(IndySupport.class, "initInvokeJS", MethodType.methodType(Object.class, MutableCallSite.class, var7));
      Object[] var8 = new Object[]{callSite, moduleName, functionID};
      MethodHandle initHandle = MethodHandles.insertArguments(var10000, 0, var8);
      callSite.setTarget(initHandle.asType(type));
      return (CallSite)callSite;
   }

   @JvmStatic
   @Nullable
   public static final Object initInvokeJS(@NotNull MutableCallSite callSite, @NotNull String moduleName, @NotNull String functionID, @NotNull Object[] args) {
      Intrinsics.checkNotNullParameter(callSite, "callSite");
      Intrinsics.checkNotNullParameter(moduleName, "moduleName");
      Intrinsics.checkNotNullParameter(functionID, "functionID");
      Intrinsics.checkNotNullParameter(args, "args");
      MethodHandle targetHandle = ModuleManager.INSTANCE.asmInvokeLookup(moduleName, functionID);
      MethodHandle initTarget = callSite.getTarget();
      MethodHandle guardedTarget = invocationInvalidator.guardWithTest(targetHandle, initTarget);
      callSite.setTarget(guardedTarget);
      return targetHandle.invoke(args);
   }

   public final void invalidateInvocations() {
      SwitchPoint[] var1 = new SwitchPoint[]{invocationInvalidator};
      SwitchPoint.invalidateAll(var1);
      invocationInvalidator = new SwitchPoint();
   }
}
