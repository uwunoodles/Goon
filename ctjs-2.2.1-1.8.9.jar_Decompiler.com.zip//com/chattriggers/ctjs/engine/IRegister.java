package com.chattriggers.ctjs.engine;

import com.chattriggers.ctjs.triggers.ChatTrigger;
import com.chattriggers.ctjs.triggers.CommandTrigger;
import com.chattriggers.ctjs.triggers.EventTrigger;
import com.chattriggers.ctjs.triggers.ForgeTrigger;
import com.chattriggers.ctjs.triggers.PacketTrigger;
import com.chattriggers.ctjs.triggers.RegularTrigger;
import com.chattriggers.ctjs.triggers.RenderEntityTrigger;
import com.chattriggers.ctjs.triggers.RenderTileEntityTrigger;
import com.chattriggers.ctjs.triggers.SoundPlayTrigger;
import com.chattriggers.ctjs.triggers.StepTrigger;
import com.chattriggers.ctjs.triggers.Trigger;
import com.chattriggers.ctjs.triggers.TriggerType;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KFunction;
import kotlin.reflect.full.KClasses;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\bf\u0018\u0000 [2\u00020\u0001:\u0001[J\b\u0010\u0002\u001a\u00020\u0003H&J\u0018\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00012\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\f\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u000e\u001a\u00020\t2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u000f\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u0010\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u0011\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u0014\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u0015\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u0016\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u0017\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u0018\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u0019\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u001a\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u001b\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u001c\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u001d\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u001e\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\u001f\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010 \u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010!\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010\"\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010#\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010$\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010%\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010&\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010'\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010(\u001a\u00020)2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010*\u001a\u00020)2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010+\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010,\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010-\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010.\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010/\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u00100\u001a\u0002012\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u00102\u001a\u0002032\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u00104\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u00105\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u00106\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u00107\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u00108\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u00109\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010:\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010;\u001a\u0002012\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010<\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010=\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010>\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010?\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010@\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010A\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010B\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010C\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010D\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010E\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010F\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010G\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010H\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010I\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010J\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010K\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010L\u001a\u0002032\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010M\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010N\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010O\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010P\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010Q\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010R\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010S\u001a\u00020T2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010U\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010V\u001a\u00020W2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010X\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010Y\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016J\u0010\u0010Z\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0001H\u0016¨\u0006\\"},
   d2 = {"Lcom/chattriggers/ctjs/engine/IRegister;", "", "getImplementationLoader", "Lcom/chattriggers/ctjs/engine/ILoader;", "register", "Lcom/chattriggers/ctjs/triggers/Trigger;", "triggerType", "method", "registerActionBar", "Lcom/chattriggers/ctjs/triggers/ChatTrigger;", "registerAttackEntity", "Lcom/chattriggers/ctjs/triggers/EventTrigger;", "registerBlockBreak", "Lcom/chattriggers/ctjs/triggers/RegularTrigger;", "registerChat", "registerChatComponentClicked", "registerChatComponentHovered", "registerClicked", "registerCommand", "Lcom/chattriggers/ctjs/triggers/CommandTrigger;", "registerDragged", "registerDrawBlockHighlight", "registerDropItem", "registerEntityDamage", "registerEntityDeath", "registerGameLoad", "registerGameUnload", "registerGuiClosed", "registerGuiDrawBackground", "registerGuiKey", "registerGuiMouseClick", "registerGuiMouseDrag", "registerGuiMouseRelease", "registerGuiOpened", "registerGuiRender", "registerHitBlock", "registerItemTooltip", "registerMessageSent", "registerNoteBlockChange", "registerNoteBlockPlay", "registerPacketReceived", "Lcom/chattriggers/ctjs/triggers/PacketTrigger;", "registerPacketSent", "registerPickupItem", "registerPlayerInteract", "registerPlayerJoined", "registerPlayerLeft", "registerPostGuiRender", "registerPostRenderEntity", "Lcom/chattriggers/ctjs/triggers/RenderEntityTrigger;", "registerPostRenderTileEntity", "Lcom/chattriggers/ctjs/triggers/RenderTileEntityTrigger;", "registerPreItemRender", "registerRenderAir", "registerRenderArmor", "registerRenderBossHealth", "registerRenderChat", "registerRenderCrosshair", "registerRenderDebug", "registerRenderEntity", "registerRenderExperience", "registerRenderFood", "registerRenderHand", "registerRenderHealth", "registerRenderHelmet", "registerRenderHotbar", "registerRenderItemIntoGui", "registerRenderItemOverlayIntoGui", "registerRenderJumpBar", "registerRenderMountHealth", "registerRenderOverlay", "registerRenderPlayerList", "registerRenderPortal", "registerRenderScoreboard", "registerRenderSlot", "registerRenderSlotHighlight", "registerRenderTileEntity", "registerRenderTitle", "registerRenderWorld", "registerScreenshotTaken", "registerScrolled", "registerServerConnect", "registerServerDisconnect", "registerSoundPlay", "Lcom/chattriggers/ctjs/triggers/SoundPlayTrigger;", "registerSpawnParticle", "registerStep", "Lcom/chattriggers/ctjs/triggers/StepTrigger;", "registerTick", "registerWorldLoad", "registerWorldUnload", "Companion", "ctjs"}
)
public interface IRegister {
   @NotNull
   IRegister.Companion Companion = IRegister.Companion.$$INSTANCE;

   @NotNull
   Trigger register(@NotNull Object var1, @NotNull Object var2);

   @NotNull
   ChatTrigger registerChat(@NotNull Object var1);

   @NotNull
   ChatTrigger registerActionBar(@NotNull Object var1);

   @NotNull
   RegularTrigger registerWorldLoad(@NotNull Object var1);

   @NotNull
   RegularTrigger registerWorldUnload(@NotNull Object var1);

   @NotNull
   RegularTrigger registerClicked(@NotNull Object var1);

   @NotNull
   RegularTrigger registerScrolled(@NotNull Object var1);

   @NotNull
   RegularTrigger registerDragged(@NotNull Object var1);

   @NotNull
   SoundPlayTrigger registerSoundPlay(@NotNull Object var1);

   @NotNull
   EventTrigger registerNoteBlockPlay(@NotNull Object var1);

   @NotNull
   EventTrigger registerNoteBlockChange(@NotNull Object var1);

   @NotNull
   RegularTrigger registerTick(@NotNull Object var1);

   @NotNull
   StepTrigger registerStep(@NotNull Object var1);

   @NotNull
   RegularTrigger registerRenderWorld(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderOverlay(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderPlayerList(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderCrosshair(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderDebug(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderBossHealth(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderHealth(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderArmor(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderFood(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderMountHealth(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderExperience(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderHotbar(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderAir(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderPortal(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderJumpBar(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderChat(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderHelmet(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderHand(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderScoreboard(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderTitle(@NotNull Object var1);

   @NotNull
   EventTrigger registerDrawBlockHighlight(@NotNull Object var1);

   @NotNull
   RegularTrigger registerGameLoad(@NotNull Object var1);

   @NotNull
   RegularTrigger registerGameUnload(@NotNull Object var1);

   @NotNull
   CommandTrigger registerCommand(@NotNull Object var1);

   @NotNull
   EventTrigger registerGuiOpened(@NotNull Object var1);

   @NotNull
   RegularTrigger registerGuiClosed(@NotNull Object var1);

   @NotNull
   RegularTrigger registerPlayerJoined(@NotNull Object var1);

   @NotNull
   RegularTrigger registerPlayerLeft(@NotNull Object var1);

   @NotNull
   EventTrigger registerPickupItem(@NotNull Object var1);

   @NotNull
   EventTrigger registerDropItem(@NotNull Object var1);

   @NotNull
   EventTrigger registerScreenshotTaken(@NotNull Object var1);

   @NotNull
   EventTrigger registerMessageSent(@NotNull Object var1);

   @NotNull
   EventTrigger registerItemTooltip(@NotNull Object var1);

   @NotNull
   EventTrigger registerPlayerInteract(@NotNull Object var1);

   @NotNull
   RegularTrigger registerBlockBreak(@NotNull Object var1);

   @NotNull
   RegularTrigger registerEntityDamage(@NotNull Object var1);

   @NotNull
   RegularTrigger registerEntityDeath(@NotNull Object var1);

   @NotNull
   EventTrigger registerGuiDrawBackground(@NotNull Object var1);

   @NotNull
   RegularTrigger registerGuiRender(@NotNull Object var1);

   @NotNull
   EventTrigger registerGuiKey(@NotNull Object var1);

   @NotNull
   EventTrigger registerGuiMouseClick(@NotNull Object var1);

   @NotNull
   EventTrigger registerGuiMouseRelease(@NotNull Object var1);

   @NotNull
   EventTrigger registerGuiMouseDrag(@NotNull Object var1);

   @NotNull
   PacketTrigger registerPacketSent(@NotNull Object var1);

   @NotNull
   PacketTrigger registerPacketReceived(@NotNull Object var1);

   @NotNull
   EventTrigger registerServerConnect(@NotNull Object var1);

   @NotNull
   RegularTrigger registerServerDisconnect(@NotNull Object var1);

   @NotNull
   EventTrigger registerChatComponentClicked(@NotNull Object var1);

   @NotNull
   EventTrigger registerChatComponentHovered(@NotNull Object var1);

   @NotNull
   RenderEntityTrigger registerRenderEntity(@NotNull Object var1);

   @NotNull
   RenderEntityTrigger registerPostRenderEntity(@NotNull Object var1);

   @NotNull
   RenderTileEntityTrigger registerRenderTileEntity(@NotNull Object var1);

   @NotNull
   RenderTileEntityTrigger registerPostRenderTileEntity(@NotNull Object var1);

   @NotNull
   RegularTrigger registerPostGuiRender(@NotNull Object var1);

   @NotNull
   RegularTrigger registerPreItemRender(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderSlot(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderItemIntoGui(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderItemOverlayIntoGui(@NotNull Object var1);

   @NotNull
   EventTrigger registerRenderSlotHighlight(@NotNull Object var1);

   @NotNull
   EventTrigger registerSpawnParticle(@NotNull Object var1);

   @NotNull
   EventTrigger registerAttackEntity(@NotNull Object var1);

   @NotNull
   EventTrigger registerHitBlock(@NotNull Object var1);

   @NotNull
   ILoader getImplementationLoader();

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010%\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u001e\u0010\u0003\u001a\u0012\u0012\u0004\u0012\u00020\u0005\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00060\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0007"},
      d2 = {"Lcom/chattriggers/ctjs/engine/IRegister$Companion;", "", "()V", "methodMap", "", "", "Lkotlin/reflect/KFunction;", "ctjs"}
   )
   public static final class Companion {
      // $FF: synthetic field
      static final IRegister.Companion $$INSTANCE = new IRegister.Companion();
      @NotNull
      private static final Map<String, KFunction<?>> methodMap = (Map)(new LinkedHashMap());

      private Companion() {
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public static final class DefaultImpls {
      @NotNull
      public static Trigger register(@NotNull IRegister var0, @NotNull Object triggerType, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(triggerType, "triggerType");
         Intrinsics.checkNotNullParameter(method, "method");
         if (triggerType instanceof Class) {
            return (Trigger)(new ForgeTrigger(method, (Class)triggerType, var0.getImplementationLoader()));
         } else if (!(triggerType instanceof String)) {
            int var18 = false;
            String var19 = "register() expects a String or Class as its first argument";
            throw new IllegalArgumentException(var19.toString());
         } else {
            Map $this$getOrPut$iv = IRegister.Companion.methodMap;
            int $i$f$getOrPut = false;
            Object value$iv = $this$getOrPut$iv.get(triggerType);
            Object var20;
            if (value$iv == null) {
               int var8 = false;
               String var10000 = ((String)triggerType).toLowerCase(Locale.ROOT);
               Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String).toLowerCase(Locale.ROOT)");
               String name = var10000;
               Iterable $this$firstOrNull$iv = (Iterable)KClasses.getMemberFunctions(Reflection.getOrCreateKotlinClass(var0.getClass()));
               int $i$f$firstOrNull = false;
               Iterator var12 = $this$firstOrNull$iv.iterator();

               while(true) {
                  if (!var12.hasNext()) {
                     var20 = null;
                     break;
                  }

                  Object element$iv = var12.next();
                  KFunction it = (KFunction)element$iv;
                  int var15 = false;
                  var10000 = it.getName().toLowerCase(Locale.ROOT);
                  Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String).toLowerCase(Locale.ROOT)");
                  if (Intrinsics.areEqual(var10000, Intrinsics.stringPlus("register", name))) {
                     var20 = element$iv;
                     break;
                  }
               }

               KFunction var16 = (KFunction)var20;
               if (var16 == null) {
                  throw new NoSuchMethodException("No trigger type named '" + triggerType + '\'');
               }

               $this$getOrPut$iv.put(triggerType, var16);
               var20 = var16;
            } else {
               var20 = value$iv;
            }

            KFunction func = (KFunction)var20;
            Object[] var5 = new Object[]{var0, method};
            var20 = func.call(var5);
            if (var20 == null) {
               throw new NullPointerException("null cannot be cast to non-null type com.chattriggers.ctjs.triggers.Trigger");
            } else {
               return (Trigger)var20;
            }
         }
      }

      @NotNull
      public static ChatTrigger registerChat(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new ChatTrigger(method, TriggerType.Chat, var0.getImplementationLoader());
      }

      @NotNull
      public static ChatTrigger registerActionBar(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new ChatTrigger(method, TriggerType.ActionBar, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerWorldLoad(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.WorldLoad, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerWorldUnload(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.WorldUnload, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerClicked(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.Clicked, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerScrolled(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.Scrolled, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerDragged(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.Dragged, var0.getImplementationLoader());
      }

      @NotNull
      public static SoundPlayTrigger registerSoundPlay(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new SoundPlayTrigger(method, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerNoteBlockPlay(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.NoteBlockPlay, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerNoteBlockChange(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.NoteBlockChange, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerTick(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.Tick, var0.getImplementationLoader());
      }

      @NotNull
      public static StepTrigger registerStep(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new StepTrigger(method, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerRenderWorld(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.RenderWorld, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderOverlay(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderOverlay, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderPlayerList(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderPlayerList, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderCrosshair(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderCrosshair, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderDebug(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderDebug, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderBossHealth(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderBossHealth, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderHealth(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderHealth, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderArmor(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderArmor, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderFood(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderFood, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderMountHealth(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderMountHealth, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderExperience(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderExperience, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderHotbar(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderHotbar, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderAir(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderAir, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderPortal(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderPortal, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderJumpBar(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderJumpBar, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderChat(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderChat, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderHelmet(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderHelmet, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderHand(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderHand, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderScoreboard(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderScoreboard, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderTitle(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderTitle, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerDrawBlockHighlight(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.BlockHighlight, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerGameLoad(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.GameLoad, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerGameUnload(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.GameUnload, var0.getImplementationLoader());
      }

      @NotNull
      public static CommandTrigger registerCommand(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new CommandTrigger(method, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerGuiOpened(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.GuiOpened, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerGuiClosed(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.GuiClosed, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerPlayerJoined(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.PlayerJoin, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerPlayerLeft(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.PlayerLeave, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerPickupItem(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.PickupItem, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerDropItem(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.DropItem, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerScreenshotTaken(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.ScreenshotTaken, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerMessageSent(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.MessageSent, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerItemTooltip(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.Tooltip, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerPlayerInteract(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.PlayerInteract, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerBlockBreak(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.BlockBreak, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerEntityDamage(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.EntityDamage, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerEntityDeath(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.EntityDeath, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerGuiDrawBackground(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.GuiDrawBackground, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerGuiRender(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.GuiRender, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerGuiKey(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.GuiKey, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerGuiMouseClick(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.GuiMouseClick, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerGuiMouseRelease(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.GuiMouseRelease, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerGuiMouseDrag(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.GuiMouseDrag, var0.getImplementationLoader());
      }

      @NotNull
      public static PacketTrigger registerPacketSent(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new PacketTrigger(method, TriggerType.PacketSent, var0.getImplementationLoader());
      }

      @NotNull
      public static PacketTrigger registerPacketReceived(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new PacketTrigger(method, TriggerType.PacketReceived, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerServerConnect(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.ServerConnect, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerServerDisconnect(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.ServerDisconnect, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerChatComponentClicked(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.ChatComponentClicked, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerChatComponentHovered(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.ChatComponentHovered, var0.getImplementationLoader());
      }

      @NotNull
      public static RenderEntityTrigger registerRenderEntity(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RenderEntityTrigger(method, TriggerType.RenderEntity, var0.getImplementationLoader());
      }

      @NotNull
      public static RenderEntityTrigger registerPostRenderEntity(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RenderEntityTrigger(method, TriggerType.PostRenderEntity, var0.getImplementationLoader());
      }

      @NotNull
      public static RenderTileEntityTrigger registerRenderTileEntity(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RenderTileEntityTrigger(method, TriggerType.RenderTileEntity, var0.getImplementationLoader());
      }

      @NotNull
      public static RenderTileEntityTrigger registerPostRenderTileEntity(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RenderTileEntityTrigger(method, TriggerType.PostRenderTileEntity, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerPostGuiRender(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.PostGuiRender, var0.getImplementationLoader());
      }

      @NotNull
      public static RegularTrigger registerPreItemRender(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new RegularTrigger(method, TriggerType.PreItemRender, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderSlot(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderSlot, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderItemIntoGui(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderItemIntoGui, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderItemOverlayIntoGui(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderItemOverlayIntoGui, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerRenderSlotHighlight(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.RenderSlotHighlight, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerSpawnParticle(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.SpawnParticle, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerAttackEntity(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.AttackEntity, var0.getImplementationLoader());
      }

      @NotNull
      public static EventTrigger registerHitBlock(@NotNull IRegister var0, @NotNull Object method) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(method, "method");
         return new EventTrigger(method, TriggerType.HitBlock, var0.getImplementationLoader());
      }
   }
}
