package com.chattriggers.ctjs.engine;

import com.chattriggers.ctjs.engine.langs.Lang;
import com.chattriggers.ctjs.engine.module.Module;
import com.chattriggers.ctjs.triggers.Trigger;
import com.chattriggers.ctjs.triggers.TriggerType;
import com.chattriggers.ctjs.utils.console.Console;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.invoke.MethodHandle;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.List;
import kotlin.Metadata;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import org.apache.commons.io.FileUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH&J\u0018\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fH&J\u0018\u0010\u0010\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u0011\u001a\u00020\u000fH&J\b\u0010\u0012\u001a\u00020\u0007H&J\b\u0010\u0013\u001a\u00020\u0007H&J\u0018\u0010\u0014\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u0015\u001a\u00020\u000fH&J\b\u0010\u0016\u001a\u00020\u0007H&J\u0010\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u0018H&J'\u0010\u001a\u001a\u00020\u00072\u0006\u0010\u001b\u001a\u00020\u001c2\u0010\u0010\u001d\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u00010\u001eH&¢\u0006\u0002\u0010\u001fJ\b\u0010 \u001a\u00020!H&J\u0010\u0010\"\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH&J\"\u0010#\u001a\u00020\u00182\b\u0010$\u001a\u0004\u0018\u00010\u00182\u0006\u0010%\u001a\u00020&2\u0006\u0010'\u001a\u00020(H\u0016J\u0016\u0010)\u001a\u00020\u00072\f\u0010*\u001a\b\u0012\u0004\u0012\u00020,0+H&J/\u0010\b\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010-\u001a\u00020\u00012\u0010\u0010\u001d\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u00010\u001eH&¢\u0006\u0002\u0010.R\u0012\u0010\u0002\u001a\u00020\u0003X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0004\u0010\u0005¨\u0006/"},
   d2 = {"Lcom/chattriggers/ctjs/engine/ILoader;", "", "console", "Lcom/chattriggers/ctjs/utils/console/Console;", "getConsole", "()Lcom/chattriggers/ctjs/utils/console/Console;", "addTrigger", "", "trigger", "Lcom/chattriggers/ctjs/triggers/Trigger;", "asmInvokeLookup", "Ljava/lang/invoke/MethodHandle;", "module", "Lcom/chattriggers/ctjs/engine/module/Module;", "functionURI", "Ljava/net/URI;", "asmPass", "asmURI", "asmSetup", "clearTriggers", "entryPass", "entryURI", "entrySetup", "eval", "", "code", "exec", "type", "Lcom/chattriggers/ctjs/triggers/TriggerType;", "args", "", "(Lcom/chattriggers/ctjs/triggers/TriggerType;[Ljava/lang/Object;)V", "getLanguage", "Lcom/chattriggers/ctjs/engine/langs/Lang;", "removeTrigger", "saveResource", "resourceName", "outputFile", "Ljava/io/File;", "replace", "", "setup", "jars", "", "Ljava/net/URL;", "method", "(Lcom/chattriggers/ctjs/triggers/Trigger;Ljava/lang/Object;[Ljava/lang/Object;)V", "ctjs"}
)
public interface ILoader {
   @NotNull
   Console getConsole();

   void setup(@NotNull List<URL> var1);

   void asmSetup();

   void asmPass(@NotNull Module var1, @NotNull URI var2);

   void entrySetup();

   void entryPass(@NotNull Module var1, @NotNull URI var2);

   @NotNull
   MethodHandle asmInvokeLookup(@NotNull Module var1, @NotNull URI var2);

   void exec(@NotNull TriggerType var1, @NotNull Object[] var2);

   @NotNull
   String eval(@NotNull String var1);

   void addTrigger(@NotNull Trigger var1);

   void clearTriggers();

   @NotNull
   Lang getLanguage();

   void trigger(@NotNull Trigger var1, @NotNull Object var2, @NotNull Object[] var3);

   void removeTrigger(@NotNull Trigger var1);

   @NotNull
   String saveResource(@Nullable String var1, @NotNull File var2, boolean var3);

   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public static final class DefaultImpls {
      @NotNull
      public static String saveResource(@NotNull ILoader var0, @Nullable String resourceName, @NotNull File outputFile, boolean replace) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(outputFile, "outputFile");
         if (resourceName == null || Intrinsics.areEqual(resourceName, "")) {
            int var5 = false;
            String var11 = "ResourcePath cannot be null or empty";
            throw new IllegalArgumentException(var11.toString());
         } else {
            String parsedResourceName = StringsKt.replace$default(resourceName, '\\', '/', false, 4, (Object)null);
            InputStream var6 = var0.getClass().getResourceAsStream(parsedResourceName);
            if (var6 == null) {
               throw new IllegalArgumentException("The embedded resource '" + parsedResourceName + "' cannot be found.");
            } else {
               Charset var8 = Charsets.UTF_8;
               Reader var9 = (Reader)(new InputStreamReader(var6, var8));
               short var10 = 8192;
               String res = TextStreamsKt.readText((Reader)(var9 instanceof BufferedReader ? (BufferedReader)var9 : new BufferedReader(var9, var10)));
               FileUtils.write(outputFile, (CharSequence)res);
               return res;
            }
         }
      }
   }
}
