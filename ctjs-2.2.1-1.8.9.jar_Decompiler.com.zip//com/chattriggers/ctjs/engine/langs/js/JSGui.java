package com.chattriggers.ctjs.engine.langs.js;

import com.chattriggers.ctjs.engine.ILoader;
import com.chattriggers.ctjs.minecraft.objects.gui.Gui;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\r\u0010\u0003\u001a\u00020\u0004H\u0010¢\u0006\u0002\b\u0005¨\u0006\u0006"},
   d2 = {"Lcom/chattriggers/ctjs/engine/langs/js/JSGui;", "Lcom/chattriggers/ctjs/minecraft/objects/gui/Gui;", "()V", "getLoader", "Lcom/chattriggers/ctjs/engine/ILoader;", "getLoader$ctjs", "ctjs"}
)
public final class JSGui extends Gui {
   @NotNull
   public ILoader getLoader$ctjs() {
      return (ILoader)JSLoader.INSTANCE;
   }
}
