package com.chattriggers.ctjs.engine.langs.js;

import com.chattriggers.ctjs.ReferenceKt;
import com.chattriggers.ctjs.engine.ILoader;
import com.chattriggers.ctjs.engine.langs.Lang;
import com.chattriggers.ctjs.engine.module.Module;
import com.chattriggers.ctjs.engine.module.ModuleManager;
import com.chattriggers.ctjs.triggers.Trigger;
import com.chattriggers.ctjs.triggers.TriggerType;
import com.chattriggers.ctjs.utils.console.Console;
import com.chattriggers.ctjs.utils.console.LogType;
import dev.falsehonesty.asmhelper.dsl.At;
import dev.falsehonesty.asmhelper.dsl.Method;
import dev.falsehonesty.asmhelper.dsl.instructions.InsnListBuilder;
import dev.falsehonesty.asmhelper.dsl.writers.AccessType;
import dev.falsehonesty.asmhelper.dsl.writers.FieldWriter;
import dev.falsehonesty.asmhelper.dsl.writers.InjectWriter;
import dev.falsehonesty.asmhelper.dsl.writers.RemoveWriter;
import java.io.File;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles.Lookup;
import java.net.URI;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentSkipListSet;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mozilla.javascript.Callable;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.ImporterTopLevel;
import org.mozilla.javascript.NativeJavaObject;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Wrapper;
import org.mozilla.javascript.commonjs.module.ModuleScriptProvider;
import org.mozilla.javascript.commonjs.module.Require;
import org.mozilla.javascript.commonjs.module.provider.ModuleSourceProvider;
import org.mozilla.javascript.commonjs.module.provider.StrongCachingModuleScriptProvider;
import org.mozilla.javascript.commonjs.module.provider.UrlModuleSourceProvider;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000¼\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010$\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001]B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u0019H\u0016J8\u0010\u001d\u001a\u00020\u001b2\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u001f2\u0006\u0010!\u001a\u00020\u001f2\b\u0010\"\u001a\u0004\u0018\u00010\u00042\f\u0010#\u001a\b\u0012\u0004\u0012\u00020%0$H\u0007Jd\u0010&\u001a\u00020\u001b2\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010'\u001a\u00020(2\u0006\u0010)\u001a\u00020\u001f2\u0006\u0010*\u001a\u00020\u001f2\u0012\u0010+\u001a\u000e\u0012\u0004\u0012\u00020\u001f\u0012\u0004\u0012\u00020\u001f0,2\u0012\u0010-\u001a\u000e\u0012\u0004\u0012\u00020\u001f\u0012\u0004\u0012\u00020\u001f0,2\u0012\u0010.\u001a\u000e\u0012\u0004\u0012\u000200\u0012\u0004\u0012\u00020\u001b0/H\u0007J%\u00101\u001a\u00020\u00042\u0006\u00102\u001a\u0002032\u000e\u00104\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000405H\u0007¢\u0006\u0002\u00106J\u0018\u00107\u001a\u00020\u00062\u0006\u00108\u001a\u0002092\u0006\u0010:\u001a\u00020;H\u0016J\u0018\u0010<\u001a\u00020\u001b2\u0006\u00108\u001a\u0002092\u0006\u0010=\u001a\u00020;H\u0016JD\u0010>\u001a\u00020\u001b2\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010'\u001a\u00020(2\u0006\u0010)\u001a\u00020\u001f2\u0006\u0010*\u001a\u00020\u001f2\u0012\u0010-\u001a\u000e\u0012\u0004\u0012\u00020\u001f\u0012\u0004\u0012\u00020\u001f0,2\u0006\u0010?\u001a\u00020@H\u0007J\b\u0010A\u001a\u00020\u001bH\u0016J\b\u0010B\u001a\u00020\u001bH\u0016J\u0018\u0010C\u001a\u00020\u001b2\u0006\u00108\u001a\u0002092\u0006\u0010D\u001a\u00020;H\u0016J\b\u0010E\u001a\u00020\u001bH\u0016J\u0010\u0010F\u001a\u00020\u001f2\u0006\u0010G\u001a\u00020\u001fH\u0016J'\u0010H\u001a\u00020\u001b2\u0006\u0010I\u001a\u00020\u00172\u0010\u00104\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u000405H\u0016¢\u0006\u0002\u0010JJ\b\u0010K\u001a\u00020LH\u0016J\u0016\u0010M\u001a\u00020\u001b2\f\u0010N\u001a\b\u0012\u0004\u0012\u00020O0$H\u0002J\u000e\u0010P\u001a\b\u0012\u0004\u0012\u00020\u00190\u0018H\u0002J\u0010\u0010Q\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u0019H\u0016J\u0016\u0010R\u001a\u00020\u001b2\f\u0010S\u001a\b\u0012\u0004\u0012\u00020O0$H\u0016J/\u0010\u001c\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u00192\u0006\u0010T\u001a\u00020\u00042\u0010\u00104\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u000405H\u0016¢\u0006\u0002\u0010UJ@\u0010V\u001a\u0002HW\"\u0004\b\u0000\u0010W2\b\b\u0002\u0010X\u001a\u00020\u000f2\u000e\b\u0004\u0010Y\u001a\b\u0012\u0004\u0012\u0002HW0ZH\u0080\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0001¢\u0006\u0004\b[\u0010\\R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082.¢\u0006\u0002\n\u0000R\u0016\u0010\u0005\u001a\n \u0007*\u0004\u0018\u00010\u00060\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u001b\u0010\b\u001a\u00020\t8VX\u0096\u0084\u0002¢\u0006\f\n\u0004\b\f\u0010\r\u001a\u0004\b\n\u0010\u000bR\u000e\u0010\u000e\u001a\u00020\u000fX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u000fX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082.¢\u0006\u0002\n\u0000R \u0010\u0015\u001a\u0014\u0012\u0004\u0012\u00020\u0017\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00190\u00180\u0016X\u0082\u0004¢\u0006\u0002\n\u0000\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006^"},
   d2 = {"Lcom/chattriggers/ctjs/engine/langs/js/JSLoader;", "Lcom/chattriggers/ctjs/engine/ILoader;", "()V", "ASMLib", "", "INVOKE_JS_CALL", "Ljava/lang/invoke/MethodHandle;", "kotlin.jvm.PlatformType", "console", "Lcom/chattriggers/ctjs/utils/console/Console;", "getConsole", "()Lcom/chattriggers/ctjs/utils/console/Console;", "console$delegate", "Lkotlin/Lazy;", "evalContext", "Lorg/mozilla/javascript/Context;", "moduleContext", "require", "Lcom/chattriggers/ctjs/engine/langs/js/JSLoader$CTRequire;", "scope", "Lorg/mozilla/javascript/Scriptable;", "triggers", "Ljava/util/concurrent/ConcurrentHashMap;", "Lcom/chattriggers/ctjs/triggers/TriggerType;", "Ljava/util/concurrent/ConcurrentSkipListSet;", "Lcom/chattriggers/ctjs/triggers/Trigger;", "addTrigger", "", "trigger", "asmFieldHelper", "_className", "", "_fieldName", "_fieldDesc", "_initialValue", "_accessTypes", "", "Ldev/falsehonesty/asmhelper/dsl/writers/AccessType;", "asmInjectHelper", "_at", "Ldev/falsehonesty/asmhelper/dsl/At;", "_methodName", "_methodDesc", "_fieldMaps", "", "_methodMaps", "_insnList", "Lkotlin/Function1;", "Lorg/mozilla/javascript/Wrapper;", "asmInvoke", "func", "Lorg/mozilla/javascript/Callable;", "args", "", "(Lorg/mozilla/javascript/Callable;[Ljava/lang/Object;)Ljava/lang/Object;", "asmInvokeLookup", "module", "Lcom/chattriggers/ctjs/engine/module/Module;", "functionURI", "Ljava/net/URI;", "asmPass", "asmURI", "asmRemoveHelper", "_numberToRemove", "", "asmSetup", "clearTriggers", "entryPass", "entryURI", "entrySetup", "eval", "code", "exec", "type", "(Lcom/chattriggers/ctjs/triggers/TriggerType;[Ljava/lang/Object;)V", "getLanguage", "Lcom/chattriggers/ctjs/engine/langs/Lang;", "instanceContexts", "files", "Ljava/net/URL;", "newTriggerSet", "removeTrigger", "setup", "jars", "method", "(Lcom/chattriggers/ctjs/triggers/Trigger;Ljava/lang/Object;[Ljava/lang/Object;)V", "wrapInContext", "T", "context", "block", "Lkotlin/Function0;", "wrapInContext$ctjs", "(Lorg/mozilla/javascript/Context;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "CTRequire", "ctjs"}
)
public final class JSLoader implements ILoader {
   @NotNull
   public static final JSLoader INSTANCE = new JSLoader();
   @NotNull
   private static final ConcurrentHashMap<TriggerType, ConcurrentSkipListSet<Trigger>> triggers = new ConcurrentHashMap();
   @NotNull
   private static final Lazy console$delegate;
   private static Context moduleContext;
   private static Context evalContext;
   private static Scriptable scope;
   private static JSLoader.CTRequire require;
   private static Object ASMLib;
   private static final MethodHandle INVOKE_JS_CALL;

   private JSLoader() {
   }

   @NotNull
   public Console getConsole() {
      Lazy var1 = console$delegate;
      return (Console)var1.getValue();
   }

   public void exec(@NotNull TriggerType type, @NotNull Object[] args) {
      Intrinsics.checkNotNullParameter(type, "type");
      Intrinsics.checkNotNullParameter(args, "args");
      ConcurrentSkipListSet var10000 = (ConcurrentSkipListSet)triggers.get(type);
      if (var10000 != null) {
         Iterable $this$forEach$iv = (Iterable)var10000;
         int $i$f$forEach = false;
         Iterator var5 = $this$forEach$iv.iterator();

         while(var5.hasNext()) {
            Object element$iv = var5.next();
            Trigger it = (Trigger)element$iv;
            int var8 = false;
            it.trigger(args);
         }
      }

   }

   public void addTrigger(@NotNull Trigger trigger) {
      Intrinsics.checkNotNullParameter(trigger, "trigger");
      ConcurrentMap $this$getOrPut$iv = (ConcurrentMap)triggers;
      Object key$iv = trigger.getType();
      int $i$f$getOrPut = false;
      Object var10000 = $this$getOrPut$iv.get(key$iv);
      if (var10000 == null) {
         int var5 = false;
         Object default$iv = this.newTriggerSet();
         int var7 = false;
         var10000 = $this$getOrPut$iv.putIfAbsent(key$iv, default$iv);
         if (var10000 == null) {
            var10000 = default$iv;
         }
      }

      ((ConcurrentSkipListSet)var10000).add(trigger);
   }

   public void clearTriggers() {
      triggers.clear();
   }

   public void removeTrigger(@NotNull Trigger trigger) {
      Intrinsics.checkNotNullParameter(trigger, "trigger");
      ConcurrentSkipListSet var10000 = (ConcurrentSkipListSet)triggers.get(trigger.getType());
      if (var10000 != null) {
         var10000.remove(trigger);
      }

   }

   private final ConcurrentSkipListSet<Trigger> newTriggerSet() {
      return new ConcurrentSkipListSet();
   }

   public void setup(@NotNull List<URL> jars) {
      Intrinsics.checkNotNullParameter(jars, "jars");
      this.instanceContexts(jars);
      Context var10000 = access$getModuleContext$p();
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
         var10000 = null;
      }

      Context context$iv = var10000;
      int $i$f$wrapInContext$ctjs = false;
      boolean missingContext$iv = Context.getCurrentContext() == null;
      if (missingContext$iv) {
         try {
            JSContextFactory.INSTANCE.enterContext(context$iv);
         } catch (Throwable var14) {
            JSContextFactory.INSTANCE.enterContext();
         }
      }

      try {
         int var6 = false;
         String asmProvidedLibs = INSTANCE.saveResource("/js/asmProvidedLibs.js", new File(ModuleManager.INSTANCE.getModulesFolder().getParentFile(), "chattriggers-asm-provided-libs.js"), true);

         try {
            var10000 = access$getModuleContext$p();
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
               var10000 = null;
            }

            Scriptable var10001 = access$getScope$p();
            if (var10001 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("scope");
               var10001 = null;
            }

            Object var16 = var10000.evaluateString(var10001, asmProvidedLibs, "asmProvided", 1, (Object)null);
         } catch (Throwable var13) {
            var13.printStackTrace();
            ReferenceKt.printTraceToConsole(var13, INSTANCE.getConsole());
            Unit var8 = Unit.INSTANCE;
         }
      } finally {
         if (missingContext$iv) {
            Context.exit();
         }

      }

   }

   public void asmSetup() {
      Context var10000 = access$getModuleContext$p();
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
         var10000 = null;
      }

      Context context$iv = var10000;
      int $i$f$wrapInContext$ctjs = false;
      boolean missingContext$iv = Context.getCurrentContext() == null;
      if (missingContext$iv) {
         try {
            JSContextFactory.INSTANCE.enterContext(context$iv);
         } catch (Throwable var13) {
            JSContextFactory.INSTANCE.enterContext();
         }
      }

      try {
         int var5 = false;
         File asmLibFile = new File(ModuleManager.INSTANCE.getModulesFolder().getParentFile(), "chattriggers-asmLib.js");
         INSTANCE.saveResource("/js/asmLib.js", asmLibFile, true);

         try {
            JSLoader.CTRequire var15 = access$getRequire$p();
            if (var15 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("require");
               var15 = null;
            }

            URI var7 = asmLibFile.toURI();
            Intrinsics.checkNotNullExpressionValue(var7, "asmLibFile.toURI()");
            Scriptable returned = var15.loadCTModule("ASMLib", var7);
            JSLoader var16 = INSTANCE;
            Object var17 = ScriptableObject.getProperty(returned, "default");
            Intrinsics.checkNotNullExpressionValue(var17, "getProperty(returned, \"default\")");
            access$setASMLib$p(var17);
         } catch (Throwable var12) {
            var12.printStackTrace();
            ReferenceKt.printTraceToConsole(var12, INSTANCE.getConsole());
         }

         Unit var4 = Unit.INSTANCE;
      } finally {
         if (missingContext$iv) {
            Context.exit();
         }

      }

   }

   public void asmPass(@NotNull Module module, @NotNull URI asmURI) {
      Intrinsics.checkNotNullParameter(module, "module");
      Intrinsics.checkNotNullParameter(asmURI, "asmURI");
      Context var10000 = access$getModuleContext$p();
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
         var10000 = null;
      }

      Context context$iv = var10000;
      int $i$f$wrapInContext$ctjs = false;
      boolean missingContext$iv = Context.getCurrentContext() == null;
      if (missingContext$iv) {
         try {
            JSContextFactory.INSTANCE.enterContext(context$iv);
         } catch (Throwable var14) {
            JSContextFactory.INSTANCE.enterContext();
         }
      }

      try {
         boolean var7 = false;

         try {
            JSLoader.CTRequire var18 = access$getRequire$p();
            if (var18 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("require");
               var18 = null;
            }

            Scriptable returned = var18.loadCTModule(Intrinsics.stringPlus(module.getName(), "-asm$$"), asmURI);
            Object var10 = ScriptableObject.getProperty(returned, "default");
            Function asmFunction = var10 instanceof Function ? (Function)var10 : null;
            if (asmFunction == null) {
               StringBuilder var20 = (new StringBuilder()).append("Asm entry for module ").append(module.getName()).append(" has an invalid export. ");
               ReferenceKt.printToConsole("An Asm entry must have a default export of a function.", INSTANCE.getConsole(), LogType.WARN);
               var20.append(Unit.INSTANCE).toString();
            } else {
               Object var19 = access$getASMLib$p();
               if (var19 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("ASMLib");
                  var19 = Unit.INSTANCE;
               }

               ScriptableObject.putProperty((Object)var19, (Object)"currentModule", module.getName());
               Context var10001 = access$getModuleContext$p();
               if (var10001 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
                  var10001 = null;
               }

               Scriptable var10002 = access$getScope$p();
               if (var10002 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("scope");
                  var10002 = null;
               }

               Scriptable var10003 = access$getScope$p();
               if (var10003 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("scope");
                  var10003 = null;
               }

               Object[] var17 = new Object[1];
               Object var10006 = access$getASMLib$p();
               if (var10006 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("ASMLib");
                  var10006 = Unit.INSTANCE;
               }

               var17[0] = var10006;
               asmFunction.call(var10001, var10002, var10003, var17);
            }
         } catch (Throwable var15) {
            System.out.println(Intrinsics.stringPlus("Error loading asm entry for module ", module.getName()));
            var15.printStackTrace();
            ReferenceKt.printTraceToConsole(var15, INSTANCE.getConsole());
            ReferenceKt.printToConsole(Intrinsics.stringPlus("Error loading asm entry for module ", module.getName()), INSTANCE.getConsole(), LogType.ERROR);
         }

         Unit var6 = Unit.INSTANCE;
      } finally {
         if (missingContext$iv) {
            Context.exit();
         }

      }

   }

   public void entrySetup() {
      Context var10000 = access$getModuleContext$p();
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
         var10000 = null;
      }

      Context context$iv = var10000;
      int $i$f$wrapInContext$ctjs = false;
      boolean missingContext$iv = Context.getCurrentContext() == null;
      if (missingContext$iv) {
         try {
            JSContextFactory.INSTANCE.enterContext(context$iv);
         } catch (Throwable var12) {
            JSContextFactory.INSTANCE.enterContext();
         }
      }

      try {
         int var5 = false;
         String moduleProvidedLibs = INSTANCE.saveResource("/js/moduleProvidedLibs.js", new File(ModuleManager.INSTANCE.getModulesFolder().getParentFile(), "chattriggers-modules-provided-libs.js"), true);

         try {
            var10000 = access$getModuleContext$p();
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
               var10000 = null;
            }

            Scriptable var10001 = access$getScope$p();
            if (var10001 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("scope");
               var10001 = null;
            }

            var10000.evaluateString(var10001, moduleProvidedLibs, "moduleProvided", 1, (Object)null);
         } catch (Throwable var11) {
            var11.printStackTrace();
            ReferenceKt.printTraceToConsole(var11, INSTANCE.getConsole());
         }

         Unit var4 = Unit.INSTANCE;
      } finally {
         if (missingContext$iv) {
            Context.exit();
         }

      }

   }

   public void entryPass(@NotNull Module module, @NotNull URI entryURI) {
      Intrinsics.checkNotNullParameter(module, "module");
      Intrinsics.checkNotNullParameter(entryURI, "entryURI");
      Context var10000 = access$getModuleContext$p();
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
         var10000 = null;
      }

      Context context$iv = var10000;
      int $i$f$wrapInContext$ctjs = false;
      boolean missingContext$iv = Context.getCurrentContext() == null;
      if (missingContext$iv) {
         try {
            JSContextFactory.INSTANCE.enterContext(context$iv);
         } catch (Throwable var13) {
            JSContextFactory.INSTANCE.enterContext();
         }
      }

      try {
         boolean var7 = false;

         try {
            JSLoader.CTRequire var15 = access$getRequire$p();
            if (var15 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("require");
               var15 = null;
            }

            var15.loadCTModule(module.getName(), entryURI);
         } catch (Throwable var12) {
            System.out.println(Intrinsics.stringPlus("Error loading module ", module.getName()));
            var12.printStackTrace();
            ReferenceKt.printToConsole(Intrinsics.stringPlus("Error loading module ", module.getName()), INSTANCE.getConsole(), LogType.ERROR);
            ReferenceKt.printTraceToConsole(var12, INSTANCE.getConsole());
         }

         Unit var6 = Unit.INSTANCE;
      } finally {
         if (missingContext$iv) {
            Context.exit();
         }

      }

   }

   @NotNull
   public MethodHandle asmInvokeLookup(@NotNull Module module, @NotNull URI functionURI) {
      Intrinsics.checkNotNullParameter(module, "module");
      Intrinsics.checkNotNullParameter(functionURI, "functionURI");
      Context var10000 = access$getModuleContext$p();
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
         var10000 = null;
      }

      Context context$iv = var10000;
      int $i$f$wrapInContext$ctjs = false;
      boolean missingContext$iv = Context.getCurrentContext() == null;
      if (missingContext$iv) {
         try {
            JSContextFactory.INSTANCE.enterContext(context$iv);
         } catch (Throwable var16) {
            JSContextFactory.INSTANCE.enterContext();
         }
      }

      MethodHandle var7;
      try {
         boolean var8 = false;

         MethodHandle var10;
         try {
            JSLoader.CTRequire var20 = access$getRequire$p();
            if (var20 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("require");
               var20 = null;
            }

            Scriptable returned = var20.loadCTModule(module.getName(), functionURI);
            Object var21 = ScriptableObject.getProperty(returned, "default");
            if (var21 == null) {
               throw new NullPointerException("null cannot be cast to non-null type org.mozilla.javascript.Callable");
            }

            Callable func = (Callable)var21;
            var10 = access$getINVOKE_JS_CALL$p().bindTo(func);
         } catch (Throwable var15) {
            System.out.println("Error loading asm function " + functionURI + " in module " + module.getName() + '.');
            var15.printStackTrace();
            ReferenceKt.printToConsole("Error loading asm function " + functionURI + " in module " + module.getName() + '.', INSTANCE.getConsole(), LogType.ERROR);
            ReferenceKt.printTraceToConsole(var15, INSTANCE.getConsole());
            MethodHandle var19 = MethodHandles.constant(Object.class, (Object)null);
            Class[] var11 = new Class[]{Object[].class};
            var10 = MethodHandles.dropArguments(var19, 0, var11);
         }

         var7 = var10;
      } finally {
         if (missingContext$iv) {
            Context.exit();
         }

      }

      Intrinsics.checkNotNullExpressionValue(var7, "wrapInContext {\n        …)\n            }\n        }");
      return var7;
   }

   @JvmStatic
   @NotNull
   public static final Object asmInvoke(@NotNull Callable func, @NotNull Object[] args) {
      Intrinsics.checkNotNullParameter(func, "func");
      Intrinsics.checkNotNullParameter(args, "args");
      JSLoader this_$iv = INSTANCE;
      Context var10000 = access$getModuleContext$p();
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
         var10000 = null;
      }

      Context context$iv = var10000;
      int $i$f$wrapInContext$ctjs = false;
      boolean missingContext$iv = Context.getCurrentContext() == null;
      if (missingContext$iv) {
         try {
            JSContextFactory.INSTANCE.enterContext(context$iv);
         } catch (Throwable var11) {
            JSContextFactory.INSTANCE.enterContext();
         }
      }

      Object var7;
      try {
         int var8 = false;
         Context var10001 = access$getModuleContext$p();
         if (var10001 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
            var10001 = null;
         }

         Scriptable var10002 = access$getScope$p();
         if (var10002 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("scope");
            var10002 = null;
         }

         Scriptable var10003 = access$getScope$p();
         if (var10003 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("scope");
            var10003 = null;
         }

         var7 = func.call(var10001, var10002, var10003, args);
      } finally {
         if (missingContext$iv) {
            Context.exit();
         }

      }

      Intrinsics.checkNotNullExpressionValue(var7, "wrapInContext {\n        …e, scope, args)\n        }");
      return var7;
   }

   public final <T> T wrapInContext$ctjs(@NotNull Context context, @NotNull Function0<? extends T> block) {
      Intrinsics.checkNotNullParameter(context, "context");
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$wrapInContext$ctjs = false;
      boolean missingContext = Context.getCurrentContext() == null;
      if (missingContext) {
         try {
            JSContextFactory.INSTANCE.enterContext(context);
         } catch (Throwable var8) {
            JSContextFactory.INSTANCE.enterContext();
         }
      }

      Object var5;
      try {
         var5 = block.invoke();
      } finally {
         InlineMarker.finallyStart(1);
         if (missingContext) {
            Context.exit();
         }

         InlineMarker.finallyEnd(1);
      }

      return var5;
   }

   // $FF: synthetic method
   public static Object wrapInContext$ctjs$default(JSLoader var0, Context context, Function0 block, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         Context var10000 = access$getModuleContext$p();
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
            var10000 = null;
         }

         context = var10000;
      }

      Intrinsics.checkNotNullParameter(context, "context");
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$wrapInContext$ctjs = false;
      boolean missingContext = Context.getCurrentContext() == null;
      if (missingContext) {
         try {
            JSContextFactory.INSTANCE.enterContext(context);
         } catch (Throwable var8) {
            JSContextFactory.INSTANCE.enterContext();
         }
      }

      Object var5;
      try {
         var5 = block.invoke();
      } finally {
         InlineMarker.finallyStart(1);
         if (missingContext) {
            Context.exit();
         }

         InlineMarker.finallyEnd(1);
      }

      return var5;
   }

   @JvmStatic
   public static final void asmInjectHelper(@NotNull final String _className, @NotNull final At _at, @NotNull final String _methodName, @NotNull final String _methodDesc, @NotNull final Map<String, String> _fieldMaps, @NotNull final Map<String, String> _methodMaps, @NotNull final Function1<? super Wrapper, Unit> _insnList) {
      Intrinsics.checkNotNullParameter(_className, "_className");
      Intrinsics.checkNotNullParameter(_at, "_at");
      Intrinsics.checkNotNullParameter(_methodName, "_methodName");
      Intrinsics.checkNotNullParameter(_methodDesc, "_methodDesc");
      Intrinsics.checkNotNullParameter(_fieldMaps, "_fieldMaps");
      Intrinsics.checkNotNullParameter(_methodMaps, "_methodMaps");
      Intrinsics.checkNotNullParameter(_insnList, "_insnList");
      Method.inject((Function1)(new Function1<InjectWriter.Builder, Unit>() {
         public final void invoke(@NotNull InjectWriter.Builder $this$inject) {
            Intrinsics.checkNotNullParameter($this$inject, "$this$inject");
            $this$inject.setClassName(_className);
            $this$inject.setMethodName(_methodName);
            $this$inject.setMethodDesc(_methodDesc);
            $this$inject.setAt(_at);
            $this$inject.setFieldMaps(_fieldMaps);
            $this$inject.setMethodMaps(_methodMaps);
            $this$inject.insnList((Function1)(new Function1<InsnListBuilder, Unit>() {
               public final void invoke(@NotNull InsnListBuilder $this$insnList) {
                  Intrinsics.checkNotNullParameter($this$insnList, "$this$insnList");
                  JSLoader var2 = JSLoader.INSTANCE;
                  Function1 var4 = _insnList;
                  Context var10000 = JSLoader.moduleContext;
                  if (var10000 == null) {
                     Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
                     var10000 = null;
                  }

                  Context context$iv = var10000;
                  int $i$f$wrapInContext$ctjs = false;
                  boolean missingContext$iv = Context.getCurrentContext() == null;
                  if (missingContext$iv) {
                     try {
                        JSContextFactory.INSTANCE.enterContext(context$iv);
                     } catch (Throwable var11) {
                        JSContextFactory.INSTANCE.enterContext();
                     }
                  }

                  try {
                     int var8 = false;
                     NativeJavaObject var10001 = new NativeJavaObject;
                     Scriptable var10003 = JSLoader.scope;
                     if (var10003 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("scope");
                        var10003 = null;
                     }

                     var10001.<init>(var10003, $this$insnList, InsnListBuilder.class);
                     var4.invoke(var10001);
                     Unit var7 = Unit.INSTANCE;
                  } finally {
                     if (missingContext$iv) {
                        Context.exit();
                     }

                  }

               }
            }));
         }
      }));
   }

   @JvmStatic
   public static final void asmRemoveHelper(@NotNull final String _className, @NotNull final At _at, @NotNull final String _methodName, @NotNull final String _methodDesc, @NotNull final Map<String, String> _methodMaps, final int _numberToRemove) {
      Intrinsics.checkNotNullParameter(_className, "_className");
      Intrinsics.checkNotNullParameter(_at, "_at");
      Intrinsics.checkNotNullParameter(_methodName, "_methodName");
      Intrinsics.checkNotNullParameter(_methodDesc, "_methodDesc");
      Intrinsics.checkNotNullParameter(_methodMaps, "_methodMaps");
      Method.remove((Function1)(new Function1<RemoveWriter.Builder, Unit>() {
         public final void invoke(@NotNull RemoveWriter.Builder $this$remove) {
            Intrinsics.checkNotNullParameter($this$remove, "$this$remove");
            $this$remove.setClassName(_className);
            $this$remove.setMethodName(_methodName);
            $this$remove.setMethodDesc(_methodDesc);
            $this$remove.setAt(_at);
            $this$remove.setMethodMaps(_methodMaps);
            $this$remove.setNumberToRemove(_numberToRemove);
         }
      }));
   }

   @JvmStatic
   public static final void asmFieldHelper(@NotNull final String _className, @NotNull final String _fieldName, @NotNull final String _fieldDesc, @Nullable final Object _initialValue, @NotNull final List<? extends AccessType> _accessTypes) {
      Intrinsics.checkNotNullParameter(_className, "_className");
      Intrinsics.checkNotNullParameter(_fieldName, "_fieldName");
      Intrinsics.checkNotNullParameter(_fieldDesc, "_fieldDesc");
      Intrinsics.checkNotNullParameter(_accessTypes, "_accessTypes");
      Method.applyField((Function1)(new Function1<FieldWriter.Builder, Unit>() {
         public final void invoke(@NotNull FieldWriter.Builder $this$applyField) {
            Intrinsics.checkNotNullParameter($this$applyField, "$this$applyField");
            $this$applyField.setClassName(_className);
            $this$applyField.setFieldName(_fieldName);
            $this$applyField.setFieldDesc(_fieldDesc);
            $this$applyField.setInitialValue(_initialValue);
            $this$applyField.setAccessTypes(_accessTypes);
         }
      }));
   }

   @NotNull
   public String eval(@NotNull String code) {
      Intrinsics.checkNotNullParameter(code, "code");
      Context var10000 = evalContext;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("evalContext");
         var10000 = null;
      }

      Context context$iv = var10000;
      int $i$f$wrapInContext$ctjs = false;
      boolean missingContext$iv = Context.getCurrentContext() == null;
      if (missingContext$iv) {
         try {
            JSContextFactory.INSTANCE.enterContext(context$iv);
         } catch (Throwable var11) {
            JSContextFactory.INSTANCE.enterContext();
         }
      }

      String var7;
      try {
         int var8 = false;
         var10000 = access$getEvalContext$p();
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("evalContext");
            var10000 = null;
         }

         Scriptable var10001 = access$getScope$p();
         if (var10001 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("scope");
            var10001 = null;
         }

         var7 = Context.toString(var10000.evaluateString(var10001, code, "<eval>", 1, (Object)null));
      } finally {
         if (missingContext$iv) {
            Context.exit();
         }

      }

      Intrinsics.checkNotNullExpressionValue(var7, "wrapInContext(evalContex…al>\", 1, null))\n        }");
      return var7;
   }

   @NotNull
   public Lang getLanguage() {
      return Lang.JS;
   }

   public void trigger(@NotNull Trigger trigger, @NotNull Object method, @NotNull Object[] args) {
      Intrinsics.checkNotNullParameter(trigger, "trigger");
      Intrinsics.checkNotNullParameter(method, "method");
      Intrinsics.checkNotNullParameter(args, "args");
      Context var10000 = access$getModuleContext$p();
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
         var10000 = null;
      }

      Context context$iv = var10000;
      int $i$f$wrapInContext$ctjs = false;
      boolean missingContext$iv = Context.getCurrentContext() == null;
      if (missingContext$iv) {
         try {
            JSContextFactory.INSTANCE.enterContext(context$iv);
         } catch (Throwable var15) {
            JSContextFactory.INSTANCE.enterContext();
         }
      }

      try {
         boolean var8 = false;

         try {
            if (!(method instanceof Function)) {
               int var10 = false;
               String var18 = "Need to pass actual function to the register function, not the name!";
               throw new IllegalArgumentException(var18.toString());
            }

            Function var19 = (Function)method;
            Context var10001 = Context.getCurrentContext();
            Scriptable var10002 = access$getScope$p();
            if (var10002 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("scope");
               var10002 = null;
            }

            Scriptable var10003 = access$getScope$p();
            if (var10003 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("scope");
               var10003 = null;
            }

            Object var17 = var19.call(var10001, var10002, var10003, args);
         } catch (Throwable var14) {
            ReferenceKt.printTraceToConsole(var14, INSTANCE.getConsole());
            INSTANCE.removeTrigger(trigger);
            Unit var9 = Unit.INSTANCE;
         }
      } finally {
         if (missingContext$iv) {
            Context.exit();
         }

      }

   }

   private final void instanceContexts(List<URL> files) {
      JSContextFactory.INSTANCE.addAllURLs(files);
      Context var2 = JSContextFactory.INSTANCE.enterContext();
      Intrinsics.checkNotNullExpressionValue(var2, "JSContextFactory.enterContext()");
      moduleContext = var2;
      ImporterTopLevel var10000 = new ImporterTopLevel;
      Context var10002 = moduleContext;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
         var10002 = null;
      }

      var10000.<init>(var10002);
      scope = (Scriptable)var10000;
      UrlModuleSourceProvider sourceProvider = new UrlModuleSourceProvider((Iterable)CollectionsKt.listOf(ModuleManager.INSTANCE.getModulesFolder().toURI()), (Iterable)CollectionsKt.emptyList());
      StrongCachingModuleScriptProvider moduleProvider = new StrongCachingModuleScriptProvider((ModuleSourceProvider)sourceProvider);
      require = new JSLoader.CTRequire((ModuleScriptProvider)moduleProvider);
      JSLoader.CTRequire var5 = require;
      if (var5 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("require");
         var5 = null;
      }

      Scriptable var10001 = scope;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("scope");
         var10001 = null;
      }

      var5.install(var10001);
      Context.exit();
      JSContextFactory.INSTANCE.setOptimize(false);
      Context var4 = JSContextFactory.INSTANCE.enterContext();
      Intrinsics.checkNotNullExpressionValue(var4, "JSContextFactory.enterContext()");
      evalContext = var4;
      Context.exit();
      JSContextFactory.INSTANCE.setOptimize(true);
   }

   @NotNull
   public String saveResource(@Nullable String resourceName, @NotNull File outputFile, boolean replace) {
      return ILoader.DefaultImpls.saveResource((ILoader)this, resourceName, outputFile, replace);
   }

   // $FF: synthetic method
   public static final JSLoader.CTRequire access$getRequire$p() {
      return require;
   }

   // $FF: synthetic method
   public static final void access$setASMLib$p(Object var0) {
      ASMLib = var0;
   }

   // $FF: synthetic method
   public static final Object access$getASMLib$p() {
      return ASMLib;
   }

   // $FF: synthetic method
   public static final MethodHandle access$getINVOKE_JS_CALL$p() {
      return INVOKE_JS_CALL;
   }

   // $FF: synthetic method
   public static final Context access$getEvalContext$p() {
      return evalContext;
   }

   static {
      console$delegate = LazyKt.lazy((Function0)null.INSTANCE);
      Lookup var10000 = MethodHandles.lookup();
      Class[] var0 = new Class[]{Object[].class};
      INVOKE_JS_CALL = var10000.findStatic(JSLoader.class, "asmInvoke", MethodType.methodType(Object.class, Callable.class, var0));
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0016\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n¨\u0006\u000b"},
      d2 = {"Lcom/chattriggers/ctjs/engine/langs/js/JSLoader$CTRequire;", "Lorg/mozilla/javascript/commonjs/module/Require;", "moduleProvider", "Lorg/mozilla/javascript/commonjs/module/ModuleScriptProvider;", "(Lorg/mozilla/javascript/commonjs/module/ModuleScriptProvider;)V", "loadCTModule", "Lorg/mozilla/javascript/Scriptable;", "cachedName", "", "uri", "Ljava/net/URI;", "ctjs"}
   )
   public static final class CTRequire extends Require {
      public CTRequire(@NotNull ModuleScriptProvider moduleProvider) {
         Intrinsics.checkNotNullParameter(moduleProvider, "moduleProvider");
         Context var10001 = JSLoader.moduleContext;
         if (var10001 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
            var10001 = null;
         }

         Scriptable var10002 = JSLoader.scope;
         if (var10002 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("scope");
            var10002 = null;
         }

         super(var10001, var10002, moduleProvider, (Script)null, (Script)null, false);
      }

      @NotNull
      public final Scriptable loadCTModule(@NotNull String cachedName, @NotNull URI uri) {
         Intrinsics.checkNotNullParameter(cachedName, "cachedName");
         Intrinsics.checkNotNullParameter(uri, "uri");
         Context var10001 = JSLoader.moduleContext;
         if (var10001 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("moduleContext");
            var10001 = null;
         }

         Scriptable var3 = this.getExportedModuleInterface(var10001, cachedName, uri, (URI)null, false);
         Intrinsics.checkNotNullExpressionValue(var3, "getExportedModuleInterfa…edName, uri, null, false)");
         return var3;
      }
   }
}
