package com.chattriggers.ctjs.engine.langs.js;

import com.chattriggers.ctjs.minecraft.objects.keybind.KeyBind;
import com.chattriggers.ctjs.minecraft.objects.keybind.KeyBindHandler;
import com.chattriggers.ctjs.minecraft.wrappers.Client;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.settings.KeyBinding;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0012\u0010\u000b\u001a\u0004\u0018\u00010\f2\u0006\u0010\r\u001a\u00020\u000eH\u0016J\u0012\u0010\u000f\u001a\u0004\u0018\u00010\f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0016J\u0018\u0010\u000f\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\r\u001a\u00020\u000eH\u0016J \u0010\u000f\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u000eH\u0016R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0013"},
   d2 = {"Lcom/chattriggers/ctjs/engine/langs/js/JSClient;", "Lcom/chattriggers/ctjs/minecraft/wrappers/Client;", "()V", "camera", "Lcom/chattriggers/ctjs/minecraft/wrappers/Client$Companion$camera;", "getCamera", "()Lcom/chattriggers/ctjs/minecraft/wrappers/Client$Companion$camera;", "currentGui", "Lcom/chattriggers/ctjs/minecraft/wrappers/Client$Companion$currentGui;", "getCurrentGui", "()Lcom/chattriggers/ctjs/minecraft/wrappers/Client$Companion$currentGui;", "getKeyBindFromDescription", "Lcom/chattriggers/ctjs/minecraft/objects/keybind/KeyBind;", "description", "", "getKeyBindFromKey", "keyCode", "", "category", "ctjs"}
)
public final class JSClient extends Client {
   @NotNull
   public static final JSClient INSTANCE = new JSClient();
   @NotNull
   private static final Client.Companion.currentGui currentGui;
   @NotNull
   private static final Client.Companion.camera camera;

   private JSClient() {
   }

   @Nullable
   public KeyBind getKeyBindFromKey(int keyCode) {
      Iterator var5 = ((Iterable)KeyBindHandler.INSTANCE.getKeyBinds()).iterator();

      Object var10000;
      while(true) {
         if (var5.hasNext()) {
            Object var6 = var5.next();
            KeyBind it = (KeyBind)var6;
            int var8 = false;
            if (it.getKeyCode() != keyCode) {
               continue;
            }

            var10000 = var6;
            break;
         }

         var10000 = null;
         break;
      }

      KeyBind var2 = (KeyBind)var10000;
      KeyBind var17;
      if (var2 == null) {
         KeyBinding[] var4 = Client.Companion.getMinecraft().field_71474_y.field_74324_K;
         Intrinsics.checkNotNullExpressionValue(var4, "getMinecraft().gameSettings.keyBindings");
         Object[] var11 = (Object[])var4;
         int var12 = 0;

         label40: {
            for(int var14 = var11.length; var12 < var14; ++var12) {
               Object var15 = var11[var12];
               KeyBinding it = (KeyBinding)var15;
               int var10 = false;
               if (it.func_151463_i() == keyCode) {
                  var10000 = var15;
                  break label40;
               }
            }

            var10000 = null;
         }

         KeyBinding var3 = (KeyBinding)var10000;
         JSKeyBind var16;
         if (var3 == null) {
            var16 = null;
         } else {
            int var13 = false;
            var16 = new JSKeyBind(var3);
         }

         var17 = (KeyBind)var16;
      } else {
         var17 = var2;
      }

      return var17;
   }

   @NotNull
   public KeyBind getKeyBindFromKey(int keyCode, @NotNull String description, @NotNull String category) {
      Intrinsics.checkNotNullParameter(description, "description");
      Intrinsics.checkNotNullParameter(category, "category");
      KeyBind var10000 = this.getKeyBindFromKey(keyCode);
      if (var10000 == null) {
         var10000 = (KeyBind)(new JSKeyBind(description, keyCode, category));
      }

      return var10000;
   }

   @NotNull
   public KeyBind getKeyBindFromKey(int keyCode, @NotNull String description) {
      Intrinsics.checkNotNullParameter(description, "description");
      return this.getKeyBindFromKey(keyCode, description, "ChatTriggers");
   }

   @Nullable
   public KeyBind getKeyBindFromDescription(@NotNull String description) {
      Intrinsics.checkNotNullParameter(description, "description");
      Iterator var5 = ((Iterable)KeyBindHandler.INSTANCE.getKeyBinds()).iterator();

      Object var10000;
      while(true) {
         if (var5.hasNext()) {
            Object var6 = var5.next();
            KeyBind it = (KeyBind)var6;
            int var8 = false;
            if (!Intrinsics.areEqual(it.getDescription(), description)) {
               continue;
            }

            var10000 = var6;
            break;
         }

         var10000 = null;
         break;
      }

      KeyBind var2 = (KeyBind)var10000;
      KeyBind var17;
      if (var2 == null) {
         KeyBinding[] var4 = Client.Companion.getMinecraft().field_71474_y.field_74324_K;
         Intrinsics.checkNotNullExpressionValue(var4, "getMinecraft().gameSettings.keyBindings");
         Object[] var11 = (Object[])var4;
         int var12 = 0;
         int var14 = var11.length;

         while(true) {
            if (var12 >= var14) {
               var10000 = null;
               break;
            }

            Object var15 = var11[var12];
            KeyBinding it = (KeyBinding)var15;
            int var10 = false;
            if (Intrinsics.areEqual(it.func_151464_g(), description)) {
               var10000 = var15;
               break;
            }

            ++var12;
         }

         KeyBinding var3 = (KeyBinding)var10000;
         JSKeyBind var16;
         if (var3 == null) {
            var16 = null;
         } else {
            int var13 = false;
            var16 = new JSKeyBind(var3);
         }

         var17 = (KeyBind)var16;
      } else {
         var17 = var2;
      }

      return var17;
   }

   @NotNull
   public final Client.Companion.currentGui getCurrentGui() {
      return currentGui;
   }

   @NotNull
   public final Client.Companion.camera getCamera() {
      return camera;
   }

   static {
      currentGui = Client.Companion.currentGui.INSTANCE;
      camera = Client.Companion.camera.INSTANCE;
   }
}
