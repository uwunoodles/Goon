package com.chattriggers.ctjs.engine.langs.js;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmClassMappingKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.reflect.KProperty1;
import kotlin.reflect.KVisibility;
import kotlin.reflect.full.KClasses;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0003H\u0016¨\u0006\u0005"},
   d2 = {"Lcom/chattriggers/ctjs/engine/langs/js/JSONImpl;", "", "toJSON", "", "key", "ctjs"}
)
public interface JSONImpl {
   @NotNull
   String toJSON(@NotNull String var1);

   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public static final class DefaultImpls {
      @NotNull
      public static String toJSON(@NotNull final JSONImpl var0, @NotNull String key) {
         Intrinsics.checkNotNullParameter(var0, "this");
         Intrinsics.checkNotNullParameter(key, "key");
         StringBuilder sb = new StringBuilder();
         sb.append("{");
         Iterable $this$filter$iv = (Iterable)KClasses.getMemberProperties(JvmClassMappingKt.getKotlinClass(var0.getClass()));
         int $i$f$filter = false;
         Collection destination$iv$iv = (Collection)(new ArrayList());
         int $i$f$filterTo = false;
         Iterator var8 = $this$filter$iv.iterator();

         while(var8.hasNext()) {
            Object element$iv$iv = var8.next();
            KProperty1 it = (KProperty1)element$iv$iv;
            int var11 = false;
            if (it.getVisibility() == KVisibility.PUBLIC) {
               destination$iv$iv.add(element$iv$iv);
            }
         }

         sb.append(CollectionsKt.joinToString$default((Iterable)((List)destination$iv$iv), (CharSequence)",\n", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)(new Function1<KProperty1<JSONImpl, ?>, CharSequence>() {
            @NotNull
            public final CharSequence invoke(@NotNull KProperty1<JSONImpl, ?> it) {
               Intrinsics.checkNotNullParameter(it, "it");
               return (CharSequence)('"' + it.getName() + "\": \"" + it.get(var0) + '"');
            }
         }), 30, (Object)null));
         if (sb.length() > 1) {
            sb.append(",\n");
         }

         sb.append("\"toString\": \"" + var0 + '"');
         sb.append("}");
         String var13 = sb.toString();
         Intrinsics.checkNotNullExpressionValue(var13, "sb.toString()");
         return var13;
      }
   }
}
