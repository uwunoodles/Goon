package com.chattriggers.ctjs.engine.langs.js;

import com.chattriggers.ctjs.engine.ILoader;
import com.chattriggers.ctjs.minecraft.objects.display.DisplayLine;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.mozilla.javascript.NativeObject;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u000f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004B\u0017\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007J\r\u0010\b\u001a\u00020\tH\u0010¢\u0006\u0002\b\n¨\u0006\u000b"},
   d2 = {"Lcom/chattriggers/ctjs/engine/langs/js/JSDisplayLine;", "Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayLine;", "text", "", "(Ljava/lang/String;)V", "config", "Lorg/mozilla/javascript/NativeObject;", "(Ljava/lang/String;Lorg/mozilla/javascript/NativeObject;)V", "getLoader", "Lcom/chattriggers/ctjs/engine/ILoader;", "getLoader$ctjs", "ctjs"}
)
public final class JSDisplayLine extends DisplayLine {
   public JSDisplayLine(@NotNull String text) {
      Intrinsics.checkNotNullParameter(text, "text");
      super(text);
   }

   public JSDisplayLine(@NotNull String text, @NotNull NativeObject config) {
      Intrinsics.checkNotNullParameter(text, "text");
      Intrinsics.checkNotNullParameter(config, "config");
      super(text, config);
   }

   @NotNull
   public ILoader getLoader$ctjs() {
      return (ILoader)JSLoader.INSTANCE;
   }
}
