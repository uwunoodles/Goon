package com.chattriggers.ctjs.engine.module;

import com.chattriggers.ctjs.CTJS;
import com.chattriggers.ctjs.ReferenceKt;
import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.utils.Config;
import com.chattriggers.ctjs.utils.console.Console;
import com.chattriggers.ctjs.utils.console.LogType;
import com.chattriggers.ctjs.utils.kotlin.ExtensionsKt;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.nio.file.CopyOption;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.io.CloseableKt;
import kotlin.io.FilesKt;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Text;
import net.minecraftforge.event.world.WorldEvent.Load;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.apache.commons.io.FileUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\u001cB\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0012\u0010\b\u001a\u0004\u0018\u00010\t2\u0006\u0010\n\u001a\u00020\u000bH\u0002J \u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r2\u0006\u0010\u000f\u001a\u00020\u000b2\n\b\u0002\u0010\u0010\u001a\u0004\u0018\u00010\u000bJ\u0006\u0010\u0011\u001a\u00020\u0012J\u0010\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\u0015H\u0007J\u0010\u0010\u0016\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\u0017H\u0007J\u0010\u0010\u0018\u001a\u00020\u00122\u0006\u0010\u0019\u001a\u00020\u0005H\u0002J\u0010\u0010\u001a\u001a\u00020\u00122\u0006\u0010\u0019\u001a\u00020\u0005H\u0002J\u000e\u0010\u001b\u001a\u00020\u00122\u0006\u0010\u0019\u001a\u00020\u000eR\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001d"},
   d2 = {"Lcom/chattriggers/ctjs/engine/module/ModuleUpdater;", "", "()V", "changelogs", "", "Lcom/chattriggers/ctjs/engine/module/ModuleMetadata;", "shouldReportChangelog", "", "downloadModule", "Lcom/chattriggers/ctjs/engine/module/ModuleUpdater$DownloadResult;", "name", "", "importModule", "", "Lcom/chattriggers/ctjs/engine/module/Module;", "moduleName", "requiredBy", "importPendingModules", "", "onRenderGameOverlay", "event", "Lnet/minecraftforge/client/event/RenderGameOverlayEvent$Text;", "onWorldLoad", "Lnet/minecraftforge/event/world/WorldEvent$Load;", "reportChangelog", "module", "tryReportChangelog", "updateModule", "DownloadResult", "ctjs"}
)
public final class ModuleUpdater {
   @NotNull
   public static final ModuleUpdater INSTANCE = new ModuleUpdater();
   @NotNull
   private static final List<ModuleMetadata> changelogs = (List)(new ArrayList());
   private static boolean shouldReportChangelog;

   private ModuleUpdater() {
   }

   @SubscribeEvent
   public final void onWorldLoad(@NotNull Load event) {
      Intrinsics.checkNotNullParameter(event, "event");
      shouldReportChangelog = true;
   }

   @SubscribeEvent
   public final void onRenderGameOverlay(@NotNull Text event) {
      Intrinsics.checkNotNullParameter(event, "event");
      if (shouldReportChangelog) {
         Iterable $this$forEach$iv = (Iterable)changelogs;
         int $i$f$forEach = false;
         Iterator var4 = $this$forEach$iv.iterator();

         while(var4.hasNext()) {
            Object element$iv = var4.next();
            ModuleMetadata p0 = (ModuleMetadata)element$iv;
            int var7 = false;
            this.reportChangelog(p0);
         }

         changelogs.clear();
      }
   }

   private final void tryReportChangelog(ModuleMetadata module) {
      if (shouldReportChangelog) {
         this.reportChangelog(module);
      } else {
         changelogs.add(module);
      }

   }

   private final void reportChangelog(ModuleMetadata module) {
      ChatLib.chat("&a[ChatTriggers] " + module.getName() + " has updated to version " + module.getVersion());
      ChatLib.chat(Intrinsics.stringPlus("&aChangelog: &r", module.getChangelog()));
   }

   public final void importPendingModules() {
      File toDownload = new File(ModuleManager.INSTANCE.getModulesFolder(), ".to_download.txt");
      if (toDownload.exists()) {
         CharSequence var10000 = (CharSequence)FilesKt.readText$default(toDownload, (Charset)null, 1, (Object)null);
         String[] var2 = new String[]{","};
         Iterable $this$forEach$iv = (Iterable)StringsKt.split$default(var10000, var2, false, 0, 6, (Object)null);
         int $i$f$forEach = false;
         Collection destination$iv$iv = (Collection)(new ArrayList());
         int $i$f$filterTo = false;
         Iterator var7 = $this$forEach$iv.iterator();

         while(var7.hasNext()) {
            Object element$iv$iv = var7.next();
            String p0 = (String)element$iv$iv;
            int var10 = false;
            if (StringsKt.isBlank((CharSequence)p0)) {
               destination$iv$iv.add(element$iv$iv);
            }
         }

         $this$forEach$iv = (Iterable)((List)destination$iv$iv);
         $i$f$forEach = false;
         Iterator var4 = $this$forEach$iv.iterator();

         while(var4.hasNext()) {
            Object element$iv = var4.next();
            String p0 = (String)element$iv;
            int var14 = false;
            importModule$default(this, p0, (String)null, 2, (Object)null);
         }

         toDownload.delete();
      }
   }

   public final void updateModule(@NotNull Module module) {
      Intrinsics.checkNotNullParameter(module, "module");
      if (Config.INSTANCE.getAutoUpdateModules()) {
         ModuleMetadata metadata = module.getMetadata();

         try {
            if (metadata.getName() == null) {
               return;
            }

            ReferenceKt.printToConsole$default(Intrinsics.stringPlus("Checking for update in ", metadata.getName()), (Console)null, (LogType)null, 3, (Object)null);
            String url = "https://www.chattriggers.com/api/modules/" + metadata.getName() + "/metadata?modVersion=2.2.1";
            URLConnection connection = CTJS.INSTANCE.makeWebRequest(url);
            InputStream var6 = connection.getInputStream();
            Intrinsics.checkNotNullExpressionValue(var6, "connection.getInputStream()");
            Charset var7 = Charsets.UTF_8;
            Reader var8 = (Reader)(new InputStreamReader(var6, var7));
            short var9 = 8192;
            String newMetadataText = TextStreamsKt.readText((Reader)(var8 instanceof BufferedReader ? (BufferedReader)var8 : new BufferedReader(var8, var9)));
            ModuleMetadata newMetadata = (ModuleMetadata)CTJS.INSTANCE.getGson().fromJson(newMetadataText, ModuleMetadata.class);
            if (newMetadata.getVersion() == null) {
               ReferenceKt.printToConsole$default("Remote version of module " + metadata.getName() + " has no version numbers, so it will not be updated!", (Console)null, LogType.WARN, 1, (Object)null);
               return;
            }

            if (metadata.getVersion() != null && ExtensionsKt.toVersion(metadata.getVersion()).compareTo(ExtensionsKt.toVersion(newMetadata.getVersion())) >= 0) {
               return;
            }

            this.downloadModule(metadata.getName());
            ReferenceKt.printToConsole$default(Intrinsics.stringPlus("Updated module ", metadata.getName()), (Console)null, (LogType)null, 3, (Object)null);
            File it = new File(module.getFolder(), "metadata.json");
            int var10 = false;
            ModuleMetadata var14 = (ModuleMetadata)CTJS.INSTANCE.getGson().fromJson(FilesKt.readText$default(it, (Charset)null, 1, (Object)null), ModuleMetadata.class);
            Intrinsics.checkNotNullExpressionValue(var14, "File(module.folder, \"met…class.java)\n            }");
            module.setMetadata(var14);
            if (Config.INSTANCE.getModuleChangelog() && module.getMetadata().getChangelog() != null) {
               this.tryReportChangelog(module.getMetadata());
            }
         } catch (Exception var12) {
            ReferenceKt.printToConsole$default(Intrinsics.stringPlus("Can't find page for ", metadata.getName()), (Console)null, LogType.WARN, 1, (Object)null);
         }

      }
   }

   @NotNull
   public final List<Module> importModule(@NotNull String moduleName, @Nullable String requiredBy) {
      Intrinsics.checkNotNullParameter(moduleName, "moduleName");
      Iterable $this$any$iv = (Iterable)ModuleManager.INSTANCE.getCachedModules();
      int $i$f$any = false;
      Module module;
      boolean var10000;
      if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
         var10000 = false;
      } else {
         label72: {
            Iterator var6 = $this$any$iv.iterator();

            while(var6.hasNext()) {
               Object element$iv = var6.next();
               module = (Module)element$iv;
               int var9 = false;
               if (StringsKt.equals(module.getName(), moduleName, true)) {
                  if (requiredBy != null) {
                     module.getMetadata().setRequired(true);
                     module.getRequiredBy().add(requiredBy);
                  }

                  var10000 = true;
               } else {
                  var10000 = false;
               }

               if (var10000) {
                  var10000 = true;
                  break label72;
               }
            }

            var10000 = false;
         }
      }

      boolean alreadyImported = var10000;
      if (alreadyImported) {
         return CollectionsKt.emptyList();
      } else {
         ModuleUpdater.DownloadResult var28 = this.downloadModule(moduleName);
         if (var28 == null) {
            return CollectionsKt.emptyList();
         } else {
            ModuleUpdater.DownloadResult var23 = var28;
            String realName = var23.component1();
            String modVersion = var23.component2();
            File moduleDir = new File(ModuleManager.INSTANCE.getModulesFolder(), realName);
            module = ModuleManager.INSTANCE.parseModule(moduleDir);
            module.setTargetModVersion(ExtensionsKt.toVersion(modVersion));
            if (requiredBy != null) {
               module.getMetadata().setRequired(true);
               module.getRequiredBy().add(requiredBy);
            }

            ModuleManager.INSTANCE.getCachedModules().add(module);
            CollectionsKt.sortWith(ModuleManager.INSTANCE.getCachedModules(), ModuleUpdater::importModule$lambda-3);
            Collection var29 = (Collection)CollectionsKt.listOf(module);
            ArrayList var10 = module.getMetadata().getRequires();
            List var10001;
            if (var10 == null) {
               var10001 = null;
            } else {
               Iterable $this$map$iv = (Iterable)var10;
               Collection var21 = var29;
               int $i$f$map = false;
               Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
               int $i$f$mapTo = false;
               Iterator var17 = $this$map$iv.iterator();

               while(var17.hasNext()) {
                  Object item$iv$iv = var17.next();
                  String it = (String)item$iv$iv;
                  int var20 = false;
                  destination$iv$iv.add(INSTANCE.importModule(it, module.getName()));
               }

               var10001 = (List)destination$iv$iv;
               var29 = var21;
               List var11 = var10001;
               var10001 = CollectionsKt.flatten((Iterable)var11);
            }

            List var27 = var10001;
            return CollectionsKt.plus(var29, var27 == null ? (Iterable)CollectionsKt.emptyList() : (Iterable)var27);
         }
      }
   }

   // $FF: synthetic method
   public static List importModule$default(ModuleUpdater var0, String var1, String var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = null;
      }

      return var0.importModule(var1, var2);
   }

   private final ModuleUpdater.DownloadResult downloadModule(String name) {
      File downloadZip = new File(ModuleManager.INSTANCE.getModulesFolder(), "currDownload.zip");

      try {
         String url = "https://www.chattriggers.com/api/modules/" + name + "/scripts?modVersion=2.2.1";
         URLConnection connection = CTJS.INSTANCE.makeWebRequest(url);
         FileUtils.copyInputStreamToFile(connection.getInputStream(), downloadZip);
         Closeable var5 = (Closeable)FileSystems.newFileSystem(downloadZip.toPath(), (ClassLoader)null);
         Throwable var6 = null;

         ModuleUpdater.DownloadResult var15;
         try {
            FileSystem it = (FileSystem)var5;
            int var8 = false;
            Iterable var9 = it.getRootDirectories();
            Intrinsics.checkNotNullExpressionValue(var9, "it.rootDirectories");
            Iterator var10 = Files.newDirectoryStream((Path)CollectionsKt.first(var9)).iterator();
            Intrinsics.checkNotNullExpressionValue(var10, "newDirectoryStream(it.ro…ories.first()).iterator()");
            Iterator rootFolder = var10;
            if (!var10.hasNext()) {
               throw new Exception("Too small");
            }

            Path moduleFolder = (Path)var10.next();
            if (rootFolder.hasNext()) {
               throw new Exception("Too big");
            }

            String var10000 = moduleFolder.getFileName().toString();
            char[] var12 = new char[]{File.separatorChar};
            String realName = StringsKt.trimEnd(var10000, var12);
            File var31 = new File(ModuleManager.INSTANCE.getModulesFolder(), realName);
            int var14 = false;
            var31.mkdir();
            Files.walk(moduleFolder).forEach(ModuleUpdater::downloadModule$lambda-7$lambda-6);
            String var32 = connection.getHeaderField("CT-Version");
            Intrinsics.checkNotNullExpressionValue(var32, "connection.getHeaderField(\"CT-Version\")");
            var15 = new ModuleUpdater.DownloadResult(realName, var32);
         } catch (Throwable var25) {
            var6 = var25;
            throw var25;
         } finally {
            CloseableKt.closeFinally(var5, var6);
         }

         ModuleUpdater.DownloadResult var16 = var15;
         return var16;
      } catch (Exception var27) {
         ReferenceKt.printTraceToConsole$default((Throwable)var27, (Console)null, 1, (Object)null);
      } finally {
         downloadZip.delete();
      }

      return null;
   }

   private static final int importModule$lambda_3/* $FF was: importModule$lambda-3*/(Module a, Module b) {
      return a.getName().compareTo(b.getName());
   }

   private static final void downloadModule$lambda_7$lambda_6/* $FF was: downloadModule$lambda-7$lambda-6*/(Path path) {
      String var10000 = ModuleManager.INSTANCE.getModulesFolder().toString();
      String[] var2 = new String[]{path.toString()};
      Path resolvedPath = Paths.get(var10000, var2);
      if (!Files.isDirectory(resolvedPath, new LinkOption[0])) {
         CopyOption[] var3 = new CopyOption[]{(CopyOption)StandardCopyOption.REPLACE_EXISTING};
         Files.copy(path, resolvedPath, var3);
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J\t\u0010\t\u001a\u00020\u0003HÆ\u0003J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\u000b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001J\t\u0010\u0011\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0007¨\u0006\u0012"},
      d2 = {"Lcom/chattriggers/ctjs/engine/module/ModuleUpdater$DownloadResult;", "", "name", "", "modVersion", "(Ljava/lang/String;Ljava/lang/String;)V", "getModVersion", "()Ljava/lang/String;", "getName", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "ctjs"}
   )
   public static final class DownloadResult {
      @NotNull
      private final String name;
      @NotNull
      private final String modVersion;

      public DownloadResult(@NotNull String name, @NotNull String modVersion) {
         Intrinsics.checkNotNullParameter(name, "name");
         Intrinsics.checkNotNullParameter(modVersion, "modVersion");
         super();
         this.name = name;
         this.modVersion = modVersion;
      }

      @NotNull
      public final String getName() {
         return this.name;
      }

      @NotNull
      public final String getModVersion() {
         return this.modVersion;
      }

      @NotNull
      public final String component1() {
         return this.name;
      }

      @NotNull
      public final String component2() {
         return this.modVersion;
      }

      @NotNull
      public final ModuleUpdater.DownloadResult copy(@NotNull String name, @NotNull String modVersion) {
         Intrinsics.checkNotNullParameter(name, "name");
         Intrinsics.checkNotNullParameter(modVersion, "modVersion");
         return new ModuleUpdater.DownloadResult(name, modVersion);
      }

      // $FF: synthetic method
      public static ModuleUpdater.DownloadResult copy$default(ModuleUpdater.DownloadResult var0, String var1, String var2, int var3, Object var4) {
         if ((var3 & 1) != 0) {
            var1 = var0.name;
         }

         if ((var3 & 2) != 0) {
            var2 = var0.modVersion;
         }

         return var0.copy(var1, var2);
      }

      @NotNull
      public String toString() {
         return "DownloadResult(name=" + this.name + ", modVersion=" + this.modVersion + ')';
      }

      public int hashCode() {
         int result = this.name.hashCode();
         result = result * 31 + this.modVersion.hashCode();
         return result;
      }

      public boolean equals(@Nullable Object other) {
         if (this == other) {
            return true;
         } else if (!(other instanceof ModuleUpdater.DownloadResult)) {
            return false;
         } else {
            ModuleUpdater.DownloadResult var2 = (ModuleUpdater.DownloadResult)other;
            if (!Intrinsics.areEqual(this.name, var2.name)) {
               return false;
            } else {
               return Intrinsics.areEqual(this.modVersion, var2.modVersion);
            }
         }
      }
   }
}
