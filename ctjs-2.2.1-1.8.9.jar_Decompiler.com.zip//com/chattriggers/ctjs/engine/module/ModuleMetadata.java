package com.chattriggers.ctjs.engine.module;

import java.util.ArrayList;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010$\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b(\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001Bí\u0001\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0003\u0012\u0016\b\u0002\u0010\u0007\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0003\u0018\u00010\b\u0012\u001c\b\u0002\u0010\t\u001a\u0016\u0012\u0004\u0012\u00020\u0003\u0018\u00010\nj\n\u0012\u0004\u0012\u00020\u0003\u0018\u0001`\u000b\u0012\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u0003\u0012\u001c\b\u0002\u0010\u000f\u001a\u0016\u0012\u0004\u0012\u00020\u0003\u0018\u00010\nj\n\u0012\u0004\u0012\u00020\u0003\u0018\u0001`\u000b\u0012\n\b\u0002\u0010\u0010\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u0003\u0012\u001c\b\u0002\u0010\u0012\u001a\u0016\u0012\u0004\u0012\u00020\u0003\u0018\u00010\nj\n\u0012\u0004\u0012\u00020\u0003\u0018\u0001`\u000b\u0012\b\b\u0002\u0010\u0013\u001a\u00020\u0014¢\u0006\u0002\u0010\u0015J\u000b\u0010+\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u001d\u0010,\u001a\u0016\u0012\u0004\u0012\u00020\u0003\u0018\u00010\nj\n\u0012\u0004\u0012\u00020\u0003\u0018\u0001`\u000bHÆ\u0003J\u000b\u0010-\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010.\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u001d\u0010/\u001a\u0016\u0012\u0004\u0012\u00020\u0003\u0018\u00010\nj\n\u0012\u0004\u0012\u00020\u0003\u0018\u0001`\u000bHÆ\u0003J\t\u00100\u001a\u00020\u0014HÆ\u0003J\u000b\u00101\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u00102\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u00103\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u0017\u00104\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0003\u0018\u00010\bHÆ\u0003J\u001d\u00105\u001a\u0016\u0012\u0004\u0012\u00020\u0003\u0018\u00010\nj\n\u0012\u0004\u0012\u00020\u0003\u0018\u0001`\u000bHÆ\u0003J\u000b\u00106\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u00107\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u00108\u001a\u0004\u0018\u00010\u0003HÆ\u0003Jñ\u0001\u00109\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00032\u0016\b\u0002\u0010\u0007\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0003\u0018\u00010\b2\u001c\b\u0002\u0010\t\u001a\u0016\u0012\u0004\u0012\u00020\u0003\u0018\u00010\nj\n\u0012\u0004\u0012\u00020\u0003\u0018\u0001`\u000b2\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u00032\u001c\b\u0002\u0010\u000f\u001a\u0016\u0012\u0004\u0012\u00020\u0003\u0018\u00010\nj\n\u0012\u0004\u0012\u00020\u0003\u0018\u0001`\u000b2\n\b\u0002\u0010\u0010\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u00032\u001c\b\u0002\u0010\u0012\u001a\u0016\u0012\u0004\u0012\u00020\u0003\u0018\u00010\nj\n\u0012\u0004\u0012\u00020\u0003\u0018\u0001`\u000b2\b\b\u0002\u0010\u0013\u001a\u00020\u0014HÆ\u0001J\u0013\u0010:\u001a\u00020\u00142\b\u0010;\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010<\u001a\u00020=HÖ\u0001J\t\u0010>\u001a\u00020\u0003HÖ\u0001R\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u001f\u0010\u0007\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0003\u0018\u00010\b¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0013\u0010\u0011\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0017R\u0013\u0010\r\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0017R\u0013\u0010\u000e\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0017R\u001c\u0010\u0005\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u0017\"\u0004\b\u001e\u0010\u001fR\u0013\u0010\u0010\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u0017R%\u0010\u0012\u001a\u0016\u0012\u0004\u0012\u00020\u0003\u0018\u00010\nj\n\u0012\u0004\u0012\u00020\u0003\u0018\u0001`\u000b¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\"R\u001a\u0010\u0013\u001a\u00020\u0014X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010#\"\u0004\b$\u0010%R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b&\u0010\u0017R\u0013\u0010\f\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b'\u0010\u0017R%\u0010\u000f\u001a\u0016\u0012\u0004\u0012\u00020\u0003\u0018\u00010\nj\n\u0012\u0004\u0012\u00020\u0003\u0018\u0001`\u000b¢\u0006\b\n\u0000\u001a\u0004\b(\u0010\"R%\u0010\t\u001a\u0016\u0012\u0004\u0012\u00020\u0003\u0018\u00010\nj\n\u0012\u0004\u0012\u00020\u0003\u0018\u0001`\u000b¢\u0006\b\n\u0000\u001a\u0004\b)\u0010\"R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b*\u0010\u0017¨\u0006?"},
   d2 = {"Lcom/chattriggers/ctjs/engine/module/ModuleMetadata;", "", "name", "", "version", "entry", "asmEntry", "asmExposedFunctions", "", "tags", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "pictureLink", "creator", "description", "requires", "helpMessage", "changelog", "ignored", "isRequired", "", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Z)V", "getAsmEntry", "()Ljava/lang/String;", "getAsmExposedFunctions", "()Ljava/util/Map;", "getChangelog", "getCreator", "getDescription", "getEntry", "setEntry", "(Ljava/lang/String;)V", "getHelpMessage", "getIgnored", "()Ljava/util/ArrayList;", "()Z", "setRequired", "(Z)V", "getName", "getPictureLink", "getRequires", "getTags", "getVersion", "component1", "component10", "component11", "component12", "component13", "component14", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "", "toString", "ctjs"}
)
public final class ModuleMetadata {
   @Nullable
   private final String name;
   @Nullable
   private final String version;
   @Nullable
   private String entry;
   @Nullable
   private final String asmEntry;
   @Nullable
   private final Map<String, String> asmExposedFunctions;
   @Nullable
   private final ArrayList<String> tags;
   @Nullable
   private final String pictureLink;
   @Nullable
   private final String creator;
   @Nullable
   private final String description;
   @Nullable
   private final ArrayList<String> requires;
   @Nullable
   private final String helpMessage;
   @Nullable
   private final String changelog;
   @Nullable
   private final ArrayList<String> ignored;
   private boolean isRequired;

   public ModuleMetadata(@Nullable String name, @Nullable String version, @Nullable String entry, @Nullable String asmEntry, @Nullable Map<String, String> asmExposedFunctions, @Nullable ArrayList<String> tags, @Nullable String pictureLink, @Nullable String creator, @Nullable String description, @Nullable ArrayList<String> requires, @Nullable String helpMessage, @Nullable String changelog, @Nullable ArrayList<String> ignored, boolean isRequired) {
      this.name = name;
      this.version = version;
      this.entry = entry;
      this.asmEntry = asmEntry;
      this.asmExposedFunctions = asmExposedFunctions;
      this.tags = tags;
      this.pictureLink = pictureLink;
      this.creator = creator;
      this.description = description;
      this.requires = requires;
      this.helpMessage = helpMessage;
      this.changelog = changelog;
      this.ignored = ignored;
      this.isRequired = isRequired;
   }

   // $FF: synthetic method
   public ModuleMetadata(String var1, String var2, String var3, String var4, Map var5, ArrayList var6, String var7, String var8, String var9, ArrayList var10, String var11, String var12, ArrayList var13, boolean var14, int var15, DefaultConstructorMarker var16) {
      if ((var15 & 1) != 0) {
         var1 = null;
      }

      if ((var15 & 2) != 0) {
         var2 = null;
      }

      if ((var15 & 4) != 0) {
         var3 = null;
      }

      if ((var15 & 8) != 0) {
         var4 = null;
      }

      if ((var15 & 16) != 0) {
         var5 = null;
      }

      if ((var15 & 32) != 0) {
         var6 = null;
      }

      if ((var15 & 64) != 0) {
         var7 = null;
      }

      if ((var15 & 128) != 0) {
         var8 = null;
      }

      if ((var15 & 256) != 0) {
         var9 = null;
      }

      if ((var15 & 512) != 0) {
         var10 = null;
      }

      if ((var15 & 1024) != 0) {
         var11 = null;
      }

      if ((var15 & 2048) != 0) {
         var12 = null;
      }

      if ((var15 & 4096) != 0) {
         var13 = null;
      }

      if ((var15 & 8192) != 0) {
         var14 = false;
      }

      this(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14);
   }

   @Nullable
   public final String getName() {
      return this.name;
   }

   @Nullable
   public final String getVersion() {
      return this.version;
   }

   @Nullable
   public final String getEntry() {
      return this.entry;
   }

   public final void setEntry(@Nullable String var1) {
      this.entry = var1;
   }

   @Nullable
   public final String getAsmEntry() {
      return this.asmEntry;
   }

   @Nullable
   public final Map<String, String> getAsmExposedFunctions() {
      return this.asmExposedFunctions;
   }

   @Nullable
   public final ArrayList<String> getTags() {
      return this.tags;
   }

   @Nullable
   public final String getPictureLink() {
      return this.pictureLink;
   }

   @Nullable
   public final String getCreator() {
      return this.creator;
   }

   @Nullable
   public final String getDescription() {
      return this.description;
   }

   @Nullable
   public final ArrayList<String> getRequires() {
      return this.requires;
   }

   @Nullable
   public final String getHelpMessage() {
      return this.helpMessage;
   }

   @Nullable
   public final String getChangelog() {
      return this.changelog;
   }

   @Nullable
   public final ArrayList<String> getIgnored() {
      return this.ignored;
   }

   public final boolean isRequired() {
      return this.isRequired;
   }

   public final void setRequired(boolean var1) {
      this.isRequired = var1;
   }

   @Nullable
   public final String component1() {
      return this.name;
   }

   @Nullable
   public final String component2() {
      return this.version;
   }

   @Nullable
   public final String component3() {
      return this.entry;
   }

   @Nullable
   public final String component4() {
      return this.asmEntry;
   }

   @Nullable
   public final Map<String, String> component5() {
      return this.asmExposedFunctions;
   }

   @Nullable
   public final ArrayList<String> component6() {
      return this.tags;
   }

   @Nullable
   public final String component7() {
      return this.pictureLink;
   }

   @Nullable
   public final String component8() {
      return this.creator;
   }

   @Nullable
   public final String component9() {
      return this.description;
   }

   @Nullable
   public final ArrayList<String> component10() {
      return this.requires;
   }

   @Nullable
   public final String component11() {
      return this.helpMessage;
   }

   @Nullable
   public final String component12() {
      return this.changelog;
   }

   @Nullable
   public final ArrayList<String> component13() {
      return this.ignored;
   }

   public final boolean component14() {
      return this.isRequired;
   }

   @NotNull
   public final ModuleMetadata copy(@Nullable String name, @Nullable String version, @Nullable String entry, @Nullable String asmEntry, @Nullable Map<String, String> asmExposedFunctions, @Nullable ArrayList<String> tags, @Nullable String pictureLink, @Nullable String creator, @Nullable String description, @Nullable ArrayList<String> requires, @Nullable String helpMessage, @Nullable String changelog, @Nullable ArrayList<String> ignored, boolean isRequired) {
      return new ModuleMetadata(name, version, entry, asmEntry, asmExposedFunctions, tags, pictureLink, creator, description, requires, helpMessage, changelog, ignored, isRequired);
   }

   // $FF: synthetic method
   public static ModuleMetadata copy$default(ModuleMetadata var0, String var1, String var2, String var3, String var4, Map var5, ArrayList var6, String var7, String var8, String var9, ArrayList var10, String var11, String var12, ArrayList var13, boolean var14, int var15, Object var16) {
      if ((var15 & 1) != 0) {
         var1 = var0.name;
      }

      if ((var15 & 2) != 0) {
         var2 = var0.version;
      }

      if ((var15 & 4) != 0) {
         var3 = var0.entry;
      }

      if ((var15 & 8) != 0) {
         var4 = var0.asmEntry;
      }

      if ((var15 & 16) != 0) {
         var5 = var0.asmExposedFunctions;
      }

      if ((var15 & 32) != 0) {
         var6 = var0.tags;
      }

      if ((var15 & 64) != 0) {
         var7 = var0.pictureLink;
      }

      if ((var15 & 128) != 0) {
         var8 = var0.creator;
      }

      if ((var15 & 256) != 0) {
         var9 = var0.description;
      }

      if ((var15 & 512) != 0) {
         var10 = var0.requires;
      }

      if ((var15 & 1024) != 0) {
         var11 = var0.helpMessage;
      }

      if ((var15 & 2048) != 0) {
         var12 = var0.changelog;
      }

      if ((var15 & 4096) != 0) {
         var13 = var0.ignored;
      }

      if ((var15 & 8192) != 0) {
         var14 = var0.isRequired;
      }

      return var0.copy(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14);
   }

   @NotNull
   public String toString() {
      StringBuilder var1 = new StringBuilder();
      var1.append("ModuleMetadata(name=").append(this.name).append(", version=").append(this.version).append(", entry=").append(this.entry).append(", asmEntry=").append(this.asmEntry).append(", asmExposedFunctions=").append(this.asmExposedFunctions).append(", tags=").append(this.tags).append(", pictureLink=").append(this.pictureLink).append(", creator=").append(this.creator).append(", description=").append(this.description).append(", requires=").append(this.requires).append(", helpMessage=").append(this.helpMessage).append(", changelog=");
      var1.append(this.changelog).append(", ignored=").append(this.ignored).append(", isRequired=").append(this.isRequired).append(')');
      return var1.toString();
   }

   public int hashCode() {
      int result = this.name == null ? 0 : this.name.hashCode();
      result = result * 31 + (this.version == null ? 0 : this.version.hashCode());
      result = result * 31 + (this.entry == null ? 0 : this.entry.hashCode());
      result = result * 31 + (this.asmEntry == null ? 0 : this.asmEntry.hashCode());
      result = result * 31 + (this.asmExposedFunctions == null ? 0 : this.asmExposedFunctions.hashCode());
      result = result * 31 + (this.tags == null ? 0 : this.tags.hashCode());
      result = result * 31 + (this.pictureLink == null ? 0 : this.pictureLink.hashCode());
      result = result * 31 + (this.creator == null ? 0 : this.creator.hashCode());
      result = result * 31 + (this.description == null ? 0 : this.description.hashCode());
      result = result * 31 + (this.requires == null ? 0 : this.requires.hashCode());
      result = result * 31 + (this.helpMessage == null ? 0 : this.helpMessage.hashCode());
      result = result * 31 + (this.changelog == null ? 0 : this.changelog.hashCode());
      result = result * 31 + (this.ignored == null ? 0 : this.ignored.hashCode());
      int var10000 = result * 31;
      byte var10001 = this.isRequired;
      if (var10001 != 0) {
         var10001 = 1;
      }

      result = var10000 + var10001;
      return result;
   }

   public boolean equals(@Nullable Object other) {
      if (this == other) {
         return true;
      } else if (!(other instanceof ModuleMetadata)) {
         return false;
      } else {
         ModuleMetadata var2 = (ModuleMetadata)other;
         if (!Intrinsics.areEqual(this.name, var2.name)) {
            return false;
         } else if (!Intrinsics.areEqual(this.version, var2.version)) {
            return false;
         } else if (!Intrinsics.areEqual(this.entry, var2.entry)) {
            return false;
         } else if (!Intrinsics.areEqual(this.asmEntry, var2.asmEntry)) {
            return false;
         } else if (!Intrinsics.areEqual(this.asmExposedFunctions, var2.asmExposedFunctions)) {
            return false;
         } else if (!Intrinsics.areEqual(this.tags, var2.tags)) {
            return false;
         } else if (!Intrinsics.areEqual(this.pictureLink, var2.pictureLink)) {
            return false;
         } else if (!Intrinsics.areEqual(this.creator, var2.creator)) {
            return false;
         } else if (!Intrinsics.areEqual(this.description, var2.description)) {
            return false;
         } else if (!Intrinsics.areEqual(this.requires, var2.requires)) {
            return false;
         } else if (!Intrinsics.areEqual(this.helpMessage, var2.helpMessage)) {
            return false;
         } else if (!Intrinsics.areEqual(this.changelog, var2.changelog)) {
            return false;
         } else if (!Intrinsics.areEqual(this.ignored, var2.ignored)) {
            return false;
         } else {
            return this.isRequired == var2.isRequired;
         }
      }
   }

   public ModuleMetadata() {
      this((String)null, (String)null, (String)null, (String)null, (Map)null, (ArrayList)null, (String)null, (String)null, (String)null, (ArrayList)null, (String)null, (String)null, (ArrayList)null, false, 16383, (DefaultConstructorMarker)null);
   }
}
