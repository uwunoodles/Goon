package com.chattriggers.ctjs.engine.module;

import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.minecraft.libs.renderer.Renderer;
import com.chattriggers.ctjs.minecraft.libs.renderer.Text;
import com.fasterxml.jackson.core.Version;
import java.io.File;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000K\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\b\t\n\u0002\u0010#\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0003*\u0001\f\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\u001e\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020#2\u0006\u0010%\u001a\u00020&J\u001e\u0010'\u001a\u00020&2\u0006\u0010\"\u001a\u00020&2\u0006\u0010$\u001a\u00020&2\u0006\u0010%\u001a\u00020&J\b\u0010(\u001a\u00020\u0003H\u0016R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0010\u0010\u000b\u001a\u00020\fX\u0082\u0004¢\u0006\u0004\n\u0002\u0010\rR\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R \u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00030\u0015X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019R\u001c\u0010\u001a\u001a\u0004\u0018\u00010\u001bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\u001d\"\u0004\b\u001e\u0010\u001f¨\u0006)"},
   d2 = {"Lcom/chattriggers/ctjs/engine/module/Module;", "", "name", "", "metadata", "Lcom/chattriggers/ctjs/engine/module/ModuleMetadata;", "folder", "Ljava/io/File;", "(Ljava/lang/String;Lcom/chattriggers/ctjs/engine/module/ModuleMetadata;Ljava/io/File;)V", "getFolder", "()Ljava/io/File;", "gui", "com/chattriggers/ctjs/engine/module/Module$gui$1", "Lcom/chattriggers/ctjs/engine/module/Module$gui$1;", "getMetadata", "()Lcom/chattriggers/ctjs/engine/module/ModuleMetadata;", "setMetadata", "(Lcom/chattriggers/ctjs/engine/module/ModuleMetadata;)V", "getName", "()Ljava/lang/String;", "requiredBy", "", "getRequiredBy", "()Ljava/util/Set;", "setRequiredBy", "(Ljava/util/Set;)V", "targetModVersion", "Lcom/fasterxml/jackson/core/Version;", "getTargetModVersion", "()Lcom/fasterxml/jackson/core/Version;", "setTargetModVersion", "(Lcom/fasterxml/jackson/core/Version;)V", "click", "", "x", "", "y", "width", "", "draw", "toString", "ctjs"}
)
public final class Module {
   @NotNull
   private final String name;
   @NotNull
   private ModuleMetadata metadata;
   @NotNull
   private final File folder;
   @Nullable
   private Version targetModVersion;
   @NotNull
   private Set<String> requiredBy;
   @NotNull
   private final <undefinedtype> gui;

   public Module(@NotNull String name, @NotNull ModuleMetadata metadata, @NotNull File folder) {
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(metadata, "metadata");
      Intrinsics.checkNotNullParameter(folder, "folder");
      super();
      this.name = name;
      this.metadata = metadata;
      this.folder = folder;
      this.requiredBy = (Set)(new LinkedHashSet());
      this.gui = (<undefinedtype>)(new Object() {
         private boolean collapsed = true;
         private float x;
         private float y;
         @NotNull
         private Text description;

         {
            Text var10001 = new Text;
            String var10003 = Module.this.getMetadata().getDescription();
            if (var10003 == null) {
               var10003 = "No description provided in the metadata";
            }

            this.description = var10001;
         }

         public final boolean getCollapsed() {
            return this.collapsed;
         }

         public final void setCollapsed(boolean var1) {
            this.collapsed = var1;
         }

         public final float getX() {
            return this.x;
         }

         public final void setX(float var1) {
            this.x = var1;
         }

         public final float getY() {
            return this.y;
         }

         public final void setY(float var1) {
            this.y = var1;
         }

         @NotNull
         public final Text getDescription() {
            return this.description;
         }

         public final void setDescription(@NotNull Text var1) {
            Intrinsics.checkNotNullParameter(var1, "<set-?>");
            this.description = var1;
         }
      });
   }

   @NotNull
   public final String getName() {
      return this.name;
   }

   @NotNull
   public final ModuleMetadata getMetadata() {
      return this.metadata;
   }

   public final void setMetadata(@NotNull ModuleMetadata var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.metadata = var1;
   }

   @NotNull
   public final File getFolder() {
      return this.folder;
   }

   @Nullable
   public final Version getTargetModVersion() {
      return this.targetModVersion;
   }

   public final void setTargetModVersion(@Nullable Version var1) {
      this.targetModVersion = var1;
   }

   @NotNull
   public final Set<String> getRequiredBy() {
      return this.requiredBy;
   }

   public final void setRequiredBy(@NotNull Set<String> var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.requiredBy = var1;
   }

   public final float draw(float x, float y, float width) {
      this.gui.setX(x);
      this.gui.setY(y);
      Renderer.drawRect(2852126720L, x, y, width, 13.0F);
      String var10000;
      if (this.metadata.isRequired() && !((Collection)this.requiredBy).isEmpty()) {
         String var10001 = this.metadata.getName();
         if (var10001 == null) {
            var10001 = this.name;
         }

         var10000 = Intrinsics.stringPlus("&7", var10001);
      } else {
         var10000 = this.metadata.getName();
         if (var10000 == null) {
            var10000 = this.name;
         }
      }

      Renderer.drawStringWithShadow(ChatLib.addColor(var10000), x + (float)3, y + (float)3);
      float var4;
      if (this.gui.getCollapsed()) {
         Renderer.translate$default(x + width - (float)5, y + (float)8, 0.0F, 4, (Object)null);
         Renderer.rotate(180.0F);
         Renderer.drawString$default("^", 0.0F, 0.0F, false, 8, (Object)null);
         var4 = 15.0F;
      } else {
         this.gui.getDescription().setMaxWidth((int)width - 5);
         Renderer.drawRect(1342177280L, x, y + (float)13, width, this.gui.getDescription().getHeight() + (float)12);
         Renderer.drawString$default("^", x + width - (float)10, y + (float)5, false, 8, (Object)null);
         this.gui.getDescription().draw(x + (float)3, y + (float)15);
         if (this.metadata.getVersion() != null) {
            Renderer.drawStringWithShadow(ChatLib.addColor(Intrinsics.stringPlus("&8v", this.metadata.getVersion())), x + width - (float)Renderer.getStringWidth(ChatLib.addColor(Intrinsics.stringPlus("&8v", this.metadata.getVersion()))), y + this.gui.getDescription().getHeight() + (float)15);
         }

         Renderer.drawStringWithShadow(ChatLib.addColor(this.metadata.isRequired() && !((Collection)this.requiredBy).isEmpty() ? Intrinsics.stringPlus("&8required by ", this.requiredBy) : "&4[delete]"), x + (float)3, y + this.gui.getDescription().getHeight() + (float)15);
         var4 = this.gui.getDescription().getHeight() + (float)27;
      }

      return var4;
   }

   public final void click(int x, int y, float width) {
      if ((float)x > this.gui.getX() && (float)x < this.gui.getX() + width && (float)y > this.gui.getY() && (float)y < this.gui.getY() + (float)13) {
         this.gui.setCollapsed(!this.gui.getCollapsed());
      } else if (!this.gui.getCollapsed() && (!this.metadata.isRequired() || ((Collection)this.requiredBy).isEmpty())) {
         if ((float)x > this.gui.getX() && (float)x < this.gui.getX() + (float)45 && (float)y > this.gui.getY() + this.gui.getDescription().getHeight() + (float)15 && (float)y < this.gui.getY() + this.gui.getDescription().getHeight() + (float)25) {
            ModuleManager.INSTANCE.deleteModule(this.name);
         }

      }
   }

   @NotNull
   public String toString() {
      return "Module{name=" + this.name + ",version=" + this.metadata.getVersion() + '}';
   }
}
