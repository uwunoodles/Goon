package com.chattriggers.ctjs.engine.module;

import com.chattriggers.ctjs.CTJS;
import com.chattriggers.ctjs.Reference;
import com.chattriggers.ctjs.ReferenceKt;
import com.chattriggers.ctjs.engine.ILoader;
import com.chattriggers.ctjs.engine.langs.js.JSContextFactory;
import com.chattriggers.ctjs.engine.langs.js.JSLoader;
import com.chattriggers.ctjs.launch.IndySupport;
import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.minecraft.libs.FileLib;
import com.chattriggers.ctjs.minecraft.wrappers.World;
import com.chattriggers.ctjs.triggers.TriggerType;
import com.chattriggers.ctjs.utils.Config;
import com.chattriggers.ctjs.utils.console.Console;
import com.chattriggers.ctjs.utils.console.LogType;
import gg.essential.vigilance.impl.nightconfig.core.file.FileConfig;
import java.io.File;
import java.lang.invoke.MethodHandle;
import java.net.URI;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.io.FileWalkDirection;
import kotlin.io.FilesKt;
import kotlin.jdk7.AutoCloseableKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.StringsKt;
import org.apache.commons.io.FileUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mozilla.javascript.Context;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000t\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001;B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0016\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u0018J\u0006\u0010\u001a\u001a\u00020\u001bJ\u000e\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u0018J;\u0010\u001f\u001a\u00020\u001b2\u000e\b\u0002\u0010 \u001a\b\u0012\u0004\u0012\u00020\u00050\r2#\b\u0002\u0010!\u001a\u001d\u0012\u0013\u0012\u00110#¢\u0006\f\b$\u0012\b\b\u001e\u0012\u0004\b\b(%\u0012\u0004\u0012\u00020\u001b0\"J\u000e\u0010&\u001a\u00020\t2\u0006\u0010'\u001a\u00020\u0018J\u0016\u0010(\u001a\b\u0012\u0004\u0012\u00020\u00100\r2\u0006\u0010)\u001a\u00020\u0010H\u0002J\u000e\u0010*\u001a\u00020+2\u0006\u0010\u0017\u001a\u00020\u0018J\u0016\u0010,\u001a\u00020\u001b2\f\u0010 \u001a\b\u0012\u0004\u0012\u00020\u00050\rH\u0002J\u0016\u0010-\u001a\u00020\u001b2\f\u0010 \u001a\b\u0012\u0004\u0012\u00020\u00050\rH\u0002J\u000e\u0010.\u001a\u00020\u00052\u0006\u0010/\u001a\u00020\u0010J\u000e\u00100\u001a\u00020\u001b2\u0006\u00101\u001a\u00020\u0005J\u0006\u00102\u001a\u00020\u001bJ\u0006\u00103\u001a\u00020\u001bJ%\u00104\u001a\u00020\u001b2\u0006\u00105\u001a\u0002062\u0010\u00107\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u000108¢\u0006\u0002\u00109J\u000e\u0010:\u001a\u00020\u001b2\u0006\u00101\u001a\u00020\u0005R\u0017\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u000f\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0017\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0007¨\u0006<"},
   d2 = {"Lcom/chattriggers/ctjs/engine/module/ModuleManager;", "", "()V", "cachedModules", "", "Lcom/chattriggers/ctjs/engine/module/Module;", "getCachedModules", "()Ljava/util/List;", "generalConsole", "Lcom/chattriggers/ctjs/utils/console/Console;", "getGeneralConsole", "()Lcom/chattriggers/ctjs/utils/console/Console;", "loaders", "", "Lcom/chattriggers/ctjs/engine/langs/js/JSLoader;", "modulesFolder", "Ljava/io/File;", "getModulesFolder", "()Ljava/io/File;", "pendingOldModules", "getPendingOldModules", "asmInvokeLookup", "Ljava/lang/invoke/MethodHandle;", "moduleName", "", "functionID", "asmPass", "", "deleteModule", "", "name", "entryPass", "modules", "completionListener", "Lkotlin/Function1;", "", "Lkotlin/ParameterName;", "percentComplete", "getConsole", "language", "getFoldersInDir", "dir", "importModule", "Lcom/chattriggers/ctjs/engine/module/ModuleManager$ImportedModule;", "loadAssets", "loadAssetsAndJars", "parseModule", "directory", "reportOldVersion", "module", "setup", "teardown", "trigger", "type", "Lcom/chattriggers/ctjs/triggers/TriggerType;", "arguments", "", "(Lcom/chattriggers/ctjs/triggers/TriggerType;[Ljava/lang/Object;)V", "tryReportOldVersion", "ImportedModule", "ctjs"}
)
public final class ModuleManager {
   @NotNull
   public static final ModuleManager INSTANCE;
   @NotNull
   private static final List<JSLoader> loaders;
   @NotNull
   private static final Console generalConsole;
   @NotNull
   private static final List<Module> cachedModules;
   @NotNull
   private static final File modulesFolder;
   @NotNull
   private static final List<Module> pendingOldModules;

   private ModuleManager() {
   }

   @NotNull
   public final Console getGeneralConsole() {
      return generalConsole;
   }

   @NotNull
   public final List<Module> getCachedModules() {
      return cachedModules;
   }

   @NotNull
   public final File getModulesFolder() {
      return modulesFolder;
   }

   @NotNull
   public final List<Module> getPendingOldModules() {
      return pendingOldModules;
   }

   public final void setup() {
      modulesFolder.mkdirs();
      ModuleUpdater.INSTANCE.importPendingModules();
      Iterable $this$forEach$iv = (Iterable)this.getFoldersInDir(modulesFolder);
      int $i$f$forEach = false;
      Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$forEach$iv, 10)));
      int $i$f$mapTo = false;
      Iterator var7 = $this$forEach$iv.iterator();

      boolean $i$f$forEach;
      while(var7.hasNext()) {
         Object item$iv$iv = var7.next();
         File p0 = (File)item$iv$iv;
         $i$f$forEach = false;
         destination$iv$iv.add(this.parseModule(p0));
      }

      $this$forEach$iv = (Iterable)((List)destination$iv$iv);
      $i$f$forEach = false;
      HashSet set$iv = new HashSet();
      ArrayList list$iv = new ArrayList();
      Iterator var22 = $this$forEach$iv.iterator();

      while(var22.hasNext()) {
         Object e$iv = var22.next();
         Module it = (Module)e$iv;
         int var31 = false;
         String var10000 = it.getName().toLowerCase(Locale.ROOT);
         Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String).toLowerCase(Locale.ROOT)");
         Object key$iv = var10000;
         if (set$iv.add(key$iv)) {
            list$iv.add(e$iv);
         }
      }

      List installedModules = (List)list$iv;
      $this$forEach$iv = (Iterable)installedModules;
      ModuleUpdater var16 = ModuleUpdater.INSTANCE;
      int $i$f$forEach = false;
      Iterator var20 = $this$forEach$iv.iterator();

      while(var20.hasNext()) {
         Object element$iv = var20.next();
         Module p0 = (Module)element$iv;
         int var30 = false;
         var16.updateModule(p0);
      }

      cachedModules.addAll((Collection)installedModules);
      $this$forEach$iv = (Iterable)CollectionsKt.distinct((Iterable)installedModules);
      $i$f$forEach = false;
      Iterator var18 = $this$forEach$iv.iterator();

      while(var18.hasNext()) {
         Object element$iv = var18.next();
         Module module = (Module)element$iv;
         int var27 = false;
         ArrayList var33 = module.getMetadata().getRequires();
         if (var33 != null) {
            Iterable $this$forEach$iv = (Iterable)var33;
            $i$f$forEach = false;
            Iterator var11 = $this$forEach$iv.iterator();

            while(var11.hasNext()) {
               Object element$iv = var11.next();
               String it = (String)element$iv;
               int var14 = false;
               ModuleUpdater.INSTANCE.importModule(it, module.getName());
            }
         }
      }

      this.loadAssetsAndJars(cachedModules);
      IndySupport.INSTANCE.invalidateInvocations();
   }

   private final void loadAssetsAndJars(List<Module> modules) {
      this.loadAssets(modules);
      Iterable $this$forEach$iv = (Iterable)modules;
      int $i$f$forEach = false;

      boolean $i$f$mapTo;
      ModuleMetadata var10000;
      String var10001;
      for(Iterator var4 = $this$forEach$iv.iterator(); var4.hasNext(); var10000.setEntry(var10001)) {
         Object element$iv = var4.next();
         Module it = (Module)element$iv;
         $i$f$mapTo = false;
         var10000 = it.getMetadata();
         var10001 = it.getMetadata().getEntry();
         if (var10001 == null) {
            var10001 = null;
         } else {
            var10001 = StringsKt.replace$default(var10001, '/', File.separatorChar, false, 4, (Object)null);
            var10001 = var10001 == null ? null : StringsKt.replace$default(var10001, '\\', File.separatorChar, false, 4, (Object)null);
         }
      }

      Iterable $this$forEach$iv = (Iterable)modules;
      int $i$f$forEach = false;
      Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$forEach$iv, 10)));
      $i$f$mapTo = false;
      Iterator var8 = $this$forEach$iv.iterator();

      while(var8.hasNext()) {
         Object item$iv$iv = var8.next();
         Module module = (Module)item$iv$iv;
         int var11 = false;
         destination$iv$iv.add(SequencesKt.toList(SequencesKt.map(SequencesKt.filter((Sequence)FilesKt.walk$default(module.getFolder(), (FileWalkDirection)null, 1, (Object)null), (Function1)null.INSTANCE), (Function1)null.INSTANCE)));
      }

      List jars = CollectionsKt.flatten((Iterable)((List)destination$iv$iv));
      $this$forEach$iv = (Iterable)loaders;
      $i$f$forEach = false;
      Iterator var16 = $this$forEach$iv.iterator();

      while(var16.hasNext()) {
         Object element$iv = var16.next();
         JSLoader it = (JSLoader)element$iv;
         int var20 = false;
         it.setup(jars);
      }

   }

   public final void asmPass() {
      Iterable $this$forEach$iv = (Iterable)loaders;
      int $i$f$forEach = false;
      Iterator var3 = $this$forEach$iv.iterator();

      Object element$iv;
      boolean var6;
      while(var3.hasNext()) {
         element$iv = var3.next();
         ILoader p0 = (ILoader)element$iv;
         var6 = false;
         p0.asmSetup();
      }

      $this$forEach$iv = (Iterable)loaders;
      $i$f$forEach = false;
      var3 = $this$forEach$iv.iterator();

      while(var3.hasNext()) {
         element$iv = var3.next();
         JSLoader loader = (JSLoader)element$iv;
         var6 = false;
         Iterable $this$forEach$iv = (Iterable)INSTANCE.getCachedModules();
         int $i$f$forEach = false;
         Collection destination$iv$iv = (Collection)(new ArrayList());
         int $i$f$filterTo = false;
         Iterator var12 = $this$forEach$iv.iterator();

         while(var12.hasNext()) {
            Object element$iv$iv = var12.next();
            Module it = (Module)element$iv$iv;
            int var15 = false;
            File var10000 = it.getFolder();
            String var10001 = it.getMetadata().getAsmEntry();
            boolean var24;
            if (var10001 == null) {
               boolean var16 = false;
               var24 = var16;
            } else {
               String var17 = var10001;
               File var18 = var10000;
               var24 = Intrinsics.areEqual(FilesKt.getExtension(new File(var18, var17)), loader.getLanguage().getExtension());
            }

            if (var24) {
               destination$iv$iv.add(element$iv$iv);
            }
         }

         $this$forEach$iv = (Iterable)((List)destination$iv$iv);
         $i$f$forEach = false;
         Iterator var9 = $this$forEach$iv.iterator();

         while(var9.hasNext()) {
            Object element$iv = var9.next();
            Module it = (Module)element$iv;
            int var22 = false;
            File var10004 = it.getFolder();
            String var10005 = it.getMetadata().getAsmEntry();
            Intrinsics.checkNotNull(var10005);
            URI var23 = (new File(var10004, var10005)).toURI();
            Intrinsics.checkNotNullExpressionValue(var23, "File(it.folder, it.metadata.asmEntry!!).toURI()");
            loader.asmPass(it, var23);
         }
      }

   }

   public final void entryPass(@NotNull List<Module> modules, @NotNull Function1<? super Float, Unit> completionListener) {
      Intrinsics.checkNotNullParameter(modules, "modules");
      Intrinsics.checkNotNullParameter(completionListener, "completionListener");
      Iterable $this$forEach$iv = (Iterable)loaders;
      int $i$f$forEach = false;
      Iterator var5 = $this$forEach$iv.iterator();

      while(var5.hasNext()) {
         Object element$iv = var5.next();
         ILoader p0 = (ILoader)element$iv;
         int var8 = false;
         p0.entrySetup();
      }

      Iterable $this$count$iv = (Iterable)modules;
      int $i$f$count = false;
      boolean var10;
      int var10000;
      Iterator var30;
      Object element$iv;
      if ($this$count$iv instanceof Collection && ((Collection)$this$count$iv).isEmpty()) {
         var10000 = 0;
      } else {
         int count$iv = 0;
         var30 = $this$count$iv.iterator();

         while(var30.hasNext()) {
            element$iv = var30.next();
            Module it = (Module)element$iv;
            var10 = false;
            if (it.getMetadata().getEntry() != null) {
               ++count$iv;
               if (count$iv < 0) {
                  CollectionsKt.throwCountOverflow();
               }
            }
         }

         var10000 = count$iv;
      }

      int total = var10000;
      int completed = 0;
      Iterable $this$forEach$iv = (Iterable)loaders;
      int $i$f$forEach = false;
      var30 = $this$forEach$iv.iterator();

      while(var30.hasNext()) {
         element$iv = var30.next();
         JSLoader loader = (JSLoader)element$iv;
         var10 = false;
         Iterable $this$forEach$iv = (Iterable)modules;
         int $i$f$forEach = false;
         Collection destination$iv$iv = (Collection)(new ArrayList());
         int $i$f$filterTo = false;
         Iterator var16 = $this$forEach$iv.iterator();

         while(var16.hasNext()) {
            Object element$iv$iv = var16.next();
            Module it = (Module)element$iv$iv;
            int var19 = false;
            File var36 = it.getFolder();
            String var10001 = it.getMetadata().getEntry();
            boolean var37;
            if (var10001 == null) {
               boolean var20 = false;
               var37 = var20;
            } else {
               String var21 = var10001;
               File var22 = var36;
               var37 = Intrinsics.areEqual(FilesKt.getExtension(new File(var22, var21)), loader.getLanguage().getExtension());
            }

            if (var37) {
               destination$iv$iv.add(element$iv$iv);
            }
         }

         $this$forEach$iv = (Iterable)((List)destination$iv$iv);
         $i$f$forEach = false;
         Iterator var13 = $this$forEach$iv.iterator();

         while(var13.hasNext()) {
            Object element$iv = var13.next();
            Module it = (Module)element$iv;
            int var35 = false;
            File var10004 = it.getFolder();
            String var10005 = it.getMetadata().getEntry();
            Intrinsics.checkNotNull(var10005);
            URI var38 = (new File(var10004, var10005)).toURI();
            Intrinsics.checkNotNullExpressionValue(var38, "File(it.folder, it.metadata.entry!!).toURI()");
            loader.entryPass(it, var38);
            ++completed;
            completionListener.invoke((float)completed / (float)total);
         }
      }

   }

   // $FF: synthetic method
   public static void entryPass$default(ModuleManager var0, List var1, Function1 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = cachedModules;
      }

      if ((var3 & 2) != 0) {
         var2 = (Function1)null.INSTANCE;
      }

      var0.entryPass(var1, var2);
   }

   @NotNull
   public final MethodHandle asmInvokeLookup(@NotNull String moduleName, @NotNull String functionID) {
      Intrinsics.checkNotNullParameter(moduleName, "moduleName");
      Intrinsics.checkNotNullParameter(functionID, "functionID");
      Iterable $this$first$iv = (Iterable)cachedModules;
      int $i$f$first = false;
      Iterator var6 = $this$first$iv.iterator();

      Object element$iv;
      Module it;
      do {
         if (!var6.hasNext()) {
            throw new NoSuchElementException("Collection contains no element matching the predicate.");
         }

         element$iv = var6.next();
         it = (Module)element$iv;
         int var9 = false;
      } while(!Intrinsics.areEqual(it.getName(), moduleName));

      Module module = (Module)element$iv;
      Map var10000 = module.getMetadata().getAsmExposedFunctions();
      String var19 = var10000 == null ? null : (String)var10000.get(functionID);
      if (var19 == null) {
         throw new IllegalArgumentException("Module " + module + " contains no asm exported function with id " + functionID);
      } else {
         String funcPath = var19;
         File funcFile = new File(module.getFolder(), StringsKt.replace$default(StringsKt.replace$default(funcPath, '/', File.separatorChar, false, 4, (Object)null), '\\', File.separatorChar, false, 4, (Object)null));
         Iterable $this$first$iv = (Iterable)loaders;
         int $i$f$first = false;
         Iterator var17 = $this$first$iv.iterator();

         JSLoader it;
         Object element$iv;
         do {
            if (!var17.hasNext()) {
               throw new NoSuchElementException("Collection contains no element matching the predicate.");
            }

            element$iv = var17.next();
            it = (JSLoader)element$iv;
            int var11 = false;
         } while(!Intrinsics.areEqual(it.getLanguage().getExtension(), FilesKt.getExtension(funcFile)));

         JSLoader var20 = (JSLoader)element$iv;
         URI var15 = funcFile.toURI();
         Intrinsics.checkNotNullExpressionValue(var15, "funcFile.toURI()");
         return var20.asmInvokeLookup(module, var15);
      }
   }

   private final List<File> getFoldersInDir(File dir) {
      if (!dir.isDirectory()) {
         return CollectionsKt.emptyList();
      } else {
         File[] var10000 = dir.listFiles();
         List var13;
         if (var10000 == null) {
            var13 = null;
         } else {
            Object[] $this$filter$iv = var10000;
            int $i$f$filter = false;
            File[] $this$filterTo$iv$iv = $this$filter$iv;
            Collection destination$iv$iv = (Collection)(new ArrayList());
            int $i$f$filterTo = false;
            int var8 = 0;

            for(int var9 = $this$filter$iv.length; var8 < var9; ++var8) {
               Object element$iv$iv = $this$filterTo$iv$iv[var8];
               int var12 = false;
               if (element$iv$iv.isDirectory()) {
                  destination$iv$iv.add(element$iv$iv);
               }
            }

            var13 = (List)destination$iv$iv;
         }

         List var2 = var13;
         return var2 == null ? CollectionsKt.emptyList() : var2;
      }
   }

   @NotNull
   public final Module parseModule(@NotNull File directory) {
      Intrinsics.checkNotNullParameter(directory, "directory");
      File metadataFile = new File(directory, "metadata.json");
      ModuleMetadata metadata = new ModuleMetadata((String)null, (String)null, (String)null, (String)null, (Map)null, (ArrayList)null, (String)null, (String)null, (String)null, (ArrayList)null, (String)null, (String)null, (ArrayList)null, false, 16383, (DefaultConstructorMarker)null);
      if (metadataFile.exists()) {
         try {
            Object var4 = CTJS.INSTANCE.getGson().fromJson(FileLib.read(metadataFile), ModuleMetadata.class);
            Intrinsics.checkNotNullExpressionValue(var4, "CTJS.gson.fromJson(FileL…duleMetadata::class.java)");
            metadata = (ModuleMetadata)var4;
         } catch (Exception var5) {
            ReferenceKt.printToConsole$default("Module " + directory + " has invalid metadata.json", (Console)null, LogType.ERROR, 1, (Object)null);
         }
      }

      String var6 = directory.getName();
      Intrinsics.checkNotNullExpressionValue(var6, "directory.name");
      return new Module(var6, metadata, directory);
   }

   @NotNull
   public final ModuleManager.ImportedModule importModule(@NotNull String moduleName) {
      Intrinsics.checkNotNullParameter(moduleName, "moduleName");
      List newModules = ModuleUpdater.importModule$default(ModuleUpdater.INSTANCE, moduleName, (String)null, 2, (Object)null);
      this.loadAssetsAndJars(newModules);
      entryPass$default(this, newModules, (Function1)null, 2, (Object)null);
      return new ModuleManager.ImportedModule((Module)CollectionsKt.getOrNull(newModules, 0), CollectionsKt.drop((Iterable)newModules, 1));
   }

   public final boolean deleteModule(@NotNull String name) {
      Intrinsics.checkNotNullParameter(name, "name");
      Iterator var6 = ((Iterable)cachedModules).iterator();

      Object var10000;
      while(true) {
         if (var6.hasNext()) {
            Object var7 = var6.next();
            Module it = (Module)var7;
            int var9 = false;
            String var15 = it.getName().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(var15, "this as java.lang.String).toLowerCase(Locale.ROOT)");
            String var10001 = name.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).toLowerCase(Locale.ROOT)");
            if (!Intrinsics.areEqual(var15, var10001)) {
               continue;
            }

            var10000 = var7;
            break;
         }

         var10000 = null;
         break;
      }

      Module var16 = (Module)var10000;
      if (var16 == null) {
         return false;
      } else {
         Module module = var16;
         File file = new File(modulesFolder, module.getName());
         if (!file.exists()) {
            int var12 = false;
            String var13 = "Expected module to have an existing folder!";
            throw new IllegalStateException(var13.toString());
         } else {
            Context context = JSContextFactory.INSTANCE.enterContext();

            boolean var14;
            try {
               ClassLoader var17 = context.getApplicationClassLoader();
               if (var17 == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.net.URLClassLoader");
               }

               URLClassLoader classLoader = (URLClassLoader)var17;
               classLoader.close();
               if (!FilesKt.deleteRecursively(file)) {
                  return false;
               }

               Reference.loadCT();
               var14 = true;
            } finally {
               Context.exit();
            }

            return var14;
         }
      }
   }

   public final void tryReportOldVersion(@NotNull Module module) {
      Intrinsics.checkNotNullParameter(module, "module");
      if (World.isLoaded()) {
         this.reportOldVersion(module);
      } else {
         pendingOldModules.add(module);
      }

   }

   public final void reportOldVersion(@NotNull Module module) {
      Intrinsics.checkNotNullParameter(module, "module");
      ChatLib.chat("&cWarning: the module \"" + module.getName() + "\" was made for an older version of CT, so it may not work correctly.");
   }

   private final void loadAssets(List<Module> modules) {
      Iterable $this$forEach$iv = (Iterable)modules;
      int $i$f$forEach = false;
      Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$forEach$iv, 10)));
      int $i$f$mapTo = false;
      Iterator var7 = $this$forEach$iv.iterator();

      Object item$iv$iv;
      boolean var10;
      while(var7.hasNext()) {
         item$iv$iv = var7.next();
         Module it = (Module)item$iv$iv;
         var10 = false;
         destination$iv$iv.add(new File(it.getFolder(), "assets"));
      }

      $this$forEach$iv = (Iterable)((List)destination$iv$iv);
      $i$f$forEach = false;
      destination$iv$iv = (Collection)(new ArrayList());
      $i$f$mapTo = false;
      var7 = $this$forEach$iv.iterator();

      File it;
      while(var7.hasNext()) {
         item$iv$iv = var7.next();
         it = (File)item$iv$iv;
         var10 = false;
         if (it.exists() && !it.isFile()) {
            destination$iv$iv.add(item$iv$iv);
         }
      }

      $this$forEach$iv = (Iterable)((List)destination$iv$iv);
      $i$f$forEach = false;
      destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$forEach$iv, 10)));
      $i$f$mapTo = false;

      List var16;
      for(var7 = $this$forEach$iv.iterator(); var7.hasNext(); destination$iv$iv.add(var16)) {
         item$iv$iv = var7.next();
         it = (File)item$iv$iv;
         var10 = false;
         File[] var10000 = it.listFiles();
         var16 = var10000 == null ? null : ArraysKt.toList(var10000);
         if (var16 == null) {
            var16 = CollectionsKt.emptyList();
         }
      }

      $this$forEach$iv = (Iterable)CollectionsKt.flatten((Iterable)((List)destination$iv$iv));
      $i$f$forEach = false;
      Iterator var4 = $this$forEach$iv.iterator();

      while(var4.hasNext()) {
         Object element$iv = var4.next();
         File it = (File)element$iv;
         int var14 = false;
         FileUtils.copyFileToDirectory(it, CTJS.INSTANCE.getAssetsDir());
      }

   }

   public final void teardown() {
      cachedModules.clear();
      Iterable $this$forEach$iv = (Iterable)loaders;
      int $i$f$forEach = false;
      Iterator var3 = $this$forEach$iv.iterator();

      while(var3.hasNext()) {
         Object element$iv = var3.next();
         JSLoader it = (JSLoader)element$iv;
         int var6 = false;
         it.clearTriggers();
         if (Config.INSTANCE.getClearConsoleOnLoad()) {
            it.getConsole().clearConsole();
         }
      }

      if (Config.INSTANCE.getClearConsoleOnLoad()) {
         generalConsole.clearConsole();
      }

   }

   public final void trigger(@NotNull TriggerType type, @NotNull Object[] arguments) {
      Intrinsics.checkNotNullParameter(type, "type");
      Intrinsics.checkNotNullParameter(arguments, "arguments");
      Iterable $this$forEach$iv = (Iterable)loaders;
      int $i$f$forEach = false;
      Iterator var5 = $this$forEach$iv.iterator();

      while(var5.hasNext()) {
         Object element$iv = var5.next();
         JSLoader it = (JSLoader)element$iv;
         int var8 = false;
         it.exec(type, arguments);
      }

   }

   @NotNull
   public final Console getConsole(@NotNull String language) {
      Intrinsics.checkNotNullParameter(language, "language");
      Iterable $this$firstOrNull$iv = (Iterable)loaders;
      int $i$f$firstOrNull = false;
      Iterator var6 = $this$firstOrNull$iv.iterator();

      Object var10000;
      while(true) {
         if (var6.hasNext()) {
            Object element$iv = var6.next();
            JSLoader it = (JSLoader)element$iv;
            int var9 = false;
            if (!Intrinsics.areEqual(it.getLanguage().getLangName(), language)) {
               continue;
            }

            var10000 = element$iv;
            break;
         }

         var10000 = null;
         break;
      }

      JSLoader var3 = (JSLoader)var10000;
      Console var2 = var3 == null ? null : var3.getConsole();
      return var2 == null ? generalConsole : var2;
   }

   static {
      File var10000;
      label50: {
         INSTANCE = new ModuleManager();
         loaders = CollectionsKt.listOf(JSLoader.INSTANCE);
         generalConsole = new Console((ILoader)null);
         cachedModules = (List)(new ArrayList());
         ModuleManager $this$modulesFolder_u24lambda_u2d1 = INSTANCE;
         int var1 = false;
         File configFile = new File(CTJS.INSTANCE.getConfigLocation(), "ChatTriggers.toml");
         if (configFile.exists()) {
            try {
               AutoCloseable var3 = (AutoCloseable)FileConfig.of(configFile);
               Throwable var4 = null;

               File var7;
               try {
                  FileConfig it = (FileConfig)var3;
                  int var6 = false;
                  it.load();
                  var7 = new File((String)it.get("general.modules_folders"));
               } catch (Throwable var11) {
                  var4 = var11;
                  throw var11;
               } finally {
                  AutoCloseableKt.closeFinally(var3, var4);
               }

               var10000 = var7;
               break label50;
            } catch (Exception var13) {
               var13.printStackTrace();
            }
         }

         var10000 = new File("./config/ChatTriggers/modules");
      }

      modulesFolder = var10000;
      pendingOldModules = (List)(new ArrayList());
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u001d\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005¢\u0006\u0002\u0010\u0006J\u000b\u0010\u000b\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005HÆ\u0003J%\u0010\r\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\u000e\b\u0002\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001J\t\u0010\u0013\u001a\u00020\u0014HÖ\u0001R\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0015"},
      d2 = {"Lcom/chattriggers/ctjs/engine/module/ModuleManager$ImportedModule;", "", "module", "Lcom/chattriggers/ctjs/engine/module/Module;", "dependencies", "", "(Lcom/chattriggers/ctjs/engine/module/Module;Ljava/util/List;)V", "getDependencies", "()Ljava/util/List;", "getModule", "()Lcom/chattriggers/ctjs/engine/module/Module;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "ctjs"}
   )
   public static final class ImportedModule {
      @Nullable
      private final Module module;
      @NotNull
      private final List<Module> dependencies;

      public ImportedModule(@Nullable Module module, @NotNull List<Module> dependencies) {
         Intrinsics.checkNotNullParameter(dependencies, "dependencies");
         super();
         this.module = module;
         this.dependencies = dependencies;
      }

      @Nullable
      public final Module getModule() {
         return this.module;
      }

      @NotNull
      public final List<Module> getDependencies() {
         return this.dependencies;
      }

      @Nullable
      public final Module component1() {
         return this.module;
      }

      @NotNull
      public final List<Module> component2() {
         return this.dependencies;
      }

      @NotNull
      public final ModuleManager.ImportedModule copy(@Nullable Module module, @NotNull List<Module> dependencies) {
         Intrinsics.checkNotNullParameter(dependencies, "dependencies");
         return new ModuleManager.ImportedModule(module, dependencies);
      }

      // $FF: synthetic method
      public static ModuleManager.ImportedModule copy$default(ModuleManager.ImportedModule var0, Module var1, List var2, int var3, Object var4) {
         if ((var3 & 1) != 0) {
            var1 = var0.module;
         }

         if ((var3 & 2) != 0) {
            var2 = var0.dependencies;
         }

         return var0.copy(var1, var2);
      }

      @NotNull
      public String toString() {
         return "ImportedModule(module=" + this.module + ", dependencies=" + this.dependencies + ')';
      }

      public int hashCode() {
         int result = this.module == null ? 0 : this.module.hashCode();
         result = result * 31 + this.dependencies.hashCode();
         return result;
      }

      public boolean equals(@Nullable Object other) {
         if (this == other) {
            return true;
         } else if (!(other instanceof ModuleManager.ImportedModule)) {
            return false;
         } else {
            ModuleManager.ImportedModule var2 = (ModuleManager.ImportedModule)other;
            if (!Intrinsics.areEqual(this.module, var2.module)) {
               return false;
            } else {
               return Intrinsics.areEqual(this.dependencies, var2.dependencies);
            }
         }
      }
   }
}
