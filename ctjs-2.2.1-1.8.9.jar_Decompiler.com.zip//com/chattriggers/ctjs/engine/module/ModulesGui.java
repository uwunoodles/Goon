package com.chattriggers.ctjs.engine.module;

import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.minecraft.libs.renderer.Renderer;
import com.chattriggers.ctjs.minecraft.libs.renderer.Text;
import com.chattriggers.ctjs.minecraft.wrappers.Player;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Mouse;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000/\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0004*\u0001\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0006\u001a\u00020\u0007H\u0016J \u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000eH\u0016J\b\u0010\u000f\u001a\u00020\tH\u0016J \u0010\u0010\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\u0011\u001a\u00020\u000bH\u0014R\u0010\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0005¨\u0006\u0012"},
   d2 = {"Lcom/chattriggers/ctjs/engine/module/ModulesGui;", "Lnet/minecraft/client/gui/GuiScreen;", "()V", "window", "com/chattriggers/ctjs/engine/module/ModulesGui$window$1", "Lcom/chattriggers/ctjs/engine/module/ModulesGui$window$1;", "doesGuiPauseGame", "", "drawScreen", "", "mouseX", "", "mouseY", "partialTicks", "", "handleMouseInput", "mouseClicked", "button", "ctjs"}
)
public final class ModulesGui extends GuiScreen {
   @NotNull
   public static final ModulesGui INSTANCE = new ModulesGui();
   @NotNull
   private static final <undefinedtype> window = new Object() {
      @NotNull
      private Text title = (new Text("Modules", 0.0F, 0.0F, 6, (DefaultConstructorMarker)null)).setScale(2.0F).setShadow(true);
      @NotNull
      private Text exit = (new Text(ChatLib.addColor("&cx"), 0.0F, 0.0F, 6, (DefaultConstructorMarker)null)).setScale(2.0F);
      private float height;
      private float scroll;

      @NotNull
      public final Text getTitle() {
         return this.title;
      }

      public final void setTitle(@NotNull Text var1) {
         Intrinsics.checkNotNullParameter(var1, "<set-?>");
         this.title = var1;
      }

      @NotNull
      public final Text getExit() {
         return this.exit;
      }

      public final void setExit(@NotNull Text var1) {
         Intrinsics.checkNotNullParameter(var1, "<set-?>");
         this.exit = var1;
      }

      public final float getHeight() {
         return this.height;
      }

      public final void setHeight(float var1) {
         this.height = var1;
      }

      public final float getScroll() {
         return this.scroll;
      }

      public final void setScroll(float var1) {
         this.scroll = var1;
      }
   };

   private ModulesGui() {
   }

   public boolean func_73868_f() {
      return false;
   }

   public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
      super.func_73863_a(mouseX, mouseY, partialTicks);
      GlStateManager.func_179094_E();
      float middle = (float)Renderer.screen.getWidth() / 2.0F;
      float width = 0.0F;
      width = (float)Renderer.screen.getWidth() - 100.0F;
      if (width > 500.0F) {
         width = 500.0F;
      }

      Renderer.drawRect(1342177280L, 0.0F, 0.0F, (float)Renderer.screen.getWidth(), (float)Renderer.screen.getHeight());
      if (-window.getScroll() > window.getHeight() - (float)Renderer.screen.getHeight() + (float)20) {
         window.setScroll(-window.getHeight() + (float)Renderer.screen.getHeight() - (float)20);
      }

      if (-window.getScroll() < 0.0F) {
         window.setScroll(0.0F);
      }

      if (-window.getScroll() > 0.0F) {
         Renderer.drawRect(2852126720L, (float)Renderer.screen.getWidth() - 20.0F, (float)Renderer.screen.getHeight() - 20.0F, 20.0F, 20.0F);
         Renderer.drawString$default("^", (float)Renderer.screen.getWidth() - 12.0F, (float)Renderer.screen.getHeight() - 12.0F, false, 8, (Object)null);
      }

      Renderer.drawRect(1342177280L, middle - width / 2.0F, window.getScroll() + 95.0F, width, window.getHeight() - (float)90);
      Renderer.drawRect(2852126720L, middle - width / 2.0F, window.getScroll() + 95.0F, width, 25.0F);
      window.getTitle().draw(middle - width / 2.0F + (float)5, window.getScroll() + 100.0F);
      window.getExit().setString(ChatLib.addColor("&cx")).draw(middle + width / 2.0F - (float)17, window.getScroll() + 99.0F);
      window.setHeight(125.0F);
      Iterable $this$forEach$iv = (Iterable)ModuleManager.INSTANCE.getCachedModules();
      int $i$f$forEach = false;
      Iterator var8 = $this$forEach$iv.iterator();

      while(var8.hasNext()) {
         Object element$iv = var8.next();
         Module it = (Module)element$iv;
         int var11 = false;
         <undefinedtype> var12 = window;
         var12.setHeight(var12.getHeight() + it.draw(middle - width / 2.0F, window.getScroll() + window.getHeight(), width));
      }

      GlStateManager.func_179121_F();
   }

   protected void func_73864_a(int mouseX, int mouseY, int button) {
      super.func_73864_a(mouseX, mouseY, button);
      float width = 0.0F;
      width = (float)Renderer.screen.getWidth() - 100.0F;
      if (width > 500.0F) {
         width = 500.0F;
      }

      if (mouseX > Renderer.screen.getWidth() - 20 && mouseY > Renderer.screen.getHeight() - 20) {
         window.setScroll(0.0F);
      } else if ((float)mouseX > (float)Renderer.screen.getWidth() / 2.0F + width / 2.0F - (float)25 && (float)mouseX < (float)Renderer.screen.getWidth() / 2.0F + width / 2.0F && (float)mouseY > window.getScroll() + (float)95 && (float)mouseY < window.getScroll() + (float)120) {
         EntityPlayerSP var10000 = Player.getPlayer();
         if (var10000 != null) {
            var10000.func_71053_j();
         }

      } else {
         Iterable $this$forEach$iv = (Iterable)CollectionsKt.toList((Iterable)ModuleManager.INSTANCE.getCachedModules());
         int $i$f$forEach = false;
         Iterator var7 = $this$forEach$iv.iterator();

         while(var7.hasNext()) {
            Object element$iv = var7.next();
            Module it = (Module)element$iv;
            int var10 = false;
            it.click(mouseX, mouseY, width);
         }

      }
   }

   public void func_146274_d() {
      super.func_146274_d();
      int i = Mouse.getEventDWheel();
      <undefinedtype> var2 = window;
      var2.setScroll(var2.getScroll() + (float)(i / 10));
   }
}
