package com.chattriggers.ctjs;

import com.chattriggers.ctjs.commands.CTCommand;
import com.chattriggers.ctjs.engine.module.ModuleManager;
import com.chattriggers.ctjs.engine.module.ModuleUpdater;
import com.chattriggers.ctjs.loader.UriScheme;
import com.chattriggers.ctjs.minecraft.libs.renderer.Image;
import com.chattriggers.ctjs.minecraft.listeners.ClientListener;
import com.chattriggers.ctjs.minecraft.listeners.MouseListener;
import com.chattriggers.ctjs.minecraft.listeners.WorldListener;
import com.chattriggers.ctjs.minecraft.objects.Sound;
import com.chattriggers.ctjs.minecraft.objects.gui.GuiHandler;
import com.chattriggers.ctjs.minecraft.wrappers.CPS;
import com.chattriggers.ctjs.minecraft.wrappers.Player;
import com.chattriggers.ctjs.triggers.ForgeTrigger;
import com.chattriggers.ctjs.utils.Config;
import com.chattriggers.ctjs.utils.UpdateChecker;
import com.google.gson.Gson;
import java.io.File;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.concurrent.ThreadsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.minecraft.command.ICommand;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Mod(
   modid = "chattriggers",
   name = "ChatTriggers",
   version = "2.2.1",
   clientSideOnly = true,
   modLanguage = "Kotlin",
   modLanguageAdapter = "gg.essential.api.utils.KotlinAdapter",
   acceptedMinecraftVersions = "[1.8.9]"
)
@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010#\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020#H\u0007J\u000e\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020\u0004J\u0010\u0010'\u001a\u00020!2\u0006\u0010\"\u001a\u00020(H\u0007J\b\u0010)\u001a\u00020!H\u0002J\b\u0010*\u001a\u00020!H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\t\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\bR\u0011\u0010\u000b\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0017\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0017\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00160\u0015¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R#\u0010\u0019\u001a\u0004\u0018\u00010\u001a8FX\u0087\u0084\u0002¢\u0006\u0012\n\u0004\b\u001e\u0010\u001f\u0012\u0004\b\u001b\u0010\u0002\u001a\u0004\b\u001c\u0010\u001d¨\u0006+"},
   d2 = {"Lcom/chattriggers/ctjs/CTJS;", "", "()V", "WEBSITE_ROOT", "", "assetsDir", "Ljava/io/File;", "getAssetsDir", "()Ljava/io/File;", "configLocation", "getConfigLocation", "gson", "Lcom/google/gson/Gson;", "getGson", "()Lcom/google/gson/Gson;", "images", "", "Lcom/chattriggers/ctjs/minecraft/libs/renderer/Image;", "getImages", "()Ljava/util/Set;", "sounds", "", "Lcom/chattriggers/ctjs/minecraft/objects/Sound;", "getSounds", "()Ljava/util/List;", "sslContext", "Ljavax/net/ssl/SSLContext;", "getSslContext$annotations", "getSslContext", "()Ljavax/net/ssl/SSLContext;", "sslContext$delegate", "Lkotlin/Lazy;", "init", "", "event", "Lnet/minecraftforge/fml/common/event/FMLInitializationEvent;", "makeWebRequest", "Ljava/net/URLConnection;", "url", "preInit", "Lnet/minecraftforge/fml/common/event/FMLPreInitializationEvent;", "registerHooks", "reportHashedUUID", "ctjs"}
)
public final class CTJS {
   @NotNull
   public static final CTJS INSTANCE = new CTJS();
   @NotNull
   public static final String WEBSITE_ROOT = "https://www.chattriggers.com";
   @NotNull
   private static final Gson gson = new Gson();
   @NotNull
   private static final File configLocation = new File("./config");
   @NotNull
   private static final File assetsDir;
   @NotNull
   private static final List<Sound> sounds;
   @NotNull
   private static final Set<Image> images;
   @NotNull
   private static final Lazy sslContext$delegate;

   private CTJS() {
   }

   @NotNull
   public final Gson getGson() {
      return gson;
   }

   @NotNull
   public final File getConfigLocation() {
      return configLocation;
   }

   @NotNull
   public final File getAssetsDir() {
      return assetsDir;
   }

   @NotNull
   public final List<Sound> getSounds() {
      return sounds;
   }

   @NotNull
   public final Set<Image> getImages() {
      return images;
   }

   @Nullable
   public static final SSLContext getSslContext() {
      Lazy var0 = sslContext$delegate;
      CTJS var10000 = INSTANCE;
      return (SSLContext)var0.getValue();
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getSslContext$annotations() {
   }

   @EventHandler
   public final void preInit(@NotNull FMLPreInitializationEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      Object[] var2 = new Object[]{WorldListener.INSTANCE, CPS.INSTANCE, GuiHandler.INSTANCE, ClientListener.INSTANCE, UpdateChecker.INSTANCE, MouseListener.INSTANCE, ModuleUpdater.INSTANCE, ForgeTrigger.Companion};
      Iterable $this$forEach$iv = (Iterable)CollectionsKt.listOf(var2);
      EventBus var3 = MinecraftForge.EVENT_BUS;
      Intrinsics.checkNotNullExpressionValue(var3, "EVENT_BUS");
      var3 = var3;
      int $i$f$forEach = false;
      Iterator var5 = $this$forEach$iv.iterator();

      while(var5.hasNext()) {
         Object element$iv = var5.next();
         int var8 = false;
         var3.register(element$iv);
      }

      UriScheme.installUriScheme();
      UriScheme.createSocketListener();
   }

   @EventHandler
   public final void init(@NotNull FMLInitializationEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      Config.INSTANCE.loadData();
      if (Config.INSTANCE.getThreadedLoading()) {
         ThreadsKt.thread$default(false, false, (ClassLoader)null, (String)null, 0, (Function0)null.INSTANCE, 31, (Object)null);
      } else {
         ModuleManager.entryPass$default(ModuleManager.INSTANCE, (List)null, (Function1)null, 3, (Object)null);
         ThreadsKt.thread$default(false, false, (ClassLoader)null, (String)null, 0, (Function0)null.INSTANCE, 31, (Object)null);
      }

      this.registerHooks();
   }

   @NotNull
   public final URLConnection makeWebRequest(@NotNull String url) {
      Intrinsics.checkNotNullParameter(url, "url");
      URLConnection connection = (new URL(url)).openConnection();
      connection.setRequestProperty("User-Agent", "Mozilla/5.0 (ChatTriggers)");
      if (connection instanceof HttpsURLConnection && getSslContext() != null) {
         HttpsURLConnection var10000 = (HttpsURLConnection)connection;
         SSLContext var10001 = getSslContext();
         Intrinsics.checkNotNull(var10001);
         var10000.setSSLSocketFactory(var10001.getSocketFactory());
      }

      connection.setConnectTimeout(3000);
      connection.setReadTimeout(3000);
      Intrinsics.checkNotNullExpressionValue(connection, "connection");
      return connection;
   }

   private final void registerHooks() {
      ClientCommandHandler.instance.func_71560_a((ICommand)CTCommand.INSTANCE);
      Runtime.getRuntime().addShutdownHook(new Thread(() -> {
         $this$registerHooks_u24triggerAll.triggerAll();
      }));
   }

   private final void reportHashedUUID() {
      byte[] uuid = StringsKt.encodeToByteArray(Player.getUUID());
      String var10000 = System.getProperty("user.name");
      if (var10000 == null) {
         var10000 = "";
      }

      byte[] salt = StringsKt.encodeToByteArray(var10000);
      MessageDigest md = MessageDigest.getInstance("SHA-256");
      md.update(salt);
      byte[] hashedUUID = md.digest(uuid);
      String hash = Base64.getUrlEncoder().encodeToString(hashedUUID);
      String url = "https://www.chattriggers.com/api/statistics/track?hash=" + hash + "&version=2.2.1";
      URLConnection connection = this.makeWebRequest(url);
      connection.getInputStream();
   }

   static {
      CTJS var10002 = INSTANCE;
      File var0 = new File(configLocation, "ChatTriggers/images/");
      int var2 = false;
      var0.mkdirs();
      assetsDir = var0;
      sounds = (List)(new ArrayList());
      images = (Set)(new LinkedHashSet());
      sslContext$delegate = LazyKt.lazy((Function0)null.INSTANCE);
   }
}
