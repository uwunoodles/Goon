package com.chattriggers.ctjs.minecraft.listeners;

import com.chattriggers.ctjs.minecraft.wrappers.Client;
import com.chattriggers.ctjs.minecraft.wrappers.World;
import com.chattriggers.ctjs.triggers.TriggerType;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.internal.Intrinsics;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.client.event.GuiScreenEvent.MouseInputEvent.Pre;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.input.Mouse;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\u0010\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001-B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u001b\u001a\u00020\u000fJ(\u0010\u001c\u001a\u00020\u000f2\u0006\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u00062\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\rH\u0002J0\u0010\u001d\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u00062\u0006\u0010\f\u001a\u00020\u000bH\u0002J\r\u0010\u001e\u001a\u00020\u000fH\u0000¢\u0006\u0002\b\u001fJ\u0010\u0010 \u001a\u00020\u000f2\u0006\u0010!\u001a\u00020\"H\u0007J\u0010\u0010#\u001a\u00020\u000f2\u0006\u0010!\u001a\u00020$H\u0007J\u0018\u0010%\u001a\u00020\u000f2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010&\u001a\u00020\u000bH\u0002Jh\u0010'\u001a\u00020\u000f2`\u0010(\u001a\\\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\t\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\n\u0012\u0013\u0012\u00110\u000b¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\f\u0012\u0013\u0012\u00110\r¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\u000e\u0012\u0004\u0012\u00020\u000f0\u0005J}\u0010)\u001a\u00020\u000f2u\u0010(\u001aq\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\u0012\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\u0013\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\t\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\n\u0012\u0013\u0012\u00110\u000b¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\u000f0\u0011JS\u0010*\u001a\u00020\u000f2K\u0010(\u001aG\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\t\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\n\u0012\u0013\u0012\u00110\u000b¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\u001a\u0012\u0004\u0012\u00020\u000f0\u0019J\u0006\u0010+\u001a\u00020\u000fJ \u0010,\u001a\u00020\u000f2\u0006\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u00062\u0006\u0010\u001a\u001a\u00020\u000bH\u0002Rn\u0010\u0003\u001ab\u0012^\u0012\\\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\t\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\n\u0012\u0013\u0012\u00110\u000b¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\f\u0012\u0013\u0012\u00110\r¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\u000e\u0012\u0004\u0012\u00020\u000f0\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0083\u0001\u0010\u0010\u001aw\u0012s\u0012q\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\u0012\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\u0013\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\t\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\n\u0012\u0013\u0012\u00110\u000b¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\u000f0\u00110\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00160\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\r0\u0015X\u0082\u0004¢\u0006\u0002\n\u0000RY\u0010\u0018\u001aM\u0012I\u0012G\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\t\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\n\u0012\u0013\u0012\u00110\u000b¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\u001a\u0012\u0004\u0012\u00020\u000f0\u00190\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006."},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/listeners/MouseListener;", "", "()V", "clickListeners", "", "Lkotlin/Function4;", "", "Lkotlin/ParameterName;", "name", "x", "y", "", "button", "", "pressed", "", "draggedListeners", "Lkotlin/Function5;", "deltaX", "deltaY", "draggedState", "", "Lcom/chattriggers/ctjs/minecraft/listeners/MouseListener$State;", "mouseState", "scrollListeners", "Lkotlin/Function3;", "delta", "clearListeners", "clicked", "dragged", "handleDragged", "handleDragged$ctjs", "onGuiMouseInput", "event", "Lnet/minecraftforge/client/event/GuiScreenEvent$MouseInputEvent$Pre;", "onMouseInput", "Lnet/minecraftforge/client/event/MouseEvent;", "process", "dWheel", "registerClickListener", "listener", "registerDraggedListener", "registerScrollListener", "registerTriggerListeners", "scrolled", "State", "ctjs"}
)
public final class MouseListener {
   @NotNull
   public static final MouseListener INSTANCE = new MouseListener();
   @NotNull
   private static final List<Function3<Double, Double, Integer, Unit>> scrollListeners = (List)(new ArrayList());
   @NotNull
   private static final List<Function4<Double, Double, Integer, Boolean, Unit>> clickListeners = (List)(new ArrayList());
   @NotNull
   private static final List<Function5<Double, Double, Double, Double, Integer, Unit>> draggedListeners = (List)(new ArrayList());
   @NotNull
   private static final Map<Integer, Boolean> mouseState = (Map)(new LinkedHashMap());
   @NotNull
   private static final Map<Integer, MouseListener.State> draggedState = (Map)(new LinkedHashMap());

   private MouseListener() {
   }

   public final void registerScrollListener(@NotNull Function3<? super Double, ? super Double, ? super Integer, Unit> listener) {
      Intrinsics.checkNotNullParameter(listener, "listener");
      scrollListeners.add(listener);
   }

   public final void registerClickListener(@NotNull Function4<? super Double, ? super Double, ? super Integer, ? super Boolean, Unit> listener) {
      Intrinsics.checkNotNullParameter(listener, "listener");
      clickListeners.add(listener);
   }

   public final void registerDraggedListener(@NotNull Function5<? super Double, ? super Double, ? super Double, ? super Double, ? super Integer, Unit> listener) {
      Intrinsics.checkNotNullParameter(listener, "listener");
      draggedListeners.add(listener);
   }

   private final void scrolled(double x, double y, int delta) {
      Iterable $this$forEach$iv = (Iterable)scrollListeners;
      int $i$f$forEach = false;
      Iterator var8 = $this$forEach$iv.iterator();

      while(var8.hasNext()) {
         Object element$iv = var8.next();
         Function3 it = (Function3)element$iv;
         int var11 = false;
         it.invoke(x, y, delta);
      }

   }

   private final void clicked(double x, double y, int button, boolean pressed) {
      Iterable $this$forEach$iv = (Iterable)clickListeners;
      int $i$f$forEach = false;
      Iterator var9 = $this$forEach$iv.iterator();

      while(var9.hasNext()) {
         Object element$iv = var9.next();
         Function4 it = (Function4)element$iv;
         int var12 = false;
         it.invoke(x, y, button, pressed);
      }

   }

   private final void dragged(double deltaX, double deltaY, double x, double y, int button) {
      Iterable $this$forEach$iv = (Iterable)draggedListeners;
      int $i$f$forEach = false;
      Iterator var12 = $this$forEach$iv.iterator();

      while(var12.hasNext()) {
         Object element$iv = var12.next();
         Function5 it = (Function5)element$iv;
         int var15 = false;
         it.invoke(deltaX, deltaY, x, y, button);
      }

   }

   public final void clearListeners() {
      scrollListeners.clear();
      clickListeners.clear();
      draggedListeners.clear();
   }

   public final void registerTriggerListeners() {
      this.registerScrollListener((Function3)(new Function3<Object, Object, Object, Unit>(TriggerType.Scrolled) {
         public final void invoke(@Nullable Object p0, @Nullable Object p1, @Nullable Object p2) {
            MouseListener.registerTriggerListeners$triggerAll((TriggerType)access$getReceiver$p(this), p0, p1, p2);
         }

         // $FF: synthetic method
         public static final Object access$getReceiver$p(Object $this) {
            return $this.receiver;
         }
      }));
      this.registerClickListener((Function4)(new Function4<Object, Object, Object, Object, Unit>(TriggerType.Clicked) {
         public final void invoke(@Nullable Object p0, @Nullable Object p1, @Nullable Object p2, @Nullable Object p3) {
            MouseListener.registerTriggerListeners$triggerAll-3((TriggerType)access$getReceiver$p(this), p0, p1, p2, p3);
         }

         // $FF: synthetic method
         public static final Object access$getReceiver$p(Object $this) {
            return $this.receiver;
         }
      }));
      this.registerDraggedListener((Function5)(new Function5<Object, Object, Object, Object, Object, Unit>(TriggerType.Dragged) {
         public final void invoke(@Nullable Object p0, @Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4) {
            MouseListener.registerTriggerListeners$triggerAll-4((TriggerType)access$getReceiver$p(this), p0, p1, p2, p3, p4);
         }

         // $FF: synthetic method
         public static final Object access$getReceiver$p(Object $this) {
            return $this.receiver;
         }
      }));
   }

   private final void process(int button, int dWheel) {
      if (dWheel != 0) {
         this.scrolled((double)Client.Companion.getMouseX(), (double)Client.Companion.getMouseY(), dWheel < 0 ? -1 : 1);
      }

      if (button != -1) {
         if (!Intrinsics.areEqual(Mouse.isButtonDown(button), mouseState.get(button))) {
            double x = (double)Client.Companion.getMouseX();
            double y = (double)Client.Companion.getMouseY();
            this.clicked(x, y, button, Mouse.isButtonDown(button));
            Map var7 = mouseState;
            Integer var8 = button;
            Boolean var9 = Mouse.isButtonDown(button);
            var7.put(var8, var9);
            if (Mouse.isButtonDown(button)) {
               var7 = draggedState;
               var8 = button;
               MouseListener.State var10 = new MouseListener.State(x, y);
               var7.put(var8, var10);
            } else if (draggedState.containsKey(button)) {
               draggedState.remove(button);
            }

         }
      }
   }

   @SubscribeEvent
   public final void onMouseInput(@NotNull MouseEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      this.process(event.button, event.dwheel);
   }

   @SubscribeEvent
   public final void onGuiMouseInput(@NotNull Pre event) {
      Intrinsics.checkNotNullParameter(event, "event");
      if (!World.isLoaded()) {
         mouseState.clear();
         draggedState.clear();
      } else {
         int button = Mouse.getEventButton();
         int dWheel = Mouse.getEventDWheel();
         this.process(button, dWheel);
      }
   }

   public final void handleDragged$ctjs() {
      int var1 = 0;

      while(true) {
         int button;
         double y;
         double x;
         MouseListener.State var10001;
         do {
            Map var3;
            Integer var4;
            do {
               if (var1 >= 5) {
                  return;
               }

               button = var1++;
               var3 = draggedState;
               var4 = button;
            } while(!var3.containsKey(var4));

            x = (double)Client.Companion.getMouseX();
            y = (double)Client.Companion.getMouseY();
            var10001 = (MouseListener.State)draggedState.get(button);
            if (!Intrinsics.areEqual(x, var10001 == null ? null : var10001.getX())) {
               break;
            }

            var10001 = (MouseListener.State)draggedState.get(button);
         } while(Intrinsics.areEqual(y, var10001 == null ? null : var10001.getY()));

         MouseListener.State var10002 = (MouseListener.State)draggedState.get(button);
         double var8;
         double var14;
         if (var10002 == null) {
            var14 = 0.0D;
         } else {
            var8 = var10002.getX();
            var14 = var8;
         }

         double var13 = x - var14;
         MouseListener.State var10003 = (MouseListener.State)draggedState.get(button);
         double var15;
         if (var10003 == null) {
            var15 = 0.0D;
         } else {
            var8 = var10003.getY();
            var15 = var8;
         }

         this.dragged(var13, y - var15, x, y, button);
         Map var7 = draggedState;
         Integer var12 = button;
         MouseListener.State var10 = new MouseListener.State(x, y);
         var7.put(var12, var10);
      }
   }

   // $FF: synthetic method
   private static final void registerTriggerListeners$triggerAll(TriggerType $this$registerTriggerListeners_u24triggerAll, Object p0, Object p1, Object p2) {
      Object[] var4 = new Object[]{p0, p1, p2};
      $this$registerTriggerListeners_u24triggerAll.triggerAll(var4);
   }

   // $FF: synthetic method
   private static final void registerTriggerListeners$triggerAll_3/* $FF was: registerTriggerListeners$triggerAll-3*/(TriggerType $this$registerTriggerListeners_u24triggerAll_u2d3, Object p0, Object p1, Object p2, Object p3) {
      Object[] var5 = new Object[]{p0, p1, p2, p3};
      $this$registerTriggerListeners_u24triggerAll_u2d3.triggerAll(var5);
   }

   // $FF: synthetic method
   private static final void registerTriggerListeners$triggerAll_4/* $FF was: registerTriggerListeners$triggerAll-4*/(TriggerType $this$registerTriggerListeners_u24triggerAll_u2d4, Object p0, Object p1, Object p2, Object p3, Object p4) {
      Object[] var6 = new Object[]{p0, p1, p2, p3, p4};
      $this$registerTriggerListeners_u24triggerAll_u2d4.triggerAll(var6);
   }

   static {
      INSTANCE.registerTriggerListeners();
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0007¨\u0006\t"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/listeners/MouseListener$State;", "", "x", "", "y", "(DD)V", "getX", "()D", "getY", "ctjs"}
   )
   public static final class State {
      private final double x;
      private final double y;

      public State(double x, double y) {
         this.x = x;
         this.y = y;
      }

      public final double getX() {
         return this.x;
      }

      public final double getY() {
         return this.y;
      }
   }
}
