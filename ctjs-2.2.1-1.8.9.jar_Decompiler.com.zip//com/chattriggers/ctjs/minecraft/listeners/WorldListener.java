package com.chattriggers.ctjs.minecraft.listeners;

import com.chattriggers.ctjs.CTJS;
import com.chattriggers.ctjs.engine.module.Module;
import com.chattriggers.ctjs.engine.module.ModuleManager;
import com.chattriggers.ctjs.minecraft.libs.Tessellator;
import com.chattriggers.ctjs.minecraft.objects.Sound;
import com.chattriggers.ctjs.minecraft.wrappers.World;
import com.chattriggers.ctjs.minecraft.wrappers.entity.PlayerMP;
import com.chattriggers.ctjs.triggers.TriggerType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.audio.SoundCategory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.world.NoteBlockEvent.Change;
import net.minecraftforge.event.world.NoteBlockEvent.Play;
import net.minecraftforge.event.world.WorldEvent.Load;
import net.minecraftforge.event.world.WorldEvent.Unload;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.util.vector.Vector3f;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0007J\u0010\u0010\f\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\rH\u0007J\u0010\u0010\u000e\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000fH\u0007J\u0010\u0010\u0010\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0011H\u0007J\u0010\u0010\u0012\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0013H\u0007J\u0010\u0010\u0014\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0015H\u0007J\u0010\u0010\u0016\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0017H\u0007J\u0010\u0010\u0018\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0019H\u0007J\u0010\u0010\u001a\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u001bH\u0007J\u0010\u0010\u001c\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u001dH\u0007R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001e"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/listeners/WorldListener;", "", "()V", "playerList", "", "", "shouldTriggerWorldLoad", "", "attackEntityEvent", "", "event", "Lnet/minecraftforge/event/entity/player/AttackEntityEvent;", "livingDeathEvent", "Lnet/minecraftforge/event/entity/living/LivingDeathEvent;", "noteBlockEventChange", "Lnet/minecraftforge/event/world/NoteBlockEvent$Change;", "noteBlockEventPlay", "Lnet/minecraftforge/event/world/NoteBlockEvent$Play;", "onRenderGameOverlay", "Lnet/minecraftforge/client/event/RenderGameOverlayEvent$Pre;", "onRenderWorld", "Lnet/minecraftforge/client/event/RenderWorldLastEvent;", "onSoundPlay", "Lnet/minecraftforge/client/event/sound/PlaySoundEvent;", "onWorldLoad", "Lnet/minecraftforge/event/world/WorldEvent$Load;", "onWorldUnload", "Lnet/minecraftforge/event/world/WorldEvent$Unload;", "updatePlayerList", "Lnet/minecraftforge/fml/common/gameevent/TickEvent$ClientTickEvent;", "ctjs"}
)
public final class WorldListener {
   @NotNull
   public static final WorldListener INSTANCE = new WorldListener();
   private static boolean shouldTriggerWorldLoad;
   @NotNull
   private static List<String> playerList = (List)(new ArrayList());

   private WorldListener() {
   }

   @SubscribeEvent
   public final void onWorldLoad(@NotNull Load event) {
      Intrinsics.checkNotNullParameter(event, "event");
      playerList.clear();
      shouldTriggerWorldLoad = true;
   }

   @SubscribeEvent
   public final void onRenderGameOverlay(@NotNull Pre event) {
      Intrinsics.checkNotNullParameter(event, "event");
      if (shouldTriggerWorldLoad) {
         TriggerType.WorldLoad.triggerAll();
         Iterable $this$forEach$iv = (Iterable)ModuleManager.INSTANCE.getPendingOldModules();
         ModuleManager var3 = ModuleManager.INSTANCE;
         int $i$f$forEach = false;
         Iterator var5 = $this$forEach$iv.iterator();

         while(var5.hasNext()) {
            Object element$iv = var5.next();
            Module p0 = (Module)element$iv;
            int var8 = false;
            var3.reportOldVersion(p0);
         }

         ModuleManager.INSTANCE.getPendingOldModules().clear();
         shouldTriggerWorldLoad = false;
         $this$forEach$iv = (Iterable)CTJS.INSTANCE.getSounds();
         int $i$f$forEach = false;
         Collection destination$iv$iv = (Collection)(new ArrayList());
         int $i$f$filterTo = false;
         Iterator var17 = $this$forEach$iv.iterator();

         while(var17.hasNext()) {
            Object element$iv$iv = var17.next();
            Sound it = (Sound)element$iv$iv;
            int var10 = false;
            if (it.isListening()) {
               destination$iv$iv.add(element$iv$iv);
            }
         }

         $this$forEach$iv = (Iterable)((List)destination$iv$iv);
         $i$f$forEach = false;
         Iterator var12 = $this$forEach$iv.iterator();

         while(var12.hasNext()) {
            Object element$iv = var12.next();
            Sound it = (Sound)element$iv;
            int var18 = false;
            it.onWorldLoad();
         }

         CTJS.INSTANCE.getSounds().clear();
      }
   }

   @SubscribeEvent
   public final void onRenderWorld(@NotNull RenderWorldLastEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      Tessellator.setPartialTicks$ctjs(event.partialTicks);
      TriggerType var10000 = TriggerType.RenderWorld;
      Object[] var2 = new Object[]{event.partialTicks};
      var10000.triggerAll(var2);
   }

   @SubscribeEvent
   public final void onWorldUnload(@NotNull Unload event) {
      Intrinsics.checkNotNullParameter(event, "event");
      TriggerType.WorldUnload.triggerAll();
   }

   @SubscribeEvent
   public final void onSoundPlay(@NotNull PlaySoundEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      Vector3f position = new Vector3f(event.sound.func_147649_g(), event.sound.func_147654_h(), event.sound.func_147651_i());

      Object var4;
      try {
         var4 = event.sound.func_147653_e();
      } catch (Exception var8) {
         var4 = 0;
      }

      Object var5;
      try {
         var5 = event.sound.func_147655_f();
      } catch (Exception var7) {
         var5 = 1;
      }

      TriggerType var10000 = TriggerType.SoundPlay;
      Object[] var9 = new Object[]{position, event.name, var4, var5, null, null};
      Object var10003 = event.category;
      if (var10003 == null) {
         SoundCategory var10 = event.category;
         var10003 = var10 == null ? null : var10.func_147155_a();
      }

      var9[4] = var10003;
      var9[5] = event;
      var10000.triggerAll(var9);
   }

   @SubscribeEvent
   public final void noteBlockEventPlay(@NotNull Play event) {
      Intrinsics.checkNotNullParameter(event, "event");
      Vector3f position = new Vector3f((float)event.pos.func_177958_n(), (float)event.pos.func_177956_o(), (float)event.pos.func_177952_p());
      TriggerType var10000 = TriggerType.NoteBlockPlay;
      Object[] var3 = new Object[]{position, event.getNote().name(), event.getOctave(), event};
      var10000.triggerAll(var3);
   }

   @SubscribeEvent
   public final void noteBlockEventChange(@NotNull Change event) {
      Intrinsics.checkNotNullParameter(event, "event");
      Vector3f position = new Vector3f((float)event.pos.func_177958_n(), (float)event.pos.func_177956_o(), (float)event.pos.func_177952_p());
      TriggerType var10000 = TriggerType.NoteBlockChange;
      Object[] var3 = new Object[]{position, event.getNote().name(), event.getOctave(), event};
      var10000.triggerAll(var3);
   }

   @SubscribeEvent
   public final void updatePlayerList(@NotNull ClientTickEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      if (event.phase != Phase.END) {
         Iterable $this$forEach$iv = (Iterable)World.getAllPlayers();
         int $i$f$forEach = false;
         Collection destination$iv$iv = (Collection)(new ArrayList());
         int $i$f$filterTo = false;
         Iterator var7 = $this$forEach$iv.iterator();

         while(var7.hasNext()) {
            Object element$iv$iv = var7.next();
            PlayerMP it = (PlayerMP)element$iv$iv;
            int var10 = false;
            if (!playerList.contains(it.getName())) {
               destination$iv$iv.add(element$iv$iv);
            }
         }

         $this$forEach$iv = (Iterable)((List)destination$iv$iv);
         $i$f$forEach = false;
         Iterator var4 = $this$forEach$iv.iterator();

         TriggerType var10000;
         while(var4.hasNext()) {
            Object element$iv = var4.next();
            PlayerMP it = (PlayerMP)element$iv;
            int var16 = false;
            playerList.add(it.getName());
            var10000 = TriggerType.PlayerJoin;
            Object[] var17 = new Object[]{it};
            var10000.triggerAll(var17);
         }

         ListIterator ite = playerList.listIterator();

         while(ite.hasNext()) {
            String it = (String)ite.next();
            if (World.getPlayerByName(it) == null) {
               playerList.remove(it);
               var10000 = TriggerType.PlayerLeave;
               Object[] var13 = new Object[]{it};
               var10000.triggerAll(var13);
               break;
            }
         }

      }
   }

   @SubscribeEvent
   public final void livingDeathEvent(@NotNull LivingDeathEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      TriggerType var10000 = TriggerType.EntityDeath;
      Object[] var2 = new Object[1];
      Entity var3 = event.entity;
      Intrinsics.checkNotNullExpressionValue(var3, "event.entity");
      var2[0] = new com.chattriggers.ctjs.minecraft.wrappers.entity.Entity(var3);
      var10000.triggerAll(var2);
   }

   @SubscribeEvent
   public final void attackEntityEvent(@NotNull AttackEntityEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      TriggerType var10000 = TriggerType.EntityDamage;
      Object[] var2 = new Object[2];
      Entity var3 = event.target;
      Intrinsics.checkNotNullExpressionValue(var3, "event.target");
      var2[0] = new com.chattriggers.ctjs.minecraft.wrappers.entity.Entity(var3);
      EntityPlayer var4 = event.entityPlayer;
      Intrinsics.checkNotNullExpressionValue(var4, "event.entityPlayer");
      var2[1] = new PlayerMP(var4);
      var10000.triggerAll(var2);
   }
}
