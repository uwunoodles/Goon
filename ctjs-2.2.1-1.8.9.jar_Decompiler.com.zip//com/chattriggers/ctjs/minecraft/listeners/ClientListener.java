package com.chattriggers.ctjs.minecraft.listeners;

import com.chattriggers.ctjs.ReferenceKt;
import com.chattriggers.ctjs.engine.langs.js.JSContextFactory;
import com.chattriggers.ctjs.engine.langs.js.JSLoader;
import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.minecraft.libs.EventLib;
import com.chattriggers.ctjs.minecraft.wrappers.Scoreboard;
import com.chattriggers.ctjs.minecraft.wrappers.World;
import com.chattriggers.ctjs.minecraft.wrappers.entity.PlayerMP;
import com.chattriggers.ctjs.minecraft.wrappers.inventory.Item;
import com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockFace;
import com.chattriggers.ctjs.triggers.TriggerType;
import com.chattriggers.ctjs.utils.Config;
import com.chattriggers.ctjs.utils.console.Console;
import com.chattriggers.ctjs.utils.console.LogType;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.DrawBlockHighlightEvent;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.GuiScreenEvent.BackgroundDrawnEvent;
import net.minecraftforge.client.event.GuiScreenEvent.DrawScreenEvent.Post;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.Action;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent.RenderTickEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent.ClientConnectedToServerEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent.ClientDisconnectionFromServerEvent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.util.vector.Vector3f;
import org.mozilla.javascript.Context;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000®\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001:\u0002<=B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u001c\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00102\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00120\u0015J\u0010\u0010\u0016\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020\u0018H\u0002J\u0010\u0010\u0019\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020\u001aH\u0007J\u0010\u0010\u001b\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020\u001cH\u0007J\u0010\u0010\u001d\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020\u001eH\u0007J\u0010\u0010\u001f\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020 H\u0007J\u0010\u0010!\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020\"H\u0007J\u0010\u0010#\u001a\u00020\u00122\u0006\u0010$\u001a\u00020%H\u0007J\u0010\u0010&\u001a\u00020\u00122\u0006\u0010$\u001a\u00020'H\u0007J\u001a\u0010(\u001a\u00020)2\n\u0010*\u001a\u00060+j\u0002`,2\u0006\u0010-\u001a\u00020.J\u0010\u0010/\u001a\u00020\u00122\u0006\u0010$\u001a\u000200H\u0007J\u0010\u00101\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u000202H\u0007J\u0010\u00103\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u000204H\u0007J\u0010\u00105\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u000206H\u0007J\u0010\u00107\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020\u0018H\u0007J\u0010\u00108\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u000209H\u0007J\u0010\u0010:\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020;H\u0007R\u0017\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0017\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0007R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006>"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/listeners/ClientListener;", "", "()V", "actionBarHistory", "", "", "getActionBarHistory", "()Ljava/util/List;", "chatHistory", "getChatHistory", "packetContext", "Lorg/mozilla/javascript/Context;", "tasks", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Lcom/chattriggers/ctjs/minecraft/listeners/ClientListener$Task;", "ticksPassed", "", "addTask", "", "delay", "callback", "Lkotlin/Function0;", "handleOverlayTriggers", "event", "Lnet/minecraftforge/client/event/RenderGameOverlayEvent$Pre;", "onBlockHighlight", "Lnet/minecraftforge/client/event/DrawBlockHighlightEvent;", "onClientDisconnect", "Lnet/minecraftforge/fml/common/network/FMLNetworkEvent$ClientDisconnectionFromServerEvent;", "onDrawScreenEvent", "Lnet/minecraftforge/client/event/GuiScreenEvent$DrawScreenEvent$Post;", "onDropItem", "Lnet/minecraftforge/event/entity/item/ItemTossEvent;", "onGuiOpened", "Lnet/minecraftforge/client/event/GuiOpenEvent;", "onGuiRender", "e", "Lnet/minecraftforge/client/event/GuiScreenEvent$BackgroundDrawnEvent;", "onHandRender", "Lnet/minecraftforge/client/event/RenderHandEvent;", "onHitBlock", "", "pos", "Lnet/minecraft/util/BlockPos;", "Lcom/chattriggers/ctjs/utils/kotlin/MCBlockPos;", "facing", "Lnet/minecraft/util/EnumFacing;", "onInteract", "Lnet/minecraftforge/event/entity/player/PlayerInteractEvent;", "onNetworkEvent", "Lnet/minecraftforge/fml/common/network/FMLNetworkEvent$ClientConnectedToServerEvent;", "onPickupItem", "Lnet/minecraftforge/event/entity/player/EntityItemPickupEvent;", "onReceiveChat", "Lnet/minecraftforge/client/event/ClientChatReceivedEvent;", "onRenderGameOverlay", "onRenderTick", "Lnet/minecraftforge/fml/common/gameevent/TickEvent$RenderTickEvent;", "onTick", "Lnet/minecraftforge/fml/common/gameevent/TickEvent$ClientTickEvent;", "PlayerInteractAction", "Task", "ctjs"}
)
public final class ClientListener {
   @NotNull
   public static final ClientListener INSTANCE = new ClientListener();
   private static int ticksPassed;
   @NotNull
   private static final List<String> chatHistory = (List)(new ArrayList());
   @NotNull
   private static final List<String> actionBarHistory = (List)(new ArrayList());
   @NotNull
   private static final CopyOnWriteArrayList<ClientListener.Task> tasks = new CopyOnWriteArrayList();
   @NotNull
   private static Context packetContext;

   private ClientListener() {
   }

   @NotNull
   public final List<String> getChatHistory() {
      return chatHistory;
   }

   @NotNull
   public final List<String> getActionBarHistory() {
      return actionBarHistory;
   }

   @SubscribeEvent
   public final void onReceiveChat(@NotNull ClientChatReceivedEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      int var2 = EventLib.getType(event);
      TriggerType var10000;
      Object[] var3;
      if (0 <= var2 ? var2 < 2 : false) {
         ((Collection)chatHistory).add(ChatLib.getChatMessage(event, true));
         if (chatHistory.size() > 1000) {
            chatHistory.remove(0);
         }

         var10000 = TriggerType.Chat;
         var3 = new Object[]{ChatLib.getChatMessage(event, false), event};
         var10000.triggerAll(var3);
         if (Config.INSTANCE.getPrintChatToConsole()) {
            ReferenceKt.printToConsole$default(Intrinsics.stringPlus("[CHAT] ", ChatLib.replaceFormatting(ChatLib.getChatMessage(event, true))), (Console)null, (LogType)null, 3, (Object)null);
         }
      } else if (var2 == 2) {
         ((Collection)actionBarHistory).add(ChatLib.getChatMessage(event, true));
         if (actionBarHistory.size() > 1000) {
            actionBarHistory.remove(0);
         }

         var10000 = TriggerType.ActionBar;
         var3 = new Object[]{ChatLib.getChatMessage(event, false), event};
         var10000.triggerAll(var3);
      }

   }

   public final void addTask(int delay, @NotNull Function0<Unit> callback) {
      Intrinsics.checkNotNullParameter(callback, "callback");
      tasks.add(new ClientListener.Task(delay, callback));
   }

   @SubscribeEvent
   public final void onTick(@NotNull ClientTickEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      if (event.phase != Phase.END) {
         CollectionsKt.removeAll((List)tasks, (Function1)null.INSTANCE);
         if (World.isLoaded()) {
            TriggerType var10000 = TriggerType.Tick;
            Object[] var2 = new Object[]{ticksPassed};
            var10000.triggerAll(var2);
            int var3 = ticksPassed++;
            Scoreboard.resetCache();
         }
      }
   }

   @SubscribeEvent
   public final void onClientDisconnect(@NotNull ClientDisconnectionFromServerEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      TriggerType var10000 = TriggerType.ServerDisconnect;
      Object[] var2 = new Object[]{event};
      var10000.triggerAll(var2);
   }

   @SubscribeEvent
   public final void onNetworkEvent(@NotNull ClientConnectedToServerEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      TriggerType var10000 = TriggerType.ServerConnect;
      Object[] var2 = new Object[]{event};
      var10000.triggerAll(var2);
      event.manager.channel().pipeline().addAfter("fml:packet_handler", "CT_packet_handler", (ChannelHandler)(new ChannelDuplexHandler() {
         public void channelRead(@Nullable ChannelHandlerContext ctx, @Nullable Object msg) {
            CancellableEvent packetReceivedEvent = new CancellableEvent();
            if (msg instanceof Packet) {
               JSLoader var4 = JSLoader.INSTANCE;
               Context context$iv = ClientListener.packetContext;
               int $i$f$wrapInContext$ctjs = false;
               boolean missingContext$iv = Context.getCurrentContext() == null;
               if (missingContext$iv) {
                  try {
                     JSContextFactory.INSTANCE.enterContext(context$iv);
                  } catch (Throwable var13) {
                     JSContextFactory.INSTANCE.enterContext();
                  }
               }

               try {
                  int var9 = false;
                  TriggerType var10000 = TriggerType.PacketReceived;
                  Object[] var10 = new Object[]{msg, packetReceivedEvent};
                  var10000.triggerAll(var10);
                  Unit var8 = Unit.INSTANCE;
               } finally {
                  if (missingContext$iv) {
                     Context.exit();
                  }

               }
            }

            if (!packetReceivedEvent.isCancelled()) {
               if (ctx != null) {
                  ctx.fireChannelRead(msg);
               }
            }

         }

         public void write(@Nullable ChannelHandlerContext ctx, @Nullable Object msg, @Nullable ChannelPromise promise) {
            CancellableEvent packetSentEvent = new CancellableEvent();
            if (msg instanceof Packet) {
               JSLoader var5 = JSLoader.INSTANCE;
               Context context$iv = ClientListener.packetContext;
               int $i$f$wrapInContext$ctjs = false;
               boolean missingContext$iv = Context.getCurrentContext() == null;
               if (missingContext$iv) {
                  try {
                     JSContextFactory.INSTANCE.enterContext(context$iv);
                  } catch (Throwable var14) {
                     JSContextFactory.INSTANCE.enterContext();
                  }
               }

               try {
                  int var10 = false;
                  TriggerType var10000 = TriggerType.PacketSent;
                  Object[] var11 = new Object[]{msg, packetSentEvent};
                  var10000.triggerAll(var11);
                  Unit var9 = Unit.INSTANCE;
               } finally {
                  if (missingContext$iv) {
                     Context.exit();
                  }

               }
            }

            if (!packetSentEvent.isCancelled()) {
               if (ctx != null) {
                  ctx.write(msg, promise);
               }
            }

         }
      }));
   }

   @SubscribeEvent
   public final void onDrawScreenEvent(@NotNull Post event) {
      Intrinsics.checkNotNullParameter(event, "event");
      TriggerType var10000 = TriggerType.PostGuiRender;
      Object[] var2 = new Object[]{event.mouseX, event.mouseY, event.gui};
      var10000.triggerAll(var2);
   }

   @SubscribeEvent
   public final void onRenderTick(@NotNull RenderTickEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      TriggerType.Step.triggerAll();
      if (World.isLoaded()) {
         MouseListener.INSTANCE.handleDragged$ctjs();
      }

   }

   @SubscribeEvent
   public final void onRenderGameOverlay(@NotNull Pre event) {
      Intrinsics.checkNotNullParameter(event, "event");
      GlStateManager.func_179094_E();
      this.handleOverlayTriggers(event);
      GlStateManager.func_179121_F();
   }

   private final void handleOverlayTriggers(Pre event) {
      ElementType var10000 = event.type;
      Object[] var2;
      TriggerType var3;
      switch(var10000 == null ? -1 : ClientListener.WhenMappings.$EnumSwitchMapping$0[var10000.ordinal()]) {
      case 1:
         var3 = TriggerType.RenderPlayerList;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 2:
         var3 = TriggerType.RenderCrosshair;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 3:
         var3 = TriggerType.RenderDebug;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 4:
         var3 = TriggerType.RenderBossHealth;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 5:
         var3 = TriggerType.RenderHealth;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 6:
         var3 = TriggerType.RenderArmor;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 7:
         var3 = TriggerType.RenderFood;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 8:
         var3 = TriggerType.RenderMountHealth;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 9:
         var3 = TriggerType.RenderExperience;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 10:
         var3 = TriggerType.RenderHotbar;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 11:
         var3 = TriggerType.RenderAir;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 12:
         var3 = TriggerType.RenderOverlay;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 13:
         var3 = TriggerType.RenderPortal;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 14:
         var3 = TriggerType.RenderJumpBar;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 15:
         var3 = TriggerType.RenderChat;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
         break;
      case 16:
         var3 = TriggerType.RenderHelmet;
         var2 = new Object[]{event};
         var3.triggerAll(var2);
      }

   }

   @SubscribeEvent
   public final void onGuiOpened(@NotNull GuiOpenEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      if (event.gui != null) {
         TriggerType var10000 = TriggerType.GuiOpened;
         Object[] var2 = new Object[]{event};
         var10000.triggerAll(var2);
      }

   }

   @SubscribeEvent
   public final void onBlockHighlight(@NotNull DrawBlockHighlightEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      if (event.target != null && event.target.func_178782_a() != null) {
         Vector3f position = new Vector3f((float)event.target.func_178782_a().func_177958_n(), (float)event.target.func_178782_a().func_177956_o(), (float)event.target.func_178782_a().func_177952_p());
         TriggerType var10000 = TriggerType.BlockHighlight;
         Object[] var3 = new Object[]{position, event};
         var10000.triggerAll(var3);
      }
   }

   @SubscribeEvent
   public final void onPickupItem(@NotNull EntityItemPickupEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      if (event.entityPlayer instanceof EntityPlayerMP) {
         EntityPlayer var10000 = event.entityPlayer;
         if (var10000 == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.minecraft.entity.player.EntityPlayerMP");
         } else {
            EntityPlayerMP player = (EntityPlayerMP)var10000;
            EntityItem item = event.item;
            Vector3f position = new Vector3f((float)item.field_70165_t, (float)item.field_70163_u, (float)item.field_70161_v);
            Vector3f motion = new Vector3f((float)item.field_70159_w, (float)item.field_70181_x, (float)item.field_70179_y);
            TriggerType var8 = TriggerType.PickupItem;
            Object[] var6 = new Object[5];
            ItemStack var7 = item.func_92059_d();
            Intrinsics.checkNotNullExpressionValue(var7, "item.entityItem");
            var6[0] = new Item(var7);
            var6[1] = new PlayerMP((EntityPlayer)player);
            var6[2] = position;
            var6[3] = motion;
            var6[4] = event;
            var8.triggerAll(var6);
         }
      }
   }

   public final boolean onHitBlock(@NotNull BlockPos pos, @NotNull EnumFacing facing) {
      Intrinsics.checkNotNullParameter(pos, "pos");
      Intrinsics.checkNotNullParameter(facing, "facing");
      CancellableEvent event = new CancellableEvent();
      TriggerType var10000 = TriggerType.HitBlock;
      Object[] var4 = new Object[]{World.getBlockAt((Number)pos.func_177958_n(), (Number)pos.func_177956_o(), (Number)pos.func_177952_p()).withFace(BlockFace.Companion.fromMCEnumFacing(facing)), event};
      var10000.triggerAll(var4);
      return event.isCancelled();
   }

   @SubscribeEvent
   public final void onDropItem(@NotNull ItemTossEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      EntityItem item = event.entityItem;
      Vector3f position = new Vector3f((float)item.field_70165_t, (float)item.field_70163_u, (float)item.field_70161_v);
      Vector3f motion = new Vector3f((float)item.field_70159_w, (float)item.field_70181_x, (float)item.field_70179_y);
      TriggerType var10000 = TriggerType.DropItem;
      Object[] var5 = new Object[5];
      Intrinsics.checkNotNullExpressionValue(item, "item");
      var5[0] = new Item(item);
      EntityPlayer var6 = event.player;
      Intrinsics.checkNotNullExpressionValue(var6, "event.player");
      var5[1] = new PlayerMP(var6);
      var5[2] = position;
      var5[3] = motion;
      var5[4] = event;
      var10000.triggerAll(var5);
   }

   @SubscribeEvent
   public final void onGuiRender(@NotNull BackgroundDrawnEvent e) {
      Intrinsics.checkNotNullParameter(e, "e");
      GlStateManager.func_179094_E();
      TriggerType var10000 = TriggerType.GuiRender;
      Object[] var2 = new Object[]{e.getMouseX(), e.getMouseY(), e.gui};
      var10000.triggerAll(var2);
      GlStateManager.func_179121_F();
   }

   @SubscribeEvent
   public final void onInteract(@NotNull PlayerInteractEvent e) {
      Intrinsics.checkNotNullParameter(e, "e");
      Action var10000 = e.action;
      ClientListener.PlayerInteractAction var10;
      switch(var10000 == null ? -1 : ClientListener.WhenMappings.$EnumSwitchMapping$1[var10000.ordinal()]) {
      case -1:
         var10 = ClientListener.PlayerInteractAction.UNKNOWN;
         break;
      case 0:
      default:
         throw new NoWhenBranchMatchedException();
      case 1:
         return;
      case 2:
         var10 = ClientListener.PlayerInteractAction.RIGHT_CLICK_EMPTY;
         break;
      case 3:
         var10 = ClientListener.PlayerInteractAction.RIGHT_CLICK_BLOCK;
      }

      ClientListener.PlayerInteractAction action = var10;
      TriggerType var11 = TriggerType.PlayerInteract;
      Object[] var3 = new Object[]{action, null, null};
      Vector3f var10003 = new Vector3f;
      BlockPos var10005 = e.pos;
      int var4;
      int var5;
      if (var10005 == null) {
         var5 = 0;
      } else {
         var4 = var10005.func_177958_n();
         var5 = var4;
      }

      float var6 = (float)var5;
      BlockPos var10006 = e.pos;
      int var7;
      if (var10006 == null) {
         var7 = 0;
      } else {
         var4 = var10006.func_177956_o();
         var7 = var4;
      }

      float var8 = (float)var7;
      BlockPos var10007 = e.pos;
      int var9;
      if (var10007 == null) {
         var9 = 0;
      } else {
         var4 = var10007.func_177952_p();
         var9 = var4;
      }

      var10003.<init>(var6, var8, (float)var9);
      var3[1] = var10003;
      var3[2] = e;
      var11.triggerAll(var3);
   }

   @SubscribeEvent
   public final void onHandRender(@NotNull RenderHandEvent e) {
      Intrinsics.checkNotNullParameter(e, "e");
      TriggerType var10000 = TriggerType.RenderHand;
      Object[] var2 = new Object[]{e};
      var10000.triggerAll(var2);
   }

   static {
      ClientListener var10000 = INSTANCE;
      ticksPassed = 0;
      var10000 = INSTANCE;
      Context var0 = JSContextFactory.INSTANCE.enterContext();
      Intrinsics.checkNotNullExpressionValue(var0, "JSContextFactory.enterContext()");
      packetContext = var0;
      Context.exit();
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\b\u0018\u00002\u00020\u0001B\u001b\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\u0002\u0010\u0007R\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\r¨\u0006\u000e"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/listeners/ClientListener$Task;", "", "delay", "", "callback", "Lkotlin/Function0;", "", "(ILkotlin/jvm/functions/Function0;)V", "getCallback", "()Lkotlin/jvm/functions/Function0;", "getDelay", "()I", "setDelay", "(I)V", "ctjs"}
   )
   public static final class Task {
      private int delay;
      @NotNull
      private final Function0<Unit> callback;

      public Task(int delay, @NotNull Function0<Unit> callback) {
         Intrinsics.checkNotNullParameter(callback, "callback");
         super();
         this.delay = delay;
         this.callback = callback;
      }

      public final int getDelay() {
         return this.delay;
      }

      public final void setDelay(int var1) {
         this.delay = var1;
      }

      @NotNull
      public final Function0<Unit> getCallback() {
         return this.callback;
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/listeners/ClientListener$PlayerInteractAction;", "", "(Ljava/lang/String;I)V", "RIGHT_CLICK_BLOCK", "RIGHT_CLICK_EMPTY", "UNKNOWN", "ctjs"}
   )
   public static enum PlayerInteractAction {
      RIGHT_CLICK_BLOCK,
      RIGHT_CLICK_EMPTY,
      UNKNOWN;

      // $FF: synthetic method
      private static final ClientListener.PlayerInteractAction[] $values() {
         ClientListener.PlayerInteractAction[] var0 = new ClientListener.PlayerInteractAction[]{RIGHT_CLICK_BLOCK, RIGHT_CLICK_EMPTY, UNKNOWN};
         return var0;
      }
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$1;

      static {
         int[] var0 = new int[ElementType.values().length];
         var0[ElementType.PLAYER_LIST.ordinal()] = 1;
         var0[ElementType.CROSSHAIRS.ordinal()] = 2;
         var0[ElementType.DEBUG.ordinal()] = 3;
         var0[ElementType.BOSSHEALTH.ordinal()] = 4;
         var0[ElementType.HEALTH.ordinal()] = 5;
         var0[ElementType.ARMOR.ordinal()] = 6;
         var0[ElementType.FOOD.ordinal()] = 7;
         var0[ElementType.HEALTHMOUNT.ordinal()] = 8;
         var0[ElementType.EXPERIENCE.ordinal()] = 9;
         var0[ElementType.HOTBAR.ordinal()] = 10;
         var0[ElementType.AIR.ordinal()] = 11;
         var0[ElementType.TEXT.ordinal()] = 12;
         var0[ElementType.PORTAL.ordinal()] = 13;
         var0[ElementType.JUMPBAR.ordinal()] = 14;
         var0[ElementType.CHAT.ordinal()] = 15;
         var0[ElementType.HELMET.ordinal()] = 16;
         $EnumSwitchMapping$0 = var0;
         var0 = new int[Action.values().length];
         var0[Action.LEFT_CLICK_BLOCK.ordinal()] = 1;
         var0[Action.RIGHT_CLICK_AIR.ordinal()] = 2;
         var0[Action.RIGHT_CLICK_BLOCK.ordinal()] = 3;
         $EnumSwitchMapping$1 = var0;
      }
   }
}
