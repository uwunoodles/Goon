package com.chattriggers.ctjs.minecraft.objects.display;

import com.chattriggers.ctjs.engine.ILoader;
import com.chattriggers.ctjs.minecraft.libs.renderer.Renderer;
import com.chattriggers.ctjs.minecraft.libs.renderer.Text;
import com.chattriggers.ctjs.minecraft.listeners.MouseListener;
import com.chattriggers.ctjs.minecraft.wrappers.Client;
import com.chattriggers.ctjs.triggers.RegularTrigger;
import com.chattriggers.ctjs.triggers.TriggerType;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mozilla.javascript.NativeObject;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u0006\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u001d\b&\u0018\u00002\u00020\u0001B\u000f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004B\u0017\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007J>\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020#2\u0006\u0010'\u001a\u00020#2\u0006\u0010(\u001a\u00020#2\u0006\u0010)\u001a\u00020\u000b2\u0006\u0010*\u001a\u00020\r2\u0006\u0010+\u001a\u00020\r2\u0006\u0010\b\u001a\u00020\tJ\b\u0010,\u001a\u0004\u0018\u00010\tJ\b\u0010-\u001a\u0004\u0018\u00010\u000bJ\r\u0010.\u001a\u0004\u0018\u00010\r¢\u0006\u0002\u0010/J\r\u00100\u001a\u000201H ¢\u0006\u0002\b2J\u0006\u00103\u001a\u00020 J\r\u00104\u001a\u0004\u0018\u00010\r¢\u0006\u0002\u0010/J\u0006\u00105\u001a\u00020#J\u0010\u00106\u001a\u0004\u0018\u00010\u00172\u0006\u00107\u001a\u00020\u0001J\u0010\u00108\u001a\u0004\u0018\u00010\u00172\u0006\u00107\u001a\u00020\u0001J\u0010\u00109\u001a\u0004\u0018\u00010\u00172\u0006\u00107\u001a\u00020\u0001J\u0010\u0010:\u001a\u0004\u0018\u00010\u00172\u0006\u00107\u001a\u00020\u0001J\u0010\u0010;\u001a\u00020\u00002\b\u0010\b\u001a\u0004\u0018\u00010\u0001J\u0010\u0010<\u001a\u00020\u00002\b\u0010\n\u001a\u0004\u0018\u00010\u0001J\u0015\u0010=\u001a\u00020\u00002\b\u0010\f\u001a\u0004\u0018\u00010\r¢\u0006\u0002\u0010>J\u000e\u0010?\u001a\u00020\u00002\u0006\u0010@\u001a\u00020#J\u000e\u0010A\u001a\u00020\u00002\u0006\u0010B\u001a\u00020\u0015J\u000e\u0010C\u001a\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0003J\u0015\u0010D\u001a\u00020\u00002\b\u0010E\u001a\u0004\u0018\u00010\r¢\u0006\u0002\u0010>J\b\u0010F\u001a\u00020\u0003H\u0016J\u0006\u0010G\u001a\u00020\u0000J\u0006\u0010H\u001a\u00020\u0000J\u0006\u0010I\u001a\u00020\u0000J\u0006\u0010J\u001a\u00020\u0000J\"\u0010K\u001a\u0004\u0018\u00010\u0003*\u0004\u0018\u00010\u00062\u0006\u0010L\u001a\u00020\u00032\b\u0010M\u001a\u0004\u0018\u00010\u0001H\u0002R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u000eR\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0018\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0019\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001a\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u001b\u001a\u00020\u0015X\u0080\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\u001d\"\u0004\b\u001e\u0010\u001fR\u000e\u0010\u0002\u001a\u00020 X\u0082.¢\u0006\u0002\n\u0000R\u0012\u0010!\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u000eR\u000e\u0010\"\u001a\u00020#X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006N"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayLine;", "", "text", "", "(Ljava/lang/String;)V", "config", "Lorg/mozilla/javascript/NativeObject;", "(Ljava/lang/String;Lorg/mozilla/javascript/NativeObject;)V", "align", "Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler$Align;", "background", "Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler$Background;", "backgroundColor", "", "Ljava/lang/Long;", "cachedHeight", "", "cachedWidth", "cachedX", "cachedY", "hovered", "", "onClicked", "Lcom/chattriggers/ctjs/triggers/RegularTrigger;", "onDragged", "onHovered", "onMouseLeave", "shouldRender", "getShouldRender$ctjs", "()Z", "setShouldRender$ctjs", "(Z)V", "Lcom/chattriggers/ctjs/minecraft/libs/renderer/Text;", "textColor", "textWidth", "", "draw", "", "x", "y", "totalWidth", "background_", "backgroundColor_", "textColor_", "getAlign", "getBackground", "getBackgroundColor", "()Ljava/lang/Long;", "getLoader", "Lcom/chattriggers/ctjs/engine/ILoader;", "getLoader$ctjs", "getText", "getTextColor", "getTextWidth", "registerClicked", "method", "registerDragged", "registerHovered", "registerMouseLeave", "setAlign", "setBackground", "setBackgroundColor", "(Ljava/lang/Long;)Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayLine;", "setScale", "scale", "setShadow", "shadow", "setText", "setTextColor", "color", "toString", "unregisterClicked", "unregisterDragged", "unregisterHovered", "unregisterMouseLeave", "getOption", "key", "default", "ctjs"}
)
public abstract class DisplayLine {
   private Text text;
   private float textWidth;
   @Nullable
   private Long textColor;
   @Nullable
   private Long backgroundColor;
   @Nullable
   private DisplayHandler.Background background;
   @Nullable
   private DisplayHandler.Align align;
   @Nullable
   private RegularTrigger onClicked;
   @Nullable
   private RegularTrigger onHovered;
   @Nullable
   private RegularTrigger onDragged;
   @Nullable
   private RegularTrigger onMouseLeave;
   private boolean shouldRender;
   private boolean hovered;
   private double cachedX;
   private double cachedY;
   private double cachedWidth;
   private double cachedHeight;

   public final boolean getShouldRender$ctjs() {
      return this.shouldRender;
   }

   public final void setShouldRender$ctjs(boolean var1) {
      this.shouldRender = var1;
   }

   public DisplayLine(@NotNull String text) {
      Intrinsics.checkNotNullParameter(text, "text");
      super();
      this.shouldRender = true;
      MouseListener.INSTANCE.registerClickListener((Function4)(new Function4<Double, Double, Integer, Boolean, Unit>() {
         public final void invoke(double x, double y, int button, boolean pressed) {
            if (DisplayLine.this.getShouldRender$ctjs()) {
               double var7 = DisplayLine.this.cachedX;
               if (x <= DisplayLine.this.cachedX + DisplayLine.this.cachedWidth ? var7 <= x : false) {
                  var7 = DisplayLine.this.cachedY;
                  if (y <= DisplayLine.this.cachedY + DisplayLine.this.cachedHeight ? var7 <= y : false) {
                     RegularTrigger var10000 = DisplayLine.this.onClicked;
                     if (var10000 != null) {
                        Object[] var8 = new Object[]{x, y, button, pressed};
                        var10000.trigger(var8);
                     }
                  }
               }
            }

         }
      }));
      MouseListener.INSTANCE.registerDraggedListener((Function5)(new Function5<Double, Double, Double, Double, Integer, Unit>() {
         public final void invoke(double deltaX, double deltaY, double x, double y, int button) {
            if (DisplayLine.this.getShouldRender$ctjs()) {
               RegularTrigger var10000 = DisplayLine.this.onDragged;
               if (var10000 != null) {
                  Object[] var10 = new Object[]{deltaX, deltaY, x, y, button};
                  var10000.trigger(var10);
               }
            }

         }
      }));
      this.setText(text);
   }

   public DisplayLine(@NotNull String text, @NotNull NativeObject config) {
      Intrinsics.checkNotNullParameter(text, "text");
      Intrinsics.checkNotNullParameter(config, "config");
      super();
      this.shouldRender = true;
      MouseListener.INSTANCE.registerClickListener((Function4)(new Function4<Double, Double, Integer, Boolean, Unit>() {
         public final void invoke(double x, double y, int button, boolean pressed) {
            if (DisplayLine.this.getShouldRender$ctjs()) {
               double var7 = DisplayLine.this.cachedX;
               if (x <= DisplayLine.this.cachedX + DisplayLine.this.cachedWidth ? var7 <= x : false) {
                  var7 = DisplayLine.this.cachedY;
                  if (y <= DisplayLine.this.cachedY + DisplayLine.this.cachedHeight ? var7 <= y : false) {
                     RegularTrigger var10000 = DisplayLine.this.onClicked;
                     if (var10000 != null) {
                        Object[] var8 = new Object[]{x, y, button, pressed};
                        var10000.trigger(var8);
                     }
                  }
               }
            }

         }
      }));
      MouseListener.INSTANCE.registerDraggedListener((Function5)(new Function5<Double, Double, Double, Double, Integer, Unit>() {
         public final void invoke(double deltaX, double deltaY, double x, double y, int button) {
            if (DisplayLine.this.getShouldRender$ctjs()) {
               RegularTrigger var10000 = DisplayLine.this.onDragged;
               if (var10000 != null) {
                  Object[] var10 = new Object[]{deltaX, deltaY, x, y, button};
                  var10000.trigger(var10);
               }
            }

         }
      }));
      this.setText(text);
      String var3 = this.getOption(config, "textColor", (Object)null);
      this.textColor = var3 == null ? null : Long.parseLong(var3);
      var3 = this.getOption(config, "backgroundColor", (Object)null);
      this.backgroundColor = var3 == null ? null : Long.parseLong(var3);
      this.setAlign(this.getOption(config, "align", (Object)null));
      this.setBackground(this.getOption(config, "background", (Object)null));
   }

   private final String getOption(NativeObject $this$getOption, String key, Object var3) {
      Object var10000;
      if ($this$getOption == null) {
         var10000 = var3;
      } else {
         var10000 = $this$getOption.get(key);
         if (var10000 == null) {
            var10000 = var3;
         }
      }

      return var10000 == null ? null : var10000.toString();
   }

   @NotNull
   public final Text getText() {
      Text var10000 = this.text;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("text");
         var10000 = null;
      }

      return var10000;
   }

   @NotNull
   public final DisplayLine setText(@NotNull String text) {
      Intrinsics.checkNotNullParameter(text, "text");
      DisplayLine $this$setText_u24lambda_u2d0 = (DisplayLine)this;
      int var4 = false;
      $this$setText_u24lambda_u2d0.text = new Text(text, 0.0F, 0.0F, 6, (DefaultConstructorMarker)null);
      float var10001 = (float)Renderer.getStringWidth(text);
      Text var10002 = $this$setText_u24lambda_u2d0.text;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("text");
         var10002 = null;
      }

      $this$setText_u24lambda_u2d0.textWidth = var10001 * var10002.getScale();
      return (DisplayLine)this;
   }

   @Nullable
   public final Long getTextColor() {
      return this.textColor;
   }

   @NotNull
   public final DisplayLine setTextColor(@Nullable Long color) {
      DisplayLine $this$setTextColor_u24lambda_u2d1 = (DisplayLine)this;
      int var4 = false;
      $this$setTextColor_u24lambda_u2d1.textColor = color;
      return (DisplayLine)this;
   }

   public final float getTextWidth() {
      return this.textWidth;
   }

   @NotNull
   public final DisplayLine setShadow(boolean shadow) {
      DisplayLine $this$setShadow_u24lambda_u2d2 = (DisplayLine)this;
      int var4 = false;
      Text var10000 = $this$setShadow_u24lambda_u2d2.text;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("text");
         var10000 = null;
      }

      var10000.setShadow(shadow);
      return (DisplayLine)this;
   }

   @NotNull
   public final DisplayLine setScale(float scale) {
      DisplayLine $this$setScale_u24lambda_u2d3 = (DisplayLine)this;
      int var4 = false;
      Text var10000 = $this$setScale_u24lambda_u2d3.text;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("text");
         var10000 = null;
      }

      var10000.setScale(scale);
      Text var10001 = $this$setScale_u24lambda_u2d3.text;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("text");
         var10001 = null;
      }

      $this$setScale_u24lambda_u2d3.textWidth = (float)Renderer.getStringWidth(var10001.getString()) * scale;
      return (DisplayLine)this;
   }

   @Nullable
   public final DisplayHandler.Align getAlign() {
      return this.align;
   }

   @NotNull
   public final DisplayLine setAlign(@Nullable Object align) {
      DisplayLine $this$setAlign_u24lambda_u2d4 = (DisplayLine)this;
      int var4 = false;
      DisplayHandler.Align var6;
      if (align instanceof String) {
         String var10001 = ((String)align).toUpperCase(Locale.ROOT);
         Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).toUpperCase(Locale.ROOT)");
         var6 = DisplayHandler.Align.valueOf(var10001);
      } else {
         var6 = align instanceof DisplayHandler.Align ? (DisplayHandler.Align)align : null;
      }

      $this$setAlign_u24lambda_u2d4.align = var6;
      return (DisplayLine)this;
   }

   @Nullable
   public final DisplayHandler.Background getBackground() {
      return this.background;
   }

   @NotNull
   public final DisplayLine setBackground(@Nullable Object background) {
      DisplayLine $this$setBackground_u24lambda_u2d5 = (DisplayLine)this;
      int var4 = false;
      DisplayHandler.Background var6;
      if (background instanceof String) {
         String var10001 = ((String)background).toUpperCase(Locale.ROOT);
         Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).toUpperCase(Locale.ROOT)");
         var6 = DisplayHandler.Background.valueOf(StringsKt.replace$default(var10001, " ", "_", false, 4, (Object)null));
      } else {
         var6 = background instanceof DisplayHandler.Background ? (DisplayHandler.Background)background : null;
      }

      $this$setBackground_u24lambda_u2d5.background = var6;
      return (DisplayLine)this;
   }

   @Nullable
   public final Long getBackgroundColor() {
      return this.backgroundColor;
   }

   @NotNull
   public final DisplayLine setBackgroundColor(@Nullable Long backgroundColor) {
      DisplayLine $this$setBackgroundColor_u24lambda_u2d6 = (DisplayLine)this;
      int var4 = false;
      $this$setBackgroundColor_u24lambda_u2d6.backgroundColor = backgroundColor;
      return (DisplayLine)this;
   }

   @Nullable
   public final RegularTrigger registerClicked(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      DisplayLine $this$registerClicked_u24lambda_u2d7 = (DisplayLine)this;
      int var3 = false;
      $this$registerClicked_u24lambda_u2d7.onClicked = new RegularTrigger(method, TriggerType.Other, $this$registerClicked_u24lambda_u2d7.getLoader$ctjs());
      return $this$registerClicked_u24lambda_u2d7.onClicked;
   }

   @Nullable
   public final RegularTrigger registerHovered(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      DisplayLine $this$registerHovered_u24lambda_u2d8 = (DisplayLine)this;
      int var3 = false;
      $this$registerHovered_u24lambda_u2d8.onHovered = new RegularTrigger(method, TriggerType.Other, $this$registerHovered_u24lambda_u2d8.getLoader$ctjs());
      return $this$registerHovered_u24lambda_u2d8.onHovered;
   }

   @Nullable
   public final RegularTrigger registerMouseLeave(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      DisplayLine $this$registerMouseLeave_u24lambda_u2d9 = (DisplayLine)this;
      int var3 = false;
      $this$registerMouseLeave_u24lambda_u2d9.onMouseLeave = new RegularTrigger(method, TriggerType.Other, $this$registerMouseLeave_u24lambda_u2d9.getLoader$ctjs());
      return $this$registerMouseLeave_u24lambda_u2d9.onMouseLeave;
   }

   @Nullable
   public final RegularTrigger registerDragged(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      DisplayLine $this$registerDragged_u24lambda_u2d10 = (DisplayLine)this;
      int var3 = false;
      $this$registerDragged_u24lambda_u2d10.onDragged = new RegularTrigger(method, TriggerType.Other, $this$registerDragged_u24lambda_u2d10.getLoader$ctjs());
      return $this$registerDragged_u24lambda_u2d10.onDragged;
   }

   @NotNull
   public final DisplayLine unregisterClicked() {
      DisplayLine $this$unregisterClicked_u24lambda_u2d11 = (DisplayLine)this;
      int var3 = false;
      RegularTrigger var10000 = $this$unregisterClicked_u24lambda_u2d11.onClicked;
      if (var10000 != null) {
         var10000.unregister();
      }

      $this$unregisterClicked_u24lambda_u2d11.onClicked = null;
      return (DisplayLine)this;
   }

   @NotNull
   public final DisplayLine unregisterHovered() {
      DisplayLine $this$unregisterHovered_u24lambda_u2d12 = (DisplayLine)this;
      int var3 = false;
      RegularTrigger var10000 = $this$unregisterHovered_u24lambda_u2d12.onHovered;
      if (var10000 != null) {
         var10000.unregister();
      }

      $this$unregisterHovered_u24lambda_u2d12.onHovered = null;
      return (DisplayLine)this;
   }

   @NotNull
   public final DisplayLine unregisterMouseLeave() {
      DisplayLine $this$unregisterMouseLeave_u24lambda_u2d13 = (DisplayLine)this;
      int var3 = false;
      RegularTrigger var10000 = $this$unregisterMouseLeave_u24lambda_u2d13.onMouseLeave;
      if (var10000 != null) {
         var10000.unregister();
      }

      $this$unregisterMouseLeave_u24lambda_u2d13.onMouseLeave = null;
      return (DisplayLine)this;
   }

   @NotNull
   public final DisplayLine unregisterDragged() {
      DisplayLine $this$unregisterDragged_u24lambda_u2d14 = (DisplayLine)this;
      int var3 = false;
      RegularTrigger var10000 = $this$unregisterDragged_u24lambda_u2d14.onDragged;
      if (var10000 != null) {
         var10000.unregister();
      }

      $this$unregisterDragged_u24lambda_u2d14.onDragged = null;
      return (DisplayLine)this;
   }

   public final void draw(float x, float y, float totalWidth, @NotNull DisplayHandler.Background background_, long backgroundColor_, long textColor_, @NotNull DisplayHandler.Align align) {
      Intrinsics.checkNotNullParameter(background_, "background_");
      Intrinsics.checkNotNullParameter(align, "align");
      DisplayHandler.Background var10000 = this.background;
      if (var10000 == null) {
         var10000 = background_;
      }

      DisplayHandler.Background background = var10000;
      Long var23 = this.backgroundColor;
      long backgroundColor = var23 == null ? backgroundColor_ : var23;
      var23 = this.textColor;
      long textColor = var23 == null ? textColor_ : var23;
      float var24;
      switch(DisplayLine.WhenMappings.$EnumSwitchMapping$0[align.ordinal()]) {
      case 1:
         var24 = x;
         break;
      case 2:
         var24 = x - totalWidth / (float)2;
         break;
      case 3:
         var24 = x - totalWidth;
         break;
      default:
         throw new NoWhenBranchMatchedException();
      }

      float baseX = var24;
      float var10001;
      float var10002;
      float var10003;
      Text var10004;
      if (background == DisplayHandler.Background.FULL) {
         var10001 = baseX - (float)1;
         var10002 = y - (float)1;
         var10003 = totalWidth + (float)1;
         var10004 = this.text;
         if (var10004 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("text");
            var10004 = null;
         }

         Renderer.drawRect(backgroundColor, var10001, var10002, var10003, var10004.getHeight());
      }

      Text var26 = this.text;
      if (var26 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("text");
         var26 = null;
      }

      if (((CharSequence)var26.getString()).length() != 0) {
         DisplayHandler.Align var27 = this.align;
         if (var27 == null) {
            var27 = align;
         }

         switch(DisplayLine.WhenMappings.$EnumSwitchMapping$0[var27.ordinal()]) {
         case 1:
            var24 = baseX;
            break;
         case 2:
            var24 = baseX + (totalWidth - this.textWidth) / (float)2;
            break;
         case 3:
            var24 = baseX + (totalWidth - this.textWidth);
            break;
         default:
            throw new NoWhenBranchMatchedException();
         }

         float xOffset = var24;
         if (background == DisplayHandler.Background.PER_LINE) {
            var10001 = xOffset - (float)1;
            var10002 = y - (float)1;
            var10003 = this.textWidth + (float)1;
            var10004 = this.text;
            if (var10004 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("text");
               var10004 = null;
            }

            Renderer.drawRect(backgroundColor, var10001, var10002, var10003, var10004.getHeight());
         }

         var26 = this.text;
         if (var26 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("text");
            var26 = null;
         }

         Text.draw$default(var26.setX(xOffset).setY(y).setColor(textColor), (Float)null, (Float)null, 3, (Object)null);
         this.cachedX = (double)baseX - 1.0D;
         this.cachedY = (double)y - 2.0D;
         this.cachedWidth = (double)totalWidth + 1.0D;
         Text var25 = this.text;
         if (var25 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("text");
            var25 = null;
         }

         this.cachedHeight = (double)var25.getHeight() + 1.0D;
         if (this.shouldRender) {
            double var17 = this.cachedX;
            double var19 = this.cachedX + this.cachedWidth;
            double var21 = (double)Client.Companion.getMouseX();
            Float[] var18;
            RegularTrigger var28;
            if (var17 <= var21 ? var21 <= var19 : false) {
               var17 = this.cachedY;
               var19 = this.cachedY + this.cachedHeight;
               var21 = (double)Client.Companion.getMouseY();
               if (var17 <= var21 ? var21 <= var19 : false) {
                  this.hovered = true;
                  var28 = this.onHovered;
                  if (var28 != null) {
                     var18 = new Float[]{Client.Companion.getMouseX(), Client.Companion.getMouseY()};
                     var28.trigger(var18);
                  }

                  return;
               }
            }

            if (this.hovered) {
               var28 = this.onMouseLeave;
               if (var28 != null) {
                  var18 = new Float[]{Client.Companion.getMouseX(), Client.Companion.getMouseY()};
                  var28.trigger(var18);
               }
            }

            this.hovered = false;
         }
      }
   }

   @NotNull
   public abstract ILoader getLoader$ctjs();

   @NotNull
   public String toString() {
      StringBuilder var10000 = (new StringBuilder()).append("DisplayLine{text=");
      Text var10001 = this.text;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("text");
         var10001 = null;
      }

      return var10000.append(var10001).append(", textColor=").append(this.textColor).append(", align=").append(this.align).append(", background=").append(this.background).append(", backgroundColor=").append(this.backgroundColor).append('}').toString();
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[DisplayHandler.Align.values().length];
         var0[DisplayHandler.Align.LEFT.ordinal()] = 1;
         var0[DisplayHandler.Align.CENTER.ordinal()] = 2;
         var0[DisplayHandler.Align.RIGHT.ordinal()] = 3;
         $EnumSwitchMapping$0 = var0;
      }
   }
}
