package com.chattriggers.ctjs.minecraft.objects.display;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.GuiScreenEvent.DrawScreenEvent.Post;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Text;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001:\u0004\u0010\u0011\u0012\u0013B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0006\u001a\u00020\u0007J\u000e\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0005J\u0010\u0010\u000b\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\rH\u0007J\u0010\u0010\u000e\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\u000fH\u0007R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0014"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler;", "", "()V", "displays", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Lcom/chattriggers/ctjs/minecraft/objects/display/Display;", "clearDisplays", "", "registerDisplay", "", "display", "renderDisplayGui", "event", "Lnet/minecraftforge/client/event/GuiScreenEvent$DrawScreenEvent$Post;", "renderDisplayOverlay", "Lnet/minecraftforge/client/event/RenderGameOverlayEvent$Text;", "Align", "Background", "Order", "RegisterType", "ctjs"}
)
public final class DisplayHandler {
   @NotNull
   public static final DisplayHandler INSTANCE = new DisplayHandler();
   @NotNull
   private static final CopyOnWriteArrayList<Display> displays = new CopyOnWriteArrayList();

   private DisplayHandler() {
   }

   public final boolean registerDisplay(@NotNull Display display) {
      Intrinsics.checkNotNullParameter(display, "display");
      return displays.add(display);
   }

   public final void clearDisplays() {
      displays.clear();
   }

   @SubscribeEvent
   public final void renderDisplayOverlay(@NotNull Text event) {
      Intrinsics.checkNotNullParameter(event, "event");
      GlStateManager.func_179094_E();
      Iterable $this$forEach$iv = (Iterable)displays;
      int $i$f$forEach = false;
      Iterator var4 = $this$forEach$iv.iterator();

      while(var4.hasNext()) {
         Object element$iv = var4.next();
         Display it = (Display)element$iv;
         int var7 = false;
         if (it.getRegisterType$ctjs() == DisplayHandler.RegisterType.RENDER_OVERLAY) {
            it.render();
         }
      }

      GlStateManager.func_179121_F();
   }

   @SubscribeEvent
   public final void renderDisplayGui(@NotNull Post event) {
      Intrinsics.checkNotNullParameter(event, "event");
      GlStateManager.func_179094_E();
      Iterable $this$forEach$iv = (Iterable)displays;
      int $i$f$forEach = false;
      Iterator var4 = $this$forEach$iv.iterator();

      while(var4.hasNext()) {
         Object element$iv = var4.next();
         Display it = (Display)element$iv;
         int var7 = false;
         if (it.getRegisterType$ctjs() == DisplayHandler.RegisterType.POST_GUI_RENDER) {
            it.render();
         }
      }

      GlStateManager.func_179121_F();
   }

   static {
      MinecraftForge.EVENT_BUS.register(INSTANCE);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004¨\u0006\u0005"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler$RegisterType;", "", "(Ljava/lang/String;I)V", "RENDER_OVERLAY", "POST_GUI_RENDER", "ctjs"}
   )
   public static enum RegisterType {
      RENDER_OVERLAY,
      POST_GUI_RENDER;

      // $FF: synthetic method
      private static final DisplayHandler.RegisterType[] $values() {
         DisplayHandler.RegisterType[] var0 = new DisplayHandler.RegisterType[]{RENDER_OVERLAY, POST_GUI_RENDER};
         return var0;
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler$Background;", "", "(Ljava/lang/String;I)V", "NONE", "FULL", "PER_LINE", "ctjs"}
   )
   public static enum Background {
      NONE,
      FULL,
      PER_LINE;

      // $FF: synthetic method
      private static final DisplayHandler.Background[] $values() {
         DisplayHandler.Background[] var0 = new DisplayHandler.Background[]{NONE, FULL, PER_LINE};
         return var0;
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler$Align;", "", "(Ljava/lang/String;I)V", "LEFT", "CENTER", "RIGHT", "ctjs"}
   )
   public static enum Align {
      LEFT,
      CENTER,
      RIGHT;

      // $FF: synthetic method
      private static final DisplayHandler.Align[] $values() {
         DisplayHandler.Align[] var0 = new DisplayHandler.Align[]{LEFT, CENTER, RIGHT};
         return var0;
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004¨\u0006\u0005"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler$Order;", "", "(Ljava/lang/String;I)V", "UP", "DOWN", "ctjs"}
   )
   public static enum Order {
      UP,
      DOWN;

      // $FF: synthetic method
      private static final DisplayHandler.Order[] $values() {
         DisplayHandler.Order[] var0 = new DisplayHandler.Order[]{UP, DOWN};
         return var0;
      }
   }
}
