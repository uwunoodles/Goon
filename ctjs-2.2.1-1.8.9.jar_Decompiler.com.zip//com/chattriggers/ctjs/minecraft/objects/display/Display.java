package com.chattriggers.ctjs.minecraft.objects.display;

import com.chattriggers.ctjs.utils.kotlin.ExtensionsKt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;
import kotlin.Metadata;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mozilla.javascript.NativeObject;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000|\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010 \n\u0002\b\u000b\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010!\n\u0002\b\u000b\b&\u0018\u00002\u00020\u0001B\u0011\b\u0016\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\u0002\u0010\u0004B\u0005¢\u0006\u0002\u0010\u0005J\u001a\u0010 \u001a\u00020\u00002\b\b\u0002\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020\u0001H\u0007J\u001f\u0010$\u001a\u00020\u00002\u0012\u0010\u000e\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00010%\"\u00020\u0001¢\u0006\u0002\u0010&J\u0006\u0010'\u001a\u00020\u0000J\u0015\u0010(\u001a\u00020\u00102\u0006\u0010)\u001a\u00020*H ¢\u0006\u0002\b+J\u0006\u0010,\u001a\u00020\u0007J\u0006\u0010-\u001a\u00020\tJ\u0006\u0010.\u001a\u00020\u000bJ\u0006\u0010/\u001a\u00020\rJ\u000e\u00100\u001a\u00020\u00102\u0006\u0010!\u001a\u00020\"J\f\u00101\u001a\b\u0012\u0004\u0012\u00020\u001002J\u0006\u00103\u001a\u00020\rJ\u0006\u00104\u001a\u00020\u0013J\u0006\u00105\u001a\u00020\u0015J\u0006\u00106\u001a\u00020\rJ\u0006\u00107\u001a\u00020\rJ\u0006\u00108\u001a\u00020\u001dJ\u0006\u00109\u001a\u00020\u000bJ\u0006\u0010:\u001a\u00020\rJ\u0006\u0010;\u001a\u00020\u0000J\u000e\u0010<\u001a\u00020\u00002\u0006\u0010!\u001a\u00020\"J\u0006\u0010=\u001a\u00020>J\u000e\u0010?\u001a\u00020\u00002\u0006\u0010\u0006\u001a\u00020\u0001J\u000e\u0010@\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u0001J\u000e\u0010A\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010B\u001a\u00020\u00002\u0006\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020\u0001J\u0014\u0010C\u001a\u00020\u00002\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100DJ\u000e\u0010E\u001a\u00020\u00002\u0006\u0010\u0011\u001a\u00020\rJ\u000e\u0010F\u001a\u00020\u00002\u0006\u0010\u0012\u001a\u00020\u0001J\u000e\u0010G\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\u0001J\u0016\u0010H\u001a\u00020\u00002\u0006\u0010\u001a\u001a\u00020\r2\u0006\u0010\u001b\u001a\u00020\rJ\u000e\u0010I\u001a\u00020\u00002\u0006\u0010\u001a\u001a\u00020\rJ\u000e\u0010J\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\rJ\u000e\u0010K\u001a\u00020\u00002\u0006\u0010\u001c\u001a\u00020\u001dJ\u000e\u0010L\u001a\u00020\u00002\u0006\u0010\u001e\u001a\u00020\u000bJ\u0006\u0010M\u001a\u00020\u0000J\b\u0010N\u001a\u00020*H\u0016R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u0014\u001a\u00020\u0015X\u0080\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019R\u000e\u0010\u001a\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006O"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/display/Display;", "", "config", "Lorg/mozilla/javascript/NativeObject;", "(Lorg/mozilla/javascript/NativeObject;)V", "()V", "align", "Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler$Align;", "background", "Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler$Background;", "backgroundColor", "", "height", "", "lines", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayLine;", "minWidth", "order", "Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler$Order;", "registerType", "Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler$RegisterType;", "getRegisterType$ctjs", "()Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler$RegisterType;", "setRegisterType$ctjs", "(Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler$RegisterType;)V", "renderX", "renderY", "shouldRender", "", "textColor", "width", "addLine", "index", "", "line", "addLines", "", "([Ljava/lang/Object;)Lcom/chattriggers/ctjs/minecraft/objects/display/Display;", "clearLines", "createDisplayLine", "text", "", "createDisplayLine$ctjs", "getAlign", "getBackground", "getBackgroundColor", "getHeight", "getLine", "getLines", "", "getMinWidth", "getOrder", "getRegisterType", "getRenderX", "getRenderY", "getShouldRender", "getTextColor", "getWidth", "hide", "removeLine", "render", "", "setAlign", "setBackground", "setBackgroundColor", "setLine", "setLines", "", "setMinWidth", "setOrder", "setRegisterType", "setRenderLoc", "setRenderX", "setRenderY", "setShouldRender", "setTextColor", "show", "toString", "ctjs"}
)
public abstract class Display {
   @NotNull
   private CopyOnWriteArrayList<DisplayLine> lines;
   private float renderX;
   private float renderY;
   private boolean shouldRender;
   @NotNull
   private DisplayHandler.Order order;
   private long backgroundColor;
   private long textColor;
   @NotNull
   private DisplayHandler.Background background;
   @NotNull
   private DisplayHandler.Align align;
   private float minWidth;
   private float width;
   private float height;
   @NotNull
   private DisplayHandler.RegisterType registerType;

   public Display() {
      this.lines = new CopyOnWriteArrayList();
      this.shouldRender = true;
      this.order = DisplayHandler.Order.DOWN;
      this.backgroundColor = 1342177280L;
      this.textColor = 4294967295L;
      this.background = DisplayHandler.Background.NONE;
      this.align = DisplayHandler.Align.LEFT;
      this.registerType = DisplayHandler.RegisterType.RENDER_OVERLAY;
      DisplayHandler.INSTANCE.registerDisplay(this);
   }

   @NotNull
   public final DisplayHandler.RegisterType getRegisterType$ctjs() {
      return this.registerType;
   }

   public final void setRegisterType$ctjs(@NotNull DisplayHandler.RegisterType var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.registerType = var1;
   }

   public Display(@Nullable NativeObject config) {
      this();
      this.setBackgroundColor(Long.parseLong(ExtensionsKt.getOption(config, "backgroundColor", 1342177280)));
      this.setTextColor(Long.parseLong(ExtensionsKt.getOption(config, "textColor", 4294967295L)));
      this.setBackground(ExtensionsKt.getOption(config, "background", DisplayHandler.Background.NONE));
      this.setAlign(ExtensionsKt.getOption(config, "align", DisplayHandler.Align.LEFT));
      this.setOrder(ExtensionsKt.getOption(config, "order", DisplayHandler.Order.DOWN));
      this.setRenderX(Float.parseFloat(ExtensionsKt.getOption(config, "renderX", 0.0F)));
      this.setRenderY(Float.parseFloat(ExtensionsKt.getOption(config, "renderY", 0.0F)));
      this.setShouldRender(Boolean.parseBoolean(ExtensionsKt.getOption(config, "shouldRender", true)));
      this.setMinWidth(Float.parseFloat(ExtensionsKt.getOption(config, "minWidth", 0.0F)));
      this.setRegisterType(ExtensionsKt.getOption(config, "registerType", DisplayHandler.RegisterType.RENDER_OVERLAY));
   }

   public final long getBackgroundColor() {
      return this.backgroundColor;
   }

   @NotNull
   public final Display setBackgroundColor(long backgroundColor) {
      Display $this$setBackgroundColor_u24lambda_u2d0 = (Display)this;
      int var5 = false;
      $this$setBackgroundColor_u24lambda_u2d0.backgroundColor = backgroundColor;
      return (Display)this;
   }

   public final long getTextColor() {
      return this.textColor;
   }

   @NotNull
   public final Display setTextColor(long textColor) {
      Display $this$setTextColor_u24lambda_u2d1 = (Display)this;
      int var5 = false;
      $this$setTextColor_u24lambda_u2d1.textColor = textColor;
      return (Display)this;
   }

   @NotNull
   public final DisplayHandler.Background getBackground() {
      return this.background;
   }

   @NotNull
   public final Display setBackground(@NotNull Object background) {
      Intrinsics.checkNotNullParameter(background, "background");
      Display $this$setBackground_u24lambda_u2d2 = (Display)this;
      int var4 = false;
      DisplayHandler.Background var6;
      if (background instanceof String) {
         String var10001 = ((String)background).toUpperCase(Locale.ROOT);
         Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).toUpperCase(Locale.ROOT)");
         var6 = DisplayHandler.Background.valueOf(StringsKt.replace$default(var10001, " ", "_", false, 4, (Object)null));
      } else {
         var6 = background instanceof DisplayHandler.Background ? (DisplayHandler.Background)background : DisplayHandler.Background.NONE;
      }

      $this$setBackground_u24lambda_u2d2.background = var6;
      return (Display)this;
   }

   @NotNull
   public final DisplayHandler.Align getAlign() {
      return this.align;
   }

   @NotNull
   public final Display setAlign(@NotNull Object align) {
      Intrinsics.checkNotNullParameter(align, "align");
      Display $this$setAlign_u24lambda_u2d3 = (Display)this;
      int var4 = false;
      DisplayHandler.Align var6;
      if (align instanceof String) {
         String var10001 = ((String)align).toUpperCase(Locale.ROOT);
         Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).toUpperCase(Locale.ROOT)");
         var6 = DisplayHandler.Align.valueOf(var10001);
      } else {
         var6 = align instanceof DisplayHandler.Align ? (DisplayHandler.Align)align : DisplayHandler.Align.LEFT;
      }

      $this$setAlign_u24lambda_u2d3.align = var6;
      return (Display)this;
   }

   @NotNull
   public final DisplayHandler.Order getOrder() {
      return this.order;
   }

   @NotNull
   public final Display setOrder(@NotNull Object order) {
      Intrinsics.checkNotNullParameter(order, "order");
      Display $this$setOrder_u24lambda_u2d4 = (Display)this;
      int var4 = false;
      DisplayHandler.Order var6;
      if (order instanceof String) {
         String var10001 = ((String)order).toUpperCase(Locale.ROOT);
         Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).toUpperCase(Locale.ROOT)");
         var6 = DisplayHandler.Order.valueOf(var10001);
      } else {
         var6 = order instanceof DisplayHandler.Order ? (DisplayHandler.Order)order : DisplayHandler.Order.DOWN;
      }

      $this$setOrder_u24lambda_u2d4.order = var6;
      return (Display)this;
   }

   @NotNull
   public final Display setLine(int index, @NotNull Object line) {
      Intrinsics.checkNotNullParameter(line, "line");
      Display $this$setLine_u24lambda_u2d5 = (Display)this;
      boolean var5 = false;

      while($this$setLine_u24lambda_u2d5.lines.size() - 1 < index) {
         $this$setLine_u24lambda_u2d5.lines.add($this$setLine_u24lambda_u2d5.createDisplayLine$ctjs(""));
      }

      $this$setLine_u24lambda_u2d5.lines.set(index, line instanceof String ? $this$setLine_u24lambda_u2d5.createDisplayLine$ctjs((String)line) : (line instanceof DisplayLine ? (DisplayLine)line : $this$setLine_u24lambda_u2d5.createDisplayLine$ctjs("")));
      return (Display)this;
   }

   @NotNull
   public final DisplayLine getLine(int index) {
      Object var2 = this.lines.get(index);
      Intrinsics.checkNotNullExpressionValue(var2, "lines[index]");
      return (DisplayLine)var2;
   }

   @NotNull
   public final List<DisplayLine> getLines() {
      return (List)this.lines;
   }

   @NotNull
   public final Display setLines(@NotNull List<DisplayLine> lines) {
      Intrinsics.checkNotNullParameter(lines, "lines");
      Display $this$setLines_u24lambda_u2d6 = (Display)this;
      int var4 = false;
      $this$setLines_u24lambda_u2d6.lines = new CopyOnWriteArrayList((Collection)lines);
      return (Display)this;
   }

   @JvmOverloads
   @NotNull
   public final Display addLine(int index, @NotNull Object line) {
      Intrinsics.checkNotNullParameter(line, "line");
      Display $this$addLine_u24lambda_u2d7 = (Display)this;
      int var5 = false;
      DisplayLine toAdd = line instanceof String ? $this$addLine_u24lambda_u2d7.createDisplayLine$ctjs((String)line) : (line instanceof DisplayLine ? (DisplayLine)line : $this$addLine_u24lambda_u2d7.createDisplayLine$ctjs(""));
      if (index == -1) {
         $this$addLine_u24lambda_u2d7.lines.add(toAdd);
      } else {
         $this$addLine_u24lambda_u2d7.lines.add(index, toAdd);
      }

      return (Display)this;
   }

   // $FF: synthetic method
   public static Display addLine$default(Display var0, int var1, Object var2, int var3, Object var4) {
      if (var4 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: addLine");
      } else {
         if ((var3 & 1) != 0) {
            var1 = -1;
         }

         return var0.addLine(var1, var2);
      }
   }

   @NotNull
   public final Display addLines(@NotNull Object... lines) {
      Intrinsics.checkNotNullParameter(lines, "lines");
      Display $this$addLines_u24lambda_u2d9 = (Display)this;
      int var4 = false;
      CopyOnWriteArrayList var6 = $this$addLines_u24lambda_u2d9.lines;
      int $i$f$map = false;
      Object[] $this$mapTo$iv$iv = lines;
      Collection destination$iv$iv = (Collection)(new ArrayList(lines.length));
      int $i$f$mapTo = false;
      int var11 = 0;

      for(int var12 = lines.length; var11 < var12; ++var11) {
         Object item$iv$iv = $this$mapTo$iv$iv[var11];
         int var16 = false;
         destination$iv$iv.add(item$iv$iv instanceof String ? $this$addLines_u24lambda_u2d9.createDisplayLine$ctjs((String)item$iv$iv) : (item$iv$iv instanceof DisplayLine ? (DisplayLine)item$iv$iv : $this$addLines_u24lambda_u2d9.createDisplayLine$ctjs("")));
      }

      var6.addAll((Collection)((List)destination$iv$iv));
      return (Display)this;
   }

   @NotNull
   public final Display removeLine(int index) {
      Display $this$removeLine_u24lambda_u2d10 = (Display)this;
      int var4 = false;
      $this$removeLine_u24lambda_u2d10.lines.remove(index);
      return (Display)this;
   }

   @NotNull
   public final Display clearLines() {
      Display $this$clearLines_u24lambda_u2d11 = (Display)this;
      int var3 = false;
      $this$clearLines_u24lambda_u2d11.lines.clear();
      return (Display)this;
   }

   public final float getRenderX() {
      return this.renderX;
   }

   @NotNull
   public final Display setRenderX(float renderX) {
      Display $this$setRenderX_u24lambda_u2d12 = (Display)this;
      int var4 = false;
      $this$setRenderX_u24lambda_u2d12.renderX = renderX;
      return (Display)this;
   }

   public final float getRenderY() {
      return this.renderY;
   }

   @NotNull
   public final Display setRenderY(float renderY) {
      Display $this$setRenderY_u24lambda_u2d13 = (Display)this;
      int var4 = false;
      $this$setRenderY_u24lambda_u2d13.renderY = renderY;
      return (Display)this;
   }

   @NotNull
   public final Display setRenderLoc(float renderX, float renderY) {
      Display $this$setRenderLoc_u24lambda_u2d14 = (Display)this;
      int var5 = false;
      $this$setRenderLoc_u24lambda_u2d14.renderX = renderX;
      $this$setRenderLoc_u24lambda_u2d14.renderY = renderY;
      return (Display)this;
   }

   public final boolean getShouldRender() {
      return this.shouldRender;
   }

   @NotNull
   public final Display setShouldRender(boolean shouldRender) {
      Display $this$setShouldRender_u24lambda_u2d16 = (Display)this;
      int var4 = false;
      $this$setShouldRender_u24lambda_u2d16.shouldRender = shouldRender;
      Iterable $this$forEach$iv = (Iterable)$this$setShouldRender_u24lambda_u2d16.lines;
      int $i$f$forEach = false;
      Iterator var7 = $this$forEach$iv.iterator();

      while(var7.hasNext()) {
         Object element$iv = var7.next();
         DisplayLine it = (DisplayLine)element$iv;
         int var10 = false;
         it.setShouldRender$ctjs(shouldRender);
      }

      return (Display)this;
   }

   @NotNull
   public final Display show() {
      Display $this$show_u24lambda_u2d17 = (Display)this;
      int var3 = false;
      $this$show_u24lambda_u2d17.setShouldRender(true);
      return (Display)this;
   }

   @NotNull
   public final Display hide() {
      Display $this$hide_u24lambda_u2d18 = (Display)this;
      int var3 = false;
      $this$hide_u24lambda_u2d18.setShouldRender(false);
      return (Display)this;
   }

   public final float getWidth() {
      return this.width;
   }

   public final float getHeight() {
      return this.height;
   }

   public final float getMinWidth() {
      return this.minWidth;
   }

   @NotNull
   public final Display setMinWidth(float minWidth) {
      Display $this$setMinWidth_u24lambda_u2d19 = (Display)this;
      int var4 = false;
      $this$setMinWidth_u24lambda_u2d19.minWidth = minWidth;
      return (Display)this;
   }

   @NotNull
   public final DisplayHandler.RegisterType getRegisterType() {
      return this.registerType;
   }

   @NotNull
   public final Display setRegisterType(@NotNull Object registerType) {
      Intrinsics.checkNotNullParameter(registerType, "registerType");
      Display $this$setRegisterType_u24lambda_u2d20 = (Display)this;
      int var4 = false;
      DisplayHandler.RegisterType var6;
      if (registerType instanceof String) {
         String var10001 = ((String)registerType).toUpperCase(Locale.ROOT);
         Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).toUpperCase(Locale.ROOT)");
         var6 = DisplayHandler.RegisterType.valueOf(StringsKt.replace$default(var10001, " ", "_", false, 4, (Object)null));
      } else {
         var6 = registerType instanceof DisplayHandler.RegisterType ? (DisplayHandler.RegisterType)registerType : DisplayHandler.RegisterType.RENDER_OVERLAY;
      }

      $this$setRegisterType_u24lambda_u2d20.setRegisterType$ctjs(var6);
      return (Display)this;
   }

   public final void render() {
      if (this.shouldRender) {
         Iterable var3 = (Iterable)this.lines;
         Iterator var4 = var3.iterator();
         boolean var7;
         DisplayLine it;
         Float var10000;
         if (!var4.hasNext()) {
            var10000 = null;
         } else {
            DisplayLine it = (DisplayLine)var4.next();
            int var6 = false;

            float var10;
            float var13;
            for(var10 = it.getTextWidth(); var4.hasNext(); var10 = Math.max(var10, var13)) {
               it = (DisplayLine)var4.next();
               var7 = false;
               var13 = it.getTextWidth();
            }

            var10000 = var10;
         }

         Float var10001 = var10000 == null ? null : RangesKt.coerceAtLeast(var10000, this.minWidth);
         this.width = var10001 == null ? this.minWidth : var10001;
         float i = 0.0F;
         Iterable $this$forEach$iv = (Iterable)this.lines;
         int $i$f$forEach = false;
         var4 = $this$forEach$iv.iterator();

         while(var4.hasNext()) {
            Object element$iv = var4.next();
            it = (DisplayLine)element$iv;
            var7 = false;
            it.draw(this.renderX, this.renderY + i, this.width, this.background, this.backgroundColor, this.textColor, this.align);
            switch(Display.WhenMappings.$EnumSwitchMapping$0[this.order.ordinal()]) {
            case 1:
               i += it.getText().getHeight();
               break;
            case 2:
               i -= it.getText().getHeight();
            }
         }

         this.height = i;
      }
   }

   @NotNull
   public abstract DisplayLine createDisplayLine$ctjs(@NotNull String var1);

   @NotNull
   public String toString() {
      StringBuilder var1 = new StringBuilder();
      var1.append("Display{shouldRender=").append(this.shouldRender).append(", registerType=").append(this.registerType).append(", renderX=").append(this.renderX).append(", renderY=").append(this.renderY).append(", background=").append(this.background).append(", backgroundColor=").append(this.backgroundColor).append(", textColor=").append(this.textColor).append(", align=").append(this.align).append(", order=").append(this.order).append(", minWidth=").append(this.minWidth).append(", width=").append(this.width).append(", height=");
      var1.append(this.height).append(", lines=").append(this.lines).append('}');
      return var1.toString();
   }

   @JvmOverloads
   @NotNull
   public final Display addLine(@NotNull Object line) {
      Intrinsics.checkNotNullParameter(line, "line");
      return addLine$default(this, 0, line, 1, (Object)null);
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[DisplayHandler.Order.values().length];
         var0[DisplayHandler.Order.DOWN.ordinal()] = 1;
         var0[DisplayHandler.Order.UP.ordinal()] = 2;
         $EnumSwitchMapping$0 = var0;
      }
   }
}
