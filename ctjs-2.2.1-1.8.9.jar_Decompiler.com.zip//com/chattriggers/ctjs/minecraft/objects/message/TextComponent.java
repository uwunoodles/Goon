package com.chattriggers.ctjs.minecraft.objects.message;

import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.utils.kotlin.ExtensionsKt;
import java.net.URI;
import java.net.URISyntaxException;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.CharsKt;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import net.minecraft.event.ClickEvent;
import net.minecraft.event.HoverEvent;
import net.minecraft.event.ClickEvent.Action;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatStyle;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IChatComponent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0015\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u0000 .2\u00020\u0001:\u0001.B\u000f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004B\u0013\b\u0016\u0012\n\u0010\u0005\u001a\u00060\u0006j\u0002`\u0007¢\u0006\u0002\u0010\bJ\u0006\u0010\u0013\u001a\u00020\u0014J\u0006\u0010\u0015\u001a\u00020\u0014J\b\u0010\u0016\u001a\u0004\u0018\u00010\u0003J\b\u0010\u0017\u001a\u0004\u0018\u00010\u0003J\b\u0010\u0018\u001a\u0004\u0018\u00010\u0003J\b\u0010\u0019\u001a\u0004\u0018\u00010\u0003J\u0006\u0010\u001a\u001a\u00020\u0003J\u0006\u0010\u001b\u001a\u00020\u0010J\b\u0010\u001c\u001a\u00020\u0014H\u0002J\b\u0010\u001d\u001a\u00020\u0014H\u0002J\b\u0010\u001e\u001a\u00020\u0014H\u0002J\u0016\u0010\u001f\u001a\u00020\u00002\u0006\u0010 \u001a\u00020\u00032\u0006\u0010!\u001a\u00020\u0003J\u000e\u0010\"\u001a\u00020\u00002\u0006\u0010 \u001a\u00020\u0003J\u000e\u0010#\u001a\u00020\u00002\u0006\u0010!\u001a\u00020\u0003J\u000e\u0010$\u001a\u00020\u00002\u0006\u0010\u000f\u001a\u00020\u0010J\u0016\u0010%\u001a\u00020\u00002\u0006\u0010 \u001a\u00020\u00032\u0006\u0010!\u001a\u00020\u0003J\u000e\u0010&\u001a\u00020\u00002\u0006\u0010 \u001a\u00020\u0003J\u000e\u0010'\u001a\u00020\u00002\u0006\u0010!\u001a\u00020\u0003J\u000e\u0010(\u001a\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0003J\u0014\u0010)\u001a\u00060*j\u0002`+2\u0006\u0010,\u001a\u00020\u0003H\u0002J\b\u0010-\u001a\u00020\u0003H\u0016R\u001e\u0010\t\u001a\u00060\u0006j\u0002`\u0007X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\bR\u0010\u0010\r\u001a\u0004\u0018\u00010\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006/"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/message/TextComponent;", "", "text", "", "(Ljava/lang/String;)V", "chatComponent", "Lnet/minecraft/util/IChatComponent;", "Lcom/chattriggers/ctjs/utils/kotlin/MCITextComponent;", "(Lnet/minecraft/util/IChatComponent;)V", "chatComponentText", "getChatComponentText", "()Lnet/minecraft/util/IChatComponent;", "setChatComponentText", "clickAction", "clickValue", "formatted", "", "hoverAction", "hoverValue", "actionBar", "", "chat", "getClickAction", "getClickValue", "getHoverAction", "getHoverValue", "getText", "isFormatted", "reInstance", "reInstanceClick", "reInstanceHover", "setClick", "action", "value", "setClickAction", "setClickValue", "setFormatted", "setHover", "setHoverAction", "setHoverValue", "setText", "stringToComponent", "Lnet/minecraft/util/ChatComponentText;", "Lcom/chattriggers/ctjs/utils/kotlin/MCBaseTextComponent;", "string", "toString", "Companion", "ctjs"}
)
public final class TextComponent {
   @NotNull
   public static final TextComponent.Companion Companion = new TextComponent.Companion((DefaultConstructorMarker)null);
   public IChatComponent chatComponentText;
   @NotNull
   private String text;
   private boolean formatted;
   @Nullable
   private String clickAction;
   @Nullable
   private String clickValue;
   @Nullable
   private String hoverAction;
   @Nullable
   private String hoverValue;
   @NotNull
   private static final Regex URL_REGEX = new Regex("((?:[a-z\\d]{2,}://)?[-\\w.]+\\.[a-z]{2,}?(?::\\d{1,5})?.*?(?=[!\"§ \n]|$))");
   @NotNull
   private static final Regex formatRegex = new Regex("[§&][\\da-fk-or]");

   @NotNull
   public final IChatComponent getChatComponentText() {
      IChatComponent var1 = this.chatComponentText;
      if (var1 != null) {
         return var1;
      } else {
         Intrinsics.throwUninitializedPropertyAccessException("chatComponentText");
         return null;
      }
   }

   public final void setChatComponentText(@NotNull IChatComponent var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.chatComponentText = var1;
   }

   public TextComponent(@NotNull String text) {
      Intrinsics.checkNotNullParameter(text, "text");
      super();
      this.formatted = true;
      this.hoverAction = "show_text";
      this.text = text;
      this.reInstance();
   }

   public TextComponent(@NotNull IChatComponent chatComponent) {
      Intrinsics.checkNotNullParameter(chatComponent, "chatComponent");
      super();
      this.formatted = true;
      this.hoverAction = "show_text";
      this.setChatComponentText(chatComponent);
      String var2 = this.getChatComponentText().func_150254_d();
      Intrinsics.checkNotNullExpressionValue(var2, "chatComponentText.formattedText");
      this.text = var2;
      ChatStyle chatStyle = ExtensionsKt.getStyling(chatComponent);
      ClickEvent clickEvent = ExtensionsKt.getClick(chatStyle);
      String var10001;
      if (clickEvent == null) {
         var10001 = null;
      } else {
         Action var6 = clickEvent.func_150669_a();
         var10001 = var6 == null ? null : var6.func_150673_b();
      }

      this.clickAction = var10001;
      this.clickValue = clickEvent == null ? null : clickEvent.func_150668_b();
      HoverEvent hoverEvent = ExtensionsKt.getHover(chatStyle);
      if (hoverEvent == null) {
         var10001 = null;
      } else {
         net.minecraft.event.HoverEvent.Action var7 = hoverEvent.func_150701_a();
         var10001 = var7 == null ? null : var7.func_150685_b();
      }

      this.hoverAction = var10001;
      if (hoverEvent == null) {
         var10001 = null;
      } else {
         IChatComponent var8 = hoverEvent.func_150702_b();
         var10001 = var8 == null ? null : var8.func_150254_d();
      }

      this.hoverValue = var10001;
   }

   @NotNull
   public final String getText() {
      return this.text;
   }

   @NotNull
   public final TextComponent setText(@NotNull String text) {
      Intrinsics.checkNotNullParameter(text, "text");
      TextComponent $this$setText_u24lambda_u2d0 = (TextComponent)this;
      int var4 = false;
      $this$setText_u24lambda_u2d0.text = text;
      $this$setText_u24lambda_u2d0.reInstance();
      return (TextComponent)this;
   }

   public final boolean isFormatted() {
      return this.formatted;
   }

   @NotNull
   public final TextComponent setFormatted(boolean formatted) {
      TextComponent $this$setFormatted_u24lambda_u2d1 = (TextComponent)this;
      int var4 = false;
      $this$setFormatted_u24lambda_u2d1.formatted = formatted;
      $this$setFormatted_u24lambda_u2d1.reInstance();
      return (TextComponent)this;
   }

   @NotNull
   public final TextComponent setClick(@NotNull String action, @NotNull String value) {
      Intrinsics.checkNotNullParameter(action, "action");
      Intrinsics.checkNotNullParameter(value, "value");
      TextComponent $this$setClick_u24lambda_u2d2 = (TextComponent)this;
      int var5 = false;
      $this$setClick_u24lambda_u2d2.clickAction = action;
      $this$setClick_u24lambda_u2d2.clickValue = value;
      $this$setClick_u24lambda_u2d2.reInstanceClick();
      return (TextComponent)this;
   }

   @Nullable
   public final String getClickAction() {
      return this.clickAction;
   }

   @NotNull
   public final TextComponent setClickAction(@NotNull String action) {
      Intrinsics.checkNotNullParameter(action, "action");
      TextComponent $this$setClickAction_u24lambda_u2d3 = (TextComponent)this;
      int var4 = false;
      $this$setClickAction_u24lambda_u2d3.clickAction = action;
      $this$setClickAction_u24lambda_u2d3.reInstanceClick();
      return (TextComponent)this;
   }

   @Nullable
   public final String getClickValue() {
      return this.clickValue;
   }

   @NotNull
   public final TextComponent setClickValue(@NotNull String value) {
      Intrinsics.checkNotNullParameter(value, "value");
      TextComponent $this$setClickValue_u24lambda_u2d4 = (TextComponent)this;
      int var4 = false;
      $this$setClickValue_u24lambda_u2d4.clickValue = value;
      $this$setClickValue_u24lambda_u2d4.reInstanceClick();
      return (TextComponent)this;
   }

   @NotNull
   public final TextComponent setHover(@NotNull String action, @NotNull String value) {
      Intrinsics.checkNotNullParameter(action, "action");
      Intrinsics.checkNotNullParameter(value, "value");
      TextComponent $this$setHover_u24lambda_u2d5 = (TextComponent)this;
      int var5 = false;
      $this$setHover_u24lambda_u2d5.hoverAction = action;
      $this$setHover_u24lambda_u2d5.hoverValue = value;
      $this$setHover_u24lambda_u2d5.reInstanceHover();
      return (TextComponent)this;
   }

   @Nullable
   public final String getHoverAction() {
      return this.hoverAction;
   }

   @NotNull
   public final TextComponent setHoverAction(@NotNull String action) {
      Intrinsics.checkNotNullParameter(action, "action");
      TextComponent $this$setHoverAction_u24lambda_u2d6 = (TextComponent)this;
      int var4 = false;
      $this$setHoverAction_u24lambda_u2d6.hoverAction = action;
      $this$setHoverAction_u24lambda_u2d6.reInstanceHover();
      return (TextComponent)this;
   }

   @Nullable
   public final String getHoverValue() {
      return this.hoverValue;
   }

   @NotNull
   public final TextComponent setHoverValue(@NotNull String value) {
      Intrinsics.checkNotNullParameter(value, "value");
      TextComponent $this$setHoverValue_u24lambda_u2d7 = (TextComponent)this;
      int var4 = false;
      $this$setHoverValue_u24lambda_u2d7.hoverValue = value;
      $this$setHoverValue_u24lambda_u2d7.reInstanceHover();
      return (TextComponent)this;
   }

   public final void chat() {
      Object[] var1 = new Object[]{this};
      (new Message(var1)).chat();
   }

   public final void actionBar() {
      Object[] var1 = new Object[]{this};
      (new Message(var1)).actionBar();
   }

   @NotNull
   public String toString() {
      return "TextComponent{text:" + this.text + ", formatted:" + this.formatted + ", hoverAction:" + this.hoverAction + ", hoverValue:" + this.hoverValue + ", clickAction:" + this.clickAction + ", clickValue:" + this.clickValue + '}';
   }

   private final void reInstance() {
      String string = this.formatted ? ChatLib.addColor(this.text) : this.text;
      this.setChatComponentText((IChatComponent)this.stringToComponent(string));
      this.reInstanceClick();
      this.reInstanceHover();
   }

   private final void reInstanceClick() {
      if (this.clickAction != null && this.clickValue != null) {
         ExtensionsKt.getStyling(this.getChatComponentText()).func_150241_a(new ClickEvent(Action.func_150672_a(this.clickAction), this.formatted ? ChatLib.addColor(this.clickValue) : this.clickValue));
      }
   }

   private final void reInstanceHover() {
      if (this.hoverAction != null && this.hoverValue != null) {
         ExtensionsKt.getStyling(this.getChatComponentText()).func_150209_a(new HoverEvent(net.minecraft.event.HoverEvent.Action.func_150684_a(this.hoverAction), (IChatComponent)(new ChatComponentText(this.formatted ? ChatLib.addColor(this.hoverValue) : this.hoverValue))));
      }
   }

   private final ChatComponentText stringToComponent(String string) {
      StringBuilder buffer = new StringBuilder();
      ChatComponentText comp = new ChatComponentText("");
      Object style = null;
      style = new ChatStyle();

      for(int i = 0; i < string.length(); ++i) {
         boolean var9;
         ChatComponentText var15;
         if (i < string.length() - 1) {
            Regex var10000 = formatRegex;
            int var7 = i + 1;
            String var10001 = string.substring(i, var7);
            Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String…ing(startIndex, endIndex)");
            if (var10000.matches((CharSequence)var10001)) {
               var15 = new ChatComponentText(buffer.toString());
               var9 = false;
               var15.func_150255_a(style.func_150206_m());
               StringsKt.clear(buffer);
               comp.func_150257_a((IChatComponent)var15);
               ++i;
               char var17 = string.charAt(i);
               if ('0' <= var17 ? var17 < 'g' : false) {
                  style.func_150238_a(EnumChatFormatting.values()[CharsKt.digitToInt(string.charAt(i), 16)]);
               } else if (string.charAt(i) == 'k') {
                  style.func_150237_e(true);
               } else if (string.charAt(i) == 'l') {
                  style.func_150227_a(true);
               } else if (string.charAt(i) == 'm') {
                  style.func_150225_c(true);
               } else if (string.charAt(i) == 'n') {
                  style.func_150228_d(true);
               } else if (string.charAt(i) == 'o') {
                  style.func_150217_b(true);
               } else if (string.charAt(i) == 'r') {
                  style = new ChatStyle();
               }
               continue;
            }
         }

         if (URL_REGEX.matchesAt((CharSequence)string, i)) {
            var15 = new ChatComponentText(buffer.toString());
            var9 = false;
            var15.func_150255_a(style.func_150206_m());
            StringsKt.clear(buffer);
            comp.func_150257_a((IChatComponent)var15);
            MatchResult var19 = URL_REGEX.matchAt((CharSequence)string, i);
            Intrinsics.checkNotNull(var19);
            String link = var19.getValue();
            i += link.length() - 1;
            ChatComponentText var18 = new ChatComponentText(link);
            ChatComponentText $this$stringToComponent_u24lambda_u2d10 = var18;
            int var11 = false;
            var18.func_150255_a(style.func_150206_m());

            try {
               $this$stringToComponent_u24lambda_u2d10.func_150256_b().func_150241_a(new ClickEvent(Action.OPEN_URL, (new URI(link)).getScheme() == null ? Intrinsics.stringPlus("http://", link) : link));
            } catch (URISyntaxException var14) {
            }

            comp.func_150257_a((IChatComponent)var18);
         } else {
            buffer.append(string.charAt(i));
         }
      }

      if (((CharSequence)buffer).length() > 0) {
         ChatComponentText var6 = new ChatComponentText(buffer.toString());
         int var8 = false;
         var6.func_150255_a(style.func_150206_m());
         comp.func_150257_a((IChatComponent)var6);
      }

      return comp;
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0006"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/message/TextComponent$Companion;", "", "()V", "URL_REGEX", "Lkotlin/text/Regex;", "formatRegex", "ctjs"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
