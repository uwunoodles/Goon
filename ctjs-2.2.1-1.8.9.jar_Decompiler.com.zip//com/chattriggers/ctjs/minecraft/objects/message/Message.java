package com.chattriggers.ctjs.minecraft.objects.message;

import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.minecraft.wrappers.Client;
import com.chattriggers.ctjs.minecraft.wrappers.Player;
import com.chattriggers.ctjs.minecraft.wrappers.inventory.Item;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.IChatComponent;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000`\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u000b\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\b\u000b\u0018\u00002\u00020\u0001B\u000f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004B\u0013\b\u0016\u0012\n\u0010\u0005\u001a\u00060\u0006j\u0002`\u0007¢\u0006\u0002\u0010\bB\u001f\b\u0016\u0012\u0016\u0010\t\u001a\u0012\u0012\u0004\u0012\u00020\u00010\nj\b\u0012\u0004\u0012\u00020\u0001`\u000b¢\u0006\u0002\u0010\fB\u001b\b\u0016\u0012\u0012\u0010\r\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00010\u000e\"\u00020\u0001¢\u0006\u0002\u0010\u000fJ\u0006\u0010\u0018\u001a\u00020\u0019J\u000e\u0010\u001a\u001a\u00020\u00002\u0006\u0010\u0005\u001a\u00020\u0001J\u0016\u0010\u001a\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\u00112\u0006\u0010\u0005\u001a\u00020\u0001J\u0006\u0010\u001c\u001a\u00020\u0019J\u0006\u0010\u001d\u001a\u00020\u0000J\u0006\u0010\u001e\u001a\u00020\u0000J\u001f\u0010\u001f\u001a\u00020\u00192\u0012\u0010 \u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00000\u000e\"\u00020\u0000¢\u0006\u0002\u0010!J\u0006\u0010\"\u001a\u00020\u0011J\n\u0010#\u001a\u00060\u0006j\u0002`\u0007J\u0006\u0010$\u001a\u00020%J\f\u0010&\u001a\b\u0012\u0004\u0012\u00020\u00160'J\u0006\u0010(\u001a\u00020%J\u0006\u0010)\u001a\u00020\u0014J\u0006\u0010*\u001a\u00020\u0014J\b\u0010+\u001a\u00020\u0019H\u0002J\u000e\u0010,\u001a\u00020\u00002\u0006\u0010-\u001a\u00020\u0011J\u000e\u0010.\u001a\u00020\u00002\u0006\u0010\u0013\u001a\u00020\u0014J\u000e\u0010/\u001a\u00020\u00002\u0006\u0010\u0017\u001a\u00020\u0014J\u0016\u00100\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\u00112\u0006\u0010\u0005\u001a\u00020\u0001J\b\u00101\u001a\u00020%H\u0016R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0012\u001a\u00060\u0006j\u0002`\u0007X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00160\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000¨\u00062"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/message/Message;", "", "event", "Lnet/minecraftforge/client/event/ClientChatReceivedEvent;", "(Lnet/minecraftforge/client/event/ClientChatReceivedEvent;)V", "component", "Lnet/minecraft/util/IChatComponent;", "Lcom/chattriggers/ctjs/utils/kotlin/MCITextComponent;", "(Lnet/minecraft/util/IChatComponent;)V", "messageParts", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "(Ljava/util/ArrayList;)V", "components", "", "([Ljava/lang/Object;)V", "chatLineId", "", "chatMessage", "formatted", "", "", "Lcom/chattriggers/ctjs/minecraft/objects/message/TextComponent;", "recursive", "actionBar", "", "addTextComponent", "index", "chat", "clone", "copy", "edit", "replacements", "([Lcom/chattriggers/ctjs/minecraft/objects/message/Message;)V", "getChatLineId", "getChatMessage", "getFormattedText", "", "getMessageParts", "", "getUnformattedText", "isFormatted", "isRecursive", "parseMessage", "setChatLineId", "id", "setFormatted", "setRecursive", "setTextComponent", "toString", "ctjs"}
)
public final class Message {
   private IChatComponent chatMessage;
   @NotNull
   private final List<TextComponent> messageParts;
   private int chatLineId;
   private boolean recursive;
   private boolean formatted;

   public Message(@NotNull ClientChatReceivedEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      IChatComponent var2 = event.message;
      Intrinsics.checkNotNullExpressionValue(var2, "event.message");
      this(var2);
   }

   public Message(@NotNull IChatComponent component) {
      Intrinsics.checkNotNullParameter(component, "component");
      super();
      this.messageParts = (List)(new ArrayList());
      this.chatLineId = -1;
      this.formatted = true;
      List var10000;
      if (component.func_150253_a().isEmpty()) {
         if (!(component instanceof ChatComponentTranslation)) {
            this.messageParts.add(new TextComponent(component));
            return;
         }

         Iterable $this$forEach$iv = (Iterable)component;
         int $i$f$forEach = false;
         Iterator var4 = $this$forEach$iv.iterator();

         while(var4.hasNext()) {
            Object element$iv = var4.next();
            IChatComponent it = (IChatComponent)element$iv;
            int var7 = false;
            if (it.func_150253_a().isEmpty()) {
               var10000 = this.messageParts;
               Intrinsics.checkNotNullExpressionValue(it, "it");
               var10000.add(new TextComponent(it));
            }
         }
      } else {
         String formattedText = component.func_150254_d();
         Intrinsics.checkNotNullExpressionValue(formattedText, "formattedText");
         CharSequence var10004 = (CharSequence)formattedText;
         String var20 = ((IChatComponent)component.func_150253_a().get(0)).func_150254_d();
         Intrinsics.checkNotNullExpressionValue(var20, "component.siblings[0].formattedText");
         String var10002 = formattedText.substring(0, StringsKt.indexOf$default(var10004, var20, 0, false, 6, (Object)null));
         Intrinsics.checkNotNullExpressionValue(var10002, "this as java.lang.String…ing(startIndex, endIndex)");
         ChatComponentText var16 = new ChatComponentText(var10002);
         int var21 = false;
         var16.func_150255_a(component.func_150256_b());
         this.messageParts.add(new TextComponent((IChatComponent)var16));
         var10000 = this.messageParts;
         List var17 = component.func_150253_a();
         Intrinsics.checkNotNullExpressionValue(var17, "component.siblings");
         Iterable $this$map$iv = (Iterable)var17;
         List var13 = var10000;
         int $i$f$map = false;
         Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
         int $i$f$mapTo = false;
         Iterator var9 = $this$map$iv.iterator();

         while(var9.hasNext()) {
            Object item$iv$iv = var9.next();
            IChatComponent p0 = (IChatComponent)item$iv$iv;
            int var12 = false;
            destination$iv$iv.add(new TextComponent(p0));
         }

         var13.addAll((Collection)((List)destination$iv$iv));
      }

   }

   public Message(@NotNull ArrayList<Object> messageParts) {
      Intrinsics.checkNotNullParameter(messageParts, "messageParts");
      super();
      this.messageParts = (List)(new ArrayList());
      this.chatLineId = -1;
      this.formatted = true;
      Iterable $this$map$iv = (Iterable)messageParts;
      List var12 = this.messageParts;
      int $i$f$map = false;
      Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
      int $i$f$mapTo = false;

      TextComponent var10000;
      for(Iterator var7 = $this$map$iv.iterator(); var7.hasNext(); destination$iv$iv.add(var10000)) {
         Object item$iv$iv = var7.next();
         int var10 = false;
         if (item$iv$iv instanceof String) {
            var10000 = new TextComponent((String)item$iv$iv);
         } else if (item$iv$iv instanceof TextComponent) {
            var10000 = (TextComponent)item$iv$iv;
         } else {
            if (!(item$iv$iv instanceof Item)) {
               return;
            }

            var10000 = ((Item)item$iv$iv).getTextComponent();
         }
      }

      var12.addAll((Collection)((List)destination$iv$iv));
   }

   public Message(@NotNull Object... components) {
      Intrinsics.checkNotNullParameter(components, "components");
      this(new ArrayList((Collection)ArraysKt.asList(components)));
   }

   @NotNull
   public final IChatComponent getChatMessage() {
      this.parseMessage();
      IChatComponent var10000 = this.chatMessage;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("chatMessage");
         var10000 = null;
      }

      return var10000;
   }

   @NotNull
   public final String getFormattedText() {
      String var1 = this.getChatMessage().func_150254_d();
      Intrinsics.checkNotNullExpressionValue(var1, "getChatMessage().formattedText");
      return var1;
   }

   @NotNull
   public final String getUnformattedText() {
      String var1 = this.getChatMessage().func_150260_c();
      Intrinsics.checkNotNullExpressionValue(var1, "getChatMessage().unformattedText");
      return var1;
   }

   @NotNull
   public final List<TextComponent> getMessageParts() {
      return this.messageParts;
   }

   public final int getChatLineId() {
      return this.chatLineId;
   }

   @NotNull
   public final Message setChatLineId(int id) {
      Message $this$setChatLineId_u24lambda_u2d3 = (Message)this;
      int var4 = false;
      $this$setChatLineId_u24lambda_u2d3.chatLineId = id;
      return (Message)this;
   }

   public final boolean isRecursive() {
      return this.recursive;
   }

   @NotNull
   public final Message setRecursive(boolean recursive) {
      Message $this$setRecursive_u24lambda_u2d4 = (Message)this;
      int var4 = false;
      $this$setRecursive_u24lambda_u2d4.recursive = recursive;
      return (Message)this;
   }

   public final boolean isFormatted() {
      return this.formatted;
   }

   @NotNull
   public final Message setFormatted(boolean formatted) {
      Message $this$setFormatted_u24lambda_u2d5 = (Message)this;
      int var4 = false;
      $this$setFormatted_u24lambda_u2d5.formatted = formatted;
      return (Message)this;
   }

   @NotNull
   public final Message setTextComponent(int index, @NotNull Object component) {
      Intrinsics.checkNotNullParameter(component, "component");
      Message $this$setTextComponent_u24lambda_u2d6 = (Message)this;
      int var5 = false;
      if (component instanceof String) {
         $this$setTextComponent_u24lambda_u2d6.messageParts.set(index, new TextComponent((String)component));
      } else if (component instanceof TextComponent) {
         $this$setTextComponent_u24lambda_u2d6.messageParts.set(index, component);
      }

      return (Message)this;
   }

   @NotNull
   public final Message addTextComponent(@NotNull Object component) {
      Intrinsics.checkNotNullParameter(component, "component");
      Message $this$addTextComponent_u24lambda_u2d7 = (Message)this;
      int var4 = false;
      if (component instanceof String) {
         $this$addTextComponent_u24lambda_u2d7.messageParts.add(new TextComponent((String)component));
      } else if (component instanceof TextComponent) {
         $this$addTextComponent_u24lambda_u2d7.messageParts.add(component);
      }

      return (Message)this;
   }

   @NotNull
   public final Message addTextComponent(int index, @NotNull Object component) {
      Intrinsics.checkNotNullParameter(component, "component");
      Message $this$addTextComponent_u24lambda_u2d8 = (Message)this;
      int var5 = false;
      if (component instanceof String) {
         $this$addTextComponent_u24lambda_u2d8.messageParts.add(index, new TextComponent((String)component));
      } else if (component instanceof TextComponent) {
         $this$addTextComponent_u24lambda_u2d8.messageParts.add(index, component);
      }

      return (Message)this;
   }

   @NotNull
   public final Message clone() {
      return this.copy();
   }

   @NotNull
   public final Message copy() {
      Object[] var2 = new Object[]{this.messageParts};
      Message copy = (new Message(var2)).setChatLineId(this.chatLineId);
      copy.recursive = this.recursive;
      copy.formatted = this.formatted;
      return copy;
   }

   public final void edit(@NotNull Message... replacements) {
      Intrinsics.checkNotNullParameter(replacements, "replacements");
      ChatLib.editChat(this, (Message[])Arrays.copyOf(replacements, replacements.length));
   }

   public final void chat() {
      this.parseMessage();
      ChatLib var10000 = ChatLib.INSTANCE;
      IChatComponent var10002 = this.chatMessage;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("chatMessage");
         var10002 = null;
      }

      if (var10000.isPlayer(Intrinsics.stringPlus("[CHAT]: ", var10002.func_150254_d()))) {
         IChatComponent var10001;
         if (this.chatLineId != -1) {
            GuiNewChat var2 = Client.Companion.getChatGUI();
            if (var2 != null) {
               var10001 = this.chatMessage;
               if (var10001 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("chatMessage");
                  var10001 = null;
               }

               var2.func_146234_a(var10001, this.chatLineId);
            }

         } else {
            if (this.recursive) {
               Client.Companion.scheduleTask$default(Client.Companion, 0, (Function0)(new Function0<Unit>() {
                  public final void invoke() {
                     NetHandlerPlayClient var10000 = Client.Companion.getConnection();
                     if (var10000 != null) {
                        S02PacketChat var10001 = new S02PacketChat;
                        IChatComponent var10003 = Message.this.chatMessage;
                        if (var10003 == null) {
                           Intrinsics.throwUninitializedPropertyAccessException("chatMessage");
                           var10003 = null;
                        }

                        var10001.<init>(var10003, (byte)0);
                        var10000.func_147251_a(var10001);
                     }

                  }
               }), 1, (Object)null);
            } else {
               EntityPlayerSP var1 = Player.getPlayer();
               if (var1 != null) {
                  var10001 = this.chatMessage;
                  if (var10001 == null) {
                     Intrinsics.throwUninitializedPropertyAccessException("chatMessage");
                     var10001 = null;
                  }

                  var1.func_145747_a(var10001);
               }
            }

         }
      }
   }

   public final void actionBar() {
      this.parseMessage();
      ChatLib var10000 = ChatLib.INSTANCE;
      IChatComponent var10002 = this.chatMessage;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("chatMessage");
         var10002 = null;
      }

      if (var10000.isPlayer(Intrinsics.stringPlus("[ACTION BAR]: ", var10002.func_150254_d()))) {
         NetHandlerPlayClient var1 = Client.Companion.getConnection();
         if (var1 != null) {
            S02PacketChat var10001 = new S02PacketChat;
            IChatComponent var10003 = this.chatMessage;
            if (var10003 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("chatMessage");
               var10003 = null;
            }

            var10001.<init>(var10003, (byte)2);
            var1.func_147251_a(var10001);
         }

      }
   }

   @NotNull
   public String toString() {
      return "Message{formatted=" + this.formatted + ", recursive=" + this.recursive + ", chatLineId=" + this.chatLineId + ", messageParts=" + this.messageParts + '}';
   }

   private final void parseMessage() {
      this.chatMessage = (IChatComponent)(new ChatComponentText(""));
      Iterable $this$forEach$iv = (Iterable)this.messageParts;
      int $i$f$forEach = false;

      IChatComponent var10000;
      TextComponent it;
      for(Iterator var3 = $this$forEach$iv.iterator(); var3.hasNext(); var10000.func_150257_a(it.getChatComponentText())) {
         Object element$iv = var3.next();
         it = (TextComponent)element$iv;
         int var6 = false;
         var10000 = this.chatMessage;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("chatMessage");
            var10000 = null;
         }
      }

   }
}
