package com.chattriggers.ctjs.minecraft.objects.keybind;

import com.chattriggers.ctjs.engine.ILoader;
import com.chattriggers.ctjs.minecraft.wrappers.Client;
import com.chattriggers.ctjs.triggers.RegularTrigger;
import com.chattriggers.ctjs.triggers.TriggerType;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.apache.commons.lang3.ArrayUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\r\b&\u0018\u0000 &2\u00020\u0001:\u0001&B!\b\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003¢\u0006\u0002\u0010\u0007B\u000f\b\u0016\u0012\u0006\u0010\b\u001a\u00020\t¢\u0006\u0002\u0010\nJ\u0006\u0010\u0011\u001a\u00020\u0003J\u0006\u0010\u0012\u001a\u00020\u0003J\u0006\u0010\u0013\u001a\u00020\u0005J\r\u0010\u0014\u001a\u00020\u0015H ¢\u0006\u0002\b\u0016J\u0006\u0010\u0017\u001a\u00020\fJ\u0006\u0010\u0018\u001a\u00020\fJ\r\u0010\u0019\u001a\u00020\u001aH\u0000¢\u0006\u0002\b\u001bJ\u0010\u0010\u001c\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u001d\u001a\u00020\u0001J\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u001d\u001a\u00020\u0001J\u0010\u0010\u001f\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u001d\u001a\u00020\u0001J\u000e\u0010 \u001a\u00020\u001a2\u0006\u0010!\u001a\u00020\fJ\b\u0010\"\u001a\u00020\u0003H\u0016J\u0006\u0010#\u001a\u00020\u0000J\u0006\u0010$\u001a\u00020\u0000J\u0006\u0010%\u001a\u00020\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006'"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/keybind/KeyBind;", "", "description", "", "keyCode", "", "category", "(Ljava/lang/String;ILjava/lang/String;)V", "keyBinding", "Lnet/minecraft/client/settings/KeyBinding;", "(Lnet/minecraft/client/settings/KeyBinding;)V", "down", "", "onKeyDown", "Lcom/chattriggers/ctjs/triggers/RegularTrigger;", "onKeyPress", "onKeyRelease", "getCategory", "getDescription", "getKeyCode", "getLoader", "Lcom/chattriggers/ctjs/engine/ILoader;", "getLoader$ctjs", "isKeyDown", "isPressed", "onTick", "", "onTick$ctjs", "registerKeyDown", "method", "registerKeyPress", "registerKeyRelease", "setState", "pressed", "toString", "unregisterKeyDown", "unregisterKeyPress", "unregisterKeyRelease", "Companion", "ctjs"}
)
public abstract class KeyBind {
   @NotNull
   public static final KeyBind.Companion Companion = new KeyBind.Companion((DefaultConstructorMarker)null);
   @NotNull
   private final KeyBinding keyBinding;
   @Nullable
   private RegularTrigger onKeyPress;
   @Nullable
   private RegularTrigger onKeyRelease;
   @Nullable
   private RegularTrigger onKeyDown;
   private boolean down;
   @NotNull
   private static final List<KeyBinding> customKeyBindings = (List)(new ArrayList());
   @NotNull
   private static final Map<String, Integer> uniqueCategories = (Map)(new LinkedHashMap());

   @JvmOverloads
   public KeyBind(@NotNull String description, int keyCode, @NotNull String category) {
      Intrinsics.checkNotNullParameter(description, "description");
      Intrinsics.checkNotNullParameter(category, "category");
      super();
      KeyBindHandler.INSTANCE.registerKeyBind(this);
      KeyBinding[] var5 = Client.Companion.getMinecraft().field_71474_y.field_74324_K;
      Intrinsics.checkNotNullExpressionValue(var5, "Client.getMinecraft().gameSettings.keyBindings");
      Object[] var6 = (Object[])var5;
      int var7 = 0;
      int var8 = var6.length;

      Object var10000;
      while(true) {
         if (var7 >= var8) {
            var10000 = null;
            break;
         }

         Object var9 = var6[var7];
         KeyBinding it = (KeyBinding)var9;
         int var11 = false;
         if (Intrinsics.areEqual(I18n.func_135052_a(it.func_151464_g(), new Object[0]), I18n.func_135052_a(description, new Object[0])) && Intrinsics.areEqual(I18n.func_135052_a(it.func_151466_e(), new Object[0]), I18n.func_135052_a(category, new Object[0]))) {
            var10000 = var9;
            break;
         }

         ++var7;
      }

      KeyBinding possibleDuplicate = (KeyBinding)var10000;
      if (possibleDuplicate != null) {
         if (!customKeyBindings.contains(possibleDuplicate)) {
            int var13 = false;
            String var14 = "KeyBind already exists! To get a KeyBind from an existing Minecraft KeyBinding, use the other KeyBind constructor or Client.getKeyBindFromKey.";
            throw new IllegalArgumentException(var14.toString());
         }

         this.keyBinding = possibleDuplicate;
      } else {
         Map var12;
         Integer var15;
         if (!KeyBinding.func_151467_c().contains(category)) {
            var12 = uniqueCategories;
            var15 = 0;
            var12.put(category, var15);
         }

         var12 = uniqueCategories;
         var10000 = uniqueCategories.get(category);
         Intrinsics.checkNotNull(var10000);
         var15 = ((Number)var10000).intValue() + 1;
         var12.put(category, var15);
         this.keyBinding = new KeyBinding(description, keyCode, category);
         ClientRegistry.registerKeyBinding(this.keyBinding);
         customKeyBindings.add(this.keyBinding);
      }

   }

   // $FF: synthetic method
   public KeyBind(String var1, int var2, String var3, int var4, DefaultConstructorMarker var5) {
      if ((var4 & 4) != 0) {
         var3 = "ChatTriggers";
      }

      this(var1, var2, var3);
   }

   public KeyBind(@NotNull KeyBinding keyBinding) {
      Intrinsics.checkNotNullParameter(keyBinding, "keyBinding");
      super();
      KeyBindHandler.INSTANCE.registerKeyBind(this);
      this.keyBinding = keyBinding;
   }

   @Nullable
   public final RegularTrigger registerKeyPress(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      KeyBind $this$registerKeyPress_u24lambda_u2d2 = (KeyBind)this;
      int var3 = false;
      $this$registerKeyPress_u24lambda_u2d2.onKeyPress = new RegularTrigger(method, TriggerType.Other, $this$registerKeyPress_u24lambda_u2d2.getLoader$ctjs());
      return $this$registerKeyPress_u24lambda_u2d2.onKeyPress;
   }

   @Nullable
   public final RegularTrigger registerKeyRelease(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      KeyBind $this$registerKeyRelease_u24lambda_u2d3 = (KeyBind)this;
      int var3 = false;
      $this$registerKeyRelease_u24lambda_u2d3.onKeyRelease = new RegularTrigger(method, TriggerType.Other, $this$registerKeyRelease_u24lambda_u2d3.getLoader$ctjs());
      return $this$registerKeyRelease_u24lambda_u2d3.onKeyRelease;
   }

   @Nullable
   public final RegularTrigger registerKeyDown(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      KeyBind $this$registerKeyDown_u24lambda_u2d4 = (KeyBind)this;
      int var3 = false;
      $this$registerKeyDown_u24lambda_u2d4.onKeyDown = new RegularTrigger(method, TriggerType.Other, $this$registerKeyDown_u24lambda_u2d4.getLoader$ctjs());
      return $this$registerKeyDown_u24lambda_u2d4.onKeyDown;
   }

   @NotNull
   public final KeyBind unregisterKeyPress() {
      KeyBind $this$unregisterKeyPress_u24lambda_u2d5 = (KeyBind)this;
      int var3 = false;
      RegularTrigger var10000 = $this$unregisterKeyPress_u24lambda_u2d5.onKeyPress;
      if (var10000 != null) {
         var10000.unregister();
      }

      $this$unregisterKeyPress_u24lambda_u2d5.onKeyPress = null;
      return (KeyBind)this;
   }

   @NotNull
   public final KeyBind unregisterKeyRelease() {
      KeyBind $this$unregisterKeyRelease_u24lambda_u2d6 = (KeyBind)this;
      int var3 = false;
      RegularTrigger var10000 = $this$unregisterKeyRelease_u24lambda_u2d6.onKeyRelease;
      if (var10000 != null) {
         var10000.unregister();
      }

      $this$unregisterKeyRelease_u24lambda_u2d6.onKeyRelease = null;
      return (KeyBind)this;
   }

   @NotNull
   public final KeyBind unregisterKeyDown() {
      KeyBind $this$unregisterKeyDown_u24lambda_u2d7 = (KeyBind)this;
      int var3 = false;
      RegularTrigger var10000 = $this$unregisterKeyDown_u24lambda_u2d7.onKeyDown;
      if (var10000 != null) {
         var10000.unregister();
      }

      $this$unregisterKeyDown_u24lambda_u2d7.onKeyDown = null;
      return (KeyBind)this;
   }

   public final void onTick$ctjs() {
      RegularTrigger var10000;
      if (this.isPressed()) {
         var10000 = this.onKeyPress;
         if (var10000 != null) {
            var10000.trigger(new Object[0]);
         }

         this.down = true;
      }

      if (this.isKeyDown()) {
         var10000 = this.onKeyDown;
         if (var10000 != null) {
            var10000.trigger(new Object[0]);
         }

         this.down = true;
      }

      if (this.down && !this.isKeyDown()) {
         var10000 = this.onKeyRelease;
         if (var10000 != null) {
            var10000.trigger(new Object[0]);
         }

         this.down = false;
      }

   }

   public final boolean isKeyDown() {
      return this.keyBinding.func_151470_d();
   }

   public final boolean isPressed() {
      return this.keyBinding.func_151468_f();
   }

   @NotNull
   public final String getDescription() {
      String var1 = this.keyBinding.func_151464_g();
      Intrinsics.checkNotNullExpressionValue(var1, "keyBinding.keyDescription");
      return var1;
   }

   public final int getKeyCode() {
      return this.keyBinding.func_151463_i();
   }

   @NotNull
   public final String getCategory() {
      String var1 = this.keyBinding.func_151466_e();
      Intrinsics.checkNotNullExpressionValue(var1, "keyBinding.keyCategory");
      return var1;
   }

   public final void setState(boolean pressed) {
      KeyBinding.func_74510_a(this.keyBinding.func_151463_i(), pressed);
   }

   @NotNull
   public abstract ILoader getLoader$ctjs();

   @NotNull
   public String toString() {
      return "KeyBind{description=" + this.getDescription() + ", keyCode=" + this.getKeyCode() + ", category=" + this.getCategory() + '}';
   }

   @JvmOverloads
   public KeyBind(@NotNull String description, int keyCode) {
      Intrinsics.checkNotNullParameter(description, "description");
      this(description, keyCode, (String)null, 4, (DefaultConstructorMarker)null);
   }

   @JvmStatic
   public static final void removeKeyBind(@NotNull KeyBind keyBind) {
      Companion.removeKeyBind(keyBind);
   }

   @JvmStatic
   public static final void clearKeyBinds() {
      Companion.clearKeyBinds();
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010%\n\u0002\u0010\u000e\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\n\u001a\u00020\u000bH\u0007J\u0010\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000eH\u0007J\u0010\u0010\u000f\u001a\u00020\u000b2\u0006\u0010\u0010\u001a\u00020\u0005H\u0002R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0011"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/keybind/KeyBind$Companion;", "", "()V", "customKeyBindings", "", "Lnet/minecraft/client/settings/KeyBinding;", "uniqueCategories", "", "", "", "clearKeyBinds", "", "removeKeyBind", "keyBind", "Lcom/chattriggers/ctjs/minecraft/objects/keybind/KeyBind;", "removeKeyBinding", "keyBinding", "ctjs"}
   )
   public static final class Companion {
      private Companion() {
      }

      private final void removeKeyBinding(KeyBinding keyBinding) {
         Client.Companion.getMinecraft().field_71474_y.field_74324_K = (KeyBinding[])ArrayUtils.removeElement(Client.Companion.getMinecraft().field_71474_y.field_74324_K, keyBinding);
         String category = keyBinding.func_151466_e();
         if (KeyBind.uniqueCategories.containsKey(category)) {
            Map var3 = KeyBind.uniqueCategories;
            Intrinsics.checkNotNullExpressionValue(category, "category");
            Object var10000 = KeyBind.uniqueCategories.get(category);
            Intrinsics.checkNotNull(var10000);
            Integer var5 = ((Number)var10000).intValue() - 1;
            var3.put(category, var5);
            Integer var6 = (Integer)KeyBind.uniqueCategories.get(category);
            boolean var7 = false;
            if (var6 != null) {
               if (var6 == 0) {
                  KeyBind.uniqueCategories.remove(category);
                  KeyBinding.func_151467_c().remove(category);
               }
            }
         }

      }

      @JvmStatic
      public final void removeKeyBind(@NotNull KeyBind keyBind) {
         Intrinsics.checkNotNullParameter(keyBind, "keyBind");
         KeyBinding keyBinding = keyBind.keyBinding;
         if (KeyBind.customKeyBindings.contains(keyBinding)) {
            this.removeKeyBinding(keyBinding);
            KeyBind.customKeyBindings.remove(keyBinding);
            KeyBindHandler.INSTANCE.unregisterKeyBind(keyBind);
         }
      }

      @JvmStatic
      public final void clearKeyBinds() {
         List copy = CollectionsKt.toList((Iterable)KeyBindHandler.INSTANCE.getKeyBinds());
         Iterable $this$forEach$iv = (Iterable)copy;
         int $i$f$forEach = false;
         Iterator var4 = $this$forEach$iv.iterator();

         while(var4.hasNext()) {
            Object element$iv = var4.next();
            KeyBind p0 = (KeyBind)element$iv;
            int var7 = false;
            this.removeKeyBind(p0);
         }

         KeyBind.customKeyBindings.clear();
         KeyBindHandler.INSTANCE.clearKeyBinds();
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
