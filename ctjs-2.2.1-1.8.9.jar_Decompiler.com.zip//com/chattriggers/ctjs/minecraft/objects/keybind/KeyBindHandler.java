package com.chattriggers.ctjs.minecraft.objects.keybind;

import com.chattriggers.ctjs.minecraft.wrappers.World;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\bÀ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0006\u001a\u00020\u0007J\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004J\u0010\u0010\t\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u000bH\u0007J\u000e\u0010\f\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\u0005J\u000e\u0010\u000e\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\u0005R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000f"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/keybind/KeyBindHandler;", "", "()V", "keyBinds", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Lcom/chattriggers/ctjs/minecraft/objects/keybind/KeyBind;", "clearKeyBinds", "", "getKeyBinds", "onTick", "event", "Lnet/minecraftforge/fml/common/gameevent/TickEvent$ClientTickEvent;", "registerKeyBind", "keyBind", "unregisterKeyBind", "ctjs"}
)
public final class KeyBindHandler {
   @NotNull
   public static final KeyBindHandler INSTANCE = new KeyBindHandler();
   @NotNull
   private static final CopyOnWriteArrayList<KeyBind> keyBinds;

   private KeyBindHandler() {
   }

   public final void registerKeyBind(@NotNull KeyBind keyBind) {
      Intrinsics.checkNotNullParameter(keyBind, "keyBind");
      keyBinds.add(keyBind);
   }

   public final void unregisterKeyBind(@NotNull KeyBind keyBind) {
      Intrinsics.checkNotNullParameter(keyBind, "keyBind");
      keyBinds.remove(keyBind);
   }

   public final void clearKeyBinds() {
      keyBinds.clear();
   }

   @NotNull
   public final CopyOnWriteArrayList<KeyBind> getKeyBinds() {
      return keyBinds;
   }

   @SubscribeEvent
   public final void onTick(@NotNull ClientTickEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      if (World.isLoaded() && event.phase != Phase.END) {
         Iterable $this$forEach$iv = (Iterable)keyBinds;
         int $i$f$forEach = false;
         Iterator var4 = $this$forEach$iv.iterator();

         while(var4.hasNext()) {
            Object element$iv = var4.next();
            KeyBind it = (KeyBind)element$iv;
            boolean var7 = false;

            try {
               it.onTick$ctjs();
            } catch (Exception var9) {
            }
         }

      }
   }

   static {
      MinecraftForge.EVENT_BUS.register(INSTANCE);
      keyBinds = new CopyOnWriteArrayList();
   }
}
