package com.chattriggers.ctjs.minecraft.objects;

import com.chattriggers.ctjs.minecraft.objects.gui.GuiHandler;
import com.chattriggers.ctjs.minecraft.objects.message.Message;
import com.chattriggers.ctjs.minecraft.wrappers.Client;
import com.chattriggers.ctjs.minecraft.wrappers.Player;
import com.chattriggers.ctjs.minecraft.wrappers.inventory.nbt.NBTTagCompound;
import kotlin.Metadata;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiScreenBook;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.util.IChatComponent.Serializer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\u000b\u001a\u00020\u00002\u0006\u0010\f\u001a\u00020\rJ\u000e\u0010\u000b\u001a\u00020\u00002\u0006\u0010\f\u001a\u00020\u0003J\u0012\u0010\u000e\u001a\u00020\u000f2\b\b\u0002\u0010\u0010\u001a\u00020\u0011H\u0007J\u0006\u0010\u0012\u001a\u00020\u0011J\u0006\u0010\u0013\u001a\u00020\u0014J\u0016\u0010\u0015\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\f\u001a\u00020\rJ\u000e\u0010\u0016\u001a\u00020\u000f2\u0006\u0010\u0017\u001a\u00020\u0018R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0019"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/Book;", "", "bookName", "", "(Ljava/lang/String;)V", "book", "Lnet/minecraft/item/ItemStack;", "bookData", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTTagCompound;", "bookScreen", "Lnet/minecraft/client/gui/GuiScreenBook;", "addPage", "message", "Lcom/chattriggers/ctjs/minecraft/objects/message/Message;", "display", "", "pageIndex", "", "getCurrentPage", "isOpen", "", "setPage", "updateBookScreen", "pages", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTTagList;", "ctjs"}
)
public final class Book {
   @Nullable
   private GuiScreenBook bookScreen;
   @NotNull
   private final ItemStack book;
   @NotNull
   private final NBTTagCompound bookData;

   public Book(@NotNull String bookName) {
      Intrinsics.checkNotNullParameter(bookName, "bookName");
      super();
      this.book = new ItemStack(Items.field_151164_bB);
      this.bookData = new NBTTagCompound(new net.minecraft.nbt.NBTTagCompound());
      this.bookData.set("author", new NBTTagString(Player.getName()));
      this.bookData.set("title", new NBTTagString(Intrinsics.stringPlus("CT-", bookName)));
      this.bookData.set("pages", new NBTTagList());
      this.book.func_77982_d(this.bookData.getRawNBT());
   }

   @NotNull
   public final Book addPage(@NotNull Message message) {
      Intrinsics.checkNotNullParameter(message, "message");
      Book $this$addPage_u24lambda_u2d0 = (Book)this;
      int var4 = false;
      Object var10000 = $this$addPage_u24lambda_u2d0.bookData.get("pages", NBTTagCompound.NBTDataType.TAG_LIST, 8);
      if (var10000 != null) {
         NBTTagList var6 = (NBTTagList)var10000;
         com.chattriggers.ctjs.minecraft.wrappers.inventory.nbt.NBTTagList pages = new com.chattriggers.ctjs.minecraft.wrappers.inventory.nbt.NBTTagList(var6);
         pages.appendTag((NBTBase)(new NBTTagString(Serializer.func_150696_a(message.getChatMessage()))));
         $this$addPage_u24lambda_u2d0.updateBookScreen(pages);
      }

      return (Book)this;
   }

   @NotNull
   public final Book addPage(@NotNull String message) {
      Intrinsics.checkNotNullParameter(message, "message");
      Book $this$addPage_u24lambda_u2d1 = (Book)this;
      int var4 = false;
      Object[] var5 = new Object[]{message};
      $this$addPage_u24lambda_u2d1.addPage(new Message(var5));
      return (Book)this;
   }

   @NotNull
   public final Book setPage(int pageIndex, @NotNull Message message) {
      Intrinsics.checkNotNullParameter(message, "message");
      Book $this$setPage_u24lambda_u2d2 = (Book)this;
      int var5 = false;
      Object var10000 = $this$setPage_u24lambda_u2d2.bookData.get("pages", NBTTagCompound.NBTDataType.TAG_LIST, 8);
      if (var10000 != null) {
         NBTTagList var9 = (NBTTagList)var10000;
         com.chattriggers.ctjs.minecraft.wrappers.inventory.nbt.NBTTagList pages = new com.chattriggers.ctjs.minecraft.wrappers.inventory.nbt.NBTTagList(var9);
         int var6 = pages.getTagCount();
         int i;
         if (var6 <= pageIndex) {
            do {
               i = var6++;
               $this$setPage_u24lambda_u2d2.addPage("");
            } while(i != pageIndex);
         }

         pages.set(pageIndex, (NBTBase)(new NBTTagString(Serializer.func_150696_a(message.getChatMessage()))));
         $this$setPage_u24lambda_u2d2.updateBookScreen(pages);
      }

      return (Book)this;
   }

   public final void updateBookScreen(@NotNull com.chattriggers.ctjs.minecraft.wrappers.inventory.nbt.NBTTagList pages) {
      Intrinsics.checkNotNullParameter(pages, "pages");
      this.bookData.removeTag("pages");
      this.bookData.set("pages", pages);
      this.book.func_77982_d(this.bookData.getRawNBT());
      GuiScreenBook var10000 = this.bookScreen;
      if (var10000 != null) {
         var10000.field_146483_y = pages.getRawNBT();
      }

   }

   @JvmOverloads
   public final void display(int pageIndex) {
      this.bookScreen = new GuiScreenBook((EntityPlayer)Player.getPlayer(), this.book, false);
      GuiScreenBook var10000 = this.bookScreen;
      Intrinsics.checkNotNull(var10000);
      var10000.field_146484_x = pageIndex;
      GuiHandler var2 = GuiHandler.INSTANCE;
      GuiScreenBook var10001 = this.bookScreen;
      if (var10001 != null) {
         var2.openGui((GuiScreen)var10001);
      }
   }

   // $FF: synthetic method
   public static void display$default(Book var0, int var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = 0;
      }

      var0.display(var1);
   }

   public final boolean isOpen() {
      return Client.Companion.getMinecraft().field_71462_r == this.bookScreen;
   }

   public final int getCurrentPage() {
      int var10000;
      if (this.isOpen() && this.bookScreen != null) {
         GuiScreenBook var1 = this.bookScreen;
         Intrinsics.checkNotNull(var1);
         var10000 = var1.field_146484_x;
      } else {
         var10000 = -1;
      }

      return var10000;
   }

   @JvmOverloads
   public final void display() {
      display$default(this, 0, 1, (Object)null);
   }
}
