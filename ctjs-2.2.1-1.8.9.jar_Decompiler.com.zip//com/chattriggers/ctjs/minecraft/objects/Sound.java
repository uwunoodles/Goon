package com.chattriggers.ctjs.minecraft.objects;

import com.chattriggers.ctjs.CTJS;
import com.chattriggers.ctjs.minecraft.wrappers.Client;
import com.chattriggers.ctjs.minecraft.wrappers.Player;
import com.chattriggers.ctjs.minecraft.wrappers.World;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.audio.SoundCategory;
import net.minecraft.client.audio.SoundManager;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mozilla.javascript.NativeObject;
import paulscode.sound.SoundSystem;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\b\n\u0002\u0010\b\n\u0002\b\f\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u000e\u001a\u00020\u000fH\u0002J\u0006\u0010\u0010\u001a\u00020\u0011J\u0006\u0010\u0012\u001a\u00020\u0011J\b\u0010\u0013\u001a\u00020\u000fH\u0002J\u0006\u0010\u0014\u001a\u00020\u000fJ\u0006\u0010\u0015\u001a\u00020\u000fJ\u0006\u0010\u0016\u001a\u00020\u000fJ\u0006\u0010\u0017\u001a\u00020\u000fJ\u000e\u0010\u0018\u001a\u00020\u00002\u0006\u0010\u0019\u001a\u00020\u001aJ\u000e\u0010\u001b\u001a\u00020\u00002\u0006\u0010\u001c\u001a\u00020\rJ\u000e\u0010\u001d\u001a\u00020\u00002\u0006\u0010\u001e\u001a\u00020\u0011J\u001e\u0010\u001f\u001a\u00020\u00002\u0006\u0010 \u001a\u00020\u00112\u0006\u0010!\u001a\u00020\u00112\u0006\u0010\"\u001a\u00020\u0011J\u000e\u0010#\u001a\u00020\u00002\u0006\u0010$\u001a\u00020\u0011J\u0006\u0010%\u001a\u00020\u000fR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0005\u001a\u00020\u0006X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0007\"\u0004\b\b\u0010\tR\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006&"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/Sound;", "", "config", "Lorg/mozilla/javascript/NativeObject;", "(Lorg/mozilla/javascript/NativeObject;)V", "isListening", "", "()Z", "setListening", "(Z)V", "sndSystem", "Lpaulscode/sound/SoundSystem;", "source", "", "bootstrap", "", "getPitch", "", "getVolume", "loadSndSystem", "onWorldLoad", "pause", "play", "rewind", "setAttenuation", "model", "", "setCategory", "category", "setPitch", "pitch", "setPosition", "x", "y", "z", "setVolume", "volume", "stop", "ctjs"}
)
public final class Sound {
   @NotNull
   private final NativeObject config;
   @Nullable
   private SoundSystem sndSystem;
   @NotNull
   private final String source;
   private boolean isListening;

   public Sound(@NotNull NativeObject config) {
      Intrinsics.checkNotNullParameter(config, "config");
      super();
      this.config = config;
      Object var10001 = this.config.get("source");
      if (var10001 == null) {
         throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
      } else {
         this.source = (String)var10001;
         if (World.isLoaded()) {
            this.loadSndSystem();

            try {
               this.bootstrap();
            } catch (MalformedURLException var3) {
               var3.printStackTrace();
            }
         } else {
            this.isListening = true;
         }

         CTJS.INSTANCE.getSounds().add(this);
      }
   }

   public final boolean isListening() {
      return this.isListening;
   }

   public final void setListening(boolean var1) {
      this.isListening = var1;
   }

   public final void onWorldLoad() {
      this.isListening = false;
      this.loadSndSystem();

      try {
         this.bootstrap();
      } catch (MalformedURLException var2) {
         var2.printStackTrace();
      }

   }

   private final void loadSndSystem() {
      SoundManager sndManager = Client.Companion.getMinecraft().func_147118_V().field_147694_f;
      String[] var2 = new String[]{"sndSystem", "field_148620_e"};
      this.sndSystem = (SoundSystem)ReflectionHelper.getPrivateValue(SoundManager.class, sndManager, var2);
   }

   private final void bootstrap() throws MalformedURLException {
      Object var10000 = this.config.get("source");
      String var11 = var10000 == null ? null : var10000.toString();
      if (var11 == null) {
         throw new IllegalArgumentException("Sound source is null.");
      } else {
         String source = var11;
         var10000 = this.config.getOrDefault("priority", false);
         if (var10000 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
         } else {
            boolean priority = (Boolean)var10000;
            var10000 = this.config.getOrDefault("loop", false);
            if (var10000 == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
            } else {
               boolean loop = (Boolean)var10000;
               var10000 = this.config.getOrDefault("stream", false);
               if (var10000 == null) {
                  throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
               } else {
                  boolean stream = (Boolean)var10000;
                  URL url = (new File(CTJS.INSTANCE.getAssetsDir(), source)).toURI().toURL();
                  var10000 = this.config.getOrDefault("x", Player.getX());
                  if (var10000 == null) {
                     throw new NullPointerException("null cannot be cast to non-null type kotlin.Number");
                  } else {
                     float x = ((Number)var10000).floatValue();
                     var10000 = this.config.getOrDefault("y", Player.getY());
                     if (var10000 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.Number");
                     } else {
                        float y = ((Number)var10000).floatValue();
                        var10000 = this.config.getOrDefault("z", Player.getZ());
                        if (var10000 == null) {
                           throw new NullPointerException("null cannot be cast to non-null type kotlin.Number");
                        } else {
                           float z = ((Number)var10000).floatValue();
                           var10000 = this.config.getOrDefault("attenuation", 1);
                           if (var10000 == null) {
                              throw new NullPointerException("null cannot be cast to non-null type kotlin.Number");
                           } else {
                              int attModel = ((Number)var10000).intValue();
                              int distOrRoll = 16;
                              SoundSystem var12;
                              if (stream) {
                                 var12 = this.sndSystem;
                                 Intrinsics.checkNotNull(var12);
                                 var12.newStreamingSource(priority, source, url, source, loop, x, y, z, attModel, (float)distOrRoll);
                              } else {
                                 var12 = this.sndSystem;
                                 Intrinsics.checkNotNull(var12);
                                 var12.newSource(priority, source, url, source, loop, x, y, z, attModel, (float)distOrRoll);
                              }

                              Object var10001;
                              if (this.config.get("volume") != null) {
                                 var10001 = this.config.get("volume");
                                 if (var10001 == null) {
                                    throw new NullPointerException("null cannot be cast to non-null type kotlin.Number");
                                 }

                                 this.setVolume(((Number)var10001).floatValue());
                              }

                              if (this.config.get("pitch") != null) {
                                 var10001 = this.config.get("pitch");
                                 if (var10001 == null) {
                                    throw new NullPointerException("null cannot be cast to non-null type kotlin.Number");
                                 }

                                 this.setPitch(((Number)var10001).floatValue());
                              }

                              if (this.config.get("category") != null) {
                                 var10001 = this.config.get("category");
                                 if (var10001 == null) {
                                    throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
                                 }

                                 this.setCategory((String)var10001);
                              }

                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @NotNull
   public final Sound setCategory(@NotNull String category) {
      Intrinsics.checkNotNullParameter(category, "category");
      Sound $this$setCategory_u24lambda_u2d0 = (Sound)this;
      int var4 = false;
      String var10000 = category.toLowerCase(Locale.ROOT);
      Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String).toLowerCase(Locale.ROOT)");
      SoundCategory category1 = SoundCategory.func_147154_a(var10000);
      $this$setCategory_u24lambda_u2d0.setVolume(Client.Companion.getMinecraft().field_71474_y.func_151438_a(category1));
      return (Sound)this;
   }

   @NotNull
   public final Sound setVolume(float volume) {
      Sound $this$setVolume_u24lambda_u2d1 = (Sound)this;
      int var4 = false;
      SoundSystem var10000 = $this$setVolume_u24lambda_u2d1.sndSystem;
      Intrinsics.checkNotNull(var10000);
      var10000.setVolume($this$setVolume_u24lambda_u2d1.source, volume);
      return (Sound)this;
   }

   public final float getVolume() {
      SoundSystem var10000 = this.sndSystem;
      Intrinsics.checkNotNull(var10000);
      return var10000.getVolume(this.source);
   }

   @NotNull
   public final Sound setPosition(float x, float y, float z) {
      Sound $this$setPosition_u24lambda_u2d2 = (Sound)this;
      int var6 = false;
      SoundSystem var10000 = $this$setPosition_u24lambda_u2d2.sndSystem;
      Intrinsics.checkNotNull(var10000);
      var10000.setPosition($this$setPosition_u24lambda_u2d2.source, x, y, z);
      return (Sound)this;
   }

   @NotNull
   public final Sound setPitch(float pitch) {
      Sound $this$setPitch_u24lambda_u2d3 = (Sound)this;
      int var4 = false;
      SoundSystem var10000 = $this$setPitch_u24lambda_u2d3.sndSystem;
      Intrinsics.checkNotNull(var10000);
      var10000.setPitch($this$setPitch_u24lambda_u2d3.source, pitch);
      return (Sound)this;
   }

   public final float getPitch() {
      SoundSystem var10000 = this.sndSystem;
      Intrinsics.checkNotNull(var10000);
      return var10000.getPitch(this.source);
   }

   @NotNull
   public final Sound setAttenuation(int model) {
      Sound $this$setAttenuation_u24lambda_u2d4 = (Sound)this;
      int var4 = false;
      SoundSystem var10000 = $this$setAttenuation_u24lambda_u2d4.sndSystem;
      Intrinsics.checkNotNull(var10000);
      var10000.setAttenuation($this$setAttenuation_u24lambda_u2d4.source, model);
      return (Sound)this;
   }

   public final void play() {
      SoundSystem var10000 = this.sndSystem;
      Intrinsics.checkNotNull(var10000);
      var10000.play(this.source);
   }

   public final void pause() {
      SoundSystem var10000 = this.sndSystem;
      Intrinsics.checkNotNull(var10000);
      var10000.pause(this.source);
   }

   public final void stop() {
      SoundSystem var10000 = this.sndSystem;
      Intrinsics.checkNotNull(var10000);
      var10000.stop(this.source);
   }

   public final void rewind() {
      SoundSystem var10000 = this.sndSystem;
      Intrinsics.checkNotNull(var10000);
      var10000.rewind(this.source);
   }
}
