package com.chattriggers.ctjs.minecraft.objects.gui;

import com.chattriggers.ctjs.engine.ILoader;
import com.chattriggers.ctjs.minecraft.listeners.MouseListener;
import com.chattriggers.ctjs.minecraft.wrappers.Client;
import com.chattriggers.ctjs.minecraft.wrappers.Player;
import com.chattriggers.ctjs.triggers.RegularTrigger;
import com.chattriggers.ctjs.triggers.TriggerType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000l\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\f\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0006\n\u0002\u0010\u0000\n\u0002\b\u0014\b&\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u0005H\u0014J<\u0010\u0018\u001a\u00020\u00002\u0006\u0010\u0019\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\t2\u0006\u0010\u001b\u001a\u00020\t2\b\b\u0002\u0010\u001c\u001a\u00020\t2\b\b\u0002\u0010\u001d\u001a\u00020\t2\u0006\u0010\u001e\u001a\u00020\u001fH\u0007J\u000e\u0010\u0018\u001a\u00020\u00002\u0006\u0010\u0017\u001a\u00020\u0005J\u0006\u0010 \u001a\u00020\u0000J\u0006\u0010!\u001a\u00020\u0016J\b\u0010\"\u001a\u00020\u0007H\u0016J\u001e\u0010#\u001a\u00020\u00162\u0006\u0010$\u001a\u00020\u001f2\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\tJ$\u0010%\u001a\u00020\u00162\f\u0010$\u001a\b\u0012\u0004\u0012\u00020\u001f0&2\u0006\u0010\u001a\u001a\u00020\t2\u0006\u0010\u001b\u001a\u00020\tJ \u0010'\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010(\u001a\u00020)H\u0016J&\u0010*\u001a\u00020\u00162\u0006\u0010$\u001a\u00020\u001f2\u0006\u0010\u001a\u001a\u00020\t2\u0006\u0010\u001b\u001a\u00020\t2\u0006\u0010+\u001a\u00020\tJ\u0010\u0010,\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0019\u001a\u00020\tJ\u000e\u0010-\u001a\u00020\u00072\u0006\u0010\u0019\u001a\u00020\tJ\u000e\u0010.\u001a\u00020\t2\u0006\u0010\u0019\u001a\u00020\tJ\u000e\u0010/\u001a\u00020\u00072\u0006\u0010\u0019\u001a\u00020\tJ\u000e\u00100\u001a\u00020\t2\u0006\u0010\u0019\u001a\u00020\tJ\u000e\u00101\u001a\u00020\t2\u0006\u0010\u0019\u001a\u00020\tJ\u000e\u00102\u001a\u00020\t2\u0006\u0010\u0019\u001a\u00020\tJ\r\u00103\u001a\u000204H ¢\u0006\u0002\b5J\b\u00106\u001a\u00020\u0016H\u0016J\u0006\u00107\u001a\u00020\u0007J\u0006\u00108\u001a\u00020\u0007J\u0006\u00109\u001a\u00020\u0007J\u0006\u0010:\u001a\u00020\u0007J\u0018\u0010;\u001a\u00020\u00162\u0006\u0010<\u001a\u00020=2\u0006\u0010>\u001a\u00020\tH\u0014J(\u0010?\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010@\u001a\u00020\t2\u0006\u0010A\u001a\u00020BH\u0014J \u0010C\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u0017\u001a\u00020\tH\u0014J \u0010D\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u0017\u001a\u00020\tH\u0014J\b\u0010E\u001a\u00020\u0016H\u0016J\u0006\u0010F\u001a\u00020\u0016J\u0010\u0010G\u001a\u0004\u0018\u00010\f2\u0006\u0010H\u001a\u00020IJ\u0010\u0010J\u001a\u0004\u0018\u00010\f2\u0006\u0010H\u001a\u00020IJ\u0010\u0010K\u001a\u0004\u0018\u00010\f2\u0006\u0010H\u001a\u00020IJ\u0010\u0010L\u001a\u0004\u0018\u00010\f2\u0006\u0010H\u001a\u00020IJ\u0010\u0010M\u001a\u0004\u0018\u00010\f2\u0006\u0010H\u001a\u00020IJ\u0010\u0010N\u001a\u0004\u0018\u00010\f2\u0006\u0010H\u001a\u00020IJ\u0010\u0010O\u001a\u0004\u0018\u00010\f2\u0006\u0010H\u001a\u00020IJ\u0010\u0010P\u001a\u0004\u0018\u00010\f2\u0006\u0010H\u001a\u00020IJ\u0010\u0010Q\u001a\u0004\u0018\u00010\f2\u0006\u0010H\u001a\u00020IJ\u000e\u0010R\u001a\u00020\u00002\u0006\u0010\u0019\u001a\u00020\tJ\u0016\u0010S\u001a\u00020\u00002\u0006\u0010\u0019\u001a\u00020\t2\u0006\u0010T\u001a\u00020\u0007J\u0016\u0010U\u001a\u00020\u00002\u0006\u0010\u0019\u001a\u00020\t2\u0006\u0010\u001d\u001a\u00020\tJ\u001e\u0010V\u001a\u00020\u00002\u0006\u0010\u0019\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\t2\u0006\u0010\u001b\u001a\u00020\tJ\u0016\u0010W\u001a\u00020\u00002\u0006\u0010\u0019\u001a\u00020\t2\u0006\u0010X\u001a\u00020\u0007J\u0016\u0010Y\u001a\u00020\u00002\u0006\u0010\u0019\u001a\u00020\t2\u0006\u0010\u001c\u001a\u00020\tJ\u0016\u0010Z\u001a\u00020\u00002\u0006\u0010\u0019\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\tJ\u0016\u0010[\u001a\u00020\u00002\u0006\u0010\u0019\u001a\u00020\t2\u0006\u0010\u001b\u001a\u00020\tJ\u000e\u0010\\\u001a\u00020\u00002\u0006\u0010\u0006\u001a\u00020\u0007R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006]"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/gui/Gui;", "Lnet/minecraft/client/gui/GuiScreen;", "()V", "buttons", "", "Lnet/minecraft/client/gui/GuiButton;", "doesPauseGame", "", "mouseX", "", "mouseY", "onActionPerformed", "Lcom/chattriggers/ctjs/triggers/RegularTrigger;", "onClick", "onClosed", "onDraw", "onKeyTyped", "onMouseDragged", "onMouseReleased", "onOpened", "onScroll", "actionPerformed", "", "button", "addButton", "buttonId", "x", "y", "width", "height", "buttonText", "", "clearButtons", "close", "doesGuiPauseGame", "drawCreativeTabHoveringString", "text", "drawHoveringString", "", "drawScreen", "partialTicks", "", "drawString", "color", "getButton", "getButtonEnabled", "getButtonHeight", "getButtonVisibility", "getButtonWidth", "getButtonX", "getButtonY", "getLoader", "Lcom/chattriggers/ctjs/engine/ILoader;", "getLoader$ctjs", "initGui", "isAltDown", "isControlDown", "isOpen", "isShiftDown", "keyTyped", "typedChar", "", "keyCode", "mouseClickMove", "clickedMouseButton", "timeSinceLastClick", "", "mouseClicked", "mouseReleased", "onGuiClosed", "open", "registerActionPerformed", "method", "", "registerClicked", "registerClosed", "registerDraw", "registerKeyTyped", "registerMouseDragged", "registerMouseReleased", "registerOpened", "registerScrolled", "removeButton", "setButtonEnabled", "enabled", "setButtonHeight", "setButtonLoc", "setButtonVisibility", "visible", "setButtonWidth", "setButtonX", "setButtonY", "setDoesPauseGame", "ctjs"}
)
public abstract class Gui extends GuiScreen {
   @Nullable
   private RegularTrigger onDraw;
   @Nullable
   private RegularTrigger onClick;
   @Nullable
   private RegularTrigger onScroll;
   @Nullable
   private RegularTrigger onKeyTyped;
   @Nullable
   private RegularTrigger onMouseReleased;
   @Nullable
   private RegularTrigger onMouseDragged;
   @Nullable
   private RegularTrigger onActionPerformed;
   @Nullable
   private RegularTrigger onOpened;
   @Nullable
   private RegularTrigger onClosed;
   private int mouseX;
   private int mouseY;
   @NotNull
   private final List<GuiButton> buttons = (List)(new ArrayList());
   private boolean doesPauseGame;

   public Gui() {
      this.field_146297_k = Client.Companion.getMinecraft();
      MouseListener.INSTANCE.registerScrollListener((Function3)(new Function3<Double, Double, Integer, Unit>() {
         public final void invoke(double x, double y, int delta) {
            if (Gui.this.isOpen()) {
               RegularTrigger var10000 = Gui.this.onScroll;
               if (var10000 != null) {
                  Object[] var6 = new Object[]{x, y, delta};
                  var10000.trigger(var6);
               }
            }

         }
      }));
   }

   public final void open() {
      GuiHandler.INSTANCE.openGui((GuiScreen)this);
      RegularTrigger var10000 = this.onOpened;
      if (var10000 != null) {
         Gui[] var1 = new Gui[]{this};
         var10000.trigger(var1);
      }

   }

   public final void close() {
      if (this.isOpen()) {
         EntityPlayerSP var10000 = Player.getPlayer();
         if (var10000 != null) {
            var10000.func_71053_j();
         }
      }

   }

   public final boolean isOpen() {
      return Client.Companion.getMinecraft().field_71462_r == this;
   }

   public final boolean isControlDown() {
      return GuiScreen.func_146271_m();
   }

   public final boolean isShiftDown() {
      return GuiScreen.func_146272_n();
   }

   public final boolean isAltDown() {
      return GuiScreen.func_175283_s();
   }

   @Nullable
   public final RegularTrigger registerDraw(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      Gui $this$registerDraw_u24lambda_u2d0 = (Gui)this;
      int var3 = false;
      $this$registerDraw_u24lambda_u2d0.onDraw = new RegularTrigger(method, TriggerType.Other, $this$registerDraw_u24lambda_u2d0.getLoader$ctjs());
      return $this$registerDraw_u24lambda_u2d0.onDraw;
   }

   @Nullable
   public final RegularTrigger registerClicked(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      Gui $this$registerClicked_u24lambda_u2d1 = (Gui)this;
      int var3 = false;
      $this$registerClicked_u24lambda_u2d1.onClick = new RegularTrigger(method, TriggerType.Other, $this$registerClicked_u24lambda_u2d1.getLoader$ctjs());
      return $this$registerClicked_u24lambda_u2d1.onClick;
   }

   @Nullable
   public final RegularTrigger registerScrolled(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      Gui $this$registerScrolled_u24lambda_u2d2 = (Gui)this;
      int var3 = false;
      $this$registerScrolled_u24lambda_u2d2.onScroll = new RegularTrigger(method, TriggerType.Other, $this$registerScrolled_u24lambda_u2d2.getLoader$ctjs());
      return $this$registerScrolled_u24lambda_u2d2.onScroll;
   }

   @Nullable
   public final RegularTrigger registerKeyTyped(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      Gui $this$registerKeyTyped_u24lambda_u2d3 = (Gui)this;
      int var3 = false;
      $this$registerKeyTyped_u24lambda_u2d3.onKeyTyped = new RegularTrigger(method, TriggerType.Other, $this$registerKeyTyped_u24lambda_u2d3.getLoader$ctjs());
      return $this$registerKeyTyped_u24lambda_u2d3.onKeyTyped;
   }

   @Nullable
   public final RegularTrigger registerMouseDragged(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      Gui $this$registerMouseDragged_u24lambda_u2d4 = (Gui)this;
      int var3 = false;
      $this$registerMouseDragged_u24lambda_u2d4.onMouseDragged = new RegularTrigger(method, TriggerType.Other, $this$registerMouseDragged_u24lambda_u2d4.getLoader$ctjs());
      return $this$registerMouseDragged_u24lambda_u2d4.onMouseDragged;
   }

   @Nullable
   public final RegularTrigger registerMouseReleased(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      Gui $this$registerMouseReleased_u24lambda_u2d5 = (Gui)this;
      int var3 = false;
      $this$registerMouseReleased_u24lambda_u2d5.onMouseReleased = new RegularTrigger(method, TriggerType.Other, $this$registerMouseReleased_u24lambda_u2d5.getLoader$ctjs());
      return $this$registerMouseReleased_u24lambda_u2d5.onMouseReleased;
   }

   @Nullable
   public final RegularTrigger registerActionPerformed(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      Gui $this$registerActionPerformed_u24lambda_u2d6 = (Gui)this;
      int var3 = false;
      $this$registerActionPerformed_u24lambda_u2d6.onActionPerformed = new RegularTrigger(method, TriggerType.Other, $this$registerActionPerformed_u24lambda_u2d6.getLoader$ctjs());
      return $this$registerActionPerformed_u24lambda_u2d6.onActionPerformed;
   }

   @Nullable
   public final RegularTrigger registerOpened(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      Gui $this$registerOpened_u24lambda_u2d7 = (Gui)this;
      int var3 = false;
      $this$registerOpened_u24lambda_u2d7.onOpened = new RegularTrigger(method, TriggerType.Other, $this$registerOpened_u24lambda_u2d7.getLoader$ctjs());
      return $this$registerOpened_u24lambda_u2d7.onOpened;
   }

   @Nullable
   public final RegularTrigger registerClosed(@NotNull Object method) {
      Intrinsics.checkNotNullParameter(method, "method");
      Gui $this$registerClosed_u24lambda_u2d8 = (Gui)this;
      int var3 = false;
      $this$registerClosed_u24lambda_u2d8.onClosed = new RegularTrigger(method, TriggerType.Other, $this$registerClosed_u24lambda_u2d8.getLoader$ctjs());
      return $this$registerClosed_u24lambda_u2d8.onClosed;
   }

   public void func_146281_b() {
      super.func_146281_b();
      RegularTrigger var10000 = this.onClosed;
      if (var10000 != null) {
         Gui[] var1 = new Gui[]{this};
         var10000.trigger(var1);
      }

   }

   protected void func_73864_a(int mouseX, int mouseY, int button) {
      super.func_73864_a(mouseX, mouseY, button);
      RegularTrigger var10000 = this.onClick;
      if (var10000 != null) {
         Integer[] var4 = new Integer[]{mouseX, mouseY, button};
         var10000.trigger(var4);
      }

   }

   protected void func_146286_b(int mouseX, int mouseY, int button) {
      super.func_146286_b(mouseX, mouseY, button);
      RegularTrigger var10000 = this.onMouseReleased;
      if (var10000 != null) {
         Integer[] var4 = new Integer[]{mouseX, mouseY, button};
         var10000.trigger(var4);
      }

   }

   protected void func_146284_a(@NotNull GuiButton button) {
      Intrinsics.checkNotNullParameter(button, "button");
      super.func_146284_a(button);
      RegularTrigger var10000 = this.onActionPerformed;
      if (var10000 != null) {
         Integer[] var2 = new Integer[]{button.field_146127_k};
         var10000.trigger(var2);
      }

   }

   protected void func_146273_a(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
      super.func_146273_a(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);
      RegularTrigger var10000 = this.onMouseDragged;
      if (var10000 != null) {
         Object[] var6 = new Object[]{mouseX, mouseY, clickedMouseButton, timeSinceLastClick};
         var10000.trigger(var6);
      }

   }

   public void func_73866_w_() {
      super.func_73866_w_();
      this.field_146292_n.addAll((Collection)this.buttons);
   }

   public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
      super.func_73863_a(mouseX, mouseY, partialTicks);
      GlStateManager.func_179094_E();
      this.mouseX = mouseX;
      this.mouseY = mouseY;
      RegularTrigger var10000 = this.onDraw;
      if (var10000 != null) {
         Object[] var4 = new Object[]{mouseX, mouseY, partialTicks};
         var10000.trigger(var4);
      }

      GlStateManager.func_179121_F();
   }

   protected void func_73869_a(char typedChar, int keyCode) {
      super.func_73869_a(typedChar, keyCode);
      RegularTrigger var10000 = this.onKeyTyped;
      if (var10000 != null) {
         Object[] var3 = new Object[]{typedChar, keyCode};
         var10000.trigger(var3);
      }

   }

   public boolean func_73868_f() {
      return this.doesPauseGame;
   }

   @NotNull
   public final Gui setDoesPauseGame(boolean doesPauseGame) {
      Gui $this$setDoesPauseGame_u24lambda_u2d9 = (Gui)this;
      int var4 = false;
      $this$setDoesPauseGame_u24lambda_u2d9.doesPauseGame = doesPauseGame;
      return (Gui)this;
   }

   @NotNull
   public final Gui addButton(@NotNull GuiButton button) {
      Intrinsics.checkNotNullParameter(button, "button");
      Gui $this$addButton_u24lambda_u2d10 = (Gui)this;
      int var4 = false;
      $this$addButton_u24lambda_u2d10.buttons.add(button);
      $this$addButton_u24lambda_u2d10.func_175273_b($this$addButton_u24lambda_u2d10.field_146297_k, $this$addButton_u24lambda_u2d10.field_146294_l, $this$addButton_u24lambda_u2d10.field_146295_m);
      return (Gui)this;
   }

   @JvmOverloads
   @NotNull
   public final Gui addButton(int buttonId, int x, int y, int width, int height, @NotNull String buttonText) {
      Intrinsics.checkNotNullParameter(buttonText, "buttonText");
      Gui $this$addButton_u24lambda_u2d11 = (Gui)this;
      int var9 = false;
      $this$addButton_u24lambda_u2d11.addButton(new GuiButton(buttonId, x, y, width, height, buttonText));
      return (Gui)this;
   }

   // $FF: synthetic method
   public static Gui addButton$default(Gui var0, int var1, int var2, int var3, int var4, int var5, String var6, int var7, Object var8) {
      if (var8 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: addButton");
      } else {
         if ((var7 & 8) != 0) {
            var4 = 200;
         }

         if ((var7 & 16) != 0) {
            var5 = 20;
         }

         return var0.addButton(var1, var2, var3, var4, var5, var6);
      }
   }

   @NotNull
   public final Gui removeButton(int buttonId) {
      Gui $this$removeButton_u24lambda_u2d13 = (Gui)this;
      int var4 = false;
      $this$removeButton_u24lambda_u2d13.buttons.removeIf(Gui::removeButton$lambda-13$lambda-12);
      $this$removeButton_u24lambda_u2d13.func_175273_b($this$removeButton_u24lambda_u2d13.field_146297_k, $this$removeButton_u24lambda_u2d13.field_146294_l, $this$removeButton_u24lambda_u2d13.field_146295_m);
      return (Gui)this;
   }

   @NotNull
   public final Gui clearButtons() {
      Gui $this$clearButtons_u24lambda_u2d14 = (Gui)this;
      int var3 = false;
      $this$clearButtons_u24lambda_u2d14.buttons.clear();
      $this$clearButtons_u24lambda_u2d14.func_175273_b($this$clearButtons_u24lambda_u2d14.field_146297_k, $this$clearButtons_u24lambda_u2d14.field_146294_l, $this$clearButtons_u24lambda_u2d14.field_146295_m);
      return (Gui)this;
   }

   @Nullable
   public final GuiButton getButton(int buttonId) {
      Iterable $this$firstOrNull$iv = (Iterable)this.buttons;
      int $i$f$firstOrNull = false;
      Iterator var4 = $this$firstOrNull$iv.iterator();

      Object var10000;
      while(true) {
         if (var4.hasNext()) {
            Object element$iv = var4.next();
            GuiButton it = (GuiButton)element$iv;
            int var7 = false;
            if (it.field_146127_k != buttonId) {
               continue;
            }

            var10000 = element$iv;
            break;
         }

         var10000 = null;
         break;
      }

      return (GuiButton)var10000;
   }

   public final boolean getButtonVisibility(int buttonId) {
      GuiButton var10000 = this.getButton(buttonId);
      boolean var3;
      if (var10000 == null) {
         var3 = false;
      } else {
         boolean var2 = var10000.field_146125_m;
         var3 = var2;
      }

      return var3;
   }

   @NotNull
   public final Gui setButtonVisibility(int buttonId, boolean visible) {
      Gui $this$setButtonVisibility_u24lambda_u2d16 = (Gui)this;
      int var5 = false;
      GuiButton var10000 = $this$setButtonVisibility_u24lambda_u2d16.getButton(buttonId);
      if (var10000 != null) {
         var10000.field_146125_m = visible;
      }

      return (Gui)this;
   }

   public final boolean getButtonEnabled(int buttonId) {
      GuiButton var10000 = this.getButton(buttonId);
      boolean var3;
      if (var10000 == null) {
         var3 = false;
      } else {
         boolean var2 = var10000.field_146124_l;
         var3 = var2;
      }

      return var3;
   }

   @NotNull
   public final Gui setButtonEnabled(int buttonId, boolean enabled) {
      Gui $this$setButtonEnabled_u24lambda_u2d17 = (Gui)this;
      int var5 = false;
      GuiButton var10000 = $this$setButtonEnabled_u24lambda_u2d17.getButton(buttonId);
      if (var10000 != null) {
         var10000.field_146124_l = enabled;
      }

      return (Gui)this;
   }

   public final int getButtonWidth(int buttonId) {
      GuiButton var10000 = this.getButton(buttonId);
      int var3;
      if (var10000 == null) {
         var3 = 0;
      } else {
         int var2 = var10000.field_146120_f;
         var3 = var2;
      }

      return var3;
   }

   @NotNull
   public final Gui setButtonWidth(int buttonId, int width) {
      Gui $this$setButtonWidth_u24lambda_u2d18 = (Gui)this;
      int var5 = false;
      GuiButton var10000 = $this$setButtonWidth_u24lambda_u2d18.getButton(buttonId);
      if (var10000 != null) {
         var10000.field_146120_f = width;
      }

      return (Gui)this;
   }

   public final int getButtonHeight(int buttonId) {
      GuiButton var10000 = this.getButton(buttonId);
      int var3;
      if (var10000 == null) {
         var3 = 0;
      } else {
         int var2 = var10000.field_146121_g;
         var3 = var2;
      }

      return var3;
   }

   @NotNull
   public final Gui setButtonHeight(int buttonId, int height) {
      Gui $this$setButtonHeight_u24lambda_u2d19 = (Gui)this;
      int var5 = false;
      GuiButton var10000 = $this$setButtonHeight_u24lambda_u2d19.getButton(buttonId);
      if (var10000 != null) {
         var10000.field_146121_g = height;
      }

      return (Gui)this;
   }

   public final int getButtonX(int buttonId) {
      GuiButton var10000 = this.getButton(buttonId);
      int var3;
      if (var10000 == null) {
         var3 = 0;
      } else {
         int var2 = var10000.field_146128_h;
         var3 = var2;
      }

      return var3;
   }

   @NotNull
   public final Gui setButtonX(int buttonId, int x) {
      Gui $this$setButtonX_u24lambda_u2d20 = (Gui)this;
      int var5 = false;
      GuiButton var10000 = $this$setButtonX_u24lambda_u2d20.getButton(buttonId);
      if (var10000 != null) {
         var10000.field_146128_h = x;
      }

      return (Gui)this;
   }

   public final int getButtonY(int buttonId) {
      GuiButton var10000 = this.getButton(buttonId);
      int var3;
      if (var10000 == null) {
         var3 = 0;
      } else {
         int var2 = var10000.field_146129_i;
         var3 = var2;
      }

      return var3;
   }

   @NotNull
   public final Gui setButtonY(int buttonId, int y) {
      Gui $this$setButtonY_u24lambda_u2d21 = (Gui)this;
      int var5 = false;
      GuiButton var10000 = $this$setButtonY_u24lambda_u2d21.getButton(buttonId);
      if (var10000 != null) {
         var10000.field_146129_i = y;
      }

      return (Gui)this;
   }

   @NotNull
   public final Gui setButtonLoc(int buttonId, int x, int y) {
      Gui $this$setButtonLoc_u24lambda_u2d23 = (Gui)this;
      int var6 = false;
      GuiButton var10000 = $this$setButtonLoc_u24lambda_u2d23.getButton(buttonId);
      if (var10000 != null) {
         GuiButton var7 = var10000;
         int var9 = false;
         var7.field_146128_h = x;
         var7.field_146129_i = y;
      }

      return (Gui)this;
   }

   public final void drawString(@NotNull String text, int x, int y, int color) {
      Intrinsics.checkNotNullParameter(text, "text");
      this.func_73731_b(this.field_146297_k.field_71466_p, text, x, y, color);
   }

   public final void drawCreativeTabHoveringString(@NotNull String text, int mouseX, int mouseY) {
      Intrinsics.checkNotNullParameter(text, "text");
      this.func_146279_a(text, mouseX, mouseY);
   }

   public final void drawHoveringString(@NotNull List<String> text, int x, int y) {
      Intrinsics.checkNotNullParameter(text, "text");
      this.drawHoveringText(text, x, y, this.field_146297_k.field_71466_p);
   }

   @NotNull
   public abstract ILoader getLoader$ctjs();

   @JvmOverloads
   @NotNull
   public final Gui addButton(int buttonId, int x, int y, int width, @NotNull String buttonText) {
      Intrinsics.checkNotNullParameter(buttonText, "buttonText");
      return addButton$default(this, buttonId, x, y, width, 0, buttonText, 16, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final Gui addButton(int buttonId, int x, int y, @NotNull String buttonText) {
      Intrinsics.checkNotNullParameter(buttonText, "buttonText");
      return addButton$default(this, buttonId, x, y, 0, 0, buttonText, 24, (Object)null);
   }

   private static final boolean removeButton$lambda_13$lambda_12/* $FF was: removeButton$lambda-13$lambda-12*/(int $buttonId, GuiButton it) {
      Intrinsics.checkNotNullParameter(it, "it");
      return it.field_146127_k == $buttonId;
   }
}
