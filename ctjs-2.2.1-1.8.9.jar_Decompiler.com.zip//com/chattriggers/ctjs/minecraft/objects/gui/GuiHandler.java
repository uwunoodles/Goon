package com.chattriggers.ctjs.minecraft.objects.gui;

import com.chattriggers.ctjs.minecraft.wrappers.Client;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0007J\u000e\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u0004R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u000b"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/objects/gui/GuiHandler;", "", "()V", "pendingGui", "Lnet/minecraft/client/gui/GuiScreen;", "onTick", "", "event", "Lnet/minecraftforge/fml/common/gameevent/TickEvent$ClientTickEvent;", "openGui", "gui", "ctjs"}
)
public final class GuiHandler {
   @NotNull
   public static final GuiHandler INSTANCE = new GuiHandler();
   @Nullable
   private static GuiScreen pendingGui;

   private GuiHandler() {
   }

   public final void openGui(@NotNull GuiScreen gui) {
      Intrinsics.checkNotNullParameter(gui, "gui");
      pendingGui = gui;
   }

   @SubscribeEvent
   public final void onTick(@NotNull ClientTickEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      if (event.phase != Phase.END) {
         if (pendingGui != null) {
            Minecraft var10000 = Client.Companion.getMinecraft();
            GuiScreen var10001 = pendingGui;
            Intrinsics.checkNotNull(var10001);
            var10000.func_147108_a(var10001);
            pendingGui = null;
         }

      }
   }
}
