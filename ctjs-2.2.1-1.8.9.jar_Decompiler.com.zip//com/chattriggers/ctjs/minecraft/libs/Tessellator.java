package com.chattriggers.ctjs.minecraft.libs;

import com.chattriggers.ctjs.minecraft.libs.renderer.Image;
import com.chattriggers.ctjs.minecraft.libs.renderer.Renderer;
import com.chattriggers.ctjs.minecraft.wrappers.Player;
import com.chattriggers.ctjs.utils.kotlin.ExtensionsKt;
import kotlin.Metadata;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.util.vector.Vector3f;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\r\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0016\u001a\u00020\u00002\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u0007H\u0007J\u001c\u0010\u001a\u001a\u00020\u00002\b\b\u0002\u0010\u001b\u001a\u00020\u00182\b\b\u0002\u0010\u001c\u001a\u00020\u0004H\u0007J\u0010\u0010\u001d\u001a\u00020\u00002\u0006\u0010\u001e\u001a\u00020\u001fH\u0007J\u0018\u0010 \u001a\u00020\u00002\u0006\u0010!\u001a\u00020\u00182\u0006\u0010\"\u001a\u00020\u0018H\u0007J*\u0010#\u001a\u00020\u00002\u0006\u0010$\u001a\u00020\u00072\u0006\u0010%\u001a\u00020\u00072\u0006\u0010&\u001a\u00020\u00072\b\b\u0002\u0010'\u001a\u00020\u0007H\u0007J\u0010\u0010(\u001a\u00020\u00002\u0006\u0010\u001e\u001a\u00020\u001fH\u0007J\u0010\u0010)\u001a\u00020\u00002\u0006\u0010)\u001a\u00020\u0018H\u0007J\u0010\u0010*\u001a\u00020\u00002\u0006\u0010+\u001a\u00020\u0004H\u0007J\b\u0010,\u001a\u00020\u0000H\u0007J\b\u0010-\u001a\u00020\u0000H\u0007J\b\u0010.\u001a\u00020\u0000H\u0007J\b\u0010/\u001a\u00020\u0000H\u0007J\b\u00100\u001a\u00020\u0000H\u0007J\b\u00101\u001a\u000202H\u0007JP\u00103\u001a\u0002022\u0006\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\u00072\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u00072\b\b\u0002\u00109\u001a\u00020\u00182\b\b\u0002\u0010:\u001a\u00020\u00042\b\b\u0002\u0010;\u001a\u00020\u00072\b\b\u0002\u0010<\u001a\u00020\u0004H\u0007J\b\u0010=\u001a\u00020\u0000H\u0007J\b\u0010>\u001a\u00020\u0000H\u0007J\b\u0010?\u001a\u00020\u0000H\u0007J\b\u0010@\u001a\u00020\u0000H\u0007J\b\u0010A\u001a\u00020\u0000H\u0007J \u0010B\u001a\u00020C2\u0006\u00106\u001a\u00020\u00072\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u0007H\u0007J\b\u0010D\u001a\u00020\u0000H\u0007J \u0010E\u001a\u00020\u00002\u0006\u00106\u001a\u00020\u00072\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u0007H\u0007J\b\u0010F\u001a\u00020\u0000H\u0007J(\u0010G\u001a\u00020\u00002\u0006\u0010H\u001a\u00020\u00072\u0006\u00106\u001a\u00020\u00072\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u0007H\u0007J$\u0010;\u001a\u00020\u00002\u0006\u00106\u001a\u00020\u00072\b\b\u0002\u00107\u001a\u00020\u00072\b\b\u0002\u00108\u001a\u00020\u0007H\u0007J\u0018\u0010I\u001a\u00020\u00002\u0006\u0010J\u001a\u00020\u00072\u0006\u0010K\u001a\u00020\u0007H\u0007J \u0010L\u001a\u00020\u00002\u0006\u00106\u001a\u00020\u00072\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u0007H\u0007J(\u0010M\u001a\u00020\u00002\u0006\u0010!\u001a\u00020\u00182\u0006\u0010\"\u001a\u00020\u00182\u0006\u0010N\u001a\u00020\u00182\u0006\u0010O\u001a\u00020\u0018H\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R,\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u00078\u0006@@X\u0087\u000e¢\u0006\u0014\n\u0000\u0012\u0004\b\t\u0010\u0002\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0010\u001a\n \u0012*\u0004\u0018\u00010\u00110\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0013\u001a\u00060\u0014j\u0002`\u0015X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006P"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/libs/Tessellator;", "", "()V", "began", "", "firstVertex", "<set-?>", "", "partialTicks", "getPartialTicks$annotations", "getPartialTicks", "()F", "setPartialTicks$ctjs", "(F)V", "renderManager", "Lnet/minecraft/client/renderer/entity/RenderManager;", "tessellator", "Lnet/minecraft/client/renderer/Tessellator;", "kotlin.jvm.PlatformType", "worldRenderer", "Lnet/minecraft/client/renderer/WorldRenderer;", "Lcom/chattriggers/ctjs/utils/kotlin/MCWorldRenderer;", "alphaFunc", "func", "", "ref", "begin", "drawMode", "textured", "bindTexture", "texture", "Lcom/chattriggers/ctjs/minecraft/libs/renderer/Image;", "blendFunc", "sourceFactor", "destFactor", "colorize", "red", "green", "blue", "alpha", "deleteTexture", "depthFunc", "depthMask", "flagIn", "disableAlpha", "disableBlend", "disableDepth", "disableLighting", "disableTexture2D", "draw", "", "drawString", "text", "", "x", "y", "z", "color", "renderBlackBox", "scale", "increase", "enableAlpha", "enableBlend", "enableDepth", "enableLighting", "enableTexture2D", "getRenderPos", "Lorg/lwjgl/util/vector/Vector3f;", "popMatrix", "pos", "pushMatrix", "rotate", "angle", "tex", "u", "v", "translate", "tryBlendFuncSeparate", "sourceFactorAlpha", "destFactorAlpha", "ctjs"}
)
public final class Tessellator {
   @NotNull
   public static final Tessellator INSTANCE = new Tessellator();
   private static float partialTicks;
   private static net.minecraft.client.renderer.Tessellator tessellator = net.minecraft.client.renderer.Tessellator.func_178181_a();
   @NotNull
   private static WorldRenderer worldRenderer;
   @NotNull
   private static final RenderManager renderManager;
   private static boolean firstVertex;
   private static boolean began;

   private Tessellator() {
   }

   public static final float getPartialTicks() {
      return partialTicks;
   }

   public static final void setPartialTicks$ctjs(float var0) {
      partialTicks = var0;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getPartialTicks$annotations() {
   }

   @JvmStatic
   @NotNull
   public static final Tessellator disableAlpha() {
      Tessellator var0 = INSTANCE;
      int var2 = false;
      GlStateManager.func_179118_c();
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator enableAlpha() {
      Tessellator var0 = INSTANCE;
      int var2 = false;
      GlStateManager.func_179141_d();
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator alphaFunc(int func, float ref) {
      Tessellator var2 = INSTANCE;
      int var4 = false;
      GlStateManager.func_179092_a(func, ref);
      return var2;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator enableLighting() {
      Tessellator var0 = INSTANCE;
      int var2 = false;
      GlStateManager.func_179145_e();
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator disableLighting() {
      Tessellator var0 = INSTANCE;
      int var2 = false;
      GlStateManager.func_179140_f();
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator disableDepth() {
      Tessellator var0 = INSTANCE;
      int var2 = false;
      GlStateManager.func_179097_i();
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator enableDepth() {
      Tessellator var0 = INSTANCE;
      int var2 = false;
      GlStateManager.func_179126_j();
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator depthFunc(int depthFunc) {
      Tessellator var1 = INSTANCE;
      int var3 = false;
      GlStateManager.func_179143_c(depthFunc);
      return var1;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator depthMask(boolean flagIn) {
      Tessellator var1 = INSTANCE;
      int var3 = false;
      GlStateManager.func_179132_a(flagIn);
      return var1;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator disableBlend() {
      Tessellator var0 = INSTANCE;
      int var2 = false;
      GlStateManager.func_179084_k();
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator enableBlend() {
      Tessellator var0 = INSTANCE;
      int var2 = false;
      GlStateManager.func_179147_l();
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator blendFunc(int sourceFactor, int destFactor) {
      Tessellator var2 = INSTANCE;
      int var4 = false;
      GlStateManager.func_179112_b(sourceFactor, destFactor);
      return var2;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator tryBlendFuncSeparate(int sourceFactor, int destFactor, int sourceFactorAlpha, int destFactorAlpha) {
      Tessellator var4 = INSTANCE;
      int var6 = false;
      GlStateManager.func_179120_a(sourceFactor, destFactor, sourceFactorAlpha, destFactorAlpha);
      return var4;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator enableTexture2D() {
      Tessellator var0 = INSTANCE;
      int var2 = false;
      GlStateManager.func_179098_w();
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator disableTexture2D() {
      Tessellator var0 = INSTANCE;
      int var2 = false;
      GlStateManager.func_179090_x();
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator bindTexture(@NotNull Image texture) {
      Intrinsics.checkNotNullParameter(texture, "texture");
      Tessellator var1 = INSTANCE;
      int var3 = false;
      GlStateManager.func_179144_i(texture.getTexture().func_110552_b());
      return var1;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator deleteTexture(@NotNull Image texture) {
      Intrinsics.checkNotNullParameter(texture, "texture");
      Tessellator var1 = INSTANCE;
      int var3 = false;
      GlStateManager.func_179150_h(texture.getTexture().func_110552_b());
      return var1;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator pushMatrix() {
      Tessellator var0 = INSTANCE;
      int var2 = false;
      GlStateManager.func_179094_E();
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator popMatrix() {
      Tessellator var0 = INSTANCE;
      int var2 = false;
      GlStateManager.func_179121_F();
      return var0;
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Tessellator begin(int drawMode, boolean textured) {
      Tessellator var2 = INSTANCE;
      int var4 = false;
      pushMatrix();
      enableBlend();
      tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.func_179137_b(-renderManager.field_78730_l, -renderManager.field_78731_m, -renderManager.field_78728_n);
      worldRenderer.func_181668_a(drawMode, textured ? DefaultVertexFormats.field_181707_g : DefaultVertexFormats.field_181705_e);
      firstVertex = true;
      began = true;
      return var2;
   }

   // $FF: synthetic method
   public static Tessellator begin$default(int var0, boolean var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var0 = 7;
      }

      if ((var2 & 2) != 0) {
         var1 = true;
      }

      return begin(var0, var1);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Tessellator colorize(float red, float green, float blue, float alpha) {
      Tessellator var4 = INSTANCE;
      int var6 = false;
      GlStateManager.func_179131_c(red, green, blue, alpha);
      return var4;
   }

   // $FF: synthetic method
   public static Tessellator colorize$default(float var0, float var1, float var2, float var3, int var4, Object var5) {
      if ((var4 & 8) != 0) {
         var3 = 1.0F;
      }

      return colorize(var0, var1, var2, var3);
   }

   @JvmStatic
   @NotNull
   public static final Tessellator rotate(float angle, float x, float y, float z) {
      Tessellator var4 = INSTANCE;
      int var6 = false;
      GlStateManager.func_179114_b(angle, x, y, z);
      return var4;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator translate(float x, float y, float z) {
      Tessellator var3 = INSTANCE;
      int var5 = false;
      GlStateManager.func_179109_b(x, y, z);
      return var3;
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Tessellator scale(float x, float y, float z) {
      Tessellator var3 = INSTANCE;
      int var5 = false;
      GlStateManager.func_179152_a(x, y, z);
      return var3;
   }

   // $FF: synthetic method
   public static Tessellator scale$default(float var0, float var1, float var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var1 = var0;
      }

      if ((var3 & 4) != 0) {
         var2 = var0;
      }

      return scale(var0, var1, var2);
   }

   @JvmStatic
   @NotNull
   public static final Tessellator pos(float x, float y, float z) {
      Tessellator var3 = INSTANCE;
      int var5 = false;
      if (!began) {
         begin$default(0, false, 3, (Object)null);
      }

      if (!firstVertex) {
         worldRenderer.func_181675_d();
      }

      worldRenderer.func_181662_b((double)x, (double)y, (double)z);
      firstVertex = false;
      return var3;
   }

   @JvmStatic
   @NotNull
   public static final Tessellator tex(float u, float v) {
      Tessellator var2 = INSTANCE;
      int var4 = false;
      worldRenderer.func_181673_a((double)u, (double)v);
      return var2;
   }

   @JvmStatic
   public static final void draw() {
      if (began) {
         worldRenderer.func_181675_d();
         tessellator.func_78381_a();
         Tessellator var10000 = INSTANCE;
         colorize(1.0F, 1.0F, 1.0F, 1.0F);
         var10000 = INSTANCE;
         began = false;
         var10000 = INSTANCE;
         disableBlend();
         var10000 = INSTANCE;
         popMatrix();
      }
   }

   @JvmStatic
   @NotNull
   public static final Vector3f getRenderPos(float x, float y, float z) {
      return new Vector3f(x - (float)Player.getRenderX(), y - (float)Player.getRenderY(), z - (float)Player.getRenderZ());
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawString(@NotNull String text, float x, float y, float z, int color, boolean renderBlackBox, float scale, boolean increase) {
      Intrinsics.checkNotNullParameter(text, "text");
      float lScale = scale;
      FontRenderer fontRenderer = Renderer.getFontRenderer();
      Tessellator var10000 = INSTANCE;
      Vector3f renderPos = getRenderPos(x, y, z);
      if (increase) {
         float distance = (float)Math.sqrt((double)(renderPos.x * renderPos.x + renderPos.y * renderPos.y + renderPos.z * renderPos.z));
         float multiplier = distance / 120.0F;
         lScale = scale * 0.45F * multiplier;
      }

      int xMultiplier = Minecraft.func_71410_x().field_71474_y.field_74320_O == 2 ? -1 : 1;
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 0.5F);
      var10000 = INSTANCE;
      pushMatrix();
      var10000 = INSTANCE;
      translate(renderPos.x, renderPos.y, renderPos.z);
      var10000 = INSTANCE;
      rotate(-renderManager.field_78735_i, 0.0F, 1.0F, 0.0F);
      var10000 = INSTANCE;
      rotate(renderManager.field_78732_j * (float)xMultiplier, 1.0F, 0.0F, 0.0F);
      var10000 = INSTANCE;
      scale(-lScale, -lScale, lScale);
      var10000 = INSTANCE;
      disableLighting();
      var10000 = INSTANCE;
      depthMask(false);
      var10000 = INSTANCE;
      disableDepth();
      var10000 = INSTANCE;
      enableBlend();
      var10000 = INSTANCE;
      blendFunc(770, 771);
      int textWidth = fontRenderer.func_78256_a(text);
      if (renderBlackBox) {
         int j = textWidth / 2;
         var10000 = INSTANCE;
         disableTexture2D();
         worldRenderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
         worldRenderer.func_181662_b((double)(-j - 1), -1.0D, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
         worldRenderer.func_181662_b((double)(-j - 1), 8.0D, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
         worldRenderer.func_181662_b((double)(j + 1), 8.0D, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
         worldRenderer.func_181662_b((double)(j + 1), -1.0D, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
         tessellator.func_78381_a();
         var10000 = INSTANCE;
         enableTexture2D();
      }

      fontRenderer.func_78276_b(text, -textWidth / 2, 0, color);
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      var10000 = INSTANCE;
      depthMask(true);
      var10000 = INSTANCE;
      enableDepth();
      var10000 = INSTANCE;
      popMatrix();
   }

   // $FF: synthetic method
   public static void drawString$default(String var0, float var1, float var2, float var3, int var4, boolean var5, float var6, boolean var7, int var8, Object var9) {
      if ((var8 & 16) != 0) {
         var4 = -1;
      }

      if ((var8 & 32) != 0) {
         var5 = true;
      }

      if ((var8 & 64) != 0) {
         var6 = 1.0F;
      }

      if ((var8 & 128) != 0) {
         var7 = true;
      }

      drawString(var0, var1, var2, var3, var4, var5, var6, var7);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Tessellator begin(int drawMode) {
      return begin$default(drawMode, false, 2, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Tessellator begin() {
      return begin$default(0, false, 3, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Tessellator colorize(float red, float green, float blue) {
      return colorize$default(red, green, blue, 0.0F, 8, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Tessellator scale(float x, float y) {
      return scale$default(x, y, 0.0F, 4, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Tessellator scale(float x) {
      return scale$default(x, 0.0F, 0.0F, 6, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawString(@NotNull String text, float x, float y, float z, int color, boolean renderBlackBox, float scale) {
      Intrinsics.checkNotNullParameter(text, "text");
      drawString$default(text, x, y, z, color, renderBlackBox, scale, false, 128, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawString(@NotNull String text, float x, float y, float z, int color, boolean renderBlackBox) {
      Intrinsics.checkNotNullParameter(text, "text");
      drawString$default(text, x, y, z, color, renderBlackBox, 0.0F, false, 192, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawString(@NotNull String text, float x, float y, float z, int color) {
      Intrinsics.checkNotNullParameter(text, "text");
      drawString$default(text, x, y, z, color, false, 0.0F, false, 224, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawString(@NotNull String text, float x, float y, float z) {
      Intrinsics.checkNotNullParameter(text, "text");
      drawString$default(text, x, y, z, 0, false, 0.0F, false, 240, (Object)null);
   }

   static {
      net.minecraft.client.renderer.Tessellator var0 = tessellator;
      Intrinsics.checkNotNullExpressionValue(var0, "tessellator");
      worldRenderer = ExtensionsKt.getRenderer(var0);
      renderManager = Renderer.getRenderManager();
      firstVertex = true;
   }
}
