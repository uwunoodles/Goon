package com.chattriggers.ctjs.minecraft.libs;

import com.chattriggers.ctjs.CTJS;
import com.chattriggers.ctjs.utils.Config;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import kotlin.Metadata;
import kotlin.io.ByteStreamsKt;
import kotlin.io.CloseableKt;
import kotlin.io.FilesKt;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000e\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0004H\u0002J\u0018\u0010\u0007\u001a\u00020\b2\u0006\u0010\u0006\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\u0004H\u0007J \u0010\u0007\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\u0004H\u0007J\u0010\u0010\u000b\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\u0004H\u0007J\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0006\u001a\u00020\u0004H\u0007J\u0018\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u0004H\u0007J\u0010\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u0011H\u0007J\u0010\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u0004H\u0007J\u0010\u0010\u0012\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00020\u0004H\u0007J\u0010\u0010\u0014\u001a\u00020\u000e2\u0006\u0010\u0006\u001a\u00020\u0004H\u0007J\u0018\u0010\u0014\u001a\u00020\u000e2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u0004H\u0007J\u0018\u0010\u0015\u001a\u00020\b2\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u0004H\u0002J\u001c\u0010\u0019\u001a\u00020\u00042\u0006\u0010\u001a\u001a\u00020\u00042\n\b\u0002\u0010\u001b\u001a\u0004\u0018\u00010\u0004H\u0007J\u0010\u0010\u001c\u001a\u00020\u000e2\u0006\u0010\u0006\u001a\u00020\u0004H\u0007J\u0018\u0010\u001c\u001a\u00020\u000e2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u0004H\u0007J\u0012\u0010\u001d\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u001e\u001a\u00020\u0011H\u0007J\u0012\u0010\u001d\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0006\u001a\u00020\u0004H\u0007J\u001a\u0010\u001d\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u0004H\u0007J\u0018\u0010\u001f\u001a\u00020\b2\u0006\u0010 \u001a\u00020\u00042\u0006\u0010!\u001a\u00020\u0004H\u0007J\"\u0010\"\u001a\u00020\b2\u0006\u0010\u0006\u001a\u00020\u00042\u0006\u0010#\u001a\u00020\u00042\b\b\u0002\u0010$\u001a\u00020\u000eH\u0007J*\u0010\"\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u00042\u0006\u0010#\u001a\u00020\u00042\b\b\u0002\u0010$\u001a\u00020\u000eH\u0007¨\u0006%"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/libs/FileLib;", "", "()V", "absoluteLocation", "", "importName", "fileLocation", "append", "", "toAppend", "fileName", "decodeBase64", "toDecode", "delete", "", "deleteDirectory", "dir", "Ljava/io/File;", "encodeBase64", "toEncode", "exists", "extractFile", "zipIn", "Ljava/util/zip/ZipInputStream;", "filePath", "getUrlContent", "theUrl", "userAgent", "isDirectory", "read", "file", "unzip", "zipFilePath", "destDirectory", "write", "toWrite", "recursive", "ctjs"}
)
public final class FileLib {
   @NotNull
   public static final FileLib INSTANCE = new FileLib();

   private FileLib() {
   }

   @JvmStatic
   @JvmOverloads
   public static final void write(@NotNull String importName, @NotNull String fileName, @NotNull String toWrite, boolean recursive) {
      Intrinsics.checkNotNullParameter(importName, "importName");
      Intrinsics.checkNotNullParameter(fileName, "fileName");
      Intrinsics.checkNotNullParameter(toWrite, "toWrite");
      FileLib var10000 = INSTANCE;
      write(INSTANCE.absoluteLocation(importName, fileName), toWrite, recursive);
   }

   // $FF: synthetic method
   public static void write$default(String var0, String var1, String var2, boolean var3, int var4, Object var5) {
      if ((var4 & 8) != 0) {
         var3 = false;
      }

      write(var0, var1, var2, var3);
   }

   @JvmStatic
   @JvmOverloads
   public static final void write(@NotNull String fileLocation, @NotNull String toWrite, boolean recursive) {
      Intrinsics.checkNotNullParameter(fileLocation, "fileLocation");
      Intrinsics.checkNotNullParameter(toWrite, "toWrite");
      File var3 = new File(fileLocation);
      int var5 = false;
      if (recursive && !var3.exists()) {
         var3.getParentFile().mkdirs();
      }

      FilesKt.writeText$default(var3, toWrite, (Charset)null, 2, (Object)null);
   }

   // $FF: synthetic method
   public static void write$default(String var0, String var1, boolean var2, int var3, Object var4) {
      if ((var3 & 4) != 0) {
         var2 = false;
      }

      write(var0, var1, var2);
   }

   @JvmStatic
   public static final void append(@NotNull String importName, @NotNull String fileName, @NotNull String toAppend) {
      Intrinsics.checkNotNullParameter(importName, "importName");
      Intrinsics.checkNotNullParameter(fileName, "fileName");
      Intrinsics.checkNotNullParameter(toAppend, "toAppend");
      FileLib var10000 = INSTANCE;
      append(INSTANCE.absoluteLocation(importName, fileName), toAppend);
   }

   @JvmStatic
   public static final void append(@NotNull String fileLocation, @NotNull String toAppend) {
      Intrinsics.checkNotNullParameter(fileLocation, "fileLocation");
      Intrinsics.checkNotNullParameter(toAppend, "toAppend");
      FilesKt.appendText$default(new File(fileLocation), toAppend, (Charset)null, 2, (Object)null);
   }

   @JvmStatic
   @Nullable
   public static final String read(@NotNull String importName, @NotNull String fileName) {
      Intrinsics.checkNotNullParameter(importName, "importName");
      Intrinsics.checkNotNullParameter(fileName, "fileName");
      FileLib var10000 = INSTANCE;
      return read(new File(INSTANCE.absoluteLocation(importName, fileName)));
   }

   @JvmStatic
   @Nullable
   public static final String read(@NotNull String fileLocation) {
      Intrinsics.checkNotNullParameter(fileLocation, "fileLocation");
      FileLib var10000 = INSTANCE;
      return read(new File(fileLocation));
   }

   @JvmStatic
   @Nullable
   public static final String read(@NotNull File file) {
      Intrinsics.checkNotNullParameter(file, "file");

      String var1;
      try {
         var1 = FilesKt.readText$default(file, (Charset)null, 1, (Object)null);
      } catch (Exception var3) {
         var1 = (String)null;
      }

      return var1;
   }

   @JvmStatic
   public static final boolean exists(@NotNull String importName, @NotNull String fileName) {
      Intrinsics.checkNotNullParameter(importName, "importName");
      Intrinsics.checkNotNullParameter(fileName, "fileName");
      FileLib var10000 = INSTANCE;
      return exists(INSTANCE.absoluteLocation(importName, fileName));
   }

   @JvmStatic
   public static final boolean exists(@NotNull String fileLocation) {
      Intrinsics.checkNotNullParameter(fileLocation, "fileLocation");
      return (new File(fileLocation)).exists();
   }

   @JvmStatic
   public static final boolean isDirectory(@NotNull String importName, @NotNull String fileName) {
      Intrinsics.checkNotNullParameter(importName, "importName");
      Intrinsics.checkNotNullParameter(fileName, "fileName");
      FileLib var10000 = INSTANCE;
      return isDirectory(INSTANCE.absoluteLocation(importName, fileName));
   }

   @JvmStatic
   public static final boolean isDirectory(@NotNull String fileLocation) {
      Intrinsics.checkNotNullParameter(fileLocation, "fileLocation");
      return (new File(fileLocation)).isDirectory();
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final String getUrlContent(@NotNull String theUrl, @Nullable String userAgent) throws UnknownHostException {
      Intrinsics.checkNotNullParameter(theUrl, "theUrl");
      URLConnection conn = CTJS.INSTANCE.makeWebRequest(theUrl);
      Closeable var3 = (Closeable)conn.getInputStream();
      Throwable var4 = null;

      byte[] var14;
      try {
         InputStream it = (InputStream)var3;
         int var6 = false;
         Intrinsics.checkNotNullExpressionValue(it, "it");
         var14 = ByteStreamsKt.readBytes(it);
      } catch (Throwable var11) {
         var4 = var11;
         throw var11;
      } finally {
         CloseableKt.closeFinally(var3, var4);
      }

      Charset var13 = Charset.forName("UTF-8");
      Intrinsics.checkNotNullExpressionValue(var13, "forName(\"UTF-8\")");
      return new String(var14, var13);
   }

   // $FF: synthetic method
   public static String getUrlContent$default(String var0, String var1, int var2, Object var3) throws UnknownHostException {
      if ((var2 & 2) != 0) {
         var1 = "Mozilla/5.0";
      }

      return getUrlContent(var0, var1);
   }

   @JvmStatic
   public static final boolean delete(@NotNull String importName, @NotNull String fileName) {
      Intrinsics.checkNotNullParameter(importName, "importName");
      Intrinsics.checkNotNullParameter(fileName, "fileName");
      FileLib var10000 = INSTANCE;
      return delete(INSTANCE.absoluteLocation(importName, fileName));
   }

   @JvmStatic
   public static final boolean delete(@NotNull String fileLocation) {
      Intrinsics.checkNotNullParameter(fileLocation, "fileLocation");
      return (new File(fileLocation)).delete();
   }

   @JvmStatic
   public static final boolean deleteDirectory(@NotNull String dir) {
      Intrinsics.checkNotNullParameter(dir, "dir");
      FileLib var10000 = INSTANCE;
      return deleteDirectory(new File(dir));
   }

   @JvmStatic
   public static final boolean deleteDirectory(@NotNull File dir) {
      Intrinsics.checkNotNullParameter(dir, "dir");
      return FilesKt.deleteRecursively(dir);
   }

   @JvmStatic
   public static final void unzip(@NotNull String zipFilePath, @NotNull String destDirectory) throws IOException {
      Intrinsics.checkNotNullParameter(zipFilePath, "zipFilePath");
      Intrinsics.checkNotNullParameter(destDirectory, "destDirectory");
      File destDir = new File(destDirectory);
      if (!destDir.exists()) {
         destDir.mkdir();
      }

      ZipInputStream zipIn = new ZipInputStream((InputStream)(new FileInputStream(zipFilePath)));

      for(ZipEntry entry = zipIn.getNextEntry(); entry != null; entry = zipIn.getNextEntry()) {
         String filePath = destDirectory + File.separator + entry.getName();
         if (!entry.isDirectory()) {
            INSTANCE.extractFile(zipIn, filePath);
         } else {
            File dir = new File(filePath);
            dir.mkdir();
         }

         zipIn.closeEntry();
      }

      zipIn.close();
   }

   private final void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
      File toWrite = new File(filePath);
      toWrite.getParentFile().mkdirs();
      toWrite.createNewFile();
      BufferedOutputStream bos = new BufferedOutputStream((OutputStream)(new FileOutputStream(filePath)));
      byte[] bytesIn = new byte[4096];

      for(int read = zipIn.read(bytesIn); read != -1; read = zipIn.read(bytesIn)) {
         bos.write(bytesIn, 0, read);
      }

      bos.close();
   }

   private final String absoluteLocation(String importName, String fileLocation) {
      return Config.INSTANCE.getModulesFolder() + File.separator + importName + File.separator + fileLocation;
   }

   @JvmStatic
   @NotNull
   public static final String encodeBase64(@NotNull String toEncode) {
      Intrinsics.checkNotNullParameter(toEncode, "toEncode");
      Encoder var10000 = Base64.getEncoder();
      byte[] var10001 = toEncode.getBytes(Charsets.UTF_8);
      Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).getBytes(charset)");
      String var1 = var10000.encodeToString(var10001);
      Intrinsics.checkNotNullExpressionValue(var1, "getEncoder().encodeToStr…g(toEncode.toByteArray())");
      return var1;
   }

   @JvmStatic
   @NotNull
   public static final String decodeBase64(@NotNull String toDecode) {
      Intrinsics.checkNotNullParameter(toDecode, "toDecode");
      byte[] var1 = Base64.getDecoder().decode(toDecode);
      Intrinsics.checkNotNullExpressionValue(var1, "getDecoder().decode(toDecode)");
      return new String(var1, Charsets.UTF_8);
   }

   @JvmStatic
   @JvmOverloads
   public static final void write(@NotNull String importName, @NotNull String fileName, @NotNull String toWrite) {
      Intrinsics.checkNotNullParameter(importName, "importName");
      Intrinsics.checkNotNullParameter(fileName, "fileName");
      Intrinsics.checkNotNullParameter(toWrite, "toWrite");
      write$default(importName, fileName, toWrite, false, 8, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void write(@NotNull String fileLocation, @NotNull String toWrite) {
      Intrinsics.checkNotNullParameter(fileLocation, "fileLocation");
      Intrinsics.checkNotNullParameter(toWrite, "toWrite");
      write$default(fileLocation, toWrite, false, 4, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final String getUrlContent(@NotNull String theUrl) throws UnknownHostException {
      Intrinsics.checkNotNullParameter(theUrl, "theUrl");
      return getUrlContent$default(theUrl, (String)null, 2, (Object)null);
   }
}
