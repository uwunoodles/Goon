package com.chattriggers.ctjs.minecraft.libs.renderer;

import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.minecraft.libs.MathLib;
import com.chattriggers.ctjs.minecraft.wrappers.Client;
import com.chattriggers.ctjs.minecraft.wrappers.Player;
import com.chattriggers.ctjs.minecraft.wrappers.entity.PlayerMP;
import com.chattriggers.ctjs.utils.kotlin.ExtensionsKt;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0080\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b7\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010 \n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\u0010\u0006\n\u0002\b\u0016\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0015\n\u0002\b\f\bÆ\u0002\u0018\u00002\u00020\u0001:\u0002\u0093\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J#\u0010K\u001a\u00020L2\u0014\u0010M\u001a\u0010\u0012\f\b\u0001\u0012\b\u0012\u0004\u0012\u00020L0O0NH\u0002¢\u0006\u0002\u0010PJ*\u0010Q\u001a\u00020\u00042\u0006\u0010R\u001a\u00020\u00042\u0006\u0010S\u001a\u00020\u00042\u0006\u0010T\u001a\u00020\u00042\b\b\u0002\u0010U\u001a\u00020\u0004H\u0007J*\u0010V\u001a\u00020W2\u0006\u0010R\u001a\u00020L2\u0006\u0010S\u001a\u00020L2\u0006\u0010T\u001a\u00020L2\b\b\u0002\u0010U\u001a\u00020LH\u0007J\u0015\u0010X\u001a\u00020W2\u0006\u0010Y\u001a\u00020\u0004H\u0000¢\u0006\u0002\bZJ:\u0010[\u001a\u00020W2\u0006\u0010Q\u001a\u00020\u00042\u0006\u0010\\\u001a\u00020L2\u0006\u0010]\u001a\u00020L2\u0006\u0010^\u001a\u00020L2\u0006\u0010_\u001a\u00020<2\b\b\u0002\u0010;\u001a\u00020<H\u0007J0\u0010`\u001a\u00020W2\u0006\u0010a\u001a\u00020b2\u0006\u0010\\\u001a\u00020c2\u0006\u0010]\u001a\u00020c2\u0006\u0010d\u001a\u00020c2\u0006\u0010e\u001a\u00020cH\u0007JB\u0010f\u001a\u00020W2\u0006\u0010Q\u001a\u00020\u00042\u0006\u0010g\u001a\u00020L2\u0006\u0010h\u001a\u00020L2\u0006\u0010i\u001a\u00020L2\u0006\u0010j\u001a\u00020L2\u0006\u0010k\u001a\u00020L2\b\b\u0002\u0010;\u001a\u00020<H\u0007J\\\u0010l\u001a\u00020W2\u0006\u0010m\u001a\u00020\u00012\u0006\u0010\\\u001a\u00020<2\u0006\u0010]\u001a\u00020<2\b\b\u0002\u0010n\u001a\u00020C2\b\b\u0002\u0010o\u001a\u00020C2\b\b\u0002\u0010p\u001a\u00020C2\b\b\u0002\u0010q\u001a\u00020C2\b\b\u0002\u0010r\u001a\u00020C2\b\b\u0002\u0010s\u001a\u00020CH\u0007J0\u0010t\u001a\u00020W2\u0006\u0010Q\u001a\u00020\u00042\u0006\u0010\\\u001a\u00020L2\u0006\u0010]\u001a\u00020L2\u0006\u0010d\u001a\u00020L2\u0006\u0010e\u001a\u00020LH\u0007J?\u0010u\u001a\u00020W2\u0006\u0010Q\u001a\u00020\u00042\u001e\u0010v\u001a\u0010\u0012\f\b\u0001\u0012\b\u0012\u0004\u0012\u00020L0O0N\"\b\u0012\u0004\u0012\u00020L0O2\b\b\u0002\u0010;\u001a\u00020<H\u0007¢\u0006\u0002\u0010wJ*\u0010x\u001a\u00020W2\u0006\u0010y\u001a\u00020z2\u0006\u0010\\\u001a\u00020L2\u0006\u0010]\u001a\u00020L2\b\b\u0002\u0010{\u001a\u00020CH\u0007J \u0010|\u001a\u00020W2\u0006\u0010y\u001a\u00020z2\u0006\u0010\\\u001a\u00020L2\u0006\u0010]\u001a\u00020LH\u0007J\b\u0010}\u001a\u00020WH\u0007J\u0010\u0010~\u001a\u00020\u00042\u0006\u0010Q\u001a\u00020\u0004H\u0007J\u0010\u0010\u007f\u001a\u00020\u00042\u0006\u0010Q\u001a\u00020<H\u0007J\u0011\u0010\u0080\u0001\u001a\u0004\u0018\u00010<H\u0007¢\u0006\u0003\u0010\u0081\u0001J\n\u0010\u0082\u0001\u001a\u00030\u0083\u0001H\u0007J\u001d\u0010\u0084\u0001\u001a\u00020\u00042\u0007\u0010\u0085\u0001\u001a\u00020L2\t\b\u0002\u0010\u0086\u0001\u001a\u00020LH\u0007J\u001e\u0010\u0087\u0001\u001a\u00030\u0088\u00012\u0007\u0010\u0085\u0001\u001a\u00020L2\t\b\u0002\u0010\u0086\u0001\u001a\u00020LH\u0007J\t\u0010\u0089\u0001\u001a\u00020AH\u0007J\u0011\u0010\u008a\u0001\u001a\u00020<2\u0006\u0010y\u001a\u00020zH\u0007J\u0011\u0010B\u001a\u00020W2\u0007\u0010\u008b\u0001\u001a\u00020CH\u0007J\u0011\u0010n\u001a\u00020W2\u0007\u0010\u008c\u0001\u001a\u00020LH\u0007J\u001d\u0010\u008d\u0001\u001a\u00020W2\u0007\u0010\u008e\u0001\u001a\u00020L2\t\b\u0002\u0010\u008f\u0001\u001a\u00020LH\u0007J\u0011\u0010\u0090\u0001\u001a\u00020\u00002\u0006\u0010;\u001a\u00020<H\u0007J$\u0010\u0091\u0001\u001a\u00020W2\u0006\u0010\\\u001a\u00020L2\u0006\u0010]\u001a\u00020L2\t\b\u0002\u0010\u0092\u0001\u001a\u00020LH\u0007R\u001c\u0010\u0003\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u0005\u0010\u0002\u001a\u0004\b\u0006\u0010\u0007R\u001c\u0010\b\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\t\u0010\u0002\u001a\u0004\b\n\u0010\u0007R\u001c\u0010\u000b\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\f\u0010\u0002\u001a\u0004\b\r\u0010\u0007R\u001c\u0010\u000e\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u000f\u0010\u0002\u001a\u0004\b\u0010\u0010\u0007R\u001c\u0010\u0011\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u0012\u0010\u0002\u001a\u0004\b\u0013\u0010\u0007R\u001c\u0010\u0014\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u0015\u0010\u0002\u001a\u0004\b\u0016\u0010\u0007R\u001c\u0010\u0017\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u0018\u0010\u0002\u001a\u0004\b\u0019\u0010\u0007R\u001c\u0010\u001a\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u001b\u0010\u0002\u001a\u0004\b\u001c\u0010\u0007R\u001c\u0010\u001d\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u001e\u0010\u0002\u001a\u0004\b\u001f\u0010\u0007R\u001c\u0010 \u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b!\u0010\u0002\u001a\u0004\b\"\u0010\u0007R\u001c\u0010#\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b$\u0010\u0002\u001a\u0004\b%\u0010\u0007R\u001c\u0010&\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b'\u0010\u0002\u001a\u0004\b(\u0010\u0007R\u001c\u0010)\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b*\u0010\u0002\u001a\u0004\b+\u0010\u0007R\u001c\u0010,\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b-\u0010\u0002\u001a\u0004\b.\u0010\u0007R\u001c\u0010/\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b0\u0010\u0002\u001a\u0004\b1\u0010\u0007R\u001c\u00102\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b3\u0010\u0002\u001a\u0004\b4\u0010\u0007R\u001e\u00105\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u0010\n\u0002\u0010:\u001a\u0004\b6\u00107\"\u0004\b8\u00109R\u0012\u0010;\u001a\u0004\u0018\u00010<X\u0082\u000e¢\u0006\u0004\n\u0002\u0010=R\u000e\u0010>\u001a\u00020?X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010@\u001a\u00020AX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010B\u001a\u00020CX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010D\u001a\u00020?X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010E\u001a\n G*\u0004\u0018\u00010F0FX\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u0010H\u001a\u00060Ij\u0002`JX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0094\u0001"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/libs/renderer/Renderer;", "", "()V", "AQUA", "", "getAQUA$annotations", "getAQUA", "()J", "BLACK", "getBLACK$annotations", "getBLACK", "BLUE", "getBLUE$annotations", "getBLUE", "DARK_AQUA", "getDARK_AQUA$annotations", "getDARK_AQUA", "DARK_BLUE", "getDARK_BLUE$annotations", "getDARK_BLUE", "DARK_GRAY", "getDARK_GRAY$annotations", "getDARK_GRAY", "DARK_GREEN", "getDARK_GREEN$annotations", "getDARK_GREEN", "DARK_PURPLE", "getDARK_PURPLE$annotations", "getDARK_PURPLE", "DARK_RED", "getDARK_RED$annotations", "getDARK_RED", "GOLD", "getGOLD$annotations", "getGOLD", "GRAY", "getGRAY$annotations", "getGRAY", "GREEN", "getGREEN$annotations", "getGREEN", "LIGHT_PURPLE", "getLIGHT_PURPLE$annotations", "getLIGHT_PURPLE", "RED", "getRED$annotations", "getRED", "WHITE", "getWHITE$annotations", "getWHITE", "YELLOW", "getYELLOW$annotations", "getYELLOW", "colorized", "getColorized", "()Ljava/lang/Long;", "setColorized", "(Ljava/lang/Long;)V", "Ljava/lang/Long;", "drawMode", "", "Ljava/lang/Integer;", "normalCTRenderPlayer", "Lcom/chattriggers/ctjs/minecraft/libs/renderer/CTRenderPlayer;", "renderManager", "Lnet/minecraft/client/renderer/entity/RenderManager;", "retainTransforms", "", "slimCTRenderPlayer", "tessellator", "Lnet/minecraft/client/renderer/Tessellator;", "kotlin.jvm.PlatformType", "worldRenderer", "Lnet/minecraft/client/renderer/WorldRenderer;", "Lcom/chattriggers/ctjs/utils/kotlin/MCWorldRenderer;", "area", "", "points", "", "", "([Ljava/util/List;)F", "color", "red", "green", "blue", "alpha", "colorize", "", "doColor", "longColor", "doColor$ctjs", "drawCircle", "x", "y", "radius", "steps", "drawImage", "image", "Lcom/chattriggers/ctjs/minecraft/libs/renderer/Image;", "", "width", "height", "drawLine", "x1", "y1", "x2", "y2", "thickness", "drawPlayer", "player", "rotate", "showNametag", "showArmor", "showCape", "showHeldItem", "showArrows", "drawRect", "drawShape", "vertexes", "(J[Ljava/util/List;I)V", "drawString", "text", "", "shadow", "drawStringWithShadow", "finishDraw", "fixAlpha", "getColor", "getDrawMode", "()Ljava/lang/Integer;", "getFontRenderer", "Lnet/minecraft/client/gui/FontRenderer;", "getRainbow", "step", "speed", "getRainbowColors", "", "getRenderManager", "getStringWidth", "retain", "angle", "scale", "scaleX", "scaleY", "setDrawMode", "translate", "z", "screen", "ctjs"}
)
public final class Renderer {
   @NotNull
   public static final Renderer INSTANCE = new Renderer();
   @Nullable
   private static Long colorized;
   private static boolean retainTransforms;
   @Nullable
   private static Integer drawMode;
   private static final Tessellator tessellator = Tessellator.func_178181_a();
   @NotNull
   private static final WorldRenderer worldRenderer;
   private static final long BLACK;
   private static final long DARK_BLUE;
   private static final long DARK_GREEN;
   private static final long DARK_AQUA;
   private static final long DARK_RED;
   private static final long DARK_PURPLE;
   private static final long GOLD;
   private static final long GRAY;
   private static final long DARK_GRAY;
   private static final long BLUE;
   private static final long GREEN;
   private static final long AQUA;
   private static final long RED;
   private static final long LIGHT_PURPLE;
   private static final long YELLOW;
   private static final long WHITE;
   @NotNull
   private static final RenderManager renderManager;
   @NotNull
   private static final CTRenderPlayer slimCTRenderPlayer;
   @NotNull
   private static final CTRenderPlayer normalCTRenderPlayer;

   private Renderer() {
   }

   @Nullable
   public final Long getColorized() {
      return colorized;
   }

   public final void setColorized(@Nullable Long var1) {
      colorized = var1;
   }

   public static final long getBLACK() {
      return BLACK;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getBLACK$annotations() {
   }

   public static final long getDARK_BLUE() {
      return DARK_BLUE;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getDARK_BLUE$annotations() {
   }

   public static final long getDARK_GREEN() {
      return DARK_GREEN;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getDARK_GREEN$annotations() {
   }

   public static final long getDARK_AQUA() {
      return DARK_AQUA;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getDARK_AQUA$annotations() {
   }

   public static final long getDARK_RED() {
      return DARK_RED;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getDARK_RED$annotations() {
   }

   public static final long getDARK_PURPLE() {
      return DARK_PURPLE;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getDARK_PURPLE$annotations() {
   }

   public static final long getGOLD() {
      return GOLD;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getGOLD$annotations() {
   }

   public static final long getGRAY() {
      return GRAY;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getGRAY$annotations() {
   }

   public static final long getDARK_GRAY() {
      return DARK_GRAY;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getDARK_GRAY$annotations() {
   }

   public static final long getBLUE() {
      return BLUE;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getBLUE$annotations() {
   }

   public static final long getGREEN() {
      return GREEN;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getGREEN$annotations() {
   }

   public static final long getAQUA() {
      return AQUA;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getAQUA$annotations() {
   }

   public static final long getRED() {
      return RED;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getRED$annotations() {
   }

   public static final long getLIGHT_PURPLE() {
      return LIGHT_PURPLE;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getLIGHT_PURPLE$annotations() {
   }

   public static final long getYELLOW() {
      return YELLOW;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getYELLOW$annotations() {
   }

   public static final long getWHITE() {
      return WHITE;
   }

   /** @deprecated */
   // $FF: synthetic method
   @JvmStatic
   public static void getWHITE$annotations() {
   }

   @JvmStatic
   public static final long getColor(int color) {
      Renderer var10000;
      long var1;
      switch(color) {
      case 0:
         var10000 = INSTANCE;
         var1 = BLACK;
         break;
      case 1:
         var10000 = INSTANCE;
         var1 = DARK_BLUE;
         break;
      case 2:
         var10000 = INSTANCE;
         var1 = DARK_GREEN;
         break;
      case 3:
         var10000 = INSTANCE;
         var1 = DARK_AQUA;
         break;
      case 4:
         var10000 = INSTANCE;
         var1 = DARK_RED;
         break;
      case 5:
         var10000 = INSTANCE;
         var1 = DARK_PURPLE;
         break;
      case 6:
         var10000 = INSTANCE;
         var1 = GOLD;
         break;
      case 7:
         var10000 = INSTANCE;
         var1 = GRAY;
         break;
      case 8:
         var10000 = INSTANCE;
         var1 = DARK_GRAY;
         break;
      case 9:
         var10000 = INSTANCE;
         var1 = BLUE;
         break;
      case 10:
         var10000 = INSTANCE;
         var1 = GREEN;
         break;
      case 11:
         var10000 = INSTANCE;
         var1 = AQUA;
         break;
      case 12:
         var10000 = INSTANCE;
         var1 = RED;
         break;
      case 13:
         var10000 = INSTANCE;
         var1 = LIGHT_PURPLE;
         break;
      case 14:
         var10000 = INSTANCE;
         var1 = YELLOW;
         break;
      default:
         var10000 = INSTANCE;
         var1 = WHITE;
      }

      return var1;
   }

   @JvmStatic
   @NotNull
   public static final FontRenderer getFontRenderer() {
      FontRenderer var0 = Client.Companion.getMinecraft().field_71466_p;
      Intrinsics.checkNotNullExpressionValue(var0, "Client.getMinecraft().fontRendererObj");
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final RenderManager getRenderManager() {
      RenderManager var0 = Client.Companion.getMinecraft().func_175598_ae();
      Intrinsics.checkNotNullExpressionValue(var0, "Client.getMinecraft().renderManager");
      return var0;
   }

   @JvmStatic
   public static final int getStringWidth(@NotNull String text) {
      Intrinsics.checkNotNullParameter(text, "text");
      Renderer var10000 = INSTANCE;
      return getFontRenderer().func_78256_a(ChatLib.addColor(text));
   }

   @JvmStatic
   @JvmOverloads
   public static final long color(long red, long green, long blue, long alpha) {
      return (long)(MathLib.clamp((int)alpha, 0, 255) * 16777216 + MathLib.clamp((int)red, 0, 255) * 65536 + MathLib.clamp((int)green, 0, 255) * 256 + MathLib.clamp((int)blue, 0, 255));
   }

   // $FF: synthetic method
   public static long color$default(long var0, long var2, long var4, long var6, int var8, Object var9) {
      if ((var8 & 8) != 0) {
         var6 = 255L;
      }

      return color(var0, var2, var4, var6);
   }

   @JvmStatic
   @JvmOverloads
   public static final long getRainbow(float step, float speed) {
      long red = (long)(((double)((float)Math.sin((double)(step / speed))) + 0.75D) * (double)170);
      long green = (long)((Math.sin((double)(step / speed) + 2.0943951023931953D) + 0.75D) * (double)170);
      long blue = (long)((Math.sin((double)(step / speed) + 4.1887902047863905D) + 0.75D) * (double)170);
      Renderer var10000 = INSTANCE;
      return color(red, green, blue, 255L);
   }

   // $FF: synthetic method
   public static long getRainbow$default(float var0, float var1, int var2, Object var3) {
      if ((var2 & 2) != 0) {
         var1 = 1.0F;
      }

      return getRainbow(var0, var1);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final int[] getRainbowColors(float step, float speed) {
      int red = (int)(((double)((float)Math.sin((double)(step / speed))) + 0.75D) * (double)170);
      int green = (int)((Math.sin((double)(step / speed) + 2.0943951023931953D) + 0.75D) * (double)170);
      int blue = (int)((Math.sin((double)(step / speed) + 4.1887902047863905D) + 0.75D) * (double)170);
      int[] var5 = new int[]{red, green, blue};
      return var5;
   }

   // $FF: synthetic method
   public static int[] getRainbowColors$default(float var0, float var1, int var2, Object var3) {
      if ((var2 & 2) != 0) {
         var1 = 1.0F;
      }

      return getRainbowColors(var0, var1);
   }

   @JvmStatic
   public static final void retainTransforms(boolean retain) {
      Renderer var10000 = INSTANCE;
      retainTransforms = retain;
      var10000 = INSTANCE;
      finishDraw();
   }

   @JvmStatic
   @JvmOverloads
   public static final void translate(float x, float y, float z) {
      GlStateManager.func_179109_b(x, y, z);
   }

   // $FF: synthetic method
   public static void translate$default(float var0, float var1, float var2, int var3, Object var4) {
      if ((var3 & 4) != 0) {
         var2 = 0.0F;
      }

      translate(var0, var1, var2);
   }

   @JvmStatic
   @JvmOverloads
   public static final void scale(float scaleX, float scaleY) {
      GlStateManager.func_179152_a(scaleX, scaleY, 1.0F);
   }

   // $FF: synthetic method
   public static void scale$default(float var0, float var1, int var2, Object var3) {
      if ((var2 & 2) != 0) {
         var1 = var0;
      }

      scale(var0, var1);
   }

   @JvmStatic
   public static final void rotate(float angle) {
      GlStateManager.func_179114_b(angle, 0.0F, 0.0F, 1.0F);
   }

   @JvmStatic
   @JvmOverloads
   public static final void colorize(float red, float green, float blue, float alpha) {
      Renderer var10000 = INSTANCE;
      var10000 = INSTANCE;
      var10000 = INSTANCE;
      colorized = fixAlpha(color((long)red, (long)green, (long)blue, (long)alpha));
      GlStateManager.func_179131_c(MathLib.clampFloat(red, 0.0F, 1.0F), MathLib.clampFloat(green, 0.0F, 1.0F), MathLib.clampFloat(blue, 0.0F, 1.0F), MathLib.clampFloat(alpha, 0.0F, 1.0F));
   }

   // $FF: synthetic method
   public static void colorize$default(float var0, float var1, float var2, float var3, int var4, Object var5) {
      if ((var4 & 8) != 0) {
         var3 = 1.0F;
      }

      colorize(var0, var1, var2, var3);
   }

   @JvmStatic
   @NotNull
   public static final Renderer setDrawMode(int drawMode) {
      Renderer var1 = INSTANCE;
      int var3 = false;
      Renderer.drawMode = drawMode;
      return var1;
   }

   @JvmStatic
   @Nullable
   public static final Integer getDrawMode() {
      return drawMode;
   }

   @JvmStatic
   public static final long fixAlpha(long color) {
      long alpha = color >> 24 & 255L;
      return alpha < 10L ? color & 16777215L | 184549375L : color;
   }

   @JvmStatic
   public static final void drawRect(long color, float x, float y, float width, float height) {
      Float[] var7 = new Float[]{x, y, x + width, y + height};
      List pos = CollectionsKt.mutableListOf(var7);
      if (((Number)pos.get(0)).floatValue() > ((Number)pos.get(2)).floatValue()) {
         Collections.swap(pos, 0, 2);
      }

      if (((Number)pos.get(1)).floatValue() > ((Number)pos.get(3)).floatValue()) {
         Collections.swap(pos, 1, 3);
      }

      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
      GlStateManager.func_179120_a(770, 771, 1, 0);
      INSTANCE.doColor$ctjs(color);
      Integer var10001 = drawMode;
      worldRenderer.func_181668_a(var10001 == null ? 7 : var10001, DefaultVertexFormats.field_181705_e);
      worldRenderer.func_181662_b((double)((Number)pos.get(0)).floatValue(), (double)((Number)pos.get(3)).floatValue(), 0.0D).func_181675_d();
      worldRenderer.func_181662_b((double)((Number)pos.get(2)).floatValue(), (double)((Number)pos.get(3)).floatValue(), 0.0D).func_181675_d();
      worldRenderer.func_181662_b((double)((Number)pos.get(2)).floatValue(), (double)((Number)pos.get(1)).floatValue(), 0.0D).func_181675_d();
      worldRenderer.func_181662_b((double)((Number)pos.get(0)).floatValue(), (double)((Number)pos.get(1)).floatValue(), 0.0D).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      Renderer var10000 = INSTANCE;
      finishDraw();
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawShape(long color, @NotNull List<Float>[] vertexes, int drawMode) {
      Intrinsics.checkNotNullParameter(vertexes, "vertexes");
      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
      GlStateManager.func_179120_a(770, 771, 1, 0);
      INSTANCE.doColor$ctjs(color);
      Integer var10001 = Renderer.drawMode;
      worldRenderer.func_181668_a(var10001 == null ? drawMode : var10001, DefaultVertexFormats.field_181705_e);
      if (INSTANCE.area(vertexes) >= 0.0F) {
         ArraysKt.reverse(vertexes);
      }

      Object[] $this$forEach$iv = vertexes;
      int $i$f$forEach = false;
      int var6 = 0;

      for(int var7 = vertexes.length; var6 < var7; ++var6) {
         Object element$iv = $this$forEach$iv[var6];
         int var10 = false;
         worldRenderer.func_181662_b((double)((Number)element$iv.get(0)).floatValue(), (double)((Number)element$iv.get(1)).floatValue(), 0.0D).func_181675_d();
      }

      tessellator.func_78381_a();
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      Renderer var10000 = INSTANCE;
      finishDraw();
   }

   // $FF: synthetic method
   public static void drawShape$default(long var0, List[] var2, int var3, int var4, Object var5) {
      if ((var4 & 4) != 0) {
         var3 = 9;
      }

      drawShape(var0, var2, var3);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawLine(long color, float x1, float y1, float x2, float y2, float thickness, int drawMode) {
      float i = y2 - y1;
      float j = x2 - x1;
      float theta = -((float)Math.atan2((double)i, (double)j));
      i = (float)Math.sin((double)theta) * (thickness / (float)2);
      j = (float)Math.cos((double)theta) * (thickness / (float)2);
      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
      GlStateManager.func_179120_a(770, 771, 1, 0);
      INSTANCE.doColor$ctjs(color);
      Integer var10001 = Renderer.drawMode;
      worldRenderer.func_181668_a(var10001 == null ? drawMode : var10001, DefaultVertexFormats.field_181705_e);
      worldRenderer.func_181662_b((double)(x1 + i), (double)(y1 + j), 0.0D).func_181675_d();
      worldRenderer.func_181662_b((double)(x2 + i), (double)(y2 + j), 0.0D).func_181675_d();
      worldRenderer.func_181662_b((double)(x2 - i), (double)(y2 - j), 0.0D).func_181675_d();
      worldRenderer.func_181662_b((double)(x1 - i), (double)(y1 - j), 0.0D).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      Renderer var10000 = INSTANCE;
      finishDraw();
   }

   // $FF: synthetic method
   public static void drawLine$default(long var0, float var2, float var3, float var4, float var5, float var6, int var7, int var8, Object var9) {
      if ((var8 & 64) != 0) {
         var7 = 7;
      }

      drawLine(var0, var2, var3, var4, var5, var6, var7);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawCircle(long color, float x, float y, float radius, int steps, int drawMode) {
      double theta = 6.283185307179586D / (double)steps;
      float cos = (float)Math.cos(theta);
      float sin = (float)Math.sin(theta);
      float xHolder = 0.0F;
      float circleX = 1.0F;
      float circleY = 0.0F;
      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
      GlStateManager.func_179120_a(770, 771, 1, 0);
      INSTANCE.doColor$ctjs(color);
      Integer var10001 = Renderer.drawMode;
      worldRenderer.func_181668_a(var10001 == null ? drawMode : var10001, DefaultVertexFormats.field_181705_e);
      int var14 = 0;
      int i;
      if (var14 <= steps) {
         do {
            i = var14++;
            worldRenderer.func_181662_b((double)x, (double)y, 0.0D).func_181675_d();
            worldRenderer.func_181662_b((double)(circleX * radius + x), (double)(circleY * radius + y), 0.0D).func_181675_d();
            xHolder = circleX;
            circleX = cos * circleX - sin * circleY;
            circleY = sin * xHolder + cos * circleY;
            worldRenderer.func_181662_b((double)(circleX * radius + x), (double)(circleY * radius + y), 0.0D).func_181675_d();
         } while(i != steps);
      }

      tessellator.func_78381_a();
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      Renderer var10000 = INSTANCE;
      finishDraw();
   }

   // $FF: synthetic method
   public static void drawCircle$default(long var0, float var2, float var3, float var4, int var5, int var6, int var7, Object var8) {
      if ((var7 & 32) != 0) {
         var6 = 5;
      }

      drawCircle(var0, var2, var3, var4, var5, var6);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawString(@NotNull String text, float x, float y, boolean shadow) {
      Intrinsics.checkNotNullParameter(text, "text");
      Renderer var10000 = INSTANCE;
      FontRenderer fr = getFontRenderer();
      float newY = 0.0F;
      newY = y;
      CharSequence var13 = (CharSequence)ChatLib.addColor(text);
      String[] var6 = new String[]{"\n"};
      Iterable $this$forEach$iv = (Iterable)StringsKt.split$default(var13, var6, false, 0, 6, (Object)null);
      int $i$f$forEach = false;

      for(Iterator var8 = $this$forEach$iv.iterator(); var8.hasNext(); newY += (float)fr.field_78288_b) {
         Object element$iv = var8.next();
         String it = (String)element$iv;
         int var11 = false;
         Long var10004 = INSTANCE.getColorized();
         Integer var14 = var10004 == null ? null : (int)var10004;
         fr.func_175065_a(it, x, newY, var14 == null ? (int)getWHITE() : var14, shadow);
      }

      var10000 = INSTANCE;
      finishDraw();
   }

   // $FF: synthetic method
   public static void drawString$default(String var0, float var1, float var2, boolean var3, int var4, Object var5) {
      if ((var4 & 8) != 0) {
         var3 = false;
      }

      drawString(var0, var1, var2, var3);
   }

   @JvmStatic
   public static final void drawStringWithShadow(@NotNull String text, float x, float y) {
      Intrinsics.checkNotNullParameter(text, "text");
      Renderer var10000 = INSTANCE;
      drawString(text, x, y, true);
   }

   @JvmStatic
   public static final void drawImage(@NotNull Image image, double x, double y, double width, double height) {
      Intrinsics.checkNotNullParameter(image, "image");
      Renderer var10000 = INSTANCE;
      if (colorized == null) {
         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      }

      GlStateManager.func_179147_l();
      GlStateManager.func_179152_a(1.0F, 1.0F, 50.0F);
      GlStateManager.func_179144_i(image.getTexture().func_110552_b());
      GlStateManager.func_179098_w();
      Integer var10001 = drawMode;
      worldRenderer.func_181668_a(var10001 == null ? 7 : var10001, DefaultVertexFormats.field_181707_g);
      worldRenderer.func_181662_b(x, y + height, 0.0D).func_181673_a(0.0D, 1.0D).func_181675_d();
      worldRenderer.func_181662_b(x + width, y + height, 0.0D).func_181673_a(1.0D, 1.0D).func_181675_d();
      worldRenderer.func_181662_b(x + width, y, 0.0D).func_181673_a(1.0D, 0.0D).func_181675_d();
      worldRenderer.func_181662_b(x, y, 0.0D).func_181673_a(0.0D, 0.0D).func_181675_d();
      tessellator.func_78381_a();
      var10000 = INSTANCE;
      finishDraw();
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawPlayer(@NotNull Object player, int x, int y, boolean rotate, boolean showNametag, boolean showArmor, boolean showCape, boolean showHeldItem, boolean showArrows) {
      Intrinsics.checkNotNullParameter(player, "player");
      float mouseX = -30.0F;
      float mouseY = 0.0F;
      EntityPlayer var10000;
      if (player instanceof PlayerMP) {
         var10000 = ((PlayerMP)player).getPlayer();
      } else {
         EntityPlayerSP var19 = Player.getPlayer();
         Intrinsics.checkNotNull(var19);
         var10000 = (EntityPlayer)var19;
      }

      EntityPlayer ent = var10000;
      GlStateManager.func_179142_g();
      RenderHelper.func_74519_b();
      float f = ent.field_70761_aq;
      float f1 = ent.field_70177_z;
      float f2 = ent.field_70125_A;
      float f3 = ent.field_70758_at;
      float f4 = ent.field_70759_as;
      Renderer var20 = INSTANCE;
      translate((float)x, (float)y, 50.0F);
      GlStateManager.func_179114_b(180.0F, 0.0F, 0.0F, 1.0F);
      GlStateManager.func_179114_b(45.0F, 0.0F, 1.0F, 0.0F);
      GlStateManager.func_179114_b(-45.0F, 0.0F, 1.0F, 0.0F);
      GlStateManager.func_179114_b(-((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
      var20 = INSTANCE;
      scale(-1.0F, 1.0F);
      if (!rotate) {
         ent.field_70761_aq = (float)Math.atan((double)(mouseX / 40.0F)) * 20.0F;
         ent.field_70177_z = (float)Math.atan((double)(mouseX / 40.0F)) * 40.0F;
         ent.field_70125_A = -((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F;
         ent.field_70759_as = ent.field_70177_z;
         ent.field_70758_at = ent.field_70177_z;
      }

      renderManager.field_78735_i = 180.0F;
      renderManager.func_178633_a(false);
      boolean isSmall = Intrinsics.areEqual(((AbstractClientPlayer)ent).func_175154_l(), "slim");
      CTRenderPlayer ctRenderPlayer = isSmall ? slimCTRenderPlayer : normalCTRenderPlayer;
      ctRenderPlayer.setOptions(showNametag, showArmor, showCape, showHeldItem, showArrows);
      ctRenderPlayer.func_76986_a((AbstractClientPlayer)ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
      renderManager.func_178633_a(true);
      ent.field_70761_aq = f;
      ent.field_70177_z = f1;
      ent.field_70125_A = f2;
      ent.field_70758_at = f3;
      ent.field_70759_as = f4;
      RenderHelper.func_74518_a();
      GlStateManager.func_179101_C();
      GlStateManager.func_179138_g(OpenGlHelper.field_77476_b);
      GlStateManager.func_179090_x();
      GlStateManager.func_179138_g(OpenGlHelper.field_77478_a);
      var20 = INSTANCE;
      finishDraw();
   }

   // $FF: synthetic method
   public static void drawPlayer$default(Object var0, int var1, int var2, boolean var3, boolean var4, boolean var5, boolean var6, boolean var7, boolean var8, int var9, Object var10) {
      if ((var9 & 8) != 0) {
         var3 = false;
      }

      if ((var9 & 16) != 0) {
         var4 = false;
      }

      if ((var9 & 32) != 0) {
         var5 = true;
      }

      if ((var9 & 64) != 0) {
         var6 = true;
      }

      if ((var9 & 128) != 0) {
         var7 = true;
      }

      if ((var9 & 256) != 0) {
         var8 = true;
      }

      drawPlayer(var0, var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public final void doColor$ctjs(long longColor) {
      int color = (int)longColor;
      if (colorized == null) {
         float a = (float)(color >> 24 & 255) / 255.0F;
         float r = (float)(color >> 16 & 255) / 255.0F;
         float g = (float)(color >> 8 & 255) / 255.0F;
         float b = (float)(color & 255) / 255.0F;
         GlStateManager.func_179131_c(r, g, b, a);
      }

   }

   @JvmStatic
   public static final void finishDraw() {
      if (!retainTransforms) {
         Renderer var10000 = INSTANCE;
         colorized = null;
         var10000 = INSTANCE;
         drawMode = null;
         GlStateManager.func_179121_F();
         GlStateManager.func_179094_E();
      }

   }

   private final float area(List<Float>[] points) {
      float area = 0.0F;
      int var3 = 0;

      float x1;
      float y1;
      float x2;
      float y2;
      for(int var4 = points.length; var3 < var4; area += x1 * y2 - x2 * y1) {
         int i = var3++;
         List var6 = points[i];
         x1 = ((Number)var6.get(0)).floatValue();
         y1 = ((Number)var6.get(1)).floatValue();
         List var9 = points[(i + 1) % points.length];
         x2 = ((Number)var9.get(0)).floatValue();
         y2 = ((Number)var9.get(1)).floatValue();
      }

      return area / (float)2;
   }

   @JvmStatic
   @JvmOverloads
   public static final long color(long red, long green, long blue) {
      return color$default(red, green, blue, 0L, 8, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final long getRainbow(float step) {
      return getRainbow$default(step, 0.0F, 2, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final int[] getRainbowColors(float step) {
      return getRainbowColors$default(step, 0.0F, 2, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void translate(float x, float y) {
      translate$default(x, y, 0.0F, 4, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void scale(float scaleX) {
      scale$default(scaleX, 0.0F, 2, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void colorize(float red, float green, float blue) {
      colorize$default(red, green, blue, 0.0F, 8, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawShape(long color, @NotNull List<Float>... vertexes) {
      Intrinsics.checkNotNullParameter(vertexes, "vertexes");
      drawShape$default(color, vertexes, 0, 4, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawLine(long color, float x1, float y1, float x2, float y2, float thickness) {
      drawLine$default(color, x1, y1, x2, y2, thickness, 0, 64, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawCircle(long color, float x, float y, float radius, int steps) {
      drawCircle$default(color, x, y, radius, steps, 0, 32, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawString(@NotNull String text, float x, float y) {
      Intrinsics.checkNotNullParameter(text, "text");
      drawString$default(text, x, y, false, 8, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawPlayer(@NotNull Object player, int x, int y, boolean rotate, boolean showNametag, boolean showArmor, boolean showCape, boolean showHeldItem) {
      Intrinsics.checkNotNullParameter(player, "player");
      drawPlayer$default(player, x, y, rotate, showNametag, showArmor, showCape, showHeldItem, false, 256, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawPlayer(@NotNull Object player, int x, int y, boolean rotate, boolean showNametag, boolean showArmor, boolean showCape) {
      Intrinsics.checkNotNullParameter(player, "player");
      drawPlayer$default(player, x, y, rotate, showNametag, showArmor, showCape, false, false, 384, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawPlayer(@NotNull Object player, int x, int y, boolean rotate, boolean showNametag, boolean showArmor) {
      Intrinsics.checkNotNullParameter(player, "player");
      drawPlayer$default(player, x, y, rotate, showNametag, showArmor, false, false, false, 448, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawPlayer(@NotNull Object player, int x, int y, boolean rotate, boolean showNametag) {
      Intrinsics.checkNotNullParameter(player, "player");
      drawPlayer$default(player, x, y, rotate, showNametag, false, false, false, false, 480, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawPlayer(@NotNull Object player, int x, int y, boolean rotate) {
      Intrinsics.checkNotNullParameter(player, "player");
      drawPlayer$default(player, x, y, rotate, false, false, false, false, false, 496, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void drawPlayer(@NotNull Object player, int x, int y) {
      Intrinsics.checkNotNullParameter(player, "player");
      drawPlayer$default(player, x, y, false, false, false, false, false, false, 504, (Object)null);
   }

   static {
      Tessellator var0 = tessellator;
      Intrinsics.checkNotNullExpressionValue(var0, "tessellator");
      worldRenderer = ExtensionsKt.getRenderer(var0);
      BLACK = color(0L, 0L, 0L, 255L);
      DARK_BLUE = color(0L, 0L, 190L, 255L);
      DARK_GREEN = color(0L, 190L, 0L, 255L);
      DARK_AQUA = color(0L, 190L, 190L, 255L);
      DARK_RED = color(190L, 0L, 0L, 255L);
      DARK_PURPLE = color(190L, 0L, 190L, 255L);
      GOLD = color(217L, 163L, 52L, 255L);
      GRAY = color(190L, 190L, 190L, 255L);
      DARK_GRAY = color(63L, 63L, 63L, 255L);
      BLUE = color(63L, 63L, 254L, 255L);
      GREEN = color(63L, 254L, 63L, 255L);
      AQUA = color(63L, 254L, 254L, 255L);
      RED = color(254L, 63L, 63L, 255L);
      LIGHT_PURPLE = color(254L, 63L, 254L, 255L);
      YELLOW = color(254L, 254L, 63L, 255L);
      WHITE = color(255L, 255L, 255L, 255L);
      renderManager = getRenderManager();
      slimCTRenderPlayer = new CTRenderPlayer(renderManager, true);
      normalCTRenderPlayer = new CTRenderPlayer(renderManager, false);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007J\b\u0010\u0005\u001a\u00020\u0004H\u0007J\b\u0010\u0006\u001a\u00020\u0004H\u0007¨\u0006\u0007"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/libs/renderer/Renderer$screen;", "", "()V", "getHeight", "", "getScale", "getWidth", "ctjs"}
   )
   public static final class screen {
      @NotNull
      public static final Renderer.screen INSTANCE = new Renderer.screen();

      private screen() {
      }

      @JvmStatic
      public static final int getWidth() {
         return (new ScaledResolution(Client.Companion.getMinecraft())).func_78326_a();
      }

      @JvmStatic
      public static final int getHeight() {
         return (new ScaledResolution(Client.Companion.getMinecraft())).func_78328_b();
      }

      @JvmStatic
      public static final int getScale() {
         return (new ScaledResolution(Client.Companion.getMinecraft())).func_78325_e();
      }
   }
}
