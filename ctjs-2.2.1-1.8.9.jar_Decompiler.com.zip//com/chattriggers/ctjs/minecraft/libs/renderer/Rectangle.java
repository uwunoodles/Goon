package com.chattriggers.ctjs.minecraft.libs.renderer;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.util.vector.Vector2f;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0018\u0018\u00002\u00020\u0001:\u0002,-B-\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005¢\u0006\u0002\u0010\tJ\u0006\u0010\u000e\u001a\u00020\u0000J\u0006\u0010\u000f\u001a\u00020\u0003J\u0006\u0010\u0010\u001a\u00020\u0005J\u0006\u0010\u0011\u001a\u00020\u0012J\u0006\u0010\u0013\u001a\u00020\u0003J\u0006\u0010\u0014\u001a\u00020\u0003J\u0006\u0010\u0015\u001a\u00020\u0016J\u0006\u0010\u0017\u001a\u00020\u0005J\u0006\u0010\u0018\u001a\u00020\u0005J\u0006\u0010\u0019\u001a\u00020\u0005J\u0006\u0010\u001a\u001a\u00020\u0005J\u0006\u0010\u001b\u001a\u00020\u0005J\u0006\u0010\u001c\u001a\u00020\u0005J\u0006\u0010\u001d\u001a\u00020\u0012J\u000e\u0010\u001e\u001a\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0003J\u000e\u0010\u001f\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u0005J\u000e\u0010 \u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0012J\u0016\u0010 \u001a\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010!\u001a\u00020\u0005J\u000e\u0010\"\u001a\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0003J\u000e\u0010#\u001a\u00020\u00002\u0006\u0010\f\u001a\u00020\u0012J\u001e\u0010#\u001a\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005J\u000e\u0010$\u001a\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0003J\u0016\u0010%\u001a\u00020\u00002\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005J\u000e\u0010&\u001a\u00020\u00002\u0006\u0010\u0004\u001a\u00020\u0005J\u000e\u0010'\u001a\u00020\u00002\u0006\u0010\u0006\u001a\u00020\u0005J\u000e\u0010(\u001a\u00020\u00002\u0006\u0010!\u001a\u00020\u0005J\u000e\u0010)\u001a\u00020\u00002\u0006\u0010\u0007\u001a\u00020\u0005J\u000e\u0010*\u001a\u00020\u00002\u0006\u0010\u0004\u001a\u00020\u0005J\u000e\u0010+\u001a\u00020\u00002\u0006\u0010\u0006\u001a\u00020\u0005R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006."},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/libs/renderer/Rectangle;", "", "color", "", "x", "", "y", "width", "height", "(JFFFF)V", "outline", "Lcom/chattriggers/ctjs/minecraft/libs/renderer/Rectangle$Outline;", "shadow", "Lcom/chattriggers/ctjs/minecraft/libs/renderer/Rectangle$Shadow;", "draw", "getColor", "getHeight", "getOutline", "", "getOutlineColor", "getShadowColor", "getShadowOffset", "Lorg/lwjgl/util/vector/Vector2f;", "getShadowOffsetX", "getShadowOffsetY", "getThickness", "getWidth", "getX", "getY", "isShadow", "setColor", "setHeight", "setOutline", "thickness", "setOutlineColor", "setShadow", "setShadowColor", "setShadowOffset", "setShadowOffsetX", "setShadowOffsetY", "setThickness", "setWidth", "setX", "setY", "Outline", "Shadow", "ctjs"}
)
public final class Rectangle {
   private long color;
   private float x;
   private float y;
   private float width;
   private float height;
   @NotNull
   private final Rectangle.Shadow shadow;
   @NotNull
   private final Rectangle.Outline outline;

   public Rectangle(long color, float x, float y, float width, float height) {
      this.color = color;
      this.x = x;
      this.y = y;
      this.width = width;
      this.height = height;
      this.shadow = new Rectangle.Shadow(this, false, 0L, (Vector2f)null, 14, (DefaultConstructorMarker)null);
      this.outline = new Rectangle.Outline(this, false, 0L, 0.0F, 14, (DefaultConstructorMarker)null);
   }

   public final long getColor() {
      return this.color;
   }

   @NotNull
   public final Rectangle setColor(long color) {
      Rectangle $this$setColor_u24lambda_u2d0 = (Rectangle)this;
      int var5 = false;
      $this$setColor_u24lambda_u2d0.color = Renderer.fixAlpha(color);
      return (Rectangle)this;
   }

   public final float getX() {
      return this.x;
   }

   @NotNull
   public final Rectangle setX(float x) {
      Rectangle $this$setX_u24lambda_u2d1 = (Rectangle)this;
      int var4 = false;
      $this$setX_u24lambda_u2d1.x = x;
      return (Rectangle)this;
   }

   public final float getY() {
      return this.y;
   }

   @NotNull
   public final Rectangle setY(float y) {
      Rectangle $this$setY_u24lambda_u2d2 = (Rectangle)this;
      int var4 = false;
      $this$setY_u24lambda_u2d2.y = y;
      return (Rectangle)this;
   }

   public final float getWidth() {
      return this.width;
   }

   @NotNull
   public final Rectangle setWidth(float width) {
      Rectangle $this$setWidth_u24lambda_u2d3 = (Rectangle)this;
      int var4 = false;
      $this$setWidth_u24lambda_u2d3.width = width;
      return (Rectangle)this;
   }

   public final float getHeight() {
      return this.height;
   }

   @NotNull
   public final Rectangle setHeight(float height) {
      Rectangle $this$setHeight_u24lambda_u2d4 = (Rectangle)this;
      int var4 = false;
      $this$setHeight_u24lambda_u2d4.height = height;
      return (Rectangle)this;
   }

   public final boolean isShadow() {
      return this.shadow.getOn();
   }

   @NotNull
   public final Rectangle setShadow(boolean shadow) {
      Rectangle $this$setShadow_u24lambda_u2d5 = (Rectangle)this;
      int var4 = false;
      $this$setShadow_u24lambda_u2d5.shadow.setOn(shadow);
      return (Rectangle)this;
   }

   @NotNull
   public final Vector2f getShadowOffset() {
      return this.shadow.getOffset();
   }

   public final float getShadowOffsetX() {
      return this.shadow.getOffset().x;
   }

   public final float getShadowOffsetY() {
      return this.shadow.getOffset().y;
   }

   @NotNull
   public final Rectangle setShadowOffset(float x, float y) {
      Rectangle $this$setShadowOffset_u24lambda_u2d6 = (Rectangle)this;
      int var5 = false;
      $this$setShadowOffset_u24lambda_u2d6.shadow.getOffset().x = x;
      $this$setShadowOffset_u24lambda_u2d6.shadow.getOffset().y = y;
      return (Rectangle)this;
   }

   @NotNull
   public final Rectangle setShadowOffsetX(float x) {
      Rectangle $this$setShadowOffsetX_u24lambda_u2d7 = (Rectangle)this;
      int var4 = false;
      $this$setShadowOffsetX_u24lambda_u2d7.shadow.getOffset().x = x;
      return (Rectangle)this;
   }

   @NotNull
   public final Rectangle setShadowOffsetY(float y) {
      Rectangle $this$setShadowOffsetY_u24lambda_u2d8 = (Rectangle)this;
      int var4 = false;
      $this$setShadowOffsetY_u24lambda_u2d8.shadow.getOffset().y = y;
      return (Rectangle)this;
   }

   public final long getShadowColor() {
      return this.shadow.getColor();
   }

   @NotNull
   public final Rectangle setShadowColor(long color) {
      Rectangle $this$setShadowColor_u24lambda_u2d9 = (Rectangle)this;
      int var5 = false;
      $this$setShadowColor_u24lambda_u2d9.shadow.setColor(color);
      return (Rectangle)this;
   }

   @NotNull
   public final Rectangle setShadow(long color, float x, float y) {
      Rectangle $this$setShadow_u24lambda_u2d10 = (Rectangle)this;
      int var7 = false;
      $this$setShadow_u24lambda_u2d10.setShadow(true);
      $this$setShadow_u24lambda_u2d10.setShadowColor(color);
      $this$setShadow_u24lambda_u2d10.setShadowOffset(x, y);
      return (Rectangle)this;
   }

   public final boolean getOutline() {
      return this.outline.getOn();
   }

   @NotNull
   public final Rectangle setOutline(boolean outline) {
      Rectangle $this$setOutline_u24lambda_u2d11 = (Rectangle)this;
      int var4 = false;
      $this$setOutline_u24lambda_u2d11.outline.setOn(outline);
      return (Rectangle)this;
   }

   public final long getOutlineColor() {
      return this.outline.getColor();
   }

   @NotNull
   public final Rectangle setOutlineColor(long color) {
      Rectangle $this$setOutlineColor_u24lambda_u2d12 = (Rectangle)this;
      int var5 = false;
      $this$setOutlineColor_u24lambda_u2d12.outline.setColor(color);
      return (Rectangle)this;
   }

   public final float getThickness() {
      return this.outline.getThickness();
   }

   @NotNull
   public final Rectangle setThickness(float thickness) {
      Rectangle $this$setThickness_u24lambda_u2d13 = (Rectangle)this;
      int var4 = false;
      $this$setThickness_u24lambda_u2d13.outline.setThickness(thickness);
      return (Rectangle)this;
   }

   @NotNull
   public final Rectangle setOutline(long color, float thickness) {
      Rectangle $this$setOutline_u24lambda_u2d14 = (Rectangle)this;
      int var6 = false;
      $this$setOutline_u24lambda_u2d14.setOutline(true);
      $this$setOutline_u24lambda_u2d14.setOutlineColor(color);
      $this$setOutline_u24lambda_u2d14.setThickness(thickness);
      return (Rectangle)this;
   }

   @NotNull
   public final Rectangle draw() {
      Rectangle $this$draw_u24lambda_u2d15 = (Rectangle)this;
      int var3 = false;
      $this$draw_u24lambda_u2d15.shadow.draw();
      $this$draw_u24lambda_u2d15.outline.draw();
      Renderer.drawRect($this$draw_u24lambda_u2d15.color, $this$draw_u24lambda_u2d15.x, $this$draw_u24lambda_u2d15.y, $this$draw_u24lambda_u2d15.width, $this$draw_u24lambda_u2d15.height);
      return (Rectangle)this;
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0010\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B+\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\t¢\u0006\u0002\u0010\nJ\u0006\u0010\u0019\u001a\u00020\u001aR\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u001a\u0010\b\u001a\u00020\tX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010\u0014\"\u0004\b\u0015\u0010\u0016R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018¨\u0006\u001b"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/libs/renderer/Rectangle$Shadow;", "", "rect", "Lcom/chattriggers/ctjs/minecraft/libs/renderer/Rectangle;", "on", "", "color", "", "offset", "Lorg/lwjgl/util/vector/Vector2f;", "(Lcom/chattriggers/ctjs/minecraft/libs/renderer/Rectangle;ZJLorg/lwjgl/util/vector/Vector2f;)V", "getColor", "()J", "setColor", "(J)V", "getOffset", "()Lorg/lwjgl/util/vector/Vector2f;", "setOffset", "(Lorg/lwjgl/util/vector/Vector2f;)V", "getOn", "()Z", "setOn", "(Z)V", "getRect", "()Lcom/chattriggers/ctjs/minecraft/libs/renderer/Rectangle;", "draw", "", "ctjs"}
   )
   private static final class Shadow {
      @NotNull
      private final Rectangle rect;
      private boolean on;
      private long color;
      @NotNull
      private Vector2f offset;

      public Shadow(@NotNull Rectangle rect, boolean on, long color, @NotNull Vector2f offset) {
         Intrinsics.checkNotNullParameter(rect, "rect");
         Intrinsics.checkNotNullParameter(offset, "offset");
         super();
         this.rect = rect;
         this.on = on;
         this.color = color;
         this.offset = offset;
      }

      // $FF: synthetic method
      public Shadow(Rectangle var1, boolean var2, long var3, Vector2f var5, int var6, DefaultConstructorMarker var7) {
         if ((var6 & 2) != 0) {
            var2 = false;
         }

         if ((var6 & 4) != 0) {
            var3 = 1342177280L;
         }

         if ((var6 & 8) != 0) {
            var5 = new Vector2f(5.0F, 5.0F);
         }

         this(var1, var2, var3, var5);
      }

      @NotNull
      public final Rectangle getRect() {
         return this.rect;
      }

      public final boolean getOn() {
         return this.on;
      }

      public final void setOn(boolean var1) {
         this.on = var1;
      }

      public final long getColor() {
         return this.color;
      }

      public final void setColor(long var1) {
         this.color = var1;
      }

      @NotNull
      public final Vector2f getOffset() {
         return this.offset;
      }

      public final void setOffset(@NotNull Vector2f var1) {
         Intrinsics.checkNotNullParameter(var1, "<set-?>");
         this.offset = var1;
      }

      public final void draw() {
         if (this.on) {
            Renderer.drawRect(this.color, this.rect.x + this.offset.x, this.rect.y + this.rect.height, this.rect.width, this.offset.y);
            Renderer.drawRect(this.color, this.rect.x + this.rect.width, this.rect.y + this.offset.y, this.offset.x, this.rect.height - this.offset.y);
         }
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0010\n\u0002\u0010\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B+\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\t¢\u0006\u0002\u0010\nJ\u0006\u0010\u0019\u001a\u00020\u001aR\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u001a\u0010\b\u001a\u00020\tX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018¨\u0006\u001b"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/libs/renderer/Rectangle$Outline;", "", "rect", "Lcom/chattriggers/ctjs/minecraft/libs/renderer/Rectangle;", "on", "", "color", "", "thickness", "", "(Lcom/chattriggers/ctjs/minecraft/libs/renderer/Rectangle;ZJF)V", "getColor", "()J", "setColor", "(J)V", "getOn", "()Z", "setOn", "(Z)V", "getRect", "()Lcom/chattriggers/ctjs/minecraft/libs/renderer/Rectangle;", "getThickness", "()F", "setThickness", "(F)V", "draw", "", "ctjs"}
   )
   private static final class Outline {
      @NotNull
      private final Rectangle rect;
      private boolean on;
      private long color;
      private float thickness;

      public Outline(@NotNull Rectangle rect, boolean on, long color, float thickness) {
         Intrinsics.checkNotNullParameter(rect, "rect");
         super();
         this.rect = rect;
         this.on = on;
         this.color = color;
         this.thickness = thickness;
      }

      // $FF: synthetic method
      public Outline(Rectangle var1, boolean var2, long var3, float var5, int var6, DefaultConstructorMarker var7) {
         if ((var6 & 2) != 0) {
            var2 = false;
         }

         if ((var6 & 4) != 0) {
            var3 = 4278190080L;
         }

         if ((var6 & 8) != 0) {
            var5 = 5.0F;
         }

         this(var1, var2, var3, var5);
      }

      @NotNull
      public final Rectangle getRect() {
         return this.rect;
      }

      public final boolean getOn() {
         return this.on;
      }

      public final void setOn(boolean var1) {
         this.on = var1;
      }

      public final long getColor() {
         return this.color;
      }

      public final void setColor(long var1) {
         this.color = var1;
      }

      public final float getThickness() {
         return this.thickness;
      }

      public final void setThickness(float var1) {
         this.thickness = var1;
      }

      public final void draw() {
         if (this.on) {
            Renderer.drawRect(this.color, this.rect.x - this.thickness, this.rect.y - this.thickness, this.rect.width + this.thickness * (float)2, this.rect.height + this.thickness * (float)2);
         }
      }
   }
}
