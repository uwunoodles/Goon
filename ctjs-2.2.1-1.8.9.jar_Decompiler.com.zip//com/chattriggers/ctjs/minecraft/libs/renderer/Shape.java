package com.chattriggers.ctjs.minecraft.libs.renderer;

import com.chattriggers.ctjs.utils.kotlin.ExtensionsKt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.util.vector.Vector2f;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010 \n\u0002\b\u000f\n\u0002\u0010\u0002\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0016\u0010\r\u001a\u00020\u00002\u0006\u0010\u000e\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u0006J\u0006\u0010\u0010\u001a\u00020\u0000J\u0006\u0010\u0011\u001a\u00020\u0000J\u0006\u0010\u0012\u001a\u00020\u0000J\u0006\u0010\u0013\u001a\u00020\u0003J\u0006\u0010\u0014\u001a\u00020\bJ\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u000b0\u0016J\u001e\u0010\u0017\u001a\u00020\u00002\u0006\u0010\u0018\u001a\u00020\b2\u0006\u0010\u000e\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u0006J\u000e\u0010\u0019\u001a\u00020\u00002\u0006\u0010\u0018\u001a\u00020\bJ&\u0010\u001a\u001a\u00020\u00002\u0006\u0010\u000e\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u00062\u0006\u0010\u001b\u001a\u00020\u00062\u0006\u0010\u001c\u001a\u00020\bJ\u000e\u0010\u001d\u001a\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0003J\u000e\u0010\u001e\u001a\u00020\u00002\u0006\u0010\u0007\u001a\u00020\bJ.\u0010\u001f\u001a\u00020\u00002\u0006\u0010 \u001a\u00020\u00062\u0006\u0010!\u001a\u00020\u00062\u0006\u0010\"\u001a\u00020\u00062\u0006\u0010#\u001a\u00020\u00062\u0006\u0010$\u001a\u00020\u0006J\b\u0010%\u001a\u00020&H\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006'"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/libs/renderer/Shape;", "", "color", "", "(J)V", "area", "", "drawMode", "", "reversedVertexes", "", "Lorg/lwjgl/util/vector/Vector2f;", "vertexes", "addVertex", "x", "y", "clone", "copy", "draw", "getColor", "getDrawMode", "getVertexes", "", "insertVertex", "index", "removeVertex", "setCircle", "radius", "steps", "setColor", "setDrawMode", "setLine", "x1", "y1", "x2", "y2", "thickness", "updateArea", "", "ctjs"}
)
public final class Shape {
   private long color;
   @NotNull
   private final List<Vector2f> vertexes;
   @NotNull
   private final List<Vector2f> reversedVertexes;
   private int drawMode;
   private float area;

   public Shape(long color) {
      this.color = color;
      this.vertexes = (List)(new ArrayList());
      this.reversedVertexes = CollectionsKt.asReversedMutable(this.vertexes);
      this.drawMode = 9;
   }

   @NotNull
   public final Shape copy() {
      return this.clone();
   }

   @NotNull
   public final Shape clone() {
      Shape clone = new Shape(this.color);
      clone.vertexes.addAll((Collection)this.vertexes);
      clone.setDrawMode(this.drawMode);
      return clone;
   }

   public final long getColor() {
      return this.color;
   }

   @NotNull
   public final Shape setColor(long color) {
      Shape $this$setColor_u24lambda_u2d0 = (Shape)this;
      int var5 = false;
      $this$setColor_u24lambda_u2d0.color = Renderer.fixAlpha(color);
      return (Shape)this;
   }

   public final int getDrawMode() {
      return this.drawMode;
   }

   @NotNull
   public final Shape setDrawMode(int drawMode) {
      Shape $this$setDrawMode_u24lambda_u2d1 = (Shape)this;
      int var4 = false;
      $this$setDrawMode_u24lambda_u2d1.drawMode = drawMode;
      return (Shape)this;
   }

   @NotNull
   public final List<Vector2f> getVertexes() {
      return this.vertexes;
   }

   @NotNull
   public final Shape addVertex(float x, float y) {
      Shape $this$addVertex_u24lambda_u2d2 = (Shape)this;
      int var5 = false;
      $this$addVertex_u24lambda_u2d2.vertexes.add(new Vector2f(x, y));
      $this$addVertex_u24lambda_u2d2.updateArea();
      return (Shape)this;
   }

   @NotNull
   public final Shape insertVertex(int index, float x, float y) {
      Shape $this$insertVertex_u24lambda_u2d3 = (Shape)this;
      int var6 = false;
      $this$insertVertex_u24lambda_u2d3.vertexes.add(index, new Vector2f(x, y));
      $this$insertVertex_u24lambda_u2d3.updateArea();
      return (Shape)this;
   }

   @NotNull
   public final Shape removeVertex(int index) {
      Shape $this$removeVertex_u24lambda_u2d4 = (Shape)this;
      int var4 = false;
      $this$removeVertex_u24lambda_u2d4.vertexes.remove(index);
      $this$removeVertex_u24lambda_u2d4.updateArea();
      return (Shape)this;
   }

   @NotNull
   public final Shape setLine(float x1, float y1, float x2, float y2, float thickness) {
      Shape $this$setLine_u24lambda_u2d5 = (Shape)this;
      int var8 = false;
      $this$setLine_u24lambda_u2d5.vertexes.clear();
      float i = y2 - y1;
      float j = x2 - x1;
      float theta = -((float)Math.atan2((double)i, (double)j));
      i = (float)Math.sin((double)theta) * (thickness / (float)2);
      j = (float)Math.cos((double)theta) * (thickness / (float)2);
      $this$setLine_u24lambda_u2d5.addVertex(x1 + i, y1 + j);
      $this$setLine_u24lambda_u2d5.addVertex(x2 + i, y2 + j);
      $this$setLine_u24lambda_u2d5.addVertex(x2 - i, y2 - j);
      $this$setLine_u24lambda_u2d5.addVertex(x1 - i, y1 - j);
      $this$setLine_u24lambda_u2d5.drawMode = 7;
      return (Shape)this;
   }

   @NotNull
   public final Shape setCircle(float x, float y, float radius, int steps) {
      Shape $this$setCircle_u24lambda_u2d6 = (Shape)this;
      int var7 = false;
      $this$setCircle_u24lambda_u2d6.vertexes.clear();
      double theta = 6.283185307179586D / (double)steps;
      float cos = (float)Math.cos(theta);
      float sin = (float)Math.sin(theta);
      float xHolder = 0.0F;
      float circleX = 1.0F;
      float circleY = 0.0F;
      int var15 = 0;
      int i;
      if (var15 <= steps) {
         do {
            i = var15++;
            $this$setCircle_u24lambda_u2d6.addVertex(x, y);
            $this$setCircle_u24lambda_u2d6.addVertex(circleX * radius + x, circleY * radius + y);
            xHolder = circleX;
            circleX = cos * circleX - sin * circleY;
            circleY = sin * xHolder + cos * circleY;
            $this$setCircle_u24lambda_u2d6.addVertex(circleX * radius + x, circleY * radius + y);
         } while(i != steps);
      }

      $this$setCircle_u24lambda_u2d6.drawMode = 5;
      return (Shape)this;
   }

   @NotNull
   public final Shape draw() {
      Shape $this$draw_u24lambda_u2d9 = (Shape)this;
      int var3 = false;
      Tessellator tessellator = Tessellator.func_178181_a();
      Intrinsics.checkNotNullExpressionValue(tessellator, "tessellator");
      WorldRenderer worldRenderer = ExtensionsKt.getRenderer(tessellator);
      GlStateManager.func_179147_l();
      GlStateManager.func_179090_x();
      GlStateManager.func_179120_a(770, 771, 1, 0);
      Renderer.INSTANCE.doColor$ctjs($this$draw_u24lambda_u2d9.color);
      worldRenderer.func_181668_a($this$draw_u24lambda_u2d9.drawMode, DefaultVertexFormats.field_181705_e);
      Iterable $this$forEach$iv;
      boolean $i$f$forEach;
      Iterator var8;
      Object element$iv;
      Vector2f it;
      boolean var11;
      if ($this$draw_u24lambda_u2d9.area < 0.0F) {
         $this$forEach$iv = (Iterable)$this$draw_u24lambda_u2d9.vertexes;
         $i$f$forEach = false;
         var8 = $this$forEach$iv.iterator();

         while(var8.hasNext()) {
            element$iv = var8.next();
            it = (Vector2f)element$iv;
            var11 = false;
            worldRenderer.func_181662_b((double)it.x, (double)it.y, 0.0D).func_181675_d();
         }
      } else {
         $this$forEach$iv = (Iterable)$this$draw_u24lambda_u2d9.reversedVertexes;
         $i$f$forEach = false;
         var8 = $this$forEach$iv.iterator();

         while(var8.hasNext()) {
            element$iv = var8.next();
            it = (Vector2f)element$iv;
            var11 = false;
            worldRenderer.func_181662_b((double)it.x, (double)it.y, 0.0D).func_181675_d();
         }
      }

      tessellator.func_78381_a();
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.func_179098_w();
      GlStateManager.func_179084_k();
      Renderer.finishDraw();
      return (Shape)this;
   }

   private final void updateArea() {
      this.area = 0.0F;
      int var1 = 0;

      Vector2f p1;
      Vector2f p2;
      for(int var2 = this.vertexes.size(); var1 < var2; this.area += p1.x * p2.y - p2.x * p1.y) {
         int i = var1++;
         p1 = (Vector2f)this.vertexes.get(i);
         p2 = (Vector2f)this.vertexes.get((i + 1) % this.vertexes.size());
      }

      this.area /= (float)2;
   }
}
