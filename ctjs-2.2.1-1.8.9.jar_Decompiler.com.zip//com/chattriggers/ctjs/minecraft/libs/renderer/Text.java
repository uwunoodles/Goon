package com.chattriggers.ctjs.minecraft.libs.renderer;

import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.minecraft.objects.display.DisplayHandler;
import com.chattriggers.ctjs.utils.kotlin.ExtensionsKt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import kotlin.Metadata;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import net.minecraft.client.renderer.GlStateManager;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mozilla.javascript.NativeObject;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010!\n\u0000\n\u0002\u0010\b\n\u0002\b\f\n\u0002\u0010 \n\u0002\b\u0015\n\u0002\u0010\u0002\n\u0000\u0018\u00002\u00020\u0001B#\b\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005¢\u0006\u0002\u0010\u0007B\u0017\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\t¢\u0006\u0002\u0010\nJ%\u0010\u0019\u001a\u00020\u00002\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005H\u0007¢\u0006\u0002\u0010\u001aJ\u0006\u0010\u001b\u001a\u00020\u0010J\u0006\u0010\u001c\u001a\u00020\fJ\u0006\u0010\u001d\u001a\u00020\u000eJ\u0006\u0010\u001e\u001a\u00020\u0010J\u0006\u0010\u001f\u001a\u00020\u0005J\f\u0010 \u001a\b\u0012\u0004\u0012\u00020\u00030!J\u0006\u0010\"\u001a\u00020\u0014J\u0006\u0010#\u001a\u00020\u0014J\u0006\u0010$\u001a\u00020\u0005J\u0006\u0010%\u001a\u00020\u0010J\u0006\u0010&\u001a\u00020\u0003J\u0006\u0010'\u001a\u00020\u0005J\u0006\u0010(\u001a\u00020\u0005J\u0018\u0010)\u001a\u00020\u00052\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0002J\u0006\u0010*\u001a\u00020\u0005J\u000e\u0010+\u001a\u00020\u00002\u0006\u0010\u000b\u001a\u00020\u0001J\u000e\u0010,\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u000eJ\u000e\u0010-\u001a\u00020\u00002\u0006\u0010\u000f\u001a\u00020\u0010J\u000e\u0010.\u001a\u00020\u00002\u0006\u0010\u0013\u001a\u00020\u0014J\u000e\u0010/\u001a\u00020\u00002\u0006\u0010\u0015\u001a\u00020\u0014J\u000e\u00100\u001a\u00020\u00002\u0006\u0010\u0016\u001a\u00020\u0005J\u000e\u00101\u001a\u00020\u00002\u0006\u0010\u0017\u001a\u00020\u0010J\u000e\u00102\u001a\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0003J\u000e\u00103\u001a\u00020\u00002\u0006\u0010\u0004\u001a\u00020\u0005J\u000e\u00104\u001a\u00020\u00002\u0006\u0010\u0006\u001a\u00020\u0005J\b\u00105\u001a\u00020\u0003H\u0016J\b\u00106\u001a\u000207H\u0002R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00030\u0012X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u00068"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/libs/renderer/Text;", "", "string", "", "x", "", "y", "(Ljava/lang/String;FF)V", "config", "Lorg/mozilla/javascript/NativeObject;", "(Ljava/lang/String;Lorg/mozilla/javascript/NativeObject;)V", "align", "Lcom/chattriggers/ctjs/minecraft/objects/display/DisplayHandler$Align;", "color", "", "formatted", "", "lines", "", "maxLines", "", "maxWidth", "scale", "shadow", "width", "draw", "(Ljava/lang/Float;Ljava/lang/Float;)Lcom/chattriggers/ctjs/minecraft/libs/renderer/Text;", "exceedsMaxLines", "getAlign", "getColor", "getFormatted", "getHeight", "getLines", "", "getMaxLines", "getMaxWidth", "getScale", "getShadow", "getString", "getWidth", "getX", "getXAlign", "getY", "setAlign", "setColor", "setFormatted", "setMaxLines", "setMaxWidth", "setScale", "setShadow", "setString", "setX", "setY", "toString", "updateFormatting", "", "ctjs"}
)
public final class Text {
   private String string;
   private float x;
   private float y;
   @NotNull
   private final List<String> lines;
   private long color;
   private boolean formatted;
   private boolean shadow;
   @NotNull
   private DisplayHandler.Align align;
   private float width;
   private int maxWidth;
   private int maxLines;
   private float scale;

   @JvmOverloads
   public Text(@NotNull String string, float x, float y) {
      Intrinsics.checkNotNullParameter(string, "string");
      super();
      this.lines = (List)(new ArrayList());
      this.color = 4294967295L;
      this.formatted = true;
      this.align = DisplayHandler.Align.LEFT;
      this.maxLines = Integer.MAX_VALUE;
      this.scale = 1.0F;
      this.setString(string);
      this.setX(x);
      this.setY(y);
   }

   // $FF: synthetic method
   public Text(String var1, float var2, float var3, int var4, DefaultConstructorMarker var5) {
      if ((var4 & 2) != 0) {
         var2 = 0.0F;
      }

      if ((var4 & 4) != 0) {
         var3 = 0.0F;
      }

      this(var1, var2, var3);
   }

   public Text(@NotNull String string, @NotNull NativeObject config) {
      Intrinsics.checkNotNullParameter(string, "string");
      Intrinsics.checkNotNullParameter(config, "config");
      super();
      this.lines = (List)(new ArrayList());
      this.color = 4294967295L;
      this.formatted = true;
      this.align = DisplayHandler.Align.LEFT;
      this.maxLines = Integer.MAX_VALUE;
      this.scale = 1.0F;
      this.setString(string);
      this.setColor(Long.parseLong(ExtensionsKt.getOption(config, "color", 4294967295L)));
      this.setFormatted(Boolean.parseBoolean(ExtensionsKt.getOption(config, "formatted", true)));
      this.setShadow(Boolean.parseBoolean(ExtensionsKt.getOption(config, "shadow", false)));
      this.setAlign(ExtensionsKt.getOption(config, "align", DisplayHandler.Align.LEFT));
      this.setX(Float.parseFloat(ExtensionsKt.getOption(config, "x", 0.0F)));
      this.setY(Float.parseFloat(ExtensionsKt.getOption(config, "y", 0.0F)));
      this.setMaxLines((int)Double.parseDouble(ExtensionsKt.getOption(config, "maxLines", Integer.MAX_VALUE)));
      this.setScale(Float.parseFloat(ExtensionsKt.getOption(config, "scale", 1.0F)));
      this.setMaxWidth(Integer.parseInt(ExtensionsKt.getOption(config, "maxWidth", 0)));
   }

   @NotNull
   public final String getString() {
      String var10000 = this.string;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("string");
         var10000 = null;
      }

      return var10000;
   }

   @NotNull
   public final Text setString(@NotNull String string) {
      Intrinsics.checkNotNullParameter(string, "string");
      Text $this$setString_u24lambda_u2d0 = (Text)this;
      int var4 = false;
      $this$setString_u24lambda_u2d0.string = string;
      $this$setString_u24lambda_u2d0.updateFormatting();
      return (Text)this;
   }

   public final long getColor() {
      return this.color;
   }

   @NotNull
   public final Text setColor(long color) {
      Text $this$setColor_u24lambda_u2d1 = (Text)this;
      int var5 = false;
      $this$setColor_u24lambda_u2d1.color = Renderer.fixAlpha(color);
      return (Text)this;
   }

   public final boolean getFormatted() {
      return this.formatted;
   }

   @NotNull
   public final Text setFormatted(boolean formatted) {
      Text $this$setFormatted_u24lambda_u2d2 = (Text)this;
      int var4 = false;
      $this$setFormatted_u24lambda_u2d2.formatted = formatted;
      $this$setFormatted_u24lambda_u2d2.updateFormatting();
      return (Text)this;
   }

   public final boolean getShadow() {
      return this.shadow;
   }

   @NotNull
   public final Text setShadow(boolean shadow) {
      Text $this$setShadow_u24lambda_u2d3 = (Text)this;
      int var4 = false;
      $this$setShadow_u24lambda_u2d3.shadow = shadow;
      return (Text)this;
   }

   @NotNull
   public final DisplayHandler.Align getAlign() {
      return this.align;
   }

   @NotNull
   public final Text setAlign(@NotNull Object align) {
      Intrinsics.checkNotNullParameter(align, "align");
      Text $this$setAlign_u24lambda_u2d4 = (Text)this;
      int var4 = false;
      DisplayHandler.Align var6;
      if (align instanceof String) {
         String var10001 = ((String)align).toUpperCase(Locale.ROOT);
         Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).toUpperCase(Locale.ROOT)");
         var6 = DisplayHandler.Align.valueOf(var10001);
      } else {
         var6 = align instanceof DisplayHandler.Align ? (DisplayHandler.Align)align : DisplayHandler.Align.LEFT;
      }

      $this$setAlign_u24lambda_u2d4.align = var6;
      return (Text)this;
   }

   public final float getX() {
      return this.x;
   }

   @NotNull
   public final Text setX(float x) {
      Text $this$setX_u24lambda_u2d5 = (Text)this;
      int var4 = false;
      $this$setX_u24lambda_u2d5.x = x;
      return (Text)this;
   }

   public final float getY() {
      return this.y;
   }

   @NotNull
   public final Text setY(float y) {
      Text $this$setY_u24lambda_u2d6 = (Text)this;
      int var4 = false;
      $this$setY_u24lambda_u2d6.y = y;
      return (Text)this;
   }

   public final float getWidth() {
      return this.width;
   }

   @NotNull
   public final List<String> getLines() {
      return this.lines;
   }

   public final int getMaxLines() {
      return this.maxLines;
   }

   @NotNull
   public final Text setMaxLines(int maxLines) {
      Text $this$setMaxLines_u24lambda_u2d7 = (Text)this;
      int var4 = false;
      $this$setMaxLines_u24lambda_u2d7.maxLines = maxLines;
      return (Text)this;
   }

   public final float getScale() {
      return this.scale;
   }

   @NotNull
   public final Text setScale(float scale) {
      Text $this$setScale_u24lambda_u2d8 = (Text)this;
      int var4 = false;
      $this$setScale_u24lambda_u2d8.scale = scale;
      return (Text)this;
   }

   @NotNull
   public final Text setMaxWidth(int maxWidth) {
      Text $this$setMaxWidth_u24lambda_u2d9 = (Text)this;
      int var4 = false;
      $this$setMaxWidth_u24lambda_u2d9.maxWidth = maxWidth;
      $this$setMaxWidth_u24lambda_u2d9.updateFormatting();
      return (Text)this;
   }

   public final int getMaxWidth() {
      return this.maxWidth;
   }

   public final float getHeight() {
      return this.lines.size() > 1 ? (float)RangesKt.coerceAtMost(this.lines.size(), this.maxLines) * this.scale * (float)10 : this.scale * (float)10;
   }

   public final boolean exceedsMaxLines() {
      return this.lines.size() > this.maxLines;
   }

   @JvmOverloads
   @NotNull
   public final Text draw(@Nullable Float x, @Nullable Float y) {
      Text $this$draw_u24lambda_u2d11 = (Text)this;
      int var5 = false;
      GlStateManager.func_179147_l();
      GlStateManager.func_179152_a($this$draw_u24lambda_u2d11.scale, $this$draw_u24lambda_u2d11.scale, $this$draw_u24lambda_u2d11.scale);
      Iterator var7 = ((Iterable)$this$draw_u24lambda_u2d11.lines).iterator();
      if (!var7.hasNext()) {
         throw new NoSuchElementException();
      } else {
         String it = (String)var7.next();
         int var9 = false;

         float var13;
         float var16;
         for(var13 = (float)Renderer.getStringWidth(it) * $this$draw_u24lambda_u2d11.scale; var7.hasNext(); var13 = Math.max(var13, var16)) {
            String it = (String)var7.next();
            int var10 = false;
            var16 = (float)Renderer.getStringWidth(it) * $this$draw_u24lambda_u2d11.scale;
         }

         float longestLine = var13;
         if ($this$draw_u24lambda_u2d11.maxWidth != 0) {
            longestLine = RangesKt.coerceAtMost(var13, (float)$this$draw_u24lambda_u2d11.maxWidth);
         }

         $this$draw_u24lambda_u2d11.width = longestLine;
         float yHolder = y == null ? $this$draw_u24lambda_u2d11.y : y;
         int var12 = 0;

         for(int var14 = $this$draw_u24lambda_u2d11.maxLines; var12 < var14; yHolder += $this$draw_u24lambda_u2d11.scale * (float)10) {
            int i = var12++;
            if (i >= $this$draw_u24lambda_u2d11.lines.size()) {
               break;
            }

            Renderer.getFontRenderer().func_175065_a((String)$this$draw_u24lambda_u2d11.lines.get(i), $this$draw_u24lambda_u2d11.getXAlign((String)$this$draw_u24lambda_u2d11.lines.get(i), x == null ? $this$draw_u24lambda_u2d11.x : x), yHolder / $this$draw_u24lambda_u2d11.scale, (int)$this$draw_u24lambda_u2d11.color, $this$draw_u24lambda_u2d11.shadow);
         }

         GlStateManager.func_179084_k();
         Renderer.finishDraw();
         return (Text)this;
      }
   }

   // $FF: synthetic method
   public static Text draw$default(Text var0, Float var1, Float var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = null;
      }

      if ((var3 & 2) != 0) {
         var2 = null;
      }

      return var0.draw(var1, var2);
   }

   private final void updateFormatting() {
      String var10001;
      if (this.formatted) {
         var10001 = this.string;
         if (var10001 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("string");
            var10001 = null;
         }

         var10001 = ChatLib.addColor(var10001);
      } else {
         var10001 = this.string;
         if (var10001 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("string");
            var10001 = null;
         }

         var10001 = ChatLib.replaceFormatting(var10001);
      }

      this.string = var10001;
      this.lines.clear();
      String var10000 = this.string;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("string");
         var10000 = null;
      }

      CharSequence var9 = (CharSequence)var10000;
      String[] var1 = new String[]{"\n"};
      Iterable $this$forEach$iv = (Iterable)StringsKt.split$default(var9, var1, false, 0, 6, (Object)null);
      int $i$f$forEach = false;
      Iterator var3 = $this$forEach$iv.iterator();

      while(var3.hasNext()) {
         Object element$iv = var3.next();
         String it = (String)element$iv;
         int var6 = false;
         if (this.maxWidth > 0) {
            List var10 = this.lines;
            List var7 = Renderer.getFontRenderer().func_78271_c(it, this.maxWidth);
            Intrinsics.checkNotNullExpressionValue(var7, "getFontRenderer().listFo…ringToWidth(it, maxWidth)");
            var10.addAll((Collection)var7);
         } else {
            this.lines.add(it);
         }
      }

   }

   private final float getXAlign(String string, float x) {
      float newX = x / this.scale;
      float var10000;
      switch(Text.WhenMappings.$EnumSwitchMapping$0[this.align.ordinal()]) {
      case 1:
         var10000 = newX - (float)(Renderer.getStringWidth(string) / 2);
         break;
      case 2:
         var10000 = newX - (float)Renderer.getStringWidth(string);
         break;
      default:
         var10000 = newX;
      }

      return var10000;
   }

   @NotNull
   public String toString() {
      StringBuilder var1 = new StringBuilder();
      StringBuilder var10000 = var1.append("Text{string=");
      String var10001 = this.string;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("string");
         var10001 = null;
      }

      var10000.append(var10001).append(", x=").append(this.x).append(", y=").append(this.y).append(", lines=").append(this.lines).append(", color=").append(this.color).append(", scale=").append(this.scale).append(", formatted=").append(this.formatted).append(", shadow=").append(this.shadow).append(", align=").append(this.align).append(", width=").append(this.width).append(", maxWidth=").append(this.maxWidth).append(", maxLines=");
      var1.append(this.maxLines).append('}');
      return var1.toString();
   }

   @JvmOverloads
   public Text(@NotNull String string, float x) {
      Intrinsics.checkNotNullParameter(string, "string");
      this(string, x, 0.0F, 4, (DefaultConstructorMarker)null);
   }

   @JvmOverloads
   public Text(@NotNull String string) {
      Intrinsics.checkNotNullParameter(string, "string");
      this(string, 0.0F, 0.0F, 6, (DefaultConstructorMarker)null);
   }

   @JvmOverloads
   @NotNull
   public final Text draw(@Nullable Float x) {
      return draw$default(this, x, (Float)null, 2, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final Text draw() {
      return draw$default(this, (Float)null, (Float)null, 3, (Object)null);
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[DisplayHandler.Align.values().length];
         var0[DisplayHandler.Align.CENTER.ordinal()] = 1;
         var0[DisplayHandler.Align.RIGHT.ordinal()] = 2;
         $EnumSwitchMapping$0 = var0;
      }
   }
}
