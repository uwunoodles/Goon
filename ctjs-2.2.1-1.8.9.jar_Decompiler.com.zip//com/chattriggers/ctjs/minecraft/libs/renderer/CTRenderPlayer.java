package com.chattriggers.ctjs.minecraft.libs.renderer;

import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.client.renderer.entity.layers.LayerArrow;
import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
import net.minecraft.client.renderer.entity.layers.LayerCape;
import net.minecraft.client.renderer.entity.layers.LayerCustomHead;
import net.minecraft.client.renderer.entity.layers.LayerDeadmau5Head;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0005\b\u0000\u0018\u00002\u00020\u0001B\u0017\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u0012\u0010\f\u001a\u00020\u00052\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0014J<\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u000e2\b\u0010\u0012\u001a\u0004\u0018\u00010\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0017\u001a\u00020\u00152\u0006\u0010\u0018\u001a\u00020\u0019H\u0014J*\u0010\u001a\u001a\u00020\u00102\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0017\u001a\u00020\u0015H\u0016JD\u0010\u001b\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0017\u001a\u00020\u00152\b\u0010\u0012\u001a\u0004\u0018\u00010\u00132\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u0015H\u0014J\u0010\u0010\u001f\u001a\u00020\u00102\u0006\u0010 \u001a\u00020\u000eH\u0014J.\u0010!\u001a\u00020\u00102\u0006\u0010\u000b\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0005R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\""},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/libs/renderer/CTRenderPlayer;", "Lnet/minecraft/client/renderer/entity/RenderPlayer;", "renderManager", "Lnet/minecraft/client/renderer/entity/RenderManager;", "useSmallArms", "", "(Lnet/minecraft/client/renderer/entity/RenderManager;Z)V", "showArmor", "showArrows", "showCape", "showHeldItem", "showNametag", "canRenderName", "entity", "Lnet/minecraft/client/entity/AbstractClientPlayer;", "renderLivingLabel", "", "entityIn", "str", "", "x", "", "y", "z", "maxDistance", "", "renderName", "renderOffsetLivingLabel", "p_177069_9_", "", "p_177069_10_", "setModelVisibilities", "clientPlayer", "setOptions", "ctjs"}
)
public final class CTRenderPlayer extends RenderPlayer {
   private boolean showNametag = true;
   private boolean showArmor = true;
   private boolean showCape = true;
   private boolean showHeldItem = true;
   private boolean showArrows = true;

   public CTRenderPlayer(@Nullable RenderManager renderManager, boolean useSmallArms) {
      super(renderManager, useSmallArms);
   }

   public final void setOptions(boolean showNametag, boolean showArmor, boolean showCape, boolean showHeldItem, boolean showArrows) {
      this.showNametag = showNametag;
      this.showArmor = showArmor;
      this.showCape = showCape;
      this.showHeldItem = showHeldItem;
      this.showArrows = showArrows;
      this.field_177097_h = (List)(new ArrayList());
      if (showArmor) {
         this.func_177094_a((LayerRenderer)(new LayerBipedArmor((RendererLivingEntity)this)));
      }

      if (showHeldItem) {
         this.func_177094_a((LayerRenderer)(new LayerHeldItem((RendererLivingEntity)this)));
      }

      if (showArrows) {
         this.func_177094_a((LayerRenderer)(new LayerArrow((RendererLivingEntity)this)));
      }

      this.func_177094_a((LayerRenderer)(new LayerDeadmau5Head((RenderPlayer)this)));
      if (showCape) {
         this.func_177094_a((LayerRenderer)(new LayerCape((RenderPlayer)this)));
      }

      if (showArmor) {
         this.func_177094_a((LayerRenderer)(new LayerCustomHead(this.func_177087_b().field_78116_c)));
      }

   }

   protected void func_177137_d(@NotNull AbstractClientPlayer clientPlayer) {
      Intrinsics.checkNotNullParameter(clientPlayer, "clientPlayer");
      super.func_177137_d(clientPlayer);
      if (!this.showHeldItem) {
         this.func_177087_b().field_78120_m = 0;
      }

   }

   protected boolean canRenderName(@Nullable AbstractClientPlayer entity) {
      return this.showNametag;
   }

   protected void func_177069_a(@Nullable AbstractClientPlayer entityIn, double x, double y, double z, @Nullable String str, float p_177069_9_, double p_177069_10_) {
      if (this.showNametag) {
         super.func_177069_a(entityIn, x, y, z, str, p_177069_9_, p_177069_10_);
      }

   }

   public void renderName(@Nullable AbstractClientPlayer entity, double x, double y, double z) {
      if (this.showNametag) {
         super.func_177067_a((EntityLivingBase)entity, x, y, z);
      }

   }

   protected void renderLivingLabel(@Nullable AbstractClientPlayer entityIn, @Nullable String str, double x, double y, double z, int maxDistance) {
      if (this.showNametag) {
         super.func_147906_a((Entity)entityIn, str, x, y, z, maxDistance);
      }

   }
}
