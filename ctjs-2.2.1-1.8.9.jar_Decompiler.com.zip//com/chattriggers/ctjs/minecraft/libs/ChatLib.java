package com.chattriggers.ctjs.minecraft.libs;

import com.chattriggers.ctjs.ReferenceKt;
import com.chattriggers.ctjs.minecraft.libs.renderer.Renderer;
import com.chattriggers.ctjs.minecraft.listeners.ClientListener;
import com.chattriggers.ctjs.minecraft.objects.message.Message;
import com.chattriggers.ctjs.minecraft.objects.message.TextComponent;
import com.chattriggers.ctjs.minecraft.wrappers.Client;
import com.chattriggers.ctjs.minecraft.wrappers.Player;
import com.chattriggers.ctjs.utils.console.Console;
import com.chattriggers.ctjs.utils.console.LogType;
import com.chattriggers.ctjs.utils.kotlin.ExtensionsKt;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Regex;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.ChatLine;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.IChatComponent;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mozilla.javascript.regexp.NativeRegExp;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000l\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0015\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\b\u000b\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0001H\u0007J\u0012\u0010\u0006\u001a\u00020\u00072\b\u0010\b\u001a\u0004\u0018\u00010\u0007H\u0007J\u001a\u0010\t\u001a\u00020\u00042\b\b\u0002\u0010\n\u001a\u00020\u000b2\u0006\u0010\b\u001a\u00020\u0007H\u0007J\u0010\u0010\f\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0001H\u0007J\u0014\u0010\r\u001a\u00020\u00042\n\u0010\u000e\u001a\u00020\u000f\"\u00020\u000bH\u0007J\u001a\u0010\u0010\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00072\b\b\u0002\u0010\u0011\u001a\u00020\u0012H\u0007J\u001c\u0010\u0013\u001a\u00020\u00042\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u00120\u0015H\u0002J\u0010\u0010\u0013\u001a\u00020\u00042\u0006\u0010\u0014\u001a\u00020\u0016H\u0007J\u0010\u0010\u0013\u001a\u00020\u00042\u0006\u0010\u0017\u001a\u00020\u000bH\u0007J\u0010\u0010\u0013\u001a\u00020\u00042\u0006\u0010\u0014\u001a\u00020\u0007H\u0007J\u0010\u0010\u0013\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0019H\u0007J*\u0010\u001a\u001a\u00020\u00042\f\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001c2\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u00120\u0015H\u0002J5\u0010\u001e\u001a\u00020\u00042\u0012\u0010\u001f\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u00120\u00152\u0012\u0010 \u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00160!\"\u00020\u0016H\u0002¢\u0006\u0002\u0010\"J)\u0010\u001e\u001a\u00020\u00042\u0006\u0010\u001f\u001a\u00020\u00162\u0012\u0010 \u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00160!\"\u00020\u0016H\u0007¢\u0006\u0002\u0010#J)\u0010\u001e\u001a\u00020\u00042\u0006\u0010\u0017\u001a\u00020\u000b2\u0012\u0010 \u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00160!\"\u00020\u0016H\u0007¢\u0006\u0002\u0010$J)\u0010\u001e\u001a\u00020\u00042\u0006\u0010\u001f\u001a\u00020\u00072\u0012\u0010 \u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00160!\"\u00020\u0016H\u0007¢\u0006\u0002\u0010%J)\u0010\u001e\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u00192\u0012\u0010 \u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00160!\"\u00020\u0016H\u0007¢\u0006\u0002\u0010&JC\u0010'\u001a\u00020\u00042\f\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001c2\u0012\u0010\u001f\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u00120\u00152\u0012\u0010 \u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00160!\"\u00020\u0016H\u0002¢\u0006\u0002\u0010(J\u0010\u0010)\u001a\u00020\u00072\u0006\u0010\u0005\u001a\u00020\u0007H\u0007J\u0012\u0010*\u001a\u00020\u00072\b\b\u0002\u0010+\u001a\u00020\u0007H\u0007J\u000e\u0010,\u001a\b\u0012\u0004\u0012\u00020\u00070-H\u0007J\u001a\u0010.\u001a\u00020\u00072\u0006\u0010/\u001a\u0002002\b\b\u0002\u00101\u001a\u00020\u0012H\u0007J\b\u00102\u001a\u00020\u000bH\u0007J\u000e\u00103\u001a\u00020\u00122\u0006\u00104\u001a\u00020\u0007J\u0010\u00105\u001a\u00020\u00072\u0006\u0010\u0005\u001a\u00020\u0007H\u0007J\u0010\u00106\u001a\u00020\u00072\u0006\u0010\u0005\u001a\u00020\u0007H\u0007J\u0017\u00107\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0007H\u0007¢\u0006\u0002\u00108J\u0010\u00109\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0001H\u0007¨\u0006:"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/libs/ChatLib;", "", "()V", "actionBar", "", "text", "addColor", "", "message", "addToSentMessageHistory", "index", "", "chat", "clearChat", "chatLineIDs", "", "command", "clientSide", "", "deleteChat", "toDelete", "Lkotlin/Function1;", "Lcom/chattriggers/ctjs/minecraft/objects/message/Message;", "chatLineId", "regexp", "Lorg/mozilla/javascript/regexp/NativeRegExp;", "deleteChatLineList", "lineList", "", "Lnet/minecraft/client/gui/ChatLine;", "editChat", "toReplace", "replacements", "", "(Lkotlin/jvm/functions/Function1;[Lcom/chattriggers/ctjs/minecraft/objects/message/Message;)V", "(Lcom/chattriggers/ctjs/minecraft/objects/message/Message;[Lcom/chattriggers/ctjs/minecraft/objects/message/Message;)V", "(I[Lcom/chattriggers/ctjs/minecraft/objects/message/Message;)V", "(Ljava/lang/String;[Lcom/chattriggers/ctjs/minecraft/objects/message/Message;)V", "(Lorg/mozilla/javascript/regexp/NativeRegExp;[Lcom/chattriggers/ctjs/minecraft/objects/message/Message;)V", "editChatLineList", "(Ljava/util/List;Lkotlin/jvm/functions/Function1;[Lcom/chattriggers/ctjs/minecraft/objects/message/Message;)V", "getCenteredText", "getChatBreak", "separator", "getChatLines", "", "getChatMessage", "event", "Lnet/minecraftforge/client/event/ClientChatReceivedEvent;", "formatted", "getChatWidth", "isPlayer", "out", "removeFormatting", "replaceFormatting", "say", "(Ljava/lang/String;)Lkotlin/Unit;", "simulateChat", "ctjs"}
)
public final class ChatLib {
   @NotNull
   public static final ChatLib INSTANCE = new ChatLib();

   private ChatLib() {
   }

   @JvmStatic
   public static final void chat(@NotNull Object text) {
      Intrinsics.checkNotNullParameter(text, "text");
      Object[] var2;
      if (text instanceof String) {
         var2 = new Object[]{text};
         (new Message(var2)).chat();
      } else if (text instanceof Message) {
         ((Message)text).chat();
      } else if (text instanceof TextComponent) {
         ((TextComponent)text).chat();
      } else {
         var2 = new Object[]{text.toString()};
         (new Message(var2)).chat();
      }

   }

   @JvmStatic
   public static final void actionBar(@NotNull Object text) {
      Intrinsics.checkNotNullParameter(text, "text");
      Object[] var2;
      if (text instanceof String) {
         var2 = new Object[]{text};
         (new Message(var2)).actionBar();
      } else if (text instanceof Message) {
         ((Message)text).actionBar();
      } else if (text instanceof TextComponent) {
         ((TextComponent)text).actionBar();
      } else {
         var2 = new Object[]{text.toString()};
         (new Message(var2)).actionBar();
      }

   }

   @JvmStatic
   public static final void simulateChat(@NotNull Object text) {
      Intrinsics.checkNotNullParameter(text, "text");
      Object[] var2;
      if (text instanceof String) {
         var2 = new Object[]{text};
         (new Message(var2)).setRecursive(true).chat();
      } else if (text instanceof Message) {
         ((Message)text).setRecursive(true).chat();
      } else if (text instanceof TextComponent) {
         var2 = new Object[]{text};
         (new Message(var2)).setRecursive(true).chat();
      } else {
         var2 = new Object[]{text.toString()};
         (new Message(var2)).setRecursive(true).chat();
      }

   }

   @JvmStatic
   @Nullable
   public static final Unit say(@NotNull String text) {
      Intrinsics.checkNotNullParameter(text, "text");
      EntityPlayerSP var10000 = Player.getPlayer();
      Unit var1;
      if (var10000 == null) {
         var1 = null;
      } else {
         var10000.func_71165_d(text);
         var1 = Unit.INSTANCE;
      }

      return var1;
   }

   @JvmStatic
   @JvmOverloads
   public static final void command(@NotNull String text, boolean clientSide) {
      Intrinsics.checkNotNullParameter(text, "text");
      if (clientSide) {
         ClientCommandHandler.instance.func_71556_a((ICommandSender)Player.getPlayer(), Intrinsics.stringPlus("/", text));
      } else {
         ChatLib var10000 = INSTANCE;
         say(Intrinsics.stringPlus("/", text));
      }

   }

   // $FF: synthetic method
   public static void command$default(String var0, boolean var1, int var2, Object var3) {
      if ((var2 & 2) != 0) {
         var1 = false;
      }

      command(var0, var1);
   }

   @JvmStatic
   public static final void clearChat(@NotNull int... chatLineIDs) {
      Intrinsics.checkNotNullParameter(chatLineIDs, "chatLineIDs");
      GuiNewChat var10000;
      if (chatLineIDs.length == 0) {
         var10000 = Client.Companion.getChatGUI();
         if (var10000 != null) {
            var10000.func_146231_a();
         }

      } else {
         int var1 = 0;
         int var2 = chatLineIDs.length;

         while(var1 < var2) {
            int chatLineID = chatLineIDs[var1];
            ++var1;
            var10000 = Client.Companion.getChatGUI();
            if (var10000 != null) {
               var10000.func_146242_c(chatLineID);
            }
         }

      }
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final String getChatBreak(@NotNull String separator) {
      Intrinsics.checkNotNullParameter(separator, "separator");
      int len = Renderer.getStringWidth(separator);
      ChatLib var10000 = INSTANCE;
      int times = getChatWidth() / len;
      return ExtensionsKt.times(separator, (Number)times);
   }

   // $FF: synthetic method
   public static String getChatBreak$default(String var0, int var1, Object var2) {
      if ((var1 & 1) != 0) {
         var0 = "-";
      }

      return getChatBreak(var0);
   }

   @JvmStatic
   public static final int getChatWidth() {
      GuiNewChat var10000 = Client.Companion.getChatGUI();
      int var1;
      if (var10000 == null) {
         var1 = 0;
      } else {
         int var0 = var10000.func_146228_f();
         var1 = var0;
      }

      return var1;
   }

   @JvmStatic
   @NotNull
   public static final String removeFormatting(@NotNull String text) {
      Intrinsics.checkNotNullParameter(text, "text");
      CharSequence var1 = (CharSequence)text;
      Regex var2 = new Regex("[§&][0-9a-fk-or]");
      String var3 = "";
      return var2.replace(var1, var3);
   }

   @JvmStatic
   @NotNull
   public static final String replaceFormatting(@NotNull String text) {
      Intrinsics.checkNotNullParameter(text, "text");
      CharSequence var1 = (CharSequence)text;
      Regex var2 = new Regex("§(?![^0-9a-fk-or]|$)");
      String var3 = "&";
      return var2.replace(var1, var3);
   }

   @JvmStatic
   @NotNull
   public static final String getCenteredText(@NotNull String text) {
      Intrinsics.checkNotNullParameter(text, "text");
      ChatLib var10000 = INSTANCE;
      int textWidth = Renderer.getStringWidth(addColor(text));
      var10000 = INSTANCE;
      int chatWidth = getChatWidth();
      if (textWidth >= chatWidth) {
         return text;
      } else {
         float spaceWidth = (float)(chatWidth - textWidth) / 2.0F;
         StringBuilder var5 = new StringBuilder();
         StringBuilder $this$getCenteredText_u24lambda_u2d1 = var5;
         int var7 = false;
         int var8 = MathKt.roundToInt(spaceWidth / (float)Renderer.getStringWidth(" "));

         for(int var9 = 0; var9 < var8; ++var9) {
            int var11 = false;
            $this$getCenteredText_u24lambda_u2d1.append(' ');
         }

         String var12 = var5.append(text).toString();
         Intrinsics.checkNotNullExpressionValue(var12, "spaceBuilder.append(text).toString()");
         return var12;
      }
   }

   @JvmStatic
   public static final void editChat(@NotNull NativeRegExp regexp, @NotNull Message... replacements) {
      Intrinsics.checkNotNullParameter(regexp, "regexp");
      Intrinsics.checkNotNullParameter(replacements, "replacements");
      Object var10000 = regexp.get("global");
      if (var10000 == null) {
         throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
      } else {
         final boolean global = (Boolean)var10000;
         var10000 = regexp.get("ignoreCase");
         if (var10000 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
         } else {
            boolean ignoreCase = (Boolean)var10000;
            var10000 = regexp.get("multiline");
            if (var10000 == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
            } else {
               boolean multiline = (Boolean)var10000;
               int flags = (ignoreCase ? 2 : 0) | (multiline ? 8 : 0);
               var10000 = regexp.get("source");
               if (var10000 == null) {
                  throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
               } else {
                  final Pattern pattern = Pattern.compile((String)var10000, flags);
                  INSTANCE.editChat((Function1)(new Function1<Message, Boolean>() {
                     @NotNull
                     public final Boolean invoke(@NotNull Message it) {
                        Intrinsics.checkNotNullParameter(it, "it");
                        Matcher matcher = pattern.matcher((CharSequence)it.getChatMessage().func_150260_c());
                        return global ? matcher.find() : matcher.matches();
                     }
                  }), (Message[])Arrays.copyOf(replacements, replacements.length));
               }
            }
         }
      }
   }

   @JvmStatic
   public static final void editChat(@NotNull final String toReplace, @NotNull Message... replacements) {
      Intrinsics.checkNotNullParameter(toReplace, "toReplace");
      Intrinsics.checkNotNullParameter(replacements, "replacements");
      INSTANCE.editChat((Function1)(new Function1<Message, Boolean>() {
         @NotNull
         public final Boolean invoke(@NotNull Message it) {
            Intrinsics.checkNotNullParameter(it, "it");
            String var2 = it.getChatMessage().func_150260_c();
            Intrinsics.checkNotNullExpressionValue(var2, "it.getChatMessage().unformattedText");
            return Intrinsics.areEqual(ChatLib.removeFormatting(var2), toReplace);
         }
      }), (Message[])Arrays.copyOf(replacements, replacements.length));
   }

   @JvmStatic
   public static final void editChat(@NotNull final Message toReplace, @NotNull Message... replacements) {
      Intrinsics.checkNotNullParameter(toReplace, "toReplace");
      Intrinsics.checkNotNullParameter(replacements, "replacements");
      INSTANCE.editChat((Function1)(new Function1<Message, Boolean>() {
         @NotNull
         public final Boolean invoke(@NotNull Message it) {
            Intrinsics.checkNotNullParameter(it, "it");
            String var10000 = toReplace.getChatMessage().func_150254_d();
            String var2 = it.getChatMessage().func_150254_d();
            Intrinsics.checkNotNullExpressionValue(var2, "it.getChatMessage().formattedText");
            String var10001 = var2.substring(4);
            Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).substring(startIndex)");
            return Intrinsics.areEqual(var10000, var10001);
         }
      }), (Message[])Arrays.copyOf(replacements, replacements.length));
   }

   @JvmStatic
   public static final void editChat(final int chatLineId, @NotNull Message... replacements) {
      Intrinsics.checkNotNullParameter(replacements, "replacements");
      INSTANCE.editChat((Function1)(new Function1<Message, Boolean>() {
         @NotNull
         public final Boolean invoke(@NotNull Message message) {
            Intrinsics.checkNotNullParameter(message, "message");
            return message.getChatLineId() == chatLineId;
         }
      }), (Message[])Arrays.copyOf(replacements, replacements.length));
   }

   private final void editChat(Function1<? super Message, Boolean> toReplace, Message... replacements) {
      GuiNewChat var10000 = Client.Companion.getChatGUI();
      Intrinsics.checkNotNull(var10000);
      List chatLines = var10000.field_146252_h;
      Intrinsics.checkNotNullExpressionValue(chatLines, "chatLines");
      this.editChatLineList(chatLines, toReplace, (Message[])Arrays.copyOf(replacements, replacements.length));
      var10000 = Client.Companion.getChatGUI();
      Intrinsics.checkNotNull(var10000);
      var10000.func_146245_b();
   }

   private final void editChatLineList(List<ChatLine> lineList, Function1<? super Message, Boolean> toReplace, Message... replacements) {
      ListIterator chatLineIterator = lineList.listIterator();

      while(true) {
         ChatLine chatLine;
         boolean result;
         do {
            if (!chatLineIterator.hasNext()) {
               return;
            }

            chatLine = (ChatLine)chatLineIterator.next();
            IChatComponent var7 = chatLine.func_151461_a();
            Intrinsics.checkNotNullExpressionValue(var7, "chatLine.chatComponent");
            result = (Boolean)toReplace.invoke((new Message(var7)).setChatLineId(chatLine.func_74539_c()));
         } while(!result);

         chatLineIterator.remove();
         int $i$f$forEach = false;
         Message[] $this$mapTo$iv$iv = replacements;
         Collection destination$iv$iv = (Collection)(new ArrayList(replacements.length));
         int $i$f$mapTo = false;
         int var12 = 0;

         for(int var13 = replacements.length; var12 < var13; ++var12) {
            Object item$iv$iv = $this$mapTo$iv$iv[var12];
            int var16 = false;
            int lineId = item$iv$iv.getChatLineId() == -1 ? 0 : item$iv$iv.getChatLineId();
            destination$iv$iv.add(new ChatLine(chatLine.func_74540_b(), item$iv$iv.getChatMessage(), lineId));
         }

         Iterable $this$forEach$iv = (Iterable)((List)destination$iv$iv);
         $i$f$forEach = false;
         Iterator var20 = $this$forEach$iv.iterator();

         while(var20.hasNext()) {
            Object element$iv = var20.next();
            ChatLine p0 = (ChatLine)element$iv;
            int var23 = false;
            chatLineIterator.add(p0);
         }
      }
   }

   @JvmStatic
   public static final void deleteChat(@NotNull NativeRegExp regexp) {
      Intrinsics.checkNotNullParameter(regexp, "regexp");
      Object var10000 = regexp.get("global");
      if (var10000 == null) {
         throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
      } else {
         final boolean global = (Boolean)var10000;
         var10000 = regexp.get("ignoreCase");
         if (var10000 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
         } else {
            boolean ignoreCase = (Boolean)var10000;
            var10000 = regexp.get("multiline");
            if (var10000 == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
            } else {
               boolean multiline = (Boolean)var10000;
               int flags = (ignoreCase ? 2 : 0) | (multiline ? 8 : 0);
               var10000 = regexp.get("source");
               if (var10000 == null) {
                  throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
               } else {
                  final Pattern pattern = Pattern.compile((String)var10000, flags);
                  INSTANCE.deleteChat((Function1)(new Function1<Message, Boolean>() {
                     @NotNull
                     public final Boolean invoke(@NotNull Message it) {
                        Intrinsics.checkNotNullParameter(it, "it");
                        Matcher matcher = pattern.matcher((CharSequence)it.getChatMessage().func_150260_c());
                        return global ? matcher.find() : matcher.matches();
                     }
                  }));
               }
            }
         }
      }
   }

   @JvmStatic
   public static final void deleteChat(@NotNull final String toDelete) {
      Intrinsics.checkNotNullParameter(toDelete, "toDelete");
      INSTANCE.deleteChat((Function1)(new Function1<Message, Boolean>() {
         @NotNull
         public final Boolean invoke(@NotNull Message it) {
            Intrinsics.checkNotNullParameter(it, "it");
            String var2 = it.getChatMessage().func_150260_c();
            Intrinsics.checkNotNullExpressionValue(var2, "it.getChatMessage().unformattedText");
            return Intrinsics.areEqual(ChatLib.removeFormatting(var2), toDelete);
         }
      }));
   }

   @JvmStatic
   public static final void deleteChat(@NotNull final Message toDelete) {
      Intrinsics.checkNotNullParameter(toDelete, "toDelete");
      INSTANCE.deleteChat((Function1)(new Function1<Message, Boolean>() {
         @NotNull
         public final Boolean invoke(@NotNull Message it) {
            Intrinsics.checkNotNullParameter(it, "it");
            String var10000 = toDelete.getChatMessage().func_150254_d();
            String var2 = it.getChatMessage().func_150254_d();
            Intrinsics.checkNotNullExpressionValue(var2, "it.getChatMessage().formattedText");
            String var10001 = var2.substring(4);
            Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).substring(startIndex)");
            return Intrinsics.areEqual(var10000, var10001);
         }
      }));
   }

   @JvmStatic
   public static final void deleteChat(final int chatLineId) {
      INSTANCE.deleteChat((Function1)(new Function1<Message, Boolean>() {
         @NotNull
         public final Boolean invoke(@NotNull Message it) {
            Intrinsics.checkNotNullParameter(it, "it");
            return it.getChatLineId() == chatLineId;
         }
      }));
   }

   private final void deleteChat(Function1<? super Message, Boolean> toDelete) {
      GuiNewChat var10000 = Client.Companion.getChatGUI();
      Intrinsics.checkNotNull(var10000);
      List chatLines = var10000.field_146252_h;
      Intrinsics.checkNotNullExpressionValue(chatLines, "chatLines");
      this.deleteChatLineList(chatLines, toDelete);
      var10000 = Client.Companion.getChatGUI();
      Intrinsics.checkNotNull(var10000);
      var10000.func_146245_b();
   }

   private final void deleteChatLineList(List<ChatLine> lineList, Function1<? super Message, Boolean> toDelete) {
      ListIterator chatLineIterator = lineList.listIterator();

      while(chatLineIterator.hasNext()) {
         ChatLine chatLine = (ChatLine)chatLineIterator.next();
         IChatComponent var5 = chatLine.func_151461_a();
         Intrinsics.checkNotNullExpressionValue(var5, "chatLine.chatComponent");
         if ((Boolean)toDelete.invoke((new Message(var5)).setChatLineId(chatLine.func_74539_c()))) {
            chatLineIterator.remove();
         }
      }

   }

   @JvmStatic
   @NotNull
   public static final List<String> getChatLines() {
      List hist = CollectionsKt.toMutableList((Collection)ClientListener.INSTANCE.getChatHistory());
      CollectionsKt.reverse(hist);
      return hist;
   }

   @JvmStatic
   @JvmOverloads
   public static final void addToSentMessageHistory(int index, @NotNull String message) {
      Intrinsics.checkNotNullParameter(message, "message");
      GuiNewChat var10000 = Client.Companion.getChatGUI();
      Intrinsics.checkNotNull(var10000);
      List sentMessages = var10000.func_146238_c();
      if (index == -1) {
         sentMessages.add(message);
      } else {
         sentMessages.add(index, message);
      }

   }

   // $FF: synthetic method
   public static void addToSentMessageHistory$default(int var0, String var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var0 = -1;
      }

      addToSentMessageHistory(var0, var1);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final String getChatMessage(@NotNull ClientChatReceivedEvent event, boolean formatted) {
      Intrinsics.checkNotNullParameter(event, "event");
      String var2;
      String var3;
      if (formatted) {
         ChatLib var10000 = INSTANCE;
         var2 = EventLib.getMessage(event).func_150254_d();
         Intrinsics.checkNotNullExpressionValue(var2, "getMessage(event).formattedText");
         var3 = replaceFormatting(var2);
      } else {
         var2 = EventLib.getMessage(event).func_150260_c();
         Intrinsics.checkNotNullExpressionValue(var2, "{\n            EventLib.g…unformattedText\n        }");
         var3 = var2;
      }

      return var3;
   }

   // $FF: synthetic method
   public static String getChatMessage$default(ClientChatReceivedEvent var0, boolean var1, int var2, Object var3) {
      if ((var2 & 2) != 0) {
         var1 = false;
      }

      return getChatMessage(var0, var1);
   }

   @JvmStatic
   @NotNull
   public static final String addColor(@Nullable String message) {
      CharSequence var1 = (CharSequence)String.valueOf(message);
      Regex var2 = new Regex("(?<!\\\\)&(?![^0-9a-fk-or]|$)");
      String var3 = "§";
      return var2.replace(var1, var3);
   }

   public final boolean isPlayer(@NotNull String out) {
      Intrinsics.checkNotNullParameter(out, "out");
      if (Player.getPlayer() == null) {
         ReferenceKt.printToConsole$default(out, (Console)null, (LogType)null, 3, (Object)null);
         return false;
      } else {
         return true;
      }
   }

   @JvmStatic
   @JvmOverloads
   public static final void command(@NotNull String text) {
      Intrinsics.checkNotNullParameter(text, "text");
      command$default(text, false, 2, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final String getChatBreak() {
      return getChatBreak$default((String)null, 1, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   public static final void addToSentMessageHistory(@NotNull String message) {
      Intrinsics.checkNotNullParameter(message, "message");
      addToSentMessageHistory$default(0, message, 1, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final String getChatMessage(@NotNull ClientChatReceivedEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      return getChatMessage$default(event, false, 2, (Object)null);
   }
}
