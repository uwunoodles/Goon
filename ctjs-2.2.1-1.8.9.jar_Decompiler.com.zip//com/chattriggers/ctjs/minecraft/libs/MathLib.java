package com.chattriggers.ctjs.minecraft.libs;

import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J \u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0004H\u0007J \u0010\b\u001a\u00020\t2\u0006\u0010\u0005\u001a\u00020\t2\u0006\u0010\u0006\u001a\u00020\t2\u0006\u0010\u0007\u001a\u00020\tH\u0007J0\u0010\n\u001a\u00020\t2\u0006\u0010\u0005\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\t2\u0006\u0010\r\u001a\u00020\t2\u0006\u0010\u000e\u001a\u00020\tH\u0007¨\u0006\u000f"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/libs/MathLib;", "", "()V", "clamp", "", "number", "min", "max", "clampFloat", "", "map", "in_min", "in_max", "out_min", "out_max", "ctjs"}
)
public final class MathLib {
   @NotNull
   public static final MathLib INSTANCE = new MathLib();

   private MathLib() {
   }

   @JvmStatic
   public static final float map(float number, float in_min, float in_max, float out_min, float out_max) {
      return (number - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
   }

   @JvmStatic
   public static final float clampFloat(float number, float min, float max) {
      return RangesKt.coerceIn(number, min, max);
   }

   @JvmStatic
   public static final int clamp(int number, int min, int max) {
      return RangesKt.coerceIn(number, min, max);
   }
}
