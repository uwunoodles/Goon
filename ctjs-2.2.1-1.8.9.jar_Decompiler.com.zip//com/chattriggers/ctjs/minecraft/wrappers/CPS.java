package com.chattriggers.ctjs.minecraft.wrappers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0005\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u000e\u001a\u00020\u000fH\u0002J\b\u0010\u0010\u001a\u00020\u000fH\u0002J\u0010\u0010\u0011\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u0013H\u0007J\u0016\u0010\u0014\u001a\u00020\u000f2\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004H\u0002J\b\u0010\u0016\u001a\u00020\u000fH\u0002J\b\u0010\u0017\u001a\u00020\u0005H\u0007J\b\u0010\u0018\u001a\u00020\u0005H\u0007J\b\u0010\u0019\u001a\u00020\u0005H\u0007J\b\u0010\u001a\u001a\u00020\u0005H\u0007J\b\u0010\u001b\u001a\u00020\u0005H\u0007J\b\u0010\u001c\u001a\u00020\u0005H\u0007J\u0016\u0010\u001d\u001a\u00020\u000f2\f\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u00070\u0004H\u0002J\u0010\u0010\u001f\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020 H\u0007R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00070\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00070\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006!"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/CPS;", "", "()V", "leftClicks", "", "", "leftClicksAverage", "", "leftClicksMax", "rightClicks", "rightClicksAverage", "rightClicksMax", "sysTime", "", "clearOldLeft", "", "clearOldRight", "click", "event", "Lnet/minecraftforge/client/event/MouseEvent;", "decreaseClicks", "clicks", "findMax", "getLeftClicks", "getLeftClicksAverage", "getLeftClicksMax", "getRightClicks", "getRightClicksAverage", "getRightClicksMax", "limitAverage", "average", "update", "Lnet/minecraftforge/client/event/RenderGameOverlayEvent$Pre;", "ctjs"}
)
public final class CPS {
   @NotNull
   public static final CPS INSTANCE = new CPS();
   private static long sysTime;
   @NotNull
   private static List<Integer> leftClicks;
   @NotNull
   private static List<Integer> rightClicks;
   @NotNull
   private static List<Double> leftClicksAverage;
   @NotNull
   private static List<Double> rightClicksAverage;
   private static int leftClicksMax;
   private static int rightClicksMax;

   private CPS() {
   }

   @SubscribeEvent
   public final void update(@NotNull Pre event) {
      Intrinsics.checkNotNullParameter(event, "event");

      while(Client.Companion.getSystemTime() > sysTime + 50L) {
         sysTime += 50L;
         this.decreaseClicks(leftClicks);
         this.decreaseClicks(rightClicks);
         leftClicksAverage.add((double)leftClicks.size());
         rightClicksAverage.add((double)rightClicks.size());
         this.limitAverage(leftClicksAverage);
         this.limitAverage(rightClicksAverage);
         this.clearOldLeft();
         this.clearOldRight();
         this.findMax();
      }

   }

   @SubscribeEvent
   public final void click(@NotNull MouseEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      if (event.buttonstate) {
         switch(event.button) {
         case 0:
            leftClicks.add(20);
            break;
         case 1:
            rightClicks.add(20);
         }
      }

   }

   @JvmStatic
   public static final int getLeftClicksMax() {
      return leftClicksMax;
   }

   @JvmStatic
   public static final int getRightClicksMax() {
      return rightClicksMax;
   }

   @JvmStatic
   public static final int getLeftClicks() {
      return leftClicks.size();
   }

   @JvmStatic
   public static final int getRightClicks() {
      return rightClicks.size();
   }

   @JvmStatic
   public static final int getLeftClicksAverage() {
      if (leftClicksAverage.isEmpty()) {
         return 0;
      } else {
         double clicks = 0.0D;

         double click;
         for(Iterator var2 = leftClicksAverage.iterator(); var2.hasNext(); clicks += click) {
            click = ((Number)var2.next()).doubleValue();
         }

         return MathKt.roundToInt(clicks / (double)leftClicksAverage.size());
      }
   }

   @JvmStatic
   public static final int getRightClicksAverage() {
      if (rightClicksAverage.isEmpty()) {
         return 0;
      } else {
         double clicks = 0.0D;

         double click;
         for(Iterator var2 = rightClicksAverage.iterator(); var2.hasNext(); clicks += click) {
            click = ((Number)var2.next()).doubleValue();
         }

         return MathKt.roundToInt(clicks / (double)rightClicksAverage.size());
      }
   }

   private final void limitAverage(List<Double> average) {
      if (average.size() > 100) {
         average.remove(0);
      }

   }

   private final void clearOldLeft() {
      if (!((Collection)leftClicksAverage).isEmpty() && ((Number)leftClicksAverage.get(leftClicksAverage.size() - 1)).doubleValue() == 0.0D) {
         leftClicksAverage.clear();
         leftClicksMax = 0;
      }

   }

   private final void clearOldRight() {
      if (!((Collection)rightClicksAverage).isEmpty() && ((Number)rightClicksAverage.get(rightClicksAverage.size() - 1)).doubleValue() == 0.0D) {
         rightClicksAverage.clear();
         rightClicksMax = 0;
      }

   }

   private final void findMax() {
      if (leftClicks.size() > leftClicksMax) {
         leftClicksMax = leftClicks.size();
      }

      if (rightClicks.size() > rightClicksMax) {
         rightClicksMax = rightClicks.size();
      }

   }

   private final void decreaseClicks(List<Integer> clicks) {
      if (!((Collection)clicks).isEmpty()) {
         List toRemove = (List)(new ArrayList());
         int var3 = 0;
         int var4 = clicks.size();

         while(var3 < var4) {
            int i = var3++;
            clicks.set(i, ((Number)clicks.get(i)).intValue() - 1);
            if (((Number)clicks.get(i)).intValue() == 0) {
               toRemove.add(i);
            }
         }

         Iterable $this$forEach$iv = (Iterable)CollectionsKt.sortedDescending((Iterable)toRemove);
         int $i$f$forEach = false;
         Iterator var11 = $this$forEach$iv.iterator();

         while(var11.hasNext()) {
            Object element$iv = var11.next();
            int p0 = ((Number)element$iv).intValue();
            int var8 = false;
            clicks.remove(p0);
         }
      }

   }

   static {
      sysTime = Client.Companion.getSystemTime();
      leftClicks = (List)(new ArrayList());
      rightClicks = (List)(new ArrayList());
      leftClicksAverage = (List)(new ArrayList());
      rightClicksAverage = (List)(new ArrayList());
   }
}
