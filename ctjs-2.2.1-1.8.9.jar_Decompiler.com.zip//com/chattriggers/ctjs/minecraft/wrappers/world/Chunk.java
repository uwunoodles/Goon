package com.chattriggers.ctjs.minecraft.wrappers.world;

import com.chattriggers.ctjs.minecraft.wrappers.entity.Entity;
import com.chattriggers.ctjs.minecraft.wrappers.entity.TileEntity;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ClassInheritanceMultiMap;
import net.minecraft.world.EnumSkyBlock;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\t\u0018\u00002\u00020\u0001B\u0011\u0012\n\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\u0002\u0010\u0005J\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tJ\u0018\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\t2\n\u0010\f\u001a\u0006\u0012\u0002\b\u00030\rJ\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u000f0\tJ\u0018\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u000f0\t2\n\u0010\f\u001a\u0006\u0012\u0002\b\u00030\rJ\u001e\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\u00122\u0006\u0010\u0015\u001a\u00020\u0012J\u0006\u0010\u0016\u001a\u00020\u0012J\u0006\u0010\u0017\u001a\u00020\u0012J\u001e\u0010\u0018\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\u00122\u0006\u0010\u0015\u001a\u00020\u0012J\u0006\u0010\u0019\u001a\u00020\u0012J\u0006\u0010\u001a\u001a\u00020\u0012R\u0015\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u001b"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/world/Chunk;", "", "chunk", "Lnet/minecraft/world/chunk/Chunk;", "Lcom/chattriggers/ctjs/utils/kotlin/MCChunk;", "(Lnet/minecraft/world/chunk/Chunk;)V", "getChunk", "()Lnet/minecraft/world/chunk/Chunk;", "getAllEntities", "", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/Entity;", "getAllEntitiesOfType", "clazz", "Ljava/lang/Class;", "getAllTileEntities", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/TileEntity;", "getAllTileEntitiesOfType", "getBlockLightLevel", "", "x", "y", "z", "getMinBlockX", "getMinBlockZ", "getSkyLightLevel", "getX", "getZ", "ctjs"}
)
public final class Chunk {
   @NotNull
   private final net.minecraft.world.chunk.Chunk chunk;

   public Chunk(@NotNull net.minecraft.world.chunk.Chunk chunk) {
      Intrinsics.checkNotNullParameter(chunk, "chunk");
      super();
      this.chunk = chunk;
   }

   @NotNull
   public final net.minecraft.world.chunk.Chunk getChunk() {
      return this.chunk;
   }

   public final int getX() {
      return this.chunk.field_76635_g;
   }

   public final int getZ() {
      return this.chunk.field_76647_h;
   }

   public final int getMinBlockX() {
      return this.getX() * 16;
   }

   public final int getMinBlockZ() {
      return this.getZ() * 16;
   }

   public final int getSkyLightLevel(int x, int y, int z) {
      return this.chunk.func_177413_a(EnumSkyBlock.SKY, new BlockPos(x, y, z));
   }

   public final int getBlockLightLevel(int x, int y, int z) {
      return this.chunk.func_177413_a(EnumSkyBlock.BLOCK, new BlockPos(x, y, z));
   }

   @NotNull
   public final List<Entity> getAllEntities() {
      ClassInheritanceMultiMap[] var1 = this.chunk.func_177429_s();
      Intrinsics.checkNotNullExpressionValue(var1, "chunk.entityLists");
      Iterable $this$map$iv = (Iterable)CollectionsKt.flatten((Iterable)ArraysKt.toList((Object[])var1));
      int $i$f$map = false;
      Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
      int $i$f$mapTo = false;
      Iterator var6 = $this$map$iv.iterator();

      while(var6.hasNext()) {
         Object item$iv$iv = var6.next();
         net.minecraft.entity.Entity p0 = (net.minecraft.entity.Entity)item$iv$iv;
         int var9 = false;
         destination$iv$iv.add(new Entity(p0));
      }

      return (List)destination$iv$iv;
   }

   @NotNull
   public final List<Entity> getAllEntitiesOfType(@NotNull Class<?> clazz) {
      Intrinsics.checkNotNullParameter(clazz, "clazz");
      Iterable $this$filter$iv = (Iterable)this.getAllEntities();
      int $i$f$filter = false;
      Collection destination$iv$iv = (Collection)(new ArrayList());
      int $i$f$filterTo = false;
      Iterator var7 = $this$filter$iv.iterator();

      while(var7.hasNext()) {
         Object element$iv$iv = var7.next();
         Entity it = (Entity)element$iv$iv;
         int var10 = false;
         if (clazz.isInstance(it.getEntity())) {
            destination$iv$iv.add(element$iv$iv);
         }
      }

      return (List)destination$iv$iv;
   }

   @NotNull
   public final List<TileEntity> getAllTileEntities() {
      Iterable $this$map$iv = (Iterable)this.chunk.func_177434_r().values();
      int $i$f$map = false;
      Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
      int $i$f$mapTo = false;
      Iterator var6 = $this$map$iv.iterator();

      while(var6.hasNext()) {
         Object item$iv$iv = var6.next();
         net.minecraft.tileentity.TileEntity p0 = (net.minecraft.tileentity.TileEntity)item$iv$iv;
         int var9 = false;
         destination$iv$iv.add(new TileEntity(p0));
      }

      return (List)destination$iv$iv;
   }

   @NotNull
   public final List<TileEntity> getAllTileEntitiesOfType(@NotNull Class<?> clazz) {
      Intrinsics.checkNotNullParameter(clazz, "clazz");
      Iterable $this$filter$iv = (Iterable)this.getAllTileEntities();
      int $i$f$filter = false;
      Collection destination$iv$iv = (Collection)(new ArrayList());
      int $i$f$filterTo = false;
      Iterator var7 = $this$filter$iv.iterator();

      while(var7.hasNext()) {
         Object element$iv$iv = var7.next();
         TileEntity it = (TileEntity)element$iv$iv;
         int var10 = false;
         if (clazz.isInstance(it.getTileEntity())) {
            destination$iv$iv.add(element$iv$iv);
         }
      }

      return (List)destination$iv$iv;
   }
}
