package com.chattriggers.ctjs.minecraft.wrappers.world.block;

import com.chattriggers.ctjs.minecraft.wrappers.inventory.Item;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.block.state.IBlockState;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u000f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0000¢\u0006\u0002\u0010\u0003B\u000f\b\u0016\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006B\u000f\b\u0016\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tB\u000f\b\u0016\u0012\u0006\u0010\n\u001a\u00020\u000b¢\u0006\u0002\u0010\fB\u0011\u0012\n\u0010\r\u001a\u00060\u000ej\u0002`\u000f¢\u0006\u0002\u0010\u0010J\u0006\u0010\u0013\u001a\u00020\u0014J\u0006\u0010\u0015\u001a\u00020\bJ\u0006\u0010\u0016\u001a\u00020\u0017J\u0006\u0010\u0018\u001a\u00020\bJ\u0006\u0010\u0019\u001a\u00020\bJ\u0006\u0010\u001a\u001a\u00020\bJ\u0006\u0010\u001b\u001a\u00020\u0005J\u0006\u0010\u001c\u001a\u00020\u0005J\u0006\u0010\u001d\u001a\u00020\u0005J\u0006\u0010\u001e\u001a\u00020\u0014J\b\u0010\u001f\u001a\u00020\u0005H\u0016J\u000e\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020#R\u0015\u0010\r\u001a\u00060\u000ej\u0002`\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012¨\u0006$"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockType;", "", "block", "(Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockType;)V", "blockName", "", "(Ljava/lang/String;)V", "blockID", "", "(I)V", "item", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Item;", "(Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Item;)V", "mcBlock", "Lnet/minecraft/block/Block;", "Lcom/chattriggers/ctjs/utils/kotlin/MCBlock;", "(Lnet/minecraft/block/Block;)V", "getMcBlock", "()Lnet/minecraft/block/Block;", "canProvidePower", "", "getDefaultMetadata", "getDefaultState", "Lnet/minecraft/block/state/IBlockState;", "getHarvestLevel", "getID", "getLightValue", "getName", "getRegistryName", "getUnlocalizedName", "isTranslucent", "toString", "withBlockPos", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/Block;", "blockPos", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockPos;", "ctjs"}
)
public final class BlockType {
   @NotNull
   private final net.minecraft.block.Block mcBlock;

   public BlockType(@NotNull net.minecraft.block.Block mcBlock) {
      Intrinsics.checkNotNullParameter(mcBlock, "mcBlock");
      super();
      this.mcBlock = mcBlock;
   }

   @NotNull
   public final net.minecraft.block.Block getMcBlock() {
      return this.mcBlock;
   }

   public BlockType(@NotNull BlockType block) {
      Intrinsics.checkNotNullParameter(block, "block");
      this(block.mcBlock);
   }

   public BlockType(@NotNull String blockName) {
      Intrinsics.checkNotNullParameter(blockName, "blockName");
      net.minecraft.block.Block var10001 = net.minecraft.block.Block.func_149684_b(blockName);
      Intrinsics.checkNotNull(var10001);
      this(var10001);
   }

   public BlockType(int blockID) {
      net.minecraft.block.Block var2 = net.minecraft.block.Block.func_149729_e(blockID);
      Intrinsics.checkNotNullExpressionValue(var2, "getBlockById(blockID)");
      this(var2);
   }

   public BlockType(@NotNull Item item) {
      Intrinsics.checkNotNullParameter(item, "item");
      net.minecraft.block.Block var2 = net.minecraft.block.Block.func_149634_a(item.getItem());
      Intrinsics.checkNotNullExpressionValue(var2, "getBlockFromItem(item.item)");
      this(var2);
   }

   @NotNull
   public final Block withBlockPos(@NotNull BlockPos blockPos) {
      Intrinsics.checkNotNullParameter(blockPos, "blockPos");
      return new Block(this, blockPos, (BlockFace)null, 4, (DefaultConstructorMarker)null);
   }

   public final int getID() {
      return net.minecraft.block.Block.func_149682_b(this.mcBlock);
   }

   @NotNull
   public final String getRegistryName() {
      String var1 = this.mcBlock.getRegistryName();
      Intrinsics.checkNotNullExpressionValue(var1, "mcBlock.registryName");
      return var1;
   }

   @NotNull
   public final String getUnlocalizedName() {
      String var1 = this.mcBlock.func_149739_a();
      Intrinsics.checkNotNullExpressionValue(var1, "mcBlock.unlocalizedName");
      return var1;
   }

   @NotNull
   public final String getName() {
      String var1 = this.mcBlock.func_149732_F();
      Intrinsics.checkNotNullExpressionValue(var1, "mcBlock.localizedName");
      return var1;
   }

   public final int getLightValue() {
      return this.mcBlock.func_149750_m();
   }

   @NotNull
   public final IBlockState getDefaultState() {
      IBlockState var1 = this.mcBlock.func_176223_P();
      Intrinsics.checkNotNullExpressionValue(var1, "mcBlock.defaultState");
      return var1;
   }

   public final int getDefaultMetadata() {
      return this.mcBlock.func_176201_c(this.getDefaultState());
   }

   public final boolean canProvidePower() {
      return this.mcBlock.func_149744_f();
   }

   public final int getHarvestLevel() {
      return this.mcBlock.getHarvestLevel(this.getDefaultState());
   }

   public final boolean isTranslucent() {
      return this.mcBlock.func_149751_l();
   }

   @NotNull
   public String toString() {
      return "BlockType{name=" + this.mcBlock.getRegistryName() + '}';
   }
}
