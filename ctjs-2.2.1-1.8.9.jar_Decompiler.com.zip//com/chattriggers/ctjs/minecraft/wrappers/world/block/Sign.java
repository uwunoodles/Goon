package com.chattriggers.ctjs.minecraft.wrappers.world.block;

import com.chattriggers.ctjs.minecraft.objects.message.Message;
import com.chattriggers.ctjs.minecraft.wrappers.World;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.IChatComponent;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0002\u0010\u0003J\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007J\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0007J\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\b0\u0007J\b\u0010\f\u001a\u00020\bH\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\r"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/Sign;", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/Block;", "block", "(Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/Block;)V", "sign", "Lnet/minecraft/tileentity/TileEntitySign;", "getFormattedLines", "", "", "getLines", "Lcom/chattriggers/ctjs/minecraft/objects/message/Message;", "getUnformattedLines", "toString", "ctjs"}
)
public final class Sign extends Block {
   @NotNull
   private final TileEntitySign sign;

   public Sign(@NotNull Block block) {
      Intrinsics.checkNotNullParameter(block, "block");
      super(block.getType(), block.getPos(), block.getFace());
      WorldClient var10001 = World.getWorld();
      Intrinsics.checkNotNull(var10001);
      TileEntity var2 = var10001.func_175625_s(this.getPos().toMCBlock());
      if (var2 == null) {
         throw new NullPointerException("null cannot be cast to non-null type net.minecraft.tileentity.TileEntitySign");
      } else {
         this.sign = (TileEntitySign)var2;
      }
   }

   @NotNull
   public final List<Message> getLines() {
      IChatComponent[] var1 = this.sign.field_145915_a;
      Intrinsics.checkNotNullExpressionValue(var1, "sign.signText");
      Object[] $this$map$iv = (Object[])var1;
      int $i$f$map = false;
      Object[] $this$mapTo$iv$iv = $this$map$iv;
      Collection destination$iv$iv = (Collection)(new ArrayList($this$map$iv.length));
      int $i$f$mapTo = false;
      int var6 = 0;

      for(int var7 = $this$map$iv.length; var6 < var7; ++var6) {
         Object item$iv$iv = $this$mapTo$iv$iv[var6];
         IChatComponent it = (IChatComponent)item$iv$iv;
         int var10 = false;
         Message var10000;
         if (it == null) {
            var10000 = null;
         } else {
            int var13 = false;
            var10000 = new Message(it);
         }

         if (var10000 == null) {
            Object[] var11 = new Object[]{""};
            var10000 = new Message(var11);
         }

         destination$iv$iv.add(var10000);
      }

      return (List)destination$iv$iv;
   }

   @NotNull
   public final List<String> getFormattedLines() {
      IChatComponent[] var1 = this.sign.field_145915_a;
      Intrinsics.checkNotNullExpressionValue(var1, "sign.signText");
      Object[] $this$map$iv = (Object[])var1;
      int $i$f$map = false;
      Object[] $this$mapTo$iv$iv = $this$map$iv;
      Collection destination$iv$iv = (Collection)(new ArrayList($this$map$iv.length));
      int $i$f$mapTo = false;
      int var6 = 0;

      for(int var7 = $this$map$iv.length; var6 < var7; ++var6) {
         Object item$iv$iv = $this$mapTo$iv$iv[var6];
         IChatComponent it = (IChatComponent)item$iv$iv;
         int var10 = false;
         String var10000;
         if (it == null) {
            var10000 = "";
         } else {
            var10000 = it.func_150254_d();
            if (var10000 == null) {
               var10000 = "";
            }
         }

         destination$iv$iv.add(var10000);
      }

      return (List)destination$iv$iv;
   }

   @NotNull
   public final List<String> getUnformattedLines() {
      IChatComponent[] var1 = this.sign.field_145915_a;
      Intrinsics.checkNotNullExpressionValue(var1, "sign.signText");
      Object[] $this$map$iv = (Object[])var1;
      int $i$f$map = false;
      Object[] $this$mapTo$iv$iv = $this$map$iv;
      Collection destination$iv$iv = (Collection)(new ArrayList($this$map$iv.length));
      int $i$f$mapTo = false;
      int var6 = 0;

      for(int var7 = $this$map$iv.length; var6 < var7; ++var6) {
         Object item$iv$iv = $this$mapTo$iv$iv[var6];
         IChatComponent it = (IChatComponent)item$iv$iv;
         int var10 = false;
         String var10000;
         if (it == null) {
            var10000 = "";
         } else {
            var10000 = it.func_150260_c();
            if (var10000 == null) {
               var10000 = "";
            }
         }

         destination$iv$iv.add(var10000);
      }

      return (List)destination$iv$iv;
   }

   @NotNull
   public String toString() {
      return "Sign{lines=" + this.getLines() + ", name=" + this.getType().getMcBlock().getRegistryName() + ", x=" + this.getX() + ", y=" + this.getY() + ", z=" + this.getZ() + '}';
   }
}
