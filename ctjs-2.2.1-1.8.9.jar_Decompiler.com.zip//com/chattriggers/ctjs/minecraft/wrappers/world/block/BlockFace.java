package com.chattriggers.ctjs.minecraft.wrappers.world.block;

import com.chattriggers.ctjs.minecraft.wrappers.utils.Vec3i;
import java.util.Iterator;
import java.util.Locale;
import java.util.function.Predicate;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.ArrayIteratorKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.markers.KMappedMarker;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000e\n\u0002\b\u0013\b\u0086\u0001\u0018\u0000 &2\b\u0012\u0004\u0012\u00020\u00000\u00012\u00020\u0002:\u0004$%&'B'\b\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\n¢\u0006\u0002\u0010\u000bJ\b\u0010\u0014\u001a\u00020\u0015H\u0016J\u0006\u0010\u0016\u001a\u00020\u0004J\u0006\u0010\u0017\u001a\u00020\u0004J\u0006\u0010\u0018\u001a\u00020\u0004J\u0006\u0010\u0019\u001a\u00020\u0000J\u000e\u0010\u001a\u001a\u00020\u00002\u0006\u0010\u0007\u001a\u00020\bJ\u0006\u0010\u001b\u001a\u00020\u0000J\u0006\u0010\u001c\u001a\u00020\u0000J\u0006\u0010\u001d\u001a\u00020\u0000R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013j\u0002\b\u001ej\u0002\b\u001fj\u0002\b j\u0002\b!j\u0002\b\"j\u0002\b#¨\u0006("},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace;", "", "Lnet/minecraft/util/IStringSerializable;", "oppositeIndex", "", "axisDirection", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace$AxisDirection;", "axis", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace$Axis;", "directionVec", "Lcom/chattriggers/ctjs/minecraft/wrappers/utils/Vec3i;", "(Ljava/lang/String;IILcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace$AxisDirection;Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace$Axis;Lcom/chattriggers/ctjs/minecraft/wrappers/utils/Vec3i;)V", "getAxis", "()Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace$Axis;", "getAxisDirection", "()Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace$AxisDirection;", "getDirectionVec", "()Lcom/chattriggers/ctjs/minecraft/wrappers/utils/Vec3i;", "getOppositeIndex", "()I", "getName", "", "getOffsetX", "getOffsetY", "getOffsetZ", "getOpposite", "rotateAround", "rotateX", "rotateY", "rotateZ", "Down", "Up", "North", "South", "West", "East", "Axis", "AxisDirection", "Companion", "Plane", "ctjs"}
)
public enum BlockFace implements IStringSerializable {
   @NotNull
   public static final BlockFace.Companion Companion = new BlockFace.Companion((DefaultConstructorMarker)null);
   private final int oppositeIndex;
   @NotNull
   private final BlockFace.AxisDirection axisDirection;
   @NotNull
   private final BlockFace.Axis axis;
   @NotNull
   private final Vec3i directionVec;
   Down(1, BlockFace.AxisDirection.Negative, BlockFace.Axis.Y, new Vec3i(0, -1, 0)),
   Up(0, BlockFace.AxisDirection.Positive, BlockFace.Axis.Y, new Vec3i(0, 1, 0)),
   North(3, BlockFace.AxisDirection.Negative, BlockFace.Axis.Z, new Vec3i(0, 0, -1)),
   South(2, BlockFace.AxisDirection.Positive, BlockFace.Axis.Z, new Vec3i(0, 0, 1)),
   West(5, BlockFace.AxisDirection.Negative, BlockFace.Axis.X, new Vec3i(-1, 0, 0)),
   East(4, BlockFace.AxisDirection.Positive, BlockFace.Axis.X, new Vec3i(1, 0, 0));

   private BlockFace(int oppositeIndex, BlockFace.AxisDirection axisDirection, BlockFace.Axis axis, Vec3i directionVec) {
      this.oppositeIndex = oppositeIndex;
      this.axisDirection = axisDirection;
      this.axis = axis;
      this.directionVec = directionVec;
   }

   public final int getOppositeIndex() {
      return this.oppositeIndex;
   }

   @NotNull
   public final BlockFace.AxisDirection getAxisDirection() {
      return this.axisDirection;
   }

   @NotNull
   public final BlockFace.Axis getAxis() {
      return this.axis;
   }

   @NotNull
   public final Vec3i getDirectionVec() {
      return this.directionVec;
   }

   @NotNull
   public final BlockFace getOpposite() {
      return values()[this.oppositeIndex];
   }

   public final int getOffsetX() {
      return this.directionVec.getX();
   }

   public final int getOffsetY() {
      return this.directionVec.getY();
   }

   public final int getOffsetZ() {
      return this.directionVec.getZ();
   }

   @NotNull
   public final BlockFace rotateAround(@NotNull BlockFace.Axis axis) {
      Intrinsics.checkNotNullParameter(axis, "axis");
      BlockFace var10000;
      switch(BlockFace.WhenMappings.$EnumSwitchMapping$0[axis.ordinal()]) {
      case 1:
         var10000 = this != West && this != East ? this.rotateX() : this;
         break;
      case 2:
         var10000 = this != Up && this != Down ? this.rotateY() : this;
         break;
      case 3:
         var10000 = this != North && this != South ? this.rotateZ() : this;
         break;
      default:
         throw new NoWhenBranchMatchedException();
      }

      return var10000;
   }

   @NotNull
   public final BlockFace rotateX() {
      BlockFace var10000;
      switch(BlockFace.WhenMappings.$EnumSwitchMapping$1[this.ordinal()]) {
      case 1:
         var10000 = South;
         break;
      case 2:
         var10000 = North;
         break;
      case 3:
         var10000 = Down;
         break;
      case 4:
         var10000 = Up;
         break;
      default:
         throw new IllegalStateException("Cannot rotate " + this + " around x-axis");
      }

      return var10000;
   }

   @NotNull
   public final BlockFace rotateY() {
      BlockFace var10000;
      switch(BlockFace.WhenMappings.$EnumSwitchMapping$1[this.ordinal()]) {
      case 3:
         var10000 = East;
         break;
      case 4:
         var10000 = West;
         break;
      case 5:
         var10000 = North;
         break;
      case 6:
         var10000 = South;
         break;
      default:
         throw new IllegalStateException("Cannot rotate " + this + " around y-axis");
      }

      return var10000;
   }

   @NotNull
   public final BlockFace rotateZ() {
      BlockFace var10000;
      switch(BlockFace.WhenMappings.$EnumSwitchMapping$1[this.ordinal()]) {
      case 1:
         var10000 = West;
         break;
      case 2:
         var10000 = East;
         break;
      case 3:
      case 4:
      default:
         throw new IllegalStateException("Cannot rotate " + this + " around z-axis");
      case 5:
         var10000 = Up;
         break;
      case 6:
         var10000 = Down;
      }

      return var10000;
   }

   @NotNull
   public String func_176610_l() {
      String var10000 = this.name().toLowerCase(Locale.ROOT);
      Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String).toLowerCase(Locale.ROOT)");
      return var10000;
   }

   // $FF: synthetic method
   private static final BlockFace[] $values() {
      BlockFace[] var0 = new BlockFace[]{Down, Up, North, South, West, East};
      return var0;
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u001c\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010(\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u00012\b\u0012\u0004\u0012\u00020\u00030\u00022\b\u0012\u0004\u0012\u00020\u00030\u0004B\u0007\b\u0002¢\u0006\u0002\u0010\u0005J\u0011\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00030\u0007¢\u0006\u0002\u0010\bJ\u000f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00030\nH\u0096\u0002J\u0010\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u0003H\u0016j\u0002\b\u000ej\u0002\b\u000f¨\u0006\u0010"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace$Plane;", "", "Ljava/util/function/Predicate;", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace;", "", "(Ljava/lang/String;I)V", "facings", "", "()[Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace;", "iterator", "", "test", "", "t", "Horizontal", "Vertical", "ctjs"}
   )
   public static enum Plane implements Predicate<BlockFace>, Iterable<BlockFace>, KMappedMarker {
      Horizontal,
      Vertical;

      public boolean test(@NotNull BlockFace t) {
         Intrinsics.checkNotNullParameter(t, "t");
         return t.getAxis().getPlane() == this;
      }

      @NotNull
      public final BlockFace[] facings() {
         BlockFace[] var10000;
         BlockFace[] var1;
         switch(BlockFace.Plane.WhenMappings.$EnumSwitchMapping$0[this.ordinal()]) {
         case 1:
            var1 = new BlockFace[]{BlockFace.North, BlockFace.East, BlockFace.West, BlockFace.South};
            var10000 = var1;
            break;
         case 2:
            var1 = new BlockFace[]{BlockFace.Up, BlockFace.Down};
            var10000 = var1;
            break;
         default:
            throw new NoWhenBranchMatchedException();
         }

         return var10000;
      }

      @NotNull
      public Iterator<BlockFace> iterator() {
         return ArrayIteratorKt.iterator(this.facings());
      }

      // $FF: synthetic method
      private static final BlockFace.Plane[] $values() {
         BlockFace.Plane[] var0 = new BlockFace.Plane[]{Horizontal, Vertical};
         return var0;
      }

      // $FF: synthetic class
      @Metadata(
         mv = {1, 6, 0},
         k = 3,
         xi = 48
      )
      public class WhenMappings {
         // $FF: synthetic field
         public static final int[] $EnumSwitchMapping$0;

         static {
            int[] var0 = new int[BlockFace.Plane.values().length];
            var0[BlockFace.Plane.Horizontal.ordinal()] = 1;
            var0[BlockFace.Plane.Vertical.ordinal()] = 2;
            $EnumSwitchMapping$0 = var0;
         }
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\b¨\u0006\t"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace$AxisDirection;", "", "offset", "", "(Ljava/lang/String;II)V", "getOffset", "()I", "Positive", "Negative", "ctjs"}
   )
   public static enum AxisDirection {
      private final int offset;
      Positive(1),
      Negative(-1);

      private AxisDirection(int offset) {
         this.offset = offset;
      }

      public final int getOffset() {
         return this.offset;
      }

      // $FF: synthetic method
      private static final BlockFace.AxisDirection[] $values() {
         BlockFace.AxisDirection[] var0 = new BlockFace.AxisDirection[]{Positive, Negative};
         return var0;
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0007\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u00012\b\u0012\u0004\u0012\u00020\u00030\u00022\u00020\u0004B\u000f\b\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007J\b\u0010\n\u001a\u00020\u000bH\u0016J\u0006\u0010\f\u001a\u00020\rJ\u0006\u0010\u000e\u001a\u00020\rJ\u0010\u0010\u000f\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\u0003H\u0016R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tj\u0002\b\u0011j\u0002\b\u0012j\u0002\b\u0013¨\u0006\u0014"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace$Axis;", "", "Ljava/util/function/Predicate;", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace;", "Lnet/minecraft/util/IStringSerializable;", "plane", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace$Plane;", "(Ljava/lang/String;ILcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace$Plane;)V", "getPlane", "()Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace$Plane;", "getName", "", "isHorizontal", "", "isVertical", "test", "t", "X", "Y", "Z", "ctjs"}
   )
   public static enum Axis implements Predicate<BlockFace>, IStringSerializable {
      @NotNull
      private final BlockFace.Plane plane;
      X(BlockFace.Plane.Horizontal),
      Y(BlockFace.Plane.Vertical),
      Z(BlockFace.Plane.Horizontal);

      private Axis(BlockFace.Plane plane) {
         this.plane = plane;
      }

      @NotNull
      public final BlockFace.Plane getPlane() {
         return this.plane;
      }

      public final boolean isHorizontal() {
         return this.plane == BlockFace.Plane.Horizontal;
      }

      public final boolean isVertical() {
         return this.plane == BlockFace.Plane.Vertical;
      }

      public boolean test(@NotNull BlockFace t) {
         Intrinsics.checkNotNullParameter(t, "t");
         return t.getAxis() == this;
      }

      @NotNull
      public String func_176610_l() {
         String var10000 = this.name().toLowerCase(Locale.ROOT);
         Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String).toLowerCase(Locale.ROOT)");
         return var10000;
      }

      // $FF: synthetic method
      private static final BlockFace.Axis[] $values() {
         BlockFace.Axis[] var0 = new BlockFace.Axis[]{X, Y, Z};
         return var0;
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0012\u0010\u0003\u001a\u00020\u00042\n\u0010\u0005\u001a\u00060\u0006j\u0002`\u0007¨\u0006\b"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace$Companion;", "", "()V", "fromMCEnumFacing", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace;", "facing", "Lnet/minecraft/util/EnumFacing;", "Lcom/chattriggers/ctjs/utils/kotlin/MCEnumFacing;", "ctjs"}
   )
   public static final class Companion {
      private Companion() {
      }

      @NotNull
      public final BlockFace fromMCEnumFacing(@NotNull EnumFacing facing) {
         Intrinsics.checkNotNullParameter(facing, "facing");
         BlockFace var10000;
         switch(BlockFace.Companion.WhenMappings.$EnumSwitchMapping$0[facing.ordinal()]) {
         case 1:
            var10000 = BlockFace.Down;
            break;
         case 2:
            var10000 = BlockFace.Up;
            break;
         case 3:
            var10000 = BlockFace.North;
            break;
         case 4:
            var10000 = BlockFace.South;
            break;
         case 5:
            var10000 = BlockFace.West;
            break;
         case 6:
            var10000 = BlockFace.East;
            break;
         default:
            throw new NoWhenBranchMatchedException();
         }

         return var10000;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }

      // $FF: synthetic class
      @Metadata(
         mv = {1, 6, 0},
         k = 3,
         xi = 48
      )
      public class WhenMappings {
         // $FF: synthetic field
         public static final int[] $EnumSwitchMapping$0;

         static {
            int[] var0 = new int[EnumFacing.values().length];
            var0[EnumFacing.DOWN.ordinal()] = 1;
            var0[EnumFacing.UP.ordinal()] = 2;
            var0[EnumFacing.NORTH.ordinal()] = 3;
            var0[EnumFacing.SOUTH.ordinal()] = 4;
            var0[EnumFacing.WEST.ordinal()] = 5;
            var0[EnumFacing.EAST.ordinal()] = 6;
            $EnumSwitchMapping$0 = var0;
         }
      }
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$1;

      static {
         int[] var0 = new int[BlockFace.Axis.values().length];
         var0[BlockFace.Axis.X.ordinal()] = 1;
         var0[BlockFace.Axis.Y.ordinal()] = 2;
         var0[BlockFace.Axis.Z.ordinal()] = 3;
         $EnumSwitchMapping$0 = var0;
         var0 = new int[BlockFace.values().length];
         var0[BlockFace.Down.ordinal()] = 1;
         var0[BlockFace.Up.ordinal()] = 2;
         var0[BlockFace.North.ordinal()] = 3;
         var0[BlockFace.South.ordinal()] = 4;
         var0[BlockFace.West.ordinal()] = 5;
         var0[BlockFace.East.ordinal()] = 6;
         $EnumSwitchMapping$1 = var0;
      }
   }
}
