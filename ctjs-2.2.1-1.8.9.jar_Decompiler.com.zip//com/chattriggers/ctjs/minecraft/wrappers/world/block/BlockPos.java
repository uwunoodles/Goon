package com.chattriggers.ctjs.minecraft.wrappers.world.block;

import com.chattriggers.ctjs.minecraft.wrappers.entity.Entity;
import com.chattriggers.ctjs.minecraft.wrappers.utils.Vec3i;
import kotlin.Metadata;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0004\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u000f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0002\u0010\u0003B\u0013\b\u0016\u0012\n\u0010\u0002\u001a\u00060\u0004j\u0002`\u0005¢\u0006\u0002\u0010\u0006B\u000f\b\u0016\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tB\u001d\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u0006\u0010\f\u001a\u00020\u000b\u0012\u0006\u0010\r\u001a\u00020\u000b¢\u0006\u0002\u0010\u000eJ\u000e\u0010\u000f\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u0001J\u001e\u0010\u000f\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000bJ\u0012\u0010\u0011\u001a\u00020\u00002\b\b\u0002\u0010\u0012\u001a\u00020\u0013H\u0007J\u0012\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0012\u001a\u00020\u0013H\u0007J\u0011\u0010\u0015\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u0001H\u0086\u0002J\u0012\u0010\u0016\u001a\u00020\u00002\b\b\u0002\u0010\u0012\u001a\u00020\u0013H\u0007J\u001a\u0010\u0017\u001a\u00020\u00002\u0006\u0010\u0018\u001a\u00020\u00192\b\b\u0002\u0010\u0012\u001a\u00020\u0013H\u0007J\u0011\u0010\u001a\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u0001H\u0086\u0002J\u0012\u0010\u001b\u001a\u00020\u00002\b\b\u0002\u0010\u0012\u001a\u00020\u0013H\u0007J\u000e\u0010\u001c\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u0001J\u001e\u0010\u001c\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000bJ\n\u0010\u001d\u001a\u00060\u0004j\u0002`\u0005J\u0012\u0010\u001e\u001a\u00020\u00002\b\b\u0002\u0010\u0012\u001a\u00020\u0013H\u0007J\u0012\u0010\u001f\u001a\u00020\u00002\b\b\u0002\u0010\u0012\u001a\u00020\u0013H\u0007¨\u0006 "},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockPos;", "Lcom/chattriggers/ctjs/minecraft/wrappers/utils/Vec3i;", "pos", "(Lcom/chattriggers/ctjs/minecraft/wrappers/utils/Vec3i;)V", "Lnet/minecraft/util/BlockPos;", "Lcom/chattriggers/ctjs/utils/kotlin/MCBlockPos;", "(Lnet/minecraft/util/BlockPos;)V", "source", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/Entity;", "(Lcom/chattriggers/ctjs/minecraft/wrappers/entity/Entity;)V", "x", "", "y", "z", "(Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V", "add", "other", "down", "n", "", "east", "minus", "north", "offset", "facing", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockFace;", "plus", "south", "subtract", "toMCBlock", "up", "west", "ctjs"}
)
public final class BlockPos extends Vec3i {
   public BlockPos(@NotNull Number x, @NotNull Number y, @NotNull Number z) {
      Intrinsics.checkNotNullParameter(x, "x");
      Intrinsics.checkNotNullParameter(y, "y");
      Intrinsics.checkNotNullParameter(z, "z");
      super(x, y, z);
   }

   public BlockPos(@NotNull Vec3i pos) {
      Intrinsics.checkNotNullParameter(pos, "pos");
      this((Number)pos.getX(), (Number)pos.getY(), (Number)pos.getZ());
   }

   public BlockPos(@NotNull net.minecraft.util.BlockPos pos) {
      Intrinsics.checkNotNullParameter(pos, "pos");
      this((Number)pos.func_177958_n(), (Number)pos.func_177956_o(), (Number)pos.func_177952_p());
   }

   public BlockPos(@NotNull Entity source) {
      Intrinsics.checkNotNullParameter(source, "source");
      this(source.getPos());
   }

   @NotNull
   public final BlockPos add(@NotNull Vec3i other) {
      Intrinsics.checkNotNullParameter(other, "other");
      return new BlockPos((Number)this.getX() + other.getX(), (Number)this.getY() + other.getY(), (Number)this.getZ() + other.getZ());
   }

   @NotNull
   public final BlockPos add(@NotNull Number x, @NotNull Number y, @NotNull Number z) {
      Intrinsics.checkNotNullParameter(x, "x");
      Intrinsics.checkNotNullParameter(y, "y");
      Intrinsics.checkNotNullParameter(z, "z");
      return this.add(new Vec3i(x, y, z));
   }

   @NotNull
   public final BlockPos plus(@NotNull Vec3i other) {
      Intrinsics.checkNotNullParameter(other, "other");
      return this.add(other);
   }

   @NotNull
   public final BlockPos subtract(@NotNull Vec3i other) {
      Intrinsics.checkNotNullParameter(other, "other");
      return new BlockPos((Number)this.getX() - other.getX(), (Number)this.getY() - other.getY(), (Number)this.getZ() - other.getZ());
   }

   @NotNull
   public final BlockPos subtract(@NotNull Number x, @NotNull Number y, @NotNull Number z) {
      Intrinsics.checkNotNullParameter(x, "x");
      Intrinsics.checkNotNullParameter(y, "y");
      Intrinsics.checkNotNullParameter(z, "z");
      return this.subtract(new Vec3i(x, y, z));
   }

   @NotNull
   public final BlockPos minus(@NotNull Vec3i other) {
      Intrinsics.checkNotNullParameter(other, "other");
      return this.subtract(other);
   }

   @JvmOverloads
   @NotNull
   public final BlockPos up(int n) {
      return this.offset(BlockFace.Up, n);
   }

   // $FF: synthetic method
   public static BlockPos up$default(BlockPos var0, int var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = 1;
      }

      return var0.up(var1);
   }

   @JvmOverloads
   @NotNull
   public final BlockPos down(int n) {
      return this.offset(BlockFace.Down, n);
   }

   // $FF: synthetic method
   public static BlockPos down$default(BlockPos var0, int var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = 1;
      }

      return var0.down(var1);
   }

   @JvmOverloads
   @NotNull
   public final BlockPos north(int n) {
      return this.offset(BlockFace.North, n);
   }

   // $FF: synthetic method
   public static BlockPos north$default(BlockPos var0, int var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = 1;
      }

      return var0.north(var1);
   }

   @JvmOverloads
   @NotNull
   public final BlockPos south(int n) {
      return this.offset(BlockFace.South, n);
   }

   // $FF: synthetic method
   public static BlockPos south$default(BlockPos var0, int var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = 1;
      }

      return var0.south(var1);
   }

   @JvmOverloads
   @NotNull
   public final BlockPos east(int n) {
      return this.offset(BlockFace.East, n);
   }

   // $FF: synthetic method
   public static BlockPos east$default(BlockPos var0, int var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = 1;
      }

      return var0.east(var1);
   }

   @JvmOverloads
   @NotNull
   public final BlockPos west(int n) {
      return this.offset(BlockFace.West, n);
   }

   // $FF: synthetic method
   public static BlockPos west$default(BlockPos var0, int var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = 1;
      }

      return var0.west(var1);
   }

   @JvmOverloads
   @NotNull
   public final BlockPos offset(@NotNull BlockFace facing, int n) {
      Intrinsics.checkNotNullParameter(facing, "facing");
      return new BlockPos((Number)this.getX() + facing.getOffsetX() * n, (Number)this.getY() + facing.getOffsetY() * n, (Number)this.getZ() + facing.getOffsetZ() * n);
   }

   // $FF: synthetic method
   public static BlockPos offset$default(BlockPos var0, BlockFace var1, int var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = 1;
      }

      return var0.offset(var1, var2);
   }

   @NotNull
   public final net.minecraft.util.BlockPos toMCBlock() {
      return new net.minecraft.util.BlockPos(this.getX(), this.getY(), this.getZ());
   }

   @JvmOverloads
   @NotNull
   public final BlockPos up() {
      return up$default(this, 0, 1, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final BlockPos down() {
      return down$default(this, 0, 1, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final BlockPos north() {
      return north$default(this, 0, 1, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final BlockPos south() {
      return south$default(this, 0, 1, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final BlockPos east() {
      return east$default(this, 0, 1, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final BlockPos west() {
      return west$default(this, 0, 1, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final BlockPos offset(@NotNull BlockFace facing) {
      Intrinsics.checkNotNullParameter(facing, "facing");
      return offset$default(this, facing, 0, 2, (Object)null);
   }
}
