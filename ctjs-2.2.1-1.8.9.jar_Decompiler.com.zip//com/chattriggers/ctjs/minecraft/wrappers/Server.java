package com.chattriggers.ctjs.minecraft.wrappers;

import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007J\b\u0010\u0005\u001a\u00020\u0004H\u0007J\b\u0010\u0006\u001a\u00020\u0004H\u0007J\b\u0010\u0007\u001a\u00020\bH\u0007¨\u0006\t"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/Server;", "", "()V", "getIP", "", "getMOTD", "getName", "getPing", "", "ctjs"}
)
public final class Server {
   @NotNull
   public static final Server INSTANCE = new Server();

   private Server() {
   }

   @JvmStatic
   @NotNull
   public static final String getIP() {
      if (Client.Companion.getMinecraft().func_71356_B()) {
         return "localhost";
      } else {
         ServerData var10000 = Client.Companion.getMinecraft().func_147104_D();
         String var0;
         if (var10000 == null) {
            var0 = "";
         } else {
            var0 = var10000.field_78845_b;
            if (var0 == null) {
               var0 = "";
            }
         }

         return var0;
      }
   }

   @JvmStatic
   @NotNull
   public static final String getName() {
      if (Client.Companion.getMinecraft().func_71356_B()) {
         return "SinglePlayer";
      } else {
         ServerData var10000 = Client.Companion.getMinecraft().func_147104_D();
         String var0;
         if (var10000 == null) {
            var0 = "";
         } else {
            var0 = var10000.field_78847_a;
            if (var0 == null) {
               var0 = "";
            }
         }

         return var0;
      }
   }

   @JvmStatic
   @NotNull
   public static final String getMOTD() {
      if (Client.Companion.getMinecraft().func_71356_B()) {
         return "SinglePlayer";
      } else {
         ServerData var10000 = Client.Companion.getMinecraft().func_147104_D();
         String var0;
         if (var10000 == null) {
            var0 = "";
         } else {
            var0 = var10000.field_78843_d;
            if (var0 == null) {
               var0 = "";
            }
         }

         return var0;
      }
   }

   @JvmStatic
   public static final long getPing() {
      EntityPlayerSP player = Player.getPlayer();
      if (player != null && !Client.Companion.getMinecraft().func_71356_B() && Client.Companion.getMinecraft().func_147104_D() != null) {
         NetHandlerPlayClient var10000 = Client.Companion.getConnection();
         Long var4;
         if (var10000 == null) {
            var4 = null;
         } else {
            NetworkPlayerInfo var5 = var10000.func_175102_a(player.func_110124_au());
            if (var5 == null) {
               var4 = null;
            } else {
               int var3 = var5.func_178853_c();
               var4 = (long)var3;
            }
         }

         long var7;
         if (var4 == null) {
            ServerData var6 = Client.Companion.getMinecraft().func_147104_D();
            if (var6 == null) {
               var7 = -1L;
            } else {
               long var1 = var6.field_78844_e;
               var7 = var1;
            }
         } else {
            var7 = var4;
         }

         return var7;
      } else {
         return 5L;
      }
   }
}
