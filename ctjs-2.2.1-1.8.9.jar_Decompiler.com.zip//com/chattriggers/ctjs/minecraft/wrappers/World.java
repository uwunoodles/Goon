package com.chattriggers.ctjs.minecraft.wrappers;

import com.chattriggers.ctjs.minecraft.wrappers.entity.Entity;
import com.chattriggers.ctjs.minecraft.wrappers.entity.Particle;
import com.chattriggers.ctjs.minecraft.wrappers.entity.PlayerMP;
import com.chattriggers.ctjs.minecraft.wrappers.entity.TileEntity;
import com.chattriggers.ctjs.minecraft.wrappers.world.Chunk;
import com.chattriggers.ctjs.minecraft.wrappers.world.block.Block;
import com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockFace;
import com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.particle.EntityFX;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.WorldType;
import net.minecraft.world.storage.WorldInfo;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0080\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0004\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\u0010\u0006\n\u0002\b\b\bÆ\u0002\u0018\u00002\u00020\u0001:\u0003345B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004H\u0007J\u001a\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u00042\n\u0010\u0007\u001a\u0006\u0012\u0002\b\u00030\bH\u0007J\u000e\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0004H\u0007J\u000e\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\f0\u0004H\u0007J\u001a\u0010\r\u001a\b\u0012\u0004\u0012\u00020\f0\u00042\n\u0010\u0007\u001a\u0006\u0012\u0002\b\u00030\bH\u0007J\u0010\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0007J \u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u0013H\u0007J\u0010\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0010\u001a\u00020\u0011H\u0007J \u0010\u0018\u001a\u00020\u00192\u0006\u0010\u0012\u001a\u00020\u001a2\u0006\u0010\u0014\u001a\u00020\u001a2\u0006\u0010\u0015\u001a\u00020\u001aH\u0007J\b\u0010\u001b\u001a\u00020\u001cH\u0007J\b\u0010\u001d\u001a\u00020\u001aH\u0007J\u0012\u0010\u001e\u001a\u0004\u0018\u00010\n2\u0006\u0010\u001f\u001a\u00020\u001cH\u0007J\b\u0010 \u001a\u00020!H\u0007J\b\u0010\"\u001a\u00020#H\u0007J\b\u0010$\u001a\u00020#H\u0007J\b\u0010%\u001a\u00020\u001cH\u0007J\n\u0010&\u001a\u0004\u0018\u00010'H\u0007J\u0010\u0010(\u001a\u00020)2\u0006\u0010\u001f\u001a\u00020\u001cH\u0007J\b\u0010*\u001a\u00020)H\u0007J\b\u0010+\u001a\u00020)H\u0007J*\u0010,\u001a\u00020-2\b\u0010\u001f\u001a\u0004\u0018\u00010\u001c2\u0006\u0010\u0012\u001a\u00020.2\u0006\u0010\u0014\u001a\u00020.2\u0006\u0010\u0015\u001a\u00020.H\u0007J \u0010/\u001a\u00020-2\u0006\u0010\u001f\u001a\u00020\u001c2\u0006\u00100\u001a\u00020!2\u0006\u00101\u001a\u00020!H\u0007J\b\u00102\u001a\u00020-H\u0007¨\u00066"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/World;", "", "()V", "getAllEntities", "", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/Entity;", "getAllEntitiesOfType", "clazz", "Ljava/lang/Class;", "getAllPlayers", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/PlayerMP;", "getAllTileEntities", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/TileEntity;", "getAllTileEntitiesOfType", "getBlockAt", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/Block;", "pos", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockPos;", "x", "", "y", "z", "getBlockStateAt", "Lnet/minecraft/block/state/IBlockState;", "getChunk", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/Chunk;", "", "getDifficulty", "", "getMoonPhase", "getPlayerByName", "name", "getRainingStrength", "", "getSeed", "", "getTime", "getType", "getWorld", "Lnet/minecraft/client/multiplayer/WorldClient;", "hasPlayer", "", "isLoaded", "isRaining", "playRecord", "", "", "playSound", "volume", "pitch", "stopAllSounds", "border", "particle", "spawn", "ctjs"}
)
public final class World {
   @NotNull
   public static final World INSTANCE = new World();

   private World() {
   }

   @JvmStatic
   @Nullable
   public static final WorldClient getWorld() {
      return Client.Companion.getMinecraft().field_71441_e;
   }

   @JvmStatic
   public static final boolean isLoaded() {
      World var10000 = INSTANCE;
      return getWorld() != null;
   }

   @JvmStatic
   public static final void playSound(@NotNull final String name, final float volume, final float pitch) {
      Intrinsics.checkNotNullParameter(name, "name");
      Client.Companion.scheduleTask$default(Client.Companion, 0, (Function0)(new Function0<Unit>() {
         public final void invoke() {
            EntityPlayerSP var10000 = Player.getPlayer();
            if (var10000 != null) {
               var10000.func_85030_a(name, volume, pitch);
            }

         }
      }), 1, (Object)null);
   }

   @JvmStatic
   public static final void playRecord(@Nullable final String name, final double x, final double y, final double z) {
      Client.Companion.scheduleTask$default(Client.Companion, 0, (Function0)(new Function0<Unit>() {
         public final void invoke() {
            WorldClient var10000 = World.getWorld();
            if (var10000 != null) {
               var10000.func_175717_a(new BlockPos(x, y, z), name);
            }

         }
      }), 1, (Object)null);
   }

   @JvmStatic
   public static final void stopAllSounds() {
      Client.Companion.getMinecraft().func_147118_V().func_147690_c();
   }

   @JvmStatic
   public static final boolean isRaining() {
      World var10000 = INSTANCE;
      WorldClient var1 = getWorld();
      boolean var2;
      if (var1 == null) {
         var2 = false;
      } else {
         WorldInfo var3 = var1.func_72912_H();
         if (var3 == null) {
            var2 = false;
         } else {
            boolean var0 = var3.func_76059_o();
            var2 = var0;
         }
      }

      return var2;
   }

   @JvmStatic
   public static final float getRainingStrength() {
      World var10000 = INSTANCE;
      WorldClient var1 = getWorld();
      float var2;
      if (var1 == null) {
         var2 = -1.0F;
      } else {
         float var0 = var1.field_73004_o;
         var2 = var0;
      }

      return var2;
   }

   @JvmStatic
   public static final long getTime() {
      World var10000 = INSTANCE;
      WorldClient var2 = getWorld();
      long var3;
      if (var2 == null) {
         var3 = -1L;
      } else {
         long var0 = var2.func_72820_D();
         var3 = var0;
      }

      return var3;
   }

   @JvmStatic
   @NotNull
   public static final String getDifficulty() {
      World var10000 = INSTANCE;
      WorldClient var0 = getWorld();
      return String.valueOf(var0 == null ? null : var0.func_175659_aa());
   }

   @JvmStatic
   public static final int getMoonPhase() {
      World var10000 = INSTANCE;
      WorldClient var1 = getWorld();
      int var2;
      if (var1 == null) {
         var2 = -1;
      } else {
         int var0 = var1.func_72853_d();
         var2 = var0;
      }

      return var2;
   }

   @JvmStatic
   public static final long getSeed() {
      World var10000 = INSTANCE;
      WorldClient var2 = getWorld();
      long var3;
      if (var2 == null) {
         var3 = -1L;
      } else {
         long var0 = var2.func_72905_C();
         var3 = var0;
      }

      return var3;
   }

   @JvmStatic
   @NotNull
   public static final String getType() {
      World var10000 = INSTANCE;
      WorldClient var0 = getWorld();
      String var1;
      if (var0 == null) {
         var1 = null;
      } else {
         WorldType var2 = var0.func_175624_G();
         var1 = var2 == null ? null : var2.func_77127_a();
      }

      return String.valueOf(var1);
   }

   @JvmStatic
   @NotNull
   public static final Block getBlockAt(@NotNull Number x, @NotNull Number y, @NotNull Number z) {
      Intrinsics.checkNotNullParameter(x, "x");
      Intrinsics.checkNotNullParameter(y, "y");
      Intrinsics.checkNotNullParameter(z, "z");
      World var10000 = INSTANCE;
      return getBlockAt(new com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockPos(x, y, z));
   }

   @JvmStatic
   @NotNull
   public static final Block getBlockAt(@NotNull com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockPos pos) {
      Intrinsics.checkNotNullParameter(pos, "pos");
      World var10004 = INSTANCE;
      net.minecraft.block.Block var1 = getBlockStateAt(pos).func_177230_c();
      Intrinsics.checkNotNullExpressionValue(var1, "getBlockStateAt(pos).block");
      return new Block(new BlockType(var1), pos, (BlockFace)null, 4, (DefaultConstructorMarker)null);
   }

   @JvmStatic
   @NotNull
   public static final IBlockState getBlockStateAt(@NotNull com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockPos pos) {
      Intrinsics.checkNotNullParameter(pos, "pos");
      World var10000 = INSTANCE;
      WorldClient var2 = getWorld();
      Intrinsics.checkNotNull(var2);
      IBlockState var1 = var2.func_180495_p(pos.toMCBlock());
      Intrinsics.checkNotNullExpressionValue(var1, "getWorld()!!.getBlockState(pos.toMCBlock())");
      return var1;
   }

   @JvmStatic
   @NotNull
   public static final List<PlayerMP> getAllPlayers() {
      World var10000 = INSTANCE;
      WorldClient var11 = getWorld();
      List var12;
      if (var11 == null) {
         var12 = null;
      } else {
         var12 = var11.field_73010_i;
         if (var12 == null) {
            var12 = null;
         } else {
            Iterable $this$map$iv = (Iterable)var12;
            int $i$f$map = false;
            Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
            int $i$f$mapTo = false;
            Iterator var6 = $this$map$iv.iterator();

            while(var6.hasNext()) {
               Object item$iv$iv = var6.next();
               EntityPlayer p0 = (EntityPlayer)item$iv$iv;
               int var9 = false;
               destination$iv$iv.add(new PlayerMP(p0));
            }

            var12 = (List)destination$iv$iv;
         }
      }

      List var0 = var12;
      return var0 == null ? CollectionsKt.emptyList() : var0;
   }

   @JvmStatic
   @Nullable
   public static final PlayerMP getPlayerByName(@NotNull String name) {
      Intrinsics.checkNotNullParameter(name, "name");
      World var10000 = INSTANCE;
      WorldClient var3 = getWorld();
      PlayerMP var4;
      if (var3 == null) {
         var4 = null;
      } else {
         EntityPlayer var5 = var3.func_72924_a(name);
         if (var5 == null) {
            var4 = null;
         } else {
            EntityPlayer p0 = var5;
            int var2 = false;
            var4 = new PlayerMP(p0);
         }
      }

      return var4;
   }

   @JvmStatic
   public static final boolean hasPlayer(@NotNull String name) {
      Intrinsics.checkNotNullParameter(name, "name");
      World var10000 = INSTANCE;
      WorldClient var1 = getWorld();
      return (var1 == null ? null : var1.func_72924_a(name)) != null;
   }

   @JvmStatic
   @NotNull
   public static final Chunk getChunk(int x, int y, int z) {
      World var10002 = INSTANCE;
      WorldClient var4 = getWorld();
      Intrinsics.checkNotNull(var4);
      net.minecraft.world.chunk.Chunk var3 = var4.func_175726_f(new BlockPos(x, y, z));
      Intrinsics.checkNotNullExpressionValue(var3, "getWorld()!!.getChunkFro…os(x, y, z)\n            )");
      return new Chunk(var3);
   }

   @JvmStatic
   @NotNull
   public static final List<Entity> getAllEntities() {
      World var10000 = INSTANCE;
      WorldClient var11 = getWorld();
      List var12;
      if (var11 == null) {
         var12 = null;
      } else {
         var12 = var11.field_72996_f;
         if (var12 == null) {
            var12 = null;
         } else {
            Iterable $this$map$iv = (Iterable)var12;
            int $i$f$map = false;
            Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
            int $i$f$mapTo = false;
            Iterator var6 = $this$map$iv.iterator();

            while(var6.hasNext()) {
               Object item$iv$iv = var6.next();
               net.minecraft.entity.Entity p0 = (net.minecraft.entity.Entity)item$iv$iv;
               int var9 = false;
               destination$iv$iv.add(new Entity(p0));
            }

            var12 = (List)destination$iv$iv;
         }
      }

      List var0 = var12;
      return var0 == null ? CollectionsKt.emptyList() : var0;
   }

   @JvmStatic
   @NotNull
   public static final List<Entity> getAllEntitiesOfType(@NotNull Class<?> clazz) {
      Intrinsics.checkNotNullParameter(clazz, "clazz");
      World var10000 = INSTANCE;
      Iterable $this$filter$iv = (Iterable)getAllEntities();
      int $i$f$filter = false;
      Collection destination$iv$iv = (Collection)(new ArrayList());
      int $i$f$filterTo = false;
      Iterator var6 = $this$filter$iv.iterator();

      while(var6.hasNext()) {
         Object element$iv$iv = var6.next();
         Entity it = (Entity)element$iv$iv;
         int var9 = false;
         if (clazz.isInstance(it.getEntity())) {
            destination$iv$iv.add(element$iv$iv);
         }
      }

      return (List)destination$iv$iv;
   }

   @JvmStatic
   @NotNull
   public static final List<TileEntity> getAllTileEntities() {
      World var10000 = INSTANCE;
      WorldClient var11 = getWorld();
      List var12;
      if (var11 == null) {
         var12 = null;
      } else {
         var12 = var11.field_147482_g;
         if (var12 == null) {
            var12 = null;
         } else {
            Iterable $this$map$iv = (Iterable)var12;
            int $i$f$map = false;
            Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
            int $i$f$mapTo = false;
            Iterator var6 = $this$map$iv.iterator();

            while(var6.hasNext()) {
               Object item$iv$iv = var6.next();
               net.minecraft.tileentity.TileEntity p0 = (net.minecraft.tileentity.TileEntity)item$iv$iv;
               int var9 = false;
               destination$iv$iv.add(new TileEntity(p0));
            }

            var12 = (List)destination$iv$iv;
         }
      }

      List var0 = var12;
      return var0 == null ? CollectionsKt.emptyList() : var0;
   }

   @JvmStatic
   @NotNull
   public static final List<TileEntity> getAllTileEntitiesOfType(@NotNull Class<?> clazz) {
      Intrinsics.checkNotNullParameter(clazz, "clazz");
      World var10000 = INSTANCE;
      Iterable $this$filter$iv = (Iterable)getAllTileEntities();
      int $i$f$filter = false;
      Collection destination$iv$iv = (Collection)(new ArrayList());
      int $i$f$filterTo = false;
      Iterator var6 = $this$filter$iv.iterator();

      while(var6.hasNext()) {
         Object element$iv$iv = var6.next();
         TileEntity it = (TileEntity)element$iv$iv;
         int var9 = false;
         if (clazz.isInstance(it.getTileEntity())) {
            destination$iv$iv.add(element$iv$iv);
         }
      }

      return (List)destination$iv$iv;
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0006\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007J\b\u0010\u0005\u001a\u00020\u0004H\u0007J\b\u0010\u0006\u001a\u00020\u0007H\u0007J\b\u0010\b\u001a\u00020\u0004H\u0007J\b\u0010\t\u001a\u00020\nH\u0007¨\u0006\u000b"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/World$border;", "", "()V", "getCenterX", "", "getCenterZ", "getSize", "", "getTargetSize", "getTimeUntilTarget", "", "ctjs"}
   )
   public static final class border {
      @NotNull
      public static final World.border INSTANCE = new World.border();

      private border() {
      }

      @JvmStatic
      public static final double getCenterX() {
         WorldClient var10000 = World.getWorld();
         Intrinsics.checkNotNull(var10000);
         return var10000.func_175723_af().func_177731_f();
      }

      @JvmStatic
      public static final double getCenterZ() {
         WorldClient var10000 = World.getWorld();
         Intrinsics.checkNotNull(var10000);
         return var10000.func_175723_af().func_177721_g();
      }

      @JvmStatic
      public static final int getSize() {
         WorldClient var10000 = World.getWorld();
         Intrinsics.checkNotNull(var10000);
         return var10000.func_175723_af().func_177722_l();
      }

      @JvmStatic
      public static final double getTargetSize() {
         WorldClient var10000 = World.getWorld();
         Intrinsics.checkNotNull(var10000);
         return var10000.func_175723_af().func_177751_j();
      }

      @JvmStatic
      public static final long getTimeUntilTarget() {
         WorldClient var10000 = World.getWorld();
         Intrinsics.checkNotNull(var10000);
         return var10000.func_175723_af().func_177732_i();
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007J\b\u0010\u0005\u001a\u00020\u0004H\u0007J\b\u0010\u0006\u001a\u00020\u0004H\u0007¨\u0006\u0007"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/World$spawn;", "", "()V", "getX", "", "getY", "getZ", "ctjs"}
   )
   public static final class spawn {
      @NotNull
      public static final World.spawn INSTANCE = new World.spawn();

      private spawn() {
      }

      @JvmStatic
      public static final int getX() {
         WorldClient var10000 = World.getWorld();
         Intrinsics.checkNotNull(var10000);
         return var10000.func_175694_M().func_177958_n();
      }

      @JvmStatic
      public static final int getY() {
         WorldClient var10000 = World.getWorld();
         Intrinsics.checkNotNull(var10000);
         return var10000.func_175694_M().func_177956_o();
      }

      @JvmStatic
      public static final int getZ() {
         WorldClient var10000 = World.getWorld();
         Intrinsics.checkNotNull(var10000);
         return var10000.func_175694_M().func_177952_p();
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004H\u0007J\u0014\u0010\u0006\u001a\u00020\u00072\n\u0010\b\u001a\u00060\tj\u0002`\nH\u0007J@\u0010\u0006\u001a\u00020\u000b2\u0006\u0010\b\u001a\u00020\u00052\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\r2\u0006\u0010\u0011\u001a\u00020\r2\u0006\u0010\u0012\u001a\u00020\rH\u0007¨\u0006\u0013"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/World$particle;", "", "()V", "getParticleNames", "", "", "spawnParticle", "", "particle", "Lnet/minecraft/client/particle/EntityFX;", "Lcom/chattriggers/ctjs/utils/kotlin/MCParticle;", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/Particle;", "x", "", "y", "z", "xSpeed", "ySpeed", "zSpeed", "ctjs"}
   )
   public static final class particle {
      @NotNull
      public static final World.particle INSTANCE = new World.particle();

      private particle() {
      }

      @JvmStatic
      @NotNull
      public static final List<String> getParticleNames() {
         Object[] $this$map$iv = EnumParticleTypes.values();
         int $i$f$map = false;
         EnumParticleTypes[] $this$mapTo$iv$iv = $this$map$iv;
         Collection destination$iv$iv = (Collection)(new ArrayList($this$map$iv.length));
         int $i$f$mapTo = false;
         int var5 = 0;

         for(int var6 = $this$map$iv.length; var5 < var6; ++var5) {
            Object item$iv$iv = $this$mapTo$iv$iv[var5];
            int var9 = false;
            destination$iv$iv.add(item$iv$iv.name());
         }

         return CollectionsKt.toList((Iterable)((List)destination$iv$iv));
      }

      @JvmStatic
      @NotNull
      public static final Particle spawnParticle(@NotNull String particle, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
         Intrinsics.checkNotNullParameter(particle, "particle");
         EnumParticleTypes particleType = EnumParticleTypes.valueOf(particle);
         EntityFX fx = Client.Companion.getMinecraft().field_71438_f.func_174974_b(particleType.func_179348_c(), particleType.func_179344_e(), x, y, z, xSpeed, ySpeed, zSpeed, new int[0]);
         Intrinsics.checkNotNullExpressionValue(fx, "fx");
         return new Particle(fx);
      }

      @JvmStatic
      public static final void spawnParticle(@NotNull EntityFX particle) {
         Intrinsics.checkNotNullParameter(particle, "particle");
         Client.Companion.getMinecraft().field_71452_i.func_78873_a(particle);
      }
   }
}
