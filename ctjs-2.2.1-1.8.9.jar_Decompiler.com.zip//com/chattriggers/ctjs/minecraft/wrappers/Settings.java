package com.chattriggers.ctjs.minecraft.wrappers;

import java.util.Locale;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.audio.SoundCategory;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.entity.player.EntityPlayer.EnumChatVisibility;
import net.minecraft.world.EnumDifficulty;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u000b\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0006\u0010\f\u001a\u00020\rJ\u0006\u0010\u000e\u001a\u00020\u000fJ\u000e\u0010\u0010\u001a\n \u0012*\u0004\u0018\u00010\u00110\u0011J\u000e\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\rJ\u000e\u0010\u0016\u001a\u00020\u00142\u0006\u0010\u0017\u001a\u00020\u000fR\u0011\u0010\u0003\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0006\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\u0005R\u0011\u0010\b\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0005R\u0011\u0010\n\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\u0005¨\u0006\u0018"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/Settings;", "", "()V", "chat", "getChat", "()Ljava/lang/Object;", "skin", "getSkin", "sound", "getSound", "video", "getVideo", "getDifficulty", "", "getFOV", "", "getSettings", "Lnet/minecraft/client/settings/GameSettings;", "kotlin.jvm.PlatformType", "setDifficulty", "", "difficulty", "setFOV", "fov", "ctjs"}
)
public final class Settings {
   @NotNull
   private final Object skin = new Object() {
      public final boolean getCape() {
         return Settings.this.getSettings().func_178876_d().contains(EnumPlayerModelParts.CAPE);
      }

      public final void setCape(boolean toggled) {
         Settings.this.getSettings().func_178878_a(EnumPlayerModelParts.CAPE, toggled);
      }

      public final boolean getJacket() {
         return Settings.this.getSettings().func_178876_d().contains(EnumPlayerModelParts.JACKET);
      }

      public final void setJacket(boolean toggled) {
         Settings.this.getSettings().func_178878_a(EnumPlayerModelParts.JACKET, toggled);
      }

      public final boolean getLeftSleeve() {
         return Settings.this.getSettings().func_178876_d().contains(EnumPlayerModelParts.LEFT_SLEEVE);
      }

      public final void setLeftSleeve(boolean toggled) {
         Settings.this.getSettings().func_178878_a(EnumPlayerModelParts.LEFT_SLEEVE, toggled);
      }

      public final boolean getRightSleeve() {
         return Settings.this.getSettings().func_178876_d().contains(EnumPlayerModelParts.RIGHT_SLEEVE);
      }

      public final void setRightSleeve(boolean toggled) {
         Settings.this.getSettings().func_178878_a(EnumPlayerModelParts.RIGHT_SLEEVE, toggled);
      }

      public final boolean getLeftPantsLeg() {
         return Settings.this.getSettings().func_178876_d().contains(EnumPlayerModelParts.LEFT_PANTS_LEG);
      }

      public final void setLeftPantsLeg(boolean toggled) {
         Settings.this.getSettings().func_178878_a(EnumPlayerModelParts.LEFT_PANTS_LEG, toggled);
      }

      public final boolean getRightPantsLeg() {
         return Settings.this.getSettings().func_178876_d().contains(EnumPlayerModelParts.RIGHT_PANTS_LEG);
      }

      public final void setRightPantsLeg(boolean toggled) {
         Settings.this.getSettings().func_178878_a(EnumPlayerModelParts.RIGHT_PANTS_LEG, toggled);
      }

      public final boolean getHat() {
         return Settings.this.getSettings().func_178876_d().contains(EnumPlayerModelParts.HAT);
      }

      public final void setHat(boolean toggled) {
         Settings.this.getSettings().func_178878_a(EnumPlayerModelParts.HAT, toggled);
      }
   };
   @NotNull
   private final Object sound = new Object() {
      public final float getMasterVolume() {
         return Settings.this.getSettings().func_151438_a(SoundCategory.MASTER);
      }

      public final void setMasterVolume(float level) {
         Settings.this.getSettings().func_151439_a(SoundCategory.MASTER, level);
      }

      public final float getMusicVolume() {
         return Settings.this.getSettings().func_151438_a(SoundCategory.MUSIC);
      }

      public final void setMusicVolume(float level) {
         Settings.this.getSettings().func_151439_a(SoundCategory.MUSIC, level);
      }

      public final float getNoteblockVolume() {
         return Settings.this.getSettings().func_151438_a(SoundCategory.RECORDS);
      }

      public final void setNoteblockVolume(float level) {
         Settings.this.getSettings().func_151439_a(SoundCategory.RECORDS, level);
      }

      public final float getWeather() {
         return Settings.this.getSettings().func_151438_a(SoundCategory.WEATHER);
      }

      public final void setWeather(float level) {
         Settings.this.getSettings().func_151439_a(SoundCategory.WEATHER, level);
      }

      public final float getBlocks() {
         return Settings.this.getSettings().func_151438_a(SoundCategory.BLOCKS);
      }

      public final void setBlocks(float level) {
         Settings.this.getSettings().func_151439_a(SoundCategory.BLOCKS, level);
      }

      public final float getHostileCreatures() {
         return Settings.this.getSettings().func_151438_a(SoundCategory.MOBS);
      }

      public final void setHostileCreatures(float level) {
         Settings.this.getSettings().func_151439_a(SoundCategory.MOBS, level);
      }

      public final float getFriendlyCreatures() {
         return Settings.this.getSettings().func_151438_a(SoundCategory.ANIMALS);
      }

      public final void setFriendlyCreatures(float level) {
         Settings.this.getSettings().func_151439_a(SoundCategory.ANIMALS, level);
      }

      public final float getPlayers() {
         return Settings.this.getSettings().func_151438_a(SoundCategory.PLAYERS);
      }

      public final void setPlayers(float level) {
         Settings.this.getSettings().func_151439_a(SoundCategory.PLAYERS, level);
      }

      public final float getAmbient() {
         return Settings.this.getSettings().func_151438_a(SoundCategory.AMBIENT);
      }

      public final void setAmbient(float level) {
         Settings.this.getSettings().func_151439_a(SoundCategory.AMBIENT, level);
      }
   };
   @NotNull
   private final Object video = new Object() {
      public final boolean getGraphics() {
         return Settings.this.getSettings().field_74347_j;
      }

      public final void setGraphics(boolean fancy) {
         Settings.this.getSettings().field_74347_j = fancy;
      }

      public final int getRenderDistance() {
         return Settings.this.getSettings().field_151451_c;
      }

      public final void setRenderDistance(int distance) {
         Settings.this.getSettings().field_151451_c = distance;
      }

      public final int getSmoothLighting() {
         return Settings.this.getSettings().field_74348_k;
      }

      public final void setSmoothLighting(int level) {
         Settings.this.getSettings().field_74348_k = level;
      }

      public final int getMaxFrameRate() {
         return Settings.this.getSettings().field_74350_i;
      }

      public final void setMaxFrameRate(int frameRate) {
         Settings.this.getSettings().field_74350_i = frameRate;
      }

      public final boolean get3dAnaglyph() {
         return Settings.this.getSettings().field_74337_g;
      }

      public final void set3dAnaglyph(boolean toggled) {
         Settings.this.getSettings().field_74337_g = toggled;
      }

      public final boolean getBobbing() {
         return Settings.this.getSettings().field_74336_f;
      }

      public final void setBobbing(boolean toggled) {
         Settings.this.getSettings().field_74336_f = toggled;
      }

      public final int getGuiScale() {
         return Settings.this.getSettings().field_74335_Z;
      }

      public final void setGuiScale(int scale) {
         Settings.this.getSettings().field_74335_Z = scale;
      }

      public final float getBrightness() {
         return Settings.this.getSettings().field_74333_Y;
      }

      public final void setBrightness(float brightness) {
         Settings.this.getSettings().field_74333_Y = brightness;
      }

      public final int getClouds() {
         return Settings.this.getSettings().field_74345_l;
      }

      public final void setClouds(int clouds) {
         Settings.this.getSettings().field_74345_l = clouds;
      }

      public final int getParticles() {
         return Settings.this.getSettings().field_74362_aa;
      }

      public final void setParticles(int particles) {
         Settings.this.getSettings().field_74362_aa = particles;
      }

      public final boolean getFullscreen() {
         return Settings.this.getSettings().field_74353_u;
      }

      public final void setFullscreen(boolean toggled) {
         Settings.this.getSettings().field_74353_u = toggled;
      }

      public final boolean getVsync() {
         return Settings.this.getSettings().field_74352_v;
      }

      public final void setVsync(boolean toggled) {
         Settings.this.getSettings().field_74352_v = toggled;
      }

      public final int getMipmapLevels() {
         return Settings.this.getSettings().field_151442_I;
      }

      public final void setMipmapLevels(int mipmapLevels) {
         Settings.this.getSettings().field_151442_I = mipmapLevels;
      }

      public final boolean getAlternateBlocks() {
         return Settings.this.getSettings().field_178880_u;
      }

      public final void setAlternateBlocks(boolean toggled) {
         Settings.this.getSettings().field_178880_u = toggled;
      }

      public final boolean getVBOs() {
         return Settings.this.getSettings().field_178881_t;
      }

      public final void setVBOs(boolean toggled) {
         Settings.this.getSettings().field_178881_t = toggled;
      }

      public final boolean getEntityShadows() {
         return Settings.this.getSettings().field_181151_V;
      }

      public final void setEntityShadows(boolean toggled) {
         Settings.this.getSettings().field_181151_V = toggled;
      }
   };
   @NotNull
   private final Object chat = new Object() {
      public final EnumChatVisibility getVisibility() {
         return Settings.this.getSettings().field_74343_n;
      }

      public final void setVisibility(@NotNull String visibility) {
         GameSettings var10000;
         EnumChatVisibility var3;
         label24: {
            label23: {
               Intrinsics.checkNotNullParameter(visibility, "visibility");
               var10000 = Settings.this.getSettings();
               String var10001 = visibility.toLowerCase(Locale.ROOT);
               Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).toLowerCase(Locale.ROOT)");
               String var2 = var10001;
               switch(var2.hashCode()) {
               case -1217487446:
                  if (var2.equals("hidden")) {
                     var3 = EnumChatVisibility.HIDDEN;
                     break label24;
                  }
                  break;
               case -887328209:
                  if (var2.equals("system")) {
                     break label23;
                  }
                  break;
               case -602535288:
                  if (var2.equals("commands")) {
                     break label23;
                  }
               }

               var3 = EnumChatVisibility.FULL;
               break label24;
            }

            var3 = EnumChatVisibility.SYSTEM;
         }

         var10000.field_74343_n = var3;
      }

      public final boolean getColors() {
         return Settings.this.getSettings().field_74344_o;
      }

      public final void setColors(boolean toggled) {
         Settings.this.getSettings().field_74344_o = toggled;
      }

      public final boolean getWebLinks() {
         return Settings.this.getSettings().field_74359_p;
      }

      public final void setWebLinks(boolean toggled) {
         Settings.this.getSettings().field_74359_p = toggled;
      }

      public final float getOpacity() {
         return Settings.this.getSettings().field_74357_r;
      }

      public final void setOpacity(float opacity) {
         Settings.this.getSettings().field_74357_r = opacity;
      }

      public final boolean getPromptOnWebLinks() {
         return Settings.this.getSettings().field_74358_q;
      }

      public final void setPromptOnWebLinks(boolean toggled) {
         Settings.this.getSettings().field_74358_q = toggled;
      }

      public final float getScale() {
         return Settings.this.getSettings().field_96691_E;
      }

      public final void setScale(float scale) {
         Settings.this.getSettings().field_96691_E = scale;
      }

      public final float getFocusedHeight() {
         return Settings.this.getSettings().field_96694_H;
      }

      public final void setFocusedHeight(float height) {
         Settings.this.getSettings().field_96694_H = height;
      }

      public final float getUnfocusedHeight() {
         return Settings.this.getSettings().field_96693_G;
      }

      public final void setUnfocusedHeight(float height) {
         Settings.this.getSettings().field_96693_G = height;
      }

      public final float getWidth() {
         return Settings.this.getSettings().field_96692_F;
      }

      public final void setWidth(float width) {
         Settings.this.getSettings().field_96692_F = width;
      }

      public final boolean getReducedDebugInfo() {
         return Settings.this.getSettings().field_178879_v;
      }

      public final void setReducedDebugInfo(boolean toggled) {
         Settings.this.getSettings().field_178879_v = toggled;
      }
   };

   public final GameSettings getSettings() {
      return Client.Companion.getMinecraft().field_71474_y;
   }

   public final float getFOV() {
      return this.getSettings().field_74334_X;
   }

   public final void setFOV(float fov) {
      this.getSettings().field_74334_X = fov;
   }

   public final int getDifficulty() {
      return this.getSettings().field_74318_M.func_151525_a();
   }

   public final void setDifficulty(int difficulty) {
      this.getSettings().field_74318_M = EnumDifficulty.func_151523_a(difficulty);
   }

   @NotNull
   public final Object getSkin() {
      return this.skin;
   }

   @NotNull
   public final Object getSound() {
      return this.sound;
   }

   @NotNull
   public final Object getVideo() {
      return this.video;
   }

   @NotNull
   public final Object getChat() {
      return this.chat;
   }
}
