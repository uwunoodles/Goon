package com.chattriggers.ctjs.minecraft.wrappers;

import com.chattriggers.ctjs.minecraft.libs.Tessellator;
import com.chattriggers.ctjs.minecraft.libs.renderer.Renderer;
import com.chattriggers.ctjs.minecraft.objects.message.TextComponent;
import com.chattriggers.ctjs.minecraft.wrappers.entity.PlayerMP;
import com.chattriggers.ctjs.minecraft.wrappers.entity.Team;
import com.chattriggers.ctjs.minecraft.wrappers.inventory.Inventory;
import com.chattriggers.ctjs.minecraft.wrappers.inventory.Item;
import com.chattriggers.ctjs.minecraft.wrappers.world.PotionEffect;
import com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockFace;
import com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockType;
import com.chattriggers.ctjs.minecraft.wrappers.world.block.Sign;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSign;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.FoodStats;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000x\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0006\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u0002\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001LB\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\n\u0010\u0003\u001a\u0004\u0018\u00010\u0004H\u0007JT\u0010\u0005\u001a\u00020\u00002\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u00072\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\f\u001a\u00020\n2\b\b\u0002\u0010\r\u001a\u00020\n2\b\b\u0002\u0010\u000e\u001a\u00020\n2\b\b\u0002\u0010\u000f\u001a\u00020\nH\u0007J\b\u0010\u0010\u001a\u00020\u0011H\u0007J\u000e\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00140\u0013H\u0007J\b\u0010\u0015\u001a\u00020\u0007H\u0007J\b\u0010\u0016\u001a\u00020\u0007H\u0007J\b\u0010\u0017\u001a\u00020\u0011H\u0007J\n\u0010\u0018\u001a\u0004\u0018\u00010\u0019H\u0007J\b\u0010\u001a\u001a\u00020\u001bH\u0007J\b\u0010\u001c\u001a\u00020\u001dH\u0007J\n\u0010\u001e\u001a\u0004\u0018\u00010\u001fH\u0007J\b\u0010 \u001a\u00020\u0007H\u0007J\b\u0010!\u001a\u00020\u0007H\u0007J\n\u0010\"\u001a\u0004\u0018\u00010\u0019H\u0007J\b\u0010#\u001a\u00020$H\u0007J\b\u0010%\u001a\u00020$H\u0007J\b\u0010&\u001a\u00020$H\u0007J\b\u0010'\u001a\u00020\u0007H\u0007J\b\u0010(\u001a\u00020$H\u0007J\b\u0010)\u001a\u00020$H\u0007J\b\u0010*\u001a\u00020$H\u0007J\b\u0010+\u001a\u00020\u0011H\u0007J\n\u0010,\u001a\u0004\u0018\u00010\u0019H\u0007J\b\u0010-\u001a\u00020\u001dH\u0007J\n\u0010.\u001a\u0004\u0018\u00010/H\u0007J\b\u00100\u001a\u00020\u001dH\u0007J\b\u00101\u001a\u00020$H\u0007J\b\u00102\u001a\u00020$H\u0007J\b\u00103\u001a\u00020$H\u0007J\b\u00104\u001a\u00020\u001dH\u0007J\n\u00105\u001a\u0004\u0018\u000106H\u0007J\b\u00107\u001a\u00020\u0011H\u0007J\b\u00108\u001a\u000209H\u0007J\b\u0010:\u001a\u00020$H\u0007J\b\u0010;\u001a\u00020\u0007H\u0007J\b\u0010<\u001a\u00020\u001dH\u0007J\b\u0010=\u001a\u00020$H\u0007J\b\u0010>\u001a\u00020\u001dH\u0007J\b\u0010?\u001a\u00020$H\u0007J\b\u0010@\u001a\u00020\nH\u0007J\b\u0010A\u001a\u00020\nH\u0007J\b\u0010B\u001a\u00020\nH\u0007J\b\u0010C\u001a\u00020\nH\u0007J\b\u0010D\u001a\u00020\nH\u0007J\b\u0010E\u001a\u00020\u0001H\u0007J\u0010\u0010F\u001a\u00020G2\u0006\u0010H\u001a\u00020\u0007H\u0007J\u0010\u0010I\u001a\u00020G2\u0006\u0010J\u001a\u00020\u001bH\u0007J\u0010\u0010K\u001a\u00020G2\u0006\u0010J\u001a\u00020\u001bH\u0007¨\u0006M"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/Player;", "", "()V", "asPlayerMP", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/PlayerMP;", "draw", "x", "", "y", "rotate", "", "showNametag", "showArmor", "showCape", "showHeldItem", "showArrows", "facing", "", "getActivePotionEffects", "", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/PotionEffect;", "getAirLevel", "getArmorPoints", "getBiome", "getContainer", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Inventory;", "getDisplayName", "Lcom/chattriggers/ctjs/minecraft/objects/message/TextComponent;", "getHP", "", "getHeldItem", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Item;", "getHeldItemIndex", "getHunger", "getInventory", "getLastX", "", "getLastY", "getLastZ", "getLightLevel", "getMotionX", "getMotionY", "getMotionZ", "getName", "getOpenedInventory", "getPitch", "getPlayer", "Lnet/minecraft/client/entity/EntityPlayerSP;", "getRawYaw", "getRenderX", "getRenderY", "getRenderZ", "getSaturation", "getTeam", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/Team;", "getUUID", "getUUIDObj", "Ljava/util/UUID;", "getX", "getXPLevel", "getXPProgress", "getY", "getYaw", "getZ", "isFlying", "isMoving", "isSleeping", "isSneaking", "isSprinting", "lookingAt", "setHeldItemIndex", "", "index", "setNametagName", "textComponent", "setTabDisplayName", "armor", "ctjs"}
)
public final class Player {
   @NotNull
   public static final Player INSTANCE = new Player();

   private Player() {
   }

   @JvmStatic
   @Nullable
   public static final EntityPlayerSP getPlayer() {
      return Client.Companion.getMinecraft().field_71439_g;
   }

   @JvmStatic
   @Nullable
   public static final Team getTeam() {
      net.minecraft.scoreboard.Scoreboard var10000 = Scoreboard.getScoreboard();
      Team var2;
      if (var10000 == null) {
         var2 = null;
      } else {
         Player var10001 = INSTANCE;
         ScorePlayerTeam var3 = var10000.func_96509_i(getName());
         if (var3 == null) {
            var2 = null;
         } else {
            ScorePlayerTeam p0 = var3;
            int var1 = false;
            var2 = new Team(p0);
         }
      }

      return var2;
   }

   @JvmStatic
   @Nullable
   public static final PlayerMP asPlayerMP() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var2 = getPlayer();
      PlayerMP var3;
      if (var2 == null) {
         var3 = null;
      } else {
         EntityPlayer p0 = (EntityPlayer)var2;
         int var1 = false;
         var3 = new PlayerMP(p0);
      }

      return var3;
   }

   @JvmStatic
   public static final double getX() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var2 = getPlayer();
      double var3;
      if (var2 == null) {
         var3 = 0.0D;
      } else {
         double var0 = var2.field_70165_t;
         var3 = var0;
      }

      return var3;
   }

   @JvmStatic
   public static final double getY() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var2 = getPlayer();
      double var3;
      if (var2 == null) {
         var3 = 0.0D;
      } else {
         double var0 = var2.field_70163_u;
         var3 = var0;
      }

      return var3;
   }

   @JvmStatic
   public static final double getZ() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var2 = getPlayer();
      double var3;
      if (var2 == null) {
         var3 = 0.0D;
      } else {
         double var0 = var2.field_70161_v;
         var3 = var0;
      }

      return var3;
   }

   @JvmStatic
   public static final double getLastX() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var2 = getPlayer();
      double var3;
      if (var2 == null) {
         var3 = 0.0D;
      } else {
         double var0 = var2.field_70142_S;
         var3 = var0;
      }

      return var3;
   }

   @JvmStatic
   public static final double getLastY() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var2 = getPlayer();
      double var3;
      if (var2 == null) {
         var3 = 0.0D;
      } else {
         double var0 = var2.field_70137_T;
         var3 = var0;
      }

      return var3;
   }

   @JvmStatic
   public static final double getLastZ() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var2 = getPlayer();
      double var3;
      if (var2 == null) {
         var3 = 0.0D;
      } else {
         double var0 = var2.field_70136_U;
         var3 = var0;
      }

      return var3;
   }

   @JvmStatic
   public static final double getRenderX() {
      Player var10000 = INSTANCE;
      double var0 = getLastX();
      Player var10001 = INSTANCE;
      double var1 = getX();
      Player var10002 = INSTANCE;
      return var0 + (var1 - getLastX()) * (double)Tessellator.getPartialTicks();
   }

   @JvmStatic
   public static final double getRenderY() {
      Player var10000 = INSTANCE;
      double var0 = getLastY();
      Player var10001 = INSTANCE;
      double var1 = getY();
      Player var10002 = INSTANCE;
      return var0 + (var1 - getLastY()) * (double)Tessellator.getPartialTicks();
   }

   @JvmStatic
   public static final double getRenderZ() {
      Player var10000 = INSTANCE;
      double var0 = getLastZ();
      Player var10001 = INSTANCE;
      double var1 = getZ();
      Player var10002 = INSTANCE;
      return var0 + (var1 - getLastZ()) * (double)Tessellator.getPartialTicks();
   }

   @JvmStatic
   public static final double getMotionX() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var2 = getPlayer();
      double var3;
      if (var2 == null) {
         var3 = 0.0D;
      } else {
         double var0 = var2.field_70159_w;
         var3 = var0;
      }

      return var3;
   }

   @JvmStatic
   public static final double getMotionY() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var2 = getPlayer();
      double var3;
      if (var2 == null) {
         var3 = 0.0D;
      } else {
         double var0 = var2.field_70181_x;
         var3 = var0;
      }

      return var3;
   }

   @JvmStatic
   public static final double getMotionZ() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var2 = getPlayer();
      double var3;
      if (var2 == null) {
         var3 = 0.0D;
      } else {
         double var0 = var2.field_70179_y;
         var3 = var0;
      }

      return var3;
   }

   @JvmStatic
   public static final float getPitch() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      float var2;
      if (var1 == null) {
         var2 = 0.0F;
      } else {
         float var0 = var1.field_70125_A;
         var2 = var0;
      }

      return MathHelper.func_76142_g(var2);
   }

   @JvmStatic
   public static final float getYaw() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      float var2;
      if (var1 == null) {
         var2 = 0.0F;
      } else {
         float var0 = var1.field_70177_z;
         var2 = var0;
      }

      return MathHelper.func_76142_g(var2);
   }

   @JvmStatic
   public static final float getRawYaw() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      float var2;
      if (var1 == null) {
         var2 = 0.0F;
      } else {
         float var0 = var1.field_70177_z;
         var2 = var0;
      }

      return var2;
   }

   @JvmStatic
   @NotNull
   public static final String getName() {
      String var0 = Client.Companion.getMinecraft().func_110432_I().func_111285_a();
      Intrinsics.checkNotNullExpressionValue(var0, "Client.getMinecraft().session.username");
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final String getUUID() {
      Player var10000 = INSTANCE;
      String var0 = getUUIDObj().toString();
      Intrinsics.checkNotNullExpressionValue(var0, "getUUIDObj().toString()");
      return var0;
   }

   @JvmStatic
   @NotNull
   public static final UUID getUUIDObj() {
      UUID var0 = Client.Companion.getMinecraft().func_110432_I().func_148256_e().getId();
      Intrinsics.checkNotNullExpressionValue(var0, "Client.getMinecraft().session.profile.id");
      return var0;
   }

   @JvmStatic
   public static final float getHP() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      float var2;
      if (var1 == null) {
         var2 = 0.0F;
      } else {
         float var0 = var1.func_110143_aJ();
         var2 = var0;
      }

      return var2;
   }

   @JvmStatic
   public static final int getHunger() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      int var2;
      if (var1 == null) {
         var2 = 0;
      } else {
         FoodStats var3 = var1.func_71024_bL();
         if (var3 == null) {
            var2 = 0;
         } else {
            int var0 = var3.func_75116_a();
            var2 = var0;
         }
      }

      return var2;
   }

   @JvmStatic
   public static final float getSaturation() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      float var2;
      if (var1 == null) {
         var2 = 0.0F;
      } else {
         FoodStats var3 = var1.func_71024_bL();
         if (var3 == null) {
            var2 = 0.0F;
         } else {
            float var0 = var3.func_75115_e();
            var2 = var0;
         }
      }

      return var2;
   }

   @JvmStatic
   public static final int getArmorPoints() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      int var2;
      if (var1 == null) {
         var2 = 0;
      } else {
         int var0 = var1.func_70658_aO();
         var2 = var0;
      }

      return var2;
   }

   @JvmStatic
   public static final int getAirLevel() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      int var2;
      if (var1 == null) {
         var2 = 0;
      } else {
         int var0 = var1.func_70086_ai();
         var2 = var0;
      }

      return var2;
   }

   @JvmStatic
   public static final int getXPLevel() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      int var2;
      if (var1 == null) {
         var2 = 0;
      } else {
         int var0 = var1.field_71068_ca;
         var2 = var0;
      }

      return var2;
   }

   @JvmStatic
   public static final float getXPProgress() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      float var2;
      if (var1 == null) {
         var2 = 0.0F;
      } else {
         float var0 = var1.field_71106_cc;
         var2 = var0;
      }

      return var2;
   }

   @JvmStatic
   @NotNull
   public static final String getBiome() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var5 = getPlayer();
      if (var5 == null) {
         return "";
      } else {
         EntityPlayerSP player = var5;
         WorldClient var6 = World.getWorld();
         if (var6 == null) {
            return "";
         } else {
            WorldClient world = var6;
            Chunk chunk = world.func_175726_f(player.func_180425_c());
            BiomeGenBase biome = chunk.func_177411_a(player.func_180425_c(), world.func_72959_q());
            String var4 = biome.field_76791_y;
            Intrinsics.checkNotNullExpressionValue(var4, "biome.biomeName");
            return var4;
         }
      }
   }

   @JvmStatic
   public static final int getLightLevel() {
      WorldClient var10000 = World.getWorld();
      int var1;
      if (var10000 == null) {
         var1 = 0;
      } else {
         Player var10001 = INSTANCE;
         EntityPlayerSP var2 = getPlayer();
         int var0 = var10000.func_175699_k(var2 == null ? null : var2.func_180425_c());
         var1 = var0;
      }

      return var1;
   }

   @JvmStatic
   public static final boolean isMoving() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var3 = getPlayer();
      boolean var4;
      if (var3 == null) {
         var4 = false;
      } else {
         MovementInput var5 = var3.field_71158_b;
         if (var5 == null) {
            var4 = false;
         } else {
            MovementInput it = var5;
            int var2 = false;
            boolean var0 = it.field_78900_b != 0.0F || it.field_78902_a != 0.0F;
            var4 = var0;
         }
      }

      return var4;
   }

   @JvmStatic
   public static final boolean isSneaking() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      boolean var2;
      if (var1 == null) {
         var2 = false;
      } else {
         boolean var0 = var1.func_70093_af();
         var2 = var0;
      }

      return var2;
   }

   @JvmStatic
   public static final boolean isSprinting() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      boolean var2;
      if (var1 == null) {
         var2 = false;
      } else {
         boolean var0 = var1.func_70051_ag();
         var2 = var0;
      }

      return var2;
   }

   @JvmStatic
   public static final boolean isFlying() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      boolean var2;
      if (var1 == null) {
         var2 = true;
      } else {
         boolean var0 = var1.func_96092_aw();
         var2 = var0;
      }

      return !var2;
   }

   @JvmStatic
   public static final boolean isSleeping() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      boolean var2;
      if (var1 == null) {
         var2 = false;
      } else {
         boolean var0 = var1.func_70608_bn();
         var2 = var0;
      }

      return var2;
   }

   @JvmStatic
   @NotNull
   public static final String facing() {
      Player var10000 = INSTANCE;
      if (getPlayer() == null) {
         return "";
      } else {
         var10000 = INSTANCE;
         float yaw = getYaw();
         double var1 = (double)yaw;
         String var3;
         if (-22.5D <= var1 ? var1 <= 22.5D : false) {
            var3 = "South";
         } else {
            var1 = (double)yaw;
            if (22.5D <= var1 ? var1 <= 67.5D : false) {
               var3 = "South West";
            } else {
               var1 = (double)yaw;
               if (67.5D <= var1 ? var1 <= 112.5D : false) {
                  var3 = "West";
               } else {
                  var1 = (double)yaw;
                  if (112.5D <= var1 ? var1 <= 157.5D : false) {
                     var3 = "North West";
                  } else if (!((double)yaw < -157.5D) && !((double)yaw > 157.5D)) {
                     var1 = (double)yaw;
                     if (-157.5D <= var1 ? var1 <= -112.5D : false) {
                        var3 = "North East";
                     } else {
                        var1 = (double)yaw;
                        if (-112.5D <= var1 ? var1 <= -67.5D : false) {
                           var3 = "East";
                        } else {
                           var1 = (double)yaw;
                           var3 = (-67.5D <= var1 ? var1 <= -22.5D : false) ? "South East" : "";
                        }
                     }
                  } else {
                     var3 = "North";
                  }
               }
            }
         }

         return var3;
      }
   }

   @JvmStatic
   @NotNull
   public static final List<PotionEffect> getActivePotionEffects() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      List var13;
      if (var1 == null) {
         var13 = null;
      } else {
         Collection var2 = var1.func_70651_bq();
         if (var2 == null) {
            var13 = null;
         } else {
            Iterable $this$map$iv = (Iterable)var2;
            int $i$f$map = false;
            Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
            int $i$f$mapTo = false;
            Iterator var8 = $this$map$iv.iterator();

            while(var8.hasNext()) {
               Object item$iv$iv = var8.next();
               net.minecraft.potion.PotionEffect p0 = (net.minecraft.potion.PotionEffect)item$iv$iv;
               int var11 = false;
               destination$iv$iv.add(new PotionEffect(p0));
            }

            var13 = (List)destination$iv$iv;
         }
      }

      List var0 = var13;
      return var0 == null ? CollectionsKt.emptyList() : var0;
   }

   @JvmStatic
   @NotNull
   public static final Object lookingAt() {
      MovingObjectPosition var10000 = Client.Companion.getMinecraft().field_71476_x;
      if (var10000 == null) {
         return new BlockType(0);
      } else {
         MovingObjectPosition mop = var10000;
         WorldClient var7 = World.getWorld();
         if (var7 == null) {
            return new BlockType(0);
         } else {
            WorldClient world = var7;
            MovingObjectType var8 = mop.field_72313_a;
            Object var9;
            switch(var8 == null ? -1 : Player.WhenMappings.$EnumSwitchMapping$0[var8.ordinal()]) {
            case 1:
               Block var3 = world.func_180495_p(mop.func_178782_a()).func_177230_c();
               Intrinsics.checkNotNullExpressionValue(var3, "world.getBlockState(mop.blockPos).block");
               BlockType var10002 = new BlockType(var3);
               BlockPos var5 = mop.func_178782_a();
               Intrinsics.checkNotNullExpressionValue(var5, "mop.blockPos");
               com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockPos var10003 = new com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockPos(var5);
               BlockFace.Companion var10004 = BlockFace.Companion;
               EnumFacing var6 = mop.field_178784_b;
               Intrinsics.checkNotNullExpressionValue(var6, "mop.sideHit");
               com.chattriggers.ctjs.minecraft.wrappers.world.block.Block block = new com.chattriggers.ctjs.minecraft.wrappers.world.block.Block(var10002, var10003, var10004.fromMCEnumFacing(var6));
               var9 = block.getType().getMcBlock() instanceof BlockSign ? (com.chattriggers.ctjs.minecraft.wrappers.world.block.Block)(new Sign(block)) : block;
               break;
            case 2:
               Entity var2 = mop.field_72308_g;
               Intrinsics.checkNotNullExpressionValue(var2, "mop.entityHit");
               var9 = new com.chattriggers.ctjs.minecraft.wrappers.entity.Entity(var2);
               break;
            default:
               var9 = new BlockType(0);
            }

            return var9;
         }
      }
   }

   @JvmStatic
   @Nullable
   public static final Item getHeldItem() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var2 = getPlayer();
      Item var3;
      if (var2 == null) {
         var3 = null;
      } else {
         InventoryPlayer var4 = var2.field_71071_by;
         if (var4 == null) {
            var3 = null;
         } else {
            ItemStack var5 = var4.func_70448_g();
            if (var5 == null) {
               var3 = null;
            } else {
               ItemStack p0 = var5;
               int var1 = false;
               var3 = new Item(p0);
            }
         }
      }

      return var3;
   }

   @JvmStatic
   public static final void setHeldItemIndex(int index) {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      InventoryPlayer var2 = var1 == null ? null : var1.field_71071_by;
      if (var2 != null) {
         var2.field_70461_c = index;
      }

   }

   @JvmStatic
   public static final int getHeldItemIndex() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var1 = getPlayer();
      int var2;
      if (var1 == null) {
         var2 = -1;
      } else {
         InventoryPlayer var3 = var1.field_71071_by;
         if (var3 == null) {
            var2 = -1;
         } else {
            int var0 = var3.field_70461_c;
            var2 = var0;
         }
      }

      return var2;
   }

   @JvmStatic
   @Nullable
   public static final Inventory getInventory() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var2 = getPlayer();
      Inventory var3;
      if (var2 == null) {
         var3 = null;
      } else {
         InventoryPlayer var4 = var2.field_71071_by;
         if (var4 == null) {
            var3 = null;
         } else {
            IInventory p0 = (IInventory)var4;
            int var1 = false;
            var3 = new Inventory(p0);
         }
      }

      return var3;
   }

   @JvmStatic
   @NotNull
   public static final TextComponent getDisplayName() {
      Player var10000 = INSTANCE;
      PlayerMP var0 = asPlayerMP();
      TextComponent var1 = var0 == null ? null : var0.getDisplayName();
      if (var1 == null) {
         var1 = new TextComponent("");
      }

      return var1;
   }

   @JvmStatic
   public static final void setTabDisplayName(@NotNull TextComponent textComponent) {
      Intrinsics.checkNotNullParameter(textComponent, "textComponent");
      Player var10000 = INSTANCE;
      PlayerMP var1 = asPlayerMP();
      if (var1 != null) {
         var1.setTabDisplayName(textComponent);
      }

   }

   @JvmStatic
   public static final void setNametagName(@NotNull TextComponent textComponent) {
      Intrinsics.checkNotNullParameter(textComponent, "textComponent");
      Player var10000 = INSTANCE;
      PlayerMP var1 = asPlayerMP();
      if (var1 != null) {
         var1.setNametagName(textComponent);
      }

   }

   /** @deprecated */
   @Deprecated(
      message = "Use the better named method",
      replaceWith = @ReplaceWith(
   expression = "getContainer()",
   imports = {}
)
   )
   @JvmStatic
   @Nullable
   public static final Inventory getOpenedInventory() {
      Player var10000 = INSTANCE;
      return getContainer();
   }

   @JvmStatic
   @Nullable
   public static final Inventory getContainer() {
      Player var10000 = INSTANCE;
      EntityPlayerSP var2 = getPlayer();
      Inventory var3;
      if (var2 == null) {
         var3 = null;
      } else {
         Container var4 = var2.field_71070_bA;
         if (var4 == null) {
            var3 = null;
         } else {
            Container p0 = var4;
            int var1 = false;
            var3 = new Inventory(p0);
         }
      }

      return var3;
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Player draw(int x, int y, boolean rotate, boolean showNametag, boolean showArmor, boolean showCape, boolean showHeldItem, boolean showArrows) {
      Player var8 = INSTANCE;
      int var10 = false;
      Renderer.drawPlayer(var8, x, y, rotate, showNametag, showArmor, showCape, showHeldItem, showArrows);
      return var8;
   }

   // $FF: synthetic method
   public static Player draw$default(int var0, int var1, boolean var2, boolean var3, boolean var4, boolean var5, boolean var6, boolean var7, int var8, Object var9) {
      if ((var8 & 4) != 0) {
         var2 = false;
      }

      if ((var8 & 8) != 0) {
         var3 = false;
      }

      if ((var8 & 16) != 0) {
         var4 = true;
      }

      if ((var8 & 32) != 0) {
         var5 = true;
      }

      if ((var8 & 64) != 0) {
         var6 = true;
      }

      if ((var8 & 128) != 0) {
         var7 = true;
      }

      return draw(var0, var1, var2, var3, var4, var5, var6, var7);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Player draw(int x, int y, boolean rotate, boolean showNametag, boolean showArmor, boolean showCape, boolean showHeldItem) {
      return draw$default(x, y, rotate, showNametag, showArmor, showCape, showHeldItem, false, 128, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Player draw(int x, int y, boolean rotate, boolean showNametag, boolean showArmor, boolean showCape) {
      return draw$default(x, y, rotate, showNametag, showArmor, showCape, false, false, 192, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Player draw(int x, int y, boolean rotate, boolean showNametag, boolean showArmor) {
      return draw$default(x, y, rotate, showNametag, showArmor, false, false, false, 224, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Player draw(int x, int y, boolean rotate, boolean showNametag) {
      return draw$default(x, y, rotate, showNametag, false, false, false, false, 240, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Player draw(int x, int y, boolean rotate) {
      return draw$default(x, y, rotate, false, false, false, false, false, 248, (Object)null);
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final Player draw(int x, int y) {
      return draw$default(x, y, false, false, false, false, false, false, 252, (Object)null);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\n\u0010\u0003\u001a\u0004\u0018\u00010\u0004H\u0007J\n\u0010\u0005\u001a\u0004\u0018\u00010\u0004H\u0007J\n\u0010\u0006\u001a\u0004\u0018\u00010\u0004H\u0007J\n\u0010\u0007\u001a\u0004\u0018\u00010\u0004H\u0007¨\u0006\b"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/Player$armor;", "", "()V", "getBoots", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Item;", "getChestplate", "getHelmet", "getLeggings", "ctjs"}
   )
   public static final class armor {
      @NotNull
      public static final Player.armor INSTANCE = new Player.armor();

      private armor() {
      }

      @JvmStatic
      @Nullable
      public static final Item getHelmet() {
         Inventory var10000 = Player.getInventory();
         return var10000 == null ? null : var10000.getStackInSlot(39);
      }

      @JvmStatic
      @Nullable
      public static final Item getChestplate() {
         Inventory var10000 = Player.getInventory();
         return var10000 == null ? null : var10000.getStackInSlot(38);
      }

      @JvmStatic
      @Nullable
      public static final Item getLeggings() {
         Inventory var10000 = Player.getInventory();
         return var10000 == null ? null : var10000.getStackInSlot(37);
      }

      @JvmStatic
      @Nullable
      public static final Item getBoots() {
         Inventory var10000 = Player.getInventory();
         return var10000 == null ? null : var10000.getStackInSlot(36);
      }
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[MovingObjectType.values().length];
         var0[MovingObjectType.BLOCK.ordinal()] = 1;
         var0[MovingObjectType.ENTITY.ordinal()] = 2;
         $EnumSwitchMapping$0 = var0;
      }
   }
}
