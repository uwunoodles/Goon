package com.chattriggers.ctjs.minecraft.wrappers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Team;
import net.minecraftforge.client.GuiIngameForge;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\n\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001$B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\fH\u0007J\u0018\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00070\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\u0004H\u0007J\u0016\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00070\u000e2\u0006\u0010\u0011\u001a\u00020\fH\u0007J\u0010\u0010\u0012\u001a\n\u0018\u00010\u0013j\u0004\u0018\u0001`\u0014H\u0007J\b\u0010\u0015\u001a\u00020\tH\u0007J\b\u0010\u0016\u001a\u00020\u0004H\u0007J\n\u0010\u0017\u001a\u0004\u0018\u00010\u0018H\u0007J\b\u0010\u0019\u001a\u00020\tH\u0007J\b\u0010\u001a\u001a\u00020\u001bH\u0007J \u0010\u001c\u001a\u00020\u001b2\u0006\u0010\u0011\u001a\u00020\f2\u0006\u0010\u001d\u001a\u00020\t2\u0006\u0010\u001e\u001a\u00020\u0004H\u0007J\u0010\u0010\u001f\u001a\u00020\u001b2\u0006\u0010 \u001a\u00020\u0004H\u0007J\u0010\u0010!\u001a\u00020\u001b2\u0006\u0010\"\u001a\u00020\tH\u0007J\b\u0010#\u001a\u00020\u001bH\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006%"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/Scoreboard;", "", "()V", "needsUpdate", "", "scoreboardNames", "", "Lcom/chattriggers/ctjs/minecraft/wrappers/Scoreboard$Score;", "scoreboardTitle", "", "getLineByIndex", "index", "", "getLines", "", "descending", "getLinesByScore", "score", "getScoreboard", "Lnet/minecraft/scoreboard/Scoreboard;", "Lcom/chattriggers/ctjs/utils/kotlin/MCScoreboard;", "getScoreboardTitle", "getShouldRender", "getSidebar", "Lnet/minecraft/scoreboard/ScoreObjective;", "getTitle", "resetCache", "", "setLine", "line", "override", "setShouldRender", "shouldRender", "setTitle", "title", "updateNames", "Score", "ctjs"}
)
public final class Scoreboard {
   @NotNull
   public static final Scoreboard INSTANCE = new Scoreboard();
   private static boolean needsUpdate = true;
   @NotNull
   private static List<Scoreboard.Score> scoreboardNames = (List)(new ArrayList());
   @NotNull
   private static String scoreboardTitle = "";

   private Scoreboard() {
   }

   @JvmStatic
   @Nullable
   public static final net.minecraft.scoreboard.Scoreboard getScoreboard() {
      WorldClient var10000 = World.getWorld();
      return var10000 == null ? null : var10000.func_96441_U();
   }

   @JvmStatic
   @Nullable
   public static final ScoreObjective getSidebar() {
      Scoreboard var10000 = INSTANCE;
      net.minecraft.scoreboard.Scoreboard var0 = getScoreboard();
      return var0 == null ? null : var0.func_96539_a(1);
   }

   @JvmStatic
   @NotNull
   public static final String getScoreboardTitle() {
      Scoreboard var10000 = INSTANCE;
      return getTitle();
   }

   @JvmStatic
   @NotNull
   public static final String getTitle() {
      if (needsUpdate) {
         INSTANCE.updateNames();
         Scoreboard var10000 = INSTANCE;
         needsUpdate = false;
      }

      return scoreboardTitle;
   }

   @JvmStatic
   public static final void setTitle(@NotNull String title) {
      Intrinsics.checkNotNullParameter(title, "title");
      Scoreboard var10000 = INSTANCE;
      ScoreObjective var1 = getSidebar();
      if (var1 != null) {
         var1.func_96681_a(title);
      }

   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final List<Scoreboard.Score> getLines(boolean descending) {
      if (needsUpdate) {
         INSTANCE.updateNames();
         Scoreboard var10000 = INSTANCE;
         needsUpdate = false;
      }

      return descending ? scoreboardNames : CollectionsKt.asReversedMutable(scoreboardNames);
   }

   // $FF: synthetic method
   public static List getLines$default(boolean var0, int var1, Object var2) {
      if ((var1 & 1) != 0) {
         var0 = true;
      }

      return getLines(var0);
   }

   @JvmStatic
   @NotNull
   public static final Scoreboard.Score getLineByIndex(int index) {
      Scoreboard var10000 = INSTANCE;
      return (Scoreboard.Score)getLines$default(false, 1, (Object)null).get(index);
   }

   @JvmStatic
   @NotNull
   public static final List<Scoreboard.Score> getLinesByScore(int score) {
      Scoreboard var10000 = INSTANCE;
      Iterable $this$filter$iv = (Iterable)getLines$default(false, 1, (Object)null);
      int $i$f$filter = false;
      Collection destination$iv$iv = (Collection)(new ArrayList());
      int $i$f$filterTo = false;
      Iterator var6 = $this$filter$iv.iterator();

      while(var6.hasNext()) {
         Object element$iv$iv = var6.next();
         Scoreboard.Score it = (Scoreboard.Score)element$iv$iv;
         int var9 = false;
         if (it.getPoints() == score) {
            destination$iv$iv.add(element$iv$iv);
         }
      }

      return (List)destination$iv$iv;
   }

   @JvmStatic
   public static final void setLine(int score, @NotNull String line, boolean override) {
      Intrinsics.checkNotNullParameter(line, "line");
      Scoreboard var10000 = INSTANCE;
      net.minecraft.scoreboard.Scoreboard var20 = getScoreboard();
      if (var20 != null) {
         net.minecraft.scoreboard.Scoreboard scoreboard = var20;
         var10000 = INSTANCE;
         ScoreObjective var21 = getSidebar();
         if (var21 != null) {
            ScoreObjective sidebarObjective = var21;
            Collection var6 = scoreboard.func_96534_i(sidebarObjective);
            Intrinsics.checkNotNullExpressionValue(var6, "scoreboard.getSortedScores(sidebarObjective)");
            if (override) {
               Iterable $this$forEach$iv = (Iterable)var6;
               int $i$f$forEach = false;
               Collection destination$iv$iv = (Collection)(new ArrayList());
               int $i$f$filterTo = false;
               Iterator var11 = $this$forEach$iv.iterator();

               while(var11.hasNext()) {
                  Object element$iv$iv = var11.next();
                  net.minecraft.scoreboard.Score it = (net.minecraft.scoreboard.Score)element$iv$iv;
                  int var14 = false;
                  if (it.func_96652_c() == score) {
                     destination$iv$iv.add(element$iv$iv);
                  }
               }

               $this$forEach$iv = (Iterable)((List)destination$iv$iv);
               $i$f$forEach = false;
               Iterator var8 = $this$forEach$iv.iterator();

               while(var8.hasNext()) {
                  Object element$iv = var8.next();
                  net.minecraft.scoreboard.Score it = (net.minecraft.scoreboard.Score)element$iv;
                  int var19 = false;
                  scoreboard.func_178822_d(it.func_96653_e(), sidebarObjective);
               }
            }

            net.minecraft.scoreboard.Score var22 = scoreboard.func_96529_a(line, sidebarObjective);
            Intrinsics.checkNotNull(var22);
            net.minecraft.scoreboard.Score theScore = var22;
            theScore.func_96647_c(score);
         }
      }
   }

   @JvmStatic
   public static final void setShouldRender(boolean shouldRender) {
      GuiIngameForge.renderObjective = shouldRender;
   }

   @JvmStatic
   public static final boolean getShouldRender() {
      return GuiIngameForge.renderObjective;
   }

   private final void updateNames() {
      scoreboardNames.clear();
      scoreboardTitle = "";
      net.minecraft.scoreboard.Scoreboard var10000 = getScoreboard();
      if (var10000 != null) {
         net.minecraft.scoreboard.Scoreboard scoreboard = var10000;
         ScoreObjective var15 = getSidebar();
         if (var15 != null) {
            ScoreObjective sidebarObjective = var15;
            String var3 = sidebarObjective.func_96678_d();
            Intrinsics.checkNotNullExpressionValue(var3, "sidebarObjective.displayName");
            scoreboardTitle = var3;
            Collection var4 = scoreboard.func_96534_i(sidebarObjective);
            Intrinsics.checkNotNullExpressionValue(var4, "scoreboard.getSortedScores(sidebarObjective)");
            Iterable $this$map$iv = (Iterable)var4;
            int $i$f$map = false;
            Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
            int $i$f$mapTo = false;
            Iterator var9 = $this$map$iv.iterator();

            while(var9.hasNext()) {
               Object item$iv$iv = var9.next();
               net.minecraft.scoreboard.Score p0 = (net.minecraft.scoreboard.Score)item$iv$iv;
               int var12 = false;
               destination$iv$iv.add(new Scoreboard.Score(p0));
            }

            scoreboardNames = CollectionsKt.toMutableList((Collection)((List)destination$iv$iv));
         }
      }
   }

   @JvmStatic
   public static final void resetCache() {
      Scoreboard var10000 = INSTANCE;
      needsUpdate = true;
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final List<Scoreboard.Score> getLines() {
      return getLines$default(false, 1, (Object)null);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0011\u0012\n\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\u0002\u0010\u0005J\u0006\u0010\b\u001a\u00020\tJ\u0006\u0010\n\u001a\u00020\u000bJ\b\u0010\f\u001a\u00020\tH\u0016R\u0015\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\r"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/Scoreboard$Score;", "", "score", "Lnet/minecraft/scoreboard/Score;", "Lcom/chattriggers/ctjs/utils/kotlin/MCScore;", "(Lnet/minecraft/scoreboard/Score;)V", "getScore", "()Lnet/minecraft/scoreboard/Score;", "getName", "", "getPoints", "", "toString", "ctjs"}
   )
   public static final class Score {
      @NotNull
      private final net.minecraft.scoreboard.Score score;

      public Score(@NotNull net.minecraft.scoreboard.Score score) {
         Intrinsics.checkNotNullParameter(score, "score");
         super();
         this.score = score;
      }

      @NotNull
      public final net.minecraft.scoreboard.Score getScore() {
         return this.score;
      }

      public final int getPoints() {
         return this.score.func_96652_c();
      }

      @NotNull
      public final String getName() {
         net.minecraft.scoreboard.Scoreboard var10000 = Scoreboard.getScoreboard();
         Intrinsics.checkNotNull(var10000);
         String var1 = ScorePlayerTeam.func_96667_a((Team)var10000.func_96509_i(this.score.func_96653_e()), this.score.func_96653_e());
         Intrinsics.checkNotNullExpressionValue(var1, "formatPlayerName(\n      …core.playerName\n        )");
         return var1;
      }

      @NotNull
      public String toString() {
         return this.getName();
      }
   }
}
