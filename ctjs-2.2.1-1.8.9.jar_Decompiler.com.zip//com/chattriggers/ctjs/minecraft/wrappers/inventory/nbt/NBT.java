package com.chattriggers.ctjs.minecraft.wrappers.inventory.nbt;

import com.chattriggers.ctjs.utils.kotlin.ExtensionsKt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;
import net.minecraft.nbt.NBTException;
import net.minecraft.nbt.NBTTagByte;
import net.minecraft.nbt.NBTTagByteArray;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagFloat;
import net.minecraft.nbt.NBTTagInt;
import net.minecraft.nbt.NBTTagIntArray;
import net.minecraft.nbt.NBTTagLong;
import net.minecraft.nbt.NBTTagShort;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.nbt.NBTBase.NBTPrimitive;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.NativeObject;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u001c\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\tH\u0007J\u001c\u0010\n\u001a\u00060\u000bj\u0002`\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\u0010\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0007\u001a\u00020\u0013H\u0007J\u0010\u0010\u0014\u001a\u00020\t2\u0006\u0010\u0007\u001a\u00020\u0015H\u0007J\u001a\u0010\u0016\u001a\u00060\u000bj\u0002`\f*\u00020\u00012\b\u0010\b\u001a\u0004\u0018\u00010\tH\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0017"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBT;", "", "()V", "numberNBTFormat", "Lkotlin/text/Regex;", "parse", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTBase;", "nbt", "options", "Lorg/mozilla/javascript/NativeObject;", "parseString", "Lnet/minecraft/nbt/NBTBase;", "Lcom/chattriggers/ctjs/utils/kotlin/MCNBTBase;", "nbtData", "", "coerceNumericStrings", "", "toArray", "Lorg/mozilla/javascript/NativeArray;", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTTagList;", "toObject", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTTagCompound;", "toNBT", "ctjs"}
)
public final class NBT {
   @NotNull
   public static final NBT INSTANCE = new NBT();
   @NotNull
   private static final Regex numberNBTFormat;

   private NBT() {
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final NBTBase parse(@NotNull Object nbt, @Nullable NativeObject options) throws NBTException {
      Intrinsics.checkNotNullParameter(nbt, "nbt");
      NBTBase var10000;
      if (nbt instanceof NativeObject) {
         var10000 = (NBTBase)(new NBTTagCompound((net.minecraft.nbt.NBTTagCompound)INSTANCE.toNBT(nbt, options)));
      } else if (nbt instanceof NativeArray) {
         net.minecraft.nbt.NBTBase it = INSTANCE.toNBT(nbt, options);
         int var4 = false;
         var10000 = it instanceof net.minecraft.nbt.NBTTagList ? (NBTBase)(new NBTTagList((net.minecraft.nbt.NBTTagList)it)) : new NBTBase(it);
      } else {
         var10000 = new NBTBase(INSTANCE.toNBT(nbt, options));
      }

      return var10000;
   }

   // $FF: synthetic method
   public static NBTBase parse$default(Object var0, NativeObject var1, int var2, Object var3) throws NBTException {
      if ((var2 & 2) != 0) {
         var1 = null;
      }

      return parse(var0, var1);
   }

   @JvmStatic
   @NotNull
   public static final NativeObject toObject(@NotNull NBTTagCompound nbt) {
      Intrinsics.checkNotNullParameter(nbt, "nbt");
      return nbt.toObject();
   }

   @JvmStatic
   @NotNull
   public static final NativeArray toArray(@NotNull NBTTagList nbt) {
      Intrinsics.checkNotNullParameter(nbt, "nbt");
      return nbt.toArray();
   }

   private final net.minecraft.nbt.NBTBase toNBT(Object $this$toNBT, NativeObject options) throws NBTException {
      boolean preferArraysOverLists = Boolean.parseBoolean(ExtensionsKt.getOption(options, "preferArraysOverLists", false));
      boolean coerceNumericStrings = Boolean.parseBoolean(ExtensionsKt.getOption(options, "coerceNumericStrings", false));
      boolean $i$f$map;
      net.minecraft.nbt.NBTBase var10000;
      if ($this$toNBT instanceof NativeObject) {
         net.minecraft.nbt.NBTTagCompound var6 = new net.minecraft.nbt.NBTTagCompound();
         net.minecraft.nbt.NBTTagCompound $this$toNBT_u24lambda_u2d2 = var6;
         $i$f$map = false;
         Set var9 = ((NativeObject)$this$toNBT).entrySet();
         Intrinsics.checkNotNullExpressionValue(var9, "entries");
         Iterable $this$forEach$iv = (Iterable)var9;
         int $i$f$forEach = false;
         Iterator var11 = $this$forEach$iv.iterator();

         while(var11.hasNext()) {
            Object element$iv = var11.next();
            Entry entry = (Entry)element$iv;
            int var14 = false;
            Map var15 = $this$toNBT_u24lambda_u2d2.field_74784_a;
            Intrinsics.checkNotNullExpressionValue(var15, "tagMap");
            String var10001 = entry.getKey().toString();
            NBT var10002 = INSTANCE;
            Object var16 = entry.getValue();
            Intrinsics.checkNotNullExpressionValue(var16, "entry.value");
            var15.put(var10001, var10002.toNBT(var16, options));
         }

         var10000 = (net.minecraft.nbt.NBTBase)var6;
      } else {
         if ($this$toNBT instanceof NativeArray) {
            Iterable $this$map$iv = (Iterable)$this$toNBT;
            $i$f$map = false;
            Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
            int $i$f$mapTo = false;
            Iterator var31 = $this$map$iv.iterator();

            Object item$iv$iv;
            boolean var35;
            while(var31.hasNext()) {
               item$iv$iv = var31.next();
               var35 = false;
               destination$iv$iv.add(item$iv$iv == null ? null : INSTANCE.toNBT(item$iv$iv, options));
            }

            List normalized = (List)destination$iv$iv;
            net.minecraft.nbt.NBTTagList var23;
            boolean var25;
            if (preferArraysOverLists && !normalized.isEmpty()) {
               $this$map$iv = (Iterable)normalized;
               $i$f$map = false;
               Iterator var26;
               Object element$iv;
               net.minecraft.nbt.NBTBase it;
               boolean var32;
               boolean var36;
               if ($this$map$iv instanceof Collection && ((Collection)$this$map$iv).isEmpty()) {
                  var36 = true;
               } else {
                  var26 = $this$map$iv.iterator();

                  while(true) {
                     if (!var26.hasNext()) {
                        var36 = true;
                        break;
                     }

                     element$iv = var26.next();
                     it = (net.minecraft.nbt.NBTBase)element$iv;
                     var32 = false;
                     if (!(it instanceof NBTTagByte)) {
                        var36 = false;
                        break;
                     }
                  }
               }

               net.minecraft.nbt.NBTBase it;
               if (var36) {
                  $this$map$iv = (Iterable)normalized;
                  $i$f$map = false;
                  destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
                  $i$f$mapTo = false;
                  var31 = $this$map$iv.iterator();

                  while(var31.hasNext()) {
                     item$iv$iv = var31.next();
                     it = (net.minecraft.nbt.NBTBase)item$iv$iv;
                     var35 = false;
                     if (it == null) {
                        throw new NullPointerException("null cannot be cast to non-null type net.minecraft.nbt.NBTTagByte");
                     }

                     destination$iv$iv.add(((NBTTagByte)it).func_150290_f());
                  }

                  byte[] var19 = CollectionsKt.toByteArray((Collection)((List)destination$iv$iv));
                  var10000 = (net.minecraft.nbt.NBTBase)(new NBTTagByteArray(var19));
               } else {
                  $this$map$iv = (Iterable)normalized;
                  $i$f$map = false;
                  if ($this$map$iv instanceof Collection && ((Collection)$this$map$iv).isEmpty()) {
                     var36 = true;
                  } else {
                     var26 = $this$map$iv.iterator();

                     while(true) {
                        if (!var26.hasNext()) {
                           var36 = true;
                           break;
                        }

                        element$iv = var26.next();
                        it = (net.minecraft.nbt.NBTBase)element$iv;
                        var32 = false;
                        if (!(it instanceof NBTTagInt)) {
                           var36 = false;
                           break;
                        }
                     }
                  }

                  if (var36) {
                     $this$map$iv = (Iterable)normalized;
                     $i$f$map = false;
                     destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
                     $i$f$mapTo = false;
                     var31 = $this$map$iv.iterator();

                     while(var31.hasNext()) {
                        item$iv$iv = var31.next();
                        it = (net.minecraft.nbt.NBTBase)item$iv$iv;
                        var35 = false;
                        if (it == null) {
                           throw new NullPointerException("null cannot be cast to non-null type net.minecraft.nbt.NBTTagInt");
                        }

                        destination$iv$iv.add(((NBTTagInt)it).func_150287_d());
                     }

                     int[] var20 = CollectionsKt.toIntArray((Collection)((List)destination$iv$iv));
                     var10000 = (net.minecraft.nbt.NBTBase)(new NBTTagIntArray(var20));
                  } else {
                     var23 = new net.minecraft.nbt.NBTTagList();
                     var25 = false;
                     var23.field_74747_a = normalized;
                     var10000 = (net.minecraft.nbt.NBTBase)var23;
                  }
               }

               return var10000;
            }

            var23 = new net.minecraft.nbt.NBTTagList();
            var25 = false;
            var23.field_74747_a = normalized;
            return (net.minecraft.nbt.NBTBase)var23;
         }

         if ($this$toNBT instanceof Boolean) {
            var10000 = (net.minecraft.nbt.NBTBase)(new NBTTagByte((byte)((Boolean)$this$toNBT ? 1 : 0)));
         } else if ($this$toNBT instanceof String) {
            var10000 = this.parseString((String)$this$toNBT, coerceNumericStrings);
         } else if ($this$toNBT instanceof Byte) {
            var10000 = (net.minecraft.nbt.NBTBase)(new NBTTagByte(((Number)$this$toNBT).byteValue()));
         } else if ($this$toNBT instanceof Short) {
            var10000 = (net.minecraft.nbt.NBTBase)(new NBTTagShort(((Number)$this$toNBT).shortValue()));
         } else if ($this$toNBT instanceof Integer) {
            var10000 = (net.minecraft.nbt.NBTBase)(new NBTTagInt(((Number)$this$toNBT).intValue()));
         } else if ($this$toNBT instanceof Long) {
            var10000 = (net.minecraft.nbt.NBTBase)(new NBTTagLong(((Number)$this$toNBT).longValue()));
         } else if ($this$toNBT instanceof Float) {
            var10000 = (net.minecraft.nbt.NBTBase)(new NBTTagFloat(((Number)$this$toNBT).floatValue()));
         } else {
            if (!($this$toNBT instanceof Double)) {
               throw new NBTException(Intrinsics.stringPlus("Invalid NBT. Value provided: ", $this$toNBT));
            }

            var10000 = (net.minecraft.nbt.NBTBase)(new NBTTagDouble(((Number)$this$toNBT).doubleValue()));
         }
      }

      return var10000;
   }

   private final net.minecraft.nbt.NBTBase parseString(String nbtData, boolean coerceNumericStrings) {
      if (!coerceNumericStrings) {
         return (net.minecraft.nbt.NBTBase)(new NBTTagString(nbtData));
      } else {
         MatchResult var10000 = numberNBTFormat.matchEntire((CharSequence)nbtData);
         List var7 = var10000 == null ? null : var10000.getGroupValues();
         if (var7 == null) {
            return (net.minecraft.nbt.NBTBase)(new NBTTagString(nbtData));
         } else {
            List res = var7;
            String number = (String)res.get(1);
            String suffix = (String)res.get(2);
            String var8 = suffix.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(var8, "this as java.lang.String).toLowerCase(Locale.ROOT)");
            String var6 = var8;
            net.minecraft.nbt.NBTBase var9;
            switch(var6.hashCode()) {
            case 0:
               if (var6.equals("")) {
                  var9 = (net.minecraft.nbt.NBTBase)(StringsKt.contains$default((CharSequence)number, (CharSequence)".", false, 2, (Object)null) ? (NBTPrimitive)(new NBTTagDouble(Double.parseDouble(number))) : (NBTPrimitive)(new NBTTagInt(Integer.parseInt(number))));
                  return var9;
               }
               break;
            case 98:
               if (var6.equals("b")) {
                  var9 = (net.minecraft.nbt.NBTBase)(new NBTTagByte(Byte.parseByte(number)));
                  return var9;
               }
               break;
            case 100:
               if (var6.equals("d")) {
                  var9 = (net.minecraft.nbt.NBTBase)(new NBTTagDouble(Double.parseDouble(number)));
                  return var9;
               }
               break;
            case 102:
               if (var6.equals("f")) {
                  var9 = (net.minecraft.nbt.NBTBase)(new NBTTagFloat(Float.parseFloat(number)));
                  return var9;
               }
               break;
            case 108:
               if (var6.equals("l")) {
                  var9 = (net.minecraft.nbt.NBTBase)(new NBTTagLong(Long.parseLong(number)));
                  return var9;
               }
               break;
            case 115:
               if (var6.equals("s")) {
                  var9 = (net.minecraft.nbt.NBTBase)(new NBTTagShort(Short.parseShort(number)));
                  return var9;
               }
            }

            var9 = (net.minecraft.nbt.NBTBase)(new NBTTagString(nbtData));
            return var9;
         }
      }
   }

   @JvmStatic
   @JvmOverloads
   @NotNull
   public static final NBTBase parse(@NotNull Object nbt) throws NBTException {
      Intrinsics.checkNotNullParameter(nbt, "nbt");
      return parse$default(nbt, (NativeObject)null, 2, (Object)null);
   }

   static {
      numberNBTFormat = new Regex("^([+-]?\\d+\\.?\\d*)([bslfd])?$", RegexOption.IGNORE_CASE);
   }
}
