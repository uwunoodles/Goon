package com.chattriggers.ctjs.minecraft.wrappers.inventory;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.gui.inventory.GuiContainerCreative.CreativeSlot;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\u0018\u00002\u00020\u0001B\u0011\u0012\n\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\u0002\u0010\u0005J\u0006\u0010\b\u001a\u00020\tJ\u0006\u0010\n\u001a\u00020\tJ\u0006\u0010\u000b\u001a\u00020\tJ\u0006\u0010\f\u001a\u00020\rJ\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fJ\b\u0010\u0010\u001a\u00020\u0011H\u0016R\u0015\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0012"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Slot;", "", "mcSlot", "Lnet/minecraft/inventory/Slot;", "Lcom/chattriggers/ctjs/utils/kotlin/MCSlot;", "(Lnet/minecraft/inventory/Slot;)V", "getMcSlot", "()Lnet/minecraft/inventory/Slot;", "getDisplayX", "", "getDisplayY", "getIndex", "getInventory", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Inventory;", "getItem", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Item;", "toString", "", "ctjs"}
)
public final class Slot {
   @NotNull
   private final net.minecraft.inventory.Slot mcSlot;

   public Slot(@NotNull net.minecraft.inventory.Slot mcSlot) {
      Intrinsics.checkNotNullParameter(mcSlot, "mcSlot");
      super();
      this.mcSlot = mcSlot;
   }

   @NotNull
   public final net.minecraft.inventory.Slot getMcSlot() {
      return this.mcSlot;
   }

   public final int getIndex() {
      return this.mcSlot instanceof CreativeSlot ? ((CreativeSlot)this.mcSlot).getSlotIndex() : this.mcSlot.field_75222_d;
   }

   public final int getDisplayX() {
      return this.mcSlot.field_75223_e;
   }

   public final int getDisplayY() {
      return this.mcSlot.field_75221_f;
   }

   @NotNull
   public final Inventory getInventory() {
      IInventory var1 = this.mcSlot.field_75224_c;
      Intrinsics.checkNotNullExpressionValue(var1, "mcSlot.inventory");
      return new Inventory(var1);
   }

   @Nullable
   public final Item getItem() {
      ItemStack var10000 = this.mcSlot.func_75211_c();
      Item var3;
      if (var10000 == null) {
         var3 = null;
      } else {
         ItemStack p0 = var10000;
         int var2 = false;
         var3 = new Item(p0);
      }

      return var3;
   }

   @NotNull
   public String toString() {
      return "Slot " + this.getIndex() + " of (" + this.getInventory().getClassName() + ": " + this.getInventory().getName() + "): " + this.getItem();
   }
}
