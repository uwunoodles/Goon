package com.chattriggers.ctjs.minecraft.wrappers.inventory.action;

import com.chattriggers.ctjs.minecraft.wrappers.Player;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0005\u0018\u00002\u00020\u0001:\u0001\u0015B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J\b\u0010\u000b\u001a\u00020\fH\u0016J\u0006\u0010\r\u001a\u00020\u0007J\u0006\u0010\u000e\u001a\u00020\tJ\u0006\u0010\u000f\u001a\u00020\tJ\u000e\u0010\u0010\u001a\u00020\u00002\u0006\u0010\u0006\u001a\u00020\u0011J\u000e\u0010\u0012\u001a\u00020\u00002\u0006\u0010\u0006\u001a\u00020\u0007J\u000e\u0010\u0013\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\tJ\u000e\u0010\u0014\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\tR\u000e\u0010\u0006\u001a\u00020\u0007X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0016"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/ClickAction;", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/Action;", "slot", "", "windowId", "(II)V", "clickType", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/ClickAction$ClickType;", "holdingShift", "", "itemInHand", "complete", "", "getClickType", "getHoldingShift", "getItemInHand", "setClickString", "", "setClickType", "setHoldingShift", "setItemInHand", "ClickType", "ctjs"}
)
public final class ClickAction extends Action {
   private ClickAction.ClickType clickType;
   private boolean holdingShift;
   private boolean itemInHand = Player.getHeldItem() != null;

   public ClickAction(int slot, int windowId) {
      super(slot, windowId);
   }

   @NotNull
   public final ClickAction.ClickType getClickType() {
      ClickAction.ClickType var10000 = this.clickType;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("clickType");
         var10000 = null;
      }

      return var10000;
   }

   @NotNull
   public final ClickAction setClickType(@NotNull ClickAction.ClickType clickType) {
      Intrinsics.checkNotNullParameter(clickType, "clickType");
      ClickAction $this$setClickType_u24lambda_u2d0 = (ClickAction)this;
      int var4 = false;
      $this$setClickType_u24lambda_u2d0.clickType = clickType;
      return (ClickAction)this;
   }

   public final boolean getHoldingShift() {
      return this.holdingShift;
   }

   @NotNull
   public final ClickAction setHoldingShift(boolean holdingShift) {
      ClickAction $this$setHoldingShift_u24lambda_u2d1 = (ClickAction)this;
      int var4 = false;
      $this$setHoldingShift_u24lambda_u2d1.holdingShift = holdingShift;
      return (ClickAction)this;
   }

   public final boolean getItemInHand() {
      return this.itemInHand;
   }

   @NotNull
   public final ClickAction setItemInHand(boolean itemInHand) {
      ClickAction $this$setItemInHand_u24lambda_u2d2 = (ClickAction)this;
      int var4 = false;
      $this$setItemInHand_u24lambda_u2d2.itemInHand = itemInHand;
      return (ClickAction)this;
   }

   @NotNull
   public final ClickAction setClickString(@NotNull String clickType) {
      Intrinsics.checkNotNullParameter(clickType, "clickType");
      ClickAction $this$setClickString_u24lambda_u2d3 = (ClickAction)this;
      int var4 = false;
      String var10001 = clickType.toUpperCase(Locale.ROOT);
      Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).toUpperCase(Locale.ROOT)");
      $this$setClickString_u24lambda_u2d3.clickType = ClickAction.ClickType.valueOf(var10001);
      return (ClickAction)this;
   }

   public void complete() {
      ClickAction.ClickType var10000 = this.clickType;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("clickType");
         var10000 = null;
      }

      int mode = var10000 == ClickAction.ClickType.MIDDLE ? 3 : (this.holdingShift ? 1 : 0);
      ClickAction.ClickType var10001 = this.clickType;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("clickType");
         var10001 = null;
      }

      this.doClick(var10001.getButton(), mode);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\t¨\u0006\n"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/ClickAction$ClickType;", "", "button", "", "(Ljava/lang/String;II)V", "getButton", "()I", "LEFT", "RIGHT", "MIDDLE", "ctjs"}
   )
   public static enum ClickType {
      private final int button;
      LEFT(0),
      RIGHT(1),
      MIDDLE(2);

      private ClickType(int button) {
         this.button = button;
      }

      public final int getButton() {
         return this.button;
      }

      // $FF: synthetic method
      private static final ClickAction.ClickType[] $values() {
         ClickAction.ClickType[] var0 = new ClickAction.ClickType[]{LEFT, RIGHT, MIDDLE};
         return var0;
      }
   }
}
