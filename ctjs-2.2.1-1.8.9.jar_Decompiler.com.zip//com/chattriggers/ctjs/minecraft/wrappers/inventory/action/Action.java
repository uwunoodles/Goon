package com.chattriggers.ctjs.minecraft.wrappers.inventory.action;

import com.chattriggers.ctjs.minecraft.wrappers.Client;
import com.chattriggers.ctjs.minecraft.wrappers.Player;
import com.chattriggers.ctjs.minecraft.wrappers.inventory.Inventory;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.entity.player.EntityPlayer;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0010\u0002\n\u0002\b\u0006\b&\u0018\u0000 \u00112\u00020\u0001:\u0002\u0011\u0012B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J\b\u0010\f\u001a\u00020\rH&J\u0018\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\u00032\u0006\u0010\u0010\u001a\u00020\u0003H\u0004J\u000e\u0010\b\u001a\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0003J\u000e\u0010\u000b\u001a\u00020\u00002\u0006\u0010\u0004\u001a\u00020\u0003R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001a\u0010\u0004\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u0007\"\u0004\b\u000b\u0010\t¨\u0006\u0013"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/Action;", "", "slot", "", "windowId", "(II)V", "getSlot", "()I", "setSlot", "(I)V", "getWindowId", "setWindowId", "complete", "", "doClick", "button", "mode", "Companion", "Type", "ctjs"}
)
public abstract class Action {
   @NotNull
   public static final Action.Companion Companion = new Action.Companion((DefaultConstructorMarker)null);
   private int slot;
   private int windowId;

   public Action(int slot, int windowId) {
      this.slot = slot;
      this.windowId = windowId;
   }

   public final int getSlot() {
      return this.slot;
   }

   public final void setSlot(int var1) {
      this.slot = var1;
   }

   public final int getWindowId() {
      return this.windowId;
   }

   public final void setWindowId(int var1) {
      this.windowId = var1;
   }

   @NotNull
   public final Action setSlot(int slot) {
      Action $this$setSlot_u24lambda_u2d0 = (Action)this;
      int var4 = false;
      $this$setSlot_u24lambda_u2d0.setSlot(slot);
      return (Action)this;
   }

   @NotNull
   public final Action setWindowId(int windowId) {
      Action $this$setWindowId_u24lambda_u2d1 = (Action)this;
      int var4 = false;
      $this$setWindowId_u24lambda_u2d1.setWindowId(windowId);
      return (Action)this;
   }

   public abstract void complete();

   protected final void doClick(int button, int mode) {
      Client.Companion.getMinecraft().field_71442_b.func_78753_a(this.windowId, this.slot, button, mode, (EntityPlayer)Player.getPlayer());
   }

   @JvmStatic
   @NotNull
   public static final Action of(@NotNull Inventory inventory, int slot, @NotNull String typeString) {
      return Companion.of(inventory, slot, typeString);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J \u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0007¨\u0006\u000b"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/Action$Companion;", "", "()V", "of", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/Action;", "inventory", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Inventory;", "slot", "", "typeString", "", "ctjs"}
   )
   public static final class Companion {
      private Companion() {
      }

      @JvmStatic
      @NotNull
      public final Action of(@NotNull Inventory inventory, int slot, @NotNull String typeString) {
         Intrinsics.checkNotNullParameter(inventory, "inventory");
         Intrinsics.checkNotNullParameter(typeString, "typeString");
         String var10000 = typeString.toUpperCase(Locale.ROOT);
         Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String).toUpperCase(Locale.ROOT)");
         Action var4;
         switch(Action.Companion.WhenMappings.$EnumSwitchMapping$0[Action.Type.valueOf(var10000).ordinal()]) {
         case 1:
            var4 = (Action)(new ClickAction(slot, inventory.getWindowId()));
            break;
         case 2:
            var4 = (Action)(new DragAction(slot, inventory.getWindowId()));
            break;
         case 3:
            var4 = (Action)(new KeyAction(slot, inventory.getWindowId()));
            break;
         case 4:
            var4 = (Action)(new DropAction(slot, inventory.getWindowId()));
            break;
         default:
            throw new NoWhenBranchMatchedException();
         }

         return var4;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }

      // $FF: synthetic class
      @Metadata(
         mv = {1, 6, 0},
         k = 3,
         xi = 48
      )
      public class WhenMappings {
         // $FF: synthetic field
         public static final int[] $EnumSwitchMapping$0;

         static {
            int[] var0 = new int[Action.Type.values().length];
            var0[Action.Type.CLICK.ordinal()] = 1;
            var0[Action.Type.DRAG.ordinal()] = 2;
            var0[Action.Type.KEY.ordinal()] = 3;
            var0[Action.Type.DROP.ordinal()] = 4;
            $EnumSwitchMapping$0 = var0;
         }
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/Action$Type;", "", "(Ljava/lang/String;I)V", "CLICK", "DRAG", "KEY", "DROP", "ctjs"}
   )
   public static enum Type {
      CLICK,
      DRAG,
      KEY,
      DROP;

      // $FF: synthetic method
      private static final Action.Type[] $values() {
         Action.Type[] var0 = new Action.Type[]{CLICK, DRAG, KEY, DROP};
         return var0;
      }
   }
}
