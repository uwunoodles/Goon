package com.chattriggers.ctjs.minecraft.wrappers.inventory;

import com.chattriggers.ctjs.engine.langs.js.JSONImpl;
import com.chattriggers.ctjs.minecraft.wrappers.inventory.action.Action;
import com.chattriggers.ctjs.minecraft.wrappers.inventory.action.ClickAction;
import com.chattriggers.ctjs.minecraft.wrappers.inventory.action.DragAction;
import com.chattriggers.ctjs.minecraft.wrappers.inventory.action.DropAction;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.IntIterator;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0015\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\t\u0018\u00002\u00020\u0001B\u000f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004B\u000f\b\u0016\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007J$\u0010\f\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\u00102\b\b\u0002\u0010\u0011\u001a\u00020\u0012H\u0007J\u000e\u0010\u0013\u001a\u00020\u00102\u0006\u0010\u0014\u001a\u00020\u0015J\u000e\u0010\u0013\u001a\u00020\u00102\u0006\u0010\u0016\u001a\u00020\u000eJ\u000e\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001aJ\u001a\u0010\u001b\u001a\u00020\u00002\u0006\u0010\u001c\u001a\u00020\u00122\n\u0010\u001d\u001a\u00020\u001e\"\u00020\u000eJ\u0016\u0010\u001f\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010 \u001a\u00020\u0010J\u0006\u0010!\u001a\u00020\u0012J\u000e\u0010\"\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00150#J\u0006\u0010$\u001a\u00020\u0012J\u0006\u0010%\u001a\u00020\u000eJ\u0010\u0010&\u001a\u0004\u0018\u00010\u00152\u0006\u0010\r\u001a\u00020\u000eJ\u0006\u0010'\u001a\u00020\u000eJ\u000e\u0010(\u001a\u00020\u000e2\u0006\u0010\u0014\u001a\u00020\u0015J\u000e\u0010(\u001a\u00020\u000e2\u0006\u0010\u0016\u001a\u00020\u000eJ\u0006\u0010)\u001a\u00020\u0010J\u0016\u0010*\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0014\u001a\u00020\u0015J\b\u0010+\u001a\u00020\u0012H\u0016R\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006,"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Inventory;", "Lcom/chattriggers/ctjs/engine/langs/js/JSONImpl;", "inventory", "Lnet/minecraft/inventory/IInventory;", "(Lnet/minecraft/inventory/IInventory;)V", "container", "Lnet/minecraft/inventory/Container;", "(Lnet/minecraft/inventory/Container;)V", "getContainer", "()Lnet/minecraft/inventory/Container;", "getInventory", "()Lnet/minecraft/inventory/IInventory;", "click", "slot", "", "shift", "", "button", "", "contains", "item", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Item;", "id", "doAction", "", "action", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/Action;", "drag", "type", "slots", "", "drop", "ctrl", "getClassName", "getItems", "", "getName", "getSize", "getStackInSlot", "getWindowId", "indexOf", "isContainer", "isItemValidForSlot", "toString", "ctjs"}
)
public final class Inventory implements JSONImpl {
   @Nullable
   private final IInventory inventory;
   @Nullable
   private final Container container;

   @Nullable
   public final IInventory getInventory() {
      return this.inventory;
   }

   @Nullable
   public final Container getContainer() {
      return this.container;
   }

   public Inventory(@NotNull IInventory inventory) {
      Intrinsics.checkNotNullParameter(inventory, "inventory");
      super();
      this.inventory = inventory;
      this.container = null;
   }

   public Inventory(@NotNull Container container) {
      Intrinsics.checkNotNullParameter(container, "container");
      super();
      this.container = container;
      this.inventory = null;
   }

   public final int getSize() {
      IInventory var10000 = this.inventory;
      Integer var1 = var10000 == null ? null : var10000.func_70302_i_();
      int var3;
      if (var1 == null) {
         Container var2 = this.container;
         Intrinsics.checkNotNull(var2);
         var3 = var2.field_75151_b.size();
      } else {
         var3 = var1;
      }

      return var3;
   }

   @Nullable
   public final Item getStackInSlot(int slot) {
      ItemStack p0;
      boolean var3;
      ItemStack var4;
      Item var5;
      if (this.inventory == null) {
         Container var10000 = this.container;
         Intrinsics.checkNotNull(var10000);
         var4 = var10000.func_75139_a(slot).func_75211_c();
         if (var4 == null) {
            var5 = null;
         } else {
            p0 = var4;
            var3 = false;
            var5 = new Item(p0);
         }
      } else {
         var4 = this.inventory.func_70301_a(slot);
         if (var4 == null) {
            var5 = null;
         } else {
            p0 = var4;
            var3 = false;
            var5 = new Item(p0);
         }
      }

      return var5;
   }

   public final int getWindowId() {
      Container var10000 = this.container;
      int var2;
      if (var10000 == null) {
         var2 = -1;
      } else {
         int var1 = var10000.field_75152_c;
         var2 = var1;
      }

      return var2;
   }

   public final void doAction(@NotNull Action action) {
      Intrinsics.checkNotNullParameter(action, "action");
      action.complete();
   }

   public final boolean isItemValidForSlot(int slot, @NotNull Item item) {
      Intrinsics.checkNotNullParameter(item, "item");
      return this.inventory == null || this.inventory.func_94041_b(slot, item.getItemStack());
   }

   @NotNull
   public final List<Item> getItems() {
      Iterable $this$map$iv = (Iterable)RangesKt.until(0, this.getSize());
      int $i$f$map = false;
      Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
      int $i$f$mapTo = false;
      Iterator var6 = $this$map$iv.iterator();

      while(var6.hasNext()) {
         int item$iv$iv = ((IntIterator)var6).nextInt();
         int var9 = false;
         destination$iv$iv.add(this.getStackInSlot(item$iv$iv));
      }

      return (List)destination$iv$iv;
   }

   public final boolean contains(@NotNull Item item) {
      Intrinsics.checkNotNullParameter(item, "item");
      return this.getItems().contains(item);
   }

   public final boolean contains(int id) {
      Iterable $this$any$iv = (Iterable)this.getItems();
      int $i$f$any = false;
      boolean var10000;
      if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
         var10000 = false;
      } else {
         Iterator var4 = $this$any$iv.iterator();

         while(var4.hasNext()) {
            Object element$iv = var4.next();
            Item it = (Item)element$iv;
            int var7 = false;
            if (it == null ? false : it.getID() == id) {
               var10000 = true;
               return var10000;
            }
         }

         var10000 = false;
      }

      return var10000;
   }

   public final int indexOf(@NotNull Item item) {
      Intrinsics.checkNotNullParameter(item, "item");
      return this.getItems().indexOf(item);
   }

   public final int indexOf(int id) {
      List $this$indexOfFirst$iv = this.getItems();
      int $i$f$indexOfFirst = false;
      int index$iv = 0;
      Iterator var5 = $this$indexOfFirst$iv.iterator();

      int var10000;
      while(true) {
         if (!var5.hasNext()) {
            var10000 = -1;
            break;
         }

         Object item$iv = var5.next();
         Item it = (Item)item$iv;
         int var8 = false;
         if (it == null ? false : it.getID() == id) {
            var10000 = index$iv;
            break;
         }

         ++index$iv;
      }

      return var10000;
   }

   public final boolean isContainer() {
      return this.container != null;
   }

   @JvmOverloads
   @NotNull
   public final Inventory click(int slot, boolean shift, @NotNull String button) {
      Intrinsics.checkNotNullParameter(button, "button");
      Inventory $this$click_u24lambda_u2d4 = (Inventory)this;
      int var6 = false;
      (new ClickAction(slot, $this$click_u24lambda_u2d4.getWindowId())).setClickString(button).setHoldingShift(shift).complete();
      return (Inventory)this;
   }

   // $FF: synthetic method
   public static Inventory click$default(Inventory var0, int var1, boolean var2, String var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = false;
      }

      if ((var4 & 4) != 0) {
         var3 = "LEFT";
      }

      return var0.click(var1, var2, var3);
   }

   @NotNull
   public final Inventory drop(int slot, boolean ctrl) {
      Inventory $this$drop_u24lambda_u2d5 = (Inventory)this;
      int var5 = false;
      (new DropAction(slot, $this$drop_u24lambda_u2d5.getWindowId())).setHoldingCtrl(ctrl).complete();
      return (Inventory)this;
   }

   @NotNull
   public final Inventory drag(@NotNull String type, @NotNull int... slots) {
      Intrinsics.checkNotNullParameter(type, "type");
      Intrinsics.checkNotNullParameter(slots, "slots");
      Inventory $this$drag_u24lambda_u2d8 = (Inventory)this;
      int var5 = false;
      DragAction $this$drag_u24lambda_u2d8_u24lambda_u2d7 = new DragAction(-999, $this$drag_u24lambda_u2d8.getWindowId());
      int var7 = false;
      DragAction var10000 = $this$drag_u24lambda_u2d8_u24lambda_u2d7.setStage(DragAction.Stage.BEGIN);
      String var10001 = type.toUpperCase(Locale.ROOT);
      Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).toUpperCase(Locale.ROOT)");
      var10000.setClickType(DragAction.ClickType.valueOf(var10001)).complete();
      $this$drag_u24lambda_u2d8_u24lambda_u2d7.setStage(DragAction.Stage.SLOT);
      int[] $this$forEach$iv = slots;
      int $i$f$forEach = false;
      int var10 = 0;

      for(int var11 = slots.length; var10 < var11; ++var10) {
         int element$iv = $this$forEach$iv[var10];
         int var14 = false;
         $this$drag_u24lambda_u2d8_u24lambda_u2d7.setSlot(element$iv).complete();
      }

      $this$drag_u24lambda_u2d8_u24lambda_u2d7.setStage(DragAction.Stage.END).setSlot(-999).complete();
      return (Inventory)this;
   }

   @NotNull
   public final String getName() {
      String var10000;
      if (this.container instanceof ContainerChest) {
         String var1 = ((ContainerChest)this.container).func_85151_d().func_70005_c_();
         Intrinsics.checkNotNullExpressionValue(var1, "container.lowerChestInventory.name");
         var10000 = var1;
      } else {
         IInventory var2 = this.inventory;
         if (var2 == null) {
            var10000 = "container";
         } else {
            var10000 = var2.func_70005_c_();
            if (var10000 == null) {
               var10000 = "container";
            }
         }
      }

      return var10000;
   }

   @NotNull
   public final String getClassName() {
      IInventory var10000 = this.inventory;
      String var2;
      if (var10000 == null) {
         var2 = null;
      } else {
         Class var3 = var10000.getClass();
         var2 = var3 == null ? null : var3.getSimpleName();
      }

      if (var2 == null) {
         Container var4 = this.container;
         Intrinsics.checkNotNull(var4);
         String var1 = var4.getClass().getSimpleName();
         Intrinsics.checkNotNullExpressionValue(var1, "container!!.javaClass.simpleName");
         var2 = var1;
      }

      return var2;
   }

   @NotNull
   public String toString() {
      return "Inventory{name=" + this.getName() + ", size=" + this.getSize() + ", type=" + (this.isContainer() ? "container" : "inventory") + '}';
   }

   @NotNull
   public String toJSON(@NotNull String key) {
      return JSONImpl.DefaultImpls.toJSON((JSONImpl)this, key);
   }

   @JvmOverloads
   @NotNull
   public final Inventory click(int slot, boolean shift) {
      return click$default(this, slot, shift, (String)null, 4, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final Inventory click(int slot) {
      return click$default(this, slot, false, (String)null, 6, (Object)null);
   }
}
