package com.chattriggers.ctjs.minecraft.wrappers.inventory.nbt;

import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.nbt.NBTTagByteArray;
import net.minecraft.nbt.NBTTagIntArray;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mozilla.javascript.NativeObject;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u008c\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0005\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0015\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\n\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001CB\u0011\u0012\n\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\u0002\u0010\u0005J\u0013\u0010\u0013\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u0014\u001a\u00020\bH\u0086\u0002J'\u0010\u0013\u001a\u0004\u0018\u00010\u00152\u0006\u0010\u0014\u001a\u00020\b2\u0006\u0010\u0016\u001a\u00020\u00172\b\u0010\u0018\u001a\u0004\u0018\u00010\u0019¢\u0006\u0002\u0010\u001aJ\u000e\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u0014\u001a\u00020\bJ\u000e\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u0014\u001a\u00020\bJ\u0016\u0010\u001f\u001a\n !*\u0004\u0018\u00010 0 2\u0006\u0010\u0014\u001a\u00020\bJ\u000e\u0010\"\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\bJ\u000e\u0010#\u001a\u00020$2\u0006\u0010\u0014\u001a\u00020\bJ\u000e\u0010%\u001a\u00020&2\u0006\u0010\u0014\u001a\u00020\bJ\u0016\u0010'\u001a\n !*\u0004\u0018\u00010(0(2\u0006\u0010\u0014\u001a\u00020\bJ\u000e\u0010)\u001a\u00020\u00192\u0006\u0010\u0014\u001a\u00020\bJ\u000e\u0010*\u001a\u00020+2\u0006\u0010\u0014\u001a\u00020\bJ\u000e\u0010,\u001a\u00020-2\u0006\u0010\u0014\u001a\u00020\bJ\u0016\u0010.\u001a\n !*\u0004\u0018\u00010\b0\b2\u0006\u0010\u0014\u001a\u00020\bJ\u0010\u0010/\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u0014\u001a\u00020\bJ\u000e\u00100\u001a\u00020\u001e2\u0006\u0010\u0014\u001a\u00020\bJ\u001e\u00101\u001a\n !*\u0004\u0018\u000102022\u0006\u0010\u0014\u001a\u00020\b2\u0006\u0010\u0016\u001a\u00020\u0019J\u000e\u00103\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\bJ\u0019\u00104\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\b2\u0006\u00105\u001a\u00020\u0015H\u0086\u0002J\u0016\u00106\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\b2\u0006\u00105\u001a\u00020\u001cJ\u0016\u00107\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\b2\u0006\u00105\u001a\u00020\u001eJ\u0016\u00108\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\b2\u0006\u00105\u001a\u00020 J\u0016\u00109\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\b2\u0006\u00105\u001a\u00020$J\u0016\u0010:\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\b2\u0006\u00105\u001a\u00020&J\u0016\u0010;\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\b2\u0006\u00105\u001a\u00020(J\u0016\u0010<\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\b2\u0006\u00105\u001a\u00020\u0019J\u0016\u0010=\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\b2\u0006\u00105\u001a\u00020+J\u0016\u0010>\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\b2\u0006\u00105\u001a\u00020\u0001J\u001a\u0010>\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\b2\n\u00105\u001a\u00060\u000fj\u0002`\u0010J\u0016\u0010?\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\b2\u0006\u00105\u001a\u00020-J\u0016\u0010@\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\b2\u0006\u00105\u001a\u00020\bJ\u0006\u0010A\u001a\u00020BR\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00078F¢\u0006\u0006\u001a\u0004\b\t\u0010\nR\u0018\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR!\u0010\r\u001a\u0012\u0012\u0004\u0012\u00020\b\u0012\b\u0012\u00060\u000fj\u0002`\u00100\u000e8F¢\u0006\u0006\u001a\u0004\b\u0011\u0010\u0012¨\u0006D"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTTagCompound;", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTBase;", "rawNBT", "Lnet/minecraft/nbt/NBTTagCompound;", "Lcom/chattriggers/ctjs/utils/kotlin/MCNBTTagCompound;", "(Lnet/minecraft/nbt/NBTTagCompound;)V", "keySet", "", "", "getKeySet", "()Ljava/util/Set;", "getRawNBT", "()Lnet/minecraft/nbt/NBTTagCompound;", "tagMap", "", "Lnet/minecraft/nbt/NBTBase;", "Lcom/chattriggers/ctjs/utils/kotlin/MCNBTBase;", "getTagMap", "()Ljava/util/Map;", "get", "key", "", "type", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTTagCompound$NBTDataType;", "tagType", "", "(Ljava/lang/String;Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTTagCompound$NBTDataType;Ljava/lang/Integer;)Ljava/lang/Object;", "getBoolean", "", "getByte", "", "getByteArray", "", "kotlin.jvm.PlatformType", "getCompoundTag", "getDouble", "", "getFloat", "", "getIntArray", "", "getInteger", "getLong", "", "getShort", "", "getString", "getTag", "getTagId", "getTagList", "Lnet/minecraft/nbt/NBTTagList;", "removeTag", "set", "value", "setBoolean", "setByte", "setByteArray", "setDouble", "setFloat", "setIntArray", "setInteger", "setLong", "setNBTBase", "setShort", "setString", "toObject", "Lorg/mozilla/javascript/NativeObject;", "NBTDataType", "ctjs"}
)
public final class NBTTagCompound extends NBTBase {
   @NotNull
   private final net.minecraft.nbt.NBTTagCompound rawNBT;

   public NBTTagCompound(@NotNull net.minecraft.nbt.NBTTagCompound rawNBT) {
      Intrinsics.checkNotNullParameter(rawNBT, "rawNBT");
      super((net.minecraft.nbt.NBTBase)rawNBT);
      this.rawNBT = rawNBT;
   }

   @NotNull
   public net.minecraft.nbt.NBTTagCompound getRawNBT() {
      return this.rawNBT;
   }

   @NotNull
   public final Map<String, net.minecraft.nbt.NBTBase> getTagMap() {
      Map var1 = this.getRawNBT().field_74784_a;
      Intrinsics.checkNotNullExpressionValue(var1, "rawNBT.tagMap");
      return var1;
   }

   @NotNull
   public final Set<String> getKeySet() {
      Set var1 = this.getRawNBT().func_150296_c();
      Intrinsics.checkNotNullExpressionValue(var1, "rawNBT.keySet");
      return var1;
   }

   @Nullable
   public final NBTBase getTag(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      net.minecraft.nbt.NBTBase tag = this.getRawNBT().func_74781_a(key);
      return tag instanceof net.minecraft.nbt.NBTTagCompound ? (NBTBase)(new NBTTagCompound((net.minecraft.nbt.NBTTagCompound)tag)) : (tag != null ? new NBTBase(tag) : null);
   }

   public final byte getTagId(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.getRawNBT().func_150299_b(key);
   }

   public final byte getByte(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.getRawNBT().func_74771_c(key);
   }

   public final short getShort(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.getRawNBT().func_74765_d(key);
   }

   public final int getInteger(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.getRawNBT().func_74762_e(key);
   }

   public final long getLong(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.getRawNBT().func_74763_f(key);
   }

   public final float getFloat(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.getRawNBT().func_74760_g(key);
   }

   public final double getDouble(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.getRawNBT().func_74769_h(key);
   }

   public final String getString(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.getRawNBT().func_74779_i(key);
   }

   public final byte[] getByteArray(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.getRawNBT().func_74770_j(key);
   }

   public final int[] getIntArray(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.getRawNBT().func_74759_k(key);
   }

   public final boolean getBoolean(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.getRawNBT().func_74767_n(key);
   }

   @NotNull
   public final NBTTagCompound getCompoundTag(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      net.minecraft.nbt.NBTTagCompound var2 = this.getRawNBT().func_74775_l(key);
      Intrinsics.checkNotNullExpressionValue(var2, "rawNBT.getCompoundTag(key)");
      return new NBTTagCompound(var2);
   }

   public final net.minecraft.nbt.NBTTagList getTagList(@NotNull String key, int type) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.getRawNBT().func_150295_c(key, type);
   }

   @Nullable
   public final Object get(@NotNull String key, @NotNull NBTTagCompound.NBTDataType type, @Nullable Integer tagType) {
      Intrinsics.checkNotNullParameter(key, "key");
      Intrinsics.checkNotNullParameter(type, "type");
      Object var10000;
      switch(NBTTagCompound.WhenMappings.$EnumSwitchMapping$0[type.ordinal()]) {
      case 1:
         var10000 = this.getByte(key);
         break;
      case 2:
         var10000 = this.getShort(key);
         break;
      case 3:
         var10000 = this.getInteger(key);
         break;
      case 4:
         var10000 = this.getLong(key);
         break;
      case 5:
         var10000 = this.getFloat(key);
         break;
      case 6:
         var10000 = this.getDouble(key);
         break;
      case 7:
         if (this.getRawNBT().func_150297_b(key, 8)) {
            net.minecraft.nbt.NBTBase var6 = (net.minecraft.nbt.NBTBase)this.getTagMap().get(key);
            if (var6 == null) {
               var10000 = null;
            } else {
               net.minecraft.nbt.NBTBase it = var6;
               int var5 = false;
               var10000 = (new NBTBase(it)).toString();
            }
         } else {
            var10000 = null;
         }
         break;
      case 8:
         if (this.getRawNBT().func_150297_b(key, 7)) {
            var10000 = this.getTagMap().get(key);
            if (var10000 == null) {
               throw new NullPointerException("null cannot be cast to non-null type net.minecraft.nbt.NBTTagByteArray");
            }

            var10000 = ((NBTTagByteArray)var10000).func_150292_c();
         } else {
            var10000 = null;
         }
         break;
      case 9:
         if (this.getRawNBT().func_150297_b(key, 11)) {
            var10000 = this.getTagMap().get(key);
            if (var10000 == null) {
               throw new NullPointerException("null cannot be cast to non-null type net.minecraft.nbt.NBTTagIntArray");
            }

            var10000 = ((NBTTagIntArray)var10000).func_150302_c();
         } else {
            var10000 = null;
         }
         break;
      case 10:
         var10000 = this.getBoolean(key);
         break;
      case 11:
         var10000 = this.getCompoundTag(key);
         break;
      case 12:
         if (tagType == null) {
            throw new IllegalArgumentException("For accessing a tag list you need to provide the tagType argument");
         }

         var10000 = this.getTagList(key, tagType);
         break;
      default:
         throw new NoWhenBranchMatchedException();
      }

      return var10000;
   }

   @Nullable
   public final NBTBase get(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.getTag(key);
   }

   @NotNull
   public final NBTTagCompound setNBTBase(@NotNull String key, @NotNull NBTBase value) {
      Intrinsics.checkNotNullParameter(key, "key");
      Intrinsics.checkNotNullParameter(value, "value");
      return this.setNBTBase(key, value.getRawNBT());
   }

   @NotNull
   public final NBTTagCompound setNBTBase(@NotNull String key, @NotNull net.minecraft.nbt.NBTBase value) {
      Intrinsics.checkNotNullParameter(key, "key");
      Intrinsics.checkNotNullParameter(value, "value");
      NBTTagCompound $this$setNBTBase_u24lambda_u2d1 = (NBTTagCompound)this;
      int var5 = false;
      $this$setNBTBase_u24lambda_u2d1.getRawNBT().func_74782_a(key, value);
      return (NBTTagCompound)this;
   }

   @NotNull
   public final NBTTagCompound setByte(@NotNull String key, byte value) {
      Intrinsics.checkNotNullParameter(key, "key");
      NBTTagCompound $this$setByte_u24lambda_u2d2 = (NBTTagCompound)this;
      int var5 = false;
      $this$setByte_u24lambda_u2d2.getRawNBT().func_74774_a(key, value);
      return (NBTTagCompound)this;
   }

   @NotNull
   public final NBTTagCompound setShort(@NotNull String key, short value) {
      Intrinsics.checkNotNullParameter(key, "key");
      NBTTagCompound $this$setShort_u24lambda_u2d3 = (NBTTagCompound)this;
      int var5 = false;
      $this$setShort_u24lambda_u2d3.getRawNBT().func_74777_a(key, value);
      return (NBTTagCompound)this;
   }

   @NotNull
   public final NBTTagCompound setInteger(@NotNull String key, int value) {
      Intrinsics.checkNotNullParameter(key, "key");
      NBTTagCompound $this$setInteger_u24lambda_u2d4 = (NBTTagCompound)this;
      int var5 = false;
      $this$setInteger_u24lambda_u2d4.getRawNBT().func_74768_a(key, value);
      return (NBTTagCompound)this;
   }

   @NotNull
   public final NBTTagCompound setLong(@NotNull String key, long value) {
      Intrinsics.checkNotNullParameter(key, "key");
      NBTTagCompound $this$setLong_u24lambda_u2d5 = (NBTTagCompound)this;
      int var6 = false;
      $this$setLong_u24lambda_u2d5.getRawNBT().func_74772_a(key, value);
      return (NBTTagCompound)this;
   }

   @NotNull
   public final NBTTagCompound setFloat(@NotNull String key, float value) {
      Intrinsics.checkNotNullParameter(key, "key");
      NBTTagCompound $this$setFloat_u24lambda_u2d6 = (NBTTagCompound)this;
      int var5 = false;
      $this$setFloat_u24lambda_u2d6.getRawNBT().func_74776_a(key, value);
      return (NBTTagCompound)this;
   }

   @NotNull
   public final NBTTagCompound setDouble(@NotNull String key, double value) {
      Intrinsics.checkNotNullParameter(key, "key");
      NBTTagCompound $this$setDouble_u24lambda_u2d7 = (NBTTagCompound)this;
      int var6 = false;
      $this$setDouble_u24lambda_u2d7.getRawNBT().func_74780_a(key, value);
      return (NBTTagCompound)this;
   }

   @NotNull
   public final NBTTagCompound setString(@NotNull String key, @NotNull String value) {
      Intrinsics.checkNotNullParameter(key, "key");
      Intrinsics.checkNotNullParameter(value, "value");
      NBTTagCompound $this$setString_u24lambda_u2d8 = (NBTTagCompound)this;
      int var5 = false;
      $this$setString_u24lambda_u2d8.getRawNBT().func_74778_a(key, value);
      return (NBTTagCompound)this;
   }

   @NotNull
   public final NBTTagCompound setByteArray(@NotNull String key, @NotNull byte[] value) {
      Intrinsics.checkNotNullParameter(key, "key");
      Intrinsics.checkNotNullParameter(value, "value");
      NBTTagCompound $this$setByteArray_u24lambda_u2d9 = (NBTTagCompound)this;
      int var5 = false;
      $this$setByteArray_u24lambda_u2d9.getRawNBT().func_74773_a(key, value);
      return (NBTTagCompound)this;
   }

   @NotNull
   public final NBTTagCompound setIntArray(@NotNull String key, @NotNull int[] value) {
      Intrinsics.checkNotNullParameter(key, "key");
      Intrinsics.checkNotNullParameter(value, "value");
      NBTTagCompound $this$setIntArray_u24lambda_u2d10 = (NBTTagCompound)this;
      int var5 = false;
      $this$setIntArray_u24lambda_u2d10.getRawNBT().func_74783_a(key, value);
      return (NBTTagCompound)this;
   }

   @NotNull
   public final NBTTagCompound setBoolean(@NotNull String key, boolean value) {
      Intrinsics.checkNotNullParameter(key, "key");
      NBTTagCompound $this$setBoolean_u24lambda_u2d11 = (NBTTagCompound)this;
      int var5 = false;
      $this$setBoolean_u24lambda_u2d11.getRawNBT().func_74757_a(key, value);
      return (NBTTagCompound)this;
   }

   @NotNull
   public final NBTTagCompound set(@NotNull String key, @NotNull Object value) {
      Intrinsics.checkNotNullParameter(key, "key");
      Intrinsics.checkNotNullParameter(value, "value");
      NBTTagCompound $this$set_u24lambda_u2d12 = (NBTTagCompound)this;
      int var5 = false;
      if (value instanceof NBTBase) {
         $this$set_u24lambda_u2d12.setNBTBase(key, (NBTBase)value);
      } else if (value instanceof net.minecraft.nbt.NBTBase) {
         $this$set_u24lambda_u2d12.setNBTBase(key, (net.minecraft.nbt.NBTBase)value);
      } else if (value instanceof Byte) {
         $this$set_u24lambda_u2d12.setByte(key, ((Number)value).byteValue());
      } else if (value instanceof Short) {
         $this$set_u24lambda_u2d12.setShort(key, ((Number)value).shortValue());
      } else if (value instanceof Integer) {
         $this$set_u24lambda_u2d12.setInteger(key, ((Number)value).intValue());
      } else if (value instanceof Long) {
         $this$set_u24lambda_u2d12.setLong(key, ((Number)value).longValue());
      } else if (value instanceof Float) {
         $this$set_u24lambda_u2d12.setFloat(key, ((Number)value).floatValue());
      } else if (value instanceof Double) {
         $this$set_u24lambda_u2d12.setDouble(key, ((Number)value).doubleValue());
      } else if (value instanceof String) {
         $this$set_u24lambda_u2d12.setString(key, (String)value);
      } else if (value instanceof byte[]) {
         $this$set_u24lambda_u2d12.setByteArray(key, (byte[])value);
      } else if (value instanceof int[]) {
         $this$set_u24lambda_u2d12.setIntArray(key, (int[])value);
      } else {
         if (!(value instanceof Boolean)) {
            throw new IllegalArgumentException(Intrinsics.stringPlus("Unsupported NBT type: ", value.getClass().getSimpleName()));
         }

         $this$set_u24lambda_u2d12.setBoolean(key, (Boolean)value);
      }

      return (NBTTagCompound)this;
   }

   @NotNull
   public final NBTTagCompound removeTag(@NotNull String key) {
      Intrinsics.checkNotNullParameter(key, "key");
      NBTTagCompound $this$removeTag_u24lambda_u2d13 = (NBTTagCompound)this;
      int var4 = false;
      $this$removeTag_u24lambda_u2d13.getRawNBT().func_82580_o(key);
      return (NBTTagCompound)this;
   }

   @NotNull
   public final NativeObject toObject() {
      return NBTBase.Companion.toObject(this.getRawNBT());
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u000e\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000e¨\u0006\u000f"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTTagCompound$NBTDataType;", "", "(Ljava/lang/String;I)V", "BYTE", "SHORT", "INTEGER", "LONG", "FLOAT", "DOUBLE", "STRING", "BYTE_ARRAY", "INT_ARRAY", "BOOLEAN", "COMPOUND_TAG", "TAG_LIST", "ctjs"}
   )
   public static enum NBTDataType {
      BYTE,
      SHORT,
      INTEGER,
      LONG,
      FLOAT,
      DOUBLE,
      STRING,
      BYTE_ARRAY,
      INT_ARRAY,
      BOOLEAN,
      COMPOUND_TAG,
      TAG_LIST;

      // $FF: synthetic method
      private static final NBTTagCompound.NBTDataType[] $values() {
         NBTTagCompound.NBTDataType[] var0 = new NBTTagCompound.NBTDataType[]{BYTE, SHORT, INTEGER, LONG, FLOAT, DOUBLE, STRING, BYTE_ARRAY, INT_ARRAY, BOOLEAN, COMPOUND_TAG, TAG_LIST};
         return var0;
      }
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[NBTTagCompound.NBTDataType.values().length];
         var0[NBTTagCompound.NBTDataType.BYTE.ordinal()] = 1;
         var0[NBTTagCompound.NBTDataType.SHORT.ordinal()] = 2;
         var0[NBTTagCompound.NBTDataType.INTEGER.ordinal()] = 3;
         var0[NBTTagCompound.NBTDataType.LONG.ordinal()] = 4;
         var0[NBTTagCompound.NBTDataType.FLOAT.ordinal()] = 5;
         var0[NBTTagCompound.NBTDataType.DOUBLE.ordinal()] = 6;
         var0[NBTTagCompound.NBTDataType.STRING.ordinal()] = 7;
         var0[NBTTagCompound.NBTDataType.BYTE_ARRAY.ordinal()] = 8;
         var0[NBTTagCompound.NBTDataType.INT_ARRAY.ordinal()] = 9;
         var0[NBTTagCompound.NBTDataType.BOOLEAN.ordinal()] = 10;
         var0[NBTTagCompound.NBTDataType.COMPOUND_TAG.ordinal()] = 11;
         var0[NBTTagCompound.NBTDataType.TAG_LIST.ordinal()] = 12;
         $EnumSwitchMapping$0 = var0;
      }
   }
}
