package com.chattriggers.ctjs.minecraft.wrappers.inventory.nbt;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mozilla.javascript.NativeArray;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0015\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0011\u0012\n\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\u0002\u0010\u0005J\u000e\u0010\f\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u0001J\u0012\u0010\f\u001a\u00020\u00002\n\u0010\r\u001a\u00060\u000ej\u0002`\u000fJ\u0019\u0010\u0010\u001a\n \u0011*\u0004\u0018\u00010\u000e0\u000e2\u0006\u0010\u0012\u001a\u00020\tH\u0086\u0002J\u0018\u0010\u0010\u001a\u0004\u0018\u00010\u00132\u0006\u0010\u0012\u001a\u00020\t2\u0006\u0010\u0014\u001a\u00020\u0015J\u0016\u0010\u0016\u001a\n \u0011*\u0004\u0018\u00010\u00170\u00172\u0006\u0010\u0012\u001a\u00020\tJ\u000e\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u0012\u001a\u00020\tJ\u000e\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u0012\u001a\u00020\tJ\u0016\u0010\u001c\u001a\n \u0011*\u0004\u0018\u00010\u001d0\u001d2\u0006\u0010\u0012\u001a\u00020\tJ\u0016\u0010\u001e\u001a\n \u0011*\u0004\u0018\u00010\u001f0\u001f2\u0006\u0010\u0012\u001a\u00020\tJ\u0016\u0010 \u001a\u00020\u00002\u0006\u0010\u0012\u001a\u00020\t2\u0006\u0010\r\u001a\u00020\u0001J\u001a\u0010 \u001a\u00020\u00002\u0006\u0010\u0012\u001a\u00020\t2\n\u0010\r\u001a\u00060\u000ej\u0002`\u000fJ\u0016\u0010!\u001a\n \u0011*\u0004\u0018\u00010\u000e0\u000e2\u0006\u0010\u0012\u001a\u00020\tJ\u0019\u0010\"\u001a\u00020\u00002\u0006\u0010#\u001a\u00020\t2\u0006\u0010\r\u001a\u00020\u0001H\u0086\u0002J\u001d\u0010\"\u001a\u00020\u00002\u0006\u0010#\u001a\u00020\t2\n\u0010\r\u001a\u00060\u000ej\u0002`\u000fH\u0086\u0002J\u0006\u0010$\u001a\u00020%R\u0018\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\b\u001a\u00020\t8F¢\u0006\u0006\u001a\u0004\b\n\u0010\u000b¨\u0006&"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTTagList;", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTBase;", "rawNBT", "Lnet/minecraft/nbt/NBTTagList;", "Lcom/chattriggers/ctjs/utils/kotlin/MCNBTTagList;", "(Lnet/minecraft/nbt/NBTTagList;)V", "getRawNBT", "()Lnet/minecraft/nbt/NBTTagList;", "tagCount", "", "getTagCount", "()I", "appendTag", "nbt", "Lnet/minecraft/nbt/NBTBase;", "Lcom/chattriggers/ctjs/utils/kotlin/MCNBTBase;", "get", "kotlin.jvm.PlatformType", "index", "", "type", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTTagCompound$NBTDataType;", "getCompoundTagAt", "Lnet/minecraft/nbt/NBTTagCompound;", "getDoubleAt", "", "getFloatAt", "", "getIntArrayAt", "", "getStringTagAt", "", "insertTag", "removeTag", "set", "id", "toArray", "Lorg/mozilla/javascript/NativeArray;", "ctjs"}
)
public final class NBTTagList extends NBTBase {
   @NotNull
   private final net.minecraft.nbt.NBTTagList rawNBT;

   public NBTTagList(@NotNull net.minecraft.nbt.NBTTagList rawNBT) {
      Intrinsics.checkNotNullParameter(rawNBT, "rawNBT");
      super((net.minecraft.nbt.NBTBase)rawNBT);
      this.rawNBT = rawNBT;
   }

   @NotNull
   public net.minecraft.nbt.NBTTagList getRawNBT() {
      return this.rawNBT;
   }

   public final int getTagCount() {
      return this.getRawNBT().func_74745_c();
   }

   @NotNull
   public final NBTTagList appendTag(@NotNull NBTBase nbt) {
      Intrinsics.checkNotNullParameter(nbt, "nbt");
      return this.appendTag(nbt.getRawNBT());
   }

   @NotNull
   public final NBTTagList appendTag(@NotNull net.minecraft.nbt.NBTBase nbt) {
      Intrinsics.checkNotNullParameter(nbt, "nbt");
      NBTTagList $this$appendTag_u24lambda_u2d0 = (NBTTagList)this;
      int var4 = false;
      $this$appendTag_u24lambda_u2d0.getRawNBT().func_74742_a(nbt);
      return (NBTTagList)this;
   }

   @NotNull
   public final NBTTagList set(int id, @NotNull NBTBase nbt) {
      Intrinsics.checkNotNullParameter(nbt, "nbt");
      return this.set(id, nbt.getRawNBT());
   }

   @NotNull
   public final NBTTagList set(int id, @NotNull net.minecraft.nbt.NBTBase nbt) {
      Intrinsics.checkNotNullParameter(nbt, "nbt");
      NBTTagList $this$set_u24lambda_u2d1 = (NBTTagList)this;
      int var5 = false;
      $this$set_u24lambda_u2d1.getRawNBT().func_150304_a(id, nbt);
      return (NBTTagList)this;
   }

   @NotNull
   public final NBTTagList insertTag(int index, @NotNull NBTBase nbt) {
      Intrinsics.checkNotNullParameter(nbt, "nbt");
      return this.insertTag(index, nbt.getRawNBT());
   }

   @NotNull
   public final NBTTagList insertTag(int index, @NotNull net.minecraft.nbt.NBTBase nbt) {
      Intrinsics.checkNotNullParameter(nbt, "nbt");
      NBTTagList $this$insertTag_u24lambda_u2d2 = (NBTTagList)this;
      int var5 = false;
      $this$insertTag_u24lambda_u2d2.getRawNBT().field_74747_a.add(index, nbt);
      return (NBTTagList)this;
   }

   public final net.minecraft.nbt.NBTBase removeTag(int index) {
      return this.getRawNBT().func_74744_a(index);
   }

   public final net.minecraft.nbt.NBTTagCompound getCompoundTagAt(int index) {
      return this.getRawNBT().func_150305_b(index);
   }

   public final int[] getIntArrayAt(int index) {
      return this.getRawNBT().func_150306_c(index);
   }

   public final double getDoubleAt(int index) {
      return this.getRawNBT().func_150309_d(index);
   }

   public final float getFloatAt(int index) {
      return this.getRawNBT().func_150308_e(index);
   }

   public final String getStringTagAt(int index) {
      return this.getRawNBT().func_150307_f(index);
   }

   public final net.minecraft.nbt.NBTBase get(int index) {
      return this.getRawNBT().func_179238_g(index);
   }

   @Nullable
   public final Object get(int index, @NotNull NBTTagCompound.NBTDataType type) {
      Intrinsics.checkNotNullParameter(type, "type");
      Object var10000;
      switch(NBTTagList.WhenMappings.$EnumSwitchMapping$0[type.ordinal()]) {
      case 1:
         var10000 = this.getFloatAt(index);
         break;
      case 2:
         var10000 = this.getDoubleAt(index);
         break;
      case 3:
         var10000 = this.getStringTagAt(index);
         break;
      case 4:
         var10000 = this.getIntArrayAt(index);
         break;
      case 5:
         var10000 = this.getCompoundTagAt(index);
         break;
      default:
         var10000 = this.get(index);
      }

      return var10000;
   }

   @NotNull
   public final NativeArray toArray() {
      return NBTBase.Companion.toObject(this.getRawNBT());
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[NBTTagCompound.NBTDataType.values().length];
         var0[NBTTagCompound.NBTDataType.FLOAT.ordinal()] = 1;
         var0[NBTTagCompound.NBTDataType.DOUBLE.ordinal()] = 2;
         var0[NBTTagCompound.NBTDataType.STRING.ordinal()] = 3;
         var0[NBTTagCompound.NBTDataType.INT_ARRAY.ordinal()] = 4;
         var0[NBTTagCompound.NBTDataType.COMPOUND_TAG.ordinal()] = 5;
         $EnumSwitchMapping$0 = var0;
      }
   }
}
