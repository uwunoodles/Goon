package com.chattriggers.ctjs.minecraft.wrappers.inventory.nbt;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.nbt.NBTTagByte;
import net.minecraft.nbt.NBTTagByteArray;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagFloat;
import net.minecraft.nbt.NBTTagInt;
import net.minecraft.nbt.NBTTagIntArray;
import net.minecraft.nbt.NBTTagLong;
import net.minecraft.nbt.NBTTagShort;
import net.minecraft.nbt.NBTTagString;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.Scriptable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0005\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0016\u0018\u0000 \u00172\u00020\u0001:\u0001\u0017B\u0011\u0012\n\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\u0002\u0010\u0005J\u000e\u0010\f\u001a\n \r*\u0004\u0018\u00010\u00030\u0003J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001H\u0096\u0002J\u0006\u0010\u0011\u001a\u00020\u000fJ\u0006\u0010\u0012\u001a\u00020\u000fJ\b\u0010\u0013\u001a\u00020\u0014H\u0016J\b\u0010\u0015\u001a\u00020\u0016H\u0016R\u0011\u0010\u0006\u001a\u00020\u00078F¢\u0006\u0006\u001a\u0004\b\b\u0010\tR\u0018\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u0018"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTBase;", "", "rawNBT", "Lnet/minecraft/nbt/NBTBase;", "Lcom/chattriggers/ctjs/utils/kotlin/MCNBTBase;", "(Lnet/minecraft/nbt/NBTBase;)V", "id", "", "getId", "()B", "getRawNBT", "()Lnet/minecraft/nbt/NBTBase;", "copy", "kotlin.jvm.PlatformType", "equals", "", "other", "hasNoTags", "hasTags", "hashCode", "", "toString", "", "Companion", "ctjs"}
)
public class NBTBase {
   @NotNull
   public static final NBTBase.Companion Companion = new NBTBase.Companion((DefaultConstructorMarker)null);
   @NotNull
   private final net.minecraft.nbt.NBTBase rawNBT;

   public NBTBase(@NotNull net.minecraft.nbt.NBTBase rawNBT) {
      Intrinsics.checkNotNullParameter(rawNBT, "rawNBT");
      super();
      this.rawNBT = rawNBT;
   }

   @NotNull
   public net.minecraft.nbt.NBTBase getRawNBT() {
      return this.rawNBT;
   }

   public final byte getId() {
      return this.getRawNBT().func_74732_a();
   }

   public final net.minecraft.nbt.NBTBase copy() {
      return this.getRawNBT().func_74737_b();
   }

   public final boolean hasNoTags() {
      return this.getRawNBT().func_82582_d();
   }

   public final boolean hasTags() {
      return !this.getRawNBT().func_82582_d();
   }

   public boolean equals(@Nullable Object other) {
      return Intrinsics.areEqual(this.getRawNBT(), other);
   }

   public int hashCode() {
      return this.getRawNBT().hashCode();
   }

   @NotNull
   public String toString() {
      String var1 = this.getRawNBT().toString();
      Intrinsics.checkNotNullExpressionValue(var1, "rawNBT.toString()");
      return var1;
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\f\u0010\u0003\u001a\u00020\u0004*\u00020\u0004H\u0002J\f\u0010\u0003\u001a\u00020\u0005*\u00020\u0005H\u0002J\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0001*\u00060\u0007j\u0002`\bJ\u000e\u0010\u0006\u001a\u00020\u0005*\u00060\tj\u0002`\nJ\u000e\u0010\u0006\u001a\u00020\u0004*\u00060\u000bj\u0002`\f¨\u0006\r"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTBase$Companion;", "", "()V", "expose", "Lorg/mozilla/javascript/NativeArray;", "Lorg/mozilla/javascript/NativeObject;", "toObject", "Lnet/minecraft/nbt/NBTBase;", "Lcom/chattriggers/ctjs/utils/kotlin/MCNBTBase;", "Lnet/minecraft/nbt/NBTTagCompound;", "Lcom/chattriggers/ctjs/utils/kotlin/MCNBTTagCompound;", "Lnet/minecraft/nbt/NBTTagList;", "Lcom/chattriggers/ctjs/utils/kotlin/MCNBTTagList;", "ctjs"}
   )
   public static final class Companion {
      private Companion() {
      }

      @Nullable
      public final Object toObject(@NotNull net.minecraft.nbt.NBTBase $this$toObject) {
         Intrinsics.checkNotNullParameter($this$toObject, "<this>");
         Serializable var10000;
         if ($this$toObject instanceof NBTTagString) {
            var10000 = (Serializable)((NBTTagString)$this$toObject).func_150285_a_();
         } else if ($this$toObject instanceof NBTTagByte) {
            var10000 = (Serializable)((NBTTagByte)$this$toObject).func_150290_f();
         } else if ($this$toObject instanceof NBTTagShort) {
            var10000 = (Serializable)((NBTTagShort)$this$toObject).func_150289_e();
         } else if ($this$toObject instanceof NBTTagInt) {
            var10000 = (Serializable)((NBTTagInt)$this$toObject).func_150287_d();
         } else if ($this$toObject instanceof NBTTagLong) {
            var10000 = (Serializable)((NBTTagLong)$this$toObject).func_150291_c();
         } else if ($this$toObject instanceof NBTTagFloat) {
            var10000 = (Serializable)((NBTTagFloat)$this$toObject).func_150288_h();
         } else if ($this$toObject instanceof NBTTagDouble) {
            var10000 = (Serializable)((NBTTagDouble)$this$toObject).func_150286_g();
         } else if ($this$toObject instanceof net.minecraft.nbt.NBTTagCompound) {
            var10000 = (Serializable)this.toObject((net.minecraft.nbt.NBTTagCompound)$this$toObject);
         } else if ($this$toObject instanceof net.minecraft.nbt.NBTTagList) {
            var10000 = (Serializable)this.toObject((net.minecraft.nbt.NBTTagList)$this$toObject);
         } else if ($this$toObject instanceof NBTTagByteArray) {
            byte[] var3 = ((NBTTagByteArray)$this$toObject).func_150292_c();
            Intrinsics.checkNotNullExpressionValue(var3, "byteArray");
            var10000 = (Serializable)this.expose(new NativeArray(ArraysKt.toTypedArray(var3)));
         } else {
            if (!($this$toObject instanceof NBTTagIntArray)) {
               throw new IllegalStateException(Intrinsics.stringPlus("Unknown tag type ", $this$toObject.getClass()).toString());
            }

            int[] var4 = ((NBTTagIntArray)$this$toObject).func_150302_c();
            Intrinsics.checkNotNullExpressionValue(var4, "intArray");
            var10000 = (Serializable)this.expose(new NativeArray(ArraysKt.toTypedArray(var4)));
         }

         return var10000;
      }

      @NotNull
      public final NativeObject toObject(@NotNull net.minecraft.nbt.NBTTagCompound $this$toObject) {
         Intrinsics.checkNotNullParameter($this$toObject, "<this>");
         NativeObject o = new NativeObject();
         this.expose(o);
         Iterator var3 = $this$toObject.func_150296_c().iterator();

         while(var3.hasNext()) {
            String key = (String)var3.next();
            net.minecraft.nbt.NBTBase value = (net.minecraft.nbt.NBTBase)$this$toObject.field_74784_a.get(key);
            if (value != null) {
               o.put(key, (Scriptable)o, this.toObject(value));
            }
         }

         return o;
      }

      @NotNull
      public final NativeArray toObject(@NotNull net.minecraft.nbt.NBTTagList $this$toObject) {
         Intrinsics.checkNotNullParameter($this$toObject, "<this>");
         List tags = (List)(new ArrayList());
         int var3 = 0;
         int var4 = $this$toObject.func_74745_c();

         while(var3 < var4) {
            int i = var3++;
            net.minecraft.nbt.NBTBase var6 = $this$toObject.func_179238_g(i);
            Intrinsics.checkNotNullExpressionValue(var6, "get(i)");
            tags.add(this.toObject(var6));
         }

         Collection $this$toTypedArray$iv = (Collection)tags;
         int $i$f$toTypedArray = false;
         Object[] var10002 = $this$toTypedArray$iv.toArray(new Object[0]);
         Intrinsics.checkNotNull(var10002, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
         NativeArray array = new NativeArray(var10002);
         this.expose(array);
         return array;
      }

      private final NativeArray expose(NativeArray $this$expose) {
         int var4 = false;
         $this$expose.exportAsJSClass(32, (Scriptable)$this$expose, false);
         return $this$expose;
      }

      private final NativeObject expose(NativeObject $this$expose) {
         int var4 = false;
         $this$expose.exportAsJSClass(12, (Scriptable)$this$expose, false);
         return $this$expose;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
