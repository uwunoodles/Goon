package com.chattriggers.ctjs.minecraft.wrappers.inventory.action;

import java.util.Locale;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0006\u0018\u00002\u00020\u0001:\u0002\u0013\u0014B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J\b\u0010\n\u001a\u00020\u000bH\u0016J\u0006\u0010\f\u001a\u00020\u0007J\u0006\u0010\r\u001a\u00020\tJ\u000e\u0010\u000e\u001a\u00020\u00002\u0006\u0010\u0006\u001a\u00020\u000fJ\u000e\u0010\u0010\u001a\u00020\u00002\u0006\u0010\u0006\u001a\u00020\u0007J\u000e\u0010\u0011\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\tJ\u000e\u0010\u0012\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u000fR\u000e\u0010\u0006\u001a\u00020\u0007X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082.¢\u0006\u0002\n\u0000¨\u0006\u0015"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/DragAction;", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/Action;", "slot", "", "windowId", "(II)V", "clickType", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/DragAction$ClickType;", "stage", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/DragAction$Stage;", "complete", "", "getClickType", "getStage", "setClickString", "", "setClickType", "setStage", "setStageString", "ClickType", "Stage", "ctjs"}
)
public final class DragAction extends Action {
   private DragAction.ClickType clickType;
   private DragAction.Stage stage;

   public DragAction(int slot, int windowId) {
      super(slot, windowId);
   }

   @NotNull
   public final DragAction.ClickType getClickType() {
      DragAction.ClickType var10000 = this.clickType;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("clickType");
         var10000 = null;
      }

      return var10000;
   }

   @NotNull
   public final DragAction setClickType(@NotNull DragAction.ClickType clickType) {
      Intrinsics.checkNotNullParameter(clickType, "clickType");
      DragAction $this$setClickType_u24lambda_u2d0 = (DragAction)this;
      int var4 = false;
      $this$setClickType_u24lambda_u2d0.clickType = clickType;
      return (DragAction)this;
   }

   @NotNull
   public final DragAction.Stage getStage() {
      DragAction.Stage var10000 = this.stage;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("stage");
         var10000 = null;
      }

      return var10000;
   }

   @NotNull
   public final DragAction setStage(@NotNull DragAction.Stage stage) {
      Intrinsics.checkNotNullParameter(stage, "stage");
      DragAction $this$setStage_u24lambda_u2d1 = (DragAction)this;
      int var4 = false;
      $this$setStage_u24lambda_u2d1.stage = stage;
      return (DragAction)this;
   }

   @NotNull
   public final DragAction setClickString(@NotNull String clickType) {
      Intrinsics.checkNotNullParameter(clickType, "clickType");
      DragAction $this$setClickString_u24lambda_u2d2 = (DragAction)this;
      int var4 = false;
      String var10001 = clickType.toUpperCase(Locale.ROOT);
      Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).toUpperCase(Locale.ROOT)");
      $this$setClickString_u24lambda_u2d2.clickType = DragAction.ClickType.valueOf(var10001);
      return (DragAction)this;
   }

   @NotNull
   public final DragAction setStageString(@NotNull String stage) {
      Intrinsics.checkNotNullParameter(stage, "stage");
      DragAction $this$setStageString_u24lambda_u2d3 = (DragAction)this;
      int var4 = false;
      String var10001 = stage.toUpperCase(Locale.ROOT);
      Intrinsics.checkNotNullExpressionValue(var10001, "this as java.lang.String).toUpperCase(Locale.ROOT)");
      $this$setStageString_u24lambda_u2d3.stage = DragAction.Stage.valueOf(var10001);
      return (DragAction)this;
   }

   public void complete() {
      DragAction.Stage var10000 = this.stage;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("stage");
         var10000 = null;
      }

      int var2 = var10000.getStage() & 3;
      DragAction.ClickType var10001 = this.clickType;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("clickType");
         var10001 = null;
      }

      int button = (var2 | var10001.getButton() & 3) << 2;
      var10000 = this.stage;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("stage");
         var10000 = null;
      }

      if (var10000 != DragAction.Stage.SLOT) {
         this.setSlot(-999);
         System.out.println("Enforcing slot of -999");
      }

      this.doClick(button, 5);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\t¨\u0006\n"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/DragAction$ClickType;", "", "button", "", "(Ljava/lang/String;II)V", "getButton", "()I", "LEFT", "RIGHT", "MIDDLE", "ctjs"}
   )
   public static enum ClickType {
      private final int button;
      LEFT(0),
      RIGHT(1),
      MIDDLE(2);

      private ClickType(int button) {
         this.button = button;
      }

      public final int getButton() {
         return this.button;
      }

      // $FF: synthetic method
      private static final DragAction.ClickType[] $values() {
         DragAction.ClickType[] var0 = new DragAction.ClickType[]{LEFT, RIGHT, MIDDLE};
         return var0;
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\t¨\u0006\n"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/action/DragAction$Stage;", "", "stage", "", "(Ljava/lang/String;II)V", "getStage", "()I", "BEGIN", "SLOT", "END", "ctjs"}
   )
   public static enum Stage {
      private final int stage;
      BEGIN(0),
      SLOT(1),
      END(2);

      private Stage(int stage) {
         this.stage = stage;
      }

      public final int getStage() {
         return this.stage;
      }

      // $FF: synthetic method
      private static final DragAction.Stage[] $values() {
         DragAction.Stage[] var0 = new DragAction.Stage[]{BEGIN, SLOT, END};
         return var0;
      }
   }
}
