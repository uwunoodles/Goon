package com.chattriggers.ctjs.minecraft.wrappers.inventory;

import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.minecraft.libs.renderer.Renderer;
import com.chattriggers.ctjs.minecraft.objects.message.TextComponent;
import com.chattriggers.ctjs.minecraft.wrappers.Client;
import com.chattriggers.ctjs.minecraft.wrappers.Player;
import com.chattriggers.ctjs.minecraft.wrappers.entity.Entity;
import com.chattriggers.ctjs.minecraft.wrappers.inventory.nbt.NBTTagCompound;
import com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockType;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.collections.MapsKt;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.util.IChatComponent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0082\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\b\n\u0002\u0010$\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0011\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u000f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004B\u000f\b\u0016\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007B\u000f\b\u0016\u0012\u0006\u0010\b\u001a\u00020\t¢\u0006\u0002\u0010\nB\u000f\b\u0016\u0012\u0006\u0010\u000b\u001a\u00020\f¢\u0006\u0002\u0010\rB\u000f\b\u0016\u0012\u0006\u0010\u000e\u001a\u00020\u000f¢\u0006\u0002\u0010\u0010B\u000f\b\u0016\u0012\u0006\u0010\u0011\u001a\u00020\u0012¢\u0006\u0002\u0010\u0013J\u000e\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u0010\u001f\u001a\u00020\u001d2\u0006\u0010\u000b\u001a\u00020\fJ0\u0010 \u001a\u00020!2\b\b\u0002\u0010\"\u001a\u00020#2\b\b\u0002\u0010$\u001a\u00020#2\b\b\u0002\u0010%\u001a\u00020#2\b\b\u0002\u0010&\u001a\u00020#H\u0007J\u0013\u0010'\u001a\u00020\u001d2\b\u0010(\u001a\u0004\u0018\u00010\u0001H\u0096\u0002J\u0006\u0010)\u001a\u00020\tJ\u0006\u0010*\u001a\u00020\tJ\u0012\u0010+\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\t0,J\u0006\u0010-\u001a\u00020\tJ\b\u0010.\u001a\u00020/H\u0007J\f\u00100\u001a\b\u0012\u0004\u0012\u00020\u000601J\u0006\u00102\u001a\u00020\tJ\u0006\u00103\u001a\u00020\tJ\u0006\u00104\u001a\u00020/J\u0006\u00105\u001a\u00020\u0006J\u0006\u00106\u001a\u00020\u0006J\u0006\u00107\u001a\u00020\u0006J\u0006\u00108\u001a\u00020\tJ\u0006\u00109\u001a\u00020:J\u0006\u0010;\u001a\u00020\u0006J\b\u0010<\u001a\u00020\tH\u0016J\u0006\u0010=\u001a\u00020\u001dJ\u0006\u0010>\u001a\u00020\u001dJ\u0006\u0010?\u001a\u00020\u001dJ\u000e\u0010@\u001a\u00020\u00002\u0006\u0010A\u001a\u00020\tJ\u001f\u0010B\u001a\u00020\u00002\u0012\u0010C\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00060D\"\u00020\u0006¢\u0006\u0002\u0010EJ\u000e\u0010F\u001a\u00020\u00002\u0006\u0010G\u001a\u00020\u0006J\u000e\u0010H\u001a\u00020\u00002\u0006\u0010I\u001a\u00020\tJ\b\u0010J\u001a\u00020\u0006H\u0016R\u0015\u0010\u0014\u001a\u00060\u0015j\u0002`\u0016¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\u001a\"\u0004\b\u001b\u0010\u0004¨\u0006K"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Item;", "", "itemStack", "Lnet/minecraft/item/ItemStack;", "(Lnet/minecraft/item/ItemStack;)V", "itemName", "", "(Ljava/lang/String;)V", "itemID", "", "(I)V", "block", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockType;", "(Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockType;)V", "entityItem", "Lnet/minecraft/entity/item/EntityItem;", "(Lnet/minecraft/entity/item/EntityItem;)V", "entity", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/Entity;", "(Lcom/chattriggers/ctjs/minecraft/wrappers/entity/Entity;)V", "item", "Lnet/minecraft/item/Item;", "Lcom/chattriggers/ctjs/utils/kotlin/MCItem;", "getItem", "()Lnet/minecraft/item/Item;", "getItemStack", "()Lnet/minecraft/item/ItemStack;", "setItemStack", "canDestroy", "", "canHarvest", "canPlaceOn", "draw", "", "x", "", "y", "scale", "z", "equals", "other", "getDamage", "getDurability", "getEnchantments", "", "getID", "getItemNBT", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/nbt/NBTTagCompound;", "getLore", "", "getMaxDamage", "getMetadata", "getNBT", "getName", "getRawNBT", "getRegistryName", "getStackSize", "getTextComponent", "Lcom/chattriggers/ctjs/minecraft/objects/message/TextComponent;", "getUnlocalizedName", "hashCode", "isDamagable", "isEnchantable", "isEnchanted", "setDamage", "damage", "setLore", "loreLines", "", "([Ljava/lang/String;)Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Item;", "setName", "name", "setStackSize", "stackSize", "toString", "ctjs"}
)
public final class Item {
   @NotNull
   private final net.minecraft.item.Item item;
   @NotNull
   private ItemStack itemStack;

   @NotNull
   public final net.minecraft.item.Item getItem() {
      return this.item;
   }

   @NotNull
   public final ItemStack getItemStack() {
      return this.itemStack;
   }

   public final void setItemStack(@NotNull ItemStack var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.itemStack = var1;
   }

   public Item(@NotNull ItemStack itemStack) {
      Intrinsics.checkNotNullParameter(itemStack, "itemStack");
      super();
      net.minecraft.item.Item var2 = itemStack.func_77973_b();
      Intrinsics.checkNotNullExpressionValue(var2, "itemStack.item");
      this.item = var2;
      this.itemStack = itemStack;
   }

   public Item(@NotNull String itemName) {
      Intrinsics.checkNotNullParameter(itemName, "itemName");
      super();
      net.minecraft.item.Item var2 = net.minecraft.item.Item.func_111206_d(itemName);
      if (var2 == null) {
         throw new IllegalArgumentException("Item with name or id " + itemName + " does not exist");
      } else {
         this.item = var2;
         this.itemStack = new ItemStack(this.item);
      }
   }

   public Item(int itemID) {
      net.minecraft.item.Item var2 = net.minecraft.item.Item.func_150899_d(itemID);
      if (var2 == null) {
         throw new IllegalArgumentException("Item with id " + itemID + " does not exist");
      } else {
         this.item = var2;
         this.itemStack = new ItemStack(this.item);
      }
   }

   public Item(@NotNull BlockType block) {
      Intrinsics.checkNotNullParameter(block, "block");
      super();
      net.minecraft.item.Item var2 = net.minecraft.item.Item.func_150898_a(block.getMcBlock());
      if (var2 == null) {
         throw new IllegalArgumentException("BlockType " + block + " does not exist");
      } else {
         this.item = var2;
         this.itemStack = new ItemStack(this.item);
      }
   }

   public Item(@NotNull EntityItem entityItem) {
      Intrinsics.checkNotNullParameter(entityItem, "entityItem");
      super();
      net.minecraft.item.Item var2 = entityItem.func_92059_d().func_77973_b();
      Intrinsics.checkNotNullExpressionValue(var2, "entityItem.entityItem.item");
      this.item = var2;
      ItemStack var3 = entityItem.func_92059_d();
      Intrinsics.checkNotNullExpressionValue(var3, "entityItem.entityItem");
      this.itemStack = var3;
   }

   public Item(@NotNull Entity entity) {
      Intrinsics.checkNotNullParameter(entity, "entity");
      super();
      if (!(entity.getEntity() instanceof EntityItem)) {
         int var3 = false;
         String var5 = "Entity is not of type EntityItem";
         throw new IllegalArgumentException(var5.toString());
      } else {
         net.minecraft.item.Item var2 = ((EntityItem)entity.getEntity()).func_92059_d().func_77973_b();
         Intrinsics.checkNotNullExpressionValue(var2, "entity.entity.entityItem.item");
         this.item = var2;
         ItemStack var4 = ((EntityItem)entity.getEntity()).func_92059_d();
         Intrinsics.checkNotNullExpressionValue(var4, "entity.entity.entityItem");
         this.itemStack = var4;
      }
   }

   @NotNull
   public final TextComponent getTextComponent() {
      IChatComponent var1 = this.itemStack.func_151000_E();
      Intrinsics.checkNotNullExpressionValue(var1, "itemStack.chatComponent");
      return new TextComponent(var1);
   }

   @NotNull
   public final String getRawNBT() {
      String var1 = this.itemStack.serializeNBT().toString();
      Intrinsics.checkNotNullExpressionValue(var1, "itemStack.serializeNBT().toString()");
      return var1;
   }

   @NotNull
   public final NBTTagCompound getNBT() {
      net.minecraft.nbt.NBTTagCompound var1 = this.itemStack.serializeNBT();
      Intrinsics.checkNotNullExpressionValue(var1, "itemStack.serializeNBT()");
      return new NBTTagCompound(var1);
   }

   /** @deprecated */
   @Deprecated(
      message = "Use the better-named method",
      replaceWith = @ReplaceWith(
   expression = "getNBT",
   imports = {}
)
   )
   @NotNull
   public final NBTTagCompound getItemNBT() {
      return this.getNBT();
   }

   public final int getID() {
      return net.minecraft.item.Item.func_150891_b(this.item);
   }

   @NotNull
   public final Item setStackSize(int stackSize) {
      Item $this$setStackSize_u24lambda_u2d1 = (Item)this;
      int var4 = false;
      $this$setStackSize_u24lambda_u2d1.getItemStack().field_77994_a = stackSize;
      return (Item)this;
   }

   public final int getStackSize() {
      return this.itemStack.field_77994_a;
   }

   @NotNull
   public final String getUnlocalizedName() {
      String var1 = this.item.func_77658_a();
      Intrinsics.checkNotNullExpressionValue(var1, "item.unlocalizedName");
      return var1;
   }

   @NotNull
   public final String getRegistryName() {
      return this.item.getRegistryName().toString();
   }

   @NotNull
   public final String getName() {
      String var1 = this.itemStack.func_82833_r();
      Intrinsics.checkNotNullExpressionValue(var1, "itemStack.displayName");
      return var1;
   }

   @NotNull
   public final Item setName(@NotNull String name) {
      Intrinsics.checkNotNullParameter(name, "name");
      Item $this$setName_u24lambda_u2d2 = (Item)this;
      int var4 = false;
      $this$setName_u24lambda_u2d2.getItemStack().func_151001_c(ChatLib.addColor(name));
      return (Item)this;
   }

   @NotNull
   public final Map<String, Integer> getEnchantments() {
      Map var1 = EnchantmentHelper.func_82781_a(this.itemStack);
      Intrinsics.checkNotNullExpressionValue(var1, "getEnchantments(itemStack)");
      int $i$f$mapKeys = false;
      Map destination$iv$iv = (Map)(new LinkedHashMap(MapsKt.mapCapacity(var1.size())));
      int $i$f$mapKeysTo = false;
      Iterable $this$associateByTo$iv$iv$iv = (Iterable)var1.entrySet();
      int $i$f$associateByTo = false;
      Iterator var8 = $this$associateByTo$iv$iv$iv.iterator();

      while(var8.hasNext()) {
         Object element$iv$iv$iv = var8.next();
         Entry it = (Entry)element$iv$iv$iv;
         int var11 = false;
         Object var12 = it.getKey();
         Intrinsics.checkNotNullExpressionValue(var12, "it.key");
         String var13 = Enchantment.func_180306_c(((Number)var12).intValue()).func_77320_a();
         Intrinsics.checkNotNullExpressionValue(var13, "getEnchantmentById(\n    …dif\n                .name");
         String var10001 = StringsKt.replace$default(var13, "enchantment.", "", false, 4, (Object)null);
         Entry it$iv$iv = (Entry)element$iv$iv$iv;
         String var15 = var10001;
         int var17 = false;
         Object var19 = it$iv$iv.getValue();
         destination$iv$iv.put(var15, var19);
      }

      return destination$iv$iv;
   }

   public final boolean isEnchantable() {
      return this.itemStack.func_77956_u();
   }

   public final boolean isEnchanted() {
      return this.itemStack.func_77948_v();
   }

   public final int getMetadata() {
      return this.itemStack.func_77960_j();
   }

   public final boolean canPlaceOn(@NotNull BlockType block) {
      Intrinsics.checkNotNullParameter(block, "block");
      return this.itemStack.func_179547_d(block.getMcBlock());
   }

   public final boolean canHarvest(@NotNull BlockType block) {
      Intrinsics.checkNotNullParameter(block, "block");
      return this.itemStack.func_150998_b(block.getMcBlock());
   }

   public final boolean canDestroy(@NotNull BlockType block) {
      Intrinsics.checkNotNullParameter(block, "block");
      return this.itemStack.func_179544_c(block.getMcBlock());
   }

   public final int getDurability() {
      return this.getMaxDamage() - this.getDamage();
   }

   public final int getDamage() {
      return this.itemStack.func_77952_i();
   }

   @NotNull
   public final Item setDamage(int damage) {
      Item $this$setDamage_u24lambda_u2d4 = (Item)this;
      int var4 = false;
      $this$setDamage_u24lambda_u2d4.getItemStack().func_77964_b(damage);
      return (Item)this;
   }

   public final int getMaxDamage() {
      return this.itemStack.func_77958_k();
   }

   public final boolean isDamagable() {
      return this.itemStack.func_77984_f();
   }

   @NotNull
   public final List<String> getLore() {
      List var1 = this.itemStack.func_82840_a((EntityPlayer)Player.getPlayer(), Client.Companion.getMinecraft().field_71474_y.field_82882_x);
      Intrinsics.checkNotNullExpressionValue(var1, "itemStack.getTooltip(Pla…ngs.advancedItemTooltips)");
      return var1;
   }

   @NotNull
   public final Item setLore(@NotNull String... loreLines) {
      Intrinsics.checkNotNullParameter(loreLines, "loreLines");
      Item $this$setLore_u24lambda_u2d8 = (Item)this;
      int var4 = false;
      if ($this$setLore_u24lambda_u2d8.getItemStack().func_77978_p() == null) {
         $this$setLore_u24lambda_u2d8.getItemStack().func_77982_d(new net.minecraft.nbt.NBTTagCompound());
      }

      NBTTagCompound it = $this$setLore_u24lambda_u2d8.getNBT().getCompoundTag("tag");
      int var7 = false;
      if (!it.getRawNBT().func_74764_b("display")) {
         it.set("display", new net.minecraft.nbt.NBTTagCompound());
      }

      it = it.getCompoundTag("display");
      var7 = false;
      if (!it.getRawNBT().func_74764_b("display")) {
         it.set("Lore", new NBTTagList());
      }

      NBTTagList lore = it.getTagList("Lore", 8);
      lore.field_74747_a.clear();
      Object[] $this$forEach$iv = loreLines;
      int $i$f$forEach = false;
      int var14 = 0;

      for(int var9 = loreLines.length; var14 < var9; ++var14) {
         Object element$iv = $this$forEach$iv[var14];
         int var12 = false;
         lore.func_74742_a((NBTBase)(new NBTTagString(ChatLib.addColor(element$iv))));
      }

      return (Item)this;
   }

   @JvmOverloads
   public final void draw(float x, float y, float scale, float z) {
      RenderItem itemRenderer = Client.Companion.getMinecraft().func_175599_af();
      GlStateManager.func_179152_a(scale, scale, 1.0F);
      GlStateManager.func_179109_b(x / scale, y / scale, 0.0F);
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      RenderHelper.func_74519_b();
      RenderHelper.func_74520_c();
      itemRenderer.field_77023_b = z;
      itemRenderer.func_175042_a(this.itemStack, 0, 0);
      Renderer.finishDraw();
   }

   // $FF: synthetic method
   public static void draw$default(Item var0, float var1, float var2, float var3, float var4, int var5, Object var6) {
      if ((var5 & 1) != 0) {
         var1 = 0.0F;
      }

      if ((var5 & 2) != 0) {
         var2 = 0.0F;
      }

      if ((var5 & 4) != 0) {
         var3 = 1.0F;
      }

      if ((var5 & 8) != 0) {
         var4 = 200.0F;
      }

      var0.draw(var1, var2, var3, var4);
   }

   public boolean equals(@Nullable Object other) {
      return other instanceof Item && this.getID() == ((Item)other).getID() && this.getStackSize() == ((Item)other).getStackSize() && this.getDamage() == ((Item)other).getDamage();
   }

   public int hashCode() {
      int result = this.item.hashCode();
      result = 31 * result + this.itemStack.hashCode();
      return result;
   }

   @NotNull
   public String toString() {
      String var1 = this.itemStack.toString();
      Intrinsics.checkNotNullExpressionValue(var1, "itemStack.toString()");
      return var1;
   }

   @JvmOverloads
   public final void draw(float x, float y, float scale) {
      draw$default(this, x, y, scale, 0.0F, 8, (Object)null);
   }

   @JvmOverloads
   public final void draw(float x, float y) {
      draw$default(this, x, y, 0.0F, 0.0F, 12, (Object)null);
   }

   @JvmOverloads
   public final void draw(float x) {
      draw$default(this, x, 0.0F, 0.0F, 0.0F, 14, (Object)null);
   }

   @JvmOverloads
   public final void draw() {
      draw$default(this, 0.0F, 0.0F, 0.0F, 0.0F, 15, (Object)null);
   }
}
