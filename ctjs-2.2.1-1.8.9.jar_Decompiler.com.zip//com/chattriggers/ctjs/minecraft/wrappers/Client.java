package com.chattriggers.ctjs.minecraft.wrappers;

import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.minecraft.libs.renderer.Renderer;
import com.chattriggers.ctjs.minecraft.listeners.ClientListener;
import com.chattriggers.ctjs.minecraft.objects.keybind.KeyBind;
import com.chattriggers.ctjs.minecraft.wrappers.inventory.Slot;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.INetHandler;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraftforge.fml.client.FMLClientHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\b&\u0018\u0000 \u000b2\u00020\u0001:\u0001\u000bB\u0005¢\u0006\u0002\u0010\u0002J\u0012\u0010\u0003\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0006H&J\u0012\u0010\u0007\u001a\u0004\u0018\u00010\u00042\u0006\u0010\b\u001a\u00020\tH&J\u0018\u0010\u0007\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u0005\u001a\u00020\u0006H&J \u0010\u0007\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u0006H&¨\u0006\f"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/Client;", "", "()V", "getKeyBindFromDescription", "Lcom/chattriggers/ctjs/minecraft/objects/keybind/KeyBind;", "description", "", "getKeyBindFromKey", "keyCode", "", "category", "Companion", "ctjs"}
)
public abstract class Client {
   @NotNull
   public static final Client.Companion Companion = new Client.Companion((DefaultConstructorMarker)null);
   @NotNull
   private static final Settings settings = new Settings();

   @Nullable
   public abstract KeyBind getKeyBindFromKey(int var1);

   @NotNull
   public abstract KeyBind getKeyBindFromKey(int var1, @NotNull String var2, @NotNull String var3);

   @NotNull
   public abstract KeyBind getKeyBindFromKey(int var1, @NotNull String var2);

   @Nullable
   public abstract KeyBind getKeyBindFromDescription(@NotNull String var1);

   @NotNull
   public static final Settings getSettings() {
      return Companion.getSettings();
   }

   @JvmStatic
   @NotNull
   public static final Minecraft getMinecraft() {
      return Companion.getMinecraft();
   }

   @JvmStatic
   @Nullable
   public static final NetHandlerPlayClient getConnection() {
      return Companion.getConnection();
   }

   @JvmStatic
   @JvmOverloads
   public static final void scheduleTask(int delay, @NotNull Function0<Unit> callback) {
      Companion.scheduleTask(delay, callback);
   }

   @JvmStatic
   public static final void disconnect() {
      Companion.disconnect();
   }

   @JvmStatic
   public static final void connect(@NotNull String ip) {
      Companion.connect(ip);
   }

   @JvmStatic
   @Nullable
   public static final GuiNewChat getChatGUI() {
      return Companion.getChatGUI();
   }

   @JvmStatic
   public static final boolean isInChat() {
      return Companion.isInChat();
   }

   @JvmStatic
   @Nullable
   public static final GuiPlayerTabOverlay getTabGui() {
      return Companion.getTabGui();
   }

   @JvmStatic
   public static final boolean isInTab() {
      return Companion.isInTab();
   }

   @JvmStatic
   public static final boolean isTabbedIn() {
      return Companion.isTabbedIn();
   }

   @JvmStatic
   public static final boolean isControlDown() {
      return Companion.isControlDown();
   }

   @JvmStatic
   public static final boolean isShiftDown() {
      return Companion.isShiftDown();
   }

   @JvmStatic
   public static final boolean isAltDown() {
      return Companion.isAltDown();
   }

   @JvmStatic
   public static final int getFPS() {
      return Companion.getFPS();
   }

   @JvmStatic
   @NotNull
   public static final String getVersion() {
      return Companion.getVersion();
   }

   @JvmStatic
   public static final long getMaxMemory() {
      return Companion.getMaxMemory();
   }

   @JvmStatic
   public static final long getTotalMemory() {
      return Companion.getTotalMemory();
   }

   @JvmStatic
   public static final long getFreeMemory() {
      return Companion.getFreeMemory();
   }

   @JvmStatic
   public static final int getMemoryUsage() {
      return Companion.getMemoryUsage();
   }

   @JvmStatic
   public static final long getSystemTime() {
      return Companion.getSystemTime();
   }

   @JvmStatic
   public static final float getMouseX() {
      return Companion.getMouseX();
   }

   @JvmStatic
   public static final float getMouseY() {
      return Companion.getMouseY();
   }

   @JvmStatic
   public static final boolean isInGui() {
      return Companion.isInGui();
   }

   @JvmStatic
   @NotNull
   public static final String getCurrentChatMessage() {
      return Companion.getCurrentChatMessage();
   }

   @JvmStatic
   public static final void setCurrentChatMessage(@NotNull String message) {
      Companion.setCurrentChatMessage(message);
   }

   @JvmStatic
   public static final <T extends INetHandler> void sendPacket(@NotNull Packet<T> packet) {
      Companion.sendPacket(packet);
   }

   @JvmStatic
   public static final void showTitle(@NotNull String title, @NotNull String subtitle, int fadeIn, int time, int fadeOut) {
      Companion.showTitle(title, subtitle, fadeIn, time, fadeOut);
   }

   @JvmStatic
   @JvmOverloads
   public static final void scheduleTask(@NotNull Function0<Unit> callback) {
      Companion.scheduleTask(callback);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000r\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000b\b\u0086\u0003\u0018\u00002\u00020\u0001:\u0002;<B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0007J\b\u0010\f\u001a\u00020\tH\u0007J\n\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0007J\n\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0007J\b\u0010\u0011\u001a\u00020\u000bH\u0007J\b\u0010\u0012\u001a\u00020\u0013H\u0007J\b\u0010\u0014\u001a\u00020\u0015H\u0007J\b\u0010\u0016\u001a\u00020\u0015H\u0007J\b\u0010\u0017\u001a\u00020\u0013H\u0007J\b\u0010\u0018\u001a\u00020\u0019H\u0007J\b\u0010\u001a\u001a\u00020\u001bH\u0007J\b\u0010\u001c\u001a\u00020\u001bH\u0007J\b\u0010\u001d\u001a\u00020\u0015H\u0007J\n\u0010\u001e\u001a\u0004\u0018\u00010\u001fH\u0007J\b\u0010 \u001a\u00020\u0015H\u0007J\b\u0010!\u001a\u00020\u000bH\u0007J\b\u0010\"\u001a\u00020#H\u0007J\b\u0010$\u001a\u00020#H\u0007J\b\u0010%\u001a\u00020#H\u0007J\b\u0010&\u001a\u00020#H\u0007J\b\u0010'\u001a\u00020#H\u0007J\b\u0010(\u001a\u00020#H\u0007J\b\u0010)\u001a\u00020#H\u0007J \u0010*\u001a\u00020\t2\b\b\u0002\u0010+\u001a\u00020\u00132\f\u0010,\u001a\b\u0012\u0004\u0012\u00020\t0-H\u0007J \u0010.\u001a\u00020\t\"\b\b\u0000\u0010/*\u0002002\f\u00101\u001a\b\u0012\u0004\u0012\u0002H/02H\u0007J\u0010\u00103\u001a\u00020\t2\u0006\u00104\u001a\u00020\u000bH\u0007J0\u00105\u001a\u00020\t2\u0006\u00106\u001a\u00020\u000b2\u0006\u00107\u001a\u00020\u000b2\u0006\u00108\u001a\u00020\u00132\u0006\u00109\u001a\u00020\u00132\u0006\u0010:\u001a\u00020\u0013H\u0007R\u001c\u0010\u0003\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u0005\u0010\u0002\u001a\u0004\b\u0006\u0010\u0007¨\u0006="},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/Client$Companion;", "", "()V", "settings", "Lcom/chattriggers/ctjs/minecraft/wrappers/Settings;", "getSettings$annotations", "getSettings", "()Lcom/chattriggers/ctjs/minecraft/wrappers/Settings;", "connect", "", "ip", "", "disconnect", "getChatGUI", "Lnet/minecraft/client/gui/GuiNewChat;", "getConnection", "Lnet/minecraft/client/network/NetHandlerPlayClient;", "getCurrentChatMessage", "getFPS", "", "getFreeMemory", "", "getMaxMemory", "getMemoryUsage", "getMinecraft", "Lnet/minecraft/client/Minecraft;", "getMouseX", "", "getMouseY", "getSystemTime", "getTabGui", "Lnet/minecraft/client/gui/GuiPlayerTabOverlay;", "getTotalMemory", "getVersion", "isAltDown", "", "isControlDown", "isInChat", "isInGui", "isInTab", "isShiftDown", "isTabbedIn", "scheduleTask", "delay", "callback", "Lkotlin/Function0;", "sendPacket", "T", "Lnet/minecraft/network/INetHandler;", "packet", "Lnet/minecraft/network/Packet;", "setCurrentChatMessage", "message", "showTitle", "title", "subtitle", "fadeIn", "time", "fadeOut", "camera", "currentGui", "ctjs"}
   )
   public static final class Companion {
      private Companion() {
      }

      @NotNull
      public final Settings getSettings() {
         return Client.settings;
      }

      /** @deprecated */
      // $FF: synthetic method
      @JvmStatic
      public static void getSettings$annotations() {
      }

      @JvmStatic
      @NotNull
      public final Minecraft getMinecraft() {
         Minecraft var1 = Minecraft.func_71410_x();
         Intrinsics.checkNotNullExpressionValue(var1, "getMinecraft()");
         return var1;
      }

      @JvmStatic
      @Nullable
      public final NetHandlerPlayClient getConnection() {
         return this.getMinecraft().func_147114_u();
      }

      @JvmStatic
      @JvmOverloads
      public final void scheduleTask(int delay, @NotNull Function0<Unit> callback) {
         Intrinsics.checkNotNullParameter(callback, "callback");
         ClientListener.INSTANCE.addTask(delay, callback);
      }

      // $FF: synthetic method
      public static void scheduleTask$default(Client.Companion var0, int var1, Function0 var2, int var3, Object var4) {
         if ((var3 & 1) != 0) {
            var1 = 0;
         }

         var0.scheduleTask(var1, var2);
      }

      @JvmStatic
      public final void disconnect() {
         scheduleTask$default(this, 0, (Function0)null.INSTANCE, 1, (Object)null);
      }

      @JvmStatic
      public final void connect(@NotNull final String ip) {
         Intrinsics.checkNotNullParameter(ip, "ip");
         scheduleTask$default(this, 0, (Function0)(new Function0<Unit>() {
            public final void invoke() {
               FMLClientHandler.instance().connectToServer((GuiScreen)(new GuiMultiplayer((GuiScreen)(new GuiMainMenu()))), new ServerData("Server", ip, false));
            }
         }), 1, (Object)null);
      }

      @JvmStatic
      @Nullable
      public final GuiNewChat getChatGUI() {
         GuiIngame var10000 = this.getMinecraft().field_71456_v;
         return var10000 == null ? null : var10000.func_146158_b();
      }

      @JvmStatic
      public final boolean isInChat() {
         return this.getMinecraft().field_71462_r instanceof GuiChat;
      }

      @JvmStatic
      @Nullable
      public final GuiPlayerTabOverlay getTabGui() {
         GuiIngame var10000 = this.getMinecraft().field_71456_v;
         return var10000 == null ? null : var10000.func_175181_h();
      }

      @JvmStatic
      public final boolean isInTab() {
         return this.getMinecraft().field_71474_y.field_74321_H.func_151470_d();
      }

      @JvmStatic
      public final boolean isTabbedIn() {
         return Display.isActive();
      }

      @JvmStatic
      public final boolean isControlDown() {
         return GuiScreen.func_146271_m();
      }

      @JvmStatic
      public final boolean isShiftDown() {
         return GuiScreen.func_146272_n();
      }

      @JvmStatic
      public final boolean isAltDown() {
         return GuiScreen.func_175283_s();
      }

      @JvmStatic
      public final int getFPS() {
         return Minecraft.func_175610_ah();
      }

      @JvmStatic
      @NotNull
      public final String getVersion() {
         String var1 = this.getMinecraft().func_175600_c();
         Intrinsics.checkNotNullExpressionValue(var1, "getMinecraft().version");
         return var1;
      }

      @JvmStatic
      public final long getMaxMemory() {
         return Runtime.getRuntime().maxMemory();
      }

      @JvmStatic
      public final long getTotalMemory() {
         return Runtime.getRuntime().totalMemory();
      }

      @JvmStatic
      public final long getFreeMemory() {
         return Runtime.getRuntime().freeMemory();
      }

      @JvmStatic
      public final int getMemoryUsage() {
         return MathKt.roundToInt((float)((this.getTotalMemory() - this.getFreeMemory()) * (long)100) / (float)this.getMaxMemory());
      }

      @JvmStatic
      public final long getSystemTime() {
         return Minecraft.func_71386_F();
      }

      @JvmStatic
      public final float getMouseX() {
         float mx = (float)Mouse.getX();
         float rw = (float)Renderer.screen.getWidth();
         float dw = (float)this.getMinecraft().field_71443_c;
         return mx * rw / dw;
      }

      @JvmStatic
      public final float getMouseY() {
         float my = (float)Mouse.getY();
         float rh = (float)Renderer.screen.getHeight();
         float dh = (float)this.getMinecraft().field_71440_d;
         return rh - my * rh / dh - 1.0F;
      }

      @JvmStatic
      public final boolean isInGui() {
         return Client.Companion.currentGui.get() != null;
      }

      @JvmStatic
      @NotNull
      public final String getCurrentChatMessage() {
         String var3;
         if (this.isInChat()) {
            GuiScreen var10000 = this.getMinecraft().field_71462_r;
            if (var10000 == null) {
               throw new NullPointerException("null cannot be cast to non-null type net.minecraft.client.gui.GuiChat");
            }

            GuiChat chatGui = (GuiChat)var10000;
            String var1 = chatGui.field_146415_a.func_146179_b();
            Intrinsics.checkNotNullExpressionValue(var1, "{\n                val ch…tField.text\n            }");
            var3 = var1;
         } else {
            var3 = "";
         }

         return var3;
      }

      @JvmStatic
      public final void setCurrentChatMessage(@NotNull String message) {
         Intrinsics.checkNotNullParameter(message, "message");
         if (this.isInChat()) {
            GuiScreen var10000 = this.getMinecraft().field_71462_r;
            if (var10000 == null) {
               throw new NullPointerException("null cannot be cast to non-null type net.minecraft.client.gui.GuiChat");
            }

            GuiChat chatGui = (GuiChat)var10000;
            chatGui.field_146415_a.func_146180_a(message);
         } else {
            this.getMinecraft().func_147108_a((GuiScreen)(new GuiChat(message)));
         }

      }

      @JvmStatic
      public final <T extends INetHandler> void sendPacket(@NotNull Packet<T> packet) {
         Intrinsics.checkNotNullParameter(packet, "packet");
         NetHandlerPlayClient var10000 = this.getConnection();
         if (var10000 != null) {
            NetworkManager var2 = var10000.func_147298_b();
            if (var2 != null) {
               var2.func_179290_a(packet);
            }
         }

      }

      @JvmStatic
      public final void showTitle(@NotNull String title, @NotNull String subtitle, int fadeIn, int time, int fadeOut) {
         Intrinsics.checkNotNullParameter(title, "title");
         Intrinsics.checkNotNullParameter(subtitle, "subtitle");
         GuiIngame gui = this.getMinecraft().field_71456_v;
         gui.func_175178_a(ChatLib.addColor(title), (String)null, fadeIn, time, fadeOut);
         gui.func_175178_a((String)null, ChatLib.addColor(subtitle), fadeIn, time, fadeOut);
         gui.func_175178_a((String)null, (String)null, fadeIn, time, fadeOut);
      }

      @JvmStatic
      @JvmOverloads
      public final void scheduleTask(@NotNull Function0<Unit> callback) {
         Intrinsics.checkNotNullParameter(callback, "callback");
         scheduleTask$default(this, 0, callback, 1, (Object)null);
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }

      @Metadata(
         mv = {1, 6, 0},
         k = 1,
         xi = 48,
         d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007J\n\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0007J\b\u0010\u0007\u001a\u00020\bH\u0007J\n\u0010\t\u001a\u0004\u0018\u00010\nH\u0007¨\u0006\u000b"},
         d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/Client$Companion$currentGui;", "", "()V", "close", "", "get", "Lnet/minecraft/client/gui/GuiScreen;", "getClassName", "", "getSlotUnderMouse", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Slot;", "ctjs"}
      )
      public static final class currentGui {
         @NotNull
         public static final Client.Companion.currentGui INSTANCE = new Client.Companion.currentGui();

         private currentGui() {
         }

         @JvmStatic
         @NotNull
         public static final String getClassName() {
            Client.Companion.currentGui var10000 = INSTANCE;
            GuiScreen var0 = get();
            String var1;
            if (var0 == null) {
               var1 = "null";
            } else {
               Class var2 = var0.getClass();
               if (var2 == null) {
                  var1 = "null";
               } else {
                  var1 = var2.getSimpleName();
                  if (var1 == null) {
                     var1 = "null";
                  }
               }
            }

            return var1;
         }

         @JvmStatic
         @Nullable
         public static final GuiScreen get() {
            return Client.Companion.getMinecraft().field_71462_r;
         }

         @JvmStatic
         @Nullable
         public static final Slot getSlotUnderMouse() {
            Client.Companion.currentGui var10000 = INSTANCE;
            GuiScreen screen = get();
            Slot var2;
            if (screen instanceof GuiContainer && ((GuiContainer)screen).getSlotUnderMouse() != null) {
               net.minecraft.inventory.Slot var1 = ((GuiContainer)screen).getSlotUnderMouse();
               Intrinsics.checkNotNullExpressionValue(var1, "screen.slotUnderMouse");
               var2 = new Slot(var1);
            } else {
               var2 = null;
            }

            return var2;
         }

         @JvmStatic
         public static final void close() {
            EntityPlayerSP var10000 = Player.getPlayer();
            if (var10000 != null) {
               var10000.func_71053_j();
            }

         }
      }

      @Metadata(
         mv = {1, 6, 0},
         k = 1,
         xi = 48,
         d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0006\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007J\b\u0010\u0005\u001a\u00020\u0004H\u0007J\b\u0010\u0006\u001a\u00020\u0004H\u0007¨\u0006\u0007"},
         d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/Client$Companion$camera;", "", "()V", "getX", "", "getY", "getZ", "ctjs"}
      )
      public static final class camera {
         @NotNull
         public static final Client.Companion.camera INSTANCE = new Client.Companion.camera();

         private camera() {
         }

         @JvmStatic
         public static final double getX() {
            return Client.Companion.getMinecraft().func_175598_ae().field_78730_l;
         }

         @JvmStatic
         public static final double getY() {
            return Client.Companion.getMinecraft().func_175598_ae().field_78731_m;
         }

         @JvmStatic
         public static final double getZ() {
            return Client.Companion.getMinecraft().func_175598_ae().field_78728_n;
         }
      }
   }
}
