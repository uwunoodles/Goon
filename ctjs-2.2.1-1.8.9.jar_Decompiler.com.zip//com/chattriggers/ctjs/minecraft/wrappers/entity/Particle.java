package com.chattriggers.ctjs.minecraft.wrappers.entity;

import java.awt.Color;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.particle.EntityFX;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\t\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0006\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0000\u0018\u00002\u00020\u0001B\u0011\u0012\n\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\u0002\u0010\u0005J\u0006\u0010\b\u001a\u00020\tJ\u000e\u0010\n\u001a\u00020\u00002\u0006\u0010\u000b\u001a\u00020\fJ\u0006\u0010\r\u001a\u00020\u0000J\u000e\u0010\u000e\u001a\u00020\u00002\u0006\u0010\u000e\u001a\u00020\fJ\u000e\u0010\u000f\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\fJ\u001e\u0010\u0011\u001a\u00020\u00002\u0006\u0010\u0012\u001a\u00020\f2\u0006\u0010\u0013\u001a\u00020\f2\u0006\u0010\u0014\u001a\u00020\fJ&\u0010\u0011\u001a\u00020\u00002\u0006\u0010\u0012\u001a\u00020\f2\u0006\u0010\u0013\u001a\u00020\f2\u0006\u0010\u0014\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\fJ\u000e\u0010\u0011\u001a\u00020\u00002\u0006\u0010\u0015\u001a\u00020\u0016J\u000e\u0010\u0017\u001a\u00020\u00002\u0006\u0010\u0018\u001a\u00020\u0019J\u000e\u0010\u001a\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\u001cJ\u000e\u0010\u001d\u001a\u00020\u00002\u0006\u0010\u001e\u001a\u00020\u001cJ\u000e\u0010\u001f\u001a\u00020\u00002\u0006\u0010 \u001a\u00020\u001cJ\b\u0010!\u001a\u00020\"H\u0016R\u0015\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006#"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/entity/Particle;", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/Entity;", "underlyingEntity", "Lnet/minecraft/client/particle/EntityFX;", "Lcom/chattriggers/ctjs/utils/kotlin/MCParticle;", "(Lnet/minecraft/client/particle/EntityFX;)V", "getUnderlyingEntity", "()Lnet/minecraft/client/particle/EntityFX;", "getColor", "Ljava/awt/Color;", "multiplyVelocity", "multiplier", "", "remove", "scale", "setAlpha", "alpha", "setColor", "red", "green", "blue", "color", "", "setMaxAge", "maxAge", "", "setX", "x", "", "setY", "y", "setZ", "z", "toString", "", "ctjs"}
)
public final class Particle extends Entity {
   @NotNull
   private final EntityFX underlyingEntity;

   public Particle(@NotNull EntityFX underlyingEntity) {
      Intrinsics.checkNotNullParameter(underlyingEntity, "underlyingEntity");
      super((net.minecraft.entity.Entity)underlyingEntity);
      this.underlyingEntity = underlyingEntity;
   }

   @NotNull
   public final EntityFX getUnderlyingEntity() {
      return this.underlyingEntity;
   }

   @NotNull
   public final Particle setX(double x) {
      Particle $this$setX_u24lambda_u2d0 = (Particle)this;
      int var5 = false;
      $this$setX_u24lambda_u2d0.getUnderlyingEntity().func_70107_b(x, $this$setX_u24lambda_u2d0.getY(), $this$setX_u24lambda_u2d0.getZ());
      return (Particle)this;
   }

   @NotNull
   public final Particle setY(double y) {
      Particle $this$setY_u24lambda_u2d1 = (Particle)this;
      int var5 = false;
      $this$setY_u24lambda_u2d1.getUnderlyingEntity().func_70107_b($this$setY_u24lambda_u2d1.getX(), y, $this$setY_u24lambda_u2d1.getZ());
      return (Particle)this;
   }

   @NotNull
   public final Particle setZ(double z) {
      Particle $this$setZ_u24lambda_u2d2 = (Particle)this;
      int var5 = false;
      $this$setZ_u24lambda_u2d2.getUnderlyingEntity().func_70107_b($this$setZ_u24lambda_u2d2.getX(), $this$setZ_u24lambda_u2d2.getY(), z);
      return (Particle)this;
   }

   @NotNull
   public final Particle scale(float scale) {
      Particle $this$scale_u24lambda_u2d3 = (Particle)this;
      int var4 = false;
      $this$scale_u24lambda_u2d3.getUnderlyingEntity().func_70541_f(scale);
      return (Particle)this;
   }

   @NotNull
   public final Particle multiplyVelocity(float multiplier) {
      Particle $this$multiplyVelocity_u24lambda_u2d4 = (Particle)this;
      int var4 = false;
      $this$multiplyVelocity_u24lambda_u2d4.getUnderlyingEntity().func_70543_e(multiplier);
      return (Particle)this;
   }

   @NotNull
   public final Particle setColor(float red, float green, float blue) {
      Particle $this$setColor_u24lambda_u2d5 = (Particle)this;
      int var6 = false;
      $this$setColor_u24lambda_u2d5.getUnderlyingEntity().func_70538_b(red, green, blue);
      return (Particle)this;
   }

   @NotNull
   public final Particle setColor(float red, float green, float blue, float alpha) {
      Particle $this$setColor_u24lambda_u2d6 = (Particle)this;
      int var7 = false;
      $this$setColor_u24lambda_u2d6.setColor(red, green, blue);
      $this$setColor_u24lambda_u2d6.setAlpha(alpha);
      return (Particle)this;
   }

   @NotNull
   public final Particle setColor(long color) {
      Particle $this$setColor_u24lambda_u2d7 = (Particle)this;
      int var5 = false;
      float red = (float)(color >> 16 & 255L) / 255.0F;
      float blue = (float)(color >> 8 & 255L) / 255.0F;
      float green = (float)(color & 255L) / 255.0F;
      float alpha = (float)(color >> 24 & 255L) / 255.0F;
      $this$setColor_u24lambda_u2d7.setColor(red, green, blue, alpha);
      return (Particle)this;
   }

   @NotNull
   public final Particle setAlpha(float alpha) {
      Particle $this$setAlpha_u24lambda_u2d8 = (Particle)this;
      int var4 = false;
      $this$setAlpha_u24lambda_u2d8.getUnderlyingEntity().func_82338_g(alpha);
      return (Particle)this;
   }

   @NotNull
   public final Color getColor() {
      return new Color(this.underlyingEntity.func_70534_d(), this.underlyingEntity.func_70542_f(), this.underlyingEntity.func_70535_g(), this.underlyingEntity.func_174838_j());
   }

   @NotNull
   public final Particle setMaxAge(int maxAge) {
      Particle $this$setMaxAge_u24lambda_u2d9 = (Particle)this;
      int var4 = false;
      $this$setMaxAge_u24lambda_u2d9.getUnderlyingEntity().field_70547_e = maxAge;
      return (Particle)this;
   }

   @NotNull
   public final Particle remove() {
      Particle $this$remove_u24lambda_u2d10 = (Particle)this;
      int var3 = false;
      $this$remove_u24lambda_u2d10.getUnderlyingEntity().func_70106_y();
      return (Particle)this;
   }

   @NotNull
   public String toString() {
      String var1 = this.underlyingEntity.toString();
      Intrinsics.checkNotNullExpressionValue(var1, "underlyingEntity.toString()");
      return var1;
   }
}
