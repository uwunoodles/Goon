package com.chattriggers.ctjs.minecraft.wrappers.entity;

import com.chattriggers.ctjs.minecraft.wrappers.world.block.Block;
import com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockFace;
import com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockPos;
import com.chattriggers.ctjs.minecraft.wrappers.world.block.BlockType;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\u0018\u00002\u00020\u0001B\u0011\u0012\n\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\u0002\u0010\u0005J\u0006\u0010\b\u001a\u00020\tJ\u0006\u0010\n\u001a\u00020\u000bJ\u0006\u0010\f\u001a\u00020\rJ\u0006\u0010\u000e\u001a\u00020\u000fJ\u0006\u0010\u0010\u001a\u00020\u000fJ\u0006\u0010\u0011\u001a\u00020\u000fJ\u0006\u0010\u0012\u001a\u00020\u000fJ\b\u0010\u0013\u001a\u00020\u0014H\u0016R\u0015\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0015"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/entity/TileEntity;", "", "tileEntity", "Lnet/minecraft/tileentity/TileEntity;", "Lcom/chattriggers/ctjs/utils/kotlin/MCTileEntity;", "(Lnet/minecraft/tileentity/TileEntity;)V", "getTileEntity", "()Lnet/minecraft/tileentity/TileEntity;", "getBlock", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/Block;", "getBlockPos", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockPos;", "getBlockType", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/block/BlockType;", "getMetadata", "", "getX", "getY", "getZ", "toString", "", "ctjs"}
)
public final class TileEntity {
   @NotNull
   private final net.minecraft.tileentity.TileEntity tileEntity;

   public TileEntity(@NotNull net.minecraft.tileentity.TileEntity tileEntity) {
      Intrinsics.checkNotNullParameter(tileEntity, "tileEntity");
      super();
      this.tileEntity = tileEntity;
   }

   @NotNull
   public final net.minecraft.tileentity.TileEntity getTileEntity() {
      return this.tileEntity;
   }

   public final int getX() {
      return this.getBlock().getX();
   }

   public final int getY() {
      return this.getBlock().getY();
   }

   public final int getZ() {
      return this.getBlock().getZ();
   }

   @NotNull
   public final Block getBlock() {
      return new Block(this.getBlockType(), this.getBlockPos(), (BlockFace)null, 4, (DefaultConstructorMarker)null);
   }

   @NotNull
   public final BlockType getBlockType() {
      net.minecraft.block.Block var1 = this.tileEntity.func_145838_q();
      Intrinsics.checkNotNullExpressionValue(var1, "tileEntity.blockType");
      return new BlockType(var1);
   }

   @NotNull
   public final BlockPos getBlockPos() {
      net.minecraft.util.BlockPos var1 = this.tileEntity.func_174877_v();
      Intrinsics.checkNotNullExpressionValue(var1, "tileEntity.pos");
      return new BlockPos(var1);
   }

   public final int getMetadata() {
      return this.tileEntity.func_145832_p();
   }

   @NotNull
   public String toString() {
      return "TileEntity{x=" + this.getX() + ", y=" + this.getY() + ", z=" + this.getZ() + ", blockType=" + this.getBlockType() + '}';
   }
}
