package com.chattriggers.ctjs.minecraft.wrappers.entity;

import com.chattriggers.ctjs.minecraft.libs.renderer.Renderer;
import com.chattriggers.ctjs.minecraft.objects.message.TextComponent;
import com.chattriggers.ctjs.minecraft.wrappers.Client;
import com.mojang.authlib.GameProfile;
import java.lang.reflect.Field;
import kotlin.Metadata;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.util.IChatComponent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\u0018\u0000 $2\u00020\u0001:\u0001$B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\\\u0010\u0007\u001a\u00020\u00002\u0006\u0010\u0002\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\f\u001a\u00020\r2\b\b\u0002\u0010\u000e\u001a\u00020\r2\b\b\u0002\u0010\u000f\u001a\u00020\r2\b\b\u0002\u0010\u0010\u001a\u00020\r2\b\b\u0002\u0010\u0011\u001a\u00020\r2\b\b\u0002\u0010\u0012\u001a\u00020\rH\u0007J\u0006\u0010\u0013\u001a\u00020\u0014J\b\u0010\u0015\u001a\u00020\u0016H\u0016J\u0006\u0010\u0017\u001a\u00020\nJ\n\u0010\u0018\u001a\u0004\u0018\u00010\u0019H\u0002J\u0012\u0010\u001a\u001a\u00020\u00162\b\u0010\u001b\u001a\u0004\u0018\u00010\u0019H\u0002J\b\u0010\u001c\u001a\u0004\u0018\u00010\u001dJ\u0006\u0010\u001e\u001a\u00020\rJ\u000e\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\u0014J\u000e\u0010\"\u001a\u00020 2\u0006\u0010!\u001a\u00020\u0014J\b\u0010#\u001a\u00020\u0016H\u0016R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006%"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/entity/PlayerMP;", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/EntityLivingBase;", "player", "Lnet/minecraft/entity/player/EntityPlayer;", "(Lnet/minecraft/entity/player/EntityPlayer;)V", "getPlayer", "()Lnet/minecraft/entity/player/EntityPlayer;", "draw", "", "x", "", "y", "rotate", "", "showNametag", "showArmor", "showCape", "showHeldItem", "showArrows", "getDisplayName", "Lcom/chattriggers/ctjs/minecraft/objects/message/TextComponent;", "getName", "", "getPing", "getPlayerInfo", "Lnet/minecraft/client/network/NetworkPlayerInfo;", "getPlayerName", "networkPlayerInfoIn", "getTeam", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/Team;", "isSpectator", "setNametagName", "", "textComponent", "setTabDisplayName", "toString", "Companion", "ctjs"}
)
public final class PlayerMP extends EntityLivingBase {
   @NotNull
   public static final PlayerMP.Companion Companion = new PlayerMP.Companion((DefaultConstructorMarker)null);
   @NotNull
   private final EntityPlayer player;
   private static final Field displayNameField;

   public PlayerMP(@NotNull EntityPlayer player) {
      Intrinsics.checkNotNullParameter(player, "player");
      super((net.minecraft.entity.EntityLivingBase)player);
      this.player = player;
   }

   @NotNull
   public final EntityPlayer getPlayer() {
      return this.player;
   }

   public final boolean isSpectator() {
      return this.player.func_175149_v();
   }

   public final int getPing() {
      NetworkPlayerInfo var10000 = this.getPlayerInfo();
      int var2;
      if (var10000 == null) {
         var2 = -1;
      } else {
         int var1 = var10000.func_178853_c();
         var2 = var1;
      }

      return var2;
   }

   @Nullable
   public final Team getTeam() {
      NetworkPlayerInfo var10000 = this.getPlayerInfo();
      Team var3;
      if (var10000 == null) {
         var3 = null;
      } else {
         ScorePlayerTeam var4 = var10000.func_178850_i();
         if (var4 == null) {
            var3 = null;
         } else {
            ScorePlayerTeam p0 = var4;
            int var2 = false;
            var3 = new Team(p0);
         }
      }

      return var3;
   }

   @NotNull
   public final TextComponent getDisplayName() {
      return new TextComponent(this.getPlayerName(this.getPlayerInfo()));
   }

   public final void setTabDisplayName(@NotNull TextComponent textComponent) {
      Intrinsics.checkNotNullParameter(textComponent, "textComponent");
      NetworkPlayerInfo var10000 = this.getPlayerInfo();
      if (var10000 != null) {
         var10000.func_178859_a(textComponent.getChatComponentText());
      }

   }

   public final void setNametagName(@NotNull TextComponent textComponent) {
      Intrinsics.checkNotNullParameter(textComponent, "textComponent");
      displayNameField.set(this.player, textComponent.getChatComponentText().func_150254_d());
   }

   @JvmOverloads
   @NotNull
   public final PlayerMP draw(@NotNull Object player, int x, int y, boolean rotate, boolean showNametag, boolean showArmor, boolean showCape, boolean showHeldItem, boolean showArrows) {
      Intrinsics.checkNotNullParameter(player, "player");
      PlayerMP $this$draw_u24lambda_u2d0 = (PlayerMP)this;
      int var12 = false;
      Renderer.drawPlayer(player, x, y, rotate, showNametag, showArmor, showCape, showHeldItem, showArrows);
      return (PlayerMP)this;
   }

   // $FF: synthetic method
   public static PlayerMP draw$default(PlayerMP var0, Object var1, int var2, int var3, boolean var4, boolean var5, boolean var6, boolean var7, boolean var8, boolean var9, int var10, Object var11) {
      if ((var10 & 8) != 0) {
         var4 = false;
      }

      if ((var10 & 16) != 0) {
         var5 = false;
      }

      if ((var10 & 32) != 0) {
         var6 = true;
      }

      if ((var10 & 64) != 0) {
         var7 = true;
      }

      if ((var10 & 128) != 0) {
         var8 = true;
      }

      if ((var10 & 256) != 0) {
         var9 = true;
      }

      return var0.draw(var1, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   private final String getPlayerName(NetworkPlayerInfo networkPlayerInfoIn) {
      String var10000;
      if (networkPlayerInfoIn == null) {
         var10000 = null;
      } else {
         IChatComponent var4 = networkPlayerInfoIn.func_178854_k();
         var10000 = var4 == null ? null : var4.func_150254_d();
      }

      String var3 = var10000;
      if (var3 == null) {
         net.minecraft.scoreboard.Team var5 = (net.minecraft.scoreboard.Team)(networkPlayerInfoIn == null ? null : networkPlayerInfoIn.func_178850_i());
         String var10001;
         if (networkPlayerInfoIn == null) {
            var10001 = null;
         } else {
            GameProfile var6 = networkPlayerInfoIn.func_178845_a();
            var10001 = var6 == null ? null : var6.getName();
         }

         var10000 = ScorePlayerTeam.func_96667_a(var5, var10001);
      } else {
         var10000 = var3;
      }

      String var2 = var10000;
      return var2 == null ? "" : var2;
   }

   private final NetworkPlayerInfo getPlayerInfo() {
      NetHandlerPlayClient var10000 = Client.Companion.getConnection();
      return var10000 == null ? null : var10000.func_175102_a(this.player.func_110124_au());
   }

   @NotNull
   public String toString() {
      return "PlayerMP{name=" + this.getName() + ", ping=" + this.getPing() + ", entityLivingBase=" + super.toString() + '}';
   }

   @NotNull
   public String getName() {
      String var1 = this.player.func_70005_c_();
      Intrinsics.checkNotNullExpressionValue(var1, "player.name");
      return var1;
   }

   @JvmOverloads
   @NotNull
   public final PlayerMP draw(@NotNull Object player, int x, int y, boolean rotate, boolean showNametag, boolean showArmor, boolean showCape, boolean showHeldItem) {
      Intrinsics.checkNotNullParameter(player, "player");
      return draw$default(this, player, x, y, rotate, showNametag, showArmor, showCape, showHeldItem, false, 256, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final PlayerMP draw(@NotNull Object player, int x, int y, boolean rotate, boolean showNametag, boolean showArmor, boolean showCape) {
      Intrinsics.checkNotNullParameter(player, "player");
      return draw$default(this, player, x, y, rotate, showNametag, showArmor, showCape, false, false, 384, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final PlayerMP draw(@NotNull Object player, int x, int y, boolean rotate, boolean showNametag, boolean showArmor) {
      Intrinsics.checkNotNullParameter(player, "player");
      return draw$default(this, player, x, y, rotate, showNametag, showArmor, false, false, false, 448, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final PlayerMP draw(@NotNull Object player, int x, int y, boolean rotate, boolean showNametag) {
      Intrinsics.checkNotNullParameter(player, "player");
      return draw$default(this, player, x, y, rotate, showNametag, false, false, false, false, 480, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final PlayerMP draw(@NotNull Object player, int x, int y, boolean rotate) {
      Intrinsics.checkNotNullParameter(player, "player");
      return draw$default(this, player, x, y, rotate, false, false, false, false, false, 496, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final PlayerMP draw(@NotNull Object player, int x, int y) {
      Intrinsics.checkNotNullParameter(player, "player");
      return draw$default(this, player, x, y, false, false, false, false, false, false, 504, (Object)null);
   }

   static {
      String[] var0 = new String[]{"displayname"};
      displayNameField = ReflectionHelper.findField(EntityPlayer.class, var0);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0016\u0010\u0003\u001a\n \u0005*\u0004\u0018\u00010\u00040\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0006"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/entity/PlayerMP$Companion;", "", "()V", "displayNameField", "Ljava/lang/reflect/Field;", "kotlin.jvm.PlatformType", "ctjs"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
