package com.chattriggers.ctjs.minecraft.wrappers.entity;

import com.chattriggers.ctjs.minecraft.wrappers.inventory.Item;
import com.chattriggers.ctjs.minecraft.wrappers.world.PotionEffect;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0000\b\u0016\u0018\u00002\u00020\u0001B\u0011\u0012\n\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\u0002\u0010\u0005J\u000e\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bJ\u000e\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u0001J\u0012\u0010\f\u001a\u00020\r2\n\u0010\u000e\u001a\u00060\u000fj\u0002`\u0010J\u0006\u0010\u0011\u001a\u00020\tJ\u0006\u0010\u0012\u001a\u00020\u0013J\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u000b0\u0015J\u0006\u0010\u0016\u001a\u00020\u0017J\u0006\u0010\u0018\u001a\u00020\u0017J\u0006\u0010\u0019\u001a\u00020\u0013J\u0010\u0010\u001a\u001a\u0004\u0018\u00010\u001b2\u0006\u0010\u001c\u001a\u00020\u0017J\u0006\u0010\u001d\u001a\u00020\u0013J\u000e\u0010\u001e\u001a\u00020\r2\u0006\u0010\u001f\u001a\u00020\u000bJ\u000e\u0010\u001e\u001a\u00020\r2\u0006\u0010 \u001a\u00020\u0017J\u000e\u0010\u001e\u001a\u00020\r2\u0006\u0010!\u001a\u00020\"J\u000e\u0010#\u001a\u00020\u00002\u0006\u0010$\u001a\u00020\u0013J\u000e\u0010%\u001a\u00020\u00002\u0006\u0010&\u001a\u00020\u0013J\b\u0010'\u001a\u00020(H\u0016R\u0015\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006)"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/entity/EntityLivingBase;", "Lcom/chattriggers/ctjs/minecraft/wrappers/entity/Entity;", "entityLivingBase", "Lnet/minecraft/entity/EntityLivingBase;", "Lcom/chattriggers/ctjs/utils/kotlin/MCEntityLivingBase;", "(Lnet/minecraft/entity/EntityLivingBase;)V", "getEntityLivingBase", "()Lnet/minecraft/entity/EntityLivingBase;", "addPotionEffect", "", "effect", "Lcom/chattriggers/ctjs/minecraft/wrappers/world/PotionEffect;", "canSeeEntity", "", "other", "Lnet/minecraft/entity/Entity;", "Lcom/chattriggers/ctjs/utils/kotlin/MCEntity;", "clearPotionEffects", "getAbsorption", "", "getActivePotionEffects", "", "getAge", "", "getArmorValue", "getHP", "getItemInSlot", "Lcom/chattriggers/ctjs/minecraft/wrappers/inventory/Item;", "slot", "getMaxHP", "isPotionActive", "potionEffect", "id", "potion", "Lnet/minecraft/potion/Potion;", "setAbsorption", "absorption", "setHP", "health", "toString", "", "ctjs"}
)
public class EntityLivingBase extends Entity {
   @NotNull
   private final net.minecraft.entity.EntityLivingBase entityLivingBase;

   public EntityLivingBase(@NotNull net.minecraft.entity.EntityLivingBase entityLivingBase) {
      Intrinsics.checkNotNullParameter(entityLivingBase, "entityLivingBase");
      super((net.minecraft.entity.Entity)entityLivingBase);
      this.entityLivingBase = entityLivingBase;
   }

   @NotNull
   public final net.minecraft.entity.EntityLivingBase getEntityLivingBase() {
      return this.entityLivingBase;
   }

   public final void addPotionEffect(@NotNull PotionEffect effect) {
      Intrinsics.checkNotNullParameter(effect, "effect");
      this.entityLivingBase.func_70690_d(effect.getEffect());
   }

   public final void clearPotionEffects() {
      this.entityLivingBase.func_70674_bp();
   }

   @NotNull
   public final List<PotionEffect> getActivePotionEffects() {
      Collection var1 = this.entityLivingBase.func_70651_bq();
      Intrinsics.checkNotNullExpressionValue(var1, "entityLivingBase.activePotionEffects");
      Iterable $this$map$iv = (Iterable)var1;
      int $i$f$map = false;
      Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
      int $i$f$mapTo = false;
      Iterator var6 = $this$map$iv.iterator();

      while(var6.hasNext()) {
         Object item$iv$iv = var6.next();
         net.minecraft.potion.PotionEffect p0 = (net.minecraft.potion.PotionEffect)item$iv$iv;
         int var9 = false;
         destination$iv$iv.add(new PotionEffect(p0));
      }

      return (List)destination$iv$iv;
   }

   public final boolean canSeeEntity(@NotNull net.minecraft.entity.Entity other) {
      Intrinsics.checkNotNullParameter(other, "other");
      return this.entityLivingBase.func_70685_l(other);
   }

   public final boolean canSeeEntity(@NotNull Entity other) {
      Intrinsics.checkNotNullParameter(other, "other");
      return this.canSeeEntity(other.getEntity());
   }

   @Nullable
   public final Item getItemInSlot(int slot) {
      ItemStack var10000 = this.entityLivingBase.func_71124_b(slot);
      Item var4;
      if (var10000 == null) {
         var4 = null;
      } else {
         ItemStack p0 = var10000;
         int var3 = false;
         var4 = new Item(p0);
      }

      return var4;
   }

   public final float getHP() {
      return this.entityLivingBase.func_110143_aJ();
   }

   @NotNull
   public final EntityLivingBase setHP(float health) {
      EntityLivingBase $this$setHP_u24lambda_u2d1 = (EntityLivingBase)this;
      int var4 = false;
      $this$setHP_u24lambda_u2d1.getEntityLivingBase().func_70606_j(health);
      return (EntityLivingBase)this;
   }

   public final float getMaxHP() {
      return this.entityLivingBase.func_110138_aP();
   }

   public final float getAbsorption() {
      return this.entityLivingBase.func_110139_bj();
   }

   @NotNull
   public final EntityLivingBase setAbsorption(float absorption) {
      EntityLivingBase $this$setAbsorption_u24lambda_u2d2 = (EntityLivingBase)this;
      int var4 = false;
      $this$setAbsorption_u24lambda_u2d2.getEntityLivingBase().func_110149_m(absorption);
      return (EntityLivingBase)this;
   }

   public final int getAge() {
      return this.entityLivingBase.func_70654_ax();
   }

   public final int getArmorValue() {
      return this.entityLivingBase.func_70658_aO();
   }

   public final boolean isPotionActive(int id) {
      return this.entityLivingBase.func_82165_m(id);
   }

   public final boolean isPotionActive(@NotNull Potion potion) {
      Intrinsics.checkNotNullParameter(potion, "potion");
      return this.isPotionActive(potion.field_76415_H);
   }

   public final boolean isPotionActive(@NotNull PotionEffect potionEffect) {
      Intrinsics.checkNotNullParameter(potionEffect, "potionEffect");
      return this.isPotionActive(potionEffect.getEffect().func_76456_a());
   }

   @NotNull
   public String toString() {
      return "EntityLivingBase{name=" + this.getName() + ", entity=" + super.toString() + '}';
   }
}
