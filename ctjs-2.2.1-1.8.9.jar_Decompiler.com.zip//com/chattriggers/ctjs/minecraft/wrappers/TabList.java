package com.chattriggers.ctjs.minecraft.wrappers;

import com.chattriggers.ctjs.minecraft.objects.message.Message;
import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Ordering;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.WorldSettings.GameType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\b\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\u0018B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0007\u001a\u00020\bH\u0007J\b\u0010\t\u001a\u00020\bH\u0007J\n\u0010\n\u001a\u0004\u0018\u00010\u000bH\u0007J\n\u0010\f\u001a\u0004\u0018\u00010\rH\u0007J\n\u0010\u000e\u001a\u0004\u0018\u00010\u000bH\u0007J\n\u0010\u000f\u001a\u0004\u0018\u00010\rH\u0007J\u000e\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u000b0\u0011H\u0007J\u000e\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u000b0\u0011H\u0007J\u000e\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u000b0\u0011H\u0007J\u0012\u0010\u0014\u001a\u00020\b2\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001H\u0007J\u0012\u0010\u0016\u001a\u00020\b2\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001H\u0007R2\u0010\u0003\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005\u0018\u00010\u00040\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0019"},
   d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/TabList;", "", "()V", "playerComparator", "Lcom/google/common/collect/Ordering;", "Lnet/minecraft/client/network/NetworkPlayerInfo;", "kotlin.jvm.PlatformType", "clearFooter", "", "clearHeader", "getFooter", "", "getFooterMessage", "Lcom/chattriggers/ctjs/minecraft/objects/message/Message;", "getHeader", "getHeaderMessage", "getNames", "", "getNamesByObjectives", "getUnformattedNames", "setFooter", "footer", "setHeader", "header", "PlayerComparator", "ctjs"}
)
public final class TabList {
   @NotNull
   public static final TabList INSTANCE = new TabList();
   private static final Ordering<NetworkPlayerInfo> playerComparator = Ordering.from((Comparator)(new TabList.PlayerComparator()));

   private TabList() {
   }

   @JvmStatic
   @NotNull
   public static final List<String> getNamesByObjectives() {
      net.minecraft.scoreboard.Scoreboard var10000 = Scoreboard.getScoreboard();
      if (var10000 == null) {
         return CollectionsKt.emptyList();
      } else {
         net.minecraft.scoreboard.Scoreboard scoreboard = var10000;
         ScoreObjective var15 = scoreboard.func_96539_a(0);
         if (var15 == null) {
            return CollectionsKt.emptyList();
         } else {
            ScoreObjective sidebarObjective = var15;
            Collection var3 = scoreboard.func_96534_i(sidebarObjective);
            Intrinsics.checkNotNullExpressionValue(var3, "scoreboard.getSortedScores(sidebarObjective)");
            Iterable $this$map$iv = (Iterable)var3;
            int $i$f$map = false;
            Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
            int $i$f$mapTo = false;
            Iterator var8 = $this$map$iv.iterator();

            while(var8.hasNext()) {
               Object item$iv$iv = var8.next();
               Score it = (Score)item$iv$iv;
               int var11 = false;
               ScorePlayerTeam team = scoreboard.func_96509_i(it.func_96653_e());
               destination$iv$iv.add(ScorePlayerTeam.func_96667_a((Team)team, it.func_96653_e()));
            }

            return (List)destination$iv$iv;
         }
      }
   }

   @JvmStatic
   @NotNull
   public static final List<String> getNames() {
      if (Client.Companion.getTabGui() == null) {
         return CollectionsKt.emptyList();
      } else {
         Ordering var10000 = playerComparator;
         EntityPlayerSP var10001 = Player.getPlayer();
         Intrinsics.checkNotNull(var10001);
         List playerList = var10000.sortedCopy((Iterable)var10001.field_71174_a.func_175106_d());
         Intrinsics.checkNotNullExpressionValue(playerList, "playerList");
         Iterable $this$map$iv = (Iterable)playerList;
         GuiPlayerTabOverlay var12 = Client.Companion.getTabGui();
         Intrinsics.checkNotNull(var12);
         GuiPlayerTabOverlay var2 = var12;
         int $i$f$map = false;
         Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
         int $i$f$mapTo = false;
         Iterator var7 = $this$map$iv.iterator();

         while(var7.hasNext()) {
            Object item$iv$iv = var7.next();
            NetworkPlayerInfo p0 = (NetworkPlayerInfo)item$iv$iv;
            int var10 = false;
            destination$iv$iv.add(var2.func_175243_a(p0));
         }

         return (List)destination$iv$iv;
      }
   }

   @JvmStatic
   @NotNull
   public static final List<String> getUnformattedNames() {
      if (Player.getPlayer() == null) {
         return CollectionsKt.emptyList();
      } else {
         NetHandlerPlayClient var1 = Client.Companion.getConnection();
         List var10000;
         if (var1 == null) {
            var10000 = null;
         } else {
            Collection var2 = var1.func_175106_d();
            if (var2 == null) {
               var10000 = null;
            } else {
               int var6 = false;
               List var3 = playerComparator.sortedCopy((Iterable)var2);
               if (var3 == null) {
                  var10000 = null;
               } else {
                  Iterable $this$map$iv = (Iterable)var3;
                  int $i$f$map = false;
                  Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
                  int $i$f$mapTo = false;
                  Iterator var9 = $this$map$iv.iterator();

                  while(var9.hasNext()) {
                     Object item$iv$iv = var9.next();
                     NetworkPlayerInfo it = (NetworkPlayerInfo)item$iv$iv;
                     int var12 = false;
                     destination$iv$iv.add(it.func_178845_a().getName());
                  }

                  var10000 = (List)destination$iv$iv;
               }
            }
         }

         List var0 = var10000;
         return var0 == null ? CollectionsKt.emptyList() : var0;
      }
   }

   @JvmStatic
   @Nullable
   public static final Message getHeaderMessage() {
      GuiPlayerTabOverlay var10000 = Client.Companion.getTabGui();
      Message var2;
      if (var10000 == null) {
         var2 = null;
      } else {
         IChatComponent var3 = var10000.field_175256_i;
         if (var3 == null) {
            var2 = null;
         } else {
            IChatComponent p0 = var3;
            int var1 = false;
            var2 = new Message(p0);
         }
      }

      return var2;
   }

   @JvmStatic
   @Nullable
   public static final String getHeader() {
      GuiPlayerTabOverlay var10000 = Client.Companion.getTabGui();
      String var0;
      if (var10000 == null) {
         var0 = null;
      } else {
         IChatComponent var1 = var10000.field_175256_i;
         var0 = var1 == null ? null : var1.func_150254_d();
      }

      return var0;
   }

   @JvmStatic
   public static final void setHeader(@Nullable Object header) {
      GuiPlayerTabOverlay var10000;
      if (header instanceof String) {
         var10000 = Client.Companion.getTabGui();
         if (var10000 != null) {
            Object[] var2 = new Object[]{header};
            var10000.field_175256_i = (new Message(var2)).getChatMessage();
         }
      } else if (header instanceof Message) {
         var10000 = Client.Companion.getTabGui();
         if (var10000 != null) {
            var10000.field_175256_i = ((Message)header).getChatMessage();
         }
      } else if (header instanceof IChatComponent) {
         var10000 = Client.Companion.getTabGui();
         if (var10000 != null) {
            var10000.field_175256_i = (IChatComponent)header;
         }
      } else if (header == null) {
         var10000 = Client.Companion.getTabGui();
         if (var10000 != null) {
            var10000.field_175256_i = (IChatComponent)header;
         }
      }

   }

   @JvmStatic
   public static final void clearHeader() {
      TabList var10000 = INSTANCE;
      setHeader((Object)null);
   }

   @JvmStatic
   @Nullable
   public static final Message getFooterMessage() {
      GuiPlayerTabOverlay var10000 = Client.Companion.getTabGui();
      Message var2;
      if (var10000 == null) {
         var2 = null;
      } else {
         IChatComponent var3 = var10000.field_175255_h;
         if (var3 == null) {
            var2 = null;
         } else {
            IChatComponent p0 = var3;
            int var1 = false;
            var2 = new Message(p0);
         }
      }

      return var2;
   }

   @JvmStatic
   @Nullable
   public static final String getFooter() {
      GuiPlayerTabOverlay var10000 = Client.Companion.getTabGui();
      String var0;
      if (var10000 == null) {
         var0 = null;
      } else {
         IChatComponent var1 = var10000.field_175255_h;
         var0 = var1 == null ? null : var1.func_150254_d();
      }

      return var0;
   }

   @JvmStatic
   public static final void setFooter(@Nullable Object footer) {
      GuiPlayerTabOverlay var10000;
      if (footer instanceof String) {
         var10000 = Client.Companion.getTabGui();
         if (var10000 != null) {
            Object[] var2 = new Object[]{footer};
            var10000.field_175255_h = (new Message(var2)).getChatMessage();
         }
      } else if (footer instanceof Message) {
         var10000 = Client.Companion.getTabGui();
         if (var10000 != null) {
            var10000.field_175255_h = ((Message)footer).getChatMessage();
         }
      } else if (footer instanceof IChatComponent) {
         var10000 = Client.Companion.getTabGui();
         if (var10000 != null) {
            var10000.field_175255_h = (IChatComponent)footer;
         }
      } else if (footer == null) {
         var10000 = Client.Companion.getTabGui();
         if (var10000 != null) {
            var10000.field_175255_h = (IChatComponent)footer;
         }
      }

   }

   @JvmStatic
   public static final void clearFooter() {
      TabList var10000 = INSTANCE;
      setFooter((Object)null);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\b\u0000\u0018\u00002\u0012\u0012\u0004\u0012\u00020\u00020\u0001j\b\u0012\u0004\u0012\u00020\u0002`\u0003B\u0007\b\u0000¢\u0006\u0002\u0010\u0004J\u0018\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00022\u0006\u0010\b\u001a\u00020\u0002H\u0016¨\u0006\t"},
      d2 = {"Lcom/chattriggers/ctjs/minecraft/wrappers/TabList$PlayerComparator;", "Ljava/util/Comparator;", "Lnet/minecraft/client/network/NetworkPlayerInfo;", "Lkotlin/Comparator;", "()V", "compare", "", "playerOne", "playerTwo", "ctjs"}
   )
   public static final class PlayerComparator implements Comparator<NetworkPlayerInfo> {
      public int compare(@NotNull NetworkPlayerInfo playerOne, @NotNull NetworkPlayerInfo playerTwo) {
         Intrinsics.checkNotNullParameter(playerOne, "playerOne");
         Intrinsics.checkNotNullParameter(playerTwo, "playerTwo");
         ScorePlayerTeam teamOne = playerOne.func_178850_i();
         ScorePlayerTeam teamTwo = playerTwo.func_178850_i();
         ComparisonChain var10000 = ComparisonChain.start().compareTrueFirst(playerOne.func_178848_b() != GameType.SPECTATOR, playerTwo.func_178848_b() != GameType.SPECTATOR);
         String var10001;
         if (teamOne == null) {
            var10001 = "";
         } else {
            var10001 = teamOne.func_96661_b();
            if (var10001 == null) {
               var10001 = "";
            }
         }

         Comparable var5 = (Comparable)var10001;
         String var10002;
         if (teamTwo == null) {
            var10002 = "";
         } else {
            var10002 = teamTwo.func_96661_b();
            if (var10002 == null) {
               var10002 = "";
            }
         }

         return var10000.compare(var5, (Comparable)var10002).compare((Comparable)playerOne.func_178845_a().getName(), (Comparable)playerTwo.func_178845_a().getName()).result();
      }
   }
}
