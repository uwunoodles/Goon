package com.chattriggers.ctjs;

import com.chattriggers.ctjs.engine.module.ModuleManager;
import com.chattriggers.ctjs.utils.console.Console;
import com.chattriggers.ctjs.utils.console.LogType;
import java.awt.Color;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0000\n\u0002\u0010\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0000\u001a\u001e\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u0005\u001a\u00020\u0006\u001a\u0014\u0010\u0007\u001a\u00020\u0001*\u00020\b2\b\b\u0002\u0010\u0003\u001a\u00020\u0004¨\u0006\t"},
   d2 = {"printToConsole", "", "", "console", "Lcom/chattriggers/ctjs/utils/console/Console;", "logType", "Lcom/chattriggers/ctjs/utils/console/LogType;", "printTraceToConsole", "", "ctjs"}
)
public final class ReferenceKt {
   public static final void printToConsole(@NotNull Object $this$printToConsole, @NotNull Console console, @NotNull LogType logType) {
      Intrinsics.checkNotNullParameter($this$printToConsole, "<this>");
      Intrinsics.checkNotNullParameter(console, "console");
      Intrinsics.checkNotNullParameter(logType, "logType");
      Console.println$default(console, $this$printToConsole, logType, (String)null, (Color)null, 12, (Object)null);
   }

   // $FF: synthetic method
   public static void printToConsole$default(Object var0, Console var1, LogType var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = ModuleManager.INSTANCE.getGeneralConsole();
      }

      if ((var3 & 2) != 0) {
         var2 = LogType.INFO;
      }

      printToConsole(var0, var1, var2);
   }

   public static final void printTraceToConsole(@NotNull Throwable $this$printTraceToConsole, @NotNull Console console) {
      Intrinsics.checkNotNullParameter($this$printTraceToConsole, "<this>");
      Intrinsics.checkNotNullParameter(console, "console");
      console.printStackTrace($this$printTraceToConsole);
   }

   // $FF: synthetic method
   public static void printTraceToConsole$default(Throwable var0, Console var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = ModuleManager.INSTANCE.getGeneralConsole();
      }

      printTraceToConsole(var0, var1);
   }
}
