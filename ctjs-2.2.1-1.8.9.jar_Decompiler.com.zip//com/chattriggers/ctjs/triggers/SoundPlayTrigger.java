package com.chattriggers.ctjs.triggers;

import com.chattriggers.ctjs.engine.ILoader;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u000e\u0010\t\u001a\u00020\u00002\u0006\u0010\u0007\u001a\u00020\bJ\u001f\u0010\n\u001a\u00020\u000b2\u0010\u0010\f\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u00030\rH\u0016¢\u0006\u0002\u0010\u000eR\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u000f"},
   d2 = {"Lcom/chattriggers/ctjs/triggers/SoundPlayTrigger;", "Lcom/chattriggers/ctjs/triggers/Trigger;", "method", "", "loader", "Lcom/chattriggers/ctjs/engine/ILoader;", "(Ljava/lang/Object;Lcom/chattriggers/ctjs/engine/ILoader;)V", "soundNameCriteria", "", "setCriteria", "trigger", "", "args", "", "([Ljava/lang/Object;)V", "ctjs"}
)
public final class SoundPlayTrigger extends Trigger {
   @NotNull
   private String soundNameCriteria;

   public SoundPlayTrigger(@NotNull Object method, @NotNull ILoader loader) {
      Intrinsics.checkNotNullParameter(method, "method");
      Intrinsics.checkNotNullParameter(loader, "loader");
      super(method, TriggerType.SoundPlay, loader);
      this.soundNameCriteria = "";
   }

   @NotNull
   public final SoundPlayTrigger setCriteria(@NotNull String soundNameCriteria) {
      Intrinsics.checkNotNullParameter(soundNameCriteria, "soundNameCriteria");
      SoundPlayTrigger $this$setCriteria_u24lambda_u2d0 = (SoundPlayTrigger)this;
      int var4 = false;
      $this$setCriteria_u24lambda_u2d0.soundNameCriteria = soundNameCriteria;
      return (SoundPlayTrigger)this;
   }

   public void trigger(@NotNull Object[] args) {
      Intrinsics.checkNotNullParameter(args, "args");
      if (args[1] instanceof String && !Intrinsics.areEqual(this.soundNameCriteria, "")) {
         Object var10000 = args[1];
         if (args[1] == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
         }

         if (!StringsKt.equals((String)var10000, this.soundNameCriteria, true)) {
            return;
         }
      }

      this.callMethod(args);
   }
}
