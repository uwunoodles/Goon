package com.chattriggers.ctjs.triggers;

import com.chattriggers.ctjs.engine.ILoader;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.SortedSet;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0004\u0018\u0000 \u00102\u00020\u0001:\u0001\u0010B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\u0010\u0004\u001a\u0006\u0012\u0002\b\u00030\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\b\u0010\t\u001a\u00020\u0001H\u0016J\u001f\u0010\n\u001a\u00020\u000b2\u0010\u0010\f\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u00030\rH\u0016¢\u0006\u0002\u0010\u000eJ\b\u0010\u000f\u001a\u00020\u0001H\u0016R\u0012\u0010\u0004\u001a\u0006\u0012\u0002\b\u00030\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0011"},
   d2 = {"Lcom/chattriggers/ctjs/triggers/ForgeTrigger;", "Lcom/chattriggers/ctjs/triggers/Trigger;", "method", "", "eventClass", "Ljava/lang/Class;", "loader", "Lcom/chattriggers/ctjs/engine/ILoader;", "(Ljava/lang/Object;Ljava/lang/Class;Lcom/chattriggers/ctjs/engine/ILoader;)V", "register", "trigger", "", "args", "", "([Ljava/lang/Object;)V", "unregister", "Companion", "ctjs"}
)
public final class ForgeTrigger extends Trigger {
   @NotNull
   public static final ForgeTrigger.Companion Companion = new ForgeTrigger.Companion((DefaultConstructorMarker)null);
   @NotNull
   private final Class<?> eventClass;
   @NotNull
   private static final Map<Class<?>, SortedSet<ForgeTrigger>> forgeTriggers = (Map)(new LinkedHashMap());

   public ForgeTrigger(@NotNull Object method, @NotNull Class<?> eventClass, @NotNull ILoader loader) {
      Intrinsics.checkNotNullParameter(method, "method");
      Intrinsics.checkNotNullParameter(eventClass, "eventClass");
      Intrinsics.checkNotNullParameter(loader, "loader");
      super(method, TriggerType.Forge, loader);
      this.eventClass = eventClass;
      if (!Event.class.isAssignableFrom(this.eventClass)) {
         int var9 = false;
         String var10 = Intrinsics.stringPlus("ForgeTrigger expects an Event class, but found ", this.eventClass.getSimpleName());
         throw new IllegalArgumentException(var10.toString());
      } else {
         Map $this$getOrPut$iv = forgeTriggers;
         Object key$iv = this.eventClass;
         int $i$f$getOrPut = false;
         Object value$iv = $this$getOrPut$iv.get(key$iv);
         Object var10000;
         if (value$iv == null) {
            int var8 = false;
            Object answer$iv = (SortedSet)SetsKt.sortedSetOf(new ForgeTrigger[0]);
            $this$getOrPut$iv.put(key$iv, answer$iv);
            var10000 = answer$iv;
         } else {
            var10000 = value$iv;
         }

         ((SortedSet)var10000).add(this);
      }
   }

   @NotNull
   public Trigger register() {
      Map $this$getOrPut$iv = forgeTriggers;
      Object key$iv = this.eventClass;
      int $i$f$getOrPut = false;
      Object value$iv = $this$getOrPut$iv.get(key$iv);
      Object var10000;
      if (value$iv == null) {
         int var5 = false;
         Object answer$iv = (SortedSet)SetsKt.sortedSetOf(new ForgeTrigger[0]);
         $this$getOrPut$iv.put(key$iv, answer$iv);
         var10000 = answer$iv;
      } else {
         var10000 = value$iv;
      }

      ((SortedSet)var10000).add(this);
      return super.register();
   }

   @NotNull
   public Trigger unregister() {
      SortedSet var10000 = (SortedSet)forgeTriggers.get(this.eventClass);
      if (var10000 != null) {
         var10000.remove(this);
      }

      return super.unregister();
   }

   public void trigger(@NotNull Object[] args) {
      Intrinsics.checkNotNullParameter(args, "args");
      this.callMethod(args);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0007J\u0006\u0010\f\u001a\u00020\tR$\u0010\u0003\u001a\u0018\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070\u00060\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\r"},
      d2 = {"Lcom/chattriggers/ctjs/triggers/ForgeTrigger$Companion;", "", "()V", "forgeTriggers", "", "Ljava/lang/Class;", "Ljava/util/SortedSet;", "Lcom/chattriggers/ctjs/triggers/ForgeTrigger;", "onEvent", "", "event", "Lnet/minecraftforge/fml/common/eventhandler/Event;", "unregisterTriggers", "ctjs"}
   )
   public static final class Companion {
      private Companion() {
      }

      public final void unregisterTriggers() {
         Iterable $this$forEach$iv = (Iterable)CollectionsKt.flatten((Iterable)ForgeTrigger.forgeTriggers.values());
         int $i$f$forEach = false;
         Iterator var3 = $this$forEach$iv.iterator();

         while(var3.hasNext()) {
            Object element$iv = var3.next();
            ForgeTrigger it = (ForgeTrigger)element$iv;
            int var6 = false;
            it.unregister();
         }

         ForgeTrigger.forgeTriggers.clear();
      }

      @SubscribeEvent
      public final void onEvent(@NotNull Event event) {
         Intrinsics.checkNotNullParameter(event, "event");
         if (!Intrinsics.areEqual(Thread.currentThread().getName(), "Server thread")) {
            SortedSet var10000 = (SortedSet)ForgeTrigger.forgeTriggers.get(event.getClass());
            if (var10000 != null) {
               Iterable $this$forEach$iv = (Iterable)var10000;
               int $i$f$forEach = false;
               Iterator var4 = $this$forEach$iv.iterator();

               while(var4.hasNext()) {
                  Object element$iv = var4.next();
                  ForgeTrigger it = (ForgeTrigger)element$iv;
                  int var7 = false;
                  Event[] var8 = new Event[]{event};
                  it.trigger(var8);
               }
            }

         }
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
