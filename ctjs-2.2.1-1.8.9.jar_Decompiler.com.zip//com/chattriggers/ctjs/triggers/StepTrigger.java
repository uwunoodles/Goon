package com.chattriggers.ctjs.triggers;

import com.chattriggers.ctjs.engine.ILoader;
import com.chattriggers.ctjs.minecraft.wrappers.Client;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\b\u0010\f\u001a\u00020\u0001H\u0016J\u000e\u0010\r\u001a\u00020\u00002\u0006\u0010\u0007\u001a\u00020\bJ\u000e\u0010\u000e\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\bJ\u001f\u0010\u000f\u001a\u00020\u00102\u0010\u0010\u0011\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u00030\u0012H\u0016¢\u0006\u0002\u0010\u0013R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0014"},
   d2 = {"Lcom/chattriggers/ctjs/triggers/StepTrigger;", "Lcom/chattriggers/ctjs/triggers/Trigger;", "method", "", "loader", "Lcom/chattriggers/ctjs/engine/ILoader;", "(Ljava/lang/Object;Lcom/chattriggers/ctjs/engine/ILoader;)V", "delay", "", "elapsed", "fps", "systemTime", "register", "setDelay", "setFps", "trigger", "", "args", "", "([Ljava/lang/Object;)V", "ctjs"}
)
public final class StepTrigger extends Trigger {
   private long fps;
   private long delay;
   private long systemTime;
   private long elapsed;

   public StepTrigger(@NotNull Object method, @NotNull ILoader loader) {
      Intrinsics.checkNotNullParameter(method, "method");
      Intrinsics.checkNotNullParameter(loader, "loader");
      super(method, TriggerType.Step, loader);
      this.fps = 60L;
      this.delay = -1L;
      this.systemTime = Client.Companion.getSystemTime();
   }

   @NotNull
   public final StepTrigger setFps(long fps) {
      StepTrigger $this$setFps_u24lambda_u2d0 = (StepTrigger)this;
      int var5 = false;
      $this$setFps_u24lambda_u2d0.fps = fps < 1L ? 1L : fps;
      $this$setFps_u24lambda_u2d0.systemTime = Client.Companion.getSystemTime() + (long)1000 / $this$setFps_u24lambda_u2d0.fps;
      return (StepTrigger)this;
   }

   @NotNull
   public final StepTrigger setDelay(long delay) {
      StepTrigger $this$setDelay_u24lambda_u2d1 = (StepTrigger)this;
      int var5 = false;
      $this$setDelay_u24lambda_u2d1.delay = delay < 1L ? 1L : delay;
      $this$setDelay_u24lambda_u2d1.systemTime = Client.Companion.getSystemTime() - $this$setDelay_u24lambda_u2d1.delay * (long)1000;
      return (StepTrigger)this;
   }

   @NotNull
   public Trigger register() {
      this.systemTime = Client.Companion.getSystemTime();
      return super.register();
   }

   public void trigger(@NotNull Object[] args) {
      Intrinsics.checkNotNullParameter(args, "args");
      Long[] var2;
      if (this.delay < 0L) {
         while(this.systemTime < Client.Companion.getSystemTime() + (long)1000 / this.fps) {
            var2 = new Long[1];
            ++this.elapsed;
            var2[0] = this.elapsed;
            this.callMethod(var2);
            this.systemTime += (long)1000 / this.fps;
         }
      } else {
         while(Client.Companion.getSystemTime() > this.systemTime + this.delay * (long)1000) {
            var2 = new Long[1];
            ++this.elapsed;
            var2[0] = this.elapsed;
            this.callMethod(var2);
            this.systemTime += this.delay * (long)1000;
         }
      }

   }
}
