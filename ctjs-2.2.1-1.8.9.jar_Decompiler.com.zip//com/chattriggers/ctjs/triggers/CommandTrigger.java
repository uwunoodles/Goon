package com.chattriggers.ctjs.triggers;

import com.chattriggers.ctjs.commands.Command;
import com.chattriggers.ctjs.engine.ILoader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\t\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\b\u0010\u0013\u001a\u00020\u0014H\u0002J\u001f\u0010\u0015\u001a\u00020\u00002\u0012\u0010\u0016\u001a\n\u0012\u0006\b\u0001\u0012\u00020\t0\f\"\u00020\t¢\u0006\u0002\u0010\u0017J\u001a\u0010\u0018\u001a\u00020\u00002\u0006\u0010\u000f\u001a\u00020\t2\b\b\u0002\u0010\u0010\u001a\u00020\u0011H\u0007J\u001a\u0010\u0019\u001a\u00020\u00002\u0006\u0010\u000f\u001a\u00020\t2\b\b\u0002\u0010\u0010\u001a\u00020\u0011H\u0007J(\u0010\u001a\u001a\u00020\u00002 \u0010\n\u001a\u001c\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\t0\f\u0012\n\u0012\b\u0012\u0004\u0012\u00020\t0\b0\u000bJ\u001f\u0010\u001a\u001a\u00020\u00002\u0012\u0010\u0016\u001a\n\u0012\u0006\b\u0001\u0012\u00020\t0\f\"\u00020\t¢\u0006\u0002\u0010\u0017J\u001f\u0010\u001b\u001a\u00020\u00142\u0010\u0010\u0016\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u00030\fH\u0016¢\u0006\u0002\u0010\u001cR\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010\n\u001a\u001e\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\t0\f\u0012\n\u0012\b\u0012\u0004\u0012\u00020\t0\b\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\tX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001d"},
   d2 = {"Lcom/chattriggers/ctjs/triggers/CommandTrigger;", "Lcom/chattriggers/ctjs/triggers/Trigger;", "method", "", "loader", "Lcom/chattriggers/ctjs/engine/ILoader;", "(Ljava/lang/Object;Lcom/chattriggers/ctjs/engine/ILoader;)V", "aliases", "", "", "callback", "Lkotlin/Function1;", "", "command", "Lcom/chattriggers/ctjs/commands/Command;", "commandName", "overrideExisting", "", "tabCompletions", "reInstance", "", "setAliases", "args", "([Ljava/lang/String;)Lcom/chattriggers/ctjs/triggers/CommandTrigger;", "setCommandName", "setName", "setTabCompletions", "trigger", "([Ljava/lang/Object;)V", "ctjs"}
)
public final class CommandTrigger extends Trigger {
   private String commandName;
   private boolean overrideExisting;
   @NotNull
   private final List<String> tabCompletions;
   @NotNull
   private final List<String> aliases;
   @Nullable
   private Command command;
   @Nullable
   private Function1<? super String[], ? extends List<String>> callback;

   public CommandTrigger(@NotNull Object method, @NotNull ILoader loader) {
      Intrinsics.checkNotNullParameter(method, "method");
      Intrinsics.checkNotNullParameter(loader, "loader");
      super(method, TriggerType.Command, loader);
      this.tabCompletions = (List)(new ArrayList());
      this.aliases = (List)(new ArrayList());
   }

   public void trigger(@NotNull Object[] args) {
      Intrinsics.checkNotNullParameter(args, "args");
      this.callMethod(args);
   }

   @NotNull
   public final CommandTrigger setTabCompletions(@NotNull String... args) {
      Intrinsics.checkNotNullParameter(args, "args");
      CommandTrigger $this$setTabCompletions_u24lambda_u2d0 = (CommandTrigger)this;
      int var4 = false;
      CollectionsKt.addAll((Collection)$this$setTabCompletions_u24lambda_u2d0.tabCompletions, args);
      return (CommandTrigger)this;
   }

   @NotNull
   public final CommandTrigger setTabCompletions(@NotNull Function1<? super String[], ? extends List<String>> callback) {
      Intrinsics.checkNotNullParameter(callback, "callback");
      CommandTrigger $this$setTabCompletions_u24lambda_u2d1 = (CommandTrigger)this;
      int var4 = false;
      $this$setTabCompletions_u24lambda_u2d1.callback = callback;
      return (CommandTrigger)this;
   }

   @NotNull
   public final CommandTrigger setAliases(@NotNull String... args) {
      Intrinsics.checkNotNullParameter(args, "args");
      CommandTrigger $this$setAliases_u24lambda_u2d3 = (CommandTrigger)this;
      int var4 = false;
      if ($this$setAliases_u24lambda_u2d3.commandName == null) {
         int var5 = false;
         String var6 = "Command name must be set before aliases!";
         throw new IllegalStateException(var6.toString());
      } else {
         CollectionsKt.addAll((Collection)$this$setAliases_u24lambda_u2d3.aliases, args);
         $this$setAliases_u24lambda_u2d3.reInstance();
         return (CommandTrigger)this;
      }
   }

   @JvmOverloads
   @NotNull
   public final CommandTrigger setCommandName(@NotNull String commandName, boolean overrideExisting) {
      Intrinsics.checkNotNullParameter(commandName, "commandName");
      CommandTrigger $this$setCommandName_u24lambda_u2d4 = (CommandTrigger)this;
      int var5 = false;
      $this$setCommandName_u24lambda_u2d4.commandName = commandName;
      $this$setCommandName_u24lambda_u2d4.overrideExisting = overrideExisting;
      $this$setCommandName_u24lambda_u2d4.reInstance();
      return (CommandTrigger)this;
   }

   // $FF: synthetic method
   public static CommandTrigger setCommandName$default(CommandTrigger var0, String var1, boolean var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = false;
      }

      return var0.setCommandName(var1, var2);
   }

   @JvmOverloads
   @NotNull
   public final CommandTrigger setName(@NotNull String commandName, boolean overrideExisting) {
      Intrinsics.checkNotNullParameter(commandName, "commandName");
      return this.setCommandName(commandName, overrideExisting);
   }

   // $FF: synthetic method
   public static CommandTrigger setName$default(CommandTrigger var0, String var1, boolean var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = false;
      }

      return var0.setName(var1, var2);
   }

   private final void reInstance() {
      Command var10000 = this.command;
      if (var10000 != null) {
         var10000.unregister();
      }

      Command var10001 = new Command;
      Trigger var10003 = (Trigger)this;
      String var10004 = this.commandName;
      if (var10004 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("commandName");
         var10004 = null;
      }

      String var10006 = this.commandName;
      if (var10006 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("commandName");
         var10006 = null;
      }

      var10001.<init>(var10003, var10004, Intrinsics.stringPlus("/", var10006), this.tabCompletions, this.aliases, this.overrideExisting, this.callback);
      this.command = var10001;
      var10000 = this.command;
      Intrinsics.checkNotNull(var10000);
      var10000.register();
   }

   @JvmOverloads
   @NotNull
   public final CommandTrigger setCommandName(@NotNull String commandName) {
      Intrinsics.checkNotNullParameter(commandName, "commandName");
      return setCommandName$default(this, commandName, false, 2, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final CommandTrigger setName(@NotNull String commandName) {
      Intrinsics.checkNotNullParameter(commandName, "commandName");
      return setName$default(this, commandName, false, 2, (Object)null);
   }
}
