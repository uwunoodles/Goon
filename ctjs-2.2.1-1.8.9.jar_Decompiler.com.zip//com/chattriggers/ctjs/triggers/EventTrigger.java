package com.chattriggers.ctjs.triggers;

import com.chattriggers.ctjs.engine.ILoader;
import com.chattriggers.ctjs.minecraft.listeners.CancellableEvent;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;
import net.minecraftforge.fml.common.eventhandler.Event;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\u001f\u0010\u000b\u001a\u00020\f2\u0010\u0010\r\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u00030\u000eH\u0016¢\u0006\u0002\u0010\u000fJ\u000e\u0010\t\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\nR\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0011"},
   d2 = {"Lcom/chattriggers/ctjs/triggers/EventTrigger;", "Lcom/chattriggers/ctjs/triggers/Trigger;", "method", "", "triggerType", "Lcom/chattriggers/ctjs/triggers/TriggerType;", "loader", "Lcom/chattriggers/ctjs/engine/ILoader;", "(Ljava/lang/Object;Lcom/chattriggers/ctjs/triggers/TriggerType;Lcom/chattriggers/ctjs/engine/ILoader;)V", "triggerIfCanceled", "", "trigger", "", "args", "", "([Ljava/lang/Object;)V", "bool", "ctjs"}
)
public final class EventTrigger extends Trigger {
   private boolean triggerIfCanceled;

   public EventTrigger(@NotNull Object method, @NotNull TriggerType triggerType, @NotNull ILoader loader) {
      Intrinsics.checkNotNullParameter(method, "method");
      Intrinsics.checkNotNullParameter(triggerType, "triggerType");
      Intrinsics.checkNotNullParameter(loader, "loader");
      super(method, triggerType, loader);
      this.triggerIfCanceled = true;
   }

   @NotNull
   public final EventTrigger triggerIfCanceled(boolean bool) {
      EventTrigger $this$triggerIfCanceled_u24lambda_u2d0 = (EventTrigger)this;
      int var4 = false;
      $this$triggerIfCanceled_u24lambda_u2d0.triggerIfCanceled = bool;
      return (EventTrigger)this;
   }

   public void trigger(@NotNull Object[] args) {
      Intrinsics.checkNotNullParameter(args, "args");
      Object event = ArraysKt.lastOrNull(args);
      boolean var10000;
      if (event instanceof CancellableEvent) {
         var10000 = ((CancellableEvent)event).isCanceled();
      } else {
         if (!(event instanceof Event)) {
            IllegalArgumentException var4 = new IllegalArgumentException;
            StringBuilder var10002 = (new StringBuilder()).append("Expected last argument of ").append(this.getType().name()).append(" trigger to be an Event, got ");
            String var10003;
            if (event == null) {
               var10003 = "null";
            } else {
               Class var5 = event.getClass();
               if (var5 == null) {
                  var10003 = "null";
               } else {
                  var10003 = var5.getName();
                  if (var10003 == null) {
                     var10003 = "null";
                  }
               }
            }

            var4.<init>(var10002.append(var10003).toString());
            throw var4;
         }

         var10000 = ((Event)event).isCanceled();
      }

      boolean isCanceled = var10000;
      if (this.triggerIfCanceled || !isCanceled) {
         this.callMethod(args);
      }

   }
}
