package com.chattriggers.ctjs.triggers;

import com.chattriggers.ctjs.engine.ILoader;
import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.minecraft.libs.EventLib;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntRange;
import kotlin.text.MatchGroup;
import kotlin.text.MatchGroupCollection;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mozilla.javascript.regexp.NativeRegExp;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0010\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001:\u0001.B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\u000e\u0010\u0013\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\u0015J\u001f\u0010\u0016\u001a\u00020\u00002\u0012\u0010\u000f\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00150\u0017\"\u00020\u0015¢\u0006\u0002\u0010\u0018J\u0018\u0010\u0019\u001a\u00020\u00152\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u0015H\u0002J\u0018\u0010\u001d\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u00102\u0006\u0010\u001c\u001a\u00020\u0015H\u0002J\u0018\u0010\u001e\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u00102\u0006\u0010\u001f\u001a\u00020\u0015H\u0002J\u0006\u0010 \u001a\u00020\u0000J\u000e\u0010!\u001a\u00020\u00002\u0006\u0010\u000b\u001a\u00020\u0003J\u0006\u0010\"\u001a\u00020\u0000J\u000e\u0010#\u001a\u00020\u00002\u0006\u0010\u000b\u001a\u00020\u0003J\u0006\u0010$\u001a\u00020\u0000J\u0006\u0010%\u001a\u00020\u0000J\u000e\u0010&\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\u0015J\u001f\u0010'\u001a\u00020\u00002\u0012\u0010\u000f\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00150\u0017\"\u00020\u0015¢\u0006\u0002\u0010\u0018J\u0006\u0010(\u001a\u00020\u0000J\u001f\u0010)\u001a\u00020*2\u0010\u0010+\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u00030\u0017H\u0016¢\u0006\u0002\u0010,J\u000e\u0010\u0012\u001a\u00020\u00002\u0006\u0010-\u001a\u00020\nR\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0003X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u000f\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00110\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006/"},
   d2 = {"Lcom/chattriggers/ctjs/triggers/ChatTrigger;", "Lcom/chattriggers/ctjs/triggers/Trigger;", "method", "", "type", "Lcom/chattriggers/ctjs/triggers/TriggerType;", "loader", "Lcom/chattriggers/ctjs/engine/ILoader;", "(Ljava/lang/Object;Lcom/chattriggers/ctjs/triggers/TriggerType;Lcom/chattriggers/ctjs/engine/ILoader;)V", "caseInsensitive", "", "chatCriteria", "criteriaPattern", "Lkotlin/text/Regex;", "formatted", "parameters", "", "Lcom/chattriggers/ctjs/triggers/ChatTrigger$Parameter;", "triggerIfCanceled", "addParameter", "parameter", "", "addParameters", "", "([Ljava/lang/String;)Lcom/chattriggers/ctjs/triggers/ChatTrigger;", "getChatMessage", "chatEvent", "Lnet/minecraftforge/client/event/ClientChatReceivedEvent;", "chatMessage", "getVariables", "matchesChatCriteria", "chat", "setCaseInsensitive", "setChatCriteria", "setContains", "setCriteria", "setEnd", "setExact", "setParameter", "setParameters", "setStart", "trigger", "", "args", "([Ljava/lang/Object;)V", "bool", "Parameter", "ctjs"}
)
public final class ChatTrigger extends Trigger {
   private Object chatCriteria;
   private boolean formatted;
   private boolean caseInsensitive;
   private Regex criteriaPattern;
   @NotNull
   private final List<ChatTrigger.Parameter> parameters;
   private boolean triggerIfCanceled;

   public ChatTrigger(@NotNull Object method, @NotNull TriggerType type, @NotNull ILoader loader) {
      Intrinsics.checkNotNullParameter(method, "method");
      Intrinsics.checkNotNullParameter(type, "type");
      Intrinsics.checkNotNullParameter(loader, "loader");
      super(method, type, loader);
      this.parameters = (List)(new ArrayList());
      this.triggerIfCanceled = true;
   }

   @NotNull
   public final ChatTrigger triggerIfCanceled(boolean bool) {
      ChatTrigger $this$triggerIfCanceled_u24lambda_u2d0 = (ChatTrigger)this;
      int var4 = false;
      $this$triggerIfCanceled_u24lambda_u2d0.triggerIfCanceled = bool;
      return (ChatTrigger)this;
   }

   @NotNull
   public final ChatTrigger setChatCriteria(@NotNull Object chatCriteria) {
      Intrinsics.checkNotNullParameter(chatCriteria, "chatCriteria");
      ChatTrigger $this$setChatCriteria_u24lambda_u2d2 = (ChatTrigger)this;
      int var4 = false;
      $this$setChatCriteria_u24lambda_u2d2.chatCriteria = chatCriteria;
      Set flags = (Set)(new LinkedHashSet());
      String source = ".+";
      CharSequence var8;
      if (chatCriteria instanceof String) {
         var8 = (CharSequence)chatCriteria;
         $this$setChatCriteria_u24lambda_u2d2.formatted = (new Regex("[&§]")).containsMatchIn(var8);
         CharSequence var9 = (CharSequence)Regex.Companion.escape(StringsKt.replace$default((String)chatCriteria, "\n", "->newLine<-", false, 4, (Object)null));
         Regex var10 = new Regex("\\$\\{[^*]+?}");
         String var11 = "\\\\E(.+)\\\\Q";
         var9 = (CharSequence)var10.replace(var9, var11);
         var10 = new Regex("\\$\\{\\*?}");
         var11 = "\\\\E(?:.+)\\\\Q";
         String replacedCriteria = var10.replace(var9, var11);
         if ($this$setChatCriteria_u24lambda_u2d2.caseInsensitive) {
            flags.add(RegexOption.IGNORE_CASE);
         }

         if (!Intrinsics.areEqual("", chatCriteria)) {
            source = replacedCriteria;
         }
      } else {
         if (!(chatCriteria instanceof NativeRegExp)) {
            throw new IllegalArgumentException("Expected String or Regexp Object");
         }

         Object var10000 = ((NativeRegExp)chatCriteria).get("ignoreCase");
         if (var10000 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
         }

         if ((Boolean)var10000 || $this$setChatCriteria_u24lambda_u2d2.caseInsensitive) {
            flags.add(RegexOption.IGNORE_CASE);
         }

         var10000 = ((NativeRegExp)chatCriteria).get("multiline");
         if (var10000 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
         }

         if ((Boolean)var10000) {
            flags.add(RegexOption.MULTILINE);
         }

         var10000 = ((NativeRegExp)chatCriteria).get("source");
         if (var10000 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
         }

         String it = (String)var10000;
         int var14 = false;
         source = Intrinsics.areEqual("", it) ? ".+" : it;
         var8 = (CharSequence)source;
         $this$setChatCriteria_u24lambda_u2d2.formatted = (new Regex("[&§]")).containsMatchIn(var8);
      }

      $this$setChatCriteria_u24lambda_u2d2.criteriaPattern = new Regex(source, flags);
      return (ChatTrigger)this;
   }

   @NotNull
   public final ChatTrigger setCriteria(@NotNull Object chatCriteria) {
      Intrinsics.checkNotNullParameter(chatCriteria, "chatCriteria");
      return this.setChatCriteria(chatCriteria);
   }

   @NotNull
   public final ChatTrigger setParameter(@NotNull String parameter) {
      Intrinsics.checkNotNullParameter(parameter, "parameter");
      ChatTrigger $this$setParameter_u24lambda_u2d3 = (ChatTrigger)this;
      int var4 = false;
      $this$setParameter_u24lambda_u2d3.parameters.clear();
      $this$setParameter_u24lambda_u2d3.addParameter(parameter);
      return (ChatTrigger)this;
   }

   @NotNull
   public final ChatTrigger setParameters(@NotNull String... parameters) {
      Intrinsics.checkNotNullParameter(parameters, "parameters");
      ChatTrigger $this$setParameters_u24lambda_u2d4 = (ChatTrigger)this;
      int var4 = false;
      $this$setParameters_u24lambda_u2d4.parameters.clear();
      $this$setParameters_u24lambda_u2d4.addParameters((String[])Arrays.copyOf(parameters, parameters.length));
      return (ChatTrigger)this;
   }

   @NotNull
   public final ChatTrigger addParameter(@NotNull String parameter) {
      Intrinsics.checkNotNullParameter(parameter, "parameter");
      ChatTrigger $this$addParameter_u24lambda_u2d5 = (ChatTrigger)this;
      int var4 = false;
      $this$addParameter_u24lambda_u2d5.parameters.add(ChatTrigger.Parameter.Companion.getParameterByName(parameter));
      return (ChatTrigger)this;
   }

   @NotNull
   public final ChatTrigger addParameters(@NotNull String... parameters) {
      Intrinsics.checkNotNullParameter(parameters, "parameters");
      ChatTrigger $this$addParameters_u24lambda_u2d6 = (ChatTrigger)this;
      int var4 = false;
      Object[] $this$forEach$iv = parameters;
      int $i$f$forEach = false;
      int var7 = 0;

      for(int var8 = parameters.length; var7 < var8; ++var7) {
         Object element$iv = $this$forEach$iv[var7];
         int var11 = false;
         $this$addParameters_u24lambda_u2d6.addParameter(element$iv);
      }

      return (ChatTrigger)this;
   }

   @NotNull
   public final ChatTrigger setStart() {
      ChatTrigger $this$setStart_u24lambda_u2d7 = (ChatTrigger)this;
      int var3 = false;
      $this$setStart_u24lambda_u2d7.setParameter("start");
      return (ChatTrigger)this;
   }

   @NotNull
   public final ChatTrigger setContains() {
      ChatTrigger $this$setContains_u24lambda_u2d8 = (ChatTrigger)this;
      int var3 = false;
      $this$setContains_u24lambda_u2d8.setParameter("contains");
      return (ChatTrigger)this;
   }

   @NotNull
   public final ChatTrigger setEnd() {
      ChatTrigger $this$setEnd_u24lambda_u2d9 = (ChatTrigger)this;
      int var3 = false;
      $this$setEnd_u24lambda_u2d9.setParameter("end");
      return (ChatTrigger)this;
   }

   @NotNull
   public final ChatTrigger setExact() {
      ChatTrigger $this$setExact_u24lambda_u2d10 = (ChatTrigger)this;
      int var3 = false;
      $this$setExact_u24lambda_u2d10.parameters.clear();
      return (ChatTrigger)this;
   }

   @NotNull
   public final ChatTrigger setCaseInsensitive() {
      ChatTrigger $this$setCaseInsensitive_u24lambda_u2d11 = (ChatTrigger)this;
      int var3 = false;
      $this$setCaseInsensitive_u24lambda_u2d11.caseInsensitive = true;
      if ($this$setCaseInsensitive_u24lambda_u2d11.chatCriteria != null) {
         Object var10001 = $this$setCaseInsensitive_u24lambda_u2d11.chatCriteria;
         if (var10001 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("chatCriteria");
            var10001 = Unit.INSTANCE;
         }

         $this$setCaseInsensitive_u24lambda_u2d11.setCriteria(var10001);
      }

      return (ChatTrigger)this;
   }

   public void trigger(@NotNull Object[] args) {
      Intrinsics.checkNotNullParameter(args, "args");
      String chatMessage;
      if (!(args[0] instanceof String) || !(args[1] instanceof ClientChatReceivedEvent)) {
         int var8 = false;
         chatMessage = "Argument 1 must be a String, Argument 2 must be a ClientChatReceivedEvent";
         throw new IllegalArgumentException(chatMessage.toString());
      } else {
         Object var10000 = args[1];
         if (args[1] == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.minecraftforge.client.event.ClientChatReceivedEvent");
         } else {
            ClientChatReceivedEvent chatEvent = (ClientChatReceivedEvent)var10000;
            if (this.triggerIfCanceled || !chatEvent.isCanceled()) {
               Object var10002 = args[0];
               if (args[0] == null) {
                  throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
               } else {
                  chatMessage = this.getChatMessage(chatEvent, (String)var10002);
                  List var9 = this.getVariables(chatMessage);
                  if (var9 != null) {
                     List variables = var9;
                     variables.add(chatEvent);
                     Collection $this$toTypedArray$iv = (Collection)variables;
                     int $i$f$toTypedArray = false;
                     Object[] var10001 = $this$toTypedArray$iv.toArray(new Object[0]);
                     Intrinsics.checkNotNull(var10001, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
                     this.callMethod(var10001);
                  }
               }
            }
         }
      }
   }

   private final String getChatMessage(ClientChatReceivedEvent chatEvent, String chatMessage) {
      String var10000;
      if (this.formatted) {
         String var3 = EventLib.getMessage(chatEvent).func_150254_d();
         Intrinsics.checkNotNullExpressionValue(var3, "getMessage(chatEvent).formattedText");
         var10000 = StringsKt.replace$default(var3, "§", "&", false, 4, (Object)null);
      } else {
         var10000 = ChatLib.removeFormatting(chatMessage);
      }

      return var10000;
   }

   private final List<Object> getVariables(String chatMessage) {
      return this.criteriaPattern != null ? this.matchesChatCriteria(StringsKt.replace$default(chatMessage, "\n", "->newLine<-", false, 4, (Object)null)) : (List)(new ArrayList());
   }

   private final List<Object> matchesChatCriteria(String chat) {
      Regex var10000 = this.criteriaPattern;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("criteriaPattern");
         var10000 = null;
      }

      Regex regex = var10000;
      MatchResult var13;
      if (this.parameters.isEmpty()) {
         if (!regex.matches((CharSequence)chat)) {
            return null;
         }
      } else {
         Iterable $this$forEach$iv = (Iterable)this.parameters;
         int $i$f$forEach = false;
         Iterator var5 = $this$forEach$iv.iterator();

         while(var5.hasNext()) {
            Object element$iv = var5.next();
            ChatTrigger.Parameter parameter = (ChatTrigger.Parameter)element$iv;
            boolean var8 = false;

            MatchGroup var9;
            try {
               var13 = Regex.find$default(regex, (CharSequence)chat, 0, 2, (Object)null);
               MatchGroup var14;
               if (var13 == null) {
                  var14 = null;
               } else {
                  MatchGroupCollection var15 = var13.getGroups();
                  var14 = var15 == null ? null : var15.get(0);
               }

               var9 = var14;
            } catch (IndexOutOfBoundsException var12) {
               return null;
            }

            switch(parameter == null ? -1 : ChatTrigger.WhenMappings.$EnumSwitchMapping$0[parameter.ordinal()]) {
            case -1:
               if (!regex.matches((CharSequence)chat)) {
                  return null;
               }
            case 0:
            default:
               break;
            case 1:
               if (var9 == null) {
                  return null;
               }
               break;
            case 2:
               if (var9 != null && var9.getRange().getFirst() == 0) {
                  break;
               }

               return null;
            case 3:
               boolean var16;
               if (var9 == null) {
                  var16 = false;
               } else {
                  IntRange var17 = var9.getRange();
                  var16 = var17 == null ? false : var17.getLast() == chat.length();
               }

               if (!var16) {
                  return null;
               }
            }
         }
      }

      var13 = Regex.find$default(regex, (CharSequence)chat, 0, 2, (Object)null);
      List var18;
      if (var13 == null) {
         var18 = null;
      } else {
         var18 = var13.getGroupValues();
         if (var18 == null) {
            var18 = null;
         } else {
            var18 = CollectionsKt.drop((Iterable)var18, 1);
            var18 = var18 == null ? null : CollectionsKt.toMutableList((Collection)var18);
         }
      }

      return var18;
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\b\t\b\u0086\u0001\u0018\u0000 \u000e2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u000eB\u001b\b\u0002\u0012\u0012\u0010\u0002\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00040\u0003\"\u00020\u0004¢\u0006\u0002\u0010\u0005R \u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0006X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\r¨\u0006\u000f"},
      d2 = {"Lcom/chattriggers/ctjs/triggers/ChatTrigger$Parameter;", "", "names", "", "", "(Ljava/lang/String;I[Ljava/lang/String;)V", "", "getNames", "()Ljava/util/List;", "setNames", "(Ljava/util/List;)V", "CONTAINS", "START", "END", "Companion", "ctjs"}
   )
   public static enum Parameter {
      @NotNull
      public static final ChatTrigger.Parameter.Companion Companion;
      @NotNull
      private List<String> names;
      CONTAINS,
      START,
      END;

      private Parameter(String... names) {
         this.names = ArraysKt.asList(names);
      }

      @NotNull
      public final List<String> getNames() {
         return this.names;
      }

      public final void setNames(@NotNull List<String> var1) {
         Intrinsics.checkNotNullParameter(var1, "<set-?>");
         this.names = var1;
      }

      // $FF: synthetic method
      private static final ChatTrigger.Parameter[] $values() {
         ChatTrigger.Parameter[] var0 = new ChatTrigger.Parameter[]{CONTAINS, START, END};
         return var0;
      }

      static {
         String[] var0 = new String[]{"<c>", "<contains>", "c", "contains"};
         CONTAINS = new ChatTrigger.Parameter("CONTAINS", 0, var0);
         var0 = new String[]{"<s>", "<start>", "s", "start"};
         START = new ChatTrigger.Parameter("START", 1, var0);
         var0 = new String[]{"<e>", "<end>", "e", "end"};
         END = new ChatTrigger.Parameter("END", 2, var0);
         Companion = new ChatTrigger.Parameter.Companion((DefaultConstructorMarker)null);
      }

      @Metadata(
         mv = {1, 6, 0},
         k = 1,
         xi = 48,
         d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0006¨\u0006\u0007"},
         d2 = {"Lcom/chattriggers/ctjs/triggers/ChatTrigger$Parameter$Companion;", "", "()V", "getParameterByName", "Lcom/chattriggers/ctjs/triggers/ChatTrigger$Parameter;", "name", "", "ctjs"}
      )
      public static final class Companion {
         private Companion() {
         }

         @Nullable
         public final ChatTrigger.Parameter getParameterByName(@NotNull String name) {
            Intrinsics.checkNotNullParameter(name, "name");
            ChatTrigger.Parameter[] var2 = ChatTrigger.Parameter.values();
            int var3 = 0;
            int var4 = var2.length;

            ChatTrigger.Parameter var15;
            while(true) {
               if (var3 >= var4) {
                  var15 = null;
                  break;
               }

               ChatTrigger.Parameter var5 = var2[var3];
               int var7 = false;
               Iterable $this$any$iv = (Iterable)var5.getNames();
               int $i$f$any = false;
               boolean var14;
               if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
                  var14 = false;
               } else {
                  Iterator var10 = $this$any$iv.iterator();

                  while(true) {
                     if (!var10.hasNext()) {
                        var14 = false;
                        break;
                     }

                     Object element$iv = var10.next();
                     String it = (String)element$iv;
                     int var13 = false;
                     String var10000 = it.toLowerCase(Locale.ROOT);
                     Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String).toLowerCase(Locale.ROOT)");
                     if (Intrinsics.areEqual(var10000, name)) {
                        var14 = true;
                        break;
                     }
                  }
               }

               if (var14) {
                  var15 = var5;
                  break;
               }

               ++var3;
            }

            return var15;
         }

         // $FF: synthetic method
         public Companion(DefaultConstructorMarker $constructor_marker) {
            this();
         }
      }
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[ChatTrigger.Parameter.values().length];
         var0[ChatTrigger.Parameter.CONTAINS.ordinal()] = 1;
         var0[ChatTrigger.Parameter.START.ordinal()] = 2;
         var0[ChatTrigger.Parameter.END.ordinal()] = 3;
         $EnumSwitchMapping$0 = var0;
      }
   }
}
