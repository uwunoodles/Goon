package com.chattriggers.ctjs.triggers;

import com.chattriggers.ctjs.engine.ILoader;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0011\n\u0002\b\b\n\u0002\u0010\u0002\n\u0002\b\u0002\b&\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\u001f\u0010\u000e\u001a\u00020\u00032\u0010\u0010\u000f\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u00030\u0010H&¢\u0006\u0002\u0010\u0011J\u0014\u0010\u0012\u001a\u00020\u00002\f\u0010\u0013\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u000bJ\u0018\u0010\u0014\u001a\u00020\u00002\u0010\u0010\u0015\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u000b0\nJ\u0016\u0010\u0016\u001a\u00020\u00002\f\u0010\u0013\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u000bH\u0007J\u001a\u0010\u0017\u001a\u00020\u00002\u0010\u0010\u0015\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u000b0\nH\u0007J\u001f\u0010\u0018\u001a\u00020\u00192\u0010\u0010\u000f\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010\u00030\u0010H\u0016¢\u0006\u0002\u0010\u001aR\u0018\u0010\t\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u000b0\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\r¨\u0006\u001b"},
   d2 = {"Lcom/chattriggers/ctjs/triggers/ClassFilterTrigger;", "Lcom/chattriggers/ctjs/triggers/Trigger;", "method", "", "triggerType", "Lcom/chattriggers/ctjs/triggers/TriggerType;", "loader", "Lcom/chattriggers/ctjs/engine/ILoader;", "(Ljava/lang/Object;Lcom/chattriggers/ctjs/triggers/TriggerType;Lcom/chattriggers/ctjs/engine/ILoader;)V", "triggerClasses", "", "Ljava/lang/Class;", "getTriggerType", "()Lcom/chattriggers/ctjs/triggers/TriggerType;", "evalTriggerType", "args", "", "([Ljava/lang/Object;)Ljava/lang/Object;", "setFilteredClass", "clazz", "setFilteredClasses", "classes", "setPacketClass", "setPacketClasses", "trigger", "", "([Ljava/lang/Object;)V", "ctjs"}
)
public abstract class ClassFilterTrigger extends Trigger {
   @NotNull
   private final TriggerType triggerType;
   @NotNull
   private List<? extends Class<?>> triggerClasses;

   public ClassFilterTrigger(@NotNull Object method, @NotNull TriggerType triggerType, @NotNull ILoader loader) {
      Intrinsics.checkNotNullParameter(method, "method");
      Intrinsics.checkNotNullParameter(triggerType, "triggerType");
      Intrinsics.checkNotNullParameter(loader, "loader");
      super(method, triggerType, loader);
      this.triggerType = triggerType;
      this.triggerClasses = CollectionsKt.emptyList();
   }

   @NotNull
   public final TriggerType getTriggerType() {
      return this.triggerType;
   }

   /** @deprecated */
   @Deprecated(
      message = "Prefer setFilteredClass",
      replaceWith = @ReplaceWith(
   expression = "setFilteredClass(MyClass.class)",
   imports = {}
)
   )
   @NotNull
   public final ClassFilterTrigger setPacketClass(@Nullable Class<?> clazz) {
      return this.setFilteredClasses(CollectionsKt.listOfNotNull(clazz));
   }

   /** @deprecated */
   @Deprecated(
      message = "Prefer setFilteredClasses",
      replaceWith = @ReplaceWith(
   expression = "setFilteredClasses([A.class, B.class, C.class])",
   imports = {}
)
   )
   @NotNull
   public final ClassFilterTrigger setPacketClasses(@NotNull List<? extends Class<?>> classes) {
      Intrinsics.checkNotNullParameter(classes, "classes");
      return this.setFilteredClasses(classes);
   }

   @NotNull
   public final ClassFilterTrigger setFilteredClass(@Nullable Class<?> clazz) {
      return this.setFilteredClasses(CollectionsKt.listOfNotNull(clazz));
   }

   @NotNull
   public final ClassFilterTrigger setFilteredClasses(@NotNull List<? extends Class<?>> classes) {
      Intrinsics.checkNotNullParameter(classes, "classes");
      ClassFilterTrigger $this$setFilteredClasses_u24lambda_u2d0 = (ClassFilterTrigger)this;
      int var4 = false;
      $this$setFilteredClasses_u24lambda_u2d0.triggerClasses = classes;
      return (ClassFilterTrigger)this;
   }

   public void trigger(@NotNull Object[] args) {
      Intrinsics.checkNotNullParameter(args, "args");
      Object placeholder = this.evalTriggerType(args);
      if (!this.triggerClasses.isEmpty()) {
         Iterable $this$any$iv = (Iterable)this.triggerClasses;
         int $i$f$any = false;
         boolean var10000;
         if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
            var10000 = false;
         } else {
            Iterator var5 = $this$any$iv.iterator();

            while(true) {
               if (!var5.hasNext()) {
                  var10000 = false;
                  break;
               }

               Object element$iv = var5.next();
               Class it = (Class)element$iv;
               int var8 = false;
               if (it.isInstance(placeholder)) {
                  var10000 = true;
                  break;
               }
            }
         }

         if (!var10000) {
            return;
         }
      }

      this.callMethod(args);
   }

   @NotNull
   public abstract Object evalTriggerType(@NotNull Object[] var1);
}
