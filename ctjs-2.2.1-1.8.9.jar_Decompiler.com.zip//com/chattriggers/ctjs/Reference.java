package com.chattriggers.ctjs;

import com.chattriggers.ctjs.commands.Command;
import com.chattriggers.ctjs.engine.module.ModuleManager;
import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.minecraft.libs.renderer.Renderer;
import com.chattriggers.ctjs.minecraft.listeners.MouseListener;
import com.chattriggers.ctjs.minecraft.objects.display.DisplayHandler;
import com.chattriggers.ctjs.minecraft.objects.keybind.KeyBind;
import com.chattriggers.ctjs.minecraft.objects.message.Message;
import com.chattriggers.ctjs.minecraft.wrappers.Client;
import com.chattriggers.ctjs.triggers.ForgeTrigger;
import com.chattriggers.ctjs.triggers.TriggerType;
import com.chattriggers.ctjs.utils.Config;
import com.chattriggers.ctjs.utils.console.Console;
import com.chattriggers.ctjs.utils.kotlin.ExtensionsKt;
import java.util.Iterator;
import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.concurrent.ThreadsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0016\u0010\r\u001a\u00020\u000e2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u000e0\u0010H\u0007J\b\u0010\u0011\u001a\u00020\u000eH\u0007J\u0010\u0010\u0012\u001a\u00020\u000e2\u0006\u0010\u0013\u001a\u00020\u0014H\u0002J\b\u0010\u0015\u001a\u00020\u000eH\u0007J\u0012\u0010\u0016\u001a\u00020\u000e2\b\b\u0002\u0010\u0017\u001a\u00020\tH\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u001a\u0010\b\u001a\u00020\tX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\n\"\u0004\b\u000b\u0010\f¨\u0006\u0018"},
   d2 = {"Lcom/chattriggers/ctjs/Reference;", "", "()V", "DEFAULT_MODULES_FOLDER", "", "MODID", "MODNAME", "MODVERSION", "isLoaded", "", "()Z", "setLoaded", "(Z)V", "conditionalThread", "", "block", "Lkotlin/Function0;", "loadCT", "printLoadCompletionStatus", "percentComplete", "", "reloadCT", "unloadCT", "asCommand", "ctjs"}
)
public final class Reference {
   @NotNull
   public static final Reference INSTANCE = new Reference();
   @NotNull
   public static final String MODID = "chattriggers";
   @NotNull
   public static final String MODNAME = "ChatTriggers";
   @NotNull
   public static final String MODVERSION = "2.2.1";
   @NotNull
   public static final String DEFAULT_MODULES_FOLDER = "./config/ChatTriggers/modules";
   private static boolean isLoaded = true;

   private Reference() {
   }

   public final boolean isLoaded() {
      return isLoaded;
   }

   public final void setLoaded(boolean var1) {
      isLoaded = var1;
   }

   /** @deprecated */
   @Deprecated(
      message = "Does not provide any additional functionality",
      replaceWith = @ReplaceWith(
   expression = "loadCT",
   imports = {}
)
   )
   @JvmStatic
   public static final void reloadCT() {
      Reference var10000 = INSTANCE;
      loadCT();
   }

   @JvmStatic
   public static final void unloadCT(boolean asCommand) {
      TriggerType.WorldUnload.triggerAll();
      TriggerType.GameUnload.triggerAll();
      Reference var10000 = INSTANCE;
      isLoaded = false;
      DisplayHandler.INSTANCE.clearDisplays();
      ModuleManager.INSTANCE.teardown();
      MouseListener.INSTANCE.clearListeners();
      KeyBind.Companion.clearKeyBinds();
      ForgeTrigger.Companion.unregisterTriggers();
      Iterable $this$forEach$iv = (Iterable)CollectionsKt.toList((Iterable)Command.Companion.getActiveCommands$ctjs().values());
      int $i$f$forEach = false;
      Iterator var3 = $this$forEach$iv.iterator();

      while(var3.hasNext()) {
         Object element$iv = var3.next();
         Command p0 = (Command)element$iv;
         int var6 = false;
         p0.unregister();
      }

      Client.Companion.scheduleTask$default(Client.Companion, 0, (Function0)null.INSTANCE, 1, (Object)null);
      if (asCommand) {
         ChatLib.chat("&7Unloaded all of ChatTriggers");
      }

   }

   // $FF: synthetic method
   public static void unloadCT$default(boolean var0, int var1, Object var2) {
      if ((var1 & 1) != 0) {
         var0 = true;
      }

      unloadCT(var0);
   }

   @JvmStatic
   public static final void loadCT() {
      Client.Companion.getMinecraft().field_71474_y.func_74303_b();
      Reference var10000 = INSTANCE;
      unloadCT(false);
      ChatLib.chat("&cReloading ChatTriggers scripts...");
      INSTANCE.printLoadCompletionStatus(0.0F);
      var10000 = INSTANCE;
      conditionalThread((Function0)null.INSTANCE);
   }

   private final void printLoadCompletionStatus(float percentComplete) {
      int completionInteger = MathKt.roundToInt(percentComplete * (float)100);
      String prefix = completionInteger + "% [";
      String postfix = "]";
      int charWidth = Renderer.getStringWidth("=");
      int availableWidth = ChatLib.getChatWidth() - Renderer.getStringWidth(Intrinsics.stringPlus(prefix, postfix));
      int correctLength = availableWidth / charWidth;
      int completedLength = MathKt.roundToInt(percentComplete * (float)correctLength);
      String fullWidth = ExtensionsKt.times("=", (Number)completedLength);
      int spaceWidth = Renderer.getStringWidth(" ");
      int spaceLeft = (availableWidth - completedLength * charWidth) / spaceWidth;
      String padding = ExtensionsKt.times(" ", (Number)spaceLeft);
      String correctLine = "&c" + prefix + fullWidth + padding + postfix;
      Object[] var14 = new Object[]{correctLine};
      (new Message(var14)).setChatLineId(28445).chat();
   }

   @JvmStatic
   public static final void conditionalThread(@NotNull final Function0<Unit> block) {
      Intrinsics.checkNotNullParameter(block, "block");
      if (Config.INSTANCE.getThreadedLoading()) {
         ThreadsKt.thread$default(false, false, (ClassLoader)null, (String)null, 0, (Function0)(new Function0<Unit>() {
            public final void invoke() {
               try {
                  block.invoke();
               } catch (Throwable var2) {
                  ReferenceKt.printTraceToConsole$default(var2, (Console)null, 1, (Object)null);
               }

            }
         }), 31, (Object)null);
      } else {
         block.invoke();
      }

   }
}
