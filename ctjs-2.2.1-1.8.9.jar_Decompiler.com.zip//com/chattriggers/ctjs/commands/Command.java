package com.chattriggers.ctjs.commands;

import com.chattriggers.ctjs.ReferenceKt;
import com.chattriggers.ctjs.triggers.Trigger;
import com.chattriggers.ctjs.utils.console.LogType;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;
import net.minecraftforge.client.ClientCommandHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\u0018\u0000 #2\u00020\u0001:\u0001#Bi\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00050\b\u0012\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00050\b\u0012\b\b\u0002\u0010\n\u001a\u00020\u000b\u0012$\b\u0002\u0010\f\u001a\u001e\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\u00050\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\b\u0018\u00010\r¢\u0006\u0002\u0010\u000fJ9\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00050\b2\b\u0010\u0011\u001a\u0004\u0018\u00010\u00122\u0010\u0010\u0013\u001a\f\u0012\u0006\b\u0001\u0012\u00020\u0005\u0018\u00010\u000e2\b\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0016¢\u0006\u0002\u0010\u0016J\u000e\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00050\bH\u0016J\b\u0010\u0018\u001a\u00020\u0005H\u0016J\u0010\u0010\u0019\u001a\u00020\u00052\u0006\u0010\u0011\u001a\u00020\u0012H\u0016J\b\u0010\u001a\u001a\u00020\u001bH\u0016J\f\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u00030\u001dJ#\u0010\u001e\u001a\u00020\u001f2\u0006\u0010\u0011\u001a\u00020\u00122\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00050\u000eH\u0016¢\u0006\u0002\u0010 J\u0006\u0010!\u001a\u00020\u001fJ\u0006\u0010\"\u001a\u00020\u001fR\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00050\bX\u0082\u000e¢\u0006\u0002\n\u0000R*\u0010\f\u001a\u001e\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\u00050\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\b\u0018\u00010\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00050\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006$"},
   d2 = {"Lcom/chattriggers/ctjs/commands/Command;", "Lnet/minecraft/command/CommandBase;", "trigger", "Lcom/chattriggers/ctjs/triggers/Trigger;", "name", "", "usage", "tabCompletionOptions", "", "aliases", "overrideExisting", "", "callback", "Lkotlin/Function1;", "", "(Lcom/chattriggers/ctjs/triggers/Trigger;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;ZLkotlin/jvm/functions/Function1;)V", "addTabCompletionOptions", "sender", "Lnet/minecraft/command/ICommandSender;", "args", "pos", "Lnet/minecraft/util/BlockPos;", "(Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List;", "getCommandAliases", "getCommandName", "getCommandUsage", "getRequiredPermissionLevel", "", "getTriggers", "", "processCommand", "", "(Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V", "register", "unregister", "Companion", "ctjs"}
)
public final class Command extends CommandBase {
   @NotNull
   public static final Command.Companion Companion = new Command.Companion((DefaultConstructorMarker)null);
   @NotNull
   private final Trigger trigger;
   @NotNull
   private final String name;
   @NotNull
   private final String usage;
   @NotNull
   private final List<String> tabCompletionOptions;
   @NotNull
   private List<String> aliases;
   private final boolean overrideExisting;
   @Nullable
   private final Function1<String[], List<String>> callback;
   @NotNull
   private static final Map<String, Command> activeCommands = (Map)(new LinkedHashMap());

   public Command(@NotNull Trigger trigger, @NotNull String name, @NotNull String usage, @NotNull List<String> tabCompletionOptions, @NotNull List<String> aliases, boolean overrideExisting, @Nullable Function1<? super String[], ? extends List<String>> callback) {
      Intrinsics.checkNotNullParameter(trigger, "trigger");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(usage, "usage");
      Intrinsics.checkNotNullParameter(tabCompletionOptions, "tabCompletionOptions");
      Intrinsics.checkNotNullParameter(aliases, "aliases");
      super();
      this.trigger = trigger;
      this.name = name;
      this.usage = usage;
      this.tabCompletionOptions = tabCompletionOptions;
      this.aliases = aliases;
      this.overrideExisting = overrideExisting;
      this.callback = callback;
   }

   // $FF: synthetic method
   public Command(Trigger var1, String var2, String var3, List var4, List var5, boolean var6, Function1 var7, int var8, DefaultConstructorMarker var9) {
      if ((var8 & 32) != 0) {
         var6 = false;
      }

      if ((var8 & 64) != 0) {
         var7 = null;
      }

      this(var1, var2, var3, var4, var5, var6, var7);
   }

   @NotNull
   public final List<Trigger> getTriggers() {
      return CollectionsKt.listOf(this.trigger);
   }

   @NotNull
   public String func_71517_b() {
      return this.name;
   }

   @NotNull
   public List<String> func_71514_a() {
      return this.aliases;
   }

   public int func_82362_a() {
      return 0;
   }

   @NotNull
   public String func_71518_a(@NotNull ICommandSender sender) {
      Intrinsics.checkNotNullParameter(sender, "sender");
      return this.usage;
   }

   @NotNull
   public List<String> func_180525_a(@Nullable ICommandSender sender, @Nullable String[] args, @Nullable BlockPos pos) {
      Function1 var10000 = this.callback;
      List var4;
      if (var10000 == null) {
         var4 = null;
      } else {
         String[] var10001 = args;
         if (args == null) {
            var10001 = new String[0];
         }

         var4 = (List)var10000.invoke(var10001);
         var4 = var4 == null ? null : CollectionsKt.toMutableList((Collection)var4);
      }

      if (var4 == null) {
         var4 = this.tabCompletionOptions;
      }

      return var4;
   }

   public void func_71515_b(@NotNull ICommandSender sender, @NotNull String[] args) throws CommandException {
      Intrinsics.checkNotNullParameter(sender, "sender");
      Intrinsics.checkNotNullParameter(args, "args");
      this.trigger.trigger(args);
   }

   public final void register() {
      if (ClientCommandHandler.instance.func_71555_a().keySet().contains(this.name) && !this.overrideExisting) {
         ReferenceKt.printToConsole("Command with name " + this.name + " already exists! This will not override the other command with the same name. To override conflicting commands, set the 2nd argument in setName() to true.", this.trigger.getLoader$ctjs().getConsole(), LogType.WARN);
      } else {
         ClientCommandHandler.instance.func_71560_a((ICommand)this);
         Map var1 = activeCommands;
         String var2 = this.name;
         var1.put(var2, this);
      }
   }

   public final void unregister() {
      ClientCommandHandler.instance.field_71561_b.remove(this);
      ClientCommandHandler.instance.func_71555_a().remove(this.name);
      activeCommands.remove(this.name);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010%\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R \u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0004X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\t"},
      d2 = {"Lcom/chattriggers/ctjs/commands/Command$Companion;", "", "()V", "activeCommands", "", "", "Lcom/chattriggers/ctjs/commands/Command;", "getActiveCommands$ctjs", "()Ljava/util/Map;", "ctjs"}
   )
   public static final class Companion {
      private Companion() {
      }

      @NotNull
      public final Map<String, Command> getActiveCommands$ctjs() {
         return Command.activeCommands;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
