package com.chattriggers.ctjs.commands;

import com.chattriggers.ctjs.Reference;
import com.chattriggers.ctjs.ReferenceKt;
import com.chattriggers.ctjs.engine.module.Module;
import com.chattriggers.ctjs.engine.module.ModuleManager;
import com.chattriggers.ctjs.engine.module.ModulesGui;
import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.minecraft.listeners.ClientListener;
import com.chattriggers.ctjs.minecraft.objects.gui.GuiHandler;
import com.chattriggers.ctjs.minecraft.objects.message.Message;
import com.chattriggers.ctjs.minecraft.objects.message.TextComponent;
import com.chattriggers.ctjs.utils.Config;
import com.chattriggers.ctjs.utils.console.Console;
import com.chattriggers.ctjs.utils.kotlin.ExtensionsKt;
import com.fasterxml.jackson.core.Version;
import gg.essential.api.utils.GuiUtil;
import gg.essential.api.utils.GuiUtil.Companion;
import gg.essential.vigilance.gui.SettingsGui;
import java.awt.Desktop;
import java.awt.Toolkit;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010 \n\u0000\n\u0002\u0010!\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0006\u001a\u00020\u0007H\u0002J\u001b\u0010\b\u001a\u00020\u00072\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nH\u0002¢\u0006\u0002\u0010\fJ\u001b\u0010\r\u001a\u00020\u00072\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nH\u0002¢\u0006\u0002\u0010\fJ\u0012\u0010\u000e\u001a\u00020\u00072\b\b\u0002\u0010\u000f\u001a\u00020\u0004H\u0002J\u0012\u0010\u0010\u001a\u00020\u00072\b\b\u0002\u0010\u000f\u001a\u00020\u0004H\u0002J\u001e\u0010\u0011\u001a\u00020\u00072\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u000b0\u00132\u0006\u0010\u000f\u001a\u00020\u0004H\u0002J\u000e\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u000b0\u0015H\u0016J\b\u0010\u0016\u001a\u00020\u000bH\u0016J\u0012\u0010\u0017\u001a\u00020\u000b2\b\u0010\u0018\u001a\u0004\u0018\u00010\u0019H\u0016J\b\u0010\u001a\u001a\u00020\u0004H\u0016J\b\u0010\u001b\u001a\u00020\u000bH\u0002J\u0010\u0010\u001c\u001a\u00020\u00072\u0006\u0010\u001d\u001a\u00020\u000bH\u0002J\b\u0010\u001e\u001a\u00020\u0007H\u0002J%\u0010\u001f\u001a\u00020\u00072\b\u0010\u0018\u001a\u0004\u0018\u00010\u00192\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nH\u0016¢\u0006\u0002\u0010 J\u001b\u0010!\u001a\u00020\u00072\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nH\u0002¢\u0006\u0002\u0010\fR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\""},
   d2 = {"Lcom/chattriggers/ctjs/commands/CTCommand;", "Lnet/minecraft/command/CommandBase;", "()V", "idFixed", "", "idFixedOffset", "clearOldDump", "", "copyArgsToClipboard", "args", "", "", "([Ljava/lang/String;)V", "dump", "dumpActionBar", "lines", "dumpChat", "dumpList", "messages", "", "getCommandAliases", "", "getCommandName", "getCommandUsage", "sender", "Lnet/minecraft/command/ICommandSender;", "getRequiredPermissionLevel", "getUsage", "import", "moduleName", "openFileLocation", "processCommand", "(Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V", "run", "ctjs"}
)
public final class CTCommand extends CommandBase {
   @NotNull
   public static final CTCommand INSTANCE = new CTCommand();
   private static final int idFixed = 90123;
   private static int idFixedOffset = -1;

   private CTCommand() {
   }

   @NotNull
   public String func_71518_a(@Nullable ICommandSender sender) {
      return this.getUsage();
   }

   @NotNull
   public String func_71517_b() {
      return "chattriggers";
   }

   @NotNull
   public List<String> func_71514_a() {
      String[] var1 = new String[]{"ct"};
      return CollectionsKt.mutableListOf(var1);
   }

   public int func_82362_a() {
      return 0;
   }

   public void func_71515_b(@Nullable ICommandSender sender, @NotNull String[] args) throws CommandException {
      Intrinsics.checkNotNullParameter(args, "args");
      this.run(args);
   }

   private final void run(String[] args) {
      if (args.length == 0) {
         ChatLib.chat(this.getUsage());
      } else {
         label143: {
            label144: {
               label145: {
                  label146: {
                     String var10000 = args[0].toLowerCase(Locale.ROOT);
                     Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String).toLowerCase(Locale.ROOT)");
                     String var2 = var10000;
                     switch(var2.hashCode()) {
                     case -1354792126:
                        if (var2.equals("config")) {
                           break label144;
                        }
                        break;
                     case -1335458389:
                        if (var2.equals("delete")) {
                           if (args.length == 1) {
                              ChatLib.chat("&c/ct delete [module name]");
                           } else {
                              ChatLib.chat(Intrinsics.stringPlus(ModuleManager.INSTANCE.deleteModule(args[1]) ? "&aDeleted " : "&cFailed to delete ", args[1]));
                           }

                           return;
                        }
                        break;
                     case -1184795739:
                        if (var2.equals("import")) {
                           if (args.length == 1) {
                              ChatLib.chat("&c/ct import [module name]");
                           } else {
                              this.import(args[1]);
                           }

                           return;
                        }
                        break;
                     case -934641255:
                        if (var2.equals("reload")) {
                           break label143;
                        }
                        break;
                     case -840442113:
                        if (var2.equals("unload")) {
                           Reference.unloadCT$default(false, 1, (Object)null);
                           return;
                        }
                        break;
                     case 113879:
                        if (var2.equals("sim")) {
                           break label145;
                        }
                        break;
                     case 3059573:
                        if (var2.equals("copy")) {
                           this.copyArgsToClipboard(args);
                           return;
                        }
                        break;
                     case 3095028:
                        if (var2.equals("dump")) {
                           this.dump(args);
                           return;
                        }
                        break;
                     case 3143036:
                        if (var2.equals("file")) {
                           break label146;
                        }
                        break;
                     case 3327206:
                        if (var2.equals("load")) {
                           break label143;
                        }
                        break;
                     case 97434231:
                        if (var2.equals("files")) {
                           break label146;
                        }
                        break;
                     case 490275364:
                        if (var2.equals("simulate")) {
                           break label145;
                        }
                        break;
                     case 951510359:
                        if (var2.equals("console")) {
                           if (args.length == 1) {
                              ModuleManager.INSTANCE.getGeneralConsole().showConsole();
                           } else {
                              ModuleManager.INSTANCE.getConsole(args[1]).showConsole();
                           }

                           return;
                        }
                        break;
                     case 1227433863:
                        if (var2.equals("modules")) {
                           GuiHandler.INSTANCE.openGui((GuiScreen)ModulesGui.INSTANCE);
                           return;
                        }
                        break;
                     case 1434631203:
                        if (var2.equals("settings")) {
                           break label144;
                        }
                        break;
                     case 1985941072:
                        if (var2.equals("setting")) {
                           break label144;
                        }
                     }

                     ChatLib.chat(this.getUsage());
                     return;
                  }

                  this.openFileLocation();
                  return;
               }

               byte var4 = 1;
               int var5 = args.length;
               ChatLib.simulateChat(ArraysKt.joinToString$default(ArraysKt.copyOfRange(args, var4, var5), (CharSequence)" ", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 62, (Object)null));
               return;
            }

            Companion var6 = GuiUtil.Companion;
            SettingsGui var10001 = Config.INSTANCE.gui();
            Intrinsics.checkNotNull(var10001);
            var6.open((GuiScreen)var10001);
            return;
         }

         Reference.loadCT();
      }
   }

   private final void import(final String moduleName) {
      Iterable $this$any$iv = (Iterable)ModuleManager.INSTANCE.getCachedModules();
      int $i$f$any = false;
      boolean var10000;
      if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
         var10000 = false;
      } else {
         Iterator var4 = $this$any$iv.iterator();

         while(true) {
            if (!var4.hasNext()) {
               var10000 = false;
               break;
            }

            Object element$iv = var4.next();
            Module it = (Module)element$iv;
            int var7 = false;
            if (StringsKt.equals(it.getName(), moduleName, true)) {
               var10000 = true;
               break;
            }
         }
      }

      if (var10000) {
         ChatLib.chat("&cModule " + moduleName + " is already installed!");
      } else {
         ChatLib.chat("&cImporting " + moduleName + "...");
         Reference.conditionalThread((Function0)(new Function0<Unit>() {
            public final void invoke() {
               ModuleManager.ImportedModule var1 = ModuleManager.INSTANCE.importModule(moduleName);
               Module module = var1.component1();
               List dependencies = var1.component2();
               if (module == null) {
                  ChatLib.chat(Intrinsics.stringPlus("&cUnable to import module ", moduleName));
               } else {
                  List allModules = CollectionsKt.plus((Collection)CollectionsKt.listOf(module), (Iterable)dependencies);
                  Version modVersion = ExtensionsKt.toVersion("2.2.1");
                  Iterable $this$forEach$iv = (Iterable)allModules;
                  int $i$f$forEach = false;
                  Iterator var8 = $this$forEach$iv.iterator();

                  while(var8.hasNext()) {
                     Object element$iv = var8.next();
                     Module it = (Module)element$iv;
                     int var11 = false;
                     Version var10000 = it.getTargetModVersion();
                     if (var10000 != null) {
                        Version version = var10000;
                        if (version.getMajorVersion() < modVersion.getMajorVersion()) {
                           ModuleManager.INSTANCE.tryReportOldVersion(it);
                        }
                     }
                  }

                  String var10001 = module.getMetadata().getName();
                  if (var10001 == null) {
                     var10001 = module.getName();
                  }

                  ChatLib.chat(Intrinsics.stringPlus("&aSuccessfully imported ", var10001));
                  if (Config.INSTANCE.getModuleImportHelp() && module.getMetadata().getHelpMessage() != null) {
                     ChatLib.chat(StringsKt.take(String.valueOf(module.getMetadata().getHelpMessage()), 383));
                  }

               }
            }
         }));
      }

   }

   private final String getUsage() {
      return StringsKt.trimIndent("\n        &b&m" + ChatLib.getChatBreak$default((String)null, 1, (Object)null) + "\n        &c/ct load &7- &oReloads all of the ChatTriggers modules.\n        &c/ct import [module] &7- &oImports a module.\n        &c/ct delete [module] &7- &oDeletes a module.\n        &c/ct files &7- &oOpens the ChatTriggers folder.\n        &c/ct modules &7- &oOpens the modules GUI.\n        &c/ct console [language] &7- &oOpens the ChatTriggers console.\n        &c/ct simulate [message] &7- &oSimulates a received chat message.\n        &c/ct dump &7- &oDumps previous chat messages into chat.\n        &c/ct settings &7- &oOpens the ChatTriggers settings.\n        &c/ct &7- &oDisplays this help dialog.\n        &b&m" + ChatLib.getChatBreak$default((String)null, 1, (Object)null) + "\n    ");
   }

   private final void openFileLocation() {
      try {
         Desktop.getDesktop().open(new File("./config/ChatTriggers"));
      } catch (IOException var2) {
         ReferenceKt.printTraceToConsole$default((Throwable)var2, (Console)null, 1, (Object)null);
         ChatLib.chat("&cCould not open file location");
      }

   }

   private final void dump(String[] args) {
      if (args.length == 1) {
         dumpChat$default(this, 0, 1, (Object)null);
      } else {
         String var10000 = args[1].toLowerCase(Locale.ROOT);
         Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String).toLowerCase(Locale.ROOT)");
         String var2 = var10000;
         if (Intrinsics.areEqual(var2, "chat")) {
            if (args.length == 2) {
               dumpChat$default(this, 0, 1, (Object)null);
            } else {
               this.dumpChat(Integer.parseInt(args[2]));
            }
         } else if (Intrinsics.areEqual(var2, "actionbar")) {
            if (args.length == 2) {
               dumpActionBar$default(this, 0, 1, (Object)null);
            } else {
               this.dumpActionBar(Integer.parseInt(args[2]));
            }
         }

      }
   }

   private final void dumpChat(int lines) {
      this.dumpList(ClientListener.INSTANCE.getChatHistory(), lines);
   }

   // $FF: synthetic method
   static void dumpChat$default(CTCommand var0, int var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = 100;
      }

      var0.dumpChat(var1);
   }

   private final void dumpActionBar(int lines) {
      this.dumpList(ClientListener.INSTANCE.getActionBarHistory(), lines);
   }

   // $FF: synthetic method
   static void dumpActionBar$default(CTCommand var0, int var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = 100;
      }

      var0.dumpActionBar(var1);
   }

   private final void dumpList(List<String> messages, int lines) {
      this.clearOldDump();
      int toDump = lines;
      if (lines > messages.size()) {
         toDump = messages.size();
      }

      Object[] msg = new Object[]{Intrinsics.stringPlus("&6&m", ChatLib.getChatBreak$default((String)null, 1, (Object)null))};
      (new Message(msg)).setChatLineId(90123).chat();
      msg = null;
      int var5 = 0;

      while(var5 < toDump) {
         int i = var5++;
         String msg = ChatLib.replaceFormatting((String)messages.get(messages.size() - toDump + i));
         Object[] var7 = new Object[]{(new TextComponent(msg)).setClick("run_command", Intrinsics.stringPlus("/ct copy ", msg)).setHoverValue(ChatLib.addColor("&eClick here to copy this message.")).setFormatted(false)};
         (new Message(var7)).setFormatted(false).setChatLineId(90123 + i + 1).chat();
      }

      Object[] var9 = new Object[]{Intrinsics.stringPlus("&6&m", ChatLib.getChatBreak$default((String)null, 1, (Object)null))};
      (new Message(var9)).setChatLineId(90123 + lines + 1).chat();
      idFixedOffset = 90123 + lines + 1;
   }

   private final void clearOldDump() {
      if (idFixedOffset != -1) {
         while(idFixedOffset >= 90123) {
            int[] var1 = new int[1];
            int var2 = idFixedOffset;
            idFixedOffset = var2 + -1;
            var1[0] = var2;
            ChatLib.clearChat(var1);
         }

         idFixedOffset = -1;
      }
   }

   private final void copyArgsToClipboard(String[] args) {
      this.clearOldDump();
      byte var4 = 1;
      int var5 = args.length;
      String toCopy = ArraysKt.joinToString$default(ArraysKt.copyOfRange(args, var4, var5), (CharSequence)" ", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 62, (Object)null);
      Toolkit.getDefaultToolkit().getSystemClipboard().setContents((Transferable)(new StringSelection(toCopy)), (ClipboardOwner)null);
   }
}
