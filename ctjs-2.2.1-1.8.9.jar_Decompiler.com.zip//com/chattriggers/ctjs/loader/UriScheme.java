package com.chattriggers.ctjs.loader;

import com.chattriggers.ctjs.engine.module.ModuleManager;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.stream.Collectors;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.ModContainer;

public class UriScheme {
   private static final String PROTOCOL = "chattriggers://";
   private static final int PORT = 21965;
   private static final String QUOTE = "\"";

   public static void main(String[] args) {
      if (args.length < 1) {
         System.out.println("No URL found, aborting...");
      } else if (!args[0].startsWith("chattriggers://")) {
         System.out.println("URL found is not supported, aborting...");
         System.out.println(args[0]);
      } else {
         String url = args[0];
         System.out.println("Trying to work with URL: " + url);
         String module = url.substring("chattriggers://".length()).replace("/", "");

         try {
            connectWithSockets(module);
         } catch (Exception var4) {
            copyModuleIn(module);
         }

      }
   }

   public static void installUriScheme() {
      try {
         regAdd(" /f /ve /d " + quote("URL:chattriggers Protocol"));
         regAdd(" /f /v " + quote("URL Protocol") + " /d " + quote(""));
         ModContainer container = (ModContainer)Loader.instance().getIndexedModList().get("chattriggers");
         String modJar = container.getSource().getAbsolutePath();
         String sep = File.separator;
         String javaProgram = System.getProperty("java.home") + sep + "bin" + sep + "javaw.exe";
         String value = ("\"" + javaProgram + "\" -cp \"" + modJar + "\" com.chattriggers.ctjs.loader.UriScheme \"%1\"").replace("\"", "\\\"");
         regAdd("\\shell\\open\\command /f /ve /d \"" + value + "\"");
      } catch (Exception var5) {
         System.err.println("Unable to install chattriggers URI scheme, disregard if OS is not Windows");
      }

   }

   public static void createSocketListener() {
      (new Thread(UriScheme::socketListener, "CTJSSocketListener")).start();
   }

   private static String quote(String toQuote) {
      return "\"" + toQuote + "\"";
   }

   private static void regAdd(String args) throws IOException, InterruptedException {
      Process process = Runtime.getRuntime().exec("REG ADD HKCU\\Software\\Classes\\chattriggers" + args);
      if (process.waitFor() != 0) {
         throw new IOException("Error editing registry!");
      }
   }

   private static void socketListener() {
      try {
         ServerSocket serverSocket = new ServerSocket(21965);
         Throwable var1 = null;

         try {
            while(!Thread.interrupted()) {
               try {
                  Socket clientSocket = serverSocket.accept();
                  Throwable var3 = null;

                  try {
                     InputStream inputStream = clientSocket.getInputStream();
                     String module = (String)(new BufferedReader(new InputStreamReader(inputStream))).lines().collect(Collectors.joining("\n"));
                     ModuleManager.INSTANCE.importModule(module);
                  } catch (Throwable var31) {
                     var3 = var31;
                     throw var31;
                  } finally {
                     if (clientSocket != null) {
                        if (var3 != null) {
                           try {
                              clientSocket.close();
                           } catch (Throwable var30) {
                              var3.addSuppressed(var30);
                           }
                        } else {
                           clientSocket.close();
                        }
                     }

                  }
               } catch (Exception var33) {
                  var33.printStackTrace();
               }
            }
         } catch (Throwable var34) {
            var1 = var34;
            throw var34;
         } finally {
            if (serverSocket != null) {
               if (var1 != null) {
                  try {
                     serverSocket.close();
                  } catch (Throwable var29) {
                     var1.addSuppressed(var29);
                  }
               } else {
                  serverSocket.close();
               }
            }

         }
      } catch (IOException var36) {
         var36.printStackTrace();
      }

   }

   private static void connectWithSockets(String module) throws Exception {
      Socket socket = new Socket(InetAddress.getLocalHost(), 21965);
      socket.getOutputStream().write(module.getBytes());
      socket.close();
   }

   private static void copyModuleIn(String module) {
      System.out.println("Adding module named " + module + " to the to download list!");
      String dataFolder = System.getenv("APPDATA");
      File modulesDir = new File(dataFolder + "\\.minecraft\\config\\ChatTriggers\\modules");
      File toDownload = new File(modulesDir, ".to_download.txt");

      try {
         PrintWriter pw = new PrintWriter(new FileWriter(toDownload, true));
         pw.append(module).append(",");
         pw.close();
      } catch (Exception var5) {
         System.out.println("Error writing to file.");
      }

   }
}
