package com.chattriggers.ctjs.utils;

import com.chattriggers.ctjs.CTJS;
import gg.essential.vigilance.Vigilant;
import gg.essential.vigilance.data.Property;
import gg.essential.vigilance.data.PropertyCollector;
import gg.essential.vigilance.data.PropertyType;
import gg.essential.vigilance.data.SortingBehavior;
import java.awt.Color;
import java.io.File;
import java.lang.reflect.Field;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0010\u000e\n\u0002\b \bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u001e\u0010\u0003\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001e\u0010\t\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u0006\"\u0004\b\u000b\u0010\bR\u001e\u0010\f\u001a\u00020\r8\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u001e\u0010\u0012\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010\u0006\"\u0004\b\u0014\u0010\bR\u001e\u0010\u0015\u001a\u00020\r8\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u000f\"\u0004\b\u0017\u0010\u0011R\u001e\u0010\u0018\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\u0006\"\u0004\b\u001a\u0010\bR\u001e\u0010\u001b\u001a\u00020\u001c8\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u001e\"\u0004\b\u001f\u0010 R\u001e\u0010!\u001a\u00020\r8\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\"\u0010\u000f\"\u0004\b#\u0010\u0011R\u001e\u0010$\u001a\u00020%8\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b&\u0010'\"\u0004\b(\u0010)R\u001e\u0010*\u001a\u00020\r8\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b+\u0010\u000f\"\u0004\b,\u0010\u0011R\u001e\u0010-\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b.\u0010\u0006\"\u0004\b/\u0010\bR\u001e\u00100\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b1\u0010\u0006\"\u0004\b2\u0010\bR\u001e\u00103\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b4\u0010\u0006\"\u0004\b5\u0010\bR\u001e\u00106\u001a\u00020%8\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b7\u0010'\"\u0004\b8\u0010)R\u001e\u00109\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b:\u0010\u0006\"\u0004\b;\u0010\bR\u001e\u0010<\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b=\u0010\u0006\"\u0004\b>\u0010\bR\u001e\u0010?\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b@\u0010\u0006\"\u0004\bA\u0010\bR\u001e\u0010B\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bC\u0010\u0006\"\u0004\bD\u0010\b¨\u0006E"},
   d2 = {"Lcom/chattriggers/ctjs/utils/Config;", "Lgg/essential/vigilance/Vigilant;", "()V", "autoUpdateModules", "", "getAutoUpdateModules", "()Z", "setAutoUpdateModules", "(Z)V", "clearConsoleOnLoad", "getClearConsoleOnLoad", "setClearConsoleOnLoad", "consoleBackgroundColor", "Ljava/awt/Color;", "getConsoleBackgroundColor", "()Ljava/awt/Color;", "setConsoleBackgroundColor", "(Ljava/awt/Color;)V", "consoleErrorAndWarningColors", "getConsoleErrorAndWarningColors", "setConsoleErrorAndWarningColors", "consoleErrorColor", "getConsoleErrorColor", "setConsoleErrorColor", "consoleFiraCodeFont", "getConsoleFiraCodeFont", "setConsoleFiraCodeFont", "consoleFontSize", "", "getConsoleFontSize", "()I", "setConsoleFontSize", "(I)V", "consoleForegroundColor", "getConsoleForegroundColor", "setConsoleForegroundColor", "consoleTheme", "", "getConsoleTheme", "()Ljava/lang/String;", "setConsoleTheme", "(Ljava/lang/String;)V", "consoleWarningColor", "getConsoleWarningColor", "setConsoleWarningColor", "customTheme", "getCustomTheme", "setCustomTheme", "moduleChangelog", "getModuleChangelog", "setModuleChangelog", "moduleImportHelp", "getModuleImportHelp", "setModuleImportHelp", "modulesFolder", "getModulesFolder", "setModulesFolder", "openConsoleOnError", "getOpenConsoleOnError", "setOpenConsoleOnError", "printChatToConsole", "getPrintChatToConsole", "setPrintChatToConsole", "showUpdatesInChat", "getShowUpdatesInChat", "setShowUpdatesInChat", "threadedLoading", "getThreadedLoading", "setThreadedLoading", "ctjs"}
)
public final class Config extends Vigilant {
   @NotNull
   public static final Config INSTANCE = new Config();
   @Property(
      type = PropertyType.TEXT,
      name = "Modules Folders",
      category = "General",
      description = "Folder where CT modules are stored"
   )
   @NotNull
   private static String modulesFolder = "./config/ChatTriggers/modules";
   @Property(
      type = PropertyType.SWITCH,
      name = "Threaded loading",
      category = "General",
      description = "Load CT modules in a background thread"
   )
   private static boolean threadedLoading = true;
   @Property(
      type = PropertyType.SWITCH,
      name = "Show module help on import",
      category = "General",
      description = "If a module is imported and it has a help message, display it in chat"
   )
   private static boolean moduleImportHelp = true;
   @Property(
      type = PropertyType.SWITCH,
      name = "Show module changelog on update",
      category = "General",
      description = "If a module is updated and it has a changelog, display it in chat"
   )
   private static boolean moduleChangelog = true;
   @Property(
      type = PropertyType.SWITCH,
      name = "Print chat to console",
      category = "Console",
      description = "Prints the user's chat messages (with explicit color codes) to the general console for easy copy-pasting"
   )
   private static boolean printChatToConsole = true;
   @Property(
      type = PropertyType.SWITCH,
      name = "Show updates in chat",
      category = "General",
      description = "Show CT module import/update messages in the chat"
   )
   private static boolean showUpdatesInChat = true;
   @Property(
      type = PropertyType.SWITCH,
      name = "Auto-update modules",
      category = "General",
      description = "Check for and download module updates every time CT loads"
   )
   private static boolean autoUpdateModules = true;
   @Property(
      type = PropertyType.SWITCH,
      name = "Clear console on CT load",
      category = "Console"
   )
   private static boolean clearConsoleOnLoad = true;
   @Property(
      type = PropertyType.SWITCH,
      name = "Open console on error",
      category = "Console",
      description = "Opens the language-specific console if there is an error in a module"
   )
   private static boolean openConsoleOnError;
   @Property(
      type = PropertyType.SWITCH,
      name = "Use Fira Code font for console",
      category = "Console"
   )
   private static boolean consoleFiraCodeFont = true;
   @Property(
      type = PropertyType.NUMBER,
      name = "Console font size",
      category = "Console",
      min = 6,
      max = 32
   )
   private static int consoleFontSize = 9;
   @Property(
      type = PropertyType.SWITCH,
      name = "Use custom console theme",
      category = "Console"
   )
   private static boolean customTheme;
   @Property(
      type = PropertyType.TEXT,
      name = "Console custom theme",
      category = "Console"
   )
   @NotNull
   private static String consoleTheme = "default.dark";
   @Property(
      type = PropertyType.COLOR,
      name = "Console foreground color",
      category = "Console"
   )
   @NotNull
   private static Color consoleForegroundColor = new Color(208, 208, 208);
   @Property(
      type = PropertyType.COLOR,
      name = "Console background color",
      category = "Console"
   )
   @NotNull
   private static Color consoleBackgroundColor = new Color(21, 21, 21);
   @Property(
      type = PropertyType.SWITCH,
      name = "Use custom console colors for errors or warnings",
      category = "Console"
   )
   private static boolean consoleErrorAndWarningColors = true;
   @Property(
      type = PropertyType.COLOR,
      name = "Console error color",
      category = "Console"
   )
   @NotNull
   private static Color consoleErrorColor = new Color(225, 65, 73);
   @Property(
      type = PropertyType.COLOR,
      name = "Console warning color",
      category = "Console"
   )
   @NotNull
   private static Color consoleWarningColor = new Color(248, 191, 84);

   private Config() {
      super(new File(CTJS.INSTANCE.getConfigLocation(), "ChatTriggers.toml"), (String)null, (PropertyCollector)null, (SortingBehavior)CategorySorting.INSTANCE, 6, (DefaultConstructorMarker)null);
   }

   @NotNull
   public final String getModulesFolder() {
      return modulesFolder;
   }

   public final void setModulesFolder(@NotNull String var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      modulesFolder = var1;
   }

   public final boolean getThreadedLoading() {
      return threadedLoading;
   }

   public final void setThreadedLoading(boolean var1) {
      threadedLoading = var1;
   }

   public final boolean getModuleImportHelp() {
      return moduleImportHelp;
   }

   public final void setModuleImportHelp(boolean var1) {
      moduleImportHelp = var1;
   }

   public final boolean getModuleChangelog() {
      return moduleChangelog;
   }

   public final void setModuleChangelog(boolean var1) {
      moduleChangelog = var1;
   }

   public final boolean getPrintChatToConsole() {
      return printChatToConsole;
   }

   public final void setPrintChatToConsole(boolean var1) {
      printChatToConsole = var1;
   }

   public final boolean getShowUpdatesInChat() {
      return showUpdatesInChat;
   }

   public final void setShowUpdatesInChat(boolean var1) {
      showUpdatesInChat = var1;
   }

   public final boolean getAutoUpdateModules() {
      return autoUpdateModules;
   }

   public final void setAutoUpdateModules(boolean var1) {
      autoUpdateModules = var1;
   }

   public final boolean getClearConsoleOnLoad() {
      return clearConsoleOnLoad;
   }

   public final void setClearConsoleOnLoad(boolean var1) {
      clearConsoleOnLoad = var1;
   }

   public final boolean getOpenConsoleOnError() {
      return openConsoleOnError;
   }

   public final void setOpenConsoleOnError(boolean var1) {
      openConsoleOnError = var1;
   }

   public final boolean getConsoleFiraCodeFont() {
      return consoleFiraCodeFont;
   }

   public final void setConsoleFiraCodeFont(boolean var1) {
      consoleFiraCodeFont = var1;
   }

   public final int getConsoleFontSize() {
      return consoleFontSize;
   }

   public final void setConsoleFontSize(int var1) {
      consoleFontSize = var1;
   }

   public final boolean getCustomTheme() {
      return customTheme;
   }

   public final void setCustomTheme(boolean var1) {
      customTheme = var1;
   }

   @NotNull
   public final String getConsoleTheme() {
      return consoleTheme;
   }

   public final void setConsoleTheme(@NotNull String var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      consoleTheme = var1;
   }

   @NotNull
   public final Color getConsoleForegroundColor() {
      return consoleForegroundColor;
   }

   public final void setConsoleForegroundColor(@NotNull Color var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      consoleForegroundColor = var1;
   }

   @NotNull
   public final Color getConsoleBackgroundColor() {
      return consoleBackgroundColor;
   }

   public final void setConsoleBackgroundColor(@NotNull Color var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      consoleBackgroundColor = var1;
   }

   public final boolean getConsoleErrorAndWarningColors() {
      return consoleErrorAndWarningColors;
   }

   public final void setConsoleErrorAndWarningColors(boolean var1) {
      consoleErrorAndWarningColors = var1;
   }

   @NotNull
   public final Color getConsoleErrorColor() {
      return consoleErrorColor;
   }

   public final void setConsoleErrorColor(@NotNull Color var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      consoleErrorColor = var1;
   }

   @NotNull
   public final Color getConsoleWarningColor() {
      return consoleWarningColor;
   }

   public final void setConsoleWarningColor(@NotNull Color var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      consoleWarningColor = var1;
   }

   static {
      Config var10000 = INSTANCE;
      Field var0 = INSTANCE.getClass().getDeclaredField("consoleErrorColor");
      Intrinsics.checkNotNullExpressionValue(var0, "javaClass.getDeclaredField(\"consoleErrorColor\")");
      Field var10001 = var0;
      var0 = INSTANCE.getClass().getDeclaredField("consoleErrorAndWarningColors");
      Intrinsics.checkNotNullExpressionValue(var0, "javaClass.getDeclaredFie…leErrorAndWarningColors\")");
      var10000.addDependency(var10001, var0);
      var10000 = INSTANCE;
      var0 = INSTANCE.getClass().getDeclaredField("consoleWarningColor");
      Intrinsics.checkNotNullExpressionValue(var0, "javaClass.getDeclaredField(\"consoleWarningColor\")");
      var10001 = var0;
      var0 = INSTANCE.getClass().getDeclaredField("consoleErrorAndWarningColors");
      Intrinsics.checkNotNullExpressionValue(var0, "javaClass.getDeclaredFie…leErrorAndWarningColors\")");
      var10000.addDependency(var10001, var0);
   }
}
