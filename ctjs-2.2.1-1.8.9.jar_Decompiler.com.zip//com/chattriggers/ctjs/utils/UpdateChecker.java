package com.chattriggers.ctjs.utils;

import com.chattriggers.ctjs.CTJS;
import com.chattriggers.ctjs.ReferenceKt;
import com.chattriggers.ctjs.minecraft.libs.ChatLib;
import com.chattriggers.ctjs.minecraft.libs.FileLib;
import com.chattriggers.ctjs.minecraft.libs.renderer.Renderer;
import com.chattriggers.ctjs.minecraft.objects.message.Message;
import com.chattriggers.ctjs.minecraft.objects.message.TextComponent;
import com.chattriggers.ctjs.minecraft.wrappers.World;
import com.chattriggers.ctjs.utils.console.Console;
import com.chattriggers.ctjs.utils.kotlin.ExtensionsKt;
import com.fasterxml.jackson.core.Version;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
import net.minecraftforge.event.world.WorldEvent.Load;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0007\u001a\u00020\bJ\b\u0010\t\u001a\u00020\bH\u0002J\u0010\u0010\n\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\fH\u0007J\u0010\u0010\r\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\u000eH\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u000f"},
   d2 = {"Lcom/chattriggers/ctjs/utils/UpdateChecker;", "", "()V", "updateAvailable", "", "warned", "worldLoaded", "drawUpdateMessage", "", "getUpdate", "renderOverlay", "event", "Lnet/minecraftforge/client/event/RenderGameOverlayEvent$Pre;", "worldLoad", "Lnet/minecraftforge/event/world/WorldEvent$Load;", "ctjs"}
)
public final class UpdateChecker {
   @NotNull
   public static final UpdateChecker INSTANCE = new UpdateChecker();
   private static boolean worldLoaded;
   private static boolean updateAvailable;
   private static boolean warned;

   private UpdateChecker() {
   }

   private final void getUpdate() {
      Map versions = (Map)CTJS.INSTANCE.getGson().fromJson(FileLib.getUrlContent$default("https://www.chattriggers.com/api/versions", (String)null, 2, (Object)null), (new TypeToken<Map<String, ? extends List<? extends String>>>() {
      }).getType());
      Intrinsics.checkNotNullExpressionValue(versions, "versions");
      int $i$f$flatMap = false;
      Collection destination$iv$iv = (Collection)(new ArrayList());
      int $i$f$flatMapTo = false;
      Iterator var9 = versions.entrySet().iterator();

      while(var9.hasNext()) {
         Entry element$iv$iv = (Entry)var9.next();
         Entry entry = element$iv$iv;
         int var12 = false;
         Iterable $this$map$iv = (Iterable)element$iv$iv.getValue();
         int $i$f$map = false;
         Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
         int $i$f$mapTo = false;
         Iterator var18 = $this$map$iv.iterator();

         while(var18.hasNext()) {
            Object item$iv$iv = var18.next();
            String it = (String)item$iv$iv;
            int var22 = false;
            destination$iv$iv.add(ExtensionsKt.toVersion((String)entry.getKey() + '.' + it));
         }

         Iterable list$iv$iv = (Iterable)((List)destination$iv$iv);
         CollectionsKt.addAll(destination$iv$iv, list$iv$iv);
      }

      Version var3 = (Version)CollectionsKt.maxOrNull((Iterable)((List)destination$iv$iv));
      if (var3 != null) {
         updateAvailable = var3.compareTo(ExtensionsKt.toVersion("2.2.1")) > 0;
      }
   }

   @SubscribeEvent
   public final void worldLoad(@NotNull Load event) {
      Intrinsics.checkNotNullParameter(event, "event");
      worldLoaded = true;
   }

   @SubscribeEvent
   public final void renderOverlay(@NotNull Pre event) {
      Intrinsics.checkNotNullParameter(event, "event");
      if (worldLoaded) {
         worldLoaded = false;
         if (updateAvailable && !warned) {
            World.playSound("note.bass", 1000.0F, 1.0F);
            Object[] var2 = new Object[]{Intrinsics.stringPlus("&c&m", ChatLib.getChatBreak("-")), "\n", "&cChatTriggers requires an update to work properly!", "\n", (new TextComponent("&a[Download]")).setClick("open_url", "https://www.chattriggers.com/#download"), " ", (new TextComponent("&e[Changelog]")).setClick("open_url", "https://github.com/ChatTriggers/ChatTriggers/releases"), "\n", Intrinsics.stringPlus("&c&m", ChatLib.getChatBreak("-"))};
            (new Message(var2)).chat();
            warned = true;
         }
      }
   }

   public final void drawUpdateMessage() {
      if (updateAvailable) {
         GlStateManager.func_179094_E();
         Renderer.getFontRenderer().func_175065_a(ChatLib.addColor("&cChatTriggers requires an update to work properly!"), 2.0F, 2.0F, -1, false);
         GlStateManager.func_179121_F();
      }
   }

   static {
      try {
         INSTANCE.getUpdate();
      } catch (Exception var1) {
         ReferenceKt.printTraceToConsole$default((Throwable)var1, (Console)null, 1, (Object)null);
      }

      UpdateChecker var10000 = INSTANCE;
      warned = !Config.INSTANCE.getShowUpdatesInChat();
   }
}
