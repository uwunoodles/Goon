package com.chattriggers.ctjs.utils.kotlin;

import com.fasterxml.jackson.core.Version;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.event.ClickEvent;
import net.minecraft.event.HoverEvent;
import net.minecraft.util.ChatStyle;
import net.minecraft.util.IChatComponent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mozilla.javascript.NativeObject;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000X\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0004\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0016\u0010\u0000\u001a\n\u0018\u00010\u0001j\u0004\u0018\u0001`\u0002*\u00060\u0003j\u0002`\u0004\u001a\u0016\u0010\u0005\u001a\n\u0018\u00010\u0006j\u0004\u0018\u0001`\u0007*\u00060\u0003j\u0002`\u0004\u001a\u001c\u0010\b\u001a\u00020\t*\u0004\u0018\u00010\n2\u0006\u0010\u000b\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\r\u001a\u0012\u0010\u000e\u001a\u00060\u000fj\u0002`\u0010*\u00060\u0011j\u0002`\u0012\u001a\u0012\u0010\u0013\u001a\u00060\u0003j\u0002`\u0004*\u00060\u0014j\u0002`\u0015\u001a\u0015\u0010\u0016\u001a\u00020\t*\u00020\t2\u0006\u0010\u0016\u001a\u00020\u0017H\u0086\u0002\u001a\n\u0010\u0018\u001a\u00020\u0019*\u00020\t¨\u0006\u001a"},
   d2 = {"getClick", "Lnet/minecraft/event/ClickEvent;", "Lcom/chattriggers/ctjs/utils/kotlin/MCTextClickEvent;", "Lnet/minecraft/util/ChatStyle;", "Lcom/chattriggers/ctjs/utils/kotlin/MCTextStyle;", "getHover", "Lnet/minecraft/event/HoverEvent;", "Lcom/chattriggers/ctjs/utils/kotlin/MCTextHoverEvent;", "getOption", "", "Lorg/mozilla/javascript/NativeObject;", "key", "default", "", "getRenderer", "Lnet/minecraft/client/renderer/WorldRenderer;", "Lcom/chattriggers/ctjs/utils/kotlin/MCWorldRenderer;", "Lnet/minecraft/client/renderer/Tessellator;", "Lcom/chattriggers/ctjs/utils/kotlin/MCTessellator;", "getStyling", "Lnet/minecraft/util/IChatComponent;", "Lcom/chattriggers/ctjs/utils/kotlin/MCITextComponent;", "times", "", "toVersion", "Lcom/fasterxml/jackson/core/Version;", "ctjs"}
)
public final class ExtensionsKt {
   @NotNull
   public static final ChatStyle getStyling(@NotNull IChatComponent $this$getStyling) {
      Intrinsics.checkNotNullParameter($this$getStyling, "<this>");
      ChatStyle var1 = $this$getStyling.func_150256_b();
      Intrinsics.checkNotNullExpressionValue(var1, "this.chatStyle");
      return var1;
   }

   @Nullable
   public static final ClickEvent getClick(@NotNull ChatStyle $this$getClick) {
      Intrinsics.checkNotNullParameter($this$getClick, "<this>");
      return $this$getClick.func_150235_h();
   }

   @Nullable
   public static final HoverEvent getHover(@NotNull ChatStyle $this$getHover) {
      Intrinsics.checkNotNullParameter($this$getHover, "<this>");
      return $this$getHover.func_150210_i();
   }

   @NotNull
   public static final WorldRenderer getRenderer(@NotNull Tessellator $this$getRenderer) {
      Intrinsics.checkNotNullParameter($this$getRenderer, "<this>");
      WorldRenderer var1 = $this$getRenderer.func_178180_c();
      Intrinsics.checkNotNullExpressionValue(var1, "worldRenderer");
      return var1;
   }

   @NotNull
   public static final String times(@NotNull String $this$times, @NotNull Number times) {
      Intrinsics.checkNotNullParameter($this$times, "<this>");
      Intrinsics.checkNotNullParameter(times, "times");
      StringBuilder stringBuilder = new StringBuilder();
      int var3 = 0;
      int var4 = times.intValue();

      while(var3 < var4) {
         ++var3;
         stringBuilder.append($this$times);
      }

      String var6 = stringBuilder.toString();
      Intrinsics.checkNotNullExpressionValue(var6, "stringBuilder.toString()");
      return var6;
   }

   @NotNull
   public static final Version toVersion(@NotNull String $this$toVersion) {
      Intrinsics.checkNotNullParameter($this$toVersion, "<this>");
      CharSequence var10000 = (CharSequence)$this$toVersion;
      String[] var2 = new String[]{"."};
      Iterable $this$map$iv = (Iterable)StringsKt.split$default(var10000, var2, false, 0, 6, (Object)null);
      int $i$f$map = false;
      Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
      int $i$f$mapTo = false;
      Iterator var7 = $this$map$iv.iterator();

      while(var7.hasNext()) {
         Object item$iv$iv = var7.next();
         String p0 = (String)item$iv$iv;
         int var10 = false;
         destination$iv$iv.add(Integer.parseInt(p0));
      }

      List split = (List)destination$iv$iv;
      Integer var10002 = (Integer)CollectionsKt.getOrNull(split, 0);
      int var13 = var10002 == null ? 0 : var10002;
      Integer var10003 = (Integer)CollectionsKt.getOrNull(split, 1);
      int var14 = var10003 == null ? 0 : var10003;
      Integer var10004 = (Integer)CollectionsKt.getOrNull(split, 2);
      return new Version(var13, var14, var10004 == null ? 0 : var10004, (String)null, (String)null, (String)null);
   }

   @NotNull
   public static final String getOption(@Nullable NativeObject $this$getOption, @NotNull String key, @NotNull Object var2) {
      Intrinsics.checkNotNullParameter(key, "key");
      Intrinsics.checkNotNullParameter(var2, "default");
      Object var10000;
      if ($this$getOption == null) {
         var10000 = var2;
      } else {
         var10000 = $this$getOption.get(key);
         if (var10000 == null) {
            var10000 = var2;
         }
      }

      return var10000.toString();
   }
}
