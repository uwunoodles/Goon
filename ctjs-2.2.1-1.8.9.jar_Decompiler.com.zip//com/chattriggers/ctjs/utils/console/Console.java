package com.chattriggers.ctjs.utils.console;

import com.chattriggers.ctjs.Reference;
import com.chattriggers.ctjs.engine.ILoader;
import com.chattriggers.ctjs.engine.langs.Lang;
import com.chattriggers.ctjs.utils.Config;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.Insets;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.text.Caret;
import javax.swing.text.DefaultCaret;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.Theme;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000h\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010#\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 '2\u00020\u0001:\u0001'B\u000f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\u0002\u0010\u0004J\u0006\u0010\u0019\u001a\u00020\u001aJ\u0010\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u001c\u001a\u00020\u001dH\u0002J\u000e\u0010\u001e\u001a\u00020\u001a2\u0006\u0010\u001c\u001a\u00020\u001dJ0\u0010\u001f\u001a\u00020\u001a2\u0006\u0010 \u001a\u00020\u00012\b\b\u0002\u0010!\u001a\u00020\"2\b\b\u0002\u0010#\u001a\u00020\f2\n\b\u0002\u0010$\u001a\u0004\u0018\u00010%H\u0007J\u0006\u0010&\u001a\u00020\u001aR\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u0015\u001a\u00020\u0016¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018¨\u0006("},
   d2 = {"Lcom/chattriggers/ctjs/utils/console/Console;", "", "loader", "Lcom/chattriggers/ctjs/engine/ILoader;", "(Lcom/chattriggers/ctjs/engine/ILoader;)V", "components", "", "Ljava/awt/Component;", "frame", "Ljavax/swing/JFrame;", "history", "", "", "historyOffset", "", "inputField", "Lorg/fife/ui/rsyntaxtextarea/RSyntaxTextArea;", "getLoader", "()Lcom/chattriggers/ctjs/engine/ILoader;", "textArea", "Ljavax/swing/JTextPane;", "writer", "Lcom/chattriggers/ctjs/utils/console/TextAreaWriter;", "getWriter", "()Lcom/chattriggers/ctjs/utils/console/TextAreaWriter;", "clearConsole", "", "printErrorWithColor", "error", "", "printStackTrace", "println", "obj", "logType", "Lcom/chattriggers/ctjs/utils/console/LogType;", "end", "customColor", "Ljava/awt/Color;", "showConsole", "Companion", "ctjs"}
)
public final class Console {
   @NotNull
   public static final Console.Companion Companion = new Console.Companion((DefaultConstructorMarker)null);
   @Nullable
   private final ILoader loader;
   @NotNull
   private final JFrame frame;
   @NotNull
   private final JTextPane textArea;
   @NotNull
   private final RSyntaxTextArea inputField;
   @NotNull
   private final Set<Component> components;
   @NotNull
   private final List<String> history;
   private int historyOffset;
   @NotNull
   private final TextAreaWriter writer;
   @NotNull
   private static final Font FIRA_FONT;

   public Console(@Nullable ILoader loader) {
      this.loader = loader;
      JFrame var10001 = new JFrame;
      StringBuilder var10003 = (new StringBuilder()).append("ChatTriggers 2.2.1 ");
      ILoader var10004 = this.loader;
      String var11;
      if (var10004 == null) {
         var11 = "Default";
      } else {
         Lang var12 = var10004.getLanguage();
         if (var12 == null) {
            var11 = "Default";
         } else {
            var11 = var12.getLangName();
            if (var11 == null) {
               var11 = "Default";
            }
         }
      }

      var10001.<init>(var10003.append(var11).append(" Console").toString());
      this.frame = var10001;
      this.textArea = new JTextPane();
      RSyntaxTextArea var2 = new RSyntaxTextArea(5, 1);
      int var4 = false;
      ILoader var8 = this.getLoader();
      String var9;
      if (var8 == null) {
         var9 = "text/plain";
      } else {
         Lang var10 = var8.getLanguage();
         if (var10 == null) {
            var9 = "text/plain";
         } else {
            var9 = var10.getSyntaxStyle();
            if (var9 == null) {
               var9 = "text/plain";
            }
         }
      }

      var2.setSyntaxEditingStyle(var9);
      Theme.load(var2.getClass().getResourceAsStream("/org/fife/ui/rsyntaxtextarea/themes/dark.xml")).apply(var2);
      var2.setMargin(new Insets(5, 5, 5, 5));
      var2.setCodeFoldingEnabled(true);
      this.inputField = var2;
      Component[] var6 = new Component[]{(Component)this.textArea};
      this.components = SetsKt.mutableSetOf(var6);
      this.history = (List)(new ArrayList());
      this.writer = new TextAreaWriter(this.textArea);
      this.frame.setDefaultCloseOperation(1);
      this.textArea.setEditable(false);
      this.textArea.setMargin(new Insets(5, 5, 5, 5));
      this.textArea.setAutoscrolls(true);
      Caret var10000 = this.textArea.getCaret();
      if (var10000 == null) {
         throw new NullPointerException("null cannot be cast to non-null type javax.swing.text.DefaultCaret");
      } else {
         DefaultCaret caret = (DefaultCaret)var10000;
         caret.setUpdatePolicy(2);
         this.inputField.addKeyListener((KeyListener)(new KeyListener() {
            public void keyTyped(@NotNull KeyEvent e) {
               Intrinsics.checkNotNullParameter(e, "e");
            }

            public void keyPressed(@NotNull KeyEvent e) {
               Intrinsics.checkNotNullParameter(e, "e");
            }

            public void keyReleased(@NotNull KeyEvent e) {
               Intrinsics.checkNotNullParameter(e, "e");
               if (e.isControlDown()) {
                  Console var2;
                  int var3;
                  String command;
                  switch(e.getKeyCode()) {
                  case 10:
                     command = Console.this.inputField.getText();
                     Console.this.inputField.setText("");
                     List var10000 = Console.this.history;
                     Intrinsics.checkNotNullExpressionValue(command, "command");
                     var10000.add(command);
                     Console.this.historyOffset = 0;
                     if (Intrinsics.areEqual(command, "help")) {
                        TextAreaWriter.println$default(Console.this.getWriter(), "-------------- ChatTriggers Console Help --------------\n Shortcuts:\n  Control + Enter: Run code in the textbox\n  Control + UP / DOWN: Cycle between ran code history\n  Control + L: Clear console\n  Control + R: Reload ChatTriggers\n-------------------------------------------------------", (LogType)null, (String)null, (Color)null, 14, (Object)null);
                     } else {
                        TextAreaWriter var10 = Console.this.getWriter();
                        String var10002 = StringsKt.prependIndent(command, "    > ").substring(6);
                        Intrinsics.checkNotNullExpressionValue(var10002, "this as java.lang.String).substring(startIndex)");
                        TextAreaWriter.println$default(var10, Intrinsics.stringPlus("eval> ", var10002), (LogType)null, (String)null, (Color)null, 14, (Object)null);

                        try {
                           var10 = Console.this.getWriter();
                           ILoader var10001 = Console.this.getLoader();
                           String var11 = var10001 == null ? null : var10001.eval(command);
                           if (var11 == null) {
                              return;
                           }

                           TextAreaWriter.println$default(var10, var11, (LogType)null, (String)null, (Color)null, 14, (Object)null);
                        } catch (Throwable var7) {
                           Console.this.printStackTrace(var7);
                        }
                     }
                     break;
                  case 38:
                     var2 = Console.this;
                     var3 = var2.historyOffset;
                     var2.historyOffset = var3 + 1;

                     try {
                        command = (String)Console.this.history.get(Console.this.history.size() - Console.this.historyOffset);
                        Console.this.inputField.setText(command);
                     } catch (Exception var6) {
                        Console var9 = Console.this;
                        int var4 = var9.historyOffset;
                        var9.historyOffset = var4 + -1;
                     }
                     break;
                  case 40:
                     var2 = Console.this;
                     var3 = var2.historyOffset;
                     var2.historyOffset = var3 + -1;
                     if (Console.this.historyOffset < 0) {
                        Console.this.historyOffset = 0;
                     }

                     try {
                        command = (String)Console.this.history.get(Console.this.history.size() - Console.this.historyOffset);
                        Console.this.inputField.setText(command);
                     } catch (Exception var5) {
                        Console.this.historyOffset = 0;
                        Console.this.inputField.setText("");
                     }
                     break;
                  case 76:
                     Console.this.clearConsole();
                     break;
                  case 82:
                     Reference.loadCT();
                  }

               }
            }
         }));
         this.frame.add((Component)(new JScrollPane((Component)this.textArea)));
         this.frame.add((Component)this.inputField, "South");
         this.frame.pack();
         this.frame.setVisible(false);
         this.frame.setSize(800, 600);
      }
   }

   @Nullable
   public final ILoader getLoader() {
      return this.loader;
   }

   @NotNull
   public final TextAreaWriter getWriter() {
      return this.writer;
   }

   public final void clearConsole() {
      SwingUtilities.invokeLater(Console::clearConsole$lambda-1);
   }

   @JvmOverloads
   public final void println(@NotNull Object obj, @NotNull LogType logType, @NotNull String end, @Nullable Color customColor) {
      Intrinsics.checkNotNullParameter(obj, "obj");
      Intrinsics.checkNotNullParameter(logType, "logType");
      Intrinsics.checkNotNullParameter(end, "end");
      SwingUtilities.invokeLater(Console::println$lambda-2);
   }

   // $FF: synthetic method
   public static void println$default(Console var0, Object var1, LogType var2, String var3, Color var4, int var5, Object var6) {
      if ((var5 & 2) != 0) {
         var2 = LogType.INFO;
      }

      if ((var5 & 4) != 0) {
         var3 = "\n";
      }

      if ((var5 & 8) != 0) {
         var4 = null;
      }

      var0.println(var1, var2, var3, var4);
   }

   public final void printStackTrace(@NotNull Throwable error) {
      Intrinsics.checkNotNullParameter(error, "error");
      SwingUtilities.invokeLater(Console::printStackTrace$lambda-5);
   }

   private final void printErrorWithColor(Throwable error) {
      StringWriter sw = new StringWriter();
      error.printStackTrace(new PrintWriter((Writer)sw));
      String var4 = sw.toString();
      Intrinsics.checkNotNullExpressionValue(var4, "sw.toString()");
      TextAreaWriter.println$default(this.writer, var4, LogType.ERROR, (String)null, (Color)null, 12, (Object)null);
   }

   public final void showConsole() {
      this.frame.setVisible(true);
      Color bg = null;
      Color fg = null;
      if (Config.INSTANCE.getCustomTheme()) {
         bg = Config.INSTANCE.getConsoleBackgroundColor();
         fg = Config.INSTANCE.getConsoleForegroundColor();
      } else {
         label83: {
            String var3 = Config.INSTANCE.getConsoleTheme();
            switch(var3.hashCode()) {
            case -1240095096:
               if (var3.equals("gotham")) {
                  bg = new Color(10, 15, 20);
                  fg = new Color(152, 209, 206);
                  break label83;
               }
               break;
            case -1202757124:
               if (var3.equals("hybrid")) {
                  bg = new Color(29, 31, 33);
                  fg = new Color(197, 200, 198);
                  break label83;
               }
               break;
            case -724088889:
               if (var3.equals("3024.light")) {
                  bg = new Color(247, 247, 247);
                  fg = new Color(74, 69, 67);
                  break label83;
               }
               break;
            case -695987453:
               if (var3.equals("default.dark")) {
                  bg = new Color(41, 49, 52);
                  fg = new Color(208, 208, 208);
                  break label83;
               }
               break;
            case -411115349:
               if (var3.equals("atelierforest.dark")) {
                  bg = new Color(28, 32, 35);
                  fg = new Color(199, 204, 209);
                  break label83;
               }
               break;
            case 112785:
               if (var3.equals("red")) {
                  bg = new Color(26, 9, 11);
                  fg = new Color(231, 210, 212);
                  break label83;
               }
               break;
            case 2993847:
               if (var3.equals("aids")) {
                  bg = new Color(251, 251, 28);
                  fg = new Color(192, 20, 214);
                  break label83;
               }
               break;
            case 3027034:
               if (var3.equals("blue")) {
                  bg = new Color(15, 18, 32);
                  fg = new Color(221, 223, 235);
                  break label83;
               }
               break;
            case 64343424:
               if (var3.equals("ashes.dark")) {
                  bg = new Color(28, 32, 35);
                  fg = new Color(199, 204, 209);
                  break label83;
               }
               break;
            case 65042959:
               if (var3.equals("isotope.dark")) {
                  bg = new Color(0, 0, 0);
                  fg = new Color(208, 208, 208);
                  break label83;
               }
               break;
            case 98619139:
               if (var3.equals("green")) {
                  bg = new Color(6, 10, 10);
                  fg = new Color(47, 227, 149);
                  break label83;
               }
               break;
            case 109519257:
               if (var3.equals("slate")) {
                  bg = new Color(33, 36, 41);
                  fg = new Color(193, 199, 208);
                  break label83;
               }
               break;
            case 800203171:
               if (var3.equals("codeschool.dark")) {
                  bg = new Color(22, 27, 29);
                  fg = new Color(126, 162, 180);
                  break label83;
               }
               break;
            case 1141962883:
               if (var3.equals("chalk.light")) {
                  bg = new Color(245, 245, 245);
                  fg = new Color(48, 48, 48);
                  break label83;
               }
            }

            bg = new Color(21, 21, 21);
            fg = new Color(208, 208, 208);
         }
      }

      Iterator var5 = this.components.iterator();

      while(var5.hasNext()) {
         Component comp = (Component)var5.next();
         comp.setBackground(bg);
         comp.setForeground(fg);
      }

      this.frame.toFront();
      this.frame.repaint();
      Font chosenFont = Config.INSTANCE.getConsoleFiraCodeFont() ? FIRA_FONT.deriveFont((float)Config.INSTANCE.getConsoleFontSize()) : (new Font("DejaVu Sans Mono", 0, 15)).deriveFont((float)Config.INSTANCE.getConsoleFontSize());
      this.textArea.setFont(chosenFont);
      this.inputField.setFont(chosenFont);
      this.frame.toFront();
      this.frame.repaint();
   }

   @JvmOverloads
   public final void println(@NotNull Object obj, @NotNull LogType logType, @NotNull String end) {
      Intrinsics.checkNotNullParameter(obj, "obj");
      Intrinsics.checkNotNullParameter(logType, "logType");
      Intrinsics.checkNotNullParameter(end, "end");
      println$default(this, obj, logType, end, (Color)null, 8, (Object)null);
   }

   @JvmOverloads
   public final void println(@NotNull Object obj, @NotNull LogType logType) {
      Intrinsics.checkNotNullParameter(obj, "obj");
      Intrinsics.checkNotNullParameter(logType, "logType");
      println$default(this, obj, logType, (String)null, (Color)null, 12, (Object)null);
   }

   @JvmOverloads
   public final void println(@NotNull Object obj) {
      Intrinsics.checkNotNullParameter(obj, "obj");
      println$default(this, obj, (LogType)null, (String)null, (Color)null, 14, (Object)null);
   }

   private static final void clearConsole$lambda_1/* $FF was: clearConsole$lambda-1*/(Console this$0) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.writer.clear();
   }

   private static final void println$lambda_2/* $FF was: println$lambda-2*/(Console this$0, Object $obj, LogType $logType, String $end, Color $customColor) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNullParameter($obj, "$obj");
      Intrinsics.checkNotNullParameter($logType, "$logType");
      Intrinsics.checkNotNullParameter($end, "$end");

      try {
         this$0.writer.println($obj.toString(), $logType, $end, $customColor);
      } catch (Exception var6) {
         this$0.println($obj.toString(), $logType, $end, $customColor);
      }

   }

   private static final void printStackTrace$lambda_5/* $FF was: printStackTrace$lambda-5*/(Console this$0, Throwable $error) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNullParameter($error, "$error");

      try {
         if (Config.INSTANCE.getOpenConsoleOnError()) {
            this$0.showConsole();
         }

         StackTraceElement[] var3 = $error.getStackTrace();
         Intrinsics.checkNotNullExpressionValue(var3, "error.stackTrace");
         Object[] $this$indexOfFirst$iv = (Object[])var3;
         int $i$f$toTypedArray = false;
         int index$iv = 0;

         String var26;
         int var27;
         label63: {
            for(int var6 = $this$indexOfFirst$iv.length; index$iv < var6; ++index$iv) {
               StackTraceElement it = (StackTraceElement)$this$indexOfFirst$iv[index$iv];
               int var8 = false;
               boolean var10000;
               if (it == null) {
                  var10000 = false;
               } else {
                  String var10 = it.getFileName();
                  if (var10 == null) {
                     var10000 = false;
                  } else {
                     var26 = var10.toLowerCase(Locale.ROOT);
                     Intrinsics.checkNotNullExpressionValue(var26, "this as java.lang.String).toLowerCase(Locale.ROOT)");
                     if (var26 == null) {
                        var10000 = false;
                     } else {
                        boolean var12 = StringsKt.contains$default((CharSequence)var26, (CharSequence)"jsloader", false, 2, (Object)null);
                        var10000 = var12;
                     }
                  }
               }

               if (var10000) {
                  var27 = index$iv;
                  break label63;
               }
            }

            var27 = -1;
         }

         int index = var27;
         var3 = $error.getStackTrace();
         Intrinsics.checkNotNullExpressionValue(var3, "error.stackTrace");
         Iterable $this$map$iv = (Iterable)ArraysKt.dropLast((Object[])var3, $error.getStackTrace().length - index - 1);
         $i$f$toTypedArray = false;
         Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
         int $i$f$mapTo = false;

         StackTraceElement var29;
         for(Iterator var23 = $this$map$iv.iterator(); var23.hasNext(); destination$iv$iv.add(var29)) {
            Object item$iv$iv = var23.next();
            StackTraceElement it = (StackTraceElement)item$iv$iv;
            int var11 = false;
            var26 = it.getFileName();
            Integer var28 = var26 == null ? null : StringsKt.indexOf$default((CharSequence)var26, "ChatTriggers/modules/", 0, false, 6, (Object)null);
            if (var28 == null) {
               var29 = it;
            } else {
               int fileNameIndex = var28;
               String var25 = it.getClassName();
               Intrinsics.checkNotNullExpressionValue(var25, "it.className");
               int classNameIndex = StringsKt.indexOf$default((CharSequence)var25, "ChatTriggers_modules_", 0, false, 6, (Object)null);
               if (fileNameIndex != -1) {
                  var25 = it.getClassName();
                  Intrinsics.checkNotNullExpressionValue(var25, "it.className");
                  String var10002 = var25.substring(classNameIndex + 21);
                  Intrinsics.checkNotNullExpressionValue(var10002, "this as java.lang.String).substring(startIndex)");
                  String var10003 = it.getMethodName();
                  String var10004 = it.getFileName();
                  Intrinsics.checkNotNull(var10004);
                  var10004 = var10004.substring(fileNameIndex + 21);
                  Intrinsics.checkNotNullExpressionValue(var10004, "this as java.lang.String).substring(startIndex)");
                  var29 = new StackTraceElement(var10002, var10003, var10004, it.getLineNumber());
               } else {
                  var29 = it;
               }
            }
         }

         Collection $this$toTypedArray$iv = (Collection)((List)destination$iv$iv);
         $i$f$toTypedArray = false;
         Object[] var10001 = $this$toTypedArray$iv.toArray(new StackTraceElement[0]);
         Intrinsics.checkNotNull(var10001, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
         $error.setStackTrace((StackTraceElement[])var10001);
         this$0.printErrorWithColor($error);
      } catch (Throwable var17) {
         $error.printStackTrace();
      }

   }

   static {
      byte var10000 = 0;
      String var10001 = System.getProperty("ct.firaFile", (String)null);
      FileInputStream var6;
      if (var10001 == null) {
         var6 = null;
      } else {
         String it = var10001;
         byte var4 = 0;
         int var3 = false;
         FileInputStream var5 = new FileInputStream(new File(it));
         var10000 = var4;
         var6 = var5;
      }

      FileInputStream var1 = var6;
      Font var0 = Font.createFont(var10000, var1 == null ? Companion.getClass().getResourceAsStream("/FiraCode-Regular.otf") : (InputStream)var1).deriveFont(9.0F);
      Intrinsics.checkNotNullExpressionValue(var0, "createFont(\n            …\n        ).deriveFont(9f)");
      FIRA_FONT = var0;
      GraphicsEnvironment.getLocalGraphicsEnvironment().registerFont(FIRA_FONT);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"},
      d2 = {"Lcom/chattriggers/ctjs/utils/console/Console$Companion;", "", "()V", "FIRA_FONT", "Ljava/awt/Font;", "getFIRA_FONT", "()Ljava/awt/Font;", "ctjs"}
   )
   public static final class Companion {
      private Companion() {
      }

      @NotNull
      public final Font getFIRA_FONT() {
         return Console.FIRA_FONT;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
