package com.chattriggers.ctjs.utils.console;

import com.chattriggers.ctjs.utils.Config;
import java.awt.Color;
import java.io.PrintWriter;
import java.io.Writer;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0019\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0006\u0010\r\u001a\u00020\u000eJ\b\u0010\u000f\u001a\u00020\u000eH\u0016J\b\u0010\u0010\u001a\u00020\u000eH\u0016J0\u0010\u0011\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u00132\b\b\u0002\u0010\u0014\u001a\u00020\u00062\b\b\u0002\u0010\u0015\u001a\u00020\u00162\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\bH\u0007J \u0010\u0017\u001a\u00020\u000e2\u0006\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001bH\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001d"},
   d2 = {"Lcom/chattriggers/ctjs/utils/console/TextAreaWriter;", "Ljava/io/Writer;", "textArea", "Ljavax/swing/JTextPane;", "(Ljavax/swing/JTextPane;)V", "currentLogType", "Lcom/chattriggers/ctjs/utils/console/LogType;", "customColor", "Ljava/awt/Color;", "printWriter", "Ljava/io/PrintWriter;", "getPrintWriter", "()Ljava/io/PrintWriter;", "clear", "", "close", "flush", "println", "s", "", "logType", "end", "", "write", "cbuf", "", "off", "", "len", "ctjs"}
)
public final class TextAreaWriter extends Writer {
   @NotNull
   private final JTextPane textArea;
   @NotNull
   private final PrintWriter printWriter;
   @NotNull
   private LogType currentLogType;
   @Nullable
   private Color customColor;

   public TextAreaWriter(@NotNull JTextPane textArea) {
      Intrinsics.checkNotNullParameter(textArea, "textArea");
      super();
      this.textArea = textArea;
      this.printWriter = new PrintWriter((Writer)this);
      this.currentLogType = LogType.INFO;
   }

   @NotNull
   public final PrintWriter getPrintWriter() {
      return this.printWriter;
   }

   public void write(@NotNull char[] cbuf, int off, int len) {
      Intrinsics.checkNotNullParameter(cbuf, "cbuf");
      String s = new String(cbuf, off, len);
      StyleContext var6 = StyleContext.getDefaultStyleContext();
      Intrinsics.checkNotNullExpressionValue(var6, "getDefaultStyleContext()");
      StyleContext sc = var6;
      Color var7 = this.customColor;
      Color var10000;
      if (var7 == null) {
         switch(TextAreaWriter.WhenMappings.$EnumSwitchMapping$0[this.currentLogType.ordinal()]) {
         case 1:
            var10000 = Config.INSTANCE.getConsoleForegroundColor();
            break;
         case 2:
            var10000 = Config.INSTANCE.getConsoleWarningColor();
            break;
         case 3:
            var10000 = Config.INSTANCE.getConsoleErrorColor();
            break;
         default:
            throw new NoWhenBranchMatchedException();
         }
      } else {
         var10000 = var7;
      }

      Color color = var10000;
      AttributeSet var8 = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, color);
      Intrinsics.checkNotNullExpressionValue(var8, "sc.addAttribute(\n       …         color,\n        )");
      this.textArea.getDocument().insertString(this.textArea.getDocument().getLength(), s, var8);
      this.textArea.setCaretPosition(this.textArea.getDocument().getLength());
      this.currentLogType = LogType.INFO;
      this.customColor = null;
   }

   public void flush() {
   }

   public void close() {
   }

   @JvmOverloads
   public final void println(@NotNull Object s, @NotNull LogType logType, @NotNull String end, @Nullable Color customColor) {
      Intrinsics.checkNotNullParameter(s, "s");
      Intrinsics.checkNotNullParameter(logType, "logType");
      Intrinsics.checkNotNullParameter(end, "end");
      if (Config.INSTANCE.getConsoleErrorAndWarningColors()) {
         this.currentLogType = logType;
         this.customColor = customColor;
      }

      this.printWriter.print(s);
      this.printWriter.print(end);
   }

   // $FF: synthetic method
   public static void println$default(TextAreaWriter var0, Object var1, LogType var2, String var3, Color var4, int var5, Object var6) {
      if ((var5 & 2) != 0) {
         var2 = LogType.INFO;
      }

      if ((var5 & 4) != 0) {
         var3 = "\n";
      }

      if ((var5 & 8) != 0) {
         var4 = null;
      }

      var0.println(var1, var2, var3, var4);
   }

   public final void clear() {
      this.textArea.setText("");
   }

   @JvmOverloads
   public final void println(@NotNull Object s, @NotNull LogType logType, @NotNull String end) {
      Intrinsics.checkNotNullParameter(s, "s");
      Intrinsics.checkNotNullParameter(logType, "logType");
      Intrinsics.checkNotNullParameter(end, "end");
      println$default(this, s, logType, end, (Color)null, 8, (Object)null);
   }

   @JvmOverloads
   public final void println(@NotNull Object s, @NotNull LogType logType) {
      Intrinsics.checkNotNullParameter(s, "s");
      Intrinsics.checkNotNullParameter(logType, "logType");
      println$default(this, s, logType, (String)null, (Color)null, 12, (Object)null);
   }

   @JvmOverloads
   public final void println(@NotNull Object s) {
      Intrinsics.checkNotNullParameter(s, "s");
      println$default(this, s, (LogType)null, (String)null, (Color)null, 14, (Object)null);
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[LogType.values().length];
         var0[LogType.INFO.ordinal()] = 1;
         var0[LogType.WARN.ordinal()] = 2;
         var0[LogType.ERROR.ordinal()] = 3;
         $EnumSwitchMapping$0 = var0;
      }
   }
}
