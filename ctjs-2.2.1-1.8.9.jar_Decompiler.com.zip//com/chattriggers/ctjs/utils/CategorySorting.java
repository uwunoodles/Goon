package com.chattriggers.ctjs.utils;

import gg.essential.vigilance.data.Category;
import gg.essential.vigilance.data.SortingBehavior;
import java.util.Comparator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u001c\u0010\u0006\u001a\u0016\u0012\u0006\b\u0000\u0012\u00020\b0\u0007j\n\u0012\u0006\b\u0000\u0012\u00020\b`\tH\u0016R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\n"},
   d2 = {"Lcom/chattriggers/ctjs/utils/CategorySorting;", "Lgg/essential/vigilance/data/SortingBehavior;", "()V", "categories", "", "", "getCategoryComparator", "Ljava/util/Comparator;", "Lgg/essential/vigilance/data/Category;", "Lkotlin/Comparator;", "ctjs"}
)
public final class CategorySorting extends SortingBehavior {
   @NotNull
   public static final CategorySorting INSTANCE = new CategorySorting();
   @NotNull
   private static final List<String> categories;

   private CategorySorting() {
   }

   @NotNull
   public Comparator<? super Category> getCategoryComparator() {
      return CategorySorting::getCategoryComparator$lambda-1;
   }

   private static final int getCategoryComparator$lambda_1/* $FF was: getCategoryComparator$lambda-1*/(Category o1, Category o2) {
      if (!categories.contains(o1.getName()) || !categories.contains(o2.getName())) {
         int var2 = false;
         String var3 = "All categories must be in the list of categories";
         throw new IllegalArgumentException(var3.toString());
      } else {
         return categories.indexOf(o1.getName()) - categories.indexOf(o2.getName());
      }
   }

   static {
      String[] var0 = new String[]{"General", "Console"};
      categories = CollectionsKt.listOf(var0);
   }
}
