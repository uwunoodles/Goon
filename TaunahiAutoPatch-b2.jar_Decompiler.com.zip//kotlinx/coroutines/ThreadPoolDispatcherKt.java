package kotlinx.coroutines;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u0016\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\u001a\u0018\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0007\u001a\u0010\u0010\u0006\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u0005H\u0007¨\u0006\u0007"},
   d2 = {"newFixedThreadPoolContext", "Lkotlinx/coroutines/ExecutorCoroutineDispatcher;", "nThreads", "", "name", "", "newSingleThreadContext", "kotlinx-coroutines-core"}
)
public final class ThreadPoolDispatcherKt {
   @DelicateCoroutinesApi
   @NotNull
   public static final ExecutorCoroutineDispatcher newSingleThreadContext(@NotNull String a) {
      return newFixedThreadPoolContext(1, a);
   }

   @DelicateCoroutinesApi
   @NotNull
   public static final ExecutorCoroutineDispatcher newFixedThreadPoolContext(int a, @NotNull String a) {
      if (a < 1) {
         int a = false;
         String var5 = "Expected at least one thread, but " + a + " specified";
         throw new IllegalArgumentException(var5.toString());
      } else {
         AtomicInteger a = new AtomicInteger();
         ScheduledExecutorService a = Executors.newScheduledThreadPool(a, ThreadPoolDispatcherKt::newFixedThreadPoolContext$lambda-1);
         return ExecutorsKt.from((ExecutorService)a);
      }
   }

   private static final Thread newFixedThreadPoolContext$lambda_1/* $FF was: newFixedThreadPoolContext$lambda-1*/(int a, String a, AtomicInteger a, Runnable a) {
      Thread a = new Thread(a, a == 1 ? a : a + '-' + a.incrementAndGet());
      a.setDaemon(true);
      return a;
   }
}
