package kotlinx.coroutines;

import java.util.Iterator;
import java.util.List;
import java.util.ServiceLoader;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.sequences.SequencesKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0000\u001a\u0018\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0000\"\u0014\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\t"},
   d2 = {"handlers", "", "Lkotlinx/coroutines/CoroutineExceptionHandler;", "handleCoroutineExceptionImpl", "", "context", "Lkotlin/coroutines/CoroutineContext;", "exception", "", "kotlinx-coroutines-core"}
)
public final class CoroutineExceptionHandlerImplKt {
   @NotNull
   private static final List<CoroutineExceptionHandler> handlers = SequencesKt.toList(SequencesKt.asSequence(ServiceLoader.load(CoroutineExceptionHandler.class, CoroutineExceptionHandler.class.getClassLoader()).iterator()));

   public static final void handleCoroutineExceptionImpl(@NotNull CoroutineContext a, @NotNull Throwable a) {
      Iterator var2 = handlers.iterator();

      while(var2.hasNext()) {
         CoroutineExceptionHandler a = (CoroutineExceptionHandler)var2.next();

         try {
            a.handleException(a, a);
         } catch (Throwable var7) {
            Thread a = Thread.currentThread();
            a.getUncaughtExceptionHandler().uncaughtException(a, CoroutineExceptionHandlerKt.handlerException(a, var7));
         }
      }

      Thread a = Thread.currentThread();

      Result.Companion var10000;
      Object var9;
      try {
         var10000 = Result.Companion;
         int a = false;
         kotlin.ExceptionsKt.addSuppressed(a, (Throwable)(new DiagnosticCoroutineContextException(a)));
         var9 = Result.constructor-impl(Unit.INSTANCE);
      } catch (Throwable var6) {
         var10000 = Result.Companion;
         var9 = Result.constructor-impl(ResultKt.createFailure(var6));
      }

      a.getUncaughtExceptionHandler().uncaughtException(a, a);
   }
}
