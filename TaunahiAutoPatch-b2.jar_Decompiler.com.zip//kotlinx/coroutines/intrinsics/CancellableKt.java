package kotlinx.coroutines.intrinsics;

import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.InternalCoroutinesApi;
import kotlinx.coroutines.internal.DispatchedContinuationKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000:\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a\u001c\u0010\u0000\u001a\u00020\u00012\n\u0010\u0002\u001a\u0006\u0012\u0002\b\u00030\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0002\u001a#\u0010\u0006\u001a\u00020\u00012\n\u0010\u0002\u001a\u0006\u0012\u0002\b\u00030\u00032\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00010\bH\u0082\b\u001a\u001e\u0010\t\u001a\u00020\u0001*\b\u0012\u0004\u0012\u00020\u00010\u00032\n\u0010\n\u001a\u0006\u0012\u0002\b\u00030\u0003H\u0000\u001a>\u0010\t\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u000b*\u0018\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u000b0\u0003\u0012\u0006\u0012\u0004\u0018\u00010\r0\f2\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u0002H\u000b0\u0003H\u0007ø\u0001\u0000¢\u0006\u0002\u0010\u000e\u001ay\u0010\t\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u000f\"\u0004\b\u0001\u0010\u000b*\u001e\b\u0001\u0012\u0004\u0012\u0002H\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u000b0\u0003\u0012\u0006\u0012\u0004\u0018\u00010\r0\u00102\u0006\u0010\u0011\u001a\u0002H\u000f2\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u0002H\u000b0\u00032%\b\u0002\u0010\u0012\u001a\u001f\u0012\u0013\u0012\u00110\u0005¢\u0006\f\b\u0013\u0012\b\b\u0014\u0012\u0004\b\b(\u0015\u0012\u0004\u0012\u00020\u0001\u0018\u00010\fH\u0000ø\u0001\u0000¢\u0006\u0002\u0010\u0016\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0017"},
   d2 = {"dispatcherFailure", "", "completion", "Lkotlin/coroutines/Continuation;", "e", "", "runSafely", "block", "Lkotlin/Function0;", "startCoroutineCancellable", "fatalCompletion", "T", "Lkotlin/Function1;", "", "(Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)V", "R", "Lkotlin/Function2;", "receiver", "onCancellation", "Lkotlin/ParameterName;", "name", "cause", "(Lkotlin/jvm/functions/Function2;Ljava/lang/Object;Lkotlin/coroutines/Continuation;Lkotlin/jvm/functions/Function1;)V", "kotlinx-coroutines-core"}
)
public final class CancellableKt {
   @InternalCoroutinesApi
   public static final <T> void startCoroutineCancellable(@NotNull Function1<? super Continuation<? super T>, ? extends Object> a, @NotNull Continuation<? super T> a) {
      boolean var2 = false;

      try {
         int a = false;
         Continuation var10000 = IntrinsicsKt.intercepted(IntrinsicsKt.createCoroutineUnintercepted(a, a));
         Result.Companion var10001 = Result.Companion;
         DispatchedContinuationKt.resumeCancellableWith$default(var10000, Result.constructor-impl(Unit.INSTANCE), (Function1)null, 2, (Object)null);
      } catch (Throwable var5) {
         dispatcherFailure(a, var5);
      }

   }

   public static final <R, T> void startCoroutineCancellable(@NotNull Function2<? super R, ? super Continuation<? super T>, ? extends Object> a, R a, @NotNull Continuation<? super T> a, @Nullable Function1<? super Throwable, Unit> a) {
      boolean var4 = false;

      try {
         int a = false;
         Continuation var10000 = IntrinsicsKt.intercepted(IntrinsicsKt.createCoroutineUnintercepted(a, a, a));
         Result.Companion var10001 = Result.Companion;
         DispatchedContinuationKt.resumeCancellableWith(var10000, Result.constructor-impl(Unit.INSTANCE), a);
      } catch (Throwable var7) {
         dispatcherFailure(a, var7);
      }

   }

   // $FF: synthetic method
   public static void startCoroutineCancellable$default(Function2 var0, Object var1, Continuation var2, Function1 var3, int var4, Object var5) {
      if ((var4 & 4) != 0) {
         var3 = null;
      }

      startCoroutineCancellable(var0, var1, var2, var3);
   }

   public static final void startCoroutineCancellable(@NotNull Continuation<? super Unit> a, @NotNull Continuation<?> a) {
      boolean var2 = false;

      try {
         int a = false;
         Continuation var10000 = IntrinsicsKt.intercepted(a);
         Result.Companion var10001 = Result.Companion;
         DispatchedContinuationKt.resumeCancellableWith$default(var10000, Result.constructor-impl(Unit.INSTANCE), (Function1)null, 2, (Object)null);
      } catch (Throwable var5) {
         dispatcherFailure(a, var5);
      }

   }

   private static final void runSafely(Continuation<?> a, Function0<Unit> a) {
      boolean var2 = false;

      try {
         a.invoke();
      } catch (Throwable var4) {
         dispatcherFailure(a, var4);
      }

   }

   private static final void dispatcherFailure(Continuation<?> a, Throwable a) {
      Result.Companion var10001 = Result.Companion;
      a.resumeWith(Result.constructor-impl(ResultKt.createFailure(a)));
      throw a;
   }
}
