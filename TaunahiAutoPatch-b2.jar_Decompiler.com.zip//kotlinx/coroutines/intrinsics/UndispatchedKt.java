package kotlinx.coroutines.intrinsics;

import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.CoroutineStackFrame;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.TypeIntrinsics;
import kotlinx.coroutines.CompletedExceptionally;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.JobSupportKt;
import kotlinx.coroutines.TimeoutCancellationException;
import kotlinx.coroutines.internal.ScopeCoroutine;
import kotlinx.coroutines.internal.StackTraceRecoveryKt;
import kotlinx.coroutines.internal.ThreadContextKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000@\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a9\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u00022\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u0002H\u00020\u00042\u001a\u0010\u0005\u001a\u0016\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006H\u0082\b\u001a>\u0010\b\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\u0018\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u00062\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0004H\u0000ø\u0001\u0000¢\u0006\u0002\u0010\t\u001aR\u0010\b\u001a\u00020\u0001\"\u0004\b\u0000\u0010\n\"\u0004\b\u0001\u0010\u0002*\u001e\b\u0001\u0012\u0004\u0012\u0002H\n\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u000b2\u0006\u0010\f\u001a\u0002H\n2\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0004H\u0000ø\u0001\u0000¢\u0006\u0002\u0010\r\u001a>\u0010\u000e\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\u0018\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u00062\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0004H\u0000ø\u0001\u0000¢\u0006\u0002\u0010\t\u001aR\u0010\u000e\u001a\u00020\u0001\"\u0004\b\u0000\u0010\n\"\u0004\b\u0001\u0010\u0002*\u001e\b\u0001\u0012\u0004\u0012\u0002H\n\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u000b2\u0006\u0010\f\u001a\u0002H\n2\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0004H\u0000ø\u0001\u0000¢\u0006\u0002\u0010\r\u001aY\u0010\u000f\u001a\u0004\u0018\u00010\u0007\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\n*\b\u0012\u0004\u0012\u0002H\u00020\u00102\u0006\u0010\f\u001a\u0002H\n2'\u0010\u0005\u001a#\b\u0001\u0012\u0004\u0012\u0002H\n\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u000b¢\u0006\u0002\b\u0011H\u0000ø\u0001\u0000¢\u0006\u0002\u0010\u0012\u001aY\u0010\u0013\u001a\u0004\u0018\u00010\u0007\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\n*\b\u0012\u0004\u0012\u0002H\u00020\u00102\u0006\u0010\f\u001a\u0002H\n2'\u0010\u0005\u001a#\b\u0001\u0012\u0004\u0012\u0002H\n\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u000b¢\u0006\u0002\b\u0011H\u0000ø\u0001\u0000¢\u0006\u0002\u0010\u0012\u001a?\u0010\u0014\u001a\u0004\u0018\u00010\u0007\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00102\u0012\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u00170\u00062\u000e\u0010\u0018\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0019H\u0082\b\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001a"},
   d2 = {"startDirect", "", "T", "completion", "Lkotlin/coroutines/Continuation;", "block", "Lkotlin/Function1;", "", "startCoroutineUndispatched", "(Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)V", "R", "Lkotlin/Function2;", "receiver", "(Lkotlin/jvm/functions/Function2;Ljava/lang/Object;Lkotlin/coroutines/Continuation;)V", "startCoroutineUnintercepted", "startUndispatchedOrReturn", "Lkotlinx/coroutines/internal/ScopeCoroutine;", "Lkotlin/ExtensionFunctionType;", "(Lkotlinx/coroutines/internal/ScopeCoroutine;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)Ljava/lang/Object;", "startUndispatchedOrReturnIgnoreTimeout", "undispatchedResult", "shouldThrow", "", "", "startBlock", "Lkotlin/Function0;", "kotlinx-coroutines-core"}
)
public final class UndispatchedKt {
   public static final <T> void startCoroutineUnintercepted(@NotNull Function1<? super Continuation<? super T>, ? extends Object> a, @NotNull Continuation<? super T> a) {
      int a = false;
      int a = false;
      Continuation a = DebugProbesKt.probeCoroutineCreated(a);

      Result.Companion var10001;
      Object var7;
      try {
         int a = false;
         var7 = ((Function1)TypeIntrinsics.beforeCheckcastToFunctionOfArity(a, 1)).invoke(a);
      } catch (Throwable var8) {
         var10001 = Result.Companion;
         a.resumeWith(Result.constructor-impl(ResultKt.createFailure(var8)));
         return;
      }

      if (var7 != IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         var10001 = Result.Companion;
         a.resumeWith(Result.constructor-impl(var7));
      }

   }

   public static final <R, T> void startCoroutineUnintercepted(@NotNull Function2<? super R, ? super Continuation<? super T>, ? extends Object> a, R a, @NotNull Continuation<? super T> a) {
      int a = false;
      int a = false;
      Continuation a = DebugProbesKt.probeCoroutineCreated(a);

      Result.Companion var10001;
      Object var8;
      try {
         int a = false;
         var8 = ((Function2)TypeIntrinsics.beforeCheckcastToFunctionOfArity(a, 2)).invoke(a, a);
      } catch (Throwable var10) {
         var10001 = Result.Companion;
         a.resumeWith(Result.constructor-impl(ResultKt.createFailure(var10)));
         return;
      }

      if (var8 != IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         var10001 = Result.Companion;
         a.resumeWith(Result.constructor-impl(var8));
      }

   }

   public static final <T> void startCoroutineUndispatched(@NotNull Function1<? super Continuation<? super T>, ? extends Object> a, @NotNull Continuation<? super T> a) {
      int a = false;
      int a = false;
      Continuation a = DebugProbesKt.probeCoroutineCreated(a);

      Object var13;
      Result.Companion var10001;
      try {
         Continuation a = a;
         int a = false;
         CoroutineContext a = a.getContext();
         Object a = null;
         int a = false;
         Object a = ThreadContextKt.updateThreadContext(a, a);

         Object var12;
         try {
            int a = false;
            var12 = ((Function1)TypeIntrinsics.beforeCheckcastToFunctionOfArity(a, 1)).invoke(a);
         } finally {
            ThreadContextKt.restoreThreadContext(a, a);
         }

         var13 = var12;
      } catch (Throwable var18) {
         var10001 = Result.Companion;
         a.resumeWith(Result.constructor-impl(ResultKt.createFailure(var18)));
         return;
      }

      if (var13 != IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         var10001 = Result.Companion;
         a.resumeWith(Result.constructor-impl(var13));
      }

   }

   public static final <R, T> void startCoroutineUndispatched(@NotNull Function2<? super R, ? super Continuation<? super T>, ? extends Object> a, R a, @NotNull Continuation<? super T> a) {
      int a = false;
      int a = false;
      Continuation a = DebugProbesKt.probeCoroutineCreated(a);

      Object var14;
      Result.Companion var10001;
      try {
         Continuation a = a;
         int a = false;
         CoroutineContext a = a.getContext();
         Object a = null;
         int a = false;
         Object a = ThreadContextKt.updateThreadContext(a, a);

         Object var13;
         try {
            int a = false;
            var13 = ((Function2)TypeIntrinsics.beforeCheckcastToFunctionOfArity(a, 2)).invoke(a, a);
         } finally {
            ThreadContextKt.restoreThreadContext(a, a);
         }

         var14 = var13;
      } catch (Throwable var19) {
         var10001 = Result.Companion;
         a.resumeWith(Result.constructor-impl(ResultKt.createFailure(var19)));
         return;
      }

      if (var14 != IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         var10001 = Result.Companion;
         a.resumeWith(Result.constructor-impl(var14));
      }

   }

   private static final <T> void startDirect(Continuation<? super T> a, Function1<? super Continuation<? super T>, ? extends Object> a) {
      int a = false;
      int a = false;
      Continuation a = DebugProbesKt.probeCoroutineCreated(a);

      Result.Companion var10001;
      Object var5;
      try {
         var5 = a.invoke(a);
      } catch (Throwable var7) {
         var10001 = Result.Companion;
         a.resumeWith(Result.constructor-impl(ResultKt.createFailure(var7)));
         return;
      }

      if (var5 != IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         var10001 = Result.Companion;
         a.resumeWith(Result.constructor-impl(var5));
      }

   }

   @Nullable
   public static final <T, R> Object startUndispatchedOrReturn(@NotNull ScopeCoroutine<? super T> a, R a, @NotNull Function2<? super R, ? super Continuation<? super T>, ? extends Object> a) {
      boolean var4 = false;

      Object a;
      try {
         int a = false;
         a = ((Function2)TypeIntrinsics.beforeCheckcastToFunctionOfArity(a, 2)).invoke(a, (Continuation)a);
      } catch (Throwable var12) {
         a = new CompletedExceptionally(var12, false, 2, (DefaultConstructorMarker)null);
      }

      Object a = a;
      Object var10000;
      if (a == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         var10000 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      } else {
         a = a.makeCompletingOnce$kotlinx_coroutines_core(a);
         if (a == JobSupportKt.COMPLETING_WAITING_CHILDREN) {
            var10000 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
         } else if (a instanceof CompletedExceptionally) {
            Throwable a = ((CompletedExceptionally)a).cause;
            int a = false;
            Throwable a;
            Continuation a;
            boolean a;
            if (true) {
               a = ((CompletedExceptionally)a).cause;
               a = a.uCont;
               a = false;
               throw DebugKt.getRECOVER_STACK_TRACES() && a instanceof CoroutineStackFrame ? StackTraceRecoveryKt.access$recoverFromStackFrame(a, (CoroutineStackFrame)a) : a;
            }

            if (a instanceof CompletedExceptionally) {
               a = ((CompletedExceptionally)a).cause;
               a = a.uCont;
               a = false;
               throw DebugKt.getRECOVER_STACK_TRACES() && a instanceof CoroutineStackFrame ? StackTraceRecoveryKt.access$recoverFromStackFrame(a, (CoroutineStackFrame)a) : a;
            }

            var10000 = a;
         } else {
            var10000 = JobSupportKt.unboxState(a);
         }
      }

      return var10000;
   }

   @Nullable
   public static final <T, R> Object startUndispatchedOrReturnIgnoreTimeout(@NotNull ScopeCoroutine<? super T> a, R a, @NotNull Function2<? super R, ? super Continuation<? super T>, ? extends Object> a) {
      boolean var4 = false;

      Object a;
      try {
         int a = false;
         a = ((Function2)TypeIntrinsics.beforeCheckcastToFunctionOfArity(a, 2)).invoke(a, (Continuation)a);
      } catch (Throwable var12) {
         a = new CompletedExceptionally(var12, false, 2, (DefaultConstructorMarker)null);
      }

      Object a = a;
      Object var10000;
      if (a == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         var10000 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      } else {
         a = a.makeCompletingOnce$kotlinx_coroutines_core(a);
         if (a == JobSupportKt.COMPLETING_WAITING_CHILDREN) {
            var10000 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
         } else if (!(a instanceof CompletedExceptionally)) {
            var10000 = JobSupportKt.unboxState(a);
         } else {
            Throwable a = ((CompletedExceptionally)a).cause;
            int a = false;
            Throwable a;
            Continuation a;
            boolean a;
            if (!(a instanceof TimeoutCancellationException) || ((TimeoutCancellationException)a).coroutine != a) {
               a = ((CompletedExceptionally)a).cause;
               a = a.uCont;
               a = false;
               throw DebugKt.getRECOVER_STACK_TRACES() && a instanceof CoroutineStackFrame ? StackTraceRecoveryKt.access$recoverFromStackFrame(a, (CoroutineStackFrame)a) : a;
            }

            if (a instanceof CompletedExceptionally) {
               a = ((CompletedExceptionally)a).cause;
               a = a.uCont;
               a = false;
               throw DebugKt.getRECOVER_STACK_TRACES() && a instanceof CoroutineStackFrame ? StackTraceRecoveryKt.access$recoverFromStackFrame(a, (CoroutineStackFrame)a) : a;
            }

            var10000 = a;
         }
      }

      return var10000;
   }

   private static final <T> Object undispatchedResult(ScopeCoroutine<? super T> a, Function1<? super Throwable, Boolean> a, Function0<? extends Object> a) {
      boolean var3 = false;

      Object a;
      try {
         a = a.invoke();
      } catch (Throwable var9) {
         a = new CompletedExceptionally(var9, false, 2, (DefaultConstructorMarker)null);
      }

      Object a = a;
      if (a == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         return IntrinsicsKt.getCOROUTINE_SUSPENDED();
      } else {
         a = a.makeCompletingOnce$kotlinx_coroutines_core(a);
         if (a == JobSupportKt.COMPLETING_WAITING_CHILDREN) {
            return IntrinsicsKt.getCOROUTINE_SUSPENDED();
         } else {
            Object var10000;
            if (a instanceof CompletedExceptionally) {
               Throwable a;
               Continuation a;
               boolean a;
               if ((Boolean)a.invoke(((CompletedExceptionally)a).cause)) {
                  a = ((CompletedExceptionally)a).cause;
                  a = a.uCont;
                  a = false;
                  throw DebugKt.getRECOVER_STACK_TRACES() && a instanceof CoroutineStackFrame ? StackTraceRecoveryKt.access$recoverFromStackFrame(a, (CoroutineStackFrame)a) : a;
               }

               if (a instanceof CompletedExceptionally) {
                  a = ((CompletedExceptionally)a).cause;
                  a = a.uCont;
                  a = false;
                  throw DebugKt.getRECOVER_STACK_TRACES() && a instanceof CoroutineStackFrame ? StackTraceRecoveryKt.access$recoverFromStackFrame(a, (CoroutineStackFrame)a) : a;
               }

               var10000 = a;
            } else {
               var10000 = JobSupportKt.unboxState(a);
            }

            return var10000;
         }
      }
   }
}
