package kotlinx.coroutines;

import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.coroutines.Continuation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0003\n\u0000\b\u0002\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002B\u0013\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004¢\u0006\u0002\u0010\u0005J\u0013\u0010\u0006\u001a\u00020\u00072\b\u0010\b\u001a\u0004\u0018\u00010\tH\u0096\u0002R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\n"},
   d2 = {"Lkotlinx/coroutines/ResumeAwaitOnCompletion;", "T", "Lkotlinx/coroutines/JobNode;", "continuation", "Lkotlinx/coroutines/CancellableContinuationImpl;", "(Lkotlinx/coroutines/CancellableContinuationImpl;)V", "invoke", "", "cause", "", "kotlinx-coroutines-core"}
)
final class ResumeAwaitOnCompletion<T> extends JobNode {
   @NotNull
   private final CancellableContinuationImpl<T> continuation;

   public ResumeAwaitOnCompletion(@NotNull CancellableContinuationImpl<? super T> a) {
      a.continuation = a;
   }

   public void invoke(@Nullable Throwable a1) {
      Object a = a.getJob().getState$kotlinx_coroutines_core();
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a instanceof Incomplete) {
            throw new AssertionError();
         }
      }

      Continuation var10000;
      Result.Companion var10001;
      if (a instanceof CompletedExceptionally) {
         var10000 = (Continuation)a.continuation;
         var10001 = Result.Companion;
         var10000.resumeWith(Result.constructor-impl(ResultKt.createFailure(((CompletedExceptionally)a).cause)));
      } else {
         var10000 = (Continuation)a.continuation;
         var10001 = Result.Companion;
         var10000.resumeWith(Result.constructor-impl(JobSupportKt.unboxState(a)));
      }

   }
}
