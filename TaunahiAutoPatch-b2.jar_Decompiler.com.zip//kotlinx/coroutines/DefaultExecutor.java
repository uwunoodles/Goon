package kotlinx.coroutines;

import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\bÀ\u0002\u0018\u00002\u00020\u00012\u00060\u0002j\u0002`\u0003B\u0007\b\u0002¢\u0006\u0002\u0010\u0004J\b\u0010\u001d\u001a\u00020\u001eH\u0002J\b\u0010\u001f\u001a\u00020\u0011H\u0002J\u0014\u0010 \u001a\u00020\u001e2\n\u0010!\u001a\u00060\u0002j\u0002`\u0003H\u0016J\r\u0010\"\u001a\u00020\u001eH\u0000¢\u0006\u0002\b#J$\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020\b2\n\u0010'\u001a\u00060\u0002j\u0002`\u00032\u0006\u0010(\u001a\u00020)H\u0016J\b\u0010*\u001a\u00020\u0015H\u0002J\u0018\u0010+\u001a\u00020\u001e2\u0006\u0010,\u001a\u00020\b2\u0006\u0010-\u001a\u00020.H\u0014J\b\u0010/\u001a\u00020\u001eH\u0016J\b\u00100\u001a\u00020\u001eH\u0016J\b\u00101\u001a\u00020\u001eH\u0002J\u000e\u00102\u001a\u00020\u001e2\u0006\u00103\u001a\u00020\bR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0086T¢\u0006\u0002\n\u0000R\u0016\u0010\u0010\u001a\u0004\u0018\u00010\u0011X\u0082\u000e¢\u0006\b\n\u0000\u0012\u0004\b\u0012\u0010\u0004R\u000e\u0010\u0013\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0014\u001a\u00020\u00158BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0014\u0010\u0016R\u0014\u0010\u0017\u001a\u00020\u00158BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0017\u0010\u0016R\u0014\u0010\u0018\u001a\u00020\u00158@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0019\u0010\u0016R\u0014\u0010\u001a\u001a\u00020\u00118TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b\u001b\u0010\u001c¨\u00064"},
   d2 = {"Lkotlinx/coroutines/DefaultExecutor;", "Lkotlinx/coroutines/EventLoopImplBase;", "Ljava/lang/Runnable;", "Lkotlinx/coroutines/Runnable;", "()V", "ACTIVE", "", "DEFAULT_KEEP_ALIVE_MS", "", "FRESH", "KEEP_ALIVE_NANOS", "SHUTDOWN", "SHUTDOWN_ACK", "SHUTDOWN_REQ", "THREAD_NAME", "", "_thread", "Ljava/lang/Thread;", "get_thread$annotations", "debugStatus", "isShutDown", "", "()Z", "isShutdownRequested", "isThreadPresent", "isThreadPresent$kotlinx_coroutines_core", "thread", "getThread", "()Ljava/lang/Thread;", "acknowledgeShutdownIfNeeded", "", "createThreadSync", "enqueue", "task", "ensureStarted", "ensureStarted$kotlinx_coroutines_core", "invokeOnTimeout", "Lkotlinx/coroutines/DisposableHandle;", "timeMillis", "block", "context", "Lkotlin/coroutines/CoroutineContext;", "notifyStartup", "reschedule", "now", "delayedTask", "Lkotlinx/coroutines/EventLoopImplBase$DelayedTask;", "run", "shutdown", "shutdownError", "shutdownForTests", "timeout", "kotlinx-coroutines-core"}
)
public final class DefaultExecutor extends EventLoopImplBase implements Runnable {
   @NotNull
   public static final DefaultExecutor INSTANCE = new DefaultExecutor();
   @NotNull
   public static final String THREAD_NAME = "kotlinx.coroutines.DefaultExecutor";
   private static final long DEFAULT_KEEP_ALIVE_MS = 1000L;
   private static final long KEEP_ALIVE_NANOS;
   @Nullable
   private static volatile Thread _thread;
   private static final int FRESH = 0;
   private static final int ACTIVE = 1;
   private static final int SHUTDOWN_REQ = 2;
   private static final int SHUTDOWN_ACK = 3;
   private static final int SHUTDOWN = 4;
   private static volatile int debugStatus;

   private DefaultExecutor() {
   }

   /** @deprecated */
   // $FF: synthetic method
   private static void get_thread$annotations() {
   }

   @NotNull
   protected Thread getThread() {
      Thread var10000 = _thread;
      if (var10000 == null) {
         var10000 = a.createThreadSync();
      }

      return var10000;
   }

   private final boolean isShutDown() {
      return debugStatus == 4;
   }

   private final boolean isShutdownRequested() {
      int a = debugStatus;
      return a == 2 || a == 3;
   }

   public void enqueue(@NotNull Runnable a) {
      if (a.isShutDown()) {
         a.shutdownError();
      }

      super.enqueue(a);
   }

   protected void reschedule(long a1, @NotNull EventLoopImplBase.DelayedTask a2) {
      a.shutdownError();
   }

   private final void shutdownError() {
      throw new RejectedExecutionException("DefaultExecutor was shut down. This error indicates that Dispatchers.shutdown() was invoked prior to completion of exiting coroutines, leaving coroutines in incomplete state. Please refer to Dispatchers.shutdown documentation for more details");
   }

   public void shutdown() {
      debugStatus = 4;
      super.shutdown();
   }

   @NotNull
   public DisposableHandle invokeOnTimeout(long a, @NotNull Runnable a, @NotNull CoroutineContext a3) {
      return a.scheduleInvokeOnTimeout(a, a);
   }

   public void run() {
      ThreadLocalEventLoop.INSTANCE.setEventLoop$kotlinx_coroutines_core((EventLoop)a);
      AbstractTimeSource var10000 = AbstractTimeSourceKt.getTimeSource();
      if (var10000 != null) {
         var10000.registerTimeLoopThread();
      }

      try {
         long a = Long.MAX_VALUE;
         if (a.notifyStartup()) {
            while(true) {
               Thread.interrupted();
               long a = a.processNextEvent();
               if (a == Long.MAX_VALUE) {
                  var10000 = AbstractTimeSourceKt.getTimeSource();
                  long a = var10000 != null ? var10000.nanoTime() : System.nanoTime();
                  if (a == Long.MAX_VALUE) {
                     a = a + KEEP_ALIVE_NANOS;
                  }

                  long a = a - a;
                  if (a <= 0L) {
                     return;
                  }

                  a = RangesKt.coerceAtMost(a, a);
               } else {
                  a = Long.MAX_VALUE;
               }

               if (a > 0L) {
                  if (a.isShutdownRequested()) {
                     return;
                  }

                  var10000 = AbstractTimeSourceKt.getTimeSource();
                  Unit var11;
                  if (var10000 != null) {
                     var10000.parkNanos(a, a);
                     var11 = Unit.INSTANCE;
                  } else {
                     var11 = null;
                  }

                  if (var11 == null) {
                     LockSupport.parkNanos(a, a);
                  }
               }
            }
         }
      } finally {
         _thread = null;
         a.acknowledgeShutdownIfNeeded();
         var10000 = AbstractTimeSourceKt.getTimeSource();
         if (var10000 != null) {
            var10000.unregisterTimeLoopThread();
         }

         if (!a.isEmpty()) {
            a.getThread();
         }

      }
   }

   private final synchronized Thread createThreadSync() {
      Thread var10000 = _thread;
      if (var10000 == null) {
         Thread var1 = new Thread((Runnable)a, "kotlinx.coroutines.DefaultExecutor");
         int a = false;
         DefaultExecutor var4 = INSTANCE;
         _thread = var1;
         var1.setDaemon(true);
         var1.start();
         var10000 = var1;
      }

      return var10000;
   }

   public final synchronized void ensureStarted$kotlinx_coroutines_core() {
      boolean a;
      if (DebugKt.getASSERTIONS_ENABLED()) {
         a = false;
         if (_thread != null) {
            throw new AssertionError();
         }
      }

      if (DebugKt.getASSERTIONS_ENABLED()) {
         a = false;
         if (debugStatus != 0 && debugStatus != 3) {
            throw new AssertionError();
         }
      }

      debugStatus = 0;
      a.createThreadSync();

      while(debugStatus == 0) {
         ((Object)a).wait();
      }

   }

   private final synchronized boolean notifyStartup() {
      if (a.isShutdownRequested()) {
         return false;
      } else {
         debugStatus = 1;
         ((Object)a).notifyAll();
         return true;
      }
   }

   public final synchronized void shutdownForTests(long a) {
      long a = System.currentTimeMillis() + a;
      if (!a.isShutdownRequested()) {
         debugStatus = 2;
      }

      while(debugStatus != 3 && _thread != null) {
         Thread var10000 = _thread;
         if (var10000 != null) {
            Thread a = var10000;
            int a = false;
            AbstractTimeSource var9 = AbstractTimeSourceKt.getTimeSource();
            Unit var10;
            if (var9 != null) {
               var9.unpark(a);
               var10 = Unit.INSTANCE;
            } else {
               var10 = null;
            }

            if (var10 == null) {
               LockSupport.unpark(a);
            }
         }

         long a = a - System.currentTimeMillis();
         if (a <= 0L) {
            break;
         }

         ((Object)a).wait(a);
      }

      debugStatus = 0;
   }

   private final synchronized void acknowledgeShutdownIfNeeded() {
      if (a.isShutdownRequested()) {
         debugStatus = 3;
         a.resetAll();
         ((Object)a).notifyAll();
      }
   }

   public final boolean isThreadPresent$kotlinx_coroutines_core() {
      return _thread != null;
   }

   static {
      EventLoop.incrementUseCount$default((EventLoop)INSTANCE, false, 1, (Object)null);
      TimeUnit var2 = TimeUnit.MILLISECONDS;

      TimeUnit var10000;
      Long var0;
      try {
         var10000 = var2;
         var0 = Long.getLong("kotlinx.coroutines.DefaultExecutor.keepAlive", 1000L);
      } catch (SecurityException var3) {
         var10000 = var2;
         var0 = 1000L;
      }

      KEEP_ALIVE_NANOS = var10000.toNanos(var0);
   }
}
