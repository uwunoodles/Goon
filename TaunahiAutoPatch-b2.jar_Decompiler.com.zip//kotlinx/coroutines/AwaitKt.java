package kotlinx.coroutines;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000*\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u001e\n\u0002\b\u0002\u001a=\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u00022\u001e\u0010\u0003\u001a\u0010\u0012\f\b\u0001\u0012\b\u0012\u0004\u0012\u0002H\u00020\u00050\u0004\"\b\u0012\u0004\u0012\u0002H\u00020\u0005H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0006\u001a%\u0010\u0007\u001a\u00020\b2\u0012\u0010\t\u001a\n\u0012\u0006\b\u0001\u0012\u00020\n0\u0004\"\u00020\nH\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u000b\u001a-\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u00050\fH\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\r\u001a\u001b\u0010\u0007\u001a\u00020\b*\b\u0012\u0004\u0012\u00020\n0\fH\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\r\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u000e"},
   d2 = {"awaitAll", "", "T", "deferreds", "", "Lkotlinx/coroutines/Deferred;", "([Lkotlinx/coroutines/Deferred;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "joinAll", "", "jobs", "Lkotlinx/coroutines/Job;", "([Lkotlinx/coroutines/Job;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "", "(Ljava/util/Collection;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public final class AwaitKt {
   @Nullable
   public static final <T> Object awaitAll(@NotNull Deferred<? extends T>[] a, @NotNull Continuation<? super List<? extends T>> a) {
      return a.length == 0 ? CollectionsKt.emptyList() : (new AwaitAll(a)).await(a);
   }

   @Nullable
   public static final <T> Object awaitAll(@NotNull Collection<? extends Deferred<? extends T>> a, @NotNull Continuation<? super List<? extends T>> a) {
      if (a.isEmpty()) {
         return CollectionsKt.emptyList();
      } else {
         AwaitAll var10000 = new AwaitAll;
         int a = false;
         Object[] var10002 = a.toArray(new Deferred[0]);
         if (var10002 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
         } else {
            var10000.<init>((Deferred[])var10002);
            return var10000.await(a);
         }
      }
   }

   @Nullable
   public static final Object joinAll(@NotNull Job[] a, @NotNull Continuation<? super Unit> var1) {
      Object a;
      label35: {
         if (var1 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var1;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label35;
            }
         }

         a = new ContinuationImpl(var1) {
            Object L$0;
            int I$0;
            int I$1;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return AwaitKt.joinAll((Job[])null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var11 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      Job[] a;
      boolean a;
      int var4;
      int var5;
      boolean a;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         a = a;
         a = false;
         var4 = 0;
         var5 = a.length;
         break;
      case 1:
         a = false;
         a = false;
         var5 = ((<undefinedtype>)a).I$1;
         var4 = ((<undefinedtype>)a).I$0;
         a = (Job[])((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         ++var4;
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      while(var4 < var5) {
         Object a = a[var4];
         a = false;
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).I$0 = var4;
         ((<undefinedtype>)a).I$1 = var5;
         ((<undefinedtype>)a).label = 1;
         if (a.join((Continuation)a) == var11) {
            return var11;
         }

         ++var4;
      }

      return Unit.INSTANCE;
   }

   @Nullable
   public static final Object joinAll(@NotNull Collection<? extends Job> a, @NotNull Continuation<? super Unit> var1) {
      Object a;
      label35: {
         if (var1 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var1;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label35;
            }
         }

         a = new ContinuationImpl(var1) {
            Object L$0;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return AwaitKt.joinAll((Collection)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var10 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      boolean a;
      Iterator var4;
      boolean a;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         Iterable a = (Iterable)a;
         a = false;
         var4 = a.iterator();
         break;
      case 1:
         a = false;
         a = false;
         var4 = (Iterator)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      Job a;
      do {
         if (!var4.hasNext()) {
            return Unit.INSTANCE;
         }

         Object a = var4.next();
         a = (Job)a;
         a = false;
         ((<undefinedtype>)a).L$0 = var4;
         ((<undefinedtype>)a).label = 1;
      } while(a.join((Continuation)a) != var10);

      return var10;
   }
}
