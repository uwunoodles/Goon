package kotlinx.coroutines;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.ContinuationInterceptor;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.jvm.internal.CoroutineStackFrame;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.internal.ThreadContextKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000>\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a \u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\nH\u0002\u001a8\u0010\u000b\u001a\u0002H\f\"\u0004\b\u0000\u0010\f2\n\u0010\r\u001a\u0006\u0012\u0002\b\u00030\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u00102\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u0002H\f0\u0012H\u0080\b¢\u0006\u0002\u0010\u0013\u001a4\u0010\u0014\u001a\u0002H\f\"\u0004\b\u0000\u0010\f2\u0006\u0010\u0015\u001a\u00020\u00032\b\u0010\u000f\u001a\u0004\u0018\u00010\u00102\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u0002H\f0\u0012H\u0080\b¢\u0006\u0002\u0010\u0016\u001a\f\u0010\u0017\u001a\u00020\n*\u00020\u0003H\u0002\u001a\u0014\u0010\u0018\u001a\u00020\u0003*\u00020\u00032\u0006\u0010\u0019\u001a\u00020\u0003H\u0007\u001a\u0014\u0010\u0018\u001a\u00020\u0003*\u00020\u001a2\u0006\u0010\u0015\u001a\u00020\u0003H\u0007\u001a\u0013\u0010\u001b\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u001c*\u00020\u001dH\u0080\u0010\u001a(\u0010\u001e\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u001c*\u0006\u0012\u0002\b\u00030\u000e2\u0006\u0010\u0015\u001a\u00020\u00032\b\u0010\u001f\u001a\u0004\u0018\u00010\u0010H\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u001a\u0010\u0002\u001a\u0004\u0018\u00010\u0001*\u00020\u00038@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0004\u0010\u0005¨\u0006 "},
   d2 = {"DEBUG_THREAD_NAME_SEPARATOR", "", "coroutineName", "Lkotlin/coroutines/CoroutineContext;", "getCoroutineName", "(Lkotlin/coroutines/CoroutineContext;)Ljava/lang/String;", "foldCopies", "originalContext", "appendContext", "isNewCoroutine", "", "withContinuationContext", "T", "continuation", "Lkotlin/coroutines/Continuation;", "countOrElement", "", "block", "Lkotlin/Function0;", "(Lkotlin/coroutines/Continuation;Ljava/lang/Object;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "withCoroutineContext", "context", "(Lkotlin/coroutines/CoroutineContext;Ljava/lang/Object;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "hasCopyableElements", "newCoroutineContext", "addedContext", "Lkotlinx/coroutines/CoroutineScope;", "undispatchedCompletion", "Lkotlinx/coroutines/UndispatchedCoroutine;", "Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;", "updateUndispatchedCompletion", "oldValue", "kotlinx-coroutines-core"}
)
public final class CoroutineContextKt {
   @NotNull
   private static final String DEBUG_THREAD_NAME_SEPARATOR = " @";

   @ExperimentalCoroutinesApi
   @NotNull
   public static final CoroutineContext newCoroutineContext(@NotNull CoroutineScope a, @NotNull CoroutineContext a) {
      CoroutineContext a = foldCopies(a.getCoroutineContext(), a, true);
      CoroutineContext a = DebugKt.getDEBUG() ? a.plus((CoroutineContext)(new CoroutineId(DebugKt.getCOROUTINE_ID().incrementAndGet()))) : a;
      return a != Dispatchers.getDefault() && a.get((CoroutineContext.Key)ContinuationInterceptor.Key) == null ? a.plus((CoroutineContext)Dispatchers.getDefault()) : a;
   }

   @InternalCoroutinesApi
   @NotNull
   public static final CoroutineContext newCoroutineContext(@NotNull CoroutineContext a, @NotNull CoroutineContext a) {
      return !hasCopyableElements(a) ? a.plus(a) : foldCopies(a, a, false);
   }

   private static final boolean hasCopyableElements(CoroutineContext a) {
      return (Boolean)a.fold(false, (Function2)null.INSTANCE);
   }

   private static final CoroutineContext foldCopies(CoroutineContext a, CoroutineContext a, final boolean a) {
      boolean a = hasCopyableElements(a);
      boolean a = hasCopyableElements(a);
      if (!a && !a) {
         return a.plus(a);
      } else {
         final Ref.ObjectRef a = new Ref.ObjectRef();
         a.element = a;
         CoroutineContext a = (CoroutineContext)a.fold(EmptyCoroutineContext.INSTANCE, (Function2)(new Function2<CoroutineContext, CoroutineContext.Element, CoroutineContext>() {
            @NotNull
            public final CoroutineContext invoke(@NotNull CoroutineContext axxx, @NotNull CoroutineContext.Element axxxx) {
               if (!(axxxx instanceof CopyableThreadContextElement)) {
                  return axxx.plus((CoroutineContext)axxxx);
               } else {
                  CoroutineContext.Element axx = ((CoroutineContext)a.element).get(axxxx.getKey());
                  if (axx == null) {
                     return axxx.plus((CoroutineContext)(a ? ((CopyableThreadContextElement)axxxx).copyForChild() : (CopyableThreadContextElement)axxxx));
                  } else {
                     a.element = ((CoroutineContext)a.element).minusKey(axxxx.getKey());
                     return axxx.plus(((CopyableThreadContextElement)axxxx).mergeForChild(axx));
                  }
               }
            }
         }));
         if (a) {
            a.element = ((CoroutineContext)a.element).fold(EmptyCoroutineContext.INSTANCE, (Function2)null.INSTANCE);
         }

         return a.plus((CoroutineContext)a.element);
      }
   }

   public static final <T> T withCoroutineContext(@NotNull CoroutineContext a, @Nullable Object a, @NotNull Function0<? extends T> a) {
      int a = false;
      Object a = ThreadContextKt.updateThreadContext(a, a);

      Object var5;
      try {
         var5 = a.invoke();
      } finally {
         InlineMarker.finallyStart(1);
         ThreadContextKt.restoreThreadContext(a, a);
         InlineMarker.finallyEnd(1);
      }

      return var5;
   }

   public static final <T> T withContinuationContext(@NotNull Continuation<?> a, @Nullable Object a, @NotNull Function0<? extends T> a) {
      int a = false;
      CoroutineContext a = a.getContext();
      Object a = ThreadContextKt.updateThreadContext(a, a);
      UndispatchedCoroutine a = a != ThreadContextKt.NO_THREAD_ELEMENTS ? updateUndispatchedCompletion(a, a, a) : (UndispatchedCoroutine)null;

      Object var7;
      try {
         var7 = a.invoke();
      } finally {
         InlineMarker.finallyStart(1);
         if (a == null || a.clearThreadContext()) {
            ThreadContextKt.restoreThreadContext(a, a);
         }

         InlineMarker.finallyEnd(1);
      }

      return var7;
   }

   @Nullable
   public static final UndispatchedCoroutine<?> updateUndispatchedCompletion(@NotNull Continuation<?> a, @NotNull CoroutineContext a, @Nullable Object a) {
      if (!(a instanceof CoroutineStackFrame)) {
         return null;
      } else {
         boolean a = a.get((CoroutineContext.Key)UndispatchedMarker.INSTANCE) != null;
         if (!a) {
            return null;
         } else {
            UndispatchedCoroutine a = undispatchedCompletion((CoroutineStackFrame)a);
            if (a != null) {
               a.saveThreadContext(a, a);
            }

            return a;
         }
      }
   }

   @Nullable
   public static final UndispatchedCoroutine<?> undispatchedCompletion(@NotNull CoroutineStackFrame a) {
      CoroutineStackFrame a;
      for(CoroutineStackFrame var1 = a; !(var1 instanceof DispatchedCoroutine); var1 = a) {
         CoroutineStackFrame var10000 = var1.getCallerFrame();
         if (var10000 == null) {
            return null;
         }

         a = var10000;
         if (a instanceof UndispatchedCoroutine) {
            return (UndispatchedCoroutine)a;
         }
      }

      return null;
   }

   @Nullable
   public static final String getCoroutineName(@NotNull CoroutineContext a) {
      if (!DebugKt.getDEBUG()) {
         return null;
      } else {
         CoroutineId var10000 = (CoroutineId)a.get((CoroutineContext.Key)CoroutineId.Key);
         if (var10000 == null) {
            return null;
         } else {
            CoroutineId a;
            String var4;
            label16: {
               a = var10000;
               CoroutineName var3 = (CoroutineName)a.get((CoroutineContext.Key)CoroutineName.Key);
               if (var3 != null) {
                  var4 = var3.getName();
                  if (var4 != null) {
                     break label16;
                  }
               }

               var4 = "coroutine";
            }

            String a = var4;
            return a + '#' + a.getId();
         }
      }
   }
}
