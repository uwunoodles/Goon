package kotlinx.coroutines;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\bg\u0018\u00002\u00020\u0001J\u0019\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0097@ø\u0001\u0000¢\u0006\u0002\u0010\u0006J$\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00052\n\u0010\n\u001a\u00060\u000bj\u0002`\f2\u0006\u0010\r\u001a\u00020\u000eH\u0016J\u001e\u0010\u000f\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u00052\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00030\u0011H&\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0012"},
   d2 = {"Lkotlinx/coroutines/Delay;", "", "delay", "", "time", "", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "invokeOnTimeout", "Lkotlinx/coroutines/DisposableHandle;", "timeMillis", "block", "Ljava/lang/Runnable;", "Lkotlinx/coroutines/Runnable;", "context", "Lkotlin/coroutines/CoroutineContext;", "scheduleResumeAfterDelay", "continuation", "Lkotlinx/coroutines/CancellableContinuation;", "kotlinx-coroutines-core"}
)
@InternalCoroutinesApi
public interface Delay {
   /** @deprecated */
   @Deprecated(
      message = "Deprecated without replacement as an internal method never intended for public use",
      level = DeprecationLevel.ERROR
   )
   @Nullable
   Object delay(long var1, @NotNull Continuation<? super Unit> var3);

   void scheduleResumeAfterDelay(long var1, @NotNull CancellableContinuation<? super Unit> var3);

   @NotNull
   DisposableHandle invokeOnTimeout(long var1, @NotNull Runnable var3, @NotNull CoroutineContext var4);

   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public static final class DefaultImpls {
      /** @deprecated */
      @Deprecated(
         message = "Deprecated without replacement as an internal method never intended for public use",
         level = DeprecationLevel.ERROR
      )
      @Nullable
      public static Object delay(@NotNull Delay a, long a, @NotNull Continuation<? super Unit> a) {
         if (a <= 0L) {
            return Unit.INSTANCE;
         } else {
            int a = false;
            int a = false;
            CancellableContinuationImpl a = new CancellableContinuationImpl(IntrinsicsKt.intercepted(a), 1);
            a.initCancellability();
            CancellableContinuation a = (CancellableContinuation)a;
            int a = false;
            a.scheduleResumeAfterDelay(a, a);
            Object var10000 = a.getResult();
            if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
               DebugProbesKt.probeCoroutineSuspended(a);
            }

            return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
         }
      }

      @NotNull
      public static DisposableHandle invokeOnTimeout(@NotNull Delay a, long a, @NotNull Runnable a, @NotNull CoroutineContext a) {
         return DefaultExecutorKt.getDefaultDelay().invokeOnTimeout(a, a, a);
      }
   }
}
