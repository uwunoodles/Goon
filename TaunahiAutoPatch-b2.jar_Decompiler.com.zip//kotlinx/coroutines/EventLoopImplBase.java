package kotlinx.coroutines;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.JvmField;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlinx.coroutines.internal.LockFreeTaskQueueCore;
import kotlinx.coroutines.internal.ThreadSafeHeap;
import kotlinx.coroutines.internal.ThreadSafeHeapNode;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0013\n\u0002\u0018\u0002\n\u0002\u0018\u0002\b \u0018\u00002\u0002092\u00020::\u00044567B\u0007¢\u0006\u0004\b\u0001\u0010\u0002J\u000f\u0010\u0004\u001a\u00020\u0003H\u0002¢\u0006\u0004\b\u0004\u0010\u0002J\u0017\u0010\u0007\u001a\n\u0018\u00010\u0005j\u0004\u0018\u0001`\u0006H\u0002¢\u0006\u0004\b\u0007\u0010\bJ!\u0010\f\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\t2\n\u0010\u000b\u001a\u00060\u0005j\u0002`\u0006¢\u0006\u0004\b\f\u0010\rJ\u001b\u0010\u000f\u001a\u00020\u00032\n\u0010\u000e\u001a\u00060\u0005j\u0002`\u0006H\u0016¢\u0006\u0004\b\u000f\u0010\u0010J\u001b\u0010\u0012\u001a\u00020\u00112\n\u0010\u000e\u001a\u00060\u0005j\u0002`\u0006H\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0015\u001a\u00020\u0014H\u0016¢\u0006\u0004\b\u0015\u0010\u0016J\u000f\u0010\u0017\u001a\u00020\u0003H\u0002¢\u0006\u0004\b\u0017\u0010\u0002J\u000f\u0010\u0018\u001a\u00020\u0003H\u0004¢\u0006\u0004\b\u0018\u0010\u0002J\u001d\u0010\u001c\u001a\u00020\u00032\u0006\u0010\u0019\u001a\u00020\u00142\u0006\u0010\u001b\u001a\u00020\u001a¢\u0006\u0004\b\u001c\u0010\u001dJ\u001f\u0010\u001f\u001a\u00020\u001e2\u0006\u0010\u0019\u001a\u00020\u00142\u0006\u0010\u001b\u001a\u00020\u001aH\u0002¢\u0006\u0004\b\u001f\u0010 J#\u0010#\u001a\u00020\"2\u0006\u0010!\u001a\u00020\u00142\n\u0010\u000b\u001a\u00060\u0005j\u0002`\u0006H\u0004¢\u0006\u0004\b#\u0010$J%\u0010'\u001a\u00020\u00032\u0006\u0010!\u001a\u00020\u00142\f\u0010&\u001a\b\u0012\u0004\u0012\u00020\u00030%H\u0016¢\u0006\u0004\b'\u0010(J\u0017\u0010)\u001a\u00020\u00112\u0006\u0010\u000e\u001a\u00020\u001aH\u0002¢\u0006\u0004\b)\u0010*J\u000f\u0010+\u001a\u00020\u0003H\u0016¢\u0006\u0004\b+\u0010\u0002R$\u0010-\u001a\u00020\u00112\u0006\u0010,\u001a\u00020\u00118B@BX\u0082\u000e¢\u0006\f\u001a\u0004\b-\u0010.\"\u0004\b/\u00100R\u0014\u00101\u001a\u00020\u00118TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b1\u0010.R\u0014\u00103\u001a\u00020\u00148TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b2\u0010\u0016¨\u00068"},
   d2 = {"Lkotlinx/coroutines/EventLoopImplBase;", "EventLoopImplBase", "()V", "", "closeQueue", "Ljava/lang/Runnable;", "Lkotlinx/coroutines/Runnable;", "dequeue", "()Ljava/lang/Runnable;", "Lkotlin/coroutines/CoroutineContext;", "context", "block", "dispatch", "(Lkotlin/coroutines/CoroutineContext;Ljava/lang/Runnable;)V", "task", "enqueue", "(Ljava/lang/Runnable;)V", "", "enqueueImpl", "(Ljava/lang/Runnable;)Z", "", "processNextEvent", "()J", "rescheduleAllDelayed", "resetAll", "now", "Lkotlinx/coroutines/EventLoopImplBase$DelayedTask;", "delayedTask", "schedule", "(JLkotlinx/coroutines/EventLoopImplBase$DelayedTask;)V", "", "scheduleImpl", "(JLkotlinx/coroutines/EventLoopImplBase$DelayedTask;)I", "timeMillis", "Lkotlinx/coroutines/DisposableHandle;", "scheduleInvokeOnTimeout", "(JLjava/lang/Runnable;)Lkotlinx/coroutines/DisposableHandle;", "Lkotlinx/coroutines/CancellableContinuation;", "continuation", "scheduleResumeAfterDelay", "(JLkotlinx/coroutines/CancellableContinuation;)V", "shouldUnpark", "(Lkotlinx/coroutines/EventLoopImplBase$DelayedTask;)Z", "shutdown", "value", "isCompleted", "()Z", "setCompleted", "(Z)V", "isEmpty", "getNextTime", "nextTime", "DelayedResumeTask", "DelayedRunnableTask", "DelayedTask", "DelayedTaskQueue", "kotlinx-coroutines-core", "Lkotlinx/coroutines/EventLoopImplPlatform;", "Lkotlinx/coroutines/Delay;"}
)
public abstract class EventLoopImplBase extends EventLoopImplPlatform implements Delay {
   // $FF: synthetic field
   @NotNull
   private volatile Object _queue = null;
   // $FF: synthetic field
   private static final AtomicReferenceFieldUpdater _queue$FU = AtomicReferenceFieldUpdater.newUpdater(EventLoopImplBase.class, Object.class, "_queue");
   // $FF: synthetic field
   @NotNull
   private volatile Object _delayed = null;
   // $FF: synthetic field
   private static final AtomicReferenceFieldUpdater _delayed$FU = AtomicReferenceFieldUpdater.newUpdater(EventLoopImplBase.class, Object.class, "_delayed");
   // $FF: synthetic field
   @NotNull
   private volatile int _isCompleted = 0;

   private final boolean isCompleted() {
      return (boolean)a._isCompleted;
   }

   private final void setCompleted(boolean a) {
      a._isCompleted = a;
   }

   protected boolean isEmpty() {
      if (!a.isUnconfinedQueueEmpty()) {
         return false;
      } else {
         EventLoopImplBase.DelayedTaskQueue a = (EventLoopImplBase.DelayedTaskQueue)a._delayed;
         if (a != null && !a.isEmpty()) {
            return false;
         } else {
            Object a = a._queue;
            return a == null ? true : (a instanceof LockFreeTaskQueueCore ? ((LockFreeTaskQueueCore)a).isEmpty() : a == EventLoop_commonKt.access$getCLOSED_EMPTY$p());
         }
      }
   }

   protected long getNextTime() {
      if (super.getNextTime() == 0L) {
         return 0L;
      } else {
         Object a = a._queue;
         if (a != null) {
            if (!(a instanceof LockFreeTaskQueueCore)) {
               if (a == EventLoop_commonKt.access$getCLOSED_EMPTY$p()) {
                  return Long.MAX_VALUE;
               }

               return 0L;
            }

            if (!((LockFreeTaskQueueCore)a).isEmpty()) {
               return 0L;
            }
         }

         EventLoopImplBase.DelayedTaskQueue var10000 = (EventLoopImplBase.DelayedTaskQueue)a._delayed;
         if (var10000 != null) {
            EventLoopImplBase.DelayedTask var3 = (EventLoopImplBase.DelayedTask)var10000.peek();
            if (var3 != null) {
               EventLoopImplBase.DelayedTask a = var3;
               long var4 = a.nanoTime;
               AbstractTimeSource var10001 = AbstractTimeSourceKt.getTimeSource();
               return RangesKt.coerceAtLeast(var4 - (var10001 != null ? var10001.nanoTime() : System.nanoTime()), 0L);
            }
         }

         return Long.MAX_VALUE;
      }
   }

   public void shutdown() {
      ThreadLocalEventLoop.INSTANCE.resetEventLoop$kotlinx_coroutines_core();
      a.setCompleted(true);
      a.closeQueue();

      while(a.processNextEvent() <= 0L) {
      }

      a.rescheduleAllDelayed();
   }

   public void scheduleResumeAfterDelay(long a, @NotNull CancellableContinuation<? super Unit> a) {
      long a = EventLoop_commonKt.delayToNanos(a);
      if (a < 4611686018427387903L) {
         AbstractTimeSource var10000 = AbstractTimeSourceKt.getTimeSource();
         long a = var10000 != null ? var10000.nanoTime() : System.nanoTime();
         EventLoopImplBase.DelayedResumeTask var8 = new EventLoopImplBase.DelayedResumeTask(a + a, a);
         int a = false;
         a.schedule(a, (EventLoopImplBase.DelayedTask)var8);
         CancellableContinuationKt.disposeOnCancellation(a, (DisposableHandle)var8);
      }

   }

   @NotNull
   protected final DisposableHandle scheduleInvokeOnTimeout(long a, @NotNull Runnable a) {
      long a = EventLoop_commonKt.delayToNanos(a);
      DisposableHandle var11;
      if (a < 4611686018427387903L) {
         AbstractTimeSource var10000 = AbstractTimeSourceKt.getTimeSource();
         long a = var10000 != null ? var10000.nanoTime() : System.nanoTime();
         EventLoopImplBase.DelayedRunnableTask var8 = new EventLoopImplBase.DelayedRunnableTask(a + a, a);
         int a = false;
         a.schedule(a, (EventLoopImplBase.DelayedTask)var8);
         var11 = (DisposableHandle)var8;
      } else {
         var11 = (DisposableHandle)NonDisposableHandle.INSTANCE;
      }

      return var11;
   }

   public long processNextEvent() {
      if (a.processUnconfinedEvent()) {
         return 0L;
      } else {
         EventLoopImplBase.DelayedTaskQueue a = (EventLoopImplBase.DelayedTaskQueue)a._delayed;
         if (a != null && !a.isEmpty()) {
            AbstractTimeSource var10000 = AbstractTimeSourceKt.getTimeSource();
            long a = var10000 != null ? var10000.nanoTime() : System.nanoTime();

            ThreadSafeHeapNode var18;
            do {
               ThreadSafeHeap a = (ThreadSafeHeap)a;
               int a = false;
               int a = false;
               synchronized(a){}

               Object var10;
               label120: {
                  ThreadSafeHeapNode var14;
                  try {
                     int a = false;
                     var18 = a.firstImpl();
                     if (var18 == null) {
                        var10 = null;
                        break label120;
                     }

                     ThreadSafeHeapNode a = var18;
                     EventLoopImplBase.DelayedTask a = (EventLoopImplBase.DelayedTask)a;
                     int a = false;
                     var14 = (a.timeToExecute(a) ? a.enqueueImpl((Runnable)a) : false) ? a.removeAtImpl(0) : (ThreadSafeHeapNode)null;
                  } finally {
                     ;
                  }

                  var18 = var14;
                  continue;
               }

               var18 = (ThreadSafeHeapNode)var10;
            } while((EventLoopImplBase.DelayedTask)var18 != null);
         }

         Runnable a = a.dequeue();
         if (a != null) {
            int a = false;
            int a = false;
            a.run();
            return 0L;
         } else {
            return a.getNextTime();
         }
      }
   }

   public final void dispatch(@NotNull CoroutineContext a1, @NotNull Runnable a) {
      a.enqueue(a);
   }

   public void enqueue(@NotNull Runnable a) {
      if (a.enqueueImpl(a)) {
         a.unpark();
      } else {
         DefaultExecutor.INSTANCE.enqueue(a);
      }

   }

   private final boolean enqueueImpl(Runnable a) {
      EventLoopImplBase a = a;
      boolean var3 = false;

      while(true) {
         Object a = a._queue;
         int a = false;
         if (a.isCompleted()) {
            return false;
         }

         if (a == null) {
            if (_queue$FU.compareAndSet(a, (Object)null, a)) {
               return true;
            }
         } else if (a instanceof LockFreeTaskQueueCore) {
            if (a == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.internal.LockFreeTaskQueueCore<java.lang.Runnable{ kotlinx.coroutines.RunnableKt.Runnable }>{ kotlinx.coroutines.EventLoop_commonKt.Queue<java.lang.Runnable{ kotlinx.coroutines.RunnableKt.Runnable }> }");
            }

            switch(((LockFreeTaskQueueCore)a).addLast(a)) {
            case 0:
               return true;
            case 1:
               _queue$FU.compareAndSet(a, a, ((LockFreeTaskQueueCore)a).next());
               break;
            case 2:
               return false;
            }
         } else {
            if (a == EventLoop_commonKt.access$getCLOSED_EMPTY$p()) {
               return false;
            }

            LockFreeTaskQueueCore a = new LockFreeTaskQueueCore(8, true);
            if (a == null) {
               throw new NullPointerException("null cannot be cast to non-null type java.lang.Runnable{ kotlinx.coroutines.RunnableKt.Runnable }");
            }

            a.addLast((Runnable)a);
            a.addLast(a);
            if (_queue$FU.compareAndSet(a, a, a)) {
               return true;
            }
         }
      }
   }

   private final Runnable dequeue() {
      EventLoopImplBase a = a;
      boolean var2 = false;

      while(true) {
         Object a = a._queue;
         int a = false;
         if (a == null) {
            return null;
         }

         if (a instanceof LockFreeTaskQueueCore) {
            if (a == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.internal.LockFreeTaskQueueCore<java.lang.Runnable{ kotlinx.coroutines.RunnableKt.Runnable }>{ kotlinx.coroutines.EventLoop_commonKt.Queue<java.lang.Runnable{ kotlinx.coroutines.RunnableKt.Runnable }> }");
            }

            Object a = ((LockFreeTaskQueueCore)a).removeFirstOrNull();
            if (a != LockFreeTaskQueueCore.REMOVE_FROZEN) {
               return (Runnable)a;
            }

            _queue$FU.compareAndSet(a, a, ((LockFreeTaskQueueCore)a).next());
         } else {
            if (a == EventLoop_commonKt.access$getCLOSED_EMPTY$p()) {
               return null;
            }

            if (_queue$FU.compareAndSet(a, a, (Object)null)) {
               if (a == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.lang.Runnable{ kotlinx.coroutines.RunnableKt.Runnable }");
               }

               return (Runnable)a;
            }
         }
      }
   }

   private final void closeQueue() {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (!a.isCompleted()) {
            throw new AssertionError();
         }
      }

      EventLoopImplBase a = a;
      boolean var2 = false;

      while(true) {
         Object a = a._queue;
         int a = false;
         if (a == null) {
            if (_queue$FU.compareAndSet(a, (Object)null, EventLoop_commonKt.access$getCLOSED_EMPTY$p())) {
               return;
            }
         } else {
            if (a instanceof LockFreeTaskQueueCore) {
               ((LockFreeTaskQueueCore)a).close();
               return;
            }

            if (a == EventLoop_commonKt.access$getCLOSED_EMPTY$p()) {
               return;
            }

            LockFreeTaskQueueCore a = new LockFreeTaskQueueCore(8, true);
            if (a == null) {
               throw new NullPointerException("null cannot be cast to non-null type java.lang.Runnable{ kotlinx.coroutines.RunnableKt.Runnable }");
            }

            a.addLast((Runnable)a);
            if (_queue$FU.compareAndSet(a, a, a)) {
               return;
            }
         }
      }
   }

   public final void schedule(long a, @NotNull EventLoopImplBase.DelayedTask a) {
      switch(a.scheduleImpl(a, a)) {
      case 0:
         if (a.shouldUnpark(a)) {
            a.unpark();
         }
         break;
      case 1:
         a.reschedule(a, a);
      case 2:
         break;
      default:
         throw new IllegalStateException("unexpected result".toString());
      }

   }

   private final boolean shouldUnpark(EventLoopImplBase.DelayedTask a) {
      EventLoopImplBase.DelayedTaskQueue var10000 = (EventLoopImplBase.DelayedTaskQueue)a._delayed;
      return (var10000 != null ? (EventLoopImplBase.DelayedTask)var10000.peek() : null) == a;
   }

   private final int scheduleImpl(long a, EventLoopImplBase.DelayedTask a) {
      if (a.isCompleted()) {
         return 1;
      } else {
         EventLoopImplBase.DelayedTaskQueue var10000 = (EventLoopImplBase.DelayedTaskQueue)a._delayed;
         if (var10000 == null) {
            EventLoopImplBase a = (EventLoopImplBase)a;
            int a = false;
            _delayed$FU.compareAndSet(a, (Object)null, new EventLoopImplBase.DelayedTaskQueue(a));
            Object var7 = a._delayed;
            Intrinsics.checkNotNull(var7);
            var10000 = (EventLoopImplBase.DelayedTaskQueue)var7;
         }

         EventLoopImplBase.DelayedTaskQueue a = var10000;
         return a.scheduleTask(a, a, a);
      }
   }

   protected final void resetAll() {
      a._queue = null;
      a._delayed = null;
   }

   private final void rescheduleAllDelayed() {
      AbstractTimeSource var10000 = AbstractTimeSourceKt.getTimeSource();
      long a = var10000 != null ? var10000.nanoTime() : System.nanoTime();

      while(true) {
         EventLoopImplBase.DelayedTaskQueue var4 = (EventLoopImplBase.DelayedTaskQueue)a._delayed;
         if (var4 == null) {
            break;
         }

         EventLoopImplBase.DelayedTask var5 = (EventLoopImplBase.DelayedTask)var4.removeFirstOrNull();
         if (var5 == null) {
            break;
         }

         EventLoopImplBase.DelayedTask a = var5;
         a.reschedule(a, a);
      }

   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated without replacement as an internal method never intended for public use",
      level = DeprecationLevel.ERROR
   )
   @Nullable
   public Object delay(long a, @NotNull Continuation<? super Unit> a) {
      return Delay.DefaultImpls.delay(a, a, a);
   }

   @NotNull
   public DisposableHandle invokeOnTimeout(long a, @NotNull Runnable a, @NotNull CoroutineContext a) {
      return Delay.DefaultImpls.invokeOnTimeout(a, a, a, a);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\b \u0018\u00002\u00060\u0001j\u0002`\u00022\b\u0012\u0004\u0012\u00020\u00000\u00032\u00020\u00042\u00020\u0005B\r\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\u0011\u0010\u0018\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0000H\u0096\u0002J\u0006\u0010\u001a\u001a\u00020\u001bJ\u001e\u0010\u001c\u001a\u00020\u00132\u0006\u0010\u001d\u001a\u00020\u00072\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020!J\u000e\u0010\"\u001a\u00020#2\u0006\u0010\u001d\u001a\u00020\u0007J\b\u0010$\u001a\u00020%H\u0016R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R0\u0010\r\u001a\b\u0012\u0002\b\u0003\u0018\u00010\f2\f\u0010\u000b\u001a\b\u0012\u0002\b\u0003\u0018\u00010\f8V@VX\u0096\u000e¢\u0006\f\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0012\u001a\u00020\u0013X\u0096\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u0012\u0010\u0006\u001a\u00020\u00078\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000¨\u0006&"},
      d2 = {"Lkotlinx/coroutines/EventLoopImplBase$DelayedTask;", "Ljava/lang/Runnable;", "Lkotlinx/coroutines/Runnable;", "", "Lkotlinx/coroutines/DisposableHandle;", "Lkotlinx/coroutines/internal/ThreadSafeHeapNode;", "nanoTime", "", "(J)V", "_heap", "", "value", "Lkotlinx/coroutines/internal/ThreadSafeHeap;", "heap", "getHeap", "()Lkotlinx/coroutines/internal/ThreadSafeHeap;", "setHeap", "(Lkotlinx/coroutines/internal/ThreadSafeHeap;)V", "index", "", "getIndex", "()I", "setIndex", "(I)V", "compareTo", "other", "dispose", "", "scheduleTask", "now", "delayed", "Lkotlinx/coroutines/EventLoopImplBase$DelayedTaskQueue;", "eventLoop", "Lkotlinx/coroutines/EventLoopImplBase;", "timeToExecute", "", "toString", "", "kotlinx-coroutines-core"}
   )
   public abstract static class DelayedTask implements Runnable, Comparable<EventLoopImplBase.DelayedTask>, DisposableHandle, ThreadSafeHeapNode {
      @JvmField
      public long nanoTime;
      @Nullable
      private volatile Object _heap;
      private int index;

      public DelayedTask(long a) {
         a.nanoTime = a;
         a.index = -1;
      }

      @Nullable
      public ThreadSafeHeap<?> getHeap() {
         Object var1 = a._heap;
         return var1 instanceof ThreadSafeHeap ? (ThreadSafeHeap)var1 : null;
      }

      public void setHeap(@Nullable ThreadSafeHeap<?> a) {
         if (a._heap == EventLoop_commonKt.access$getDISPOSED_TASK$p()) {
            String var2 = "Failed requirement.";
            throw new IllegalArgumentException(var2.toString());
         } else {
            a._heap = a;
         }
      }

      public int getIndex() {
         return a.index;
      }

      public void setIndex(int a) {
         a.index = a;
      }

      public int compareTo(@NotNull EventLoopImplBase.DelayedTask a) {
         long a = a.nanoTime - a.nanoTime;
         return a > 0L ? 1 : (a < 0L ? -1 : 0);
      }

      public final boolean timeToExecute(long a) {
         return a - a.nanoTime >= 0L;
      }

      public final synchronized int scheduleTask(long a, @NotNull EventLoopImplBase.DelayedTaskQueue a, @NotNull EventLoopImplBase a) {
         if (a._heap == EventLoop_commonKt.access$getDISPOSED_TASK$p()) {
            return 2;
         } else {
            ThreadSafeHeap a = (ThreadSafeHeap)a;
            int a = false;
            int a = false;
            synchronized(a){}

            try {
               int a = false;
               EventLoopImplBase.DelayedTask a = (EventLoopImplBase.DelayedTask)a.firstImpl();
               int a = false;
               if (a.isCompleted()) {
                  byte var17 = 1;
                  return var17;
               }

               if (a == null) {
                  a.timeNow = a;
               } else {
                  long a = a.nanoTime;
                  long a = a - a >= 0L ? a : a;
                  if (a - a.timeNow > 0L) {
                     a.timeNow = a;
                  }
               }

               if (a.nanoTime - a.timeNow < 0L) {
                  a.nanoTime = a.timeNow;
               }

               boolean var10000;
               if (true) {
                  a.addImpl((ThreadSafeHeapNode)a);
                  var10000 = true;
               } else {
                  var10000 = false;
               }
            } finally {
               ;
            }

            return 0;
         }
      }

      public final synchronized void dispose() {
         Object a = a._heap;
         if (a != EventLoop_commonKt.access$getDISPOSED_TASK$p()) {
            EventLoopImplBase.DelayedTaskQueue var10000 = a instanceof EventLoopImplBase.DelayedTaskQueue ? (EventLoopImplBase.DelayedTaskQueue)a : null;
            if ((a instanceof EventLoopImplBase.DelayedTaskQueue ? (EventLoopImplBase.DelayedTaskQueue)a : null) != null) {
               var10000.remove((ThreadSafeHeapNode)a);
            }

            a._heap = EventLoop_commonKt.access$getDISPOSED_TASK$p();
         }
      }

      @NotNull
      public String toString() {
         return "Delayed[nanos=" + a.nanoTime + ']';
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0082\u0004\u0018\u00002\u00020\u0001B\u001b\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\u0002\u0010\u0007J\b\u0010\b\u001a\u00020\u0006H\u0016J\b\u0010\t\u001a\u00020\nH\u0016R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000b"},
      d2 = {"Lkotlinx/coroutines/EventLoopImplBase$DelayedResumeTask;", "Lkotlinx/coroutines/EventLoopImplBase$DelayedTask;", "nanoTime", "", "cont", "Lkotlinx/coroutines/CancellableContinuation;", "", "(Lkotlinx/coroutines/EventLoopImplBase;JLkotlinx/coroutines/CancellableContinuation;)V", "run", "toString", "", "kotlinx-coroutines-core"}
   )
   private final class DelayedResumeTask extends EventLoopImplBase.DelayedTask {
      @NotNull
      private final CancellableContinuation<Unit> cont;

      public DelayedResumeTask(long axxx, @NotNull CancellableContinuation<? super Unit> axx) {
         super(axxx);
         a.cont = axx;
      }

      public void run() {
         CancellableContinuation var1 = a.cont;
         EventLoopImplBase var2 = EventLoopImplBase.this;
         int ax = false;
         var1.resumeUndispatched((CoroutineDispatcher)var2, Unit.INSTANCE);
      }

      @NotNull
      public String toString() {
         return super.toString() + a.cont;
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\u0010\u0004\u001a\u00060\u0005j\u0002`\u0006¢\u0006\u0002\u0010\u0007J\b\u0010\b\u001a\u00020\tH\u0016J\b\u0010\n\u001a\u00020\u000bH\u0016R\u0012\u0010\u0004\u001a\u00060\u0005j\u0002`\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\f"},
      d2 = {"Lkotlinx/coroutines/EventLoopImplBase$DelayedRunnableTask;", "Lkotlinx/coroutines/EventLoopImplBase$DelayedTask;", "nanoTime", "", "block", "Ljava/lang/Runnable;", "Lkotlinx/coroutines/Runnable;", "(JLjava/lang/Runnable;)V", "run", "", "toString", "", "kotlinx-coroutines-core"}
   )
   private static final class DelayedRunnableTask extends EventLoopImplBase.DelayedTask {
      @NotNull
      private final Runnable block;

      public DelayedRunnableTask(long a, @NotNull Runnable a) {
         super(a);
         a.block = a;
      }

      public void run() {
         a.block.run();
      }

      @NotNull
      public String toString() {
         return super.toString() + a.block;
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\b\u0000\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\r\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005R\u0012\u0010\u0003\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000¨\u0006\u0006"},
      d2 = {"Lkotlinx/coroutines/EventLoopImplBase$DelayedTaskQueue;", "Lkotlinx/coroutines/internal/ThreadSafeHeap;", "Lkotlinx/coroutines/EventLoopImplBase$DelayedTask;", "timeNow", "", "(J)V", "kotlinx-coroutines-core"}
   )
   public static final class DelayedTaskQueue extends ThreadSafeHeap<EventLoopImplBase.DelayedTask> {
      @JvmField
      public long timeNow;

      public DelayedTaskQueue(long a) {
         a.timeNow = a;
      }
   }
}
