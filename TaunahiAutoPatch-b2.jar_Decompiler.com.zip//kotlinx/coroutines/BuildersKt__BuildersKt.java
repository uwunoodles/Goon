package kotlinx.coroutines;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.ContinuationInterceptor;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000\"\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001aT\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u00032'\u0010\u0004\u001a#\b\u0001\u0012\u0004\u0012\u00020\u0006\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00010\u0007\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0005¢\u0006\u0002\b\tø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0001¢\u0006\u0002\u0010\n\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u000b"},
   d2 = {"runBlocking", "T", "context", "Lkotlin/coroutines/CoroutineContext;", "block", "Lkotlin/Function2;", "Lkotlinx/coroutines/CoroutineScope;", "Lkotlin/coroutines/Continuation;", "", "Lkotlin/ExtensionFunctionType;", "(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;)Ljava/lang/Object;", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/BuildersKt"
)
final class BuildersKt__BuildersKt {
   public static final <T> T runBlocking(@NotNull CoroutineContext a, @NotNull Function2<? super CoroutineScope, ? super Continuation<? super T>, ? extends Object> a) throws InterruptedException {
      Thread a = Thread.currentThread();
      ContinuationInterceptor a = (ContinuationInterceptor)a.get((CoroutineContext.Key)ContinuationInterceptor.Key);
      EventLoop a = null;
      CoroutineContext a = null;
      if (a == null) {
         a = ThreadLocalEventLoop.INSTANCE.getEventLoop$kotlinx_coroutines_core();
         a = CoroutineContextKt.newCoroutineContext((CoroutineScope)GlobalScope.INSTANCE, a.plus((CoroutineContext)a));
      } else {
         EventLoop var10000;
         label23: {
            var10000 = a instanceof EventLoop ? (EventLoop)a : null;
            if ((a instanceof EventLoop ? (EventLoop)a : null) != null) {
               EventLoop var7 = var10000;
               int a = false;
               var10000 = var7.shouldBeProcessedFromContext() ? var7 : null;
               if (var10000 != null) {
                  break label23;
               }
            }

            var10000 = ThreadLocalEventLoop.INSTANCE.currentOrNull$kotlinx_coroutines_core();
         }

         a = var10000;
         a = CoroutineContextKt.newCoroutineContext((CoroutineScope)GlobalScope.INSTANCE, a);
      }

      BlockingCoroutine a = new BlockingCoroutine(a, a, a);
      a.start(CoroutineStart.DEFAULT, a, a);
      return a.joinBlocking();
   }

   // $FF: synthetic method
   public static Object runBlocking$default(CoroutineContext var0, Function2 var1, int var2, Object var3) throws InterruptedException {
      if ((var2 & 1) != 0) {
         var0 = (CoroutineContext)EmptyCoroutineContext.INSTANCE;
      }

      return BuildersKt.runBlocking(var0, var1);
   }
}
