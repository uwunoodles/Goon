package kotlinx.coroutines.channels;

import java.util.List;
import java.util.concurrent.CancellationException;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.ReplaceWith;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;
import kotlinx.coroutines.ExceptionsKt;
import kotlinx.coroutines.ObsoleteCoroutinesApi;
import kotlinx.coroutines.selects.SelectClause1;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000>\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0000\u001a\u001a\u0010\u0002\u001a\u00020\u0003*\u0006\u0012\u0002\b\u00030\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0001\u001aC\u0010\u0007\u001a\u0002H\b\"\u0004\b\u0000\u0010\t\"\u0004\b\u0001\u0010\b*\b\u0012\u0004\u0012\u0002H\t0\n2\u001d\u0010\u000b\u001a\u0019\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\t0\u0004\u0012\u0004\u0012\u0002H\b0\f¢\u0006\u0002\b\rH\u0087\b¢\u0006\u0002\u0010\u000e\u001aP\u0010\u0007\u001a\u0002H\b\"\u0004\b\u0000\u0010\t\"\u0004\b\u0001\u0010\b*\b\u0012\u0004\u0012\u0002H\t0\u00042\u001d\u0010\u000b\u001a\u0019\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\t0\u0004\u0012\u0004\u0012\u0002H\b0\f¢\u0006\u0002\b\rH\u0086\b\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0002\u0010\u000f\u001a5\u0010\u0010\u001a\u00020\u0003\"\u0004\b\u0000\u0010\t*\b\u0012\u0004\u0012\u0002H\t0\n2\u0012\u0010\u0011\u001a\u000e\u0012\u0004\u0012\u0002H\t\u0012\u0004\u0012\u00020\u00030\fH\u0087Hø\u0001\u0000¢\u0006\u0002\u0010\u0012\u001a5\u0010\u0010\u001a\u00020\u0003\"\u0004\b\u0000\u0010\t*\b\u0012\u0004\u0012\u0002H\t0\u00042\u0012\u0010\u0011\u001a\u000e\u0012\u0004\u0012\u0002H\t\u0012\u0004\u0012\u00020\u00030\fH\u0086Hø\u0001\u0000¢\u0006\u0002\u0010\u0013\u001a$\u0010\u0014\u001a\n\u0012\u0006\u0012\u0004\u0018\u0001H\t0\u0015\"\b\b\u0000\u0010\t*\u00020\u0016*\b\u0012\u0004\u0012\u0002H\t0\u0004H\u0007\u001a'\u0010\u0017\u001a\u0004\u0018\u0001H\t\"\b\b\u0000\u0010\t*\u00020\u0016*\b\u0012\u0004\u0012\u0002H\t0\u0004H\u0087@ø\u0001\u0000¢\u0006\u0002\u0010\u0018\u001a'\u0010\u0019\u001a\b\u0012\u0004\u0012\u0002H\t0\u001a\"\u0004\b\u0000\u0010\t*\b\u0012\u0004\u0012\u0002H\t0\u0004H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0018\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0080T¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001b"},
   d2 = {"DEFAULT_CLOSE_MESSAGE", "", "cancelConsumed", "", "Lkotlinx/coroutines/channels/ReceiveChannel;", "cause", "", "consume", "R", "E", "Lkotlinx/coroutines/channels/BroadcastChannel;", "block", "Lkotlin/Function1;", "Lkotlin/ExtensionFunctionType;", "(Lkotlinx/coroutines/channels/BroadcastChannel;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "(Lkotlinx/coroutines/channels/ReceiveChannel;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "consumeEach", "action", "(Lkotlinx/coroutines/channels/BroadcastChannel;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "(Lkotlinx/coroutines/channels/ReceiveChannel;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "onReceiveOrNull", "Lkotlinx/coroutines/selects/SelectClause1;", "", "receiveOrNull", "(Lkotlinx/coroutines/channels/ReceiveChannel;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "toList", "", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/channels/ChannelsKt"
)
final class ChannelsKt__Channels_commonKt {
   @ObsoleteCoroutinesApi
   public static final <E, R> R consume(@NotNull BroadcastChannel<E> a, @NotNull Function1<? super ReceiveChannel<? extends E>, ? extends R> a) {
      int a = false;
      ReceiveChannel a = a.openSubscription();

      Object var4;
      try {
         var4 = a.invoke(a);
      } finally {
         InlineMarker.finallyStart(1);
         ReceiveChannel.DefaultImpls.cancel$default(a, (CancellationException)null, 1, (Object)null);
         InlineMarker.finallyEnd(1);
      }

      return var4;
   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in the favour of 'receiveCatching'",
      replaceWith = @ReplaceWith(
   expression = "receiveCatching().getOrNull()",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @Nullable
   public static final <E> Object receiveOrNull(@NotNull ReceiveChannel<? extends E> a, @NotNull Continuation<? super E> a) {
      return a.receiveOrNull(a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in the favour of 'onReceiveCatching'",
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <E> SelectClause1<E> onReceiveOrNull(@NotNull ReceiveChannel<? extends E> a) {
      return a.getOnReceiveOrNull();
   }

   public static final <E, R> R consume(@NotNull ReceiveChannel<? extends E> a, @NotNull Function1<? super ReceiveChannel<? extends E>, ? extends R> a) {
      int a = false;
      Throwable a = null;

      Object var4;
      try {
         var4 = a.invoke(a);
      } catch (Throwable var7) {
         a = var7;
         throw var7;
      } finally {
         InlineMarker.finallyStart(1);
         ChannelsKt.cancelConsumed(a, a);
         InlineMarker.finallyEnd(1);
      }

      return var4;
   }

   @Nullable
   public static final <E> Object consumeEach(@NotNull ReceiveChannel<? extends E> param0, @NotNull Function1<? super E, Unit> param1, @NotNull Continuation<? super Unit> param2) {
      // $FF: Couldn't be decompiled
   }

   private static final <E> Object consumeEach$$forInline(ReceiveChannel<? extends E> a, Function1<? super E, Unit> a, Continuation<? super Unit> a2) {
      int a = false;
      ReceiveChannel a = a;
      int a = false;
      Throwable a = null;

      try {
         int a = false;
         ChannelIterator var9 = a.iterator();

         while(true) {
            InlineMarker.mark(3);
            InlineMarker.mark(0);
            Object var10000 = var9.hasNext((Continuation)null);
            InlineMarker.mark(1);
            if (!(Boolean)var10000) {
               Unit var7 = Unit.INSTANCE;
               return Unit.INSTANCE;
            }

            Object a = var9.next();
            a.invoke(a);
         }
      } catch (Throwable var13) {
         a = var13;
         throw var13;
      } finally {
         InlineMarker.finallyStart(1);
         ChannelsKt.cancelConsumed(a, a);
         InlineMarker.finallyEnd(1);
      }
   }

   @Nullable
   public static final <E> Object toList(@NotNull ReceiveChannel<? extends E> param0, @NotNull Continuation<? super List<? extends E>> param1) {
      // $FF: Couldn't be decompiled
   }

   @ObsoleteCoroutinesApi
   @Nullable
   public static final <E> Object consumeEach(@NotNull BroadcastChannel<E> param0, @NotNull Function1<? super E, Unit> param1, @NotNull Continuation<? super Unit> param2) {
      // $FF: Couldn't be decompiled
   }

   @ObsoleteCoroutinesApi
   private static final <E> Object consumeEach$$forInline(BroadcastChannel<E> a, Function1<? super E, Unit> a, Continuation<? super Unit> a2) {
      int a = false;
      int a = false;
      ReceiveChannel a = a.openSubscription();

      try {
         int a = false;
         ChannelIterator var9 = a.iterator();

         while(true) {
            InlineMarker.mark(3);
            InlineMarker.mark(0);
            Object var10000 = var9.hasNext((Continuation)null);
            InlineMarker.mark(1);
            if (!(Boolean)var10000) {
               Unit var7 = Unit.INSTANCE;
               return Unit.INSTANCE;
            }

            Object a = var9.next();
            a.invoke(a);
         }
      } finally {
         InlineMarker.finallyStart(1);
         ReceiveChannel.DefaultImpls.cancel$default(a, (CancellationException)null, 1, (Object)null);
         InlineMarker.finallyEnd(1);
      }
   }

   @PublishedApi
   public static final void cancelConsumed(@NotNull ReceiveChannel<?> a, @Nullable Throwable a) {
      ReceiveChannel var10000 = a;
      CancellationException var10001;
      if (a != null) {
         int a = false;
         CancellationException var5 = a instanceof CancellationException ? (CancellationException)a : null;
         if ((a instanceof CancellationException ? (CancellationException)a : null) == null) {
            var5 = ExceptionsKt.CancellationException("Channel was consumed, consumer had failed", a);
         }

         var10001 = var5;
         var10000 = a;
      } else {
         var10001 = null;
      }

      var10000.cancel(var10001);
   }
}
