package kotlinx.coroutines.channels;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.ExceptionsKt;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.PublishedApi;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.IndexedValue;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.GlobalScope;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000 \u0001\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u001f\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010$\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010%\n\u0002\b\u0002\n\u0002\u0010!\n\u0000\n\u0002\u0010#\n\u0000\n\u0002\u0010\"\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\u001aJ\u0010\u0000\u001a#\u0012\u0015\u0012\u0013\u0018\u00010\u0002¢\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\u0005\u0012\u0004\u0012\u00020\u00060\u0001j\u0002`\u00072\u001a\u0010\b\u001a\u000e\u0012\n\b\u0001\u0012\u0006\u0012\u0002\b\u00030\n0\t\"\u0006\u0012\u0002\b\u00030\nH\u0001¢\u0006\u0002\u0010\u000b\u001a!\u0010\f\u001a\u00020\r\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010\u000f\u001a1\u0010\u0010\u001a#\u0012\u0015\u0012\u0013\u0018\u00010\u0002¢\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\u0005\u0012\u0004\u0012\u00020\u00060\u0001j\u0002`\u0007*\u0006\u0012\u0002\b\u00030\nH\u0001\u001a!\u0010\u0011\u001a\u00020\u0012\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010\u000f\u001a\u001e\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0007\u001aZ\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e\"\u0004\b\u0001\u0010\u0015*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172\"\u0010\u0018\u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00150\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0001ø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001a0\u0010\u001d\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u0010\u001e\u001a\u00020\u00122\b\b\u0002\u0010\u0016\u001a\u00020\u0017H\u0007\u001aT\u0010\u001f\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172\"\u0010 \u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0007ø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001a)\u0010!\u001a\u0002H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u0010\"\u001a\u00020\u0012H\u0087@ø\u0001\u0000¢\u0006\u0002\u0010#\u001a+\u0010$\u001a\u0004\u0018\u0001H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u0010\"\u001a\u00020\u0012H\u0087@ø\u0001\u0000¢\u0006\u0002\u0010#\u001aT\u0010%\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172\"\u0010 \u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0001ø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001ai\u0010&\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u001727\u0010 \u001a3\b\u0001\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\"\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0'H\u0007ø\u0001\u0000¢\u0006\u0002\u0010(\u001aT\u0010)\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172\"\u0010 \u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0007ø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001a$\u0010*\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\b\b\u0000\u0010\u000e*\u00020\u001b*\n\u0012\u0006\u0012\u0004\u0018\u0001H\u000e0\nH\u0001\u001aA\u0010+\u001a\u0002H,\"\b\b\u0000\u0010\u000e*\u00020\u001b\"\u0010\b\u0001\u0010,*\n\u0012\u0006\b\u0000\u0012\u0002H\u000e0-*\n\u0012\u0006\u0012\u0004\u0018\u0001H\u000e0\n2\u0006\u0010.\u001a\u0002H,H\u0087@ø\u0001\u0000¢\u0006\u0002\u0010/\u001a?\u0010+\u001a\u0002H,\"\b\b\u0000\u0010\u000e*\u00020\u001b\"\u000e\b\u0001\u0010,*\b\u0012\u0004\u0012\u0002H\u000e00*\n\u0012\u0006\u0012\u0004\u0018\u0001H\u000e0\n2\u0006\u0010.\u001a\u0002H,H\u0087@ø\u0001\u0000¢\u0006\u0002\u00101\u001a!\u00102\u001a\u0002H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010\u000f\u001a#\u00103\u001a\u0004\u0018\u0001H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010\u000f\u001a`\u00104\u001a\b\u0012\u0004\u0012\u0002H50\n\"\u0004\b\u0000\u0010\u000e\"\u0004\b\u0001\u00105*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172(\u00106\u001a$\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H50\n0\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0007ø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001a)\u00107\u001a\u00020\u0012\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u00108\u001a\u0002H\u000eH\u0087@ø\u0001\u0000¢\u0006\u0002\u00109\u001a!\u0010:\u001a\u0002H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010\u000f\u001a)\u0010;\u001a\u00020\u0012\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u00108\u001a\u0002H\u000eH\u0087@ø\u0001\u0000¢\u0006\u0002\u00109\u001a#\u0010<\u001a\u0004\u0018\u0001H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010\u000f\u001aZ\u0010=\u001a\b\u0012\u0004\u0012\u0002H50\n\"\u0004\b\u0000\u0010\u000e\"\u0004\b\u0001\u00105*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172\"\u00106\u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H50\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0001ø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001ao\u0010>\u001a\b\u0012\u0004\u0012\u0002H50\n\"\u0004\b\u0000\u0010\u000e\"\u0004\b\u0001\u00105*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u001727\u00106\u001a3\b\u0001\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\"\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H50\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0'H\u0001ø\u0001\u0000¢\u0006\u0002\u0010(\u001au\u0010?\u001a\b\u0012\u0004\u0012\u0002H50\n\"\u0004\b\u0000\u0010\u000e\"\b\b\u0001\u00105*\u00020\u001b*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u001729\u00106\u001a5\b\u0001\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\"\u0012\u0004\u0012\u0002H\u000e\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u0001H50\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0'H\u0007ø\u0001\u0000¢\u0006\u0002\u0010(\u001a`\u0010@\u001a\b\u0012\u0004\u0012\u0002H50\n\"\u0004\b\u0000\u0010\u000e\"\b\b\u0001\u00105*\u00020\u001b*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172$\u00106\u001a \b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u0001H50\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0007ø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001a?\u0010A\u001a\u0004\u0018\u0001H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u001a\u0010B\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\u000e0Cj\n\u0012\u0006\b\u0000\u0012\u0002H\u000e`DH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010E\u001a?\u0010F\u001a\u0004\u0018\u0001H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u001a\u0010B\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\u000e0Cj\n\u0012\u0006\b\u0000\u0012\u0002H\u000e`DH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010E\u001a!\u0010G\u001a\u00020\r\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010\u000f\u001a$\u0010H\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\b\b\u0000\u0010\u000e*\u00020\u001b*\n\u0012\u0006\u0012\u0004\u0018\u0001H\u000e0\nH\u0007\u001a!\u0010I\u001a\u0002H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010\u000f\u001a#\u0010J\u001a\u0004\u0018\u0001H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010\u000f\u001a0\u0010K\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u0010\u001e\u001a\u00020\u00122\b\b\u0002\u0010\u0016\u001a\u00020\u0017H\u0007\u001aT\u0010L\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172\"\u0010 \u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0007ø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001a9\u0010M\u001a\u0002H,\"\u0004\b\u0000\u0010\u000e\"\u000e\b\u0001\u0010,*\b\u0012\u0004\u0012\u0002H\u000e00*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u0010.\u001a\u0002H,H\u0081@ø\u0001\u0000¢\u0006\u0002\u00101\u001a;\u0010N\u001a\u0002H,\"\u0004\b\u0000\u0010\u000e\"\u0010\b\u0001\u0010,*\n\u0012\u0006\b\u0000\u0012\u0002H\u000e0-*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u0010.\u001a\u0002H,H\u0081@ø\u0001\u0000¢\u0006\u0002\u0010/\u001a?\u0010O\u001a\u000e\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002HQ0P\"\u0004\b\u0000\u0010\u0015\"\u0004\b\u0001\u0010Q*\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002HQ0R0\nH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010\u000f\u001aU\u0010O\u001a\u0002HS\"\u0004\b\u0000\u0010\u0015\"\u0004\b\u0001\u0010Q\"\u0018\b\u0002\u0010S*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0015\u0012\u0006\b\u0000\u0012\u0002HQ0T*\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002HQ0R0\n2\u0006\u0010.\u001a\u0002HSH\u0081@ø\u0001\u0000¢\u0006\u0002\u0010U\u001a'\u0010V\u001a\b\u0012\u0004\u0012\u0002H\u000e0W\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010\u000f\u001a'\u0010X\u001a\b\u0012\u0004\u0012\u0002H\u000e0Y\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0081@ø\u0001\u0000¢\u0006\u0002\u0010\u000f\u001a'\u0010Z\u001a\b\u0012\u0004\u0012\u0002H\u000e0[\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@ø\u0001\u0000¢\u0006\u0002\u0010\u000f\u001a.\u0010\\\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u000e0]0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u0017H\u0007\u001a?\u0010^\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u000e\u0012\u0004\u0012\u0002H50R0\n\"\u0004\b\u0000\u0010\u000e\"\u0004\b\u0001\u00105*\b\u0012\u0004\u0012\u0002H\u000e0\n2\f\u0010_\u001a\b\u0012\u0004\u0012\u0002H50\nH\u0087\u0004\u001az\u0010^\u001a\b\u0012\u0004\u0012\u0002HQ0\n\"\u0004\b\u0000\u0010\u000e\"\u0004\b\u0001\u00105\"\u0004\b\u0002\u0010Q*\b\u0012\u0004\u0012\u0002H\u000e0\n2\f\u0010_\u001a\b\u0012\u0004\u0012\u0002H50\n2\b\b\u0002\u0010\u0016\u001a\u00020\u001726\u00106\u001a2\u0012\u0013\u0012\u0011H\u000e¢\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(`\u0012\u0013\u0012\u0011H5¢\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(a\u0012\u0004\u0012\u0002HQ0\u0019H\u0001\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006b"},
   d2 = {"consumesAll", "Lkotlin/Function1;", "", "Lkotlin/ParameterName;", "name", "cause", "", "Lkotlinx/coroutines/CompletionHandler;", "channels", "", "Lkotlinx/coroutines/channels/ReceiveChannel;", "([Lkotlinx/coroutines/channels/ReceiveChannel;)Lkotlin/jvm/functions/Function1;", "any", "", "E", "(Lkotlinx/coroutines/channels/ReceiveChannel;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "consumes", "count", "", "distinct", "distinctBy", "K", "context", "Lkotlin/coroutines/CoroutineContext;", "selector", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "(Lkotlinx/coroutines/channels/ReceiveChannel;Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/channels/ReceiveChannel;", "drop", "n", "dropWhile", "predicate", "elementAt", "index", "(Lkotlinx/coroutines/channels/ReceiveChannel;ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "elementAtOrNull", "filter", "filterIndexed", "Lkotlin/Function3;", "(Lkotlinx/coroutines/channels/ReceiveChannel;Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function3;)Lkotlinx/coroutines/channels/ReceiveChannel;", "filterNot", "filterNotNull", "filterNotNullTo", "C", "", "destination", "(Lkotlinx/coroutines/channels/ReceiveChannel;Ljava/util/Collection;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Lkotlinx/coroutines/channels/SendChannel;", "(Lkotlinx/coroutines/channels/ReceiveChannel;Lkotlinx/coroutines/channels/SendChannel;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "first", "firstOrNull", "flatMap", "R", "transform", "indexOf", "element", "(Lkotlinx/coroutines/channels/ReceiveChannel;Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "last", "lastIndexOf", "lastOrNull", "map", "mapIndexed", "mapIndexedNotNull", "mapNotNull", "maxWith", "comparator", "Ljava/util/Comparator;", "Lkotlin/Comparator;", "(Lkotlinx/coroutines/channels/ReceiveChannel;Ljava/util/Comparator;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "minWith", "none", "requireNoNulls", "single", "singleOrNull", "take", "takeWhile", "toChannel", "toCollection", "toMap", "", "V", "Lkotlin/Pair;", "M", "", "(Lkotlinx/coroutines/channels/ReceiveChannel;Ljava/util/Map;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "toMutableList", "", "toMutableSet", "", "toSet", "", "withIndex", "Lkotlin/collections/IndexedValue;", "zip", "other", "a", "b", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/channels/ChannelsKt"
)
final class ChannelsKt__DeprecatedKt {
   @PublishedApi
   @NotNull
   public static final Function1<Throwable, Unit> consumesAll(@NotNull final ReceiveChannel<?>... a) {
      return (Function1)(new Function1<Throwable, Unit>() {
         public final void invoke(@Nullable Throwable axxxx) {
            Throwable axxxxx = null;
            ReceiveChannel[] var3 = a;
            int var4 = 0;

            for(int var5 = var3.length; var4 < var5; ++var4) {
               ReceiveChannel axxx = var3[var4];

               try {
                  ChannelsKt.cancelConsumed(axxx, axxxx);
               } catch (Throwable var10) {
                  if (axxxxx == null) {
                     axxxxx = var10;
                  } else {
                     int axxxxxx = false;
                     ExceptionsKt.addSuppressed(axxxxx, var10);
                  }
               }
            }

            if (axxxxx != null) {
               int axx = false;
               throw axxxxx;
            }
         }
      });
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object elementAt(ReceiveChannel param0, int param1, Continuation param2) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object elementAtOrNull(ReceiveChannel param0, int param1, Continuation param2) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object first(ReceiveChannel param0, Continuation param1) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object firstOrNull(ReceiveChannel param0, Continuation param1) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object indexOf(ReceiveChannel param0, Object param1, Continuation param2) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object last(ReceiveChannel param0, Continuation param1) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object lastIndexOf(ReceiveChannel param0, Object param1, Continuation param2) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object lastOrNull(ReceiveChannel param0, Continuation param1) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object single(ReceiveChannel param0, Continuation param1) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object singleOrNull(ReceiveChannel param0, Continuation param1) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel drop(final ReceiveChannel a, final int a, CoroutineContext a) {
      return ProduceKt.produce$default((CoroutineScope)GlobalScope.INSTANCE, a, 0, (CoroutineStart)null, ChannelsKt.consumes(a), (Function2)(new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         int I$0;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            ProducerScope axxx;
            ChannelIterator var4;
            Object axxxxx;
            Object var6;
            Object var10000;
            Continuation var10001;
            Continuation var10002;
            label81: {
               var6 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
               int axxxx;
               switch(ax.label) {
               case 0:
                  ResultKt.throwOnFailure(axx);
                  axxx = (ProducerScope)ax.L$0;
                  boolean var7 = a >= 0;
                  int var8 = a;
                  if (!var7) {
                     int axxxxxx = false;
                     String var10 = "Requested element count " + var8 + " is less than zero.";
                     throw new IllegalArgumentException(var10.toString());
                  }

                  axxxx = a;
                  if (axxxx <= 0) {
                     var4 = a.iterator();
                     break label81;
                  }

                  var4 = a.iterator();
                  var10001 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = var4;
                  ax.I$0 = axxxx;
                  ax.label = 1;
                  var10000 = var4.hasNext(var10001);
                  if (var10000 == var6) {
                     return var6;
                  }
                  break;
               case 1:
                  axxxx = ax.I$0;
                  var4 = (ChannelIterator)ax.L$1;
                  axxx = (ProducerScope)ax.L$0;
                  ResultKt.throwOnFailure(axx);
                  var10000 = axx;
                  break;
               case 2:
                  var4 = (ChannelIterator)ax.L$1;
                  axxx = (ProducerScope)ax.L$0;
                  ResultKt.throwOnFailure(axx);
                  if (!(Boolean)axx) {
                     return Unit.INSTANCE;
                  }

                  axxxxx = var4.next();
                  var10002 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = var4;
                  ax.label = 3;
                  if (axxx.send(axxxxx, var10002) == var6) {
                     return var6;
                  }
                  break label81;
               case 3:
                  var4 = (ChannelIterator)ax.L$1;
                  axxx = (ProducerScope)ax.L$0;
                  ResultKt.throwOnFailure(axx);
                  break label81;
               default:
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
               }

               while(true) {
                  if (!(Boolean)var10000) {
                     var4 = a.iterator();
                     break;
                  }

                  var4.next();
                  --axxxx;
                  if (axxxx == 0) {
                     var4 = a.iterator();
                     break;
                  }

                  var10001 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = var4;
                  ax.I$0 = axxxx;
                  ax.label = 1;
                  var10000 = var4.hasNext(var10001);
                  if (var10000 == var6) {
                     return var6;
                  }
               }
            }

            do {
               var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.label = 2;
               var10000 = var4.hasNext(var10001);
               if (var10000 == var6) {
                  return var6;
               }

               if (!(Boolean)var10000) {
                  return Unit.INSTANCE;
               }

               axxxxx = var4.next();
               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.label = 3;
            } while(axxx.send(axxxxx, var10002) != var6);

            return var6;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super E> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 6, (Object)null);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel drop$default(ReceiveChannel var0, int var1, CoroutineContext var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.drop(var0, var1, var2);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel dropWhile(final ReceiveChannel a, CoroutineContext a, final Function2 a) {
      return ProduceKt.produce$default((CoroutineScope)GlobalScope.INSTANCE, a, 0, (CoroutineStart)null, ChannelsKt.consumes(a), (Function2)(new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         Object L$2;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var10000;
            Continuation var10001;
            ProducerScope axxx;
            Continuation var10002;
            ChannelIterator var3;
            Object axxxx;
            Object var5;
            label105: {
               var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
               switch(ax.label) {
               case 0:
                  ResultKt.throwOnFailure(axx);
                  axxx = (ProducerScope)ax.L$0;
                  var3 = a.iterator();
                  var10001 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = var3;
                  ax.L$2 = null;
                  ax.label = 1;
                  var10000 = var3.hasNext(var10001);
                  if (var10000 == var5) {
                     return var5;
                  }
                  break;
               case 1:
                  var3 = (ChannelIterator)ax.L$1;
                  axxx = (ProducerScope)ax.L$0;
                  ResultKt.throwOnFailure(axx);
                  var10000 = axx;
                  break;
               case 2:
                  axxxx = ax.L$2;
                  var3 = (ChannelIterator)ax.L$1;
                  axxx = (ProducerScope)ax.L$0;
                  ResultKt.throwOnFailure(axx);
                  if (!(Boolean)axx) {
                     var10002 = (Continuation)ax;
                     ax.L$0 = axxx;
                     ax.L$1 = null;
                     ax.L$2 = null;
                     ax.label = 3;
                     if (axxx.send(axxxx, var10002) == var5) {
                        return var5;
                     }

                     var3 = a.iterator();
                     break label105;
                  }

                  var10001 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = var3;
                  ax.L$2 = null;
                  ax.label = 1;
                  var10000 = var3.hasNext(var10001);
                  if (var10000 == var5) {
                     return var5;
                  }
                  break;
               case 3:
                  axxx = (ProducerScope)ax.L$0;
                  ResultKt.throwOnFailure(axx);
                  var3 = a.iterator();
                  break label105;
               case 4:
                  var3 = (ChannelIterator)ax.L$1;
                  axxx = (ProducerScope)ax.L$0;
                  ResultKt.throwOnFailure(axx);
                  if (!(Boolean)axx) {
                     return Unit.INSTANCE;
                  }

                  axxxx = var3.next();
                  var10002 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = var3;
                  ax.label = 5;
                  if (axxx.send(axxxx, var10002) == var5) {
                     return var5;
                  }
                  break label105;
               case 5:
                  var3 = (ChannelIterator)ax.L$1;
                  axxx = (ProducerScope)ax.L$0;
                  ResultKt.throwOnFailure(axx);
                  break label105;
               default:
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
               }

               while(true) {
                  if (!(Boolean)var10000) {
                     var3 = a.iterator();
                     break;
                  }

                  axxxx = var3.next();
                  Function2 var6 = a;
                  ax.L$0 = axxx;
                  ax.L$1 = var3;
                  ax.L$2 = axxxx;
                  ax.label = 2;
                  var10000 = var6.invoke(axxxx, ax);
                  if (var10000 == var5) {
                     return var5;
                  }

                  if (!(Boolean)var10000) {
                     var10002 = (Continuation)ax;
                     ax.L$0 = axxx;
                     ax.L$1 = null;
                     ax.L$2 = null;
                     ax.label = 3;
                     if (axxx.send(axxxx, var10002) == var5) {
                        return var5;
                     }

                     var3 = a.iterator();
                     break;
                  }

                  var10001 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = var3;
                  ax.L$2 = null;
                  ax.label = 1;
                  var10000 = var3.hasNext(var10001);
                  if (var10000 == var5) {
                     return var5;
                  }
               }
            }

            do {
               var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 4;
               var10000 = var3.hasNext(var10001);
               if (var10000 == var5) {
                  return var5;
               }

               if (!(Boolean)var10000) {
                  return Unit.INSTANCE;
               }

               axxxx = var3.next();
               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 5;
            } while(axxx.send(axxxx, var10002) != var5);

            return var5;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super E> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 6, (Object)null);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel dropWhile$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.dropWhile(var0, var1, var2);
   }

   @PublishedApi
   @NotNull
   public static final <E> ReceiveChannel<E> filter(@NotNull final ReceiveChannel<? extends E> a, @NotNull CoroutineContext a, @NotNull final Function2<? super E, ? super Continuation<? super Boolean>, ? extends Object> a) {
      return ProduceKt.produce$default((CoroutineScope)GlobalScope.INSTANCE, a, 0, (CoroutineStart)null, ChannelsKt.consumes(a), (Function2)(new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         Object L$2;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            Function2 var10000;
            ProducerScope axxx;
            Continuation var10002;
            ChannelIterator var3;
            Object axxxx;
            Object var6;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               axxx = (ProducerScope)ax.L$0;
               var3 = a.iterator();
               break;
            case 1:
               var3 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               if (!(Boolean)axx) {
                  return Unit.INSTANCE;
               }

               axxxx = var3.next();
               var10000 = a;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.L$2 = axxxx;
               ax.label = 2;
               var6 = var10000.invoke(axxxx, ax);
               if (var6 == var5) {
                  return var5;
               }

               if ((Boolean)var6) {
                  var10002 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = var3;
                  ax.L$2 = null;
                  ax.label = 3;
                  if (axxx.send(axxxx, var10002) == var5) {
                     return var5;
                  }
               }
               break;
            case 2:
               axxxx = ax.L$2;
               var3 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               if ((Boolean)axx) {
                  var10002 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = var3;
                  ax.L$2 = null;
                  ax.label = 3;
                  if (axxx.send(axxxx, var10002) == var5) {
                     return var5;
                  }
               }
               break;
            case 3:
               var3 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            while(true) {
               Continuation var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.L$2 = null;
               ax.label = 1;
               var6 = var3.hasNext(var10001);
               if (var6 == var5) {
                  return var5;
               }

               if (!(Boolean)var6) {
                  return Unit.INSTANCE;
               }

               axxxx = var3.next();
               var10000 = a;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.L$2 = axxxx;
               ax.label = 2;
               var6 = var10000.invoke(axxxx, ax);
               if (var6 == var5) {
                  return var5;
               }

               if ((Boolean)var6) {
                  var10002 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = var3;
                  ax.L$2 = null;
                  ax.label = 3;
                  if (axxx.send(axxxx, var10002) == var5) {
                     return var5;
                  }
               }
            }
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super E> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 6, (Object)null);
   }

   // $FF: synthetic method
   public static ReceiveChannel filter$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.filter(var0, var1, var2);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel filterIndexed(final ReceiveChannel a, CoroutineContext a, final Function3 a) {
      return ProduceKt.produce$default((CoroutineScope)GlobalScope.INSTANCE, a, 0, (CoroutineStart)null, ChannelsKt.consumes(a), (Function2)(new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         Object L$2;
         int I$0;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var6 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            Function3 var10000;
            ProducerScope axxx;
            Continuation var10002;
            int axxxx;
            ChannelIterator var4;
            Object axxxxx;
            Object var7;
            Integer var8;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               axxx = (ProducerScope)ax.L$0;
               axxxx = 0;
               var4 = a.iterator();
               break;
            case 1:
               axxxx = ax.I$0;
               var4 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               if (!(Boolean)axx) {
                  return Unit.INSTANCE;
               }

               axxxxx = var4.next();
               var10000 = a;
               var8 = Boxing.boxInt(axxxx++);
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.L$2 = axxxxx;
               ax.I$0 = axxxx;
               ax.label = 2;
               var7 = var10000.invoke(var8, axxxxx, ax);
               if (var7 == var6) {
                  return var6;
               }

               if ((Boolean)var7) {
                  var10002 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = var4;
                  ax.L$2 = null;
                  ax.I$0 = axxxx;
                  ax.label = 3;
                  if (axxx.send(axxxxx, var10002) == var6) {
                     return var6;
                  }
               }
               break;
            case 2:
               axxxx = ax.I$0;
               axxxxx = ax.L$2;
               var4 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               if ((Boolean)axx) {
                  var10002 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = var4;
                  ax.L$2 = null;
                  ax.I$0 = axxxx;
                  ax.label = 3;
                  if (axxx.send(axxxxx, var10002) == var6) {
                     return var6;
                  }
               }
               break;
            case 3:
               axxxx = ax.I$0;
               var4 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            while(true) {
               Continuation var9 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.L$2 = null;
               ax.I$0 = axxxx;
               ax.label = 1;
               var7 = var4.hasNext(var9);
               if (var7 == var6) {
                  return var6;
               }

               if (!(Boolean)var7) {
                  return Unit.INSTANCE;
               }

               axxxxx = var4.next();
               var10000 = a;
               var8 = Boxing.boxInt(axxxx++);
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.L$2 = axxxxx;
               ax.I$0 = axxxx;
               ax.label = 2;
               var7 = var10000.invoke(var8, axxxxx, ax);
               if (var7 == var6) {
                  return var6;
               }

               if ((Boolean)var7) {
                  var10002 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = var4;
                  ax.L$2 = null;
                  ax.I$0 = axxxx;
                  ax.label = 3;
                  if (axxx.send(axxxxx, var10002) == var6) {
                     return var6;
                  }
               }
            }
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super E> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 6, (Object)null);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel filterIndexed$default(ReceiveChannel var0, CoroutineContext var1, Function3 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.filterIndexed(var0, var1, var2);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel filterNot(ReceiveChannel a, CoroutineContext a, final Function2 a) {
      return ChannelsKt.filter(a, a, (Function2)(new Function2<E, Continuation<? super Boolean>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            Object var10000;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               Object axxx = ax.L$0;
               Function2 var4 = a;
               ax.label = 1;
               var10000 = var4.invoke(axxx, ax);
               if (var10000 == var3) {
                  return var3;
               }
               break;
            case 1:
               ResultKt.throwOnFailure(axx);
               var10000 = axx;
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            return Boxing.boxBoolean(!(Boolean)var10000);
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(E axx, @Nullable Continuation<? super Boolean> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }));
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel filterNot$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.filterNot(var0, var1, var2);
   }

   @PublishedApi
   @NotNull
   public static final <E> ReceiveChannel<E> filterNotNull(@NotNull ReceiveChannel<? extends E> a) {
      return ChannelsKt.filter$default(a, (CoroutineContext)null, (Function2)(new Function2<E, Continuation<? super Boolean>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object var1) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(a.label) {
            case 0:
               ResultKt.throwOnFailure(var1);
               Object ax = a.L$0;
               return Boxing.boxBoolean(ax != null);
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object ax, @NotNull Continuation<?> axx) {
            Function2 var3 = new <anonymous constructor>(axx);
            var3.L$0 = ax;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@Nullable E ax, @Nullable Continuation<? super Boolean> axx) {
            return ((<undefinedtype>)a.create(ax, axx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 1, (Object)null);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object filterNotNullTo(ReceiveChannel param0, Collection param1, Continuation param2) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object filterNotNullTo(ReceiveChannel param0, SendChannel param1, Continuation param2) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel take(final ReceiveChannel a, final int a, CoroutineContext a) {
      return ProduceKt.produce$default((CoroutineScope)GlobalScope.INSTANCE, a, 0, (CoroutineStart)null, ChannelsKt.consumes(a), (Function2)(new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         int I$0;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var6 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            ProducerScope axxx;
            int axxxx;
            ChannelIterator var4;
            Object axxxxx;
            Continuation var10002;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               axxx = (ProducerScope)ax.L$0;
               if (a == 0) {
                  return Unit.INSTANCE;
               }

               boolean var7 = a >= 0;
               int var8 = a;
               if (!var7) {
                  int axxxxxx = false;
                  String var10 = "Requested element count " + var8 + " is less than zero.";
                  throw new IllegalArgumentException(var10.toString());
               }

               axxxx = a;
               var4 = a.iterator();
               break;
            case 1:
               axxxx = ax.I$0;
               var4 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               if (!(Boolean)axx) {
                  return Unit.INSTANCE;
               }

               axxxxx = var4.next();
               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.I$0 = axxxx;
               ax.label = 2;
               if (axxx.send(axxxxx, var10002) == var6) {
                  return var6;
               }

               --axxxx;
               if (axxxx == 0) {
                  return Unit.INSTANCE;
               }
               break;
            case 2:
               axxxx = ax.I$0;
               var4 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               --axxxx;
               if (axxxx == 0) {
                  return Unit.INSTANCE;
               }
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            do {
               Continuation var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.I$0 = axxxx;
               ax.label = 1;
               Object var10000 = var4.hasNext(var10001);
               if (var10000 == var6) {
                  return var6;
               }

               if (!(Boolean)var10000) {
                  return Unit.INSTANCE;
               }

               axxxxx = var4.next();
               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.I$0 = axxxx;
               ax.label = 2;
               if (axxx.send(axxxxx, var10002) == var6) {
                  return var6;
               }

               --axxxx;
            } while(axxxx != 0);

            return Unit.INSTANCE;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super E> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 6, (Object)null);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel take$default(ReceiveChannel var0, int var1, CoroutineContext var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.take(var0, var1, var2);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel takeWhile(final ReceiveChannel a, CoroutineContext a, final Function2 a) {
      return ProduceKt.produce$default((CoroutineScope)GlobalScope.INSTANCE, a, 0, (CoroutineStart)null, ChannelsKt.consumes(a), (Function2)(new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         Object L$2;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            Object var10000;
            Continuation var10001;
            ProducerScope axxx;
            Continuation var10002;
            ChannelIterator var3;
            Object axxxx;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               axxx = (ProducerScope)ax.L$0;
               var3 = a.iterator();
               var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 1;
               var10000 = var3.hasNext(var10001);
               if (var10000 == var5) {
                  return var5;
               }
               break;
            case 1:
               var3 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               var10000 = axx;
               break;
            case 2:
               axxxx = ax.L$2;
               var3 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               if (!(Boolean)axx) {
                  return Unit.INSTANCE;
               }

               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.L$2 = null;
               ax.label = 3;
               if (axxx.send(axxxx, var10002) == var5) {
                  return var5;
               }

               var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 1;
               var10000 = var3.hasNext(var10001);
               if (var10000 == var5) {
                  return var5;
               }
               break;
            case 3:
               var3 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 1;
               var10000 = var3.hasNext(var10001);
               if (var10000 == var5) {
                  return var5;
               }
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            do {
               if (!(Boolean)var10000) {
                  return Unit.INSTANCE;
               }

               axxxx = var3.next();
               Function2 var6 = a;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.L$2 = axxxx;
               ax.label = 2;
               var10000 = var6.invoke(axxxx, ax);
               if (var10000 == var5) {
                  return var5;
               }

               if (!(Boolean)var10000) {
                  return Unit.INSTANCE;
               }

               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.L$2 = null;
               ax.label = 3;
               if (axxx.send(axxxx, var10002) == var5) {
                  return var5;
               }

               var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 1;
               var10000 = var3.hasNext(var10001);
            } while(var10000 != var5);

            return var5;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super E> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 6, (Object)null);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel takeWhile$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.takeWhile(var0, var1, var2);
   }

   @PublishedApi
   @Nullable
   public static final <E, C extends SendChannel<? super E>> Object toChannel(@NotNull ReceiveChannel<? extends E> param0, @NotNull C param1, @NotNull Continuation<? super C> param2) {
      // $FF: Couldn't be decompiled
   }

   @PublishedApi
   @Nullable
   public static final <E, C extends Collection<? super E>> Object toCollection(@NotNull ReceiveChannel<? extends E> param0, @NotNull C param1, @NotNull Continuation<? super C> param2) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object toMap(ReceiveChannel a, Continuation a) {
      return ChannelsKt.toMap(a, (Map)(new LinkedHashMap()), a);
   }

   @PublishedApi
   @Nullable
   public static final <K, V, M extends Map<? super K, ? super V>> Object toMap(@NotNull ReceiveChannel<? extends Pair<? extends K, ? extends V>> param0, @NotNull M param1, @NotNull Continuation<? super M> param2) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object toMutableList(ReceiveChannel a, Continuation a) {
      return ChannelsKt.toCollection(a, (Collection)(new ArrayList()), a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object toSet(ReceiveChannel a, Continuation a) {
      return ChannelsKt.toMutableSet(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel flatMap(final ReceiveChannel a, CoroutineContext a, final Function2 a) {
      return ProduceKt.produce$default((CoroutineScope)GlobalScope.INSTANCE, a, 0, (CoroutineStart)null, ChannelsKt.consumes(a), (Function2)(new Function2<ProducerScope<? super R>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            ReceiveChannel var10000;
            SendChannel var10001;
            ProducerScope axxx;
            Continuation var10002;
            ChannelIterator var3;
            Object axxxx;
            Function2 var6;
            Object var7;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               axxx = (ProducerScope)ax.L$0;
               var3 = a.iterator();
               break;
            case 1:
               var3 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               if (!(Boolean)axx) {
                  return Unit.INSTANCE;
               }

               axxxx = var3.next();
               var6 = a;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 2;
               var7 = var6.invoke(axxxx, ax);
               if (var7 == var5) {
                  return var5;
               }

               var10000 = (ReceiveChannel)var7;
               var10001 = (SendChannel)axxx;
               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 3;
               if (ChannelsKt.toChannel(var10000, var10001, var10002) == var5) {
                  return var5;
               }
               break;
            case 2:
               var3 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               var10000 = (ReceiveChannel)axx;
               var10001 = (SendChannel)axxx;
               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 3;
               if (ChannelsKt.toChannel(var10000, var10001, var10002) == var5) {
                  return var5;
               }
               break;
            case 3:
               var3 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            do {
               Continuation var8 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 1;
               var7 = var3.hasNext(var8);
               if (var7 == var5) {
                  return var5;
               }

               if (!(Boolean)var7) {
                  return Unit.INSTANCE;
               }

               axxxx = var3.next();
               var6 = a;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 2;
               var7 = var6.invoke(axxxx, ax);
               if (var7 == var5) {
                  return var5;
               }

               var10000 = (ReceiveChannel)var7;
               var10001 = (SendChannel)axxx;
               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 3;
            } while(ChannelsKt.toChannel(var10000, var10001, var10002) != var5);

            return var5;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super R> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 6, (Object)null);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel flatMap$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.flatMap(var0, var1, var2);
   }

   @PublishedApi
   @NotNull
   public static final <E, R> ReceiveChannel<R> map(@NotNull final ReceiveChannel<? extends E> a, @NotNull CoroutineContext a, @NotNull final Function2<? super E, ? super Continuation<? super R>, ? extends Object> a) {
      return ProduceKt.produce$default((CoroutineScope)GlobalScope.INSTANCE, a, 0, (CoroutineStart)null, ChannelsKt.consumes(a), (Function2)(new Function2<ProducerScope<? super R>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         Object L$2;
         Object L$3;
         Object L$4;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object param1) {
            // $FF: Couldn't be decompiled
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super R> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 6, (Object)null);
   }

   // $FF: synthetic method
   public static ReceiveChannel map$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.map(var0, var1, var2);
   }

   @PublishedApi
   @NotNull
   public static final <E, R> ReceiveChannel<R> mapIndexed(@NotNull final ReceiveChannel<? extends E> a, @NotNull CoroutineContext a, @NotNull final Function3<? super Integer, ? super E, ? super Continuation<? super R>, ? extends Object> a) {
      return ProduceKt.produce$default((CoroutineScope)GlobalScope.INSTANCE, a, 0, (CoroutineStart)null, ChannelsKt.consumes(a), (Function2)(new Function2<ProducerScope<? super R>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         Object L$2;
         int I$0;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var7 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            ProducerScope axxx;
            int axxxx;
            ChannelIterator var4;
            Object var10000;
            Continuation var10001;
            Continuation var10002;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               axxx = (ProducerScope)ax.L$0;
               axxxx = 0;
               var4 = a.iterator();
               var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.I$0 = axxxx;
               ax.label = 1;
               var10000 = var4.hasNext(var10001);
               if (var10000 == var7) {
                  return var7;
               }
               break;
            case 1:
               axxxx = ax.I$0;
               var4 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               var10000 = axx;
               break;
            case 2:
               axxxx = ax.I$0;
               ProducerScope var6 = (ProducerScope)ax.L$2;
               var4 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.L$2 = null;
               ax.I$0 = axxxx;
               ax.label = 3;
               if (var6.send(axx, var10002) == var7) {
                  return var7;
               }

               var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.I$0 = axxxx;
               ax.label = 1;
               var10000 = var4.hasNext(var10001);
               if (var10000 == var7) {
                  return var7;
               }
               break;
            case 3:
               axxxx = ax.I$0;
               var4 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.I$0 = axxxx;
               ax.label = 1;
               var10000 = var4.hasNext(var10001);
               if (var10000 == var7) {
                  return var7;
               }
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            do {
               if (!(Boolean)var10000) {
                  return Unit.INSTANCE;
               }

               Object axxxxx = var4.next();
               Function3 var8 = a;
               Integer var10 = Boxing.boxInt(axxxx++);
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.L$2 = axxx;
               ax.I$0 = axxxx;
               ax.label = 2;
               var10000 = var8.invoke(var10, axxxxx, ax);
               if (var10000 == var7) {
                  return var7;
               }

               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.L$2 = null;
               ax.I$0 = axxxx;
               ax.label = 3;
               if (axxx.send(var10000, var10002) == var7) {
                  return var7;
               }

               var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.I$0 = axxxx;
               ax.label = 1;
               var10000 = var4.hasNext(var10001);
            } while(var10000 != var7);

            return var7;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super R> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 6, (Object)null);
   }

   // $FF: synthetic method
   public static ReceiveChannel mapIndexed$default(ReceiveChannel var0, CoroutineContext var1, Function3 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.mapIndexed(var0, var1, var2);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel mapIndexedNotNull(ReceiveChannel a, CoroutineContext a, Function3 a) {
      return ChannelsKt.filterNotNull(ChannelsKt.mapIndexed(a, a, a));
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel mapIndexedNotNull$default(ReceiveChannel var0, CoroutineContext var1, Function3 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.mapIndexedNotNull(var0, var1, var2);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel mapNotNull(ReceiveChannel a, CoroutineContext a, Function2 a) {
      return ChannelsKt.filterNotNull(ChannelsKt.map(a, a, a));
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel mapNotNull$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.mapNotNull(var0, var1, var2);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel withIndex(final ReceiveChannel a, CoroutineContext a) {
      return ProduceKt.produce$default((CoroutineScope)GlobalScope.INSTANCE, a, 0, (CoroutineStart)null, ChannelsKt.consumes(a), (Function2)(new Function2<ProducerScope<? super IndexedValue<? extends E>>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         int I$0;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var6 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            IndexedValue var10001;
            ProducerScope axxx;
            Continuation var10002;
            int axxxx;
            ChannelIterator var4;
            Object axxxxx;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               axxx = (ProducerScope)ax.L$0;
               axxxx = 0;
               var4 = a.iterator();
               break;
            case 1:
               axxxx = ax.I$0;
               var4 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               if (!(Boolean)axx) {
                  return Unit.INSTANCE;
               }

               axxxxx = var4.next();
               var10001 = new IndexedValue(axxxx++, axxxxx);
               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.I$0 = axxxx;
               ax.label = 2;
               if (axxx.send(var10001, var10002) == var6) {
                  return var6;
               }
               break;
            case 2:
               axxxx = ax.I$0;
               var4 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            do {
               Continuation var7 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.I$0 = axxxx;
               ax.label = 1;
               Object var10000 = var4.hasNext(var7);
               if (var10000 == var6) {
                  return var6;
               }

               if (!(Boolean)var10000) {
                  return Unit.INSTANCE;
               }

               axxxxx = var4.next();
               var10001 = new IndexedValue(axxxx++, axxxxx);
               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var4;
               ax.I$0 = axxxx;
               ax.label = 2;
            } while(axxx.send(var10001, var10002) != var6);

            return var6;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super IndexedValue<? extends E>> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 6, (Object)null);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel withIndex$default(ReceiveChannel var0, CoroutineContext var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.withIndex(var0, var1);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel distinct(ReceiveChannel a) {
      return ChannelsKt.distinctBy$default(a, (CoroutineContext)null, (Function2)(new Function2<E, Continuation<? super E>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object var1) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(a.label) {
            case 0:
               ResultKt.throwOnFailure(var1);
               Object ax = a.L$0;
               return ax;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object ax, @NotNull Continuation<?> axx) {
            Function2 var3 = new <anonymous constructor>(axx);
            var3.L$0 = ax;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(E ax, @Nullable Continuation<? super E> axx) {
            return ((<undefinedtype>)a.create(ax, axx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 1, (Object)null);
   }

   @PublishedApi
   @NotNull
   public static final <E, K> ReceiveChannel<E> distinctBy(@NotNull final ReceiveChannel<? extends E> a, @NotNull CoroutineContext a, @NotNull final Function2<? super E, ? super Continuation<? super K>, ? extends Object> a) {
      return ProduceKt.produce$default((CoroutineScope)GlobalScope.INSTANCE, a, 0, (CoroutineStart)null, ChannelsKt.consumes(a), (Function2)(new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         Object L$2;
         Object L$3;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var7 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            Function2 var10000;
            ProducerScope axxx;
            Continuation var10002;
            HashSet axxxx;
            ChannelIterator var4;
            Object axxxxx;
            Object axxxxxx;
            Object var8;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               axxx = (ProducerScope)ax.L$0;
               axxxx = new HashSet();
               var4 = a.iterator();
               break;
            case 1:
               var4 = (ChannelIterator)ax.L$2;
               axxxx = (HashSet)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               if (!(Boolean)axx) {
                  return Unit.INSTANCE;
               }

               axxxxx = var4.next();
               var10000 = a;
               ax.L$0 = axxx;
               ax.L$1 = axxxx;
               ax.L$2 = var4;
               ax.L$3 = axxxxx;
               ax.label = 2;
               var8 = var10000.invoke(axxxxx, ax);
               if (var8 == var7) {
                  return var7;
               }

               axxxxxx = var8;
               if (!axxxx.contains(axxxxxx)) {
                  var10002 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = axxxx;
                  ax.L$2 = var4;
                  ax.L$3 = axxxxxx;
                  ax.label = 3;
                  if (axxx.send(axxxxx, var10002) == var7) {
                     return var7;
                  }

                  ((Collection)axxxx).add(axxxxxx);
               }
               break;
            case 2:
               axxxxx = ax.L$3;
               var4 = (ChannelIterator)ax.L$2;
               axxxx = (HashSet)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               if (!axxxx.contains(axx)) {
                  var10002 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = axxxx;
                  ax.L$2 = var4;
                  ax.L$3 = axx;
                  ax.label = 3;
                  if (axxx.send(axxxxx, var10002) == var7) {
                     return var7;
                  }

                  ((Collection)axxxx).add(axx);
               }
               break;
            case 3:
               axxxxxx = ax.L$3;
               var4 = (ChannelIterator)ax.L$2;
               axxxx = (HashSet)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               ((Collection)axxxx).add(axxxxxx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            while(true) {
               Continuation var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = axxxx;
               ax.L$2 = var4;
               ax.L$3 = null;
               ax.label = 1;
               var8 = var4.hasNext(var10001);
               if (var8 == var7) {
                  return var7;
               }

               if (!(Boolean)var8) {
                  return Unit.INSTANCE;
               }

               axxxxx = var4.next();
               var10000 = a;
               ax.L$0 = axxx;
               ax.L$1 = axxxx;
               ax.L$2 = var4;
               ax.L$3 = axxxxx;
               ax.label = 2;
               var8 = var10000.invoke(axxxxx, ax);
               if (var8 == var7) {
                  return var7;
               }

               axxxxxx = var8;
               if (!axxxx.contains(axxxxxx)) {
                  var10002 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.L$1 = axxxx;
                  ax.L$2 = var4;
                  ax.L$3 = axxxxxx;
                  ax.label = 3;
                  if (axxx.send(axxxxx, var10002) == var7) {
                     return var7;
                  }

                  ((Collection)axxxx).add(axxxxxx);
               }
            }
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super E> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 6, (Object)null);
   }

   // $FF: synthetic method
   public static ReceiveChannel distinctBy$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.distinctBy(var0, var1, var2);
   }

   @PublishedApi
   @Nullable
   public static final <E> Object toMutableSet(@NotNull ReceiveChannel<? extends E> a, @NotNull Continuation<? super Set<E>> a) {
      return ChannelsKt.toCollection(a, (Collection)(new LinkedHashSet()), a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object any(ReceiveChannel param0, Continuation param1) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object count(ReceiveChannel param0, Continuation param1) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object maxWith(ReceiveChannel param0, Comparator param1, Continuation param2) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object minWith(ReceiveChannel param0, Comparator param1, Continuation param2) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object none(ReceiveChannel param0, Continuation param1) {
      // $FF: Couldn't be decompiled
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Left for binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel requireNoNulls(final ReceiveChannel a) {
      return ChannelsKt.map$default(a, (CoroutineContext)null, (Function2)(new Function2<E, Continuation<? super E>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object var1) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(var1);
               Object axx = ax.L$0;
               if (axx == null) {
                  throw new IllegalArgumentException("null element found in " + a + '.');
               }

               return axx;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@Nullable E axx, @Nullable Continuation<? super E> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 1, (Object)null);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel zip(ReceiveChannel a, ReceiveChannel a) {
      return ChannelsKt.zip$default(a, a, (CoroutineContext)null, (Function2)null.INSTANCE, 2, (Object)null);
   }

   @PublishedApi
   @NotNull
   public static final <E, R, V> ReceiveChannel<V> zip(@NotNull final ReceiveChannel<? extends E> a, @NotNull final ReceiveChannel<? extends R> a, @NotNull CoroutineContext a, @NotNull final Function2<? super E, ? super R, ? extends V> a) {
      CoroutineScope var10000 = (CoroutineScope)GlobalScope.INSTANCE;
      ReceiveChannel[] var4 = new ReceiveChannel[]{a, a};
      return ProduceKt.produce$default(var10000, a, 0, (CoroutineStart)null, ChannelsKt.consumesAll(var4), (Function2)(new Function2<ProducerScope<? super V>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         Object L$2;
         Object L$3;
         Object L$4;
         Object L$5;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object param1) {
            // $FF: Couldn't be decompiled
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super V> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 6, (Object)null);
   }

   // $FF: synthetic method
   public static ReceiveChannel zip$default(ReceiveChannel var0, ReceiveChannel var1, CoroutineContext var2, Function2 var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = (CoroutineContext)Dispatchers.getUnconfined();
      }

      return ChannelsKt.zip(var0, var1, var2, var3);
   }

   @PublishedApi
   @NotNull
   public static final Function1<Throwable, Unit> consumes(@NotNull final ReceiveChannel<?> a) {
      return (Function1)(new Function1<Throwable, Unit>() {
         public final void invoke(@Nullable Throwable axx) {
            ChannelsKt.cancelConsumed(a, axx);
         }
      });
   }
}
