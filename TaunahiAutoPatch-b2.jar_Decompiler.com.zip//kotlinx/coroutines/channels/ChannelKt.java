package kotlinx.coroutines.channels;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u00004\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\b\f\u001a\u001e\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u0004H\u0007\u001a>\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u0005\u001a\u00020\u00062\u0016\b\u0002\u0010\u0007\u001a\u0010\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\t\u0018\u00010\b\u001aX\u0010\n\u001a\u0002H\u000b\"\u0004\b\u0000\u0010\u000b*\b\u0012\u0004\u0012\u0002H\u000b0\f2#\u0010\r\u001a\u001f\u0012\u0015\u0012\u0013\u0018\u00010\u000e¢\u0006\f\b\u000f\u0012\b\b\u0010\u0012\u0004\b\b(\u0011\u0012\u0004\u0012\u0002H\u000b0\bH\u0086\bø\u0001\u0000ø\u0001\u0001\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0000¢\u0006\u0004\b\u0012\u0010\u0013\u001a^\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u000b0\f\"\u0004\b\u0000\u0010\u000b*\b\u0012\u0004\u0012\u0002H\u000b0\f2#\u0010\u0015\u001a\u001f\u0012\u0015\u0012\u0013\u0018\u00010\u000e¢\u0006\f\b\u000f\u0012\b\b\u0010\u0012\u0004\b\b(\u0011\u0012\u0004\u0012\u00020\t0\bH\u0086\bø\u0001\u0000ø\u0001\u0001\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0000¢\u0006\u0004\b\u0016\u0010\u0013\u001a^\u0010\r\u001a\b\u0012\u0004\u0012\u0002H\u000b0\f\"\u0004\b\u0000\u0010\u000b*\b\u0012\u0004\u0012\u0002H\u000b0\f2#\u0010\u0015\u001a\u001f\u0012\u0015\u0012\u0013\u0018\u00010\u000e¢\u0006\f\b\u000f\u0012\b\b\u0010\u0012\u0004\b\b(\u0011\u0012\u0004\u0012\u00020\t0\bH\u0086\bø\u0001\u0000ø\u0001\u0001\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0000¢\u0006\u0004\b\u0017\u0010\u0013\u001a\\\u0010\u0018\u001a\b\u0012\u0004\u0012\u0002H\u000b0\f\"\u0004\b\u0000\u0010\u000b*\b\u0012\u0004\u0012\u0002H\u000b0\f2!\u0010\u0015\u001a\u001d\u0012\u0013\u0012\u0011H\u000b¢\u0006\f\b\u000f\u0012\b\b\u0010\u0012\u0004\b\b(\u0019\u0012\u0004\u0012\u00020\t0\bH\u0086\bø\u0001\u0000ø\u0001\u0001\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0000¢\u0006\u0004\b\u001a\u0010\u0013\u0082\u0002\u000b\n\u0002\b\u0019\n\u0005\b¡\u001e0\u0001¨\u0006\u001b"},
   d2 = {"Channel", "Lkotlinx/coroutines/channels/Channel;", "E", "capacity", "", "onBufferOverflow", "Lkotlinx/coroutines/channels/BufferOverflow;", "onUndeliveredElement", "Lkotlin/Function1;", "", "getOrElse", "T", "Lkotlinx/coroutines/channels/ChannelResult;", "onFailure", "", "Lkotlin/ParameterName;", "name", "exception", "getOrElse-WpGqRn0", "(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "onClosed", "action", "onClosed-WpGqRn0", "onFailure-WpGqRn0", "onSuccess", "value", "onSuccess-WpGqRn0", "kotlinx-coroutines-core"}
)
public final class ChannelKt {
   public static final <T> T getOrElse_WpGqRn0/* $FF was: getOrElse-WpGqRn0*/(@NotNull Object a, @NotNull Function1<? super Throwable, ? extends T> a) {
      int a = false;
      return a instanceof ChannelResult.Failed ? a.invoke(ChannelResult.exceptionOrNull-impl(a)) : a;
   }

   @NotNull
   public static final <T> Object onSuccess_WpGqRn0/* $FF was: onSuccess-WpGqRn0*/(@NotNull Object a, @NotNull Function1<? super T, Unit> a) {
      int a = false;
      if (!(a instanceof ChannelResult.Failed)) {
         a.invoke(a);
      }

      return a;
   }

   @NotNull
   public static final <T> Object onFailure_WpGqRn0/* $FF was: onFailure-WpGqRn0*/(@NotNull Object a, @NotNull Function1<? super Throwable, Unit> a) {
      int a = false;
      if (a instanceof ChannelResult.Failed) {
         a.invoke(ChannelResult.exceptionOrNull-impl(a));
      }

      return a;
   }

   @NotNull
   public static final <T> Object onClosed_WpGqRn0/* $FF was: onClosed-WpGqRn0*/(@NotNull Object a, @NotNull Function1<? super Throwable, Unit> a) {
      int a = false;
      if (a instanceof ChannelResult.Closed) {
         a.invoke(ChannelResult.exceptionOrNull-impl(a));
      }

      return a;
   }

   @NotNull
   public static final <E> Channel<E> Channel(int a, @NotNull BufferOverflow a, @Nullable Function1<? super E, Unit> a) {
      Channel var10000;
      switch(a) {
      case -2:
         var10000 = (Channel)(new ArrayChannel(a == BufferOverflow.SUSPEND ? Channel.Factory.getCHANNEL_DEFAULT_CAPACITY$kotlinx_coroutines_core() : 1, a, a));
         break;
      case -1:
         if (a != BufferOverflow.SUSPEND) {
            int a = false;
            String var4 = "CONFLATED capacity cannot be used with non-default onBufferOverflow";
            throw new IllegalArgumentException(var4.toString());
         }

         var10000 = (Channel)(new ConflatedChannel(a));
         break;
      case 0:
         var10000 = (Channel)(a == BufferOverflow.SUSPEND ? (AbstractChannel)(new RendezvousChannel(a)) : (AbstractChannel)(new ArrayChannel(1, a, a)));
         break;
      case Integer.MAX_VALUE:
         var10000 = (Channel)(new LinkedListChannel(a));
         break;
      default:
         var10000 = (Channel)(a == 1 && a == BufferOverflow.DROP_OLDEST ? (AbstractChannel)(new ConflatedChannel(a)) : (AbstractChannel)(new ArrayChannel(a, a, a)));
      }

      return var10000;
   }

   // $FF: synthetic method
   public static Channel Channel$default(int var0, BufferOverflow var1, Function1 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var0 = 0;
      }

      if ((var3 & 2) != 0) {
         var1 = BufferOverflow.SUSPEND;
      }

      if ((var3 & 4) != 0) {
         var2 = null;
      }

      return Channel(var0, var1, var2);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.4.0, binary compatibility with earlier versions",
      level = DeprecationLevel.HIDDEN
   )
   public static final Channel Channel(int a) {
      return Channel$default(a, (BufferOverflow)null, (Function1)null, 6, (Object)null);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static Channel Channel$default(int var0, int var1, Object var2) {
      if ((var1 & 1) != 0) {
         var0 = 0;
      }

      return Channel(var0);
   }
}
