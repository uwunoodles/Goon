package kotlinx.coroutines.channels;

import java.util.ArrayList;
import java.util.concurrent.CancellationException;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.internal.LowPriorityInOverloadResolution;
import kotlin.jvm.JvmField;
import kotlin.jvm.JvmName;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlinx.coroutines.BeforeResumeCancelHandler;
import kotlinx.coroutines.CancelHandlerBase;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CancellableContinuationImpl;
import kotlinx.coroutines.CancellableContinuationImplKt;
import kotlinx.coroutines.CancellableContinuationKt;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.DebugStringsKt;
import kotlinx.coroutines.DisposableHandle;
import kotlinx.coroutines.internal.AtomicDesc;
import kotlinx.coroutines.internal.AtomicKt;
import kotlinx.coroutines.internal.InlineList;
import kotlinx.coroutines.internal.LockFreeLinkedListHead;
import kotlinx.coroutines.internal.LockFreeLinkedListNode;
import kotlinx.coroutines.internal.LockFreeLinkedList_commonKt;
import kotlinx.coroutines.internal.OnUndeliveredElementKt;
import kotlinx.coroutines.internal.StackTraceRecoveryKt;
import kotlinx.coroutines.internal.Symbol;
import kotlinx.coroutines.intrinsics.CancellableKt;
import kotlinx.coroutines.intrinsics.UndispatchedKt;
import kotlinx.coroutines.selects.SelectClause1;
import kotlinx.coroutines.selects.SelectInstance;
import kotlinx.coroutines.selects.SelectKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u009c\u0001\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000e\b \u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0003:\u0007STUVWXYB'\u0012 \u0010\u0004\u001a\u001c\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005j\n\u0012\u0004\u0012\u00028\u0000\u0018\u0001`\u0007¢\u0006\u0002\u0010\bJ\u0012\u0010\u0019\u001a\u00020\n2\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0007J\u0016\u0010\u0019\u001a\u00020\u00062\u000e\u0010\u001a\u001a\n\u0018\u00010\u001cj\u0004\u0018\u0001`\u001dJ\u0017\u0010\u001e\u001a\u00020\n2\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0000¢\u0006\u0002\b\u001fJ\u000e\u0010 \u001a\b\u0012\u0004\u0012\u00028\u00000!H\u0004J\u0016\u0010\"\u001a\u00020\n2\f\u0010#\u001a\b\u0012\u0004\u0012\u00028\u00000$H\u0002J\u0016\u0010%\u001a\u00020\n2\f\u0010#\u001a\b\u0012\u0004\u0012\u00028\u00000$H\u0014JR\u0010&\u001a\u00020\n\"\u0004\b\u0001\u0010'2\f\u0010(\u001a\b\u0012\u0004\u0012\u0002H'0)2$\u0010*\u001a \b\u0001\u0012\u0006\u0012\u0004\u0018\u00010,\u0012\n\u0012\b\u0012\u0004\u0012\u0002H'0-\u0012\u0006\u0012\u0004\u0018\u00010,0+2\u0006\u0010.\u001a\u00020/H\u0002ø\u0001\u0000¢\u0006\u0002\u00100J\u000f\u00101\u001a\b\u0012\u0004\u0012\u00028\u000002H\u0086\u0002J\u0010\u00103\u001a\u00020\u00062\u0006\u00104\u001a\u00020\nH\u0014J/\u00105\u001a\u00020\u00062\f\u00106\u001a\b\u0012\u0004\u0012\u000208072\n\u00109\u001a\u0006\u0012\u0002\b\u00030:H\u0014ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b;\u0010<J\b\u0010=\u001a\u00020\u0006H\u0014J\b\u0010>\u001a\u00020\u0006H\u0014J\n\u0010?\u001a\u0004\u0018\u00010,H\u0014J\u0016\u0010@\u001a\u0004\u0018\u00010,2\n\u0010(\u001a\u0006\u0012\u0002\b\u00030)H\u0014J\u0011\u0010#\u001a\u00028\u0000H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010AJ\"\u0010B\u001a\b\u0012\u0004\u0012\u00028\u00000\u0017H\u0086@ø\u0001\u0000ø\u0001\u0000ø\u0001\u0002ø\u0001\u0001¢\u0006\u0004\bC\u0010AJ\u001f\u0010D\u001a\u0002H'\"\u0004\b\u0001\u0010'2\u0006\u0010.\u001a\u00020/H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010EJR\u0010F\u001a\u00020\u0006\"\u0004\b\u0001\u0010'2\f\u0010(\u001a\b\u0012\u0004\u0012\u0002H'0)2\u0006\u0010.\u001a\u00020/2$\u0010*\u001a \b\u0001\u0012\u0006\u0012\u0004\u0018\u00010,\u0012\n\u0012\b\u0012\u0004\u0012\u0002H'0-\u0012\u0006\u0012\u0004\u0018\u00010,0+H\u0002ø\u0001\u0000¢\u0006\u0002\u0010GJ \u0010H\u001a\u00020\u00062\n\u0010I\u001a\u0006\u0012\u0002\b\u00030J2\n\u0010#\u001a\u0006\u0012\u0002\b\u00030$H\u0002J\u0010\u0010K\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010LH\u0014J\u001c\u0010M\u001a\b\u0012\u0004\u0012\u00028\u00000\u0017ø\u0001\u0000ø\u0001\u0002ø\u0001\u0001¢\u0006\u0004\bN\u0010OJX\u0010P\u001a\u00020\u0006\"\u0004\b\u0001\u0010'* \b\u0001\u0012\u0006\u0012\u0004\u0018\u00010,\u0012\n\u0012\b\u0012\u0004\u0012\u0002H'0-\u0012\u0006\u0012\u0004\u0018\u00010,0+2\f\u0010(\u001a\b\u0012\u0004\u0012\u0002H'0)2\u0006\u0010.\u001a\u00020/2\b\u0010Q\u001a\u0004\u0018\u00010,H\u0002ø\u0001\u0000¢\u0006\u0002\u0010RR\u0014\u0010\t\u001a\u00020\n8DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\u000b\u0010\fR\u0012\u0010\r\u001a\u00020\nX¤\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\fR\u0012\u0010\u000e\u001a\u00020\nX¤\u0004¢\u0006\u0006\u001a\u0004\b\u000e\u0010\fR\u0014\u0010\u000f\u001a\u00020\n8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\fR\u0014\u0010\u0010\u001a\u00020\n8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0010\u0010\fR\u0014\u0010\u0011\u001a\u00020\n8DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\u0011\u0010\fR\u0017\u0010\u0012\u001a\b\u0012\u0004\u0012\u00028\u00000\u00138F¢\u0006\u0006\u001a\u0004\b\u0014\u0010\u0015R \u0010\u0016\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00170\u00138Fø\u0001\u0000¢\u0006\u0006\u001a\u0004\b\u0018\u0010\u0015\u0082\u0002\u000f\n\u0002\b\u0019\n\u0005\b¡\u001e0\u0001\n\u0002\b!¨\u0006Z"},
   d2 = {"Lkotlinx/coroutines/channels/AbstractChannel;", "E", "Lkotlinx/coroutines/channels/AbstractSendChannel;", "Lkotlinx/coroutines/channels/Channel;", "onUndeliveredElement", "Lkotlin/Function1;", "", "Lkotlinx/coroutines/internal/OnUndeliveredElement;", "(Lkotlin/jvm/functions/Function1;)V", "hasReceiveOrClosed", "", "getHasReceiveOrClosed", "()Z", "isBufferAlwaysEmpty", "isBufferEmpty", "isClosedForReceive", "isEmpty", "isEmptyImpl", "onReceive", "Lkotlinx/coroutines/selects/SelectClause1;", "getOnReceive", "()Lkotlinx/coroutines/selects/SelectClause1;", "onReceiveCatching", "Lkotlinx/coroutines/channels/ChannelResult;", "getOnReceiveCatching", "cancel", "cause", "", "Ljava/util/concurrent/CancellationException;", "Lkotlinx/coroutines/CancellationException;", "cancelInternal", "cancelInternal$kotlinx_coroutines_core", "describeTryPoll", "Lkotlinx/coroutines/channels/AbstractChannel$TryPollDesc;", "enqueueReceive", "receive", "Lkotlinx/coroutines/channels/Receive;", "enqueueReceiveInternal", "enqueueReceiveSelect", "R", "select", "Lkotlinx/coroutines/selects/SelectInstance;", "block", "Lkotlin/Function2;", "", "Lkotlin/coroutines/Continuation;", "receiveMode", "", "(Lkotlinx/coroutines/selects/SelectInstance;Lkotlin/jvm/functions/Function2;I)Z", "iterator", "Lkotlinx/coroutines/channels/ChannelIterator;", "onCancelIdempotent", "wasClosed", "onCancelIdempotentList", "list", "Lkotlinx/coroutines/internal/InlineList;", "Lkotlinx/coroutines/channels/Send;", "closed", "Lkotlinx/coroutines/channels/Closed;", "onCancelIdempotentList-w-w6eGU", "(Ljava/lang/Object;Lkotlinx/coroutines/channels/Closed;)V", "onReceiveDequeued", "onReceiveEnqueued", "pollInternal", "pollSelectInternal", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "receiveCatching", "receiveCatching-JP2dKIU", "receiveSuspend", "(ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "registerSelectReceiveMode", "(Lkotlinx/coroutines/selects/SelectInstance;ILkotlin/jvm/functions/Function2;)V", "removeReceiveOnCancel", "cont", "Lkotlinx/coroutines/CancellableContinuation;", "takeFirstReceiveOrPeekClosed", "Lkotlinx/coroutines/channels/ReceiveOrClosed;", "tryReceive", "tryReceive-PtdJZtk", "()Ljava/lang/Object;", "tryStartBlockUnintercepted", "value", "(Lkotlin/jvm/functions/Function2;Lkotlinx/coroutines/selects/SelectInstance;ILjava/lang/Object;)V", "Itr", "ReceiveElement", "ReceiveElementWithUndeliveredHandler", "ReceiveHasNext", "ReceiveSelect", "RemoveReceiveOnCancel", "TryPollDesc", "kotlinx-coroutines-core"}
)
public abstract class AbstractChannel<E> extends AbstractSendChannel<E> implements Channel<E> {
   public AbstractChannel(@Nullable Function1<? super E, Unit> a) {
      super(a);
   }

   protected abstract boolean isBufferAlwaysEmpty();

   protected abstract boolean isBufferEmpty();

   @Nullable
   protected Object pollInternal() {
      while(true) {
         Send var10000 = a.takeFirstSendOrPeekClosed();
         if (var10000 == null) {
            return AbstractChannelKt.POLL_FAILED;
         }

         Send a = var10000;
         Symbol a = a.tryResumeSend((LockFreeLinkedListNode.PrepareOp)null);
         if (a != null) {
            if (DebugKt.getASSERTIONS_ENABLED()) {
               int a = false;
               if (a != CancellableContinuationImplKt.RESUME_TOKEN) {
                  throw new AssertionError();
               }
            }

            a.completeResumeSend();
            return a.getPollResult();
         }

         a.undeliveredElement();
      }
   }

   @Nullable
   protected Object pollSelectInternal(@NotNull SelectInstance<?> a) {
      AbstractChannel.TryPollDesc a = a.describeTryPoll();
      Object a = a.performAtomicTrySelect((AtomicDesc)a);
      if (a != null) {
         return a;
      } else {
         Send a = (Send)a.getResult();
         a.completeResumeSend();
         return ((Send)a.getResult()).getPollResult();
      }
   }

   protected final boolean getHasReceiveOrClosed() {
      return a.getQueue().getNextNode() instanceof ReceiveOrClosed;
   }

   public boolean isClosedForReceive() {
      return a.getClosedForReceive() != null && a.isBufferEmpty();
   }

   public boolean isEmpty() {
      return a.isEmptyImpl();
   }

   protected final boolean isEmptyImpl() {
      return !(a.getQueue().getNextNode() instanceof Send) && a.isBufferEmpty();
   }

   @Nullable
   public final Object receive(@NotNull Continuation<? super E> a) {
      Object a = a.pollInternal();
      return a != AbstractChannelKt.POLL_FAILED && !(a instanceof Closed) ? a : a.receiveSuspend(0, a);
   }

   private final <R> Object receiveSuspend(int a, Continuation<? super R> a) {
      int a = false;
      int a = false;
      CancellableContinuationImpl a = CancellableContinuationKt.getOrCreateCancellableContinuation(IntrinsicsKt.intercepted(a));
      CancellableContinuation a = (CancellableContinuation)a;
      int a = false;
      AbstractChannel.ReceiveElement a = a.onUndeliveredElement == null ? new AbstractChannel.ReceiveElement(a, a) : (AbstractChannel.ReceiveElement)(new AbstractChannel.ReceiveElementWithUndeliveredHandler(a, a, a.onUndeliveredElement));

      while(true) {
         if (access$enqueueReceive(a, (Receive)a)) {
            access$removeReceiveOnCancel(a, a, (Receive)a);
            break;
         }

         Object a = a.pollInternal();
         if (a instanceof Closed) {
            a.resumeReceiveClosed((Closed)a);
            break;
         }

         if (a != AbstractChannelKt.POLL_FAILED) {
            a.resume(a.resumeValue(a), a.resumeOnCancellationFun(a));
            break;
         }
      }

      Object var10000 = a.getResult();
      if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         DebugProbesKt.probeCoroutineSuspended(a);
      }

      return var10000;
   }

   protected boolean enqueueReceiveInternal(@NotNull Receive<? super E> a) {
      boolean var10000;
      LockFreeLinkedListNode a;
      boolean a;
      LockFreeLinkedListNode a;
      if (a.isBufferAlwaysEmpty()) {
         a = (LockFreeLinkedListNode)a.getQueue();
         a = false;

         while(true) {
            a = a.getPrevNode();
            int a = false;
            if (a instanceof Send) {
               var10000 = false;
               break;
            }

            if (a.addNext((LockFreeLinkedListNode)a, a)) {
               var10000 = true;
               break;
            }
         }
      } else {
         a = (LockFreeLinkedListNode)a.getQueue();
         a = false;
         int a = false;
         LockFreeLinkedListNode.CondAddOp a = (LockFreeLinkedListNode.CondAddOp)(new AbstractChannel$enqueueReceiveInternal$$inlined$addLastIfPrevAndIf$1((LockFreeLinkedListNode)a, a));

         while(true) {
            a = a.getPrevNode();
            int a = false;
            if (a instanceof Send) {
               var10000 = false;
               break;
            }

            switch(a.tryCondAddNext((LockFreeLinkedListNode)a, a, a)) {
            case 1:
               var10000 = true;
               return var10000;
            case 2:
               var10000 = false;
               return var10000;
            }
         }
      }

      return var10000;
   }

   private final boolean enqueueReceive(Receive<? super E> a) {
      boolean var2 = a.enqueueReceiveInternal(a);
      int a = false;
      if (var2) {
         a.onReceiveEnqueued();
      }

      return var2;
   }

   @Nullable
   public final Object receiveCatching_JP2dKIU/* $FF was: receiveCatching-JP2dKIU*/(@NotNull Continuation<? super ChannelResult<? extends E>> var1) {
      Object a;
      label29: {
         if (var1 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var1;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label29;
            }
         }

         a = new ContinuationImpl(var1) {
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object axx) {
               ax.result = axx;
               ax.label |= Integer.MIN_VALUE;
               Object var10000 = a.receiveCatching-JP2dKIU((Continuation)ax);
               return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : ChannelResult.box-impl(var10000);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var7 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      Object var10000;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         Object a = a.pollInternal();
         if (a != AbstractChannelKt.POLL_FAILED) {
            int a = false;
            return a instanceof Closed ? ChannelResult.Companion.closed-JP2dKIU(((Closed)a).closeCause) : ChannelResult.Companion.success-JP2dKIU(a);
         }

         ((<undefinedtype>)a).label = 1;
         var10000 = a.receiveSuspend(1, (Continuation)a);
         if (var10000 == var7) {
            return var7;
         }
         break;
      case 1:
         ResultKt.throwOnFailure(a);
         var10000 = a;
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      return ((ChannelResult)var10000).unbox-impl();
   }

   @NotNull
   public final Object tryReceive_PtdJZtk/* $FF was: tryReceive-PtdJZtk*/() {
      Object a = a.pollInternal();
      if (a == AbstractChannelKt.POLL_FAILED) {
         return ChannelResult.Companion.failure-PtdJZtk();
      } else {
         return a instanceof Closed ? ChannelResult.Companion.closed-JP2dKIU(((Closed)a).closeCause) : ChannelResult.Companion.success-JP2dKIU(a);
      }
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public final boolean cancel(Throwable a) {
      return a.cancelInternal$kotlinx_coroutines_core(a);
   }

   public final void cancel(@Nullable CancellationException a) {
      if (!a.isClosedForReceive()) {
         CancellationException var10001 = a;
         if (a == null) {
            var10001 = new CancellationException(DebugStringsKt.getClassSimpleName(a) + " was cancelled");
         }

         a.cancelInternal$kotlinx_coroutines_core((Throwable)var10001);
      }
   }

   public final boolean cancelInternal$kotlinx_coroutines_core(@Nullable Throwable a) {
      boolean var2 = a.close(a);
      int a = false;
      a.onCancelIdempotent(var2);
      return var2;
   }

   protected void onCancelIdempotent(boolean a1) {
      Closed var10000 = a.getClosedForSend();
      if (var10000 == null) {
         throw new IllegalStateException("Cannot happen".toString());
      } else {
         Closed a = var10000;
         Object a = InlineList.constructor-impl$default((Object)null, 1, (DefaultConstructorMarker)null);

         while(true) {
            LockFreeLinkedListNode a = a.getPrevNode();
            if (a instanceof LockFreeLinkedListHead) {
               a.onCancelIdempotentList-w-w6eGU(a, a);
               return;
            }

            if (DebugKt.getASSERTIONS_ENABLED()) {
               int a = false;
               if (!(a instanceof Send)) {
                  throw new AssertionError();
               }
            }

            if (!a.remove()) {
               a.helpRemove();
            } else {
               a = InlineList.plus-FjFbRPM(a, (Send)a);
            }
         }
      }
   }

   protected void onCancelIdempotentList_w_w6eGU/* $FF was: onCancelIdempotentList-w-w6eGU*/(@NotNull Object a, @NotNull Closed<?> a) {
      int a = false;
      if (a != null) {
         if (!(a instanceof ArrayList)) {
            Send a = (Send)a;
            int a = false;
            a.resumeSendClosed(a);
         } else {
            if (a == null) {
               throw new NullPointerException("null cannot be cast to non-null type java.util.ArrayList<E of kotlinx.coroutines.internal.InlineList>{ kotlin.collections.TypeAliasesKt.ArrayList<E of kotlinx.coroutines.internal.InlineList> }");
            }

            ArrayList a = (ArrayList)a;

            for(int a = a.size() - 1; -1 < a; --a) {
               Send a = (Send)a.get(a);
               int a = false;
               a.resumeSendClosed(a);
            }
         }
      }

   }

   @NotNull
   public final ChannelIterator<E> iterator() {
      return (ChannelIterator)(new AbstractChannel.Itr(a));
   }

   @NotNull
   protected final AbstractChannel.TryPollDesc<E> describeTryPoll() {
      return new AbstractChannel.TryPollDesc(a.getQueue());
   }

   @NotNull
   public final SelectClause1<E> getOnReceive() {
      return (SelectClause1)(new SelectClause1<E>() {
         public <R> void registerSelectClause1(@NotNull SelectInstance<? super R> axx, @NotNull Function2<? super E, ? super Continuation<? super R>, ? extends Object> axxx) {
            a.registerSelectReceiveMode(axx, 0, axxx);
         }
      });
   }

   @NotNull
   public final SelectClause1<ChannelResult<E>> getOnReceiveCatching() {
      return (SelectClause1)(new SelectClause1<ChannelResult<? extends E>>() {
         public <R> void registerSelectClause1(@NotNull SelectInstance<? super R> axx, @NotNull Function2<? super ChannelResult<? extends E>, ? super Continuation<? super R>, ? extends Object> axxx) {
            a.registerSelectReceiveMode(axx, 1, axxx);
         }
      });
   }

   private final <R> void registerSelectReceiveMode(SelectInstance<? super R> a, int a, Function2<Object, ? super Continuation<? super R>, ? extends Object> a) {
      while(!a.isSelected()) {
         if (a.isEmptyImpl()) {
            if (a.enqueueReceiveSelect(a, a, a)) {
               return;
            }
         } else {
            Object a = a.pollSelectInternal(a);
            if (a == SelectKt.getALREADY_SELECTED()) {
               return;
            }

            if (a != AbstractChannelKt.POLL_FAILED && a != AtomicKt.RETRY_ATOMIC) {
               a.tryStartBlockUnintercepted(a, a, a, a);
            }
         }
      }

   }

   private final <R> void tryStartBlockUnintercepted(Function2<Object, ? super Continuation<? super R>, ? extends Object> a, SelectInstance<? super R> a, int a, Object a) {
      if (a instanceof Closed) {
         switch(a) {
         case 0:
            throw StackTraceRecoveryKt.recoverStackTrace(((Closed)a).getReceiveException());
         case 1:
            if (!a.trySelect()) {
               return;
            }

            UndispatchedKt.startCoroutineUnintercepted(a, ChannelResult.box-impl(ChannelResult.Companion.closed-JP2dKIU(((Closed)a).closeCause)), a.getCompletion());
         }
      } else if (a == 1) {
         int a = false;
         UndispatchedKt.startCoroutineUnintercepted(a, ChannelResult.box-impl(a instanceof Closed ? ChannelResult.Companion.closed-JP2dKIU(((Closed)a).closeCause) : ChannelResult.Companion.success-JP2dKIU(a)), a.getCompletion());
      } else {
         UndispatchedKt.startCoroutineUnintercepted(a, a, a.getCompletion());
      }

   }

   private final <R> boolean enqueueReceiveSelect(SelectInstance<? super R> a, Function2<Object, ? super Continuation<? super R>, ? extends Object> a, int a) {
      AbstractChannel.ReceiveSelect a = new AbstractChannel.ReceiveSelect(a, a, a, a);
      boolean a = a.enqueueReceive((Receive)a);
      if (a) {
         a.disposeOnSelect((DisposableHandle)a);
      }

      return a;
   }

   @Nullable
   protected ReceiveOrClosed<E> takeFirstReceiveOrPeekClosed() {
      ReceiveOrClosed var1 = super.takeFirstReceiveOrPeekClosed();
      int a = false;
      if (var1 != null && !(var1 instanceof Closed)) {
         a.onReceiveDequeued();
      }

      return var1;
   }

   protected void onReceiveEnqueued() {
   }

   protected void onReceiveDequeued() {
   }

   private final void removeReceiveOnCancel(CancellableContinuation<?> a, Receive<?> a) {
      CancelHandlerBase a = (CancelHandlerBase)(new AbstractChannel.RemoveReceiveOnCancel(a));
      int a = false;
      a.invokeOnCancellation((Function1)a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public void cancel() {
      Channel.DefaultImpls.cancel(a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in the favour of 'tryReceive'. Please note that the provided replacement does not rethrow channel's close cause as 'poll' did, for the precise replacement please refer to the 'poll' documentation",
      replaceWith = @ReplaceWith(
   expression = "tryReceive().getOrNull()",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @Nullable
   public E poll() {
      return Channel.DefaultImpls.poll(a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in favor of 'receiveCatching'. Please note that the provided replacement does not rethrow channel's close cause as 'receiveOrNull' did, for the detailed replacement please refer to the 'receiveOrNull' documentation",
      replaceWith = @ReplaceWith(
   expression = "receiveCatching().getOrNull()",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @LowPriorityInOverloadResolution
   @Nullable
   public Object receiveOrNull(@NotNull Continuation<? super E> a) {
      return Channel.DefaultImpls.receiveOrNull(a, a);
   }

   /** @deprecated */
   @NotNull
   public SelectClause1<E> getOnReceiveOrNull() {
      return Channel.DefaultImpls.getOnReceiveOrNull(a);
   }

   // $FF: synthetic method
   public static final Object access$receiveSuspend(AbstractChannel a, int a, Continuation a) {
      return a.receiveSuspend(a, a);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\b\u0004\u0018\u0000*\u0004\b\u0001\u0010\u00012\u0012\u0012\u0004\u0012\u00020\u00030\u0002j\b\u0012\u0004\u0012\u00020\u0003`\u0004B\r\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007J\u0012\u0010\b\u001a\u0004\u0018\u00010\t2\u0006\u0010\n\u001a\u00020\u000bH\u0014J\u0016\u0010\f\u001a\u0004\u0018\u00010\t2\n\u0010\r\u001a\u00060\u000ej\u0002`\u000fH\u0016J\u0010\u0010\u0010\u001a\u00020\u00112\u0006\u0010\n\u001a\u00020\u000bH\u0016¨\u0006\u0012"},
      d2 = {"Lkotlinx/coroutines/channels/AbstractChannel$TryPollDesc;", "E", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$RemoveFirstDesc;", "Lkotlinx/coroutines/channels/Send;", "Lkotlinx/coroutines/internal/RemoveFirstDesc;", "queue", "Lkotlinx/coroutines/internal/LockFreeLinkedListHead;", "(Lkotlinx/coroutines/internal/LockFreeLinkedListHead;)V", "failure", "", "affected", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "onPrepare", "prepareOp", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$PrepareOp;", "Lkotlinx/coroutines/internal/PrepareOp;", "onRemoved", "", "kotlinx-coroutines-core"}
   )
   protected static final class TryPollDesc<E> extends LockFreeLinkedListNode.RemoveFirstDesc<Send> {
      public TryPollDesc(@NotNull LockFreeLinkedListHead a) {
         super((LockFreeLinkedListNode)a);
      }

      @Nullable
      protected Object failure(@NotNull LockFreeLinkedListNode a) {
         return a instanceof Closed ? a : (!(a instanceof Send) ? AbstractChannelKt.POLL_FAILED : null);
      }

      @Nullable
      public Object onPrepare(@NotNull LockFreeLinkedListNode.PrepareOp a) {
         Send a = (Send)a.affected;
         Symbol var10000 = a.tryResumeSend(a);
         if (var10000 == null) {
            return LockFreeLinkedList_commonKt.REMOVE_PREPARED;
         } else {
            Symbol a = var10000;
            if (a == AtomicKt.RETRY_ATOMIC) {
               return AtomicKt.RETRY_ATOMIC;
            } else {
               if (DebugKt.getASSERTIONS_ENABLED()) {
                  int a = false;
                  if (a != CancellableContinuationImplKt.RESUME_TOKEN) {
                     throw new AssertionError();
                  }
               }

               return null;
            }
         }
      }

      public void onRemoved(@NotNull LockFreeLinkedListNode a) {
         ((Send)a).undeliveredElement();
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0003\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0011\u0012\n\u0010\u0002\u001a\u0006\u0012\u0002\b\u00030\u0003¢\u0006\u0002\u0010\u0004J\u0013\u0010\u0005\u001a\u00020\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\bH\u0096\u0002J\b\u0010\t\u001a\u00020\nH\u0016R\u0012\u0010\u0002\u001a\u0006\u0012\u0002\b\u00030\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000b"},
      d2 = {"Lkotlinx/coroutines/channels/AbstractChannel$RemoveReceiveOnCancel;", "Lkotlinx/coroutines/BeforeResumeCancelHandler;", "receive", "Lkotlinx/coroutines/channels/Receive;", "(Lkotlinx/coroutines/channels/AbstractChannel;Lkotlinx/coroutines/channels/Receive;)V", "invoke", "", "cause", "", "toString", "", "kotlinx-coroutines-core"}
   )
   private final class RemoveReceiveOnCancel extends BeforeResumeCancelHandler {
      @NotNull
      private final Receive<?> receive;

      public RemoveReceiveOnCancel(@NotNull Receive<?> axx) {
         a.receive = axx;
      }

      public void invoke(@Nullable Throwable a1) {
         if (a.receive.remove()) {
            AbstractChannel.this.onReceiveDequeued();
         }

      }

      @NotNull
      public String toString() {
         return "RemoveReceiveOnCancel[" + a.receive + ']';
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0002\u0018\u0000*\u0004\b\u0001\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B\u0013\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00010\u0004¢\u0006\u0002\u0010\u0005J\u0011\u0010\f\u001a\u00020\rH\u0096Bø\u0001\u0000¢\u0006\u0002\u0010\u000eJ\u0012\u0010\u000f\u001a\u00020\r2\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0002J\u0011\u0010\u0010\u001a\u00020\rH\u0082@ø\u0001\u0000¢\u0006\u0002\u0010\u000eJ\u000e\u0010\u0011\u001a\u00028\u0001H\u0096\u0002¢\u0006\u0002\u0010\tR\u0016\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00010\u00048\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000b\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0012"},
      d2 = {"Lkotlinx/coroutines/channels/AbstractChannel$Itr;", "E", "Lkotlinx/coroutines/channels/ChannelIterator;", "channel", "Lkotlinx/coroutines/channels/AbstractChannel;", "(Lkotlinx/coroutines/channels/AbstractChannel;)V", "result", "", "getResult", "()Ljava/lang/Object;", "setResult", "(Ljava/lang/Object;)V", "hasNext", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "hasNextResult", "hasNextSuspend", "next", "kotlinx-coroutines-core"}
   )
   private static final class Itr<E> implements ChannelIterator<E> {
      @JvmField
      @NotNull
      public final AbstractChannel<E> channel;
      @Nullable
      private Object result;

      public Itr(@NotNull AbstractChannel<E> a) {
         a.channel = a;
         a.result = AbstractChannelKt.POLL_FAILED;
      }

      @Nullable
      public final Object getResult() {
         return a.result;
      }

      public final void setResult(@Nullable Object a) {
         a.result = a;
      }

      @Nullable
      public Object hasNext(@NotNull Continuation<? super Boolean> a) {
         if (a.result != AbstractChannelKt.POLL_FAILED) {
            return Boxing.boxBoolean(a.hasNextResult(a.result));
         } else {
            a.result = a.channel.pollInternal();
            return a.result != AbstractChannelKt.POLL_FAILED ? Boxing.boxBoolean(a.hasNextResult(a.result)) : a.hasNextSuspend(a);
         }
      }

      private final boolean hasNextResult(Object a) {
         if (a instanceof Closed) {
            if (((Closed)a).closeCause != null) {
               throw StackTraceRecoveryKt.recoverStackTrace(((Closed)a).getReceiveException());
            } else {
               return false;
            }
         } else {
            return true;
         }
      }

      private final Object hasNextSuspend(Continuation<? super Boolean> a) {
         int a = false;
         int a = false;
         CancellableContinuationImpl a = CancellableContinuationKt.getOrCreateCancellableContinuation(IntrinsicsKt.intercepted(a));
         CancellableContinuation a = (CancellableContinuation)a;
         int a = false;
         AbstractChannel.ReceiveHasNext a = new AbstractChannel.ReceiveHasNext(a, a);

         while(true) {
            if (a.channel.enqueueReceive((Receive)a)) {
               a.channel.removeReceiveOnCancel(a, (Receive)a);
               break;
            }

            Object a = a.channel.pollInternal();
            a.setResult(a);
            if (a instanceof Closed) {
               Result.Companion var11;
               Continuation var10000;
               if (((Closed)a).closeCause == null) {
                  var10000 = (Continuation)a;
                  var11 = Result.Companion;
                  var10000.resumeWith(Result.constructor-impl(Boxing.boxBoolean(false)));
               } else {
                  var10000 = (Continuation)a;
                  var11 = Result.Companion;
                  var10000.resumeWith(Result.constructor-impl(ResultKt.createFailure(((Closed)a).getReceiveException())));
               }
               break;
            }

            if (a != AbstractChannelKt.POLL_FAILED) {
               Boolean var10001 = Boxing.boxBoolean(true);
               Function1 var10002 = a.channel.onUndeliveredElement;
               a.resume(var10001, var10002 != null ? OnUndeliveredElementKt.bindCancellationFun(var10002, a, a.getContext()) : null);
               break;
            }
         }

         Object var10 = a.getResult();
         if (var10 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            DebugProbesKt.probeCoroutineSuspended(a);
         }

         return var10;
      }

      public E next() {
         Object a = a.result;
         if (a instanceof Closed) {
            throw StackTraceRecoveryKt.recoverStackTrace(((Closed)a).getReceiveException());
         } else if (a != AbstractChannelKt.POLL_FAILED) {
            a.result = AbstractChannelKt.POLL_FAILED;
            return a;
         } else {
            throw new IllegalStateException("'hasNext' should be called prior to 'next' invocation");
         }
      }

      /** @deprecated */
      // $FF: synthetic method
      @Deprecated(
         message = "Since 1.3.0, binary compatibility with versions <= 1.2.x",
         level = DeprecationLevel.HIDDEN
      )
      @JvmName(
         name = "next"
      )
      public Object next(Continuation a) {
         return ChannelIterator.DefaultImpls.next(a, a);
      }

      // $FF: synthetic method
      public static final Object access$hasNextSuspend(AbstractChannel.Itr a, Continuation a) {
         return a.hasNextSuspend(a);
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0012\u0018\u0000*\u0006\b\u0001\u0010\u0001 \u00002\b\u0012\u0004\u0012\u0002H\u00010\u0002B\u001d\u0012\u000e\u0010\u0003\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\u0015\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00028\u0001H\u0016¢\u0006\u0002\u0010\fJ\u0014\u0010\r\u001a\u00020\n2\n\u0010\u000e\u001a\u0006\u0012\u0002\b\u00030\u000fH\u0016J\u0015\u0010\u0010\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u000b\u001a\u00028\u0001¢\u0006\u0002\u0010\u0011J\b\u0010\u0012\u001a\u00020\u0013H\u0016J!\u0010\u0014\u001a\u0004\u0018\u00010\u00152\u0006\u0010\u000b\u001a\u00028\u00012\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017H\u0016¢\u0006\u0002\u0010\u0018R\u0018\u0010\u0003\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u00048\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\u0019"},
      d2 = {"Lkotlinx/coroutines/channels/AbstractChannel$ReceiveElement;", "E", "Lkotlinx/coroutines/channels/Receive;", "cont", "Lkotlinx/coroutines/CancellableContinuation;", "", "receiveMode", "", "(Lkotlinx/coroutines/CancellableContinuation;I)V", "completeResumeReceive", "", "value", "(Ljava/lang/Object;)V", "resumeReceiveClosed", "closed", "Lkotlinx/coroutines/channels/Closed;", "resumeValue", "(Ljava/lang/Object;)Ljava/lang/Object;", "toString", "", "tryResumeReceive", "Lkotlinx/coroutines/internal/Symbol;", "otherOp", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$PrepareOp;", "(Ljava/lang/Object;Lkotlinx/coroutines/internal/LockFreeLinkedListNode$PrepareOp;)Lkotlinx/coroutines/internal/Symbol;", "kotlinx-coroutines-core"}
   )
   private static class ReceiveElement<E> extends Receive<E> {
      @JvmField
      @NotNull
      public final CancellableContinuation<Object> cont;
      @JvmField
      public final int receiveMode;

      public ReceiveElement(@NotNull CancellableContinuation<Object> a, int a) {
         a.cont = a;
         a.receiveMode = a;
      }

      @Nullable
      public final Object resumeValue(E a) {
         return a.receiveMode == 1 ? ChannelResult.box-impl(ChannelResult.Companion.success-JP2dKIU(a)) : a;
      }

      @Nullable
      public Symbol tryResumeReceive(E a, @Nullable LockFreeLinkedListNode.PrepareOp a) {
         Object var10000 = a.cont.tryResume(a.resumeValue(a), a != null ? a.desc : null, a.resumeOnCancellationFun(a));
         if (var10000 == null) {
            return null;
         } else {
            Object a = var10000;
            if (DebugKt.getASSERTIONS_ENABLED()) {
               int a = false;
               if (a != CancellableContinuationImplKt.RESUME_TOKEN) {
                  throw new AssertionError();
               }
            }

            if (a != null) {
               a.finishPrepare();
            }

            return CancellableContinuationImplKt.RESUME_TOKEN;
         }
      }

      public void completeResumeReceive(E a1) {
         a.cont.completeResume(CancellableContinuationImplKt.RESUME_TOKEN);
      }

      public void resumeReceiveClosed(@NotNull Closed<?> a) {
         Result.Companion var10001;
         if (a.receiveMode == 1) {
            Continuation var2 = (Continuation)a.cont;
            int a = false;
            ChannelResult var3 = ChannelResult.box-impl(ChannelResult.Companion.closed-JP2dKIU(a.closeCause));
            var10001 = Result.Companion;
            var2.resumeWith(Result.constructor-impl(var3));
         } else {
            Continuation var10000 = (Continuation)a.cont;
            var10001 = Result.Companion;
            var10000.resumeWith(Result.constructor-impl(ResultKt.createFailure(a.getReceiveException())));
         }

      }

      @NotNull
      public String toString() {
         return "ReceiveElement@" + DebugStringsKt.getHexAddress(a) + "[receiveMode=" + a.receiveMode + ']';
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0002\b\u0003\b\u0002\u0018\u0000*\u0006\b\u0001\u0010\u0001 \u00002\b\u0012\u0004\u0012\u0002H\u00010\u0002B;\u0012\u000e\u0010\u0003\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u001c\u0010\b\u001a\u0018\u0012\u0004\u0012\u00028\u0001\u0012\u0004\u0012\u00020\n0\tj\b\u0012\u0004\u0012\u00028\u0001`\u000b¢\u0006\u0002\u0010\fJ#\u0010\r\u001a\u0010\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\n\u0018\u00010\t2\u0006\u0010\u000f\u001a\u00028\u0001H\u0016¢\u0006\u0002\u0010\u0010R&\u0010\b\u001a\u0018\u0012\u0004\u0012\u00028\u0001\u0012\u0004\u0012\u00020\n0\tj\b\u0012\u0004\u0012\u00028\u0001`\u000b8\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\u0011"},
      d2 = {"Lkotlinx/coroutines/channels/AbstractChannel$ReceiveElementWithUndeliveredHandler;", "E", "Lkotlinx/coroutines/channels/AbstractChannel$ReceiveElement;", "cont", "Lkotlinx/coroutines/CancellableContinuation;", "", "receiveMode", "", "onUndeliveredElement", "Lkotlin/Function1;", "", "Lkotlinx/coroutines/internal/OnUndeliveredElement;", "(Lkotlinx/coroutines/CancellableContinuation;ILkotlin/jvm/functions/Function1;)V", "resumeOnCancellationFun", "", "value", "(Ljava/lang/Object;)Lkotlin/jvm/functions/Function1;", "kotlinx-coroutines-core"}
   )
   private static final class ReceiveElementWithUndeliveredHandler<E> extends AbstractChannel.ReceiveElement<E> {
      @JvmField
      @NotNull
      public final Function1<E, Unit> onUndeliveredElement;

      public ReceiveElementWithUndeliveredHandler(@NotNull CancellableContinuation<Object> a, int a, @NotNull Function1<? super E, Unit> a) {
         super(a, a);
         a.onUndeliveredElement = a;
      }

      @Nullable
      public Function1<Throwable, Unit> resumeOnCancellationFun(E a) {
         return OnUndeliveredElementKt.bindCancellationFun(a.onUndeliveredElement, a, a.cont.getContext());
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0012\u0018\u0000*\u0004\b\u0001\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B!\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00010\u0004\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006¢\u0006\u0002\u0010\bJ\u0015\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00028\u0001H\u0016¢\u0006\u0002\u0010\fJ#\u0010\r\u001a\u0010\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\n\u0018\u00010\u000e2\u0006\u0010\u000b\u001a\u00028\u0001H\u0016¢\u0006\u0002\u0010\u0010J\u0014\u0010\u0011\u001a\u00020\n2\n\u0010\u0012\u001a\u0006\u0012\u0002\b\u00030\u0013H\u0016J\b\u0010\u0014\u001a\u00020\u0015H\u0016J!\u0010\u0016\u001a\u0004\u0018\u00010\u00172\u0006\u0010\u000b\u001a\u00028\u00012\b\u0010\u0018\u001a\u0004\u0018\u00010\u0019H\u0016¢\u0006\u0002\u0010\u001aR\u0016\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u00068\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00010\u00048\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\u001b"},
      d2 = {"Lkotlinx/coroutines/channels/AbstractChannel$ReceiveHasNext;", "E", "Lkotlinx/coroutines/channels/Receive;", "iterator", "Lkotlinx/coroutines/channels/AbstractChannel$Itr;", "cont", "Lkotlinx/coroutines/CancellableContinuation;", "", "(Lkotlinx/coroutines/channels/AbstractChannel$Itr;Lkotlinx/coroutines/CancellableContinuation;)V", "completeResumeReceive", "", "value", "(Ljava/lang/Object;)V", "resumeOnCancellationFun", "Lkotlin/Function1;", "", "(Ljava/lang/Object;)Lkotlin/jvm/functions/Function1;", "resumeReceiveClosed", "closed", "Lkotlinx/coroutines/channels/Closed;", "toString", "", "tryResumeReceive", "Lkotlinx/coroutines/internal/Symbol;", "otherOp", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$PrepareOp;", "(Ljava/lang/Object;Lkotlinx/coroutines/internal/LockFreeLinkedListNode$PrepareOp;)Lkotlinx/coroutines/internal/Symbol;", "kotlinx-coroutines-core"}
   )
   private static class ReceiveHasNext<E> extends Receive<E> {
      @JvmField
      @NotNull
      public final AbstractChannel.Itr<E> iterator;
      @JvmField
      @NotNull
      public final CancellableContinuation<Boolean> cont;

      public ReceiveHasNext(@NotNull AbstractChannel.Itr<E> a, @NotNull CancellableContinuation<? super Boolean> a) {
         a.iterator = a;
         a.cont = a;
      }

      @Nullable
      public Symbol tryResumeReceive(E a, @Nullable LockFreeLinkedListNode.PrepareOp a) {
         Object var10000 = a.cont.tryResume(true, a != null ? a.desc : null, a.resumeOnCancellationFun(a));
         if (var10000 == null) {
            return null;
         } else {
            Object a = var10000;
            if (DebugKt.getASSERTIONS_ENABLED()) {
               int a = false;
               if (a != CancellableContinuationImplKt.RESUME_TOKEN) {
                  throw new AssertionError();
               }
            }

            if (a != null) {
               a.finishPrepare();
            }

            return CancellableContinuationImplKt.RESUME_TOKEN;
         }
      }

      public void completeResumeReceive(E a) {
         a.iterator.setResult(a);
         a.cont.completeResume(CancellableContinuationImplKt.RESUME_TOKEN);
      }

      public void resumeReceiveClosed(@NotNull Closed<?> a) {
         Object a = a.closeCause == null ? CancellableContinuation.DefaultImpls.tryResume$default(a.cont, false, (Object)null, 2, (Object)null) : a.cont.tryResumeWithException(a.getReceiveException());
         if (a != null) {
            a.iterator.setResult(a);
            a.cont.completeResume(a);
         }

      }

      @Nullable
      public Function1<Throwable, Unit> resumeOnCancellationFun(E a) {
         Function1 var10000 = a.iterator.channel.onUndeliveredElement;
         return var10000 != null ? OnUndeliveredElementKt.bindCancellationFun(var10000, a, a.cont.getContext()) : null;
      }

      @NotNull
      public String toString() {
         return "ReceiveHasNext@" + DebugStringsKt.getHexAddress(a);
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0002\u0018\u0000*\u0004\b\u0001\u0010\u0001*\u0004\b\u0002\u0010\u00022\b\u0012\u0004\u0012\u0002H\u00020\u00032\u00020\u0004BR\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00020\u0006\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00010\b\u0012$\u0010\t\u001a \b\u0001\u0012\u0006\u0012\u0004\u0018\u00010\u000b\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00010\f\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\n\u0012\u0006\u0010\r\u001a\u00020\u000eø\u0001\u0000¢\u0006\u0002\u0010\u000fJ\u0015\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00028\u0002H\u0016¢\u0006\u0002\u0010\u0014J\b\u0010\u0015\u001a\u00020\u0012H\u0016J#\u0010\u0016\u001a\u0010\u0012\u0004\u0012\u00020\u0018\u0012\u0004\u0012\u00020\u0012\u0018\u00010\u00172\u0006\u0010\u0013\u001a\u00028\u0002H\u0016¢\u0006\u0002\u0010\u0019J\u0014\u0010\u001a\u001a\u00020\u00122\n\u0010\u001b\u001a\u0006\u0012\u0002\b\u00030\u001cH\u0016J\b\u0010\u001d\u001a\u00020\u001eH\u0016J!\u0010\u001f\u001a\u0004\u0018\u00010 2\u0006\u0010\u0013\u001a\u00028\u00022\b\u0010!\u001a\u0004\u0018\u00010\"H\u0016¢\u0006\u0002\u0010#R3\u0010\t\u001a \b\u0001\u0012\u0006\u0012\u0004\u0018\u00010\u000b\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00010\f\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\n8\u0006X\u0087\u0004ø\u0001\u0000¢\u0006\u0004\n\u0002\u0010\u0010R\u0016\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00020\u00068\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u00020\u000e8\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00010\b8\u0006X\u0087\u0004¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006$"},
      d2 = {"Lkotlinx/coroutines/channels/AbstractChannel$ReceiveSelect;", "R", "E", "Lkotlinx/coroutines/channels/Receive;", "Lkotlinx/coroutines/DisposableHandle;", "channel", "Lkotlinx/coroutines/channels/AbstractChannel;", "select", "Lkotlinx/coroutines/selects/SelectInstance;", "block", "Lkotlin/Function2;", "", "Lkotlin/coroutines/Continuation;", "receiveMode", "", "(Lkotlinx/coroutines/channels/AbstractChannel;Lkotlinx/coroutines/selects/SelectInstance;Lkotlin/jvm/functions/Function2;I)V", "Lkotlin/jvm/functions/Function2;", "completeResumeReceive", "", "value", "(Ljava/lang/Object;)V", "dispose", "resumeOnCancellationFun", "Lkotlin/Function1;", "", "(Ljava/lang/Object;)Lkotlin/jvm/functions/Function1;", "resumeReceiveClosed", "closed", "Lkotlinx/coroutines/channels/Closed;", "toString", "", "tryResumeReceive", "Lkotlinx/coroutines/internal/Symbol;", "otherOp", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$PrepareOp;", "(Ljava/lang/Object;Lkotlinx/coroutines/internal/LockFreeLinkedListNode$PrepareOp;)Lkotlinx/coroutines/internal/Symbol;", "kotlinx-coroutines-core"}
   )
   private static final class ReceiveSelect<R, E> extends Receive<E> implements DisposableHandle {
      @JvmField
      @NotNull
      public final AbstractChannel<E> channel;
      @JvmField
      @NotNull
      public final SelectInstance<R> select;
      @JvmField
      @NotNull
      public final Function2<Object, Continuation<? super R>, Object> block;
      @JvmField
      public final int receiveMode;

      public ReceiveSelect(@NotNull AbstractChannel<E> a, @NotNull SelectInstance<? super R> a, @NotNull Function2<Object, ? super Continuation<? super R>, ? extends Object> a, int a) {
         a.channel = a;
         a.select = a;
         a.block = a;
         a.receiveMode = a;
      }

      @Nullable
      public Symbol tryResumeReceive(E a1, @Nullable LockFreeLinkedListNode.PrepareOp a) {
         return (Symbol)a.select.trySelectOther(a);
      }

      public void completeResumeReceive(E a) {
         CancellableKt.startCoroutineCancellable(a.block, a.receiveMode == 1 ? ChannelResult.box-impl(ChannelResult.Companion.success-JP2dKIU(a)) : a, a.select.getCompletion(), a.resumeOnCancellationFun(a));
      }

      public void resumeReceiveClosed(@NotNull Closed<?> a) {
         if (a.select.trySelect()) {
            switch(a.receiveMode) {
            case 0:
               a.select.resumeSelectWithException(a.getReceiveException());
               break;
            case 1:
               CancellableKt.startCoroutineCancellable$default(a.block, ChannelResult.box-impl(ChannelResult.Companion.closed-JP2dKIU(a.closeCause)), a.select.getCompletion(), (Function1)null, 4, (Object)null);
            }

         }
      }

      public void dispose() {
         if (a.remove()) {
            a.channel.onReceiveDequeued();
         }

      }

      @Nullable
      public Function1<Throwable, Unit> resumeOnCancellationFun(E a) {
         Function1 var10000 = a.channel.onUndeliveredElement;
         return var10000 != null ? OnUndeliveredElementKt.bindCancellationFun(var10000, a, a.select.getCompletion().getContext()) : null;
      }

      @NotNull
      public String toString() {
         return "ReceiveSelect@" + DebugStringsKt.getHexAddress(a) + '[' + a.select + ",receiveMode=" + a.receiveMode + ']';
      }
   }
}
