package kotlinx.coroutines.channels;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000\u0018\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a%\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00032\u0006\u0010\u0004\u001a\u0002H\u0002H\u0007¢\u0006\u0002\u0010\u0005\u001a,\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00032\u0006\u0010\u0004\u001a\u0002H\u0002ø\u0001\u0000¢\u0006\u0002\u0010\b\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\t"},
   d2 = {"sendBlocking", "", "E", "Lkotlinx/coroutines/channels/SendChannel;", "element", "(Lkotlinx/coroutines/channels/SendChannel;Ljava/lang/Object;)V", "trySendBlocking", "Lkotlinx/coroutines/channels/ChannelResult;", "(Lkotlinx/coroutines/channels/SendChannel;Ljava/lang/Object;)Ljava/lang/Object;", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/channels/ChannelsKt"
)
final class ChannelsKt__ChannelsKt {
   @NotNull
   public static final <E> Object trySendBlocking(@NotNull final SendChannel<? super E> a, final E a) {
      Object a = a.trySend-JP2dKIU(a);
      int a = false;
      if (!(a instanceof ChannelResult.Failed)) {
         Unit a = (Unit)a;
         int a = false;
         return ChannelResult.Companion.success-JP2dKIU(Unit.INSTANCE);
      } else {
         return ((ChannelResult)BuildersKt.runBlocking$default((CoroutineContext)null, (Function2)(new Function2<CoroutineScope, Continuation<? super ChannelResult<? extends Unit>>, Object>((Continuation)null) {
            int label;
            // $FF: synthetic field
            private Object L$0;

            @Nullable
            public final Object invokeSuspend(@NotNull Object param1) {
               // $FF: Couldn't be decompiled
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
               Function2 var3 = new <anonymous constructor>(axxx);
               var3.L$0 = axx;
               return (Continuation)var3;
            }

            @Nullable
            public final Object invoke(@NotNull CoroutineScope axx, @Nullable Continuation<? super ChannelResult<Unit>> axxx) {
               return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
            }
         }), 1, (Object)null)).unbox-impl();
      }
   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in the favour of 'trySendBlocking'. Consider handling the result of 'trySendBlocking' explicitly and rethrow exception if necessary",
      replaceWith = @ReplaceWith(
   expression = "trySendBlocking(element)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   public static final <E> void sendBlocking(@NotNull final SendChannel<? super E> a, final E a) {
      if (!ChannelResult.isSuccess-impl(a.trySend-JP2dKIU(a))) {
         BuildersKt.runBlocking$default((CoroutineContext)null, (Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object axx) {
               Object var2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
               switch(ax.label) {
               case 0:
                  ResultKt.throwOnFailure(axx);
                  SendChannel var10000 = a;
                  Object var10001 = a;
                  Continuation var10002 = (Continuation)ax;
                  ax.label = 1;
                  if (var10000.send(var10001, var10002) == var2) {
                     return var2;
                  }
                  break;
               case 1:
                  ResultKt.throwOnFailure(axx);
                  break;
               default:
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
               }

               return Unit.INSTANCE;
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object a1, @NotNull Continuation<?> axx) {
               return (Continuation)(new <anonymous constructor>(axx));
            }

            @Nullable
            public final Object invoke(@NotNull CoroutineScope axx, @Nullable Continuation<? super Unit> axxx) {
               return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
            }
         }), 1, (Object)null);
      }
   }
}
