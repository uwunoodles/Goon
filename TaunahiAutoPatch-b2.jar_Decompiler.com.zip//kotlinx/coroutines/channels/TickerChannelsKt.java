package kotlinx.coroutines.channels;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function2;
import kotlin.ranges.RangesKt;
import kotlinx.coroutines.AbstractTimeSource;
import kotlinx.coroutines.AbstractTimeSourceKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.EventLoop_commonKt;
import kotlinx.coroutines.GlobalScope;
import kotlinx.coroutines.ObsoleteCoroutinesApi;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000*\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a/\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00032\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00010\u0006H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010\u0007\u001a/\u0010\b\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00032\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00010\u0006H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010\u0007\u001a4\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00010\n2\u0006\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u000b\u001a\u00020\f2\b\b\u0002\u0010\r\u001a\u00020\u000eH\u0007\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u000f"},
   d2 = {"fixedDelayTicker", "", "delayMillis", "", "initialDelayMillis", "channel", "Lkotlinx/coroutines/channels/SendChannel;", "(JJLkotlinx/coroutines/channels/SendChannel;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "fixedPeriodTicker", "ticker", "Lkotlinx/coroutines/channels/ReceiveChannel;", "context", "Lkotlin/coroutines/CoroutineContext;", "mode", "Lkotlinx/coroutines/channels/TickerMode;", "kotlinx-coroutines-core"}
)
public final class TickerChannelsKt {
   @ObsoleteCoroutinesApi
   @NotNull
   public static final ReceiveChannel<Unit> ticker(final long a, final long a, @NotNull CoroutineContext a, @NotNull final TickerMode a) {
      boolean a;
      String var7;
      if (a < 0L) {
         a = false;
         var7 = "Expected non-negative delay, but has " + a + " ms";
         throw new IllegalArgumentException(var7.toString());
      } else if (a < 0L) {
         a = false;
         var7 = "Expected non-negative initial delay, but has " + a + " ms";
         throw new IllegalArgumentException(var7.toString());
      } else {
         return ProduceKt.produce((CoroutineScope)GlobalScope.INSTANCE, Dispatchers.getUnconfined().plus(a), 0, (Function2)(new Function2<ProducerScope<? super Unit>, Continuation<? super Unit>, Object>((Continuation)null) {
            int label;
            // $FF: synthetic field
            private Object L$0;

            @Nullable
            public final Object invokeSuspend(@NotNull Object axx) {
               Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
               switch(ax.label) {
               case 0:
                  ResultKt.throwOnFailure(axx);
                  ProducerScope axxx = (ProducerScope)ax.L$0;
                  long var10000;
                  long var10001;
                  SendChannel var10002;
                  Continuation var10003;
                  switch(null.WhenMappings.$EnumSwitchMapping$0[a.ordinal()]) {
                  case 1:
                     var10000 = a;
                     var10001 = a;
                     var10002 = axxx.getChannel();
                     var10003 = (Continuation)ax;
                     ax.label = 1;
                     if (TickerChannelsKt.fixedPeriodTicker(var10000, var10001, var10002, var10003) == var3) {
                        return var3;
                     }

                     return Unit.INSTANCE;
                  case 2:
                     var10000 = a;
                     var10001 = a;
                     var10002 = axxx.getChannel();
                     var10003 = (Continuation)ax;
                     ax.label = 2;
                     if (TickerChannelsKt.fixedDelayTicker(var10000, var10001, var10002, var10003) == var3) {
                        return var3;
                     }

                     return Unit.INSTANCE;
                  default:
                     return Unit.INSTANCE;
                  }
               case 1:
                  ResultKt.throwOnFailure(axx);
                  break;
               case 2:
                  ResultKt.throwOnFailure(axx);
                  break;
               default:
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
               }

               return Unit.INSTANCE;
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
               Function2 var3 = new <anonymous constructor>(axxx);
               var3.L$0 = axx;
               return (Continuation)var3;
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super Unit> axx, @Nullable Continuation<? super Unit> axxx) {
               return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
            }

            // $FF: synthetic class
            @Metadata(
               mv = {1, 6, 0},
               k = 3,
               xi = 48
            )
            public class WhenMappings {
               // $FF: synthetic field
               public static final int[] $EnumSwitchMapping$0;

               static {
                  int[] var0 = new int[TickerMode.values().length];
                  var0[TickerMode.FIXED_PERIOD.ordinal()] = 1;
                  var0[TickerMode.FIXED_DELAY.ordinal()] = 2;
                  $EnumSwitchMapping$0 = var0;
               }
            }
         }));
      }
   }

   // $FF: synthetic method
   public static ReceiveChannel ticker$default(long var0, long var2, CoroutineContext var4, TickerMode var5, int var6, Object var7) {
      if ((var6 & 2) != 0) {
         var2 = var0;
      }

      if ((var6 & 4) != 0) {
         var4 = (CoroutineContext)EmptyCoroutineContext.INSTANCE;
      }

      if ((var6 & 8) != 0) {
         var5 = TickerMode.FIXED_PERIOD;
      }

      return ticker(var0, var2, var4, var5);
   }

   private static final Object fixedPeriodTicker(long a, long a, SendChannel<? super Unit> a, Continuation<? super Unit> var5) {
      Object a;
      label114: {
         if (var5 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var5;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label114;
            }
         }

         a = new ContinuationImpl(var5) {
            long J$0;
            long J$1;
            Object L$0;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return TickerChannelsKt.fixedPeriodTicker(0L, 0L, (SendChannel)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var18 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      long a;
      long a;
      long a;
      long a;
      long a;
      AbstractTimeSource var10000;
      long var19;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         var10000 = AbstractTimeSourceKt.getTimeSource();
         a = (var10000 != null ? var10000.nanoTime() : System.nanoTime()) + EventLoop_commonKt.delayToNanos(a);
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).J$0 = a;
         ((<undefinedtype>)a).J$1 = a;
         ((<undefinedtype>)a).label = 1;
         if (DelayKt.delay(a, (Continuation)a) == var18) {
            return var18;
         }

         a = EventLoop_commonKt.delayToNanos(a);
         break;
      case 1:
         a = ((<undefinedtype>)a).J$1;
         a = ((<undefinedtype>)a).J$0;
         a = (SendChannel)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         a = EventLoop_commonKt.delayToNanos(a);
         break;
      case 2:
         a = ((<undefinedtype>)a).J$1;
         a = ((<undefinedtype>)a).J$0;
         a = (SendChannel)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         var10000 = AbstractTimeSourceKt.getTimeSource();
         a = var10000 != null ? var10000.nanoTime() : System.nanoTime();
         a = RangesKt.coerceAtLeast(a - a, 0L);
         if (a == 0L) {
            if (a != 0L) {
               a = a - (a - a) % a;
               a = a + a;
               var19 = EventLoop_commonKt.delayNanosToMillis(a);
               ((<undefinedtype>)a).L$0 = a;
               ((<undefinedtype>)a).J$0 = a;
               ((<undefinedtype>)a).J$1 = a;
               ((<undefinedtype>)a).label = 3;
               if (DelayKt.delay(var19, (Continuation)a) == var18) {
                  return var18;
               }
            } else {
               var19 = EventLoop_commonKt.delayNanosToMillis(a);
               ((<undefinedtype>)a).L$0 = a;
               ((<undefinedtype>)a).J$0 = a;
               ((<undefinedtype>)a).J$1 = a;
               ((<undefinedtype>)a).label = 4;
               if (DelayKt.delay(var19, (Continuation)a) == var18) {
                  return var18;
               }
            }
         } else {
            var19 = EventLoop_commonKt.delayNanosToMillis(a);
            ((<undefinedtype>)a).L$0 = a;
            ((<undefinedtype>)a).J$0 = a;
            ((<undefinedtype>)a).J$1 = a;
            ((<undefinedtype>)a).label = 4;
            if (DelayKt.delay(var19, (Continuation)a) == var18) {
               return var18;
            }
         }
         break;
      case 3:
         a = ((<undefinedtype>)a).J$1;
         a = ((<undefinedtype>)a).J$0;
         a = (SendChannel)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      case 4:
         a = ((<undefinedtype>)a).J$1;
         a = ((<undefinedtype>)a).J$0;
         a = (SendChannel)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      while(true) {
         a += a;
         Unit var10001 = Unit.INSTANCE;
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).J$0 = a;
         ((<undefinedtype>)a).J$1 = a;
         ((<undefinedtype>)a).label = 2;
         if (a.send(var10001, (Continuation)a) == var18) {
            return var18;
         }

         var10000 = AbstractTimeSourceKt.getTimeSource();
         a = var10000 != null ? var10000.nanoTime() : System.nanoTime();
         a = RangesKt.coerceAtLeast(a - a, 0L);
         if (a == 0L) {
            if (a != 0L) {
               a = a - (a - a) % a;
               a = a + a;
               var19 = EventLoop_commonKt.delayNanosToMillis(a);
               ((<undefinedtype>)a).L$0 = a;
               ((<undefinedtype>)a).J$0 = a;
               ((<undefinedtype>)a).J$1 = a;
               ((<undefinedtype>)a).label = 3;
               if (DelayKt.delay(var19, (Continuation)a) == var18) {
                  return var18;
               }
            } else {
               var19 = EventLoop_commonKt.delayNanosToMillis(a);
               ((<undefinedtype>)a).L$0 = a;
               ((<undefinedtype>)a).J$0 = a;
               ((<undefinedtype>)a).J$1 = a;
               ((<undefinedtype>)a).label = 4;
               if (DelayKt.delay(var19, (Continuation)a) == var18) {
                  return var18;
               }
            }
         } else {
            var19 = EventLoop_commonKt.delayNanosToMillis(a);
            ((<undefinedtype>)a).L$0 = a;
            ((<undefinedtype>)a).J$0 = a;
            ((<undefinedtype>)a).J$1 = a;
            ((<undefinedtype>)a).label = 4;
            if (DelayKt.delay(var19, (Continuation)a) == var18) {
               return var18;
            }
         }
      }
   }

   private static final Object fixedDelayTicker(long a, long a, SendChannel<? super Unit> a, Continuation<? super Unit> var5) {
      Object a;
      label53: {
         if (var5 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var5;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label53;
            }
         }

         a = new ContinuationImpl(var5) {
            long J$0;
            Object L$0;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return TickerChannelsKt.fixedDelayTicker(0L, 0L, (SendChannel)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var8 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).J$0 = a;
         ((<undefinedtype>)a).label = 1;
         if (DelayKt.delay(a, (Continuation)a) == var8) {
            return var8;
         }
         break;
      case 1:
         a = ((<undefinedtype>)a).J$0;
         a = (SendChannel)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      case 2:
         a = ((<undefinedtype>)a).J$0;
         a = (SendChannel)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).J$0 = a;
         ((<undefinedtype>)a).label = 3;
         if (DelayKt.delay(a, (Continuation)a) == var8) {
            return var8;
         }
         break;
      case 3:
         a = ((<undefinedtype>)a).J$0;
         a = (SendChannel)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      do {
         Unit var10001 = Unit.INSTANCE;
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).J$0 = a;
         ((<undefinedtype>)a).label = 2;
         if (a.send(var10001, (Continuation)a) == var8) {
            return var8;
         }

         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).J$0 = a;
         ((<undefinedtype>)a).label = 3;
      } while(DelayKt.delay(a, (Continuation)a) != var8);

      return var8;
   }
}
