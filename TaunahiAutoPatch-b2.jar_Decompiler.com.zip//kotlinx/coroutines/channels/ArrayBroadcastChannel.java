package kotlinx.coroutines.channels;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CancellationException;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlinx.coroutines.CancellableContinuationImplKt;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.internal.ConcurrentKt;
import kotlinx.coroutines.internal.LockFreeLinkedListNode;
import kotlinx.coroutines.internal.Symbol;
import kotlinx.coroutines.selects.SelectInstance;
import kotlinx.coroutines.selects.SelectKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0084\u0001\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0003\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\t\n\u0002\b\u0006\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\b\u0000\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00028\u00000L2\b\u0012\u0004\u0012\u00028\u00000M:\u0001JB\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u0019\u0010\t\u001a\u00020\b2\b\u0010\u0007\u001a\u0004\u0018\u00010\u0006H\u0017¢\u0006\u0004\b\t\u0010\nJ\u001f\u0010\t\u001a\u00020\r2\u000e\u0010\u0007\u001a\n\u0018\u00010\u000bj\u0004\u0018\u0001`\fH\u0016¢\u0006\u0004\b\t\u0010\u000eJ\u0019\u0010\u000f\u001a\u00020\b2\b\u0010\u0007\u001a\u0004\u0018\u00010\u0006H\u0002¢\u0006\u0004\b\u000f\u0010\nJ\u000f\u0010\u0010\u001a\u00020\rH\u0002¢\u0006\u0004\b\u0010\u0010\u0011J\u0019\u0010\u0012\u001a\u00020\b2\b\u0010\u0007\u001a\u0004\u0018\u00010\u0006H\u0016¢\u0006\u0004\b\u0012\u0010\nJ\u000f\u0010\u0014\u001a\u00020\u0013H\u0002¢\u0006\u0004\b\u0014\u0010\u0015J\u0017\u0010\u0017\u001a\u00028\u00002\u0006\u0010\u0016\u001a\u00020\u0013H\u0002¢\u0006\u0004\b\u0017\u0010\u0018J\u0017\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u0019\u001a\u00028\u0000H\u0014¢\u0006\u0004\b\u001b\u0010\u001cJ#\u0010\u001f\u001a\u00020\u001a2\u0006\u0010\u0019\u001a\u00028\u00002\n\u0010\u001e\u001a\u0006\u0012\u0002\b\u00030\u001dH\u0014¢\u0006\u0004\b\u001f\u0010 J\u0015\u0010\"\u001a\b\u0012\u0004\u0012\u00028\u00000!H\u0016¢\u0006\u0004\b\"\u0010#J4\u0010'\u001a\u00020\r2\u0010\b\u0002\u0010%\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010$2\u0010\b\u0002\u0010&\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010$H\u0082\u0010¢\u0006\u0004\b'\u0010(R\u001c\u0010*\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u001a0)8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b*\u0010+R\u0014\u0010/\u001a\u00020,8TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b-\u0010.R\u0018\u00102\u001a\u000600j\u0002`18\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b2\u00103R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0003\u00104\u001a\u0004\b5\u00106R$\u0010;\u001a\u00020\u00132\u0006\u00107\u001a\u00020\u00138B@BX\u0082\u000e¢\u0006\f\u001a\u0004\b8\u0010\u0015\"\u0004\b9\u0010:R\u0014\u0010<\u001a\u00020\b8TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b<\u0010=R\u0014\u0010>\u001a\u00020\b8TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b>\u0010=R$\u0010A\u001a\u00020\u00022\u0006\u00107\u001a\u00020\u00028B@BX\u0082\u000e¢\u0006\f\u001a\u0004\b?\u00106\"\u0004\b@\u0010\u0005R6\u0010D\u001a\u001e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000$0Bj\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000$`C8\u0002X\u0082\u0004¢\u0006\f\n\u0004\bD\u0010E\u0012\u0004\bF\u0010\u0011R$\u0010I\u001a\u00020\u00132\u0006\u00107\u001a\u00020\u00138B@BX\u0082\u000e¢\u0006\f\u001a\u0004\bG\u0010\u0015\"\u0004\bH\u0010:¨\u0006K"},
   d2 = {"Lkotlinx/coroutines/channels/ArrayBroadcastChannel;", "E", "", "capacity", "ArrayBroadcastChannel", "(I)V", "", "cause", "", "cancel", "(Ljava/lang/Throwable;)Z", "Ljava/util/concurrent/CancellationException;", "Lkotlinx/coroutines/CancellationException;", "", "(Ljava/util/concurrent/CancellationException;)V", "cancelInternal", "checkSubOffers", "()V", "close", "", "computeMinHead", "()J", "index", "elementAt", "(J)Ljava/lang/Object;", "element", "", "offerInternal", "(Ljava/lang/Object;)Ljava/lang/Object;", "Lkotlinx/coroutines/selects/SelectInstance;", "select", "offerSelectInternal", "(Ljava/lang/Object;Lkotlinx/coroutines/selects/SelectInstance;)Ljava/lang/Object;", "Lkotlinx/coroutines/channels/ReceiveChannel;", "openSubscription", "()Lkotlinx/coroutines/channels/ReceiveChannel;", "Lkotlinx/coroutines/channels/ArrayBroadcastChannel$Subscriber;", "addSub", "removeSub", "updateHead", "(Lkotlinx/coroutines/channels/ArrayBroadcastChannel$Subscriber;Lkotlinx/coroutines/channels/ArrayBroadcastChannel$Subscriber;)V", "", "buffer", "[Ljava/lang/Object;", "", "getBufferDebugString", "()Ljava/lang/String;", "bufferDebugString", "Ljava/util/concurrent/locks/ReentrantLock;", "Lkotlinx/coroutines/internal/ReentrantLock;", "bufferLock", "Ljava/util/concurrent/locks/ReentrantLock;", "I", "getCapacity", "()I", "value", "getHead", "setHead", "(J)V", "head", "isBufferAlwaysFull", "()Z", "isBufferFull", "getSize", "setSize", "size", "", "Lkotlinx/coroutines/internal/SubscribersList;", "subscribers", "Ljava/util/List;", "getSubscribers$annotations", "getTail", "setTail", "tail", "Subscriber", "kotlinx-coroutines-core", "Lkotlinx/coroutines/channels/AbstractSendChannel;", "Lkotlinx/coroutines/channels/BroadcastChannel;"}
)
public final class ArrayBroadcastChannel<E> extends AbstractSendChannel<E> implements BroadcastChannel<E> {
   private final int capacity;
   @NotNull
   private final ReentrantLock bufferLock;
   @NotNull
   private final Object[] buffer;
   // $FF: synthetic field
   @NotNull
   private volatile long _head;
   // $FF: synthetic field
   @NotNull
   private volatile long _tail;
   // $FF: synthetic field
   @NotNull
   private volatile int _size;
   @NotNull
   private final List<ArrayBroadcastChannel.Subscriber<E>> subscribers;

   public ArrayBroadcastChannel(int a) {
      super((Function1)null);
      a.capacity = a;
      if (a.capacity < 1) {
         int a = false;
         String var3 = "ArrayBroadcastChannel capacity must be at least 1, but " + a.capacity + " was specified";
         throw new IllegalArgumentException(var3.toString());
      } else {
         a.bufferLock = new ReentrantLock();
         a.buffer = new Object[a.capacity];
         a._head = 0L;
         a._tail = 0L;
         a._size = 0;
         a.subscribers = ConcurrentKt.subscriberList();
      }
   }

   public final int getCapacity() {
      return a.capacity;
   }

   private final long getHead() {
      return a._head;
   }

   private final void setHead(long a) {
      a._head = a;
   }

   private final long getTail() {
      return a._tail;
   }

   private final void setTail(long a) {
      a._tail = a;
   }

   private final int getSize() {
      return a._size;
   }

   private final void setSize(int a) {
      a._size = a;
   }

   /** @deprecated */
   // $FF: synthetic method
   private static void getSubscribers$annotations() {
   }

   protected boolean isBufferAlwaysFull() {
      return false;
   }

   protected boolean isBufferFull() {
      return a.getSize() >= a.capacity;
   }

   @NotNull
   public ReceiveChannel<E> openSubscription() {
      ArrayBroadcastChannel.Subscriber var1 = new ArrayBroadcastChannel.Subscriber(a);
      int a = false;
      updateHead$default(a, var1, (ArrayBroadcastChannel.Subscriber)null, 2, (Object)null);
      return (ReceiveChannel)var1;
   }

   public boolean close(@Nullable Throwable a) {
      if (!super.close(a)) {
         return false;
      } else {
         a.checkSubOffers();
         return true;
      }
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public boolean cancel(Throwable a) {
      return a.cancelInternal(a);
   }

   public void cancel(@Nullable CancellationException a) {
      a.cancelInternal((Throwable)a);
   }

   private final boolean cancelInternal(Throwable a) {
      boolean var2 = a.close(a);
      int a = false;
      Iterator var5 = a.subscribers.iterator();

      while(var5.hasNext()) {
         ArrayBroadcastChannel.Subscriber a = (ArrayBroadcastChannel.Subscriber)var5.next();
         a.cancelInternal$kotlinx_coroutines_core(a);
      }

      return var2;
   }

   @NotNull
   protected Object offerInternal(E a) {
      ReentrantLock a = a.bufferLock;
      int a = false;
      Lock var4 = (Lock)a;
      var4.lock();

      label68: {
         Closed var13;
         try {
            int a = false;
            Closed var10000 = a.getClosedForSend();
            if (var10000 == null) {
               int a = a.getSize();
               if (a >= a.capacity) {
                  Symbol var12 = AbstractChannelKt.OFFER_FAILED;
                  return var12;
               }

               long a = a.getTail();
               a.buffer[(int)(a % (long)a.capacity)] = a;
               a.setSize(a + 1);
               a.setTail(a + 1L);
               Unit var11 = Unit.INSTANCE;
               break label68;
            }

            Closed a = var10000;
            int a = false;
            var13 = a;
         } finally {
            var4.unlock();
         }

         return var13;
      }

      a.checkSubOffers();
      return AbstractChannelKt.OFFER_SUCCESS;
   }

   @NotNull
   protected Object offerSelectInternal(E a, @NotNull SelectInstance<?> a) {
      ReentrantLock a = a.bufferLock;
      int a = false;
      Lock var5 = (Lock)a;
      var5.lock();

      label88: {
         Closed var15;
         try {
            int a = false;
            Closed var10000 = a.getClosedForSend();
            if (var10000 == null) {
               int a = a.getSize();
               if (a >= a.capacity) {
                  Symbol var14 = AbstractChannelKt.OFFER_FAILED;
                  return var14;
               }

               if (!a.trySelect()) {
                  Object var13 = SelectKt.getALREADY_SELECTED();
                  return var13;
               }

               long a = a.getTail();
               a.buffer[(int)(a % (long)a.capacity)] = a;
               a.setSize(a + 1);
               a.setTail(a + 1L);
               Unit var12 = Unit.INSTANCE;
               break label88;
            }

            Closed a = var10000;
            int a = false;
            var15 = a;
         } finally {
            var5.unlock();
         }

         return var15;
      }

      a.checkSubOffers();
      return AbstractChannelKt.OFFER_SUCCESS;
   }

   private final void checkSubOffers() {
      boolean a = false;
      boolean a = false;
      Iterator var3 = a.subscribers.iterator();

      while(var3.hasNext()) {
         ArrayBroadcastChannel.Subscriber a = (ArrayBroadcastChannel.Subscriber)var3.next();
         a = true;
         if (a.checkOffer()) {
            a = true;
         }
      }

      if (a || !a) {
         updateHead$default(a, (ArrayBroadcastChannel.Subscriber)null, (ArrayBroadcastChannel.Subscriber)null, 3, (Object)null);
      }

   }

   private final void updateHead(ArrayBroadcastChannel.Subscriber<E> a, ArrayBroadcastChannel.Subscriber<E> a) {
      ArrayBroadcastChannel var3 = a;
      ArrayBroadcastChannel.Subscriber var4 = a;
      ArrayBroadcastChannel.Subscriber var5 = a;

      while(true) {
         ArrayBroadcastChannel var6 = var3;
         ArrayBroadcastChannel.Subscriber var7 = var4;
         ArrayBroadcastChannel.Subscriber var8 = var5;
         Object a = null;
         ReentrantLock a = var3.bufferLock;
         int a = false;
         Lock var12 = (Lock)a;
         var12.lock();

         label200: {
            try {
               int a = false;
               if (var7 != null) {
                  var7.setSubHead(var6.getTail());
                  boolean a = var6.subscribers.isEmpty();
                  var6.subscribers.add(var7);
                  if (!a) {
                     return;
                  }
               }

               if (var8 != null) {
                  var6.subscribers.remove(var8);
                  if (var6.getHead() != var8.getSubHead()) {
                     return;
                  }
               }

               long a = var6.computeMinHead();
               long a = var6.getTail();
               long a = var6.getHead();
               long a = RangesKt.coerceAtMost(a, a);
               if (a <= a) {
                  return;
               }

               int a = var6.getSize();

               label169:
               while(a < a) {
                  var6.buffer[(int)(a % (long)var6.capacity)] = null;
                  boolean a = a >= var6.capacity;
                  ++a;
                  var6.setHead(a);
                  --a;
                  var6.setSize(a);
                  if (a) {
                     Symbol a;
                     do {
                        Send var10000 = var6.takeFirstSendOrPeekClosed();
                        if (var10000 == null) {
                           continue label169;
                        }

                        a = var10000;
                        if (a instanceof Closed) {
                           continue label169;
                        }

                        Intrinsics.checkNotNull(a);
                        a = a.tryResumeSend((LockFreeLinkedListNode.PrepareOp)null);
                     } while(a == null);

                     if (DebugKt.getASSERTIONS_ENABLED()) {
                        int a = false;
                        if (a != CancellableContinuationImplKt.RESUME_TOKEN) {
                           throw new AssertionError();
                        }
                     }

                     var6.buffer[(int)(a % (long)var6.capacity)] = a.getPollResult();
                     var6.setSize(a + 1);
                     var6.setTail(a + 1L);
                     Unit var27 = Unit.INSTANCE;
                     break label200;
                  }
               }
            } finally {
               var12.unlock();
            }

            return;
         }

         a.completeResumeSend();
         var6.checkSubOffers();
         var3 = var6;
         var4 = null;
         var5 = null;
      }
   }

   // $FF: synthetic method
   static void updateHead$default(ArrayBroadcastChannel var0, ArrayBroadcastChannel.Subscriber var1, ArrayBroadcastChannel.Subscriber var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = null;
      }

      if ((var3 & 2) != 0) {
         var2 = null;
      }

      var0.updateHead(var1, var2);
   }

   private final long computeMinHead() {
      long a = Long.MAX_VALUE;

      ArrayBroadcastChannel.Subscriber a;
      for(Iterator var3 = a.subscribers.iterator(); var3.hasNext(); a = RangesKt.coerceAtMost(a, a.getSubHead())) {
         a = (ArrayBroadcastChannel.Subscriber)var3.next();
      }

      return a;
   }

   private final E elementAt(long a) {
      return a.buffer[(int)(a % (long)a.capacity)];
   }

   @NotNull
   protected String getBufferDebugString() {
      return "(buffer:capacity=" + a.buffer.length + ",size=" + a.getSize() + ')';
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\t\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\b\u0002\u0018\u0000*\u0004\b\u0001\u0010\u00012\b\u0012\u0004\u0012\u00028\u00010'2\b\u0012\u0004\u0012\u00028\u00010(B\u0015\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00010\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\r\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\u0007\u0010\bJ\u0019\u0010\u000b\u001a\u00020\u00062\b\u0010\n\u001a\u0004\u0018\u00010\tH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u000f\u0010\r\u001a\u00020\u0006H\u0002¢\u0006\u0004\b\r\u0010\bJ\u0011\u0010\u000f\u001a\u0004\u0018\u00010\u000eH\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u0011\u0010\u0011\u001a\u0004\u0018\u00010\u000eH\u0014¢\u0006\u0004\b\u0011\u0010\u0010J\u001d\u0010\u0014\u001a\u0004\u0018\u00010\u000e2\n\u0010\u0013\u001a\u0006\u0012\u0002\b\u00030\u0012H\u0014¢\u0006\u0004\b\u0014\u0010\u0015R\u001a\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00010\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0003\u0010\u0016R\u0014\u0010\u0017\u001a\u00020\u00068TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b\u0017\u0010\bR\u0014\u0010\u0018\u001a\u00020\u00068TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b\u0018\u0010\bR\u0014\u0010\u0019\u001a\u00020\u00068TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b\u0019\u0010\bR\u0014\u0010\u001a\u001a\u00020\u00068TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b\u001a\u0010\bR$\u0010!\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001b8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u001d\u0010\u001e\"\u0004\b\u001f\u0010 R\u0018\u0010$\u001a\u00060\"j\u0002`#8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b$\u0010%¨\u0006&"},
      d2 = {"Lkotlinx/coroutines/channels/ArrayBroadcastChannel$Subscriber;", "E", "Lkotlinx/coroutines/channels/ArrayBroadcastChannel;", "broadcastChannel", "ArrayBroadcastChannel$Subscriber", "(Lkotlinx/coroutines/channels/ArrayBroadcastChannel;)V", "", "checkOffer", "()Z", "", "cause", "close", "(Ljava/lang/Throwable;)Z", "needsToCheckOfferWithoutLock", "", "peekUnderLock", "()Ljava/lang/Object;", "pollInternal", "Lkotlinx/coroutines/selects/SelectInstance;", "select", "pollSelectInternal", "(Lkotlinx/coroutines/selects/SelectInstance;)Ljava/lang/Object;", "Lkotlinx/coroutines/channels/ArrayBroadcastChannel;", "isBufferAlwaysEmpty", "isBufferAlwaysFull", "isBufferEmpty", "isBufferFull", "", "value", "getSubHead", "()J", "setSubHead", "(J)V", "subHead", "Ljava/util/concurrent/locks/ReentrantLock;", "Lkotlinx/coroutines/internal/ReentrantLock;", "subLock", "Ljava/util/concurrent/locks/ReentrantLock;", "kotlinx-coroutines-core", "Lkotlinx/coroutines/channels/AbstractChannel;", "Lkotlinx/coroutines/channels/ReceiveChannel;"}
   )
   private static final class Subscriber<E> extends AbstractChannel<E> implements ReceiveChannel<E> {
      @NotNull
      private final ArrayBroadcastChannel<E> broadcastChannel;
      @NotNull
      private final ReentrantLock subLock;
      // $FF: synthetic field
      @NotNull
      private volatile long _subHead;

      public Subscriber(@NotNull ArrayBroadcastChannel<E> a) {
         super((Function1)null);
         a.broadcastChannel = a;
         a.subLock = new ReentrantLock();
         a._subHead = 0L;
      }

      public final long getSubHead() {
         return a._subHead;
      }

      public final void setSubHead(long a) {
         a._subHead = a;
      }

      protected boolean isBufferAlwaysEmpty() {
         return false;
      }

      protected boolean isBufferEmpty() {
         return a.getSubHead() >= a.broadcastChannel.getTail();
      }

      protected boolean isBufferAlwaysFull() {
         throw new IllegalStateException("Should not be used".toString());
      }

      protected boolean isBufferFull() {
         throw new IllegalStateException("Should not be used".toString());
      }

      public boolean close(@Nullable Throwable a) {
         boolean a = super.close(a);
         if (a) {
            ArrayBroadcastChannel.updateHead$default(a.broadcastChannel, (ArrayBroadcastChannel.Subscriber)null, a, 1, (Object)null);
            ReentrantLock a = a.subLock;
            int a = false;
            Lock var5 = (Lock)a;
            var5.lock();

            try {
               int a = false;
               a.setSubHead(a.broadcastChannel.getTail());
               Unit var9 = Unit.INSTANCE;
            } finally {
               var5.unlock();
            }
         }

         return a;
      }

      public final boolean checkOffer() {
         boolean a = false;
         Closed a = null;

         boolean a;
         while(a.needsToCheckOfferWithoutLock() && a.subLock.tryLock()) {
            ReceiveOrClosed a = null;
            Object a = null;

            try {
               a = a.peekUnderLock();
               if (a == AbstractChannelKt.POLL_FAILED) {
                  continue;
               }

               if (a instanceof Closed) {
                  a = (Closed)a;
                  break;
               }

               ReceiveOrClosed var10000 = a.takeFirstReceiveOrPeekClosed();
               if (var10000 == null) {
                  break;
               }

               a = var10000;
               if (a instanceof Closed) {
                  break;
               }

               Symbol var11 = a.tryResumeReceive(a, (LockFreeLinkedListNode.PrepareOp)null);
               if (var11 == null) {
                  continue;
               }

               Symbol a = var11;
               if (DebugKt.getASSERTIONS_ENABLED()) {
                  a = false;
                  if (a != CancellableContinuationImplKt.RESUME_TOKEN) {
                     throw new AssertionError();
                  }
               }

               long a = a.getSubHead();
               a.setSubHead(a + 1L);
               a = true;
            } finally {
               a.subLock.unlock();
            }

            a.completeResumeReceive(a);
         }

         if (a != null) {
            a = false;
            a.close(a.closeCause);
         }

         return a;
      }

      @Nullable
      protected Object pollInternal() {
         boolean a = false;
         ReentrantLock a = a.subLock;
         int a = false;
         Lock var5 = (Lock)a;
         var5.lock();

         boolean a;
         Object var10;
         try {
            a = false;
            Object a = a.peekUnderLock();
            if (!(a instanceof Closed) && a != AbstractChannelKt.POLL_FAILED) {
               long a = a.getSubHead();
               a.setSubHead(a + 1L);
               a = true;
            }

            var10 = a;
         } finally {
            var5.unlock();
         }

         Closed var10000 = var10 instanceof Closed ? (Closed)var10 : null;
         if ((var10 instanceof Closed ? (Closed)var10 : null) != null) {
            Closed var13 = var10000;
            a = false;
            a.close(var13.closeCause);
         }

         if (a.checkOffer()) {
            a = true;
         }

         if (a) {
            ArrayBroadcastChannel.updateHead$default(a.broadcastChannel, (ArrayBroadcastChannel.Subscriber)null, (ArrayBroadcastChannel.Subscriber)null, 3, (Object)null);
         }

         return var10;
      }

      @Nullable
      protected Object pollSelectInternal(@NotNull SelectInstance<?> a) {
         boolean a = false;
         ReentrantLock a = a.subLock;
         int a = false;
         Lock var6 = (Lock)a;
         var6.lock();

         boolean a;
         Object var11;
         try {
            a = false;
            Object a = a.peekUnderLock();
            if (!(a instanceof Closed) && a != AbstractChannelKt.POLL_FAILED) {
               if (!a.trySelect()) {
                  a = SelectKt.getALREADY_SELECTED();
               } else {
                  long a = a.getSubHead();
                  a.setSubHead(a + 1L);
                  a = true;
               }
            }

            var11 = a;
         } finally {
            var6.unlock();
         }

         Closed var10000 = var11 instanceof Closed ? (Closed)var11 : null;
         if ((var11 instanceof Closed ? (Closed)var11 : null) != null) {
            Closed var14 = var10000;
            a = false;
            a.close(var14.closeCause);
         }

         if (a.checkOffer()) {
            a = true;
         }

         if (a) {
            ArrayBroadcastChannel.updateHead$default(a.broadcastChannel, (ArrayBroadcastChannel.Subscriber)null, (ArrayBroadcastChannel.Subscriber)null, 3, (Object)null);
         }

         return var11;
      }

      private final boolean needsToCheckOfferWithoutLock() {
         if (a.getClosedForReceive() != null) {
            return false;
         } else {
            return !a.isBufferEmpty() || a.broadcastChannel.getClosedForReceive() != null;
         }
      }

      private final Object peekUnderLock() {
         long a = a.getSubHead();
         Closed a = a.broadcastChannel.getClosedForReceive();
         long a = a.broadcastChannel.getTail();
         if (a >= a) {
            Object var10000 = a;
            if (a == null) {
               var10000 = a.getClosedForReceive();
               if (var10000 == null) {
                  var10000 = AbstractChannelKt.POLL_FAILED;
               }
            }

            return var10000;
         } else {
            Object a = a.broadcastChannel.elementAt(a);
            Closed a = a.getClosedForReceive();
            return a != null ? a : a;
         }
      }
   }
}
