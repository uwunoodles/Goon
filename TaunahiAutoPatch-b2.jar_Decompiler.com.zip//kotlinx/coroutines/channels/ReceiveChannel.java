package kotlinx.coroutines.channels;

import java.util.concurrent.CancellationException;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.internal.LowPriorityInOverloadResolution;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.ExperimentalCoroutinesApi;
import kotlinx.coroutines.InternalCoroutinesApi;
import kotlinx.coroutines.internal.StackTraceRecoveryKt;
import kotlinx.coroutines.selects.SelectClause1;
import kotlinx.coroutines.selects.SelectInstance;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\bf\u0018\u0000*\u0006\b\u0000\u0010\u0001 \u00012\u00020\u0002J\b\u0010\u0014\u001a\u00020\u0015H\u0017J\u0014\u0010\u0014\u001a\u00020\u00042\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u00010\u0017H'J\u001a\u0010\u0014\u001a\u00020\u00152\u0010\b\u0002\u0010\u0016\u001a\n\u0018\u00010\u0018j\u0004\u0018\u0001`\u0019H&J\u000f\u0010\u001a\u001a\b\u0012\u0004\u0012\u00028\u00000\u001bH¦\u0002J\u000f\u0010\u001c\u001a\u0004\u0018\u00018\u0000H\u0017¢\u0006\u0002\u0010\u001dJ\u0011\u0010\u001e\u001a\u00028\u0000H¦@ø\u0001\u0000¢\u0006\u0002\u0010\u001fJ\"\u0010 \u001a\b\u0012\u0004\u0012\u00028\u00000\u000fH¦@ø\u0001\u0000ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\u0004\b!\u0010\u001fJ\u0013\u0010\"\u001a\u0004\u0018\u00018\u0000H\u0097@ø\u0001\u0000¢\u0006\u0002\u0010\u001fJ\u001e\u0010#\u001a\b\u0012\u0004\u0012\u00028\u00000\u000fH&ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\u0004\b$\u0010\u001dR\u001a\u0010\u0003\u001a\u00020\u00048&X§\u0004¢\u0006\f\u0012\u0004\b\u0005\u0010\u0006\u001a\u0004\b\u0003\u0010\u0007R\u001a\u0010\b\u001a\u00020\u00048&X§\u0004¢\u0006\f\u0012\u0004\b\t\u0010\u0006\u001a\u0004\b\b\u0010\u0007R\u0018\u0010\n\u001a\b\u0012\u0004\u0012\u00028\u00000\u000bX¦\u0004¢\u0006\u0006\u001a\u0004\b\f\u0010\rR!\u0010\u000e\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u000f0\u000bX¦\u0004ø\u0001\u0000¢\u0006\u0006\u001a\u0004\b\u0010\u0010\rR\"\u0010\u0011\u001a\n\u0012\u0006\u0012\u0004\u0018\u00018\u00000\u000b8VX\u0097\u0004¢\u0006\f\u0012\u0004\b\u0012\u0010\u0006\u001a\u0004\b\u0013\u0010\r\u0082\u0002\u000f\n\u0002\b\u0019\n\u0002\b!\n\u0005\b¡\u001e0\u0001¨\u0006%"},
   d2 = {"Lkotlinx/coroutines/channels/ReceiveChannel;", "E", "", "isClosedForReceive", "", "isClosedForReceive$annotations", "()V", "()Z", "isEmpty", "isEmpty$annotations", "onReceive", "Lkotlinx/coroutines/selects/SelectClause1;", "getOnReceive", "()Lkotlinx/coroutines/selects/SelectClause1;", "onReceiveCatching", "Lkotlinx/coroutines/channels/ChannelResult;", "getOnReceiveCatching", "onReceiveOrNull", "getOnReceiveOrNull$annotations", "getOnReceiveOrNull", "cancel", "", "cause", "", "Ljava/util/concurrent/CancellationException;", "Lkotlinx/coroutines/CancellationException;", "iterator", "Lkotlinx/coroutines/channels/ChannelIterator;", "poll", "()Ljava/lang/Object;", "receive", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "receiveCatching", "receiveCatching-JP2dKIU", "receiveOrNull", "tryReceive", "tryReceive-PtdJZtk", "kotlinx-coroutines-core"}
)
public interface ReceiveChannel<E> {
   boolean isClosedForReceive();

   boolean isEmpty();

   @Nullable
   Object receive(@NotNull Continuation<? super E> var1);

   @NotNull
   SelectClause1<E> getOnReceive();

   @Nullable
   Object receiveCatching_JP2dKIU/* $FF was: receiveCatching-JP2dKIU*/(@NotNull Continuation<? super ChannelResult<? extends E>> var1);

   @NotNull
   SelectClause1<ChannelResult<E>> getOnReceiveCatching();

   @NotNull
   Object tryReceive_PtdJZtk/* $FF was: tryReceive-PtdJZtk*/();

   @NotNull
   ChannelIterator<E> iterator();

   void cancel(@Nullable CancellationException var1);

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   void cancel();

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   boolean cancel(Throwable var1);

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in the favour of 'tryReceive'. Please note that the provided replacement does not rethrow channel's close cause as 'poll' did, for the precise replacement please refer to the 'poll' documentation",
      replaceWith = @ReplaceWith(
   expression = "tryReceive().getOrNull()",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @Nullable
   E poll();

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in favor of 'receiveCatching'. Please note that the provided replacement does not rethrow channel's close cause as 'receiveOrNull' did, for the detailed replacement please refer to the 'receiveOrNull' documentation",
      replaceWith = @ReplaceWith(
   expression = "receiveCatching().getOrNull()",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @LowPriorityInOverloadResolution
   @Nullable
   Object receiveOrNull(@NotNull Continuation<? super E> var1);

   /** @deprecated */
   @NotNull
   SelectClause1<E> getOnReceiveOrNull();

   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public static final class DefaultImpls {
      /** @deprecated */
      // $FF: synthetic method
      @ExperimentalCoroutinesApi
      public static void isClosedForReceive$annotations() {
      }

      /** @deprecated */
      // $FF: synthetic method
      @ExperimentalCoroutinesApi
      public static void isEmpty$annotations() {
      }

      // $FF: synthetic method
      public static void cancel$default(ReceiveChannel var0, CancellationException var1, int var2, Object var3) {
         if (var3 != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: cancel");
         } else {
            if ((var2 & 1) != 0) {
               var1 = null;
            }

            var0.cancel(var1);
         }
      }

      /** @deprecated */
      // $FF: synthetic method
      @Deprecated(
         message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
         level = DeprecationLevel.HIDDEN
      )
      public static void cancel(ReceiveChannel a) {
         a.cancel((CancellationException)null);
      }

      /** @deprecated */
      // $FF: synthetic method
      public static boolean cancel$default(ReceiveChannel var0, Throwable var1, int var2, Object var3) {
         if (var3 != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: cancel");
         } else {
            if ((var2 & 1) != 0) {
               var1 = null;
            }

            return var0.cancel(var1);
         }
      }

      /** @deprecated */
      @Deprecated(
         message = "Deprecated in the favour of 'tryReceive'. Please note that the provided replacement does not rethrow channel's close cause as 'poll' did, for the precise replacement please refer to the 'poll' documentation",
         replaceWith = @ReplaceWith(
   expression = "tryReceive().getOrNull()",
   imports = {}
),
         level = DeprecationLevel.ERROR
      )
      @Nullable
      public static <E> E poll(@NotNull ReceiveChannel<? extends E> a) {
         Object a = a.tryReceive-PtdJZtk();
         if (ChannelResult.isSuccess-impl(a)) {
            return ChannelResult.getOrThrow-impl(a);
         } else {
            Throwable var10000 = ChannelResult.exceptionOrNull-impl(a);
            if (var10000 == null) {
               return null;
            } else {
               throw StackTraceRecoveryKt.recoverStackTrace(var10000);
            }
         }
      }

      /** @deprecated */
      @Deprecated(
         message = "Deprecated in favor of 'receiveCatching'. Please note that the provided replacement does not rethrow channel's close cause as 'receiveOrNull' did, for the detailed replacement please refer to the 'receiveOrNull' documentation",
         replaceWith = @ReplaceWith(
   expression = "receiveCatching().getOrNull()",
   imports = {}
),
         level = DeprecationLevel.ERROR
      )
      @LowPriorityInOverloadResolution
      @Nullable
      public static <E> Object receiveOrNull(@NotNull ReceiveChannel<? extends E> a, @NotNull Continuation<? super E> var1) {
         Object a;
         label20: {
            if (var1 instanceof <undefinedtype>) {
               a = (<undefinedtype>)var1;
               if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
                  ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
                  break label20;
               }
            }

            a = new ContinuationImpl(var1) {
               // $FF: synthetic field
               Object result;
               int label;

               @Nullable
               public final Object invokeSuspend(@NotNull Object ax) {
                  a.result = ax;
                  a.label |= Integer.MIN_VALUE;
                  return ReceiveChannel.DefaultImpls.receiveOrNull((ReceiveChannel)null, (Continuation)a);
               }
            };
         }

         Object a = ((<undefinedtype>)a).result;
         Object var4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
         Object var10000;
         switch(((<undefinedtype>)a).label) {
         case 0:
            ResultKt.throwOnFailure(a);
            ((<undefinedtype>)a).label = 1;
            var10000 = a.receiveCatching-JP2dKIU((Continuation)a);
            if (var10000 == var4) {
               return var4;
            }
            break;
         case 1:
            ResultKt.throwOnFailure(a);
            var10000 = ((ChannelResult)a).unbox-impl();
            break;
         default:
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
         }

         return ChannelResult.getOrNull-impl(var10000);
      }

      /** @deprecated */
      @NotNull
      public static <E> SelectClause1<E> getOnReceiveOrNull(@NotNull final ReceiveChannel<? extends E> a) {
         return (SelectClause1)(new SelectClause1<E>() {
            @InternalCoroutinesApi
            public <R> void registerSelectClause1(@NotNull SelectInstance<? super R> axx, @NotNull final Function2<? super E, ? super Continuation<? super R>, ? extends Object> axxx) {
               a.getOnReceiveCatching().registerSelectClause1(axx, (Function2)(new Function2<ChannelResult<? extends E>, Continuation<? super R>, Object>((Continuation)null) {
                  int label;
                  // $FF: synthetic field
                  Object L$0;

                  @Nullable
                  public final Object invokeSuspend(@NotNull Object axx) {
                     Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                     Object var10000;
                     switch(ax.label) {
                     case 0:
                        ResultKt.throwOnFailure(axx);
                        Object axxxx = ((ChannelResult)ax.L$0).unbox-impl();
                        Throwable var6 = ChannelResult.exceptionOrNull-impl(axxxx);
                        if (var6 != null) {
                           Throwable axxxxx = var6;
                           int axxxxxx = false;
                           throw axxxxx;
                        }

                        Function2 var7 = axxx;
                        Object var10001 = ChannelResult.getOrNull-impl(axxxx);
                        ax.label = 1;
                        var10000 = var7.invoke(var10001, ax);
                        if (var10000 == var5) {
                           return var5;
                        }
                        break;
                     case 1:
                        ResultKt.throwOnFailure(axx);
                        var10000 = axx;
                        break;
                     default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                     }

                     return var10000;
                  }

                  @NotNull
                  public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxxx) {
                     Function2 var3 = new <anonymous constructor>(axxxx);
                     var3.L$0 = axx;
                     return (Continuation)var3;
                  }

                  @Nullable
                  public final Object invoke_WpGqRn0/* $FF was: invoke-WpGqRn0*/(@NotNull Object axx, @Nullable Continuation<? super R> axxxx) {
                     return ((<undefinedtype>)ax.create(ChannelResult.box-impl(axx), axxxx)).invokeSuspend(Unit.INSTANCE);
                  }
               }));
            }
         });
      }

      /** @deprecated */
      // $FF: synthetic method
      @Deprecated(
         message = "Deprecated in favor of onReceiveCatching extension",
         replaceWith = @ReplaceWith(
   expression = "onReceiveCatching",
   imports = {}
),
         level = DeprecationLevel.ERROR
      )
      public static void getOnReceiveOrNull$annotations() {
      }
   }
}
