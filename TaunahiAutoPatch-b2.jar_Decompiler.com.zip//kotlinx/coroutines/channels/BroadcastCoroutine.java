package kotlinx.coroutines.channels;

import java.util.concurrent.CancellationException;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function1;
import kotlinx.coroutines.AbstractCoroutine;
import kotlinx.coroutines.CoroutineExceptionHandlerKt;
import kotlinx.coroutines.ExperimentalCoroutinesApi;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.JobCancellationException;
import kotlinx.coroutines.JobSupport;
import kotlinx.coroutines.selects.SelectClause2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000d\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0012\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00020\u00030\u00022\b\u0012\u0004\u0012\u0002H\u00010\u00042\b\u0012\u0004\u0012\u0002H\u00010\u0005B#\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005\u0012\u0006\u0010\t\u001a\u00020\n¢\u0006\u0002\u0010\u000bJ\u0012\u0010\u0019\u001a\u00020\n2\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0007J\u0016\u0010\u0019\u001a\u00020\u00032\u000e\u0010\u001a\u001a\n\u0018\u00010\u001cj\u0004\u0018\u0001`\u001dJ\u0010\u0010\u001e\u001a\u00020\u00032\u0006\u0010\u001a\u001a\u00020\u001bH\u0016J\u0012\u0010\u001f\u001a\u00020\n2\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0016J.\u0010 \u001a\u00020\u00032#\u0010!\u001a\u001f\u0012\u0015\u0012\u0013\u0018\u00010\u001b¢\u0006\f\b#\u0012\b\b$\u0012\u0004\b\b(\u001a\u0012\u0004\u0012\u00020\u00030\"H\u0097\u0001J\u0016\u0010%\u001a\u00020\n2\u0006\u0010&\u001a\u00028\u0000H\u0097\u0001¢\u0006\u0002\u0010'J\u0018\u0010(\u001a\u00020\u00032\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010)\u001a\u00020\nH\u0014J\u0015\u0010*\u001a\u00020\u00032\u0006\u0010+\u001a\u00020\u0003H\u0014¢\u0006\u0002\u0010,J\u000f\u0010-\u001a\b\u0012\u0004\u0012\u00028\u00000.H\u0096\u0001J\u0019\u0010/\u001a\u00020\u00032\u0006\u0010&\u001a\u00028\u0000H\u0096Aø\u0001\u0000¢\u0006\u0002\u00100J'\u00101\u001a\b\u0012\u0004\u0012\u00020\u0003022\u0006\u0010&\u001a\u00028\u0000H\u0096\u0001ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\u0004\b3\u00104R\u001a\u0010\b\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005X\u0084\u0004¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u001a\u0010\u000e\u001a\b\u0012\u0004\u0012\u00028\u00000\u000f8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0010\u0010\u0011R\u0014\u0010\u0012\u001a\u00020\n8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0013R\u0014\u0010\u0014\u001a\u00020\n8\u0016X\u0097\u0005¢\u0006\u0006\u001a\u0004\b\u0014\u0010\u0013R$\u0010\u0015\u001a\u0014\u0012\u0004\u0012\u00028\u0000\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u000f0\u0016X\u0096\u0005¢\u0006\u0006\u001a\u0004\b\u0017\u0010\u0018\u0082\u0002\u000f\n\u0002\b\u0019\n\u0002\b!\n\u0005\b¡\u001e0\u0001¨\u00065"},
   d2 = {"Lkotlinx/coroutines/channels/BroadcastCoroutine;", "E", "Lkotlinx/coroutines/AbstractCoroutine;", "", "Lkotlinx/coroutines/channels/ProducerScope;", "Lkotlinx/coroutines/channels/BroadcastChannel;", "parentContext", "Lkotlin/coroutines/CoroutineContext;", "_channel", "active", "", "(Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/channels/BroadcastChannel;Z)V", "get_channel", "()Lkotlinx/coroutines/channels/BroadcastChannel;", "channel", "Lkotlinx/coroutines/channels/SendChannel;", "getChannel", "()Lkotlinx/coroutines/channels/SendChannel;", "isActive", "()Z", "isClosedForSend", "onSend", "Lkotlinx/coroutines/selects/SelectClause2;", "getOnSend", "()Lkotlinx/coroutines/selects/SelectClause2;", "cancel", "cause", "", "Ljava/util/concurrent/CancellationException;", "Lkotlinx/coroutines/CancellationException;", "cancelInternal", "close", "invokeOnClose", "handler", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "offer", "element", "(Ljava/lang/Object;)Z", "onCancelled", "handled", "onCompleted", "value", "(Lkotlin/Unit;)V", "openSubscription", "Lkotlinx/coroutines/channels/ReceiveChannel;", "send", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "trySend", "Lkotlinx/coroutines/channels/ChannelResult;", "trySend-JP2dKIU", "(Ljava/lang/Object;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
class BroadcastCoroutine<E> extends AbstractCoroutine<Unit> implements ProducerScope<E>, BroadcastChannel<E> {
   @NotNull
   private final BroadcastChannel<E> _channel;

   public BroadcastCoroutine(@NotNull CoroutineContext a, @NotNull BroadcastChannel<E> a, boolean a) {
      super(a, false, a);
      a._channel = a;
      a.initParentJob((Job)a.get((CoroutineContext.Key)Job.Key));
   }

   @NotNull
   protected final BroadcastChannel<E> get_channel() {
      return a._channel;
   }

   public boolean isClosedForSend() {
      return a._channel.isClosedForSend();
   }

   @NotNull
   public SelectClause2<E, SendChannel<E>> getOnSend() {
      return a._channel.getOnSend();
   }

   @ExperimentalCoroutinesApi
   public void invokeOnClose(@NotNull Function1<? super Throwable, Unit> a) {
      a._channel.invokeOnClose(a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in the favour of 'trySend' method",
      replaceWith = @ReplaceWith(
   expression = "trySend(element).isSuccess",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   public boolean offer(E a) {
      return a._channel.offer(a);
   }

   @NotNull
   public ReceiveChannel<E> openSubscription() {
      return a._channel.openSubscription();
   }

   @Nullable
   public Object send(E a, @NotNull Continuation<? super Unit> a) {
      return a._channel.send(a, a);
   }

   @NotNull
   public Object trySend_JP2dKIU/* $FF was: trySend-JP2dKIU*/(E a) {
      return a._channel.trySend-JP2dKIU(a);
   }

   public boolean isActive() {
      return super.isActive();
   }

   @NotNull
   public SendChannel<E> getChannel() {
      return (SendChannel)a;
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public final boolean cancel(Throwable a) {
      Throwable var10001 = a;
      if (a == null) {
         String a = null;
         Throwable a = null;
         int a = false;
         var10001 = (Throwable)(new JobCancellationException(JobSupport.access$cancellationExceptionMessage((JobSupport)a), (Throwable)a, (Job)((JobSupport)a)));
      }

      a.cancelInternal(var10001);
      return true;
   }

   public final void cancel(@Nullable CancellationException a) {
      CancellationException var10001 = a;
      if (a == null) {
         String a = null;
         Throwable a = null;
         int a = false;
         var10001 = (CancellationException)(new JobCancellationException(JobSupport.access$cancellationExceptionMessage((JobSupport)a), (Throwable)a, (Job)((JobSupport)a)));
      }

      a.cancelInternal((Throwable)var10001);
   }

   public void cancelInternal(@NotNull Throwable a) {
      CancellationException a = JobSupport.toCancellationException$default((JobSupport)a, a, (String)null, 1, (Object)null);
      a._channel.cancel(a);
      a.cancelCoroutine((Throwable)a);
   }

   protected void onCompleted(@NotNull Unit a1) {
      SendChannel.DefaultImpls.close$default((SendChannel)a._channel, (Throwable)null, 1, (Object)null);
   }

   protected void onCancelled(@NotNull Throwable a, boolean a) {
      boolean a = a._channel.close(a);
      if (!a && !a) {
         CoroutineExceptionHandlerKt.handleCoroutineException(a.getContext(), a);
      }

   }

   public boolean close(@Nullable Throwable a) {
      boolean a = a._channel.close(a);
      a.start();
      return a;
   }
}
