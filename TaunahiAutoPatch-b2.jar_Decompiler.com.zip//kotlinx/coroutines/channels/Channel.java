package kotlinx.coroutines.channels;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.coroutines.Continuation;
import kotlin.internal.LowPriorityInOverloadResolution;
import kotlinx.coroutines.internal.SystemPropsKt;
import kotlinx.coroutines.selects.SelectClause1;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bf\u0018\u0000 \u0004*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0003:\u0001\u0004¨\u0006\u0005"},
   d2 = {"Lkotlinx/coroutines/channels/Channel;", "E", "Lkotlinx/coroutines/channels/SendChannel;", "Lkotlinx/coroutines/channels/ReceiveChannel;", "Factory", "kotlinx-coroutines-core"}
)
public interface Channel<E> extends SendChannel<E>, ReceiveChannel<E> {
   @NotNull
   Channel.Factory Factory = Channel.Factory.$$INSTANCE;
   int UNLIMITED = Integer.MAX_VALUE;
   int RENDEZVOUS = 0;
   int CONFLATED = -1;
   int BUFFERED = -2;
   int OPTIONAL_CHANNEL = -3;
   @NotNull
   String DEFAULT_BUFFER_PROPERTY_NAME = "kotlinx.coroutines.channels.defaultBuffer";

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\u00020\u0004X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0080T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u000e"},
      d2 = {"Lkotlinx/coroutines/channels/Channel$Factory;", "", "()V", "BUFFERED", "", "CHANNEL_DEFAULT_CAPACITY", "getCHANNEL_DEFAULT_CAPACITY$kotlinx_coroutines_core", "()I", "CONFLATED", "DEFAULT_BUFFER_PROPERTY_NAME", "", "OPTIONAL_CHANNEL", "RENDEZVOUS", "UNLIMITED", "kotlinx-coroutines-core"}
   )
   public static final class Factory {
      // $FF: synthetic field
      static final Channel.Factory $$INSTANCE = new Channel.Factory();
      public static final int UNLIMITED = Integer.MAX_VALUE;
      public static final int RENDEZVOUS = 0;
      public static final int CONFLATED = -1;
      public static final int BUFFERED = -2;
      public static final int OPTIONAL_CHANNEL = -3;
      @NotNull
      public static final String DEFAULT_BUFFER_PROPERTY_NAME = "kotlinx.coroutines.channels.defaultBuffer";
      private static final int CHANNEL_DEFAULT_CAPACITY = SystemPropsKt.systemProp("kotlinx.coroutines.channels.defaultBuffer", 64, 1, 2147483646);

      private Factory() {
      }

      public final int getCHANNEL_DEFAULT_CAPACITY$kotlinx_coroutines_core() {
         return CHANNEL_DEFAULT_CAPACITY;
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public static final class DefaultImpls {
      /** @deprecated */
      @Deprecated(
         message = "Deprecated in the favour of 'trySend' method",
         replaceWith = @ReplaceWith(
   expression = "trySend(element).isSuccess",
   imports = {}
),
         level = DeprecationLevel.ERROR
      )
      public static <E> boolean offer(@NotNull Channel<E> a, E a) {
         return SendChannel.DefaultImpls.offer((SendChannel)a, a);
      }

      /** @deprecated */
      // $FF: synthetic method
      @Deprecated(
         message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
         level = DeprecationLevel.HIDDEN
      )
      public static void cancel(Channel a) {
         ReceiveChannel.DefaultImpls.cancel((ReceiveChannel)a);
      }

      /** @deprecated */
      @Deprecated(
         message = "Deprecated in the favour of 'tryReceive'. Please note that the provided replacement does not rethrow channel's close cause as 'poll' did, for the precise replacement please refer to the 'poll' documentation",
         replaceWith = @ReplaceWith(
   expression = "tryReceive().getOrNull()",
   imports = {}
),
         level = DeprecationLevel.ERROR
      )
      @Nullable
      public static <E> E poll(@NotNull Channel<E> a) {
         return ReceiveChannel.DefaultImpls.poll((ReceiveChannel)a);
      }

      /** @deprecated */
      @Deprecated(
         message = "Deprecated in favor of 'receiveCatching'. Please note that the provided replacement does not rethrow channel's close cause as 'receiveOrNull' did, for the detailed replacement please refer to the 'receiveOrNull' documentation",
         replaceWith = @ReplaceWith(
   expression = "receiveCatching().getOrNull()",
   imports = {}
),
         level = DeprecationLevel.ERROR
      )
      @LowPriorityInOverloadResolution
      @Nullable
      public static <E> Object receiveOrNull(@NotNull Channel<E> a, @NotNull Continuation<? super E> a) {
         return ReceiveChannel.DefaultImpls.receiveOrNull((ReceiveChannel)a, a);
      }

      /** @deprecated */
      @NotNull
      public static <E> SelectClause1<E> getOnReceiveOrNull(@NotNull Channel<E> a) {
         return ReceiveChannel.DefaultImpls.getOnReceiveOrNull((ReceiveChannel)a);
      }
   }
}
