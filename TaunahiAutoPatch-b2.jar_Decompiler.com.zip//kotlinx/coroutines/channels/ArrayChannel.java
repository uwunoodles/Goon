package kotlinx.coroutines.channels;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CancellableContinuationImplKt;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.internal.AtomicDesc;
import kotlinx.coroutines.internal.AtomicKt;
import kotlinx.coroutines.internal.LockFreeLinkedListNode;
import kotlinx.coroutines.internal.OnUndeliveredElementKt;
import kotlinx.coroutines.internal.Symbol;
import kotlinx.coroutines.selects.SelectInstance;
import kotlinx.coroutines.selects.SelectKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000n\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\b\u0010\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00028\u00000BB9\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012 \u0010\t\u001a\u001c\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u0006j\n\u0012\u0004\u0012\u00028\u0000\u0018\u0001`\b¢\u0006\u0004\b\n\u0010\u000bJ\u001f\u0010\u000e\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\u00022\u0006\u0010\r\u001a\u00028\u0000H\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ\u001d\u0010\u0013\u001a\u00020\u00122\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00028\u00000\u0010H\u0014¢\u0006\u0004\b\u0013\u0010\u0014J\u0019\u0010\u0018\u001a\u0004\u0018\u00010\u00172\u0006\u0010\u0016\u001a\u00020\u0015H\u0014¢\u0006\u0004\b\u0018\u0010\u0019J\u0017\u0010\u001a\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\u0002H\u0002¢\u0006\u0004\b\u001a\u0010\u001bJ\u0017\u0010\u001c\u001a\u00020\u00172\u0006\u0010\r\u001a\u00028\u0000H\u0014¢\u0006\u0004\b\u001c\u0010\u001dJ#\u0010 \u001a\u00020\u00172\u0006\u0010\r\u001a\u00028\u00002\n\u0010\u001f\u001a\u0006\u0012\u0002\b\u00030\u001eH\u0014¢\u0006\u0004\b \u0010!J\u0017\u0010#\u001a\u00020\u00072\u0006\u0010\"\u001a\u00020\u0012H\u0014¢\u0006\u0004\b#\u0010$J\u0011\u0010%\u001a\u0004\u0018\u00010\u0017H\u0014¢\u0006\u0004\b%\u0010&J\u001d\u0010'\u001a\u0004\u0018\u00010\u00172\n\u0010\u001f\u001a\u0006\u0012\u0002\b\u00030\u001eH\u0014¢\u0006\u0004\b'\u0010(J\u0019\u0010*\u001a\u0004\u0018\u00010)2\u0006\u0010\f\u001a\u00020\u0002H\u0002¢\u0006\u0004\b*\u0010+R\u001e\u0010-\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00170,8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b-\u0010.R\u0014\u00102\u001a\u00020/8TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b0\u00101R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0003\u00103R\u0016\u00104\u001a\u00020\u00028\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b4\u00103R\u0014\u00105\u001a\u00020\u00128DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b5\u00106R\u0014\u00107\u001a\u00020\u00128DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b7\u00106R\u0014\u00108\u001a\u00020\u00128DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b8\u00106R\u0014\u00109\u001a\u00020\u00128DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b9\u00106R\u0014\u0010:\u001a\u00020\u00128VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b:\u00106R\u0014\u0010;\u001a\u00020\u00128VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b;\u00106R\u0018\u0010>\u001a\u00060<j\u0002`=8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b>\u0010?R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0005\u0010@¨\u0006A"},
   d2 = {"Lkotlinx/coroutines/channels/ArrayChannel;", "E", "", "capacity", "Lkotlinx/coroutines/channels/BufferOverflow;", "onBufferOverflow", "Lkotlin/Function1;", "", "Lkotlinx/coroutines/internal/OnUndeliveredElement;", "onUndeliveredElement", "ArrayChannel", "(ILkotlinx/coroutines/channels/BufferOverflow;Lkotlin/jvm/functions/Function1;)V", "currentSize", "element", "enqueueElement", "(ILjava/lang/Object;)V", "Lkotlinx/coroutines/channels/Receive;", "receive", "", "enqueueReceiveInternal", "(Lkotlinx/coroutines/channels/Receive;)Z", "Lkotlinx/coroutines/channels/Send;", "send", "", "enqueueSend", "(Lkotlinx/coroutines/channels/Send;)Ljava/lang/Object;", "ensureCapacity", "(I)V", "offerInternal", "(Ljava/lang/Object;)Ljava/lang/Object;", "Lkotlinx/coroutines/selects/SelectInstance;", "select", "offerSelectInternal", "(Ljava/lang/Object;Lkotlinx/coroutines/selects/SelectInstance;)Ljava/lang/Object;", "wasClosed", "onCancelIdempotent", "(Z)V", "pollInternal", "()Ljava/lang/Object;", "pollSelectInternal", "(Lkotlinx/coroutines/selects/SelectInstance;)Ljava/lang/Object;", "Lkotlinx/coroutines/internal/Symbol;", "updateBufferSize", "(I)Lkotlinx/coroutines/internal/Symbol;", "", "buffer", "[Ljava/lang/Object;", "", "getBufferDebugString", "()Ljava/lang/String;", "bufferDebugString", "I", "head", "isBufferAlwaysEmpty", "()Z", "isBufferAlwaysFull", "isBufferEmpty", "isBufferFull", "isClosedForReceive", "isEmpty", "Ljava/util/concurrent/locks/ReentrantLock;", "Lkotlinx/coroutines/internal/ReentrantLock;", "lock", "Ljava/util/concurrent/locks/ReentrantLock;", "Lkotlinx/coroutines/channels/BufferOverflow;", "kotlinx-coroutines-core", "Lkotlinx/coroutines/channels/AbstractChannel;"}
)
public class ArrayChannel<E> extends AbstractChannel<E> {
   private final int capacity;
   @NotNull
   private final BufferOverflow onBufferOverflow;
   @NotNull
   private final ReentrantLock lock;
   @NotNull
   private Object[] buffer;
   private int head;
   // $FF: synthetic field
   @NotNull
   private volatile int size;

   public ArrayChannel(int a, @NotNull BufferOverflow a, @Nullable Function1<? super E, Unit> a) {
      super(a);
      a.capacity = a;
      a.onBufferOverflow = a;
      if (a.capacity < 1) {
         int a = false;
         String var8 = "ArrayChannel capacity must be at least 1, but " + a.capacity + " was specified";
         throw new IllegalArgumentException(var8.toString());
      } else {
         a.lock = new ReentrantLock();
         Object[] var4 = new Object[Math.min(a.capacity, 8)];
         int a = false;
         ArraysKt.fill$default(var4, AbstractChannelKt.EMPTY, 0, 0, 6, (Object)null);
         a.buffer = var4;
         a.size = 0;
      }
   }

   protected final boolean isBufferAlwaysEmpty() {
      return false;
   }

   protected final boolean isBufferEmpty() {
      return a.size == 0;
   }

   protected final boolean isBufferAlwaysFull() {
      return false;
   }

   protected final boolean isBufferFull() {
      return a.size == a.capacity && a.onBufferOverflow == BufferOverflow.SUSPEND;
   }

   public boolean isEmpty() {
      ReentrantLock a = a.lock;
      int a = false;
      Lock var3 = (Lock)a;
      var3.lock();

      boolean a;
      try {
         a = false;
         a = a.isEmptyImpl();
      } finally {
         var3.unlock();
      }

      return a;
   }

   public boolean isClosedForReceive() {
      ReentrantLock a = a.lock;
      int a = false;
      Lock var3 = (Lock)a;
      var3.lock();

      boolean a;
      try {
         a = false;
         a = super.isClosedForReceive();
      } finally {
         var3.unlock();
      }

      return a;
   }

   @NotNull
   protected Object offerInternal(E a) {
      Object a = null;
      ReentrantLock a = a.lock;
      int a = false;
      Lock var5 = (Lock)a;
      var5.lock();

      try {
         label162: {
            int a = false;
            int a = a.size;
            Closed var10000 = a.getClosedForSend();
            boolean a;
            if (var10000 != null) {
               Closed a = var10000;
               a = false;
               Closed var16 = a;
               return var16;
            }

            Symbol var20 = a.updateBufferSize(a);
            if (var20 != null) {
               Symbol a = var20;
               a = false;
               Symbol var15 = a;
               return var15;
            }

            if (a == 0) {
               while(true) {
                  ReceiveOrClosed var21 = a.takeFirstReceiveOrPeekClosed();
                  if (var21 == null) {
                     break;
                  }

                  a = var21;
                  if (a instanceof Closed) {
                     a.size = a;
                     ReceiveOrClosed var14 = a;
                     return var14;
                  }

                  Intrinsics.checkNotNull(a);
                  Symbol a = a.tryResumeReceive(a, (LockFreeLinkedListNode.PrepareOp)null);
                  if (a != null) {
                     if (DebugKt.getASSERTIONS_ENABLED()) {
                        int a = false;
                        if (a != CancellableContinuationImplKt.RESUME_TOKEN) {
                           throw new AssertionError();
                        }
                     }

                     a.size = a;
                     Unit var12 = Unit.INSTANCE;
                     break label162;
                  }
               }
            }

            a.enqueueElement(a, a);
            Symbol var13 = AbstractChannelKt.OFFER_SUCCESS;
            return var13;
         }
      } finally {
         var5.unlock();
      }

      a.completeResumeReceive(a);
      return a.getOfferResult();
   }

   @NotNull
   protected Object offerSelectInternal(E a, @NotNull SelectInstance<?> a) {
      Object a = null;
      ReentrantLock a = a.lock;
      int a = false;
      Lock var6 = (Lock)a;
      var6.lock();

      label160: {
         Symbol var14;
         try {
            int a = false;
            int a = a.size;
            Closed var10000 = a.getClosedForSend();
            boolean a;
            if (var10000 != null) {
               Closed a = var10000;
               a = false;
               Closed var18 = a;
               return var18;
            }

            Symbol var22 = a.updateBufferSize(a);
            if (var22 != null) {
               Symbol a = var22;
               a = false;
               Symbol var17 = a;
               return var17;
            }

            if (a == 0) {
               while(true) {
                  AbstractSendChannel.TryOfferDesc a = a.describeTryOffer(a);
                  Object a = a.performAtomicTrySelect((AtomicDesc)a);
                  if (a == null) {
                     a.size = a;
                     a = a.getResult();
                     Unit var13 = Unit.INSTANCE;
                     break label160;
                  }

                  if (a == AbstractChannelKt.OFFER_FAILED) {
                     break;
                  }

                  if (a != AtomicKt.RETRY_ATOMIC) {
                     if (a != SelectKt.getALREADY_SELECTED() && !(a instanceof Closed)) {
                        throw new IllegalStateException(("performAtomicTrySelect(describeTryOffer) returned " + a).toString());
                     }

                     a.size = a;
                     Object var16 = a;
                     return var16;
                  }
               }
            }

            if (!a.trySelect()) {
               a.size = a;
               Object var15 = SelectKt.getALREADY_SELECTED();
               return var15;
            }

            a.enqueueElement(a, a);
            var14 = AbstractChannelKt.OFFER_SUCCESS;
         } finally {
            var6.unlock();
         }

         return var14;
      }

      Intrinsics.checkNotNull(a);
      ((ReceiveOrClosed)a).completeResumeReceive(a);
      return ((ReceiveOrClosed)a).getOfferResult();
   }

   @Nullable
   protected Object enqueueSend(@NotNull Send a) {
      ReentrantLock a = a.lock;
      int a = false;
      Lock var4 = (Lock)a;
      var4.lock();

      Object var6;
      try {
         int a = false;
         var6 = super.enqueueSend(a);
      } finally {
         var4.unlock();
      }

      return var6;
   }

   private final Symbol updateBufferSize(int a) {
      if (a < a.capacity) {
         a.size = a + 1;
         return null;
      } else {
         Symbol var10000;
         switch(ArrayChannel.WhenMappings.$EnumSwitchMapping$0[a.onBufferOverflow.ordinal()]) {
         case 1:
            var10000 = AbstractChannelKt.OFFER_FAILED;
            break;
         case 2:
            var10000 = AbstractChannelKt.OFFER_SUCCESS;
            break;
         case 3:
            var10000 = null;
            break;
         default:
            throw new NoWhenBranchMatchedException();
         }

         return var10000;
      }
   }

   private final void enqueueElement(int a, E a) {
      if (a < a.capacity) {
         a.ensureCapacity(a);
         a.buffer[(a.head + a) % a.buffer.length] = a;
      } else {
         if (DebugKt.getASSERTIONS_ENABLED()) {
            int a = false;
            if (a.onBufferOverflow != BufferOverflow.DROP_OLDEST) {
               throw new AssertionError();
            }
         }

         a.buffer[a.head % a.buffer.length] = null;
         a.buffer[(a.head + a) % a.buffer.length] = a;
         a.head = (a.head + 1) % a.buffer.length;
      }

   }

   private final void ensureCapacity(int a) {
      if (a >= a.buffer.length) {
         int a = Math.min(a.buffer.length * 2, a.capacity);
         Object[] a = new Object[a];

         for(int a = 0; a < a; ++a) {
            a[a] = a.buffer[(a.head + a) % a.buffer.length];
         }

         ArraysKt.fill(a, AbstractChannelKt.EMPTY, a, a);
         a.buffer = a;
         a.head = 0;
      }

   }

   @Nullable
   protected Object pollInternal() {
      Object a = null;
      boolean a = false;
      Object a = null;
      ReentrantLock a = a.lock;
      int a = false;
      Lock var6 = (Lock)a;
      var6.lock();

      try {
         int a = false;
         int a = a.size;
         if (a == 0) {
            Object var16 = a.getClosedForSend();
            if (var16 == null) {
               var16 = AbstractChannelKt.POLL_FAILED;
            }

            Object var13 = var16;
            return var13;
         }

         a = a.buffer[a.head];
         a.buffer[a.head] = null;
         a.size = a - 1;
         Object a = AbstractChannelKt.POLL_FAILED;
         if (a == a.capacity) {
            while(true) {
               Send var10000 = a.takeFirstSendOrPeekClosed();
               if (var10000 == null) {
                  break;
               }

               a = var10000;
               Intrinsics.checkNotNull(a);
               Symbol a = a.tryResumeSend((LockFreeLinkedListNode.PrepareOp)null);
               if (a != null) {
                  if (DebugKt.getASSERTIONS_ENABLED()) {
                     int a = false;
                     if (a != CancellableContinuationImplKt.RESUME_TOKEN) {
                        throw new AssertionError();
                     }
                  }

                  a = true;
                  a = a.getPollResult();
                  break;
               }

               a.undeliveredElement();
            }
         }

         if (a != AbstractChannelKt.POLL_FAILED && !(a instanceof Closed)) {
            a.size = a;
            a.buffer[(a.head + a) % a.buffer.length] = a;
         }

         a.head = (a.head + 1) % a.buffer.length;
         Unit var12 = Unit.INSTANCE;
      } finally {
         var6.unlock();
      }

      if (a) {
         Intrinsics.checkNotNull(a);
         a.completeResumeSend();
      }

      return a;
   }

   @Nullable
   protected Object pollSelectInternal(@NotNull SelectInstance<?> a) {
      Object a = null;
      boolean a = false;
      Object a = null;
      ReentrantLock a = a.lock;
      int a = false;
      Lock var7 = (Lock)a;
      var7.lock();

      try {
         int a = false;
         int a = a.size;
         if (a == 0) {
            Object var10000 = a.getClosedForSend();
            if (var10000 == null) {
               var10000 = AbstractChannelKt.POLL_FAILED;
            }

            Object var16 = var10000;
            return var16;
         }

         a = a.buffer[a.head];
         a.buffer[a.head] = null;
         a.size = a - 1;
         Object a = AbstractChannelKt.POLL_FAILED;
         if (a == a.capacity) {
            while(true) {
               AbstractChannel.TryPollDesc a = a.describeTryPoll();
               Object a = a.performAtomicTrySelect((AtomicDesc)a);
               if (a == null) {
                  a = a.getResult();
                  a = true;
                  Intrinsics.checkNotNull(a);
                  a = ((Send)a).getPollResult();
                  break;
               }

               if (a == AbstractChannelKt.POLL_FAILED) {
                  break;
               }

               if (a != AtomicKt.RETRY_ATOMIC) {
                  if (a == SelectKt.getALREADY_SELECTED()) {
                     a.size = a;
                     a.buffer[a.head] = a;
                     Object var15 = a;
                     return var15;
                  }

                  if (!(a instanceof Closed)) {
                     throw new IllegalStateException(("performAtomicTrySelect(describeTryOffer) returned " + a).toString());
                  }

                  a = a;
                  a = true;
                  a = a;
                  break;
               }
            }
         }

         if (a != AbstractChannelKt.POLL_FAILED && !(a instanceof Closed)) {
            a.size = a;
            a.buffer[(a.head + a) % a.buffer.length] = a;
         } else if (!a.trySelect()) {
            a.size = a;
            a.buffer[a.head] = a;
            Object var14 = SelectKt.getALREADY_SELECTED();
            return var14;
         }

         a.head = (a.head + 1) % a.buffer.length;
         Unit var13 = Unit.INSTANCE;
      } finally {
         var7.unlock();
      }

      if (a) {
         Intrinsics.checkNotNull(a);
         ((Send)a).completeResumeSend();
      }

      return a;
   }

   protected boolean enqueueReceiveInternal(@NotNull Receive<? super E> a) {
      ReentrantLock a = a.lock;
      int a = false;
      Lock var4 = (Lock)a;
      var4.lock();

      boolean var6;
      try {
         int a = false;
         var6 = super.enqueueReceiveInternal(a);
      } finally {
         var4.unlock();
      }

      return var6;
   }

   protected void onCancelIdempotent(boolean a) {
      Function1 a = a.onUndeliveredElement;
      Object a = null;
      ReentrantLock a = a.lock;
      int a = false;
      Lock var6 = (Lock)a;
      var6.lock();

      boolean a;
      try {
         a = false;
         int var8 = a.size;

         for(int var9 = 0; var9 < var8; ++var9) {
            int a = false;
            Object a = a.buffer[a.head];
            if (a != null && a != AbstractChannelKt.EMPTY) {
               a = OnUndeliveredElementKt.callUndeliveredElementCatchingException(a, a, a);
            }

            a.buffer[a.head] = AbstractChannelKt.EMPTY;
            a.head = (a.head + 1) % a.buffer.length;
         }

         a.size = 0;
         Unit var13 = Unit.INSTANCE;
      } finally {
         var6.unlock();
      }

      super.onCancelIdempotent(a);
      if (a != null) {
         a = false;
         throw a;
      }
   }

   @NotNull
   protected String getBufferDebugString() {
      return "(buffer:capacity=" + a.capacity + ",size=" + a.size + ')';
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[BufferOverflow.values().length];
         var0[BufferOverflow.SUSPEND.ordinal()] = 1;
         var0[BufferOverflow.DROP_LATEST.ordinal()] = 2;
         var0[BufferOverflow.DROP_OLDEST.ordinal()] = 3;
         $EnumSwitchMapping$0 = var0;
      }
   }
}
