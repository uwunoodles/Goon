package kotlinx.coroutines.channels;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.JvmName;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\bf\u0018\u0000*\u0006\b\u0000\u0010\u0001 \u00012\u00020\u0002J\u0011\u0010\u0003\u001a\u00020\u0004H¦Bø\u0001\u0000¢\u0006\u0002\u0010\u0005J\u000e\u0010\u0006\u001a\u00028\u0000H¦\u0002¢\u0006\u0002\u0010\u0007J\u0013\u0010\b\u001a\u00028\u0000H\u0097@ø\u0001\u0000¢\u0006\u0004\b\u0006\u0010\u0005\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\t"},
   d2 = {"Lkotlinx/coroutines/channels/ChannelIterator;", "E", "", "hasNext", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "next", "()Ljava/lang/Object;", "next0", "kotlinx-coroutines-core"}
)
public interface ChannelIterator<E> {
   @Nullable
   Object hasNext(@NotNull Continuation<? super Boolean> var1);

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.3.0, binary compatibility with versions <= 1.2.x",
      level = DeprecationLevel.HIDDEN
   )
   @JvmName(
      name = "next"
   )
   Object next(Continuation var1);

   E next();

   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public static final class DefaultImpls {
      /** @deprecated */
      // $FF: synthetic method
      @Deprecated(
         message = "Since 1.3.0, binary compatibility with versions <= 1.2.x",
         level = DeprecationLevel.HIDDEN
      )
      @JvmName(
         name = "next"
      )
      public static Object next(ChannelIterator a, Continuation var1) {
         Object a;
         label24: {
            if (var1 instanceof <undefinedtype>) {
               a = (<undefinedtype>)var1;
               if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
                  ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
                  break label24;
               }
            }

            a = new ContinuationImpl(var1) {
               Object L$0;
               // $FF: synthetic field
               Object result;
               int label;

               @Nullable
               public final Object invokeSuspend(@NotNull Object ax) {
                  a.result = ax;
                  a.label |= Integer.MIN_VALUE;
                  return ChannelIterator.DefaultImpls.next((ChannelIterator)null, (Continuation)a);
               }
            };
         }

         Object a = ((<undefinedtype>)a).result;
         Object var4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
         Object var10000;
         switch(((<undefinedtype>)a).label) {
         case 0:
            ResultKt.throwOnFailure(a);
            ((<undefinedtype>)a).L$0 = a;
            ((<undefinedtype>)a).label = 1;
            var10000 = a.hasNext((Continuation)a);
            if (var10000 == var4) {
               return var4;
            }
            break;
         case 1:
            a = (ChannelIterator)((<undefinedtype>)a).L$0;
            ResultKt.throwOnFailure(a);
            var10000 = a;
            break;
         default:
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
         }

         if (!(Boolean)var10000) {
            throw new ClosedReceiveChannelException("Channel was closed");
         } else {
            return a.next();
         }
      }
   }
}
