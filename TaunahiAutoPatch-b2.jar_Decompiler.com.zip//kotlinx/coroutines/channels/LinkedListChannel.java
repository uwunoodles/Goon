package kotlinx.coroutines.channels;

import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlinx.coroutines.internal.AtomicDesc;
import kotlinx.coroutines.internal.AtomicKt;
import kotlinx.coroutines.internal.OnUndeliveredElementKt;
import kotlinx.coroutines.internal.UndeliveredElementException;
import kotlinx.coroutines.selects.SelectInstance;
import kotlinx.coroutines.selects.SelectKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0010\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B'\u0012 \u0010\u0003\u001a\u001c\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u0004j\n\u0012\u0004\u0012\u00028\u0000\u0018\u0001`\u0006¢\u0006\u0002\u0010\u0007J\u0015\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00028\u0000H\u0014¢\u0006\u0002\u0010\u0011J!\u0010\u0012\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00028\u00002\n\u0010\u0013\u001a\u0006\u0012\u0002\b\u00030\u0014H\u0014¢\u0006\u0002\u0010\u0015J/\u0010\u0016\u001a\u00020\u00052\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00190\u00182\n\u0010\u001a\u001a\u0006\u0012\u0002\b\u00030\u001bH\u0014ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\u001c\u0010\u001dR\u0014\u0010\b\u001a\u00020\t8DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\b\u0010\nR\u0014\u0010\u000b\u001a\u00020\t8DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\u000b\u0010\nR\u0014\u0010\f\u001a\u00020\t8DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\f\u0010\nR\u0014\u0010\r\u001a\u00020\t8DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\n\u0082\u0002\u000b\n\u0002\b\u0019\n\u0005\b¡\u001e0\u0001¨\u0006\u001e"},
   d2 = {"Lkotlinx/coroutines/channels/LinkedListChannel;", "E", "Lkotlinx/coroutines/channels/AbstractChannel;", "onUndeliveredElement", "Lkotlin/Function1;", "", "Lkotlinx/coroutines/internal/OnUndeliveredElement;", "(Lkotlin/jvm/functions/Function1;)V", "isBufferAlwaysEmpty", "", "()Z", "isBufferAlwaysFull", "isBufferEmpty", "isBufferFull", "offerInternal", "", "element", "(Ljava/lang/Object;)Ljava/lang/Object;", "offerSelectInternal", "select", "Lkotlinx/coroutines/selects/SelectInstance;", "(Ljava/lang/Object;Lkotlinx/coroutines/selects/SelectInstance;)Ljava/lang/Object;", "onCancelIdempotentList", "list", "Lkotlinx/coroutines/internal/InlineList;", "Lkotlinx/coroutines/channels/Send;", "closed", "Lkotlinx/coroutines/channels/Closed;", "onCancelIdempotentList-w-w6eGU", "(Ljava/lang/Object;Lkotlinx/coroutines/channels/Closed;)V", "kotlinx-coroutines-core"}
)
public class LinkedListChannel<E> extends AbstractChannel<E> {
   public LinkedListChannel(@Nullable Function1<? super E, Unit> a) {
      super(a);
   }

   protected final boolean isBufferAlwaysEmpty() {
      return true;
   }

   protected final boolean isBufferEmpty() {
      return true;
   }

   protected final boolean isBufferAlwaysFull() {
      return false;
   }

   protected final boolean isBufferFull() {
      return false;
   }

   @NotNull
   protected Object offerInternal(E a) {
      while(true) {
         Object a = super.offerInternal(a);
         if (a == AbstractChannelKt.OFFER_SUCCESS) {
            return AbstractChannelKt.OFFER_SUCCESS;
         }

         if (a == AbstractChannelKt.OFFER_FAILED) {
            ReceiveOrClosed a = a.sendBuffered(a);
            if (a == null) {
               return AbstractChannelKt.OFFER_SUCCESS;
            }

            if (!(a instanceof Closed)) {
               continue;
            }

            return a;
         }

         if (a instanceof Closed) {
            return a;
         }

         throw new IllegalStateException(("Invalid offerInternal result " + a).toString());
      }
   }

   @NotNull
   protected Object offerSelectInternal(E a, @NotNull SelectInstance<?> a) {
      Object a;
      do {
         Object var10000;
         if (a.getHasReceiveOrClosed()) {
            var10000 = super.offerSelectInternal(a, a);
         } else {
            var10000 = a.performAtomicTrySelect((AtomicDesc)a.describeSendBuffered(a));
            if (var10000 == null) {
               var10000 = AbstractChannelKt.OFFER_SUCCESS;
            }
         }

         a = var10000;
         if (a == SelectKt.getALREADY_SELECTED()) {
            return SelectKt.getALREADY_SELECTED();
         }

         if (a == AbstractChannelKt.OFFER_SUCCESS) {
            return AbstractChannelKt.OFFER_SUCCESS;
         }
      } while(a == AbstractChannelKt.OFFER_FAILED || a == AtomicKt.RETRY_ATOMIC);

      if (a instanceof Closed) {
         return a;
      } else {
         throw new IllegalStateException(("Invalid result " + a).toString());
      }
   }

   protected void onCancelIdempotentList_w_w6eGU/* $FF was: onCancelIdempotentList-w-w6eGU*/(@NotNull Object a, @NotNull Closed<?> a) {
      Object a = null;
      int a = false;
      boolean a;
      if (a != null) {
         Function1 var10000;
         Send a;
         if (!(a instanceof ArrayList)) {
            a = (Send)a;
            a = false;
            if (a instanceof AbstractSendChannel.SendBuffered) {
               var10000 = a.onUndeliveredElement;
               a = var10000 != null ? OnUndeliveredElementKt.callUndeliveredElementCatchingException(var10000, ((AbstractSendChannel.SendBuffered)a).element, (UndeliveredElementException)a) : null;
            } else {
               a.resumeSendClosed(a);
            }
         } else {
            if (a == null) {
               throw new NullPointerException("null cannot be cast to non-null type java.util.ArrayList<E of kotlinx.coroutines.internal.InlineList>{ kotlin.collections.TypeAliasesKt.ArrayList<E of kotlinx.coroutines.internal.InlineList> }");
            }

            ArrayList a = (ArrayList)a;

            for(int a = a.size() - 1; -1 < a; --a) {
               a = (Send)a.get(a);
               a = false;
               if (a instanceof AbstractSendChannel.SendBuffered) {
                  var10000 = a.onUndeliveredElement;
                  a = var10000 != null ? OnUndeliveredElementKt.callUndeliveredElementCatchingException(var10000, ((AbstractSendChannel.SendBuffered)a).element, a) : null;
               } else {
                  a.resumeSendClosed(a);
               }
            }
         }
      }

      if (a != null) {
         a = false;
         throw a;
      }
   }
}
