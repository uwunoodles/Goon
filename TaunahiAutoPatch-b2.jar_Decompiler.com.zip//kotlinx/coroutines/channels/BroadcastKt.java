package kotlinx.coroutines.channels;

import kotlin.BuilderInference;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineContextKt;
import kotlinx.coroutines.CoroutineExceptionHandler;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.GlobalScope;
import kotlinx.coroutines.ObsoleteCoroutinesApi;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000V\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u009e\u0001\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2-\b\u0002\u0010\n\u001a'\u0012\u0015\u0012\u0013\u0018\u00010\f¢\u0006\f\b\r\u0012\b\b\u000e\u0012\u0004\b\b(\u000f\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u000bj\u0004\u0018\u0001`\u00112/\b\u0001\u0010\u0012\u001a)\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00100\u0015\u0012\u0006\u0012\u0004\u0018\u00010\u00160\u0013¢\u0006\u0002\b\u0017H\u0007ø\u0001\u0000¢\u0006\u0002\u0010\u0018\u001a2\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00192\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\tH\u0007\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001a"},
   d2 = {"broadcast", "Lkotlinx/coroutines/channels/BroadcastChannel;", "E", "Lkotlinx/coroutines/CoroutineScope;", "context", "Lkotlin/coroutines/CoroutineContext;", "capacity", "", "start", "Lkotlinx/coroutines/CoroutineStart;", "onCompletion", "Lkotlin/Function1;", "", "Lkotlin/ParameterName;", "name", "cause", "", "Lkotlinx/coroutines/CompletionHandler;", "block", "Lkotlin/Function2;", "Lkotlinx/coroutines/channels/ProducerScope;", "Lkotlin/coroutines/Continuation;", "", "Lkotlin/ExtensionFunctionType;", "(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;ILkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/channels/BroadcastChannel;", "Lkotlinx/coroutines/channels/ReceiveChannel;", "kotlinx-coroutines-core"}
)
public final class BroadcastKt {
   @ObsoleteCoroutinesApi
   @NotNull
   public static final <E> BroadcastChannel<E> broadcast(@NotNull final ReceiveChannel<? extends E> a, int a, @NotNull CoroutineStart a) {
      CoroutineScope var10000 = CoroutineScopeKt.plus((CoroutineScope)GlobalScope.INSTANCE, (CoroutineContext)Dispatchers.getUnconfined());
      int a = false;
      CoroutineExceptionHandler.Key var5 = CoroutineExceptionHandler.Key;
      CoroutineScope a = CoroutineScopeKt.plus(var10000, (CoroutineContext)((CoroutineExceptionHandler)(new BroadcastKt$broadcast$$inlined$CoroutineExceptionHandler$1(var5))));
      return broadcast$default(a, (CoroutineContext)null, a, a, (Function1)(new Function1<Throwable, Unit>() {
         public final void invoke(@Nullable Throwable axx) {
            ChannelsKt.cancelConsumed(a, axx);
         }
      }), (Function2)(new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            ProducerScope axxx;
            Continuation var10002;
            ChannelIterator var3;
            Object axxxx;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               axxx = (ProducerScope)ax.L$0;
               var3 = a.iterator();
               break;
            case 1:
               var3 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               if (!(Boolean)axx) {
                  return Unit.INSTANCE;
               }

               axxxx = var3.next();
               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 2;
               if (axxx.send(axxxx, var10002) == var5) {
                  return var5;
               }
               break;
            case 2:
               var3 = (ChannelIterator)ax.L$1;
               axxx = (ProducerScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            do {
               Continuation var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 1;
               Object var10000 = var3.hasNext(var10001);
               if (var10000 == var5) {
                  return var5;
               }

               if (!(Boolean)var10000) {
                  return Unit.INSTANCE;
               }

               axxxx = var3.next();
               var10002 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.L$1 = var3;
               ax.label = 2;
            } while(axxx.send(axxxx, var10002) != var5);

            return var5;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super E> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 1, (Object)null);
   }

   // $FF: synthetic method
   public static BroadcastChannel broadcast$default(ReceiveChannel var0, int var1, CoroutineStart var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = 1;
      }

      if ((var3 & 2) != 0) {
         var2 = CoroutineStart.LAZY;
      }

      return broadcast(var0, var1, var2);
   }

   @ObsoleteCoroutinesApi
   @NotNull
   public static final <E> BroadcastChannel<E> broadcast(@NotNull CoroutineScope a, @NotNull CoroutineContext a, int a, @NotNull CoroutineStart a, @Nullable Function1<? super Throwable, Unit> a, @BuilderInference @NotNull Function2<? super ProducerScope<? super E>, ? super Continuation<? super Unit>, ? extends Object> a) {
      CoroutineContext a = CoroutineContextKt.newCoroutineContext(a, a);
      BroadcastChannel a = BroadcastChannelKt.BroadcastChannel(a);
      BroadcastCoroutine a = a.isLazy() ? (BroadcastCoroutine)(new LazyBroadcastCoroutine(a, a, a)) : new BroadcastCoroutine(a, a, true);
      if (a != null) {
         a.invokeOnCompletion(a);
      }

      a.start(a, a, a);
      return (BroadcastChannel)a;
   }

   // $FF: synthetic method
   public static BroadcastChannel broadcast$default(CoroutineScope var0, CoroutineContext var1, int var2, CoroutineStart var3, Function1 var4, Function2 var5, int var6, Object var7) {
      if ((var6 & 1) != 0) {
         var1 = (CoroutineContext)EmptyCoroutineContext.INSTANCE;
      }

      if ((var6 & 2) != 0) {
         var2 = 1;
      }

      if ((var6 & 4) != 0) {
         var3 = CoroutineStart.LAZY;
      }

      if ((var6 & 8) != 0) {
         var4 = null;
      }

      return broadcast(var0, var1, var2, var3, var4, var5);
   }
}
