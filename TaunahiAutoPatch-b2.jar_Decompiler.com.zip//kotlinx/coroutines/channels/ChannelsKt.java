package kotlinx.coroutines.channels;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.PublishedApi;
import kotlin.ReplaceWith;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlinx.coroutines.ObsoleteCoroutinesApi;
import kotlinx.coroutines.selects.SelectClause1;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 4,
   xi = 48,
   d1 = {"kotlinx/coroutines/channels/ChannelsKt__ChannelsKt", "kotlinx/coroutines/channels/ChannelsKt__Channels_commonKt", "kotlinx/coroutines/channels/ChannelsKt__DeprecatedKt"}
)
public final class ChannelsKt {
   @NotNull
   public static final String DEFAULT_CLOSE_MESSAGE = "Channel was closed";

   @NotNull
   public static final <E> Object trySendBlocking(@NotNull SendChannel<? super E> a, E a) {
      return ChannelsKt__ChannelsKt.trySendBlocking(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in the favour of 'trySendBlocking'. Consider handling the result of 'trySendBlocking' explicitly and rethrow exception if necessary",
      replaceWith = @ReplaceWith(
   expression = "trySendBlocking(element)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   public static final <E> void sendBlocking(@NotNull SendChannel<? super E> a, E a) {
      ChannelsKt__ChannelsKt.sendBlocking(a, a);
   }

   @ObsoleteCoroutinesApi
   public static final <E, R> R consume(@NotNull BroadcastChannel<E> a, @NotNull Function1<? super ReceiveChannel<? extends E>, ? extends R> a) {
      return ChannelsKt__Channels_commonKt.consume(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in the favour of 'receiveCatching'",
      replaceWith = @ReplaceWith(
   expression = "receiveCatching().getOrNull()",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @Nullable
   public static final <E> Object receiveOrNull(@NotNull ReceiveChannel<? extends E> a, @NotNull Continuation<? super E> a) {
      return ChannelsKt__Channels_commonKt.receiveOrNull(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in the favour of 'onReceiveCatching'",
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <E> SelectClause1<E> onReceiveOrNull(@NotNull ReceiveChannel<? extends E> a) {
      return ChannelsKt__Channels_commonKt.onReceiveOrNull(a);
   }

   public static final <E, R> R consume(@NotNull ReceiveChannel<? extends E> a, @NotNull Function1<? super ReceiveChannel<? extends E>, ? extends R> a) {
      return ChannelsKt__Channels_commonKt.consume(a, a);
   }

   @Nullable
   public static final <E> Object consumeEach(@NotNull ReceiveChannel<? extends E> a, @NotNull Function1<? super E, Unit> a, @NotNull Continuation<? super Unit> a) {
      return ChannelsKt__Channels_commonKt.consumeEach(a, a, a);
   }

   @Nullable
   public static final <E> Object toList(@NotNull ReceiveChannel<? extends E> a, @NotNull Continuation<? super List<? extends E>> a) {
      return ChannelsKt__Channels_commonKt.toList(a, a);
   }

   @ObsoleteCoroutinesApi
   @Nullable
   public static final <E> Object consumeEach(@NotNull BroadcastChannel<E> a, @NotNull Function1<? super E, Unit> a, @NotNull Continuation<? super Unit> a) {
      return ChannelsKt__Channels_commonKt.consumeEach(a, a, a);
   }

   @PublishedApi
   public static final void cancelConsumed(@NotNull ReceiveChannel<?> a, @Nullable Throwable a) {
      ChannelsKt__Channels_commonKt.cancelConsumed(a, a);
   }

   @PublishedApi
   @NotNull
   public static final Function1<Throwable, Unit> consumesAll(@NotNull ReceiveChannel<?>... a) {
      return ChannelsKt__DeprecatedKt.consumesAll(a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object elementAt(ReceiveChannel a, int a, Continuation a) {
      return ChannelsKt__DeprecatedKt.elementAt(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object elementAtOrNull(ReceiveChannel a, int a, Continuation a) {
      return ChannelsKt__DeprecatedKt.elementAtOrNull(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object first(ReceiveChannel a, Continuation a) {
      return ChannelsKt__DeprecatedKt.first(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object firstOrNull(ReceiveChannel a, Continuation a) {
      return ChannelsKt__DeprecatedKt.firstOrNull(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object indexOf(ReceiveChannel a, Object a, Continuation a) {
      return ChannelsKt__DeprecatedKt.indexOf(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object last(ReceiveChannel a, Continuation a) {
      return ChannelsKt__DeprecatedKt.last(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object lastIndexOf(ReceiveChannel a, Object a, Continuation a) {
      return ChannelsKt__DeprecatedKt.lastIndexOf(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object lastOrNull(ReceiveChannel a, Continuation a) {
      return ChannelsKt__DeprecatedKt.lastOrNull(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object single(ReceiveChannel a, Continuation a) {
      return ChannelsKt__DeprecatedKt.single(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object singleOrNull(ReceiveChannel a, Continuation a) {
      return ChannelsKt__DeprecatedKt.singleOrNull(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel drop(ReceiveChannel a, int a, CoroutineContext a) {
      return ChannelsKt__DeprecatedKt.drop(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel drop$default(ReceiveChannel var0, int var1, CoroutineContext var2, int var3, Object var4) {
      return ChannelsKt__DeprecatedKt.drop$default(var0, var1, var2, var3, var4);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel dropWhile(ReceiveChannel a, CoroutineContext a, Function2 a) {
      return ChannelsKt__DeprecatedKt.dropWhile(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel dropWhile$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      return ChannelsKt__DeprecatedKt.dropWhile$default(var0, var1, var2, var3, var4);
   }

   @PublishedApi
   @NotNull
   public static final <E> ReceiveChannel<E> filter(@NotNull ReceiveChannel<? extends E> a, @NotNull CoroutineContext a, @NotNull Function2<? super E, ? super Continuation<? super Boolean>, ? extends Object> a) {
      return ChannelsKt__DeprecatedKt.filter(a, a, a);
   }

   // $FF: synthetic method
   public static ReceiveChannel filter$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      return ChannelsKt__DeprecatedKt.filter$default(var0, var1, var2, var3, var4);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel filterIndexed(ReceiveChannel a, CoroutineContext a, Function3 a) {
      return ChannelsKt__DeprecatedKt.filterIndexed(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel filterIndexed$default(ReceiveChannel var0, CoroutineContext var1, Function3 var2, int var3, Object var4) {
      return ChannelsKt__DeprecatedKt.filterIndexed$default(var0, var1, var2, var3, var4);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel filterNot(ReceiveChannel a, CoroutineContext a, Function2 a) {
      return ChannelsKt__DeprecatedKt.filterNot(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel filterNot$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      return ChannelsKt__DeprecatedKt.filterNot$default(var0, var1, var2, var3, var4);
   }

   @PublishedApi
   @NotNull
   public static final <E> ReceiveChannel<E> filterNotNull(@NotNull ReceiveChannel<? extends E> a) {
      return ChannelsKt__DeprecatedKt.filterNotNull(a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object filterNotNullTo(ReceiveChannel a, Collection a, Continuation a) {
      return ChannelsKt__DeprecatedKt.filterNotNullTo(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object filterNotNullTo(ReceiveChannel a, SendChannel a, Continuation a) {
      return ChannelsKt__DeprecatedKt.filterNotNullTo(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel take(ReceiveChannel a, int a, CoroutineContext a) {
      return ChannelsKt__DeprecatedKt.take(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel take$default(ReceiveChannel var0, int var1, CoroutineContext var2, int var3, Object var4) {
      return ChannelsKt__DeprecatedKt.take$default(var0, var1, var2, var3, var4);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel takeWhile(ReceiveChannel a, CoroutineContext a, Function2 a) {
      return ChannelsKt__DeprecatedKt.takeWhile(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel takeWhile$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      return ChannelsKt__DeprecatedKt.takeWhile$default(var0, var1, var2, var3, var4);
   }

   @PublishedApi
   @Nullable
   public static final <E, C extends SendChannel<? super E>> Object toChannel(@NotNull ReceiveChannel<? extends E> a, @NotNull C a, @NotNull Continuation<? super C> a) {
      return ChannelsKt__DeprecatedKt.toChannel(a, a, a);
   }

   @PublishedApi
   @Nullable
   public static final <E, C extends Collection<? super E>> Object toCollection(@NotNull ReceiveChannel<? extends E> a, @NotNull C a, @NotNull Continuation<? super C> a) {
      return ChannelsKt__DeprecatedKt.toCollection(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object toMap(ReceiveChannel a, Continuation a) {
      return ChannelsKt__DeprecatedKt.toMap(a, a);
   }

   @PublishedApi
   @Nullable
   public static final <K, V, M extends Map<? super K, ? super V>> Object toMap(@NotNull ReceiveChannel<? extends Pair<? extends K, ? extends V>> a, @NotNull M a, @NotNull Continuation<? super M> a) {
      return ChannelsKt__DeprecatedKt.toMap(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object toMutableList(ReceiveChannel a, Continuation a) {
      return ChannelsKt__DeprecatedKt.toMutableList(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object toSet(ReceiveChannel a, Continuation a) {
      return ChannelsKt__DeprecatedKt.toSet(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel flatMap(ReceiveChannel a, CoroutineContext a, Function2 a) {
      return ChannelsKt__DeprecatedKt.flatMap(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel flatMap$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      return ChannelsKt__DeprecatedKt.flatMap$default(var0, var1, var2, var3, var4);
   }

   @PublishedApi
   @NotNull
   public static final <E, R> ReceiveChannel<R> map(@NotNull ReceiveChannel<? extends E> a, @NotNull CoroutineContext a, @NotNull Function2<? super E, ? super Continuation<? super R>, ? extends Object> a) {
      return ChannelsKt__DeprecatedKt.map(a, a, a);
   }

   // $FF: synthetic method
   public static ReceiveChannel map$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      return ChannelsKt__DeprecatedKt.map$default(var0, var1, var2, var3, var4);
   }

   @PublishedApi
   @NotNull
   public static final <E, R> ReceiveChannel<R> mapIndexed(@NotNull ReceiveChannel<? extends E> a, @NotNull CoroutineContext a, @NotNull Function3<? super Integer, ? super E, ? super Continuation<? super R>, ? extends Object> a) {
      return ChannelsKt__DeprecatedKt.mapIndexed(a, a, a);
   }

   // $FF: synthetic method
   public static ReceiveChannel mapIndexed$default(ReceiveChannel var0, CoroutineContext var1, Function3 var2, int var3, Object var4) {
      return ChannelsKt__DeprecatedKt.mapIndexed$default(var0, var1, var2, var3, var4);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel mapIndexedNotNull(ReceiveChannel a, CoroutineContext a, Function3 a) {
      return ChannelsKt__DeprecatedKt.mapIndexedNotNull(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel mapIndexedNotNull$default(ReceiveChannel var0, CoroutineContext var1, Function3 var2, int var3, Object var4) {
      return ChannelsKt__DeprecatedKt.mapIndexedNotNull$default(var0, var1, var2, var3, var4);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel mapNotNull(ReceiveChannel a, CoroutineContext a, Function2 a) {
      return ChannelsKt__DeprecatedKt.mapNotNull(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel mapNotNull$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      return ChannelsKt__DeprecatedKt.mapNotNull$default(var0, var1, var2, var3, var4);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel withIndex(ReceiveChannel a, CoroutineContext a) {
      return ChannelsKt__DeprecatedKt.withIndex(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static ReceiveChannel withIndex$default(ReceiveChannel var0, CoroutineContext var1, int var2, Object var3) {
      return ChannelsKt__DeprecatedKt.withIndex$default(var0, var1, var2, var3);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel distinct(ReceiveChannel a) {
      return ChannelsKt__DeprecatedKt.distinct(a);
   }

   @PublishedApi
   @NotNull
   public static final <E, K> ReceiveChannel<E> distinctBy(@NotNull ReceiveChannel<? extends E> a, @NotNull CoroutineContext a, @NotNull Function2<? super E, ? super Continuation<? super K>, ? extends Object> a) {
      return ChannelsKt__DeprecatedKt.distinctBy(a, a, a);
   }

   // $FF: synthetic method
   public static ReceiveChannel distinctBy$default(ReceiveChannel var0, CoroutineContext var1, Function2 var2, int var3, Object var4) {
      return ChannelsKt__DeprecatedKt.distinctBy$default(var0, var1, var2, var3, var4);
   }

   @PublishedApi
   @Nullable
   public static final <E> Object toMutableSet(@NotNull ReceiveChannel<? extends E> a, @NotNull Continuation<? super Set<E>> a) {
      return ChannelsKt__DeprecatedKt.toMutableSet(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object any(ReceiveChannel a, Continuation a) {
      return ChannelsKt__DeprecatedKt.any(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object count(ReceiveChannel a, Continuation a) {
      return ChannelsKt__DeprecatedKt.count(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object maxWith(ReceiveChannel a, Comparator a, Continuation a) {
      return ChannelsKt__DeprecatedKt.maxWith(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object minWith(ReceiveChannel a, Comparator a, Continuation a) {
      return ChannelsKt__DeprecatedKt.minWith(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final Object none(ReceiveChannel a, Continuation a) {
      return ChannelsKt__DeprecatedKt.none(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Left for binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel requireNoNulls(ReceiveChannel a) {
      return ChannelsKt__DeprecatedKt.requireNoNulls(a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Binary compatibility",
      level = DeprecationLevel.HIDDEN
   )
   public static final ReceiveChannel zip(ReceiveChannel a, ReceiveChannel a) {
      return ChannelsKt__DeprecatedKt.zip(a, a);
   }

   @PublishedApi
   @NotNull
   public static final <E, R, V> ReceiveChannel<V> zip(@NotNull ReceiveChannel<? extends E> a, @NotNull ReceiveChannel<? extends R> a, @NotNull CoroutineContext a, @NotNull Function2<? super E, ? super R, ? extends V> a) {
      return ChannelsKt__DeprecatedKt.zip(a, a, a, a);
   }

   // $FF: synthetic method
   public static ReceiveChannel zip$default(ReceiveChannel var0, ReceiveChannel var1, CoroutineContext var2, Function2 var3, int var4, Object var5) {
      return ChannelsKt__DeprecatedKt.zip$default(var0, var1, var2, var3, var4, var5);
   }

   @PublishedApi
   @NotNull
   public static final Function1<Throwable, Unit> consumes(@NotNull ReceiveChannel<?> a) {
      return ChannelsKt__DeprecatedKt.consumes(a);
   }
}
