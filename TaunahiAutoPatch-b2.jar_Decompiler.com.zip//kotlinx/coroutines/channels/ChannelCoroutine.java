package kotlinx.coroutines.channels;

import java.util.concurrent.CancellationException;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.internal.LowPriorityInOverloadResolution;
import kotlin.jvm.functions.Function1;
import kotlinx.coroutines.AbstractCoroutine;
import kotlinx.coroutines.ExperimentalCoroutinesApi;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.JobCancellationException;
import kotlinx.coroutines.JobSupport;
import kotlinx.coroutines.selects.SelectClause1;
import kotlinx.coroutines.selects.SelectClause2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000d\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0012\b\u0010\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00020\u00030\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0004B+\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\t¢\u0006\u0002\u0010\u000bJ\b\u0010\"\u001a\u00020\u0003H\u0016J\u0012\u0010\"\u001a\u00020\t2\b\u0010#\u001a\u0004\u0018\u00010$H\u0007J\u0016\u0010\"\u001a\u00020\u00032\u000e\u0010#\u001a\n\u0018\u00010%j\u0004\u0018\u0001`&J\u0010\u0010'\u001a\u00020\u00032\u0006\u0010#\u001a\u00020$H\u0016J\u0013\u0010(\u001a\u00020\t2\b\u0010#\u001a\u0004\u0018\u00010$H\u0096\u0001J.\u0010)\u001a\u00020\u00032#\u0010*\u001a\u001f\u0012\u0015\u0012\u0013\u0018\u00010$¢\u0006\f\b,\u0012\b\b-\u0012\u0004\b\b(#\u0012\u0004\u0012\u00020\u00030+H\u0097\u0001J\u000f\u0010.\u001a\b\u0012\u0004\u0012\u00028\u00000/H\u0096\u0003J\u0016\u00100\u001a\u00020\t2\u0006\u00101\u001a\u00028\u0000H\u0097\u0001¢\u0006\u0002\u00102J\u0010\u00103\u001a\u0004\u0018\u00018\u0000H\u0097\u0001¢\u0006\u0002\u00104J\u0011\u00105\u001a\u00028\u0000H\u0096Aø\u0001\u0000¢\u0006\u0002\u00106J\"\u00107\u001a\b\u0012\u0004\u0012\u00028\u00000\u0019H\u0096Aø\u0001\u0000ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\u0004\b8\u00106J\u0013\u00109\u001a\u0004\u0018\u00018\u0000H\u0097Aø\u0001\u0000¢\u0006\u0002\u00106J\u0019\u0010:\u001a\u00020\u00032\u0006\u00101\u001a\u00028\u0000H\u0096Aø\u0001\u0000¢\u0006\u0002\u0010;J\u001f\u0010<\u001a\b\u0012\u0004\u0012\u00028\u00000\u0019H\u0096\u0001ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\u0004\b=\u00104J'\u0010>\u001a\b\u0012\u0004\u0012\u00020\u00030\u00192\u0006\u00101\u001a\u00028\u0000H\u0096\u0001ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\u0004\b?\u0010@R\u001a\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004X\u0084\u0004¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0017\u0010\u000e\u001a\b\u0012\u0004\u0012\u00028\u00000\u00048F¢\u0006\u0006\u001a\u0004\b\u000f\u0010\rR\u0014\u0010\u0010\u001a\u00020\t8\u0016X\u0097\u0005¢\u0006\u0006\u001a\u0004\b\u0010\u0010\u0011R\u0014\u0010\u0012\u001a\u00020\t8\u0016X\u0097\u0005¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0011R\u0014\u0010\u0013\u001a\u00020\t8\u0016X\u0097\u0005¢\u0006\u0006\u001a\u0004\b\u0013\u0010\u0011R\u0018\u0010\u0014\u001a\b\u0012\u0004\u0012\u00028\u00000\u0015X\u0096\u0005¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0017R!\u0010\u0018\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00190\u0015X\u0096\u0005ø\u0001\u0000¢\u0006\u0006\u001a\u0004\b\u001a\u0010\u0017R\u001c\u0010\u001b\u001a\n\u0012\u0006\u0012\u0004\u0018\u00018\u00000\u00158VX\u0097\u0005¢\u0006\u0006\u001a\u0004\b\u001c\u0010\u0017R$\u0010\u001d\u001a\u0014\u0012\u0004\u0012\u00028\u0000\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u001f0\u001eX\u0096\u0005¢\u0006\u0006\u001a\u0004\b \u0010!\u0082\u0002\u000f\n\u0002\b\u0019\n\u0002\b!\n\u0005\b¡\u001e0\u0001¨\u0006A"},
   d2 = {"Lkotlinx/coroutines/channels/ChannelCoroutine;", "E", "Lkotlinx/coroutines/AbstractCoroutine;", "", "Lkotlinx/coroutines/channels/Channel;", "parentContext", "Lkotlin/coroutines/CoroutineContext;", "_channel", "initParentJob", "", "active", "(Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/channels/Channel;ZZ)V", "get_channel", "()Lkotlinx/coroutines/channels/Channel;", "channel", "getChannel", "isClosedForReceive", "()Z", "isClosedForSend", "isEmpty", "onReceive", "Lkotlinx/coroutines/selects/SelectClause1;", "getOnReceive", "()Lkotlinx/coroutines/selects/SelectClause1;", "onReceiveCatching", "Lkotlinx/coroutines/channels/ChannelResult;", "getOnReceiveCatching", "onReceiveOrNull", "getOnReceiveOrNull", "onSend", "Lkotlinx/coroutines/selects/SelectClause2;", "Lkotlinx/coroutines/channels/SendChannel;", "getOnSend", "()Lkotlinx/coroutines/selects/SelectClause2;", "cancel", "cause", "", "Ljava/util/concurrent/CancellationException;", "Lkotlinx/coroutines/CancellationException;", "cancelInternal", "close", "invokeOnClose", "handler", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "iterator", "Lkotlinx/coroutines/channels/ChannelIterator;", "offer", "element", "(Ljava/lang/Object;)Z", "poll", "()Ljava/lang/Object;", "receive", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "receiveCatching", "receiveCatching-JP2dKIU", "receiveOrNull", "send", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "tryReceive", "tryReceive-PtdJZtk", "trySend", "trySend-JP2dKIU", "(Ljava/lang/Object;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public class ChannelCoroutine<E> extends AbstractCoroutine<Unit> implements Channel<E> {
   @NotNull
   private final Channel<E> _channel;

   public ChannelCoroutine(@NotNull CoroutineContext a, @NotNull Channel<E> a, boolean a, boolean a) {
      super(a, a, a);
      a._channel = a;
   }

   @NotNull
   protected final Channel<E> get_channel() {
      return a._channel;
   }

   public boolean isClosedForReceive() {
      return a._channel.isClosedForReceive();
   }

   public boolean isClosedForSend() {
      return a._channel.isClosedForSend();
   }

   public boolean isEmpty() {
      return a._channel.isEmpty();
   }

   @NotNull
   public SelectClause1<E> getOnReceive() {
      return a._channel.getOnReceive();
   }

   @NotNull
   public SelectClause1<ChannelResult<E>> getOnReceiveCatching() {
      return a._channel.getOnReceiveCatching();
   }

   /** @deprecated */
   @NotNull
   public SelectClause1<E> getOnReceiveOrNull() {
      return a._channel.getOnReceiveOrNull();
   }

   @NotNull
   public SelectClause2<E, SendChannel<E>> getOnSend() {
      return a._channel.getOnSend();
   }

   public boolean close(@Nullable Throwable a) {
      return a._channel.close(a);
   }

   @ExperimentalCoroutinesApi
   public void invokeOnClose(@NotNull Function1<? super Throwable, Unit> a) {
      a._channel.invokeOnClose(a);
   }

   @NotNull
   public ChannelIterator<E> iterator() {
      return a._channel.iterator();
   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in the favour of 'trySend' method",
      replaceWith = @ReplaceWith(
   expression = "trySend(element).isSuccess",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   public boolean offer(E a) {
      return a._channel.offer(a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in the favour of 'tryReceive'. Please note that the provided replacement does not rethrow channel's close cause as 'poll' did, for the precise replacement please refer to the 'poll' documentation",
      replaceWith = @ReplaceWith(
   expression = "tryReceive().getOrNull()",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @Nullable
   public E poll() {
      return a._channel.poll();
   }

   @Nullable
   public Object receive(@NotNull Continuation<? super E> a) {
      return a._channel.receive(a);
   }

   @Nullable
   public Object receiveCatching_JP2dKIU/* $FF was: receiveCatching-JP2dKIU*/(@NotNull Continuation<? super ChannelResult<? extends E>> a) {
      Object var10000 = a._channel.receiveCatching-JP2dKIU(a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : var10000;
   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated in favor of 'receiveCatching'. Please note that the provided replacement does not rethrow channel's close cause as 'receiveOrNull' did, for the detailed replacement please refer to the 'receiveOrNull' documentation",
      replaceWith = @ReplaceWith(
   expression = "receiveCatching().getOrNull()",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @LowPriorityInOverloadResolution
   @Nullable
   public Object receiveOrNull(@NotNull Continuation<? super E> a) {
      return a._channel.receiveOrNull(a);
   }

   @Nullable
   public Object send(E a, @NotNull Continuation<? super Unit> a) {
      return a._channel.send(a, a);
   }

   @NotNull
   public Object tryReceive_PtdJZtk/* $FF was: tryReceive-PtdJZtk*/() {
      return a._channel.tryReceive-PtdJZtk();
   }

   @NotNull
   public Object trySend_JP2dKIU/* $FF was: trySend-JP2dKIU*/(E a) {
      return a._channel.trySend-JP2dKIU(a);
   }

   @NotNull
   public final Channel<E> getChannel() {
      return (Channel)a;
   }

   // $FF: synthetic method
   public void cancel() {
      String a = null;
      Throwable a = null;
      int a = false;
      a.cancelInternal((Throwable)(new JobCancellationException(JobSupport.access$cancellationExceptionMessage((JobSupport)a), (Throwable)a, (Job)((JobSupport)a))));
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public final boolean cancel(Throwable a1) {
      String a = null;
      Throwable a = null;
      int a = false;
      a.cancelInternal((Throwable)(new JobCancellationException(JobSupport.access$cancellationExceptionMessage((JobSupport)a), (Throwable)a, (Job)((JobSupport)a))));
      return true;
   }

   public final void cancel(@Nullable CancellationException a) {
      if (!a.isCancelled()) {
         CancellationException var10001 = a;
         if (a == null) {
            String a = null;
            Throwable a = null;
            int a = false;
            var10001 = (CancellationException)(new JobCancellationException(JobSupport.access$cancellationExceptionMessage((JobSupport)a), (Throwable)a, (Job)((JobSupport)a)));
         }

         a.cancelInternal((Throwable)var10001);
      }
   }

   public void cancelInternal(@NotNull Throwable a) {
      CancellationException a = JobSupport.toCancellationException$default((JobSupport)a, a, (String)null, 1, (Object)null);
      a._channel.cancel(a);
      a.cancelCoroutine((Throwable)a);
   }
}
