package kotlinx.coroutines.channels;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CancellableContinuationImplKt;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.internal.AtomicDesc;
import kotlinx.coroutines.internal.AtomicKt;
import kotlinx.coroutines.internal.LockFreeLinkedListNode;
import kotlinx.coroutines.internal.OnUndeliveredElementKt;
import kotlinx.coroutines.internal.Symbol;
import kotlinx.coroutines.internal.UndeliveredElementException;
import kotlinx.coroutines.selects.SelectInstance;
import kotlinx.coroutines.selects.SelectKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\b\u0010\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B'\u0012 \u0010\u0003\u001a\u001c\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u0004j\n\u0012\u0004\u0012\u00028\u0000\u0018\u0001`\u0006¢\u0006\u0002\u0010\u0007J\u0016\u0010\u0018\u001a\u00020\r2\f\u0010\u0019\u001a\b\u0012\u0004\u0012\u00028\u00000\u001aH\u0014J\u0015\u0010\u001b\u001a\u00020\u00172\u0006\u0010\u001c\u001a\u00028\u0000H\u0014¢\u0006\u0002\u0010\u001dJ!\u0010\u001e\u001a\u00020\u00172\u0006\u0010\u001c\u001a\u00028\u00002\n\u0010\u001f\u001a\u0006\u0012\u0002\b\u00030 H\u0014¢\u0006\u0002\u0010!J\u0010\u0010\"\u001a\u00020\u00052\u0006\u0010#\u001a\u00020\rH\u0014J\n\u0010$\u001a\u0004\u0018\u00010\u0017H\u0014J\u0016\u0010%\u001a\u0004\u0018\u00010\u00172\n\u0010\u001f\u001a\u0006\u0012\u0002\b\u00030 H\u0014J\u0014\u0010&\u001a\u0004\u0018\u00010'2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0017H\u0002R\u0014\u0010\b\u001a\u00020\t8TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000bR\u0014\u0010\f\u001a\u00020\r8DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\f\u0010\u000eR\u0014\u0010\u000f\u001a\u00020\r8DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u000eR\u0014\u0010\u0010\u001a\u00020\r8DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\u0010\u0010\u000eR\u0014\u0010\u0011\u001a\u00020\r8DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\u0011\u0010\u000eR\u0014\u0010\u0012\u001a\u00020\r8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u000eR\u0012\u0010\u0013\u001a\u00060\u0014j\u0002`\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006("},
   d2 = {"Lkotlinx/coroutines/channels/ConflatedChannel;", "E", "Lkotlinx/coroutines/channels/AbstractChannel;", "onUndeliveredElement", "Lkotlin/Function1;", "", "Lkotlinx/coroutines/internal/OnUndeliveredElement;", "(Lkotlin/jvm/functions/Function1;)V", "bufferDebugString", "", "getBufferDebugString", "()Ljava/lang/String;", "isBufferAlwaysEmpty", "", "()Z", "isBufferAlwaysFull", "isBufferEmpty", "isBufferFull", "isEmpty", "lock", "Ljava/util/concurrent/locks/ReentrantLock;", "Lkotlinx/coroutines/internal/ReentrantLock;", "value", "", "enqueueReceiveInternal", "receive", "Lkotlinx/coroutines/channels/Receive;", "offerInternal", "element", "(Ljava/lang/Object;)Ljava/lang/Object;", "offerSelectInternal", "select", "Lkotlinx/coroutines/selects/SelectInstance;", "(Ljava/lang/Object;Lkotlinx/coroutines/selects/SelectInstance;)Ljava/lang/Object;", "onCancelIdempotent", "wasClosed", "pollInternal", "pollSelectInternal", "updateValueLocked", "Lkotlinx/coroutines/internal/UndeliveredElementException;", "kotlinx-coroutines-core"}
)
public class ConflatedChannel<E> extends AbstractChannel<E> {
   @NotNull
   private final ReentrantLock lock = new ReentrantLock();
   @Nullable
   private Object value;

   public ConflatedChannel(@Nullable Function1<? super E, Unit> a) {
      super(a);
      a.value = AbstractChannelKt.EMPTY;
   }

   protected final boolean isBufferAlwaysEmpty() {
      return false;
   }

   protected final boolean isBufferEmpty() {
      ReentrantLock a = a.lock;
      int a = false;
      Lock var3 = (Lock)a;
      var3.lock();

      boolean a;
      try {
         a = false;
         a = a.value == AbstractChannelKt.EMPTY;
      } finally {
         var3.unlock();
      }

      return a;
   }

   protected final boolean isBufferAlwaysFull() {
      return false;
   }

   protected final boolean isBufferFull() {
      return false;
   }

   public boolean isEmpty() {
      ReentrantLock a = a.lock;
      int a = false;
      Lock var3 = (Lock)a;
      var3.lock();

      boolean a;
      try {
         a = false;
         a = a.isEmptyImpl();
      } finally {
         var3.unlock();
      }

      return a;
   }

   @NotNull
   protected Object offerInternal(E a) {
      Object a = null;
      ReentrantLock a = a.lock;
      int a = false;
      Lock var5 = (Lock)a;
      var5.lock();

      label131: {
         Closed var14;
         try {
            int a = false;
            Closed var10000 = a.getClosedForSend();
            boolean a;
            if (var10000 == null) {
               if (a.value == AbstractChannelKt.EMPTY) {
                  while(true) {
                     ReceiveOrClosed var18 = a.takeFirstReceiveOrPeekClosed();
                     if (var18 == null) {
                        break;
                     }

                     a = var18;
                     if (a instanceof Closed) {
                        ReceiveOrClosed var13 = a;
                        return var13;
                     }

                     Intrinsics.checkNotNull(a);
                     Symbol a = a.tryResumeReceive(a, (LockFreeLinkedListNode.PrepareOp)null);
                     if (a != null) {
                        if (DebugKt.getASSERTIONS_ENABLED()) {
                           int a = false;
                           if (a != CancellableContinuationImplKt.RESUME_TOKEN) {
                              throw new AssertionError();
                           }
                        }

                        Unit var11 = Unit.INSTANCE;
                        break label131;
                     }
                  }
               }

               UndeliveredElementException var19 = a.updateValueLocked(a);
               if (var19 != null) {
                  UndeliveredElementException a = var19;
                  a = false;
                  throw a;
               }

               Symbol var12 = AbstractChannelKt.OFFER_SUCCESS;
               return var12;
            }

            Closed a = var10000;
            a = false;
            var14 = a;
         } finally {
            var5.unlock();
         }

         return var14;
      }

      a.completeResumeReceive(a);
      return a.getOfferResult();
   }

   @NotNull
   protected Object offerSelectInternal(E a, @NotNull SelectInstance<?> a) {
      Object a = null;
      ReentrantLock a = a.lock;
      int a = false;
      Lock var6 = (Lock)a;
      var6.lock();

      try {
         label155: {
            int a = false;
            Closed var10000 = a.getClosedForSend();
            boolean a;
            if (var10000 != null) {
               Closed a = var10000;
               a = false;
               Closed var16 = a;
               return var16;
            }

            if (a.value == AbstractChannelKt.EMPTY) {
               while(true) {
                  AbstractSendChannel.TryOfferDesc a = a.describeTryOffer(a);
                  Object a = a.performAtomicTrySelect((AtomicDesc)a);
                  if (a == null) {
                     a = a.getResult();
                     Unit var12 = Unit.INSTANCE;
                     break label155;
                  }

                  if (a == AbstractChannelKt.OFFER_FAILED) {
                     break;
                  }

                  if (a != AtomicKt.RETRY_ATOMIC) {
                     if (a != SelectKt.getALREADY_SELECTED() && !(a instanceof Closed)) {
                        throw new IllegalStateException(("performAtomicTrySelect(describeTryOffer) returned " + a).toString());
                     }

                     Object var15 = a;
                     return var15;
                  }
               }
            }

            if (!a.trySelect()) {
               Object var14 = SelectKt.getALREADY_SELECTED();
               return var14;
            }

            UndeliveredElementException var20 = a.updateValueLocked(a);
            if (var20 != null) {
               UndeliveredElementException a = var20;
               a = false;
               throw a;
            }

            Symbol var13 = AbstractChannelKt.OFFER_SUCCESS;
            return var13;
         }
      } finally {
         var6.unlock();
      }

      Intrinsics.checkNotNull(a);
      ((ReceiveOrClosed)a).completeResumeReceive(a);
      return ((ReceiveOrClosed)a).getOfferResult();
   }

   @Nullable
   protected Object pollInternal() {
      Object a = null;
      ReentrantLock a = a.lock;
      int a = false;
      Lock var4 = (Lock)a;
      var4.lock();

      Object var7;
      try {
         int a = false;
         if (a.value != AbstractChannelKt.EMPTY) {
            a = a.value;
            a.value = AbstractChannelKt.EMPTY;
            Unit var6 = Unit.INSTANCE;
            return a;
         }

         Object var10000 = a.getClosedForSend();
         if (var10000 == null) {
            var10000 = AbstractChannelKt.POLL_FAILED;
         }

         var7 = var10000;
      } finally {
         var4.unlock();
      }

      return var7;
   }

   @Nullable
   protected Object pollSelectInternal(@NotNull SelectInstance<?> a) {
      Object a = null;
      ReentrantLock a = a.lock;
      int a = false;
      Lock var5 = (Lock)a;
      var5.lock();

      Object var8;
      try {
         int a = false;
         if (a.value == AbstractChannelKt.EMPTY) {
            Object var10000 = a.getClosedForSend();
            if (var10000 == null) {
               var10000 = AbstractChannelKt.POLL_FAILED;
            }

            Object var9 = var10000;
            return var9;
         }

         if (a.trySelect()) {
            a = a.value;
            a.value = AbstractChannelKt.EMPTY;
            Unit var7 = Unit.INSTANCE;
            return a;
         }

         var8 = SelectKt.getALREADY_SELECTED();
      } finally {
         var5.unlock();
      }

      return var8;
   }

   protected void onCancelIdempotent(boolean a) {
      Object a = null;
      ReentrantLock a = a.lock;
      int a = false;
      Lock var5 = (Lock)a;
      var5.lock();

      boolean a;
      try {
         a = false;
         a = a.updateValueLocked(AbstractChannelKt.EMPTY);
         Unit var7 = Unit.INSTANCE;
      } finally {
         var5.unlock();
      }

      super.onCancelIdempotent(a);
      if (a != null) {
         a = false;
         throw a;
      }
   }

   private final UndeliveredElementException updateValueLocked(Object a) {
      Object a = a.value;
      UndeliveredElementException var10000;
      if (a == AbstractChannelKt.EMPTY) {
         var10000 = null;
      } else {
         Function1 var4 = a.onUndeliveredElement;
         var10000 = var4 != null ? OnUndeliveredElementKt.callUndeliveredElementCatchingException$default(var4, a, (UndeliveredElementException)null, 2, (Object)null) : null;
      }

      UndeliveredElementException a = var10000;
      a.value = a;
      return a;
   }

   protected boolean enqueueReceiveInternal(@NotNull Receive<? super E> a) {
      ReentrantLock a = a.lock;
      int a = false;
      Lock var4 = (Lock)a;
      var4.lock();

      boolean var6;
      try {
         int a = false;
         var6 = super.enqueueReceiveInternal(a);
      } finally {
         var4.unlock();
      }

      return var6;
   }

   @NotNull
   protected String getBufferDebugString() {
      ReentrantLock a = a.lock;
      int a = false;
      Lock var3 = (Lock)a;
      var3.lock();

      String var7;
      try {
         int a = false;
         var7 = "(value=" + a.value + ')';
      } finally {
         var3.unlock();
      }

      return var7;
   }
}
