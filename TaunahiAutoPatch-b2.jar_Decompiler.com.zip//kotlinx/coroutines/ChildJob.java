package kotlinx.coroutines;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** @deprecated */
@Deprecated(
   message = "This is internal API and may be removed in the future releases",
   level = DeprecationLevel.ERROR
)
@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bg\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H'¨\u0006\u0006"},
   d2 = {"Lkotlinx/coroutines/ChildJob;", "Lkotlinx/coroutines/Job;", "parentCancelled", "", "parentJob", "Lkotlinx/coroutines/ParentJob;", "kotlinx-coroutines-core"}
)
@InternalCoroutinesApi
public interface ChildJob extends Job {
   @InternalCoroutinesApi
   void parentCancelled(@NotNull ParentJob var1);

   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public static final class DefaultImpls {
      /** @deprecated */
      // $FF: synthetic method
      @Deprecated(
         message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
         level = DeprecationLevel.HIDDEN
      )
      public static void cancel(ChildJob a) {
         Job.DefaultImpls.cancel((Job)a);
      }

      /** @deprecated */
      @Deprecated(
         message = "Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.",
         level = DeprecationLevel.ERROR
      )
      @NotNull
      public static Job plus(@NotNull ChildJob a, @NotNull Job a) {
         return Job.DefaultImpls.plus((Job)a, a);
      }

      @NotNull
      public static CoroutineContext plus(@NotNull ChildJob a, @NotNull CoroutineContext a) {
         return Job.DefaultImpls.plus((Job)a, a);
      }

      public static <R> R fold(@NotNull ChildJob a, R a, @NotNull Function2<? super R, ? super CoroutineContext.Element, ? extends R> a) {
         return Job.DefaultImpls.fold((Job)a, a, a);
      }

      @Nullable
      public static <E extends CoroutineContext.Element> E get(@NotNull ChildJob a, @NotNull CoroutineContext.Key<E> a) {
         return Job.DefaultImpls.get((Job)a, a);
      }

      @NotNull
      public static CoroutineContext minusKey(@NotNull ChildJob a, @NotNull CoroutineContext.Key<?> a) {
         return Job.DefaultImpls.minusKey((Job)a, a);
      }
   }
}
