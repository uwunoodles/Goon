package kotlinx.coroutines;

import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.CoroutineStackFrame;
import kotlin.jvm.JvmName;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.internal.DispatchedContinuation;
import kotlinx.coroutines.internal.StackTraceRecoveryKt;
import kotlinx.coroutines.internal.Symbol;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000¶\u0001\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0001\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000e\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\b\u0011\u0018\u0000*\u0006\b\u0000\u0010\u0001 \u00002\t\u0012\u0004\u0012\u00028\u00000\u008a\u00012\t\u0012\u0004\u0012\u00028\u00000\u008b\u00012\u00060tj\u0002`uB\u001d\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0019\u0010\u000b\u001a\u00020\n2\b\u0010\t\u001a\u0004\u0018\u00010\bH\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u001f\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u000e\u001a\u00020\r2\b\u0010\u0010\u001a\u0004\u0018\u00010\u000f¢\u0006\u0004\b\u0012\u0010\u0013JB\u0010\u0012\u001a\u00020\u00112'\u0010\u000e\u001a#\u0012\u0015\u0012\u0013\u0018\u00010\u000f¢\u0006\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u00110\u0014j\u0002`\u00172\b\u0010\u0010\u001a\u0004\u0018\u00010\u000fH\u0002¢\u0006\u0004\b\u0012\u0010\u0018J\u001e\u0010\u001b\u001a\u00020\u00112\f\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00110\u0019H\u0082\b¢\u0006\u0004\b\u001b\u0010\u001cJ8\u0010\u001e\u001a\u00020\u00112!\u0010\u001d\u001a\u001d\u0012\u0013\u0012\u00110\u000f¢\u0006\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u00110\u00142\u0006\u0010\u0010\u001a\u00020\u000f¢\u0006\u0004\b\u001e\u0010\u0018J\u0019\u0010 \u001a\u00020\u001f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u000fH\u0016¢\u0006\u0004\b \u0010!J!\u0010%\u001a\u00020\u00112\b\u0010\"\u001a\u0004\u0018\u00010\b2\u0006\u0010\u0010\u001a\u00020\u000fH\u0010¢\u0006\u0004\b#\u0010$J\u0017\u0010&\u001a\u00020\u001f2\u0006\u0010\u0010\u001a\u00020\u000fH\u0002¢\u0006\u0004\b&\u0010!J\u0017\u0010(\u001a\u00020\u00112\u0006\u0010'\u001a\u00020\bH\u0016¢\u0006\u0004\b(\u0010)J\u000f\u0010,\u001a\u00020\u0011H\u0000¢\u0006\u0004\b*\u0010+J\u000f\u0010-\u001a\u00020\u0011H\u0002¢\u0006\u0004\b-\u0010+J\u0017\u0010/\u001a\u00020\u00112\u0006\u0010.\u001a\u00020\u0004H\u0002¢\u0006\u0004\b/\u00100J\u0017\u00103\u001a\u00020\u000f2\u0006\u00102\u001a\u000201H\u0016¢\u0006\u0004\b3\u00104J\u001b\u00108\u001a\u0004\u0018\u00010\u000f2\b\u00105\u001a\u0004\u0018\u00010\bH\u0010¢\u0006\u0004\b6\u00107J\u0011\u00109\u001a\u0004\u0018\u00010\bH\u0001¢\u0006\u0004\b9\u0010:J\u0017\u0010=\u001a\n\u0018\u00010;j\u0004\u0018\u0001`<H\u0016¢\u0006\u0004\b=\u0010>J\u001f\u0010A\u001a\u00028\u0001\"\u0004\b\u0001\u0010\u00012\b\u00105\u001a\u0004\u0018\u00010\bH\u0010¢\u0006\u0004\b?\u0010@J\u000f\u0010B\u001a\u00020\u0011H\u0016¢\u0006\u0004\bB\u0010+J\u0011\u0010D\u001a\u0004\u0018\u00010CH\u0002¢\u0006\u0004\bD\u0010EJ8\u0010F\u001a\u00020\u00112'\u0010\u000e\u001a#\u0012\u0015\u0012\u0013\u0018\u00010\u000f¢\u0006\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u00110\u0014j\u0002`\u0017H\u0016¢\u0006\u0004\bF\u0010GJ\u000f\u0010H\u001a\u00020\u001fH\u0002¢\u0006\u0004\bH\u0010IJ8\u0010J\u001a\u00020\r2'\u0010\u000e\u001a#\u0012\u0015\u0012\u0013\u0018\u00010\u000f¢\u0006\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u00110\u0014j\u0002`\u0017H\u0002¢\u0006\u0004\bJ\u0010KJB\u0010L\u001a\u00020\u00112'\u0010\u000e\u001a#\u0012\u0015\u0012\u0013\u0018\u00010\u000f¢\u0006\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u00110\u0014j\u0002`\u00172\b\u00105\u001a\u0004\u0018\u00010\bH\u0002¢\u0006\u0004\bL\u0010MJ\u000f\u0010O\u001a\u00020NH\u0014¢\u0006\u0004\bO\u0010PJ\u0017\u0010S\u001a\u00020\u00112\u0006\u0010\u0010\u001a\u00020\u000fH\u0000¢\u0006\u0004\bQ\u0010RJ\u000f\u0010T\u001a\u00020\u0011H\u0002¢\u0006\u0004\bT\u0010+J\u000f\u0010U\u001a\u00020\u001fH\u0001¢\u0006\u0004\bU\u0010IJ<\u0010W\u001a\u00020\u00112\u0006\u0010V\u001a\u00028\u00002#\u0010\u001d\u001a\u001f\u0012\u0013\u0012\u00110\u000f¢\u0006\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u0014H\u0016¢\u0006\u0004\bW\u0010XJH\u0010Y\u001a\u00020\u00112\b\u0010\t\u001a\u0004\u0018\u00010\b2\u0006\u0010\u0005\u001a\u00020\u00042%\b\u0002\u0010\u001d\u001a\u001f\u0012\u0013\u0012\u00110\u000f¢\u0006\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u0014H\u0002¢\u0006\u0004\bY\u0010ZJ \u0010]\u001a\u00020\u00112\f\u0010\\\u001a\b\u0012\u0004\u0012\u00028\u00000[H\u0016ø\u0001\u0000¢\u0006\u0004\b]\u0010)JZ\u0010`\u001a\u0004\u0018\u00010\b2\u0006\u00105\u001a\u00020^2\b\u0010\t\u001a\u0004\u0018\u00010\b2\u0006\u0010\u0005\u001a\u00020\u00042#\u0010\u001d\u001a\u001f\u0012\u0013\u0012\u00110\u000f¢\u0006\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u00142\b\u0010_\u001a\u0004\u0018\u00010\bH\u0002¢\u0006\u0004\b`\u0010aJ\u0011\u0010c\u001a\u0004\u0018\u00010\bH\u0010¢\u0006\u0004\bb\u0010:J\u000f\u0010d\u001a\u00020NH\u0016¢\u0006\u0004\bd\u0010PJ\u000f\u0010e\u001a\u00020\u001fH\u0002¢\u0006\u0004\be\u0010IJ#\u0010e\u001a\u0004\u0018\u00010\b2\u0006\u0010V\u001a\u00028\u00002\b\u0010_\u001a\u0004\u0018\u00010\bH\u0016¢\u0006\u0004\be\u0010fJH\u0010e\u001a\u0004\u0018\u00010\b2\u0006\u0010V\u001a\u00028\u00002\b\u0010_\u001a\u0004\u0018\u00010\b2#\u0010\u001d\u001a\u001f\u0012\u0013\u0012\u00110\u000f¢\u0006\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u0014H\u0016¢\u0006\u0004\be\u0010gJJ\u0010i\u001a\u0004\u0018\u00010h2\b\u0010\t\u001a\u0004\u0018\u00010\b2\b\u0010_\u001a\u0004\u0018\u00010\b2#\u0010\u001d\u001a\u001f\u0012\u0013\u0012\u00110\u000f¢\u0006\f\b\u0015\u0012\b\b\u0016\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u0014H\u0002¢\u0006\u0004\bi\u0010jJ\u0019\u0010l\u001a\u0004\u0018\u00010\b2\u0006\u0010k\u001a\u00020\u000fH\u0016¢\u0006\u0004\bl\u0010mJ\u000f\u0010n\u001a\u00020\u001fH\u0002¢\u0006\u0004\bn\u0010IJ\u001b\u0010p\u001a\u00020\u0011*\u00020o2\u0006\u0010V\u001a\u00028\u0000H\u0016¢\u0006\u0004\bp\u0010qJ\u001b\u0010r\u001a\u00020\u0011*\u00020o2\u0006\u0010k\u001a\u00020\u000fH\u0016¢\u0006\u0004\br\u0010sR\u001c\u0010x\u001a\n\u0018\u00010tj\u0004\u0018\u0001`u8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\bv\u0010wR\u001a\u0010z\u001a\u00020y8\u0016X\u0096\u0004¢\u0006\f\n\u0004\bz\u0010{\u001a\u0004\b|\u0010}R!\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u00028\u0000X\u0080\u0004¢\u0006\r\n\u0004\b\u0003\u0010~\u001a\u0005\b\u007f\u0010\u0080\u0001R\u0016\u0010\u0081\u0001\u001a\u00020\u001f8VX\u0096\u0004¢\u0006\u0007\u001a\u0005\b\u0081\u0001\u0010IR\u0016\u0010\u0082\u0001\u001a\u00020\u001f8VX\u0096\u0004¢\u0006\u0007\u001a\u0005\b\u0082\u0001\u0010IR\u0016\u0010\u0083\u0001\u001a\u00020\u001f8VX\u0096\u0004¢\u0006\u0007\u001a\u0005\b\u0083\u0001\u0010IR\u001b\u0010\u0084\u0001\u001a\u0004\u0018\u00010C8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0084\u0001\u0010\u0085\u0001R\u0017\u00105\u001a\u0004\u0018\u00010\b8@X\u0080\u0004¢\u0006\u0007\u001a\u0005\b\u0086\u0001\u0010:R\u0016\u0010\u0088\u0001\u001a\u00020N8BX\u0082\u0004¢\u0006\u0007\u001a\u0005\b\u0087\u0001\u0010P\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0089\u0001"},
   d2 = {"Lkotlinx/coroutines/CancellableContinuationImpl;", "T", "Lkotlin/coroutines/Continuation;", "delegate", "", "resumeMode", "CancellableContinuationImpl", "(Lkotlin/coroutines/Continuation;I)V", "", "proposedUpdate", "", "alreadyResumedError", "(Ljava/lang/Object;)Ljava/lang/Void;", "Lkotlinx/coroutines/CancelHandler;", "handler", "", "cause", "", "callCancelHandler", "(Lkotlinx/coroutines/CancelHandler;Ljava/lang/Throwable;)V", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "Lkotlinx/coroutines/CompletionHandler;", "(Lkotlin/jvm/functions/Function1;Ljava/lang/Throwable;)V", "Lkotlin/Function0;", "block", "callCancelHandlerSafely", "(Lkotlin/jvm/functions/Function0;)V", "onCancellation", "callOnCancellation", "", "cancel", "(Ljava/lang/Throwable;)Z", "takenState", "cancelCompletedResult$kotlinx_coroutines_core", "(Ljava/lang/Object;Ljava/lang/Throwable;)V", "cancelCompletedResult", "cancelLater", "token", "completeResume", "(Ljava/lang/Object;)V", "detachChild$kotlinx_coroutines_core", "()V", "detachChild", "detachChildIfNonResuable", "mode", "dispatchResume", "(I)V", "Lkotlinx/coroutines/Job;", "parent", "getContinuationCancellationCause", "(Lkotlinx/coroutines/Job;)Ljava/lang/Throwable;", "state", "getExceptionalResult$kotlinx_coroutines_core", "(Ljava/lang/Object;)Ljava/lang/Throwable;", "getExceptionalResult", "getResult", "()Ljava/lang/Object;", "Ljava/lang/StackTraceElement;", "Lkotlinx/coroutines/internal/StackTraceElement;", "getStackTraceElement", "()Ljava/lang/StackTraceElement;", "getSuccessfulResult$kotlinx_coroutines_core", "(Ljava/lang/Object;)Ljava/lang/Object;", "getSuccessfulResult", "initCancellability", "Lkotlinx/coroutines/DisposableHandle;", "installParentHandle", "()Lkotlinx/coroutines/DisposableHandle;", "invokeOnCancellation", "(Lkotlin/jvm/functions/Function1;)V", "isReusable", "()Z", "makeCancelHandler", "(Lkotlin/jvm/functions/Function1;)Lkotlinx/coroutines/CancelHandler;", "multipleHandlersError", "(Lkotlin/jvm/functions/Function1;Ljava/lang/Object;)V", "", "nameString", "()Ljava/lang/String;", "parentCancelled$kotlinx_coroutines_core", "(Ljava/lang/Throwable;)V", "parentCancelled", "releaseClaimedReusableContinuation", "resetStateReusable", "value", "resume", "(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)V", "resumeImpl", "(Ljava/lang/Object;ILkotlin/jvm/functions/Function1;)V", "Lkotlin/Result;", "result", "resumeWith", "Lkotlinx/coroutines/NotCompleted;", "idempotent", "resumedState", "(Lkotlinx/coroutines/NotCompleted;Ljava/lang/Object;ILkotlin/jvm/functions/Function1;Ljava/lang/Object;)Ljava/lang/Object;", "takeState$kotlinx_coroutines_core", "takeState", "toString", "tryResume", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "Lkotlinx/coroutines/internal/Symbol;", "tryResumeImpl", "(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)Lkotlinx/coroutines/internal/Symbol;", "exception", "tryResumeWithException", "(Ljava/lang/Throwable;)Ljava/lang/Object;", "trySuspend", "Lkotlinx/coroutines/CoroutineDispatcher;", "resumeUndispatched", "(Lkotlinx/coroutines/CoroutineDispatcher;Ljava/lang/Object;)V", "resumeUndispatchedWithException", "(Lkotlinx/coroutines/CoroutineDispatcher;Ljava/lang/Throwable;)V", "Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;", "Lkotlinx/coroutines/internal/CoroutineStackFrame;", "getCallerFrame", "()Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;", "callerFrame", "Lkotlin/coroutines/CoroutineContext;", "context", "Lkotlin/coroutines/CoroutineContext;", "getContext", "()Lkotlin/coroutines/CoroutineContext;", "Lkotlin/coroutines/Continuation;", "getDelegate$kotlinx_coroutines_core", "()Lkotlin/coroutines/Continuation;", "isActive", "isCancelled", "isCompleted", "parentHandle", "Lkotlinx/coroutines/DisposableHandle;", "getState$kotlinx_coroutines_core", "getStateDebugRepresentation", "stateDebugRepresentation", "kotlinx-coroutines-core", "Lkotlinx/coroutines/DispatchedTask;", "Lkotlinx/coroutines/CancellableContinuation;"}
)
@PublishedApi
public class CancellableContinuationImpl<T> extends DispatchedTask<T> implements CancellableContinuation<T>, CoroutineStackFrame {
   @NotNull
   private final Continuation<T> delegate;
   @NotNull
   private final CoroutineContext context;
   // $FF: synthetic field
   @NotNull
   private volatile int _decision;
   // $FF: synthetic field
   private static final AtomicIntegerFieldUpdater _decision$FU = AtomicIntegerFieldUpdater.newUpdater(CancellableContinuationImpl.class, "_decision");
   // $FF: synthetic field
   @NotNull
   private volatile Object _state;
   // $FF: synthetic field
   private static final AtomicReferenceFieldUpdater _state$FU = AtomicReferenceFieldUpdater.newUpdater(CancellableContinuationImpl.class, Object.class, "_state");
   @Nullable
   private DisposableHandle parentHandle;

   public CancellableContinuationImpl(@NotNull Continuation<? super T> a, int a) {
      super(a);
      a.delegate = a;
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a == -1) {
            throw new AssertionError();
         }
      }

      a.context = a.delegate.getContext();
      a._decision = 0;
      a._state = Active.INSTANCE;
   }

   @NotNull
   public final Continuation<T> getDelegate$kotlinx_coroutines_core() {
      return a.delegate;
   }

   @NotNull
   public CoroutineContext getContext() {
      return a.context;
   }

   @Nullable
   public final Object getState$kotlinx_coroutines_core() {
      return a._state;
   }

   public boolean isActive() {
      return a.getState$kotlinx_coroutines_core() instanceof NotCompleted;
   }

   public boolean isCompleted() {
      return !(a.getState$kotlinx_coroutines_core() instanceof NotCompleted);
   }

   public boolean isCancelled() {
      return a.getState$kotlinx_coroutines_core() instanceof CancelledContinuation;
   }

   private final String getStateDebugRepresentation() {
      Object var1 = a.getState$kotlinx_coroutines_core();
      return var1 instanceof NotCompleted ? "Active" : (var1 instanceof CancelledContinuation ? "Cancelled" : "Completed");
   }

   public void initCancellability() {
      DisposableHandle var10000 = a.installParentHandle();
      if (var10000 != null) {
         DisposableHandle a = var10000;
         if (a.isCompleted()) {
            a.dispose();
            a.parentHandle = (DisposableHandle)NonDisposableHandle.INSTANCE;
         }

      }
   }

   private final boolean isReusable() {
      return DispatchedTaskKt.isReusableMode(a.resumeMode) && ((DispatchedContinuation)a.delegate).isReusable();
   }

   @JvmName(
      name = "resetStateReusable"
   )
   public final boolean resetStateReusable() {
      boolean a;
      if (DebugKt.getASSERTIONS_ENABLED()) {
         a = false;
         if (a.resumeMode != 2) {
            throw new AssertionError();
         }
      }

      if (DebugKt.getASSERTIONS_ENABLED()) {
         a = false;
         if (a.parentHandle == NonDisposableHandle.INSTANCE) {
            throw new AssertionError();
         }
      }

      Object a = a._state;
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a instanceof NotCompleted) {
            throw new AssertionError();
         }
      }

      if (a instanceof CompletedContinuation && ((CompletedContinuation)a).idempotentResume != null) {
         a.detachChild$kotlinx_coroutines_core();
         return false;
      } else {
         a._decision = 0;
         a._state = Active.INSTANCE;
         return true;
      }
   }

   @Nullable
   public CoroutineStackFrame getCallerFrame() {
      Continuation var1 = a.delegate;
      return var1 instanceof CoroutineStackFrame ? (CoroutineStackFrame)var1 : null;
   }

   @Nullable
   public StackTraceElement getStackTraceElement() {
      return null;
   }

   @Nullable
   public Object takeState$kotlinx_coroutines_core() {
      return a.getState$kotlinx_coroutines_core();
   }

   public void cancelCompletedResult$kotlinx_coroutines_core(@Nullable Object a1, @NotNull Throwable a) {
      CancellableContinuationImpl a = a;
      boolean var4 = false;

      while(true) {
         Object a = a._state;
         int a = false;
         if (a instanceof NotCompleted) {
            throw new IllegalStateException("Not completed".toString());
         }

         if (a instanceof CompletedExceptionally) {
            return;
         }

         if (a instanceof CompletedContinuation) {
            if (((CompletedContinuation)a).getCancelled()) {
               int a = false;
               String var10 = "Must be called at most once";
               throw new IllegalStateException(var10.toString());
            }

            CompletedContinuation a = CompletedContinuation.copy$default((CompletedContinuation)a, (Object)null, (CancelHandler)null, (Function1)null, (Object)null, a, 15, (Object)null);
            if (_state$FU.compareAndSet(a, a, a)) {
               ((CompletedContinuation)a).invokeHandlers(a, a);
               return;
            }
         } else if (_state$FU.compareAndSet(a, a, new CompletedContinuation(a, (CancelHandler)null, (Function1)null, (Object)null, a, 14, (DefaultConstructorMarker)null))) {
            return;
         }
      }
   }

   private final boolean cancelLater(Throwable a) {
      if (!a.isReusable()) {
         return false;
      } else {
         DispatchedContinuation a = (DispatchedContinuation)a.delegate;
         return a.postponeCancellation(a);
      }
   }

   public boolean cancel(@Nullable Throwable a) {
      CancellableContinuationImpl a = a;
      boolean var3 = false;

      Object a;
      CancelledContinuation a;
      do {
         a = a._state;
         int a = false;
         if (!(a instanceof NotCompleted)) {
            return false;
         }

         a = new CancelledContinuation((Continuation)a, a, a instanceof CancelHandler);
      } while(!_state$FU.compareAndSet(a, a, a));

      CancelHandler var10000 = a instanceof CancelHandler ? (CancelHandler)a : null;
      if ((a instanceof CancelHandler ? (CancelHandler)a : null) != null) {
         CancelHandler a = var10000;
         int a = false;
         a.callCancelHandler(a, a);
      }

      a.detachChildIfNonResuable();
      a.dispatchResume(a.resumeMode);
      return true;
   }

   public final void parentCancelled$kotlinx_coroutines_core(@NotNull Throwable a) {
      if (!a.cancelLater(a)) {
         a.cancel(a);
         a.detachChildIfNonResuable();
      }
   }

   private final void callCancelHandlerSafely(Function0<Unit> a) {
      boolean var2 = false;

      try {
         a.invoke();
      } catch (Throwable var4) {
         CoroutineExceptionHandlerKt.handleCoroutineException(a.getContext(), (Throwable)(new CompletionHandlerException("Exception in invokeOnCancellation handler for " + a, var4)));
      }

   }

   private final void callCancelHandler(Function1<? super Throwable, Unit> a, Throwable a) {
      boolean var4 = false;

      try {
         int a = false;
         int a = false;
         a.invoke(a);
      } catch (Throwable var9) {
         CoroutineExceptionHandlerKt.handleCoroutineException(a.getContext(), (Throwable)(new CompletionHandlerException("Exception in invokeOnCancellation handler for " + a, var9)));
      }

   }

   public final void callCancelHandler(@NotNull CancelHandler a, @Nullable Throwable a) {
      boolean var4 = false;

      try {
         int a = false;
         a.invoke(a);
      } catch (Throwable var7) {
         CoroutineExceptionHandlerKt.handleCoroutineException(a.getContext(), (Throwable)(new CompletionHandlerException("Exception in invokeOnCancellation handler for " + a, var7)));
      }

   }

   public final void callOnCancellation(@NotNull Function1<? super Throwable, Unit> a, @NotNull Throwable a) {
      try {
         a.invoke(a);
      } catch (Throwable var4) {
         CoroutineExceptionHandlerKt.handleCoroutineException(a.getContext(), (Throwable)(new CompletionHandlerException("Exception in resume onCancellation handler for " + a, var4)));
      }

   }

   @NotNull
   public Throwable getContinuationCancellationCause(@NotNull Job a) {
      return (Throwable)a.getCancellationException();
   }

   private final boolean trySuspend() {
      CancellableContinuationImpl a = a;
      boolean var2 = false;

      do {
         int a = a._decision;
         int a = false;
         switch(a) {
         case 0:
            break;
         case 1:
         default:
            throw new IllegalStateException("Already suspended".toString());
         case 2:
            return false;
         }
      } while(!_decision$FU.compareAndSet(a, 0, 1));

      return true;
   }

   private final boolean tryResume() {
      CancellableContinuationImpl a = a;
      boolean var2 = false;

      do {
         int a = a._decision;
         int a = false;
         switch(a) {
         case 0:
            break;
         case 1:
            return false;
         default:
            throw new IllegalStateException("Already resumed".toString());
         }
      } while(!_decision$FU.compareAndSet(a, 0, 2));

      return true;
   }

   @PublishedApi
   @Nullable
   public final Object getResult() {
      boolean a = a.isReusable();
      if (a.trySuspend()) {
         if (a.parentHandle == null) {
            a.installParentHandle();
         }

         if (a) {
            a.releaseClaimedReusableContinuation();
         }

         return IntrinsicsKt.getCOROUTINE_SUSPENDED();
      } else {
         if (a) {
            a.releaseClaimedReusableContinuation();
         }

         Object a = a.getState$kotlinx_coroutines_core();
         if (a instanceof CompletedExceptionally) {
            Throwable a = ((CompletedExceptionally)a).cause;
            int a = false;
            throw DebugKt.getRECOVER_STACK_TRACES() && (Continuation)a instanceof CoroutineStackFrame ? StackTraceRecoveryKt.access$recoverFromStackFrame(a, (CoroutineStackFrame)((Continuation)a)) : a;
         } else {
            if (DispatchedTaskKt.isCancellableMode(a.resumeMode)) {
               Job a = (Job)a.getContext().get((CoroutineContext.Key)Job.Key);
               if (a != null && !a.isActive()) {
                  CancellationException a = a.getCancellationException();
                  a.cancelCompletedResult$kotlinx_coroutines_core(a, (Throwable)a);
                  int a = false;
                  throw DebugKt.getRECOVER_STACK_TRACES() && (Continuation)a instanceof CoroutineStackFrame ? StackTraceRecoveryKt.access$recoverFromStackFrame((Throwable)a, (CoroutineStackFrame)((Continuation)a)) : (Throwable)a;
               }
            }

            return a.getSuccessfulResult$kotlinx_coroutines_core(a);
         }
      }
   }

   private final DisposableHandle installParentHandle() {
      Job var10000 = (Job)a.getContext().get((CoroutineContext.Key)Job.Key);
      if (var10000 == null) {
         return null;
      } else {
         Job a = var10000;
         CompletionHandlerBase a = (CompletionHandlerBase)(new ChildContinuation(a));
         int a = false;
         DisposableHandle a = Job.DefaultImpls.invokeOnCompletion$default(a, true, false, (Function1)a, 2, (Object)null);
         a.parentHandle = a;
         return a;
      }
   }

   private final void releaseClaimedReusableContinuation() {
      Continuation var2 = a.delegate;
      DispatchedContinuation var10000 = var2 instanceof DispatchedContinuation ? (DispatchedContinuation)var2 : null;
      if ((var2 instanceof DispatchedContinuation ? (DispatchedContinuation)var2 : null) != null) {
         Throwable var3 = var10000.tryReleaseClaimedContinuation((CancellableContinuation)a);
         if (var3 != null) {
            Throwable a = var3;
            a.detachChild$kotlinx_coroutines_core();
            a.cancel(a);
            return;
         }
      }

   }

   public void resumeWith(@NotNull Object a) {
      resumeImpl$default(a, CompletionStateKt.toState(a, (CancellableContinuation)a), a.resumeMode, (Function1)null, 4, (Object)null);
   }

   public void resume(T a, @Nullable Function1<? super Throwable, Unit> a) {
      a.resumeImpl(a, a.resumeMode, a);
   }

   public void invokeOnCancellation(@NotNull Function1<? super Throwable, Unit> a) {
      CancelHandler a = a.makeCancelHandler(a);
      CancellableContinuationImpl a = a;
      boolean var4 = false;

      while(true) {
         Object a = a._state;
         int a = false;
         if (a instanceof Active) {
            if (_state$FU.compareAndSet(a, a, a)) {
               return;
            }
         } else if (a instanceof CancelHandler) {
            a.multipleHandlersError(a, a);
         } else {
            if (a instanceof CompletedExceptionally) {
               if (!((CompletedExceptionally)a).makeHandled()) {
                  a.multipleHandlersError(a, a);
               }

               if (a instanceof CancelledContinuation) {
                  a.callCancelHandler(a, (a instanceof CompletedExceptionally ? (CompletedExceptionally)a : null) != null ? (a instanceof CompletedExceptionally ? (CompletedExceptionally)a : null).cause : null);
               }

               return;
            }

            CompletedContinuation a;
            if (a instanceof CompletedContinuation) {
               if (((CompletedContinuation)a).cancelHandler != null) {
                  a.multipleHandlersError(a, a);
               }

               if (a instanceof BeforeResumeCancelHandler) {
                  return;
               }

               if (((CompletedContinuation)a).getCancelled()) {
                  a.callCancelHandler(a, ((CompletedContinuation)a).cancelCause);
                  return;
               }

               a = CompletedContinuation.copy$default((CompletedContinuation)a, (Object)null, a, (Function1)null, (Object)null, (Throwable)null, 29, (Object)null);
               if (_state$FU.compareAndSet(a, a, a)) {
                  return;
               }
            } else {
               if (a instanceof BeforeResumeCancelHandler) {
                  return;
               }

               a = new CompletedContinuation(a, a, (Function1)null, (Object)null, (Throwable)null, 28, (DefaultConstructorMarker)null);
               if (_state$FU.compareAndSet(a, a, a)) {
                  return;
               }
            }
         }
      }
   }

   private final void multipleHandlersError(Function1<? super Throwable, Unit> a, Object a) {
      throw new IllegalStateException(("It's prohibited to register multiple handlers, tried to register " + a + ", already has " + a).toString());
   }

   private final CancelHandler makeCancelHandler(Function1<? super Throwable, Unit> a) {
      return a instanceof CancelHandler ? (CancelHandler)a : (CancelHandler)(new InvokeOnCancel(a));
   }

   private final void dispatchResume(int a) {
      if (!a.tryResume()) {
         DispatchedTaskKt.dispatch((DispatchedTask)a, a);
      }
   }

   private final Object resumedState(NotCompleted a, Object a, int a, Function1<? super Throwable, Unit> a, Object a) {
      Object var10000;
      if (a instanceof CompletedExceptionally) {
         boolean a;
         if (DebugKt.getASSERTIONS_ENABLED()) {
            a = false;
            if (a != null) {
               throw new AssertionError();
            }
         }

         if (DebugKt.getASSERTIONS_ENABLED()) {
            a = false;
            if (a != null) {
               throw new AssertionError();
            }
         }

         var10000 = a;
      } else {
         var10000 = !DispatchedTaskKt.isCancellableMode(a) && a == null ? a : (a == null && (!(a instanceof CancelHandler) || a instanceof BeforeResumeCancelHandler) && a == null ? a : new CompletedContinuation(a, a instanceof CancelHandler ? (CancelHandler)a : null, a, a, (Throwable)null, 16, (DefaultConstructorMarker)null));
      }

      return var10000;
   }

   private final void resumeImpl(Object a, int a, Function1<? super Throwable, Unit> a) {
      CancellableContinuationImpl a = a;
      boolean var5 = false;

      Object a;
      Object a;
      do {
         a = a._state;
         int a = false;
         if (!(a instanceof NotCompleted)) {
            if (a instanceof CancelledContinuation && ((CancelledContinuation)a).makeResumed()) {
               if (a != null) {
                  int a = false;
                  a.callOnCancellation(a, ((CancelledContinuation)a).cause);
               }

               return;
            }

            a.alreadyResumedError(a);
            throw new KotlinNothingValueException();
         }

         a = a.resumedState((NotCompleted)a, a, a, a, (Object)null);
      } while(!_state$FU.compareAndSet(a, a, a));

      a.detachChildIfNonResuable();
      a.dispatchResume(a);
   }

   // $FF: synthetic method
   static void resumeImpl$default(CancellableContinuationImpl var0, Object var1, int var2, Function1 var3, int var4, Object var5) {
      if (var5 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: resumeImpl");
      } else {
         if ((var4 & 4) != 0) {
            var3 = null;
         }

         var0.resumeImpl(var1, var2, var3);
      }
   }

   private final Symbol tryResumeImpl(Object a, Object a, Function1<? super Throwable, Unit> a) {
      CancellableContinuationImpl a = a;
      boolean var5 = false;

      Object a;
      Object a;
      do {
         a = a._state;
         int a = false;
         if (!(a instanceof NotCompleted)) {
            if (!(a instanceof CompletedContinuation)) {
               return null;
            } else {
               Symbol var10000;
               if (a != null && ((CompletedContinuation)a).idempotentResume == a) {
                  if (DebugKt.getASSERTIONS_ENABLED()) {
                     int a = false;
                     if (!Intrinsics.areEqual(((CompletedContinuation)a).result, a)) {
                        throw new AssertionError();
                     }
                  }

                  var10000 = CancellableContinuationImplKt.RESUME_TOKEN;
               } else {
                  var10000 = (Symbol)null;
               }

               return var10000;
            }
         }

         a = a.resumedState((NotCompleted)a, a, a.resumeMode, a, a);
      } while(!_state$FU.compareAndSet(a, a, a));

      a.detachChildIfNonResuable();
      return CancellableContinuationImplKt.RESUME_TOKEN;
   }

   private final Void alreadyResumedError(Object a) {
      throw new IllegalStateException(("Already resumed, but proposed with update " + a).toString());
   }

   private final void detachChildIfNonResuable() {
      if (!a.isReusable()) {
         a.detachChild$kotlinx_coroutines_core();
      }

   }

   public final void detachChild$kotlinx_coroutines_core() {
      DisposableHandle var10000 = a.parentHandle;
      if (var10000 != null) {
         DisposableHandle a = var10000;
         a.dispose();
         a.parentHandle = (DisposableHandle)NonDisposableHandle.INSTANCE;
      }
   }

   @Nullable
   public Object tryResume(T a, @Nullable Object a) {
      return a.tryResumeImpl(a, a, (Function1)null);
   }

   @Nullable
   public Object tryResume(T a, @Nullable Object a, @Nullable Function1<? super Throwable, Unit> a) {
      return a.tryResumeImpl(a, a, a);
   }

   @Nullable
   public Object tryResumeWithException(@NotNull Throwable a) {
      return a.tryResumeImpl(new CompletedExceptionally(a, false, 2, (DefaultConstructorMarker)null), (Object)null, (Function1)null);
   }

   public void completeResume(@NotNull Object a) {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a != CancellableContinuationImplKt.RESUME_TOKEN) {
            throw new AssertionError();
         }
      }

      a.dispatchResume(a.resumeMode);
   }

   public void resumeUndispatched(@NotNull CoroutineDispatcher a, T a) {
      Continuation var4 = a.delegate;
      DispatchedContinuation a = var4 instanceof DispatchedContinuation ? (DispatchedContinuation)var4 : null;
      resumeImpl$default(a, a, (a != null ? a.dispatcher : null) == a ? 4 : a.resumeMode, (Function1)null, 4, (Object)null);
   }

   public void resumeUndispatchedWithException(@NotNull CoroutineDispatcher a, @NotNull Throwable a) {
      Continuation var4 = a.delegate;
      DispatchedContinuation a = var4 instanceof DispatchedContinuation ? (DispatchedContinuation)var4 : null;
      resumeImpl$default(a, new CompletedExceptionally(a, false, 2, (DefaultConstructorMarker)null), (a != null ? a.dispatcher : null) == a ? 4 : a.resumeMode, (Function1)null, 4, (Object)null);
   }

   public <T> T getSuccessfulResult$kotlinx_coroutines_core(@Nullable Object a) {
      return a instanceof CompletedContinuation ? ((CompletedContinuation)a).result : a;
   }

   @Nullable
   public Throwable getExceptionalResult$kotlinx_coroutines_core(@Nullable Object a) {
      Throwable var10000 = super.getExceptionalResult$kotlinx_coroutines_core(a);
      if (var10000 != null) {
         Throwable a = var10000;
         int a = false;
         Continuation a = a.delegate;
         int a = false;
         var10000 = DebugKt.getRECOVER_STACK_TRACES() && a instanceof CoroutineStackFrame ? StackTraceRecoveryKt.access$recoverFromStackFrame(a, (CoroutineStackFrame)a) : a;
      } else {
         var10000 = null;
      }

      return var10000;
   }

   @NotNull
   public String toString() {
      return a.nameString() + '(' + DebugStringsKt.toDebugString(a.delegate) + "){" + a.getStateDebugRepresentation() + "}@" + DebugStringsKt.getHexAddress(a);
   }

   @NotNull
   protected String nameString() {
      return "CancellableContinuation";
   }
}
