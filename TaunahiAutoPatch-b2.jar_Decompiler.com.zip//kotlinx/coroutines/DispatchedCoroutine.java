package kotlinx.coroutines;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function1;
import kotlinx.coroutines.internal.DispatchedContinuationKt;
import kotlinx.coroutines.internal.ScopeCoroutine;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\b\u0000\u0018\u0000*\u0006\b\u0000\u0010\u0001 \u00002\b\u0012\u0004\u0012\u00028\u00000\u0015B\u001d\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0019\u0010\u000b\u001a\u00020\n2\b\u0010\t\u001a\u0004\u0018\u00010\bH\u0014¢\u0006\u0004\b\u000b\u0010\fJ\u0019\u0010\r\u001a\u00020\n2\b\u0010\t\u001a\u0004\u0018\u00010\bH\u0014¢\u0006\u0004\b\r\u0010\fJ\u000f\u0010\u000e\u001a\u0004\u0018\u00010\b¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0011\u001a\u00020\u0010H\u0002¢\u0006\u0004\b\u0011\u0010\u0012J\u000f\u0010\u0013\u001a\u00020\u0010H\u0002¢\u0006\u0004\b\u0013\u0010\u0012¨\u0006\u0014"},
   d2 = {"Lkotlinx/coroutines/DispatchedCoroutine;", "T", "Lkotlin/coroutines/CoroutineContext;", "context", "Lkotlin/coroutines/Continuation;", "uCont", "DispatchedCoroutine", "(Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;)V", "", "state", "", "afterCompletion", "(Ljava/lang/Object;)V", "afterResume", "getResult", "()Ljava/lang/Object;", "", "tryResume", "()Z", "trySuspend", "kotlinx-coroutines-core", "Lkotlinx/coroutines/internal/ScopeCoroutine;"}
)
public final class DispatchedCoroutine<T> extends ScopeCoroutine<T> {
   // $FF: synthetic field
   @NotNull
   private volatile int _decision = 0;
   // $FF: synthetic field
   private static final AtomicIntegerFieldUpdater _decision$FU = AtomicIntegerFieldUpdater.newUpdater(DispatchedCoroutine.class, "_decision");

   public DispatchedCoroutine(@NotNull CoroutineContext a, @NotNull Continuation<? super T> a) {
      super(a, a);
   }

   private final boolean trySuspend() {
      DispatchedCoroutine a = a;
      boolean var2 = false;

      do {
         int a = a._decision;
         int a = false;
         switch(a) {
         case 0:
            break;
         case 1:
         default:
            throw new IllegalStateException("Already suspended".toString());
         case 2:
            return false;
         }
      } while(!_decision$FU.compareAndSet(a, 0, 1));

      return true;
   }

   private final boolean tryResume() {
      DispatchedCoroutine a = a;
      boolean var2 = false;

      do {
         int a = a._decision;
         int a = false;
         switch(a) {
         case 0:
            break;
         case 1:
            return false;
         default:
            throw new IllegalStateException("Already resumed".toString());
         }
      } while(!_decision$FU.compareAndSet(a, 0, 2));

      return true;
   }

   protected void afterCompletion(@Nullable Object a) {
      a.afterResume(a);
   }

   protected void afterResume(@Nullable Object a) {
      if (!a.tryResume()) {
         DispatchedContinuationKt.resumeCancellableWith$default(IntrinsicsKt.intercepted(a.uCont), CompletionStateKt.recoverResult(a, a.uCont), (Function1)null, 2, (Object)null);
      }
   }

   @Nullable
   public final Object getResult() {
      if (a.trySuspend()) {
         return IntrinsicsKt.getCOROUTINE_SUSPENDED();
      } else {
         Object a = JobSupportKt.unboxState(a.getState$kotlinx_coroutines_core());
         if (a instanceof CompletedExceptionally) {
            throw ((CompletedExceptionally)a).cause;
         } else {
            return a;
         }
      }
   }
}
