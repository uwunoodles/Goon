package kotlinx.coroutines;

import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.CoroutineStackFrame;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.InlineMarker;
import kotlinx.coroutines.internal.DispatchedContinuation;
import kotlinx.coroutines.internal.StackTraceRecoveryKt;
import kotlinx.coroutines.internal.ThreadContextKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000<\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0003\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a \u0010\f\u001a\u00020\r\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\u000f2\u0006\u0010\u0010\u001a\u00020\u0001H\u0000\u001a.\u0010\u0011\u001a\u00020\r\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\u000f2\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u00132\u0006\u0010\u0014\u001a\u00020\tH\u0000\u001a\u0010\u0010\u0015\u001a\u00020\r*\u0006\u0012\u0002\b\u00030\u000fH\u0002\u001a\u0019\u0010\u0016\u001a\u00020\r*\u0006\u0012\u0002\b\u00030\u00132\u0006\u0010\u0017\u001a\u00020\u0018H\u0080\b\u001a'\u0010\u0019\u001a\u00020\r*\u0006\u0012\u0002\b\u00030\u000f2\u0006\u0010\u001a\u001a\u00020\u001b2\f\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\r0\u001dH\u0080\b\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0080T¢\u0006\u0002\n\u0000\"\u0016\u0010\u0002\u001a\u00020\u00018\u0000X\u0081T¢\u0006\b\n\u0000\u0012\u0004\b\u0003\u0010\u0004\"\u000e\u0010\u0005\u001a\u00020\u0001X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0006\u001a\u00020\u0001X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0007\u001a\u00020\u0001X\u0080T¢\u0006\u0002\n\u0000\"\u0018\u0010\b\u001a\u00020\t*\u00020\u00018@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\b\u0010\n\"\u0018\u0010\u000b\u001a\u00020\t*\u00020\u00018@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u000b\u0010\n¨\u0006\u001e"},
   d2 = {"MODE_ATOMIC", "", "MODE_CANCELLABLE", "getMODE_CANCELLABLE$annotations", "()V", "MODE_CANCELLABLE_REUSABLE", "MODE_UNDISPATCHED", "MODE_UNINITIALIZED", "isCancellableMode", "", "(I)Z", "isReusableMode", "dispatch", "", "T", "Lkotlinx/coroutines/DispatchedTask;", "mode", "resume", "delegate", "Lkotlin/coroutines/Continuation;", "undispatched", "resumeUnconfined", "resumeWithStackTrace", "exception", "", "runUnconfinedEventLoop", "eventLoop", "Lkotlinx/coroutines/EventLoop;", "block", "Lkotlin/Function0;", "kotlinx-coroutines-core"}
)
public final class DispatchedTaskKt {
   public static final int MODE_ATOMIC = 0;
   public static final int MODE_CANCELLABLE = 1;
   public static final int MODE_CANCELLABLE_REUSABLE = 2;
   public static final int MODE_UNDISPATCHED = 4;
   public static final int MODE_UNINITIALIZED = -1;

   /** @deprecated */
   // $FF: synthetic method
   @PublishedApi
   public static void getMODE_CANCELLABLE$annotations() {
   }

   public static final boolean isCancellableMode(int a) {
      return a == 1 || a == 2;
   }

   public static final boolean isReusableMode(int a) {
      return a == 2;
   }

   public static final <T> void dispatch(@NotNull DispatchedTask<? super T> a, int a) {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a == -1) {
            throw new AssertionError();
         }
      }

      Continuation a = a.getDelegate$kotlinx_coroutines_core();
      boolean a = a == 4;
      if (!a && a instanceof DispatchedContinuation && isCancellableMode(a) == isCancellableMode(a.resumeMode)) {
         CoroutineDispatcher a = ((DispatchedContinuation)a).dispatcher;
         CoroutineContext a = a.getContext();
         if (a.isDispatchNeeded(a)) {
            a.dispatch(a, (Runnable)a);
         } else {
            resumeUnconfined(a);
         }
      } else {
         resume(a, a, a);
      }

   }

   public static final <T> void resume(@NotNull DispatchedTask<? super T> a, @NotNull Continuation<? super T> a, boolean a) {
      Object a = a.takeState$kotlinx_coroutines_core();
      Throwable a = a.getExceptionalResult$kotlinx_coroutines_core(a);
      Result.Companion var10000;
      Object var18;
      if (a != null) {
         var10000 = Result.Companion;
         var18 = Result.constructor-impl(ResultKt.createFailure(a));
      } else {
         var10000 = Result.Companion;
         var18 = Result.constructor-impl(a.getSuccessfulResult$kotlinx_coroutines_core(a));
      }

      Object a = var18;
      if (a) {
         DispatchedContinuation a = (DispatchedContinuation)a;
         int a = false;
         Continuation a = a.continuation;
         Object a = a.countOrElement;
         int a = false;
         CoroutineContext a = a.getContext();
         Object a = ThreadContextKt.updateThreadContext(a, a);
         UndispatchedCoroutine a = a != ThreadContextKt.NO_THREAD_ELEMENTS ? CoroutineContextKt.updateUndispatchedCompletion(a, a, a) : (UndispatchedCoroutine)null;

         try {
            int a = false;
            a.continuation.resumeWith(a);
            Unit var17 = Unit.INSTANCE;
         } finally {
            if (a == null || a.clearThreadContext()) {
               ThreadContextKt.restoreThreadContext(a, a);
            }

         }
      } else {
         a.resumeWith(a);
      }

   }

   private static final void resumeUnconfined(DispatchedTask<?> a) {
      EventLoop a = ThreadLocalEventLoop.INSTANCE.getEventLoop$kotlinx_coroutines_core();
      if (a.isUnconfinedLoopActive()) {
         a.dispatchUnconfined(a);
      } else {
         DispatchedTask a = a;
         int a = false;
         a.incrementUseCount(true);

         try {
            int a = false;
            resume(a, a.getDelegate$kotlinx_coroutines_core(), true);

            while(a.processUnconfinedEvent()) {
            }
         } catch (Throwable var8) {
            a.handleFatalException(var8, (Throwable)null);
         } finally {
            a.decrementUseCount(true);
         }
      }

   }

   public static final void runUnconfinedEventLoop(@NotNull DispatchedTask<?> a, @NotNull EventLoop a, @NotNull Function0<Unit> a) {
      int a = false;
      a.incrementUseCount(true);

      try {
         a.invoke();

         while(a.processUnconfinedEvent()) {
         }
      } catch (Throwable var7) {
         a.handleFatalException(var7, (Throwable)null);
      } finally {
         InlineMarker.finallyStart(1);
         a.decrementUseCount(true);
         InlineMarker.finallyEnd(1);
      }

   }

   public static final void resumeWithStackTrace(@NotNull Continuation<?> a, @NotNull Throwable a) {
      int a = false;
      Result.Companion var10001 = Result.Companion;
      int a = false;
      a.resumeWith(Result.constructor-impl(ResultKt.createFailure(DebugKt.getRECOVER_STACK_TRACES() && a instanceof CoroutineStackFrame ? StackTraceRecoveryKt.access$recoverFromStackFrame(a, (CoroutineStackFrame)a) : a)));
   }
}
