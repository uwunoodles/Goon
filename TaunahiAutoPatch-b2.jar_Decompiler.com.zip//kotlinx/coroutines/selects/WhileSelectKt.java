package kotlinx.coroutines.selects;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;
import kotlinx.coroutines.ExperimentalCoroutinesApi;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001c\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a2\u0010\u0000\u001a\u00020\u00012\u001f\b\u0004\u0010\u0002\u001a\u0019\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0004\u0012\u00020\u00010\u0003¢\u0006\u0002\b\u0006H\u0087Hø\u0001\u0000¢\u0006\u0002\u0010\u0007\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\b"},
   d2 = {"whileSelect", "", "builder", "Lkotlin/Function1;", "Lkotlinx/coroutines/selects/SelectBuilder;", "", "Lkotlin/ExtensionFunctionType;", "(Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public final class WhileSelectKt {
   @ExperimentalCoroutinesApi
   @Nullable
   public static final Object whileSelect(@NotNull Function1<? super SelectBuilder<? super Boolean>, Unit> a, @NotNull Continuation<? super Unit> var1) {
      Object a;
      label49: {
         if (var1 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var1;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label49;
            }
         }

         a = new ContinuationImpl(var1) {
            Object L$0;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return WhileSelectKt.whileSelect((Function1)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var10 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      boolean a;
      boolean a;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         a = false;
         break;
      case 1:
         a = false;
         a = false;
         a = (Function1)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         if (!(Boolean)a) {
            return Unit.INSTANCE;
         }
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      Object var10000;
      do {
         a = false;
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).label = 1;
         Continuation a = (Continuation)a;
         int a = false;
         SelectBuilderImpl a = new SelectBuilderImpl(a);

         try {
            a.invoke(a);
         } catch (Throwable var11) {
            a.handleBuilderException(var11);
         }

         var10000 = a.getResult();
         if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            DebugProbesKt.probeCoroutineSuspended((Continuation)a);
         }

         if (var10000 == var10) {
            return var10;
         }
      } while((Boolean)var10000);

      return Unit.INSTANCE;
   }

   @ExperimentalCoroutinesApi
   private static final Object whileSelect$$forInline(Function1<? super SelectBuilder<? super Boolean>, Unit> a, Continuation<? super Unit> a) {
      boolean var2 = false;

      Object var10000;
      do {
         int a = false;
         InlineMarker.mark(0);
         int a = false;
         SelectBuilderImpl a = new SelectBuilderImpl(a);

         try {
            a.invoke(a);
         } catch (Throwable var8) {
            a.handleBuilderException(var8);
         }

         var10000 = a.getResult();
         if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            DebugProbesKt.probeCoroutineSuspended(a);
         }

         InlineMarker.mark(1);
      } while((Boolean)var10000);

      return Unit.INSTANCE;
   }
}
