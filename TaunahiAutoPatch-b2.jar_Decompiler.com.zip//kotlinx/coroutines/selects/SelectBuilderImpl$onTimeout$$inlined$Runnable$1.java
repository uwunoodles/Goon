package kotlinx.coroutines.selects;

import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlinx.coroutines.intrinsics.CancellableKt;

@Metadata(
   mv = {1, 6, 0},
   k = 3,
   xi = 48,
   d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u0001H\n¢\u0006\u0002\b\u0002¨\u0006\u0003"},
   d2 = {"<anonymous>", "", "run", "kotlinx/coroutines/RunnableKt$Runnable$1"}
)
public final class SelectBuilderImpl$onTimeout$$inlined$Runnable$1 implements Runnable {
   // $FF: synthetic field
   final SelectBuilderImpl this$0;
   // $FF: synthetic field
   final Function1 $block$inlined;

   public SelectBuilderImpl$onTimeout$$inlined$Runnable$1(SelectBuilderImpl var1, Function1 var2) {
      a.this$0 = var1;
      a.$block$inlined = var2;
   }

   public final void run() {
      int a = false;
      if (a.this$0.trySelect()) {
         CancellableKt.startCoroutineCancellable(a.$block$inlined, a.this$0.getCompletion());
      }

   }
}
