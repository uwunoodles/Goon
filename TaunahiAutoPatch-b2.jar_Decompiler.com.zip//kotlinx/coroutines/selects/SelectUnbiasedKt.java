package kotlinx.coroutines.selects;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u0018\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a8\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u00012\u001f\b\u0004\u0010\u0002\u001a\u0019\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00010\u0004\u0012\u0004\u0012\u00020\u00050\u0003¢\u0006\u0002\b\u0006H\u0086Hø\u0001\u0000¢\u0006\u0002\u0010\u0007\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\b"},
   d2 = {"selectUnbiased", "R", "builder", "Lkotlin/Function1;", "Lkotlinx/coroutines/selects/SelectBuilder;", "", "Lkotlin/ExtensionFunctionType;", "(Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public final class SelectUnbiasedKt {
   @Nullable
   public static final <R> Object selectUnbiased(@NotNull Function1<? super SelectBuilder<? super R>, Unit> a, @NotNull Continuation<? super R> a) {
      int a = false;
      int a = false;
      UnbiasedSelectBuilderImpl a = new UnbiasedSelectBuilderImpl(a);

      try {
         a.invoke(a);
      } catch (Throwable var7) {
         a.handleBuilderException(var7);
      }

      Object var10000 = a.initSelectResult();
      if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         DebugProbesKt.probeCoroutineSuspended(a);
      }

      return var10000;
   }

   private static final <R> Object selectUnbiased$$forInline(Function1<? super SelectBuilder<? super R>, Unit> a, Continuation<? super R> a) {
      int a = false;
      InlineMarker.mark(0);
      int a = false;
      UnbiasedSelectBuilderImpl a = new UnbiasedSelectBuilderImpl(a);

      try {
         a.invoke(a);
      } catch (Throwable var7) {
         a.handleBuilderException(var7);
      }

      Object var10000 = a.initSelectResult();
      if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         DebugProbesKt.probeCoroutineSuspended(a);
      }

      InlineMarker.mark(1);
      return var10000;
   }
}
