package kotlinx.coroutines.internal;

import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0081\b\u0018\u00002\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00020\u0001B\u0011\u0012\n\u0010\u0003\u001a\u0006\u0012\u0002\b\u00030\u0004¢\u0006\u0002\u0010\u0005J\r\u0010\u0006\u001a\u0006\u0012\u0002\b\u00030\u0004HÂ\u0003J\u0017\u0010\u0007\u001a\u00020\u00002\f\b\u0002\u0010\u0003\u001a\u0006\u0012\u0002\b\u00030\u0004HÆ\u0001J\u0013\u0010\b\u001a\u00020\t2\b\u0010\n\u001a\u0004\u0018\u00010\u000bHÖ\u0003J\t\u0010\f\u001a\u00020\rHÖ\u0001J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001R\u0012\u0010\u0003\u001a\u0006\u0012\u0002\b\u00030\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0010"},
   d2 = {"Lkotlinx/coroutines/internal/ThreadLocalKey;", "Lkotlin/coroutines/CoroutineContext$Key;", "Lkotlinx/coroutines/internal/ThreadLocalElement;", "threadLocal", "Ljava/lang/ThreadLocal;", "(Ljava/lang/ThreadLocal;)V", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "kotlinx-coroutines-core"}
)
@PublishedApi
public final class ThreadLocalKey implements CoroutineContext.Key<ThreadLocalElement<?>> {
   @NotNull
   private final ThreadLocal<?> threadLocal;

   public ThreadLocalKey(@NotNull ThreadLocal<?> a) {
      a.threadLocal = a;
   }

   private final ThreadLocal<?> component1() {
      return a.threadLocal;
   }

   @NotNull
   public final ThreadLocalKey copy(@NotNull ThreadLocal<?> a) {
      return new ThreadLocalKey(a);
   }

   // $FF: synthetic method
   public static ThreadLocalKey copy$default(ThreadLocalKey var0, ThreadLocal var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = var0.threadLocal;
      }

      return var0.copy(var1);
   }

   @NotNull
   public String toString() {
      return "ThreadLocalKey(threadLocal=" + a.threadLocal + ')';
   }

   public int hashCode() {
      return a.threadLocal.hashCode();
   }

   public boolean equals(@Nullable Object a) {
      if (a == a) {
         return true;
      } else if (!(a instanceof ThreadLocalKey)) {
         return false;
      } else {
         ThreadLocalKey var2 = (ThreadLocalKey)a;
         return Intrinsics.areEqual((Object)a.threadLocal, (Object)var2.threadLocal);
      }
   }
}
