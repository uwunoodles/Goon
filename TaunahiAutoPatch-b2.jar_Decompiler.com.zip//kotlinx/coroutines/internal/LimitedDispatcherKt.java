package kotlinx.coroutines.internal;

import kotlin.Metadata;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0002\u0010\b\n\u0000\u001a\f\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u0000¨\u0006\u0003"},
   d2 = {"checkParallelism", "", "", "kotlinx-coroutines-core"}
)
public final class LimitedDispatcherKt {
   public static final void checkParallelism(int a) {
      if (a < 1) {
         int a = false;
         String var2 = "Expected positive parallelism level, but got " + a;
         throw new IllegalArgumentException(var2.toString());
      }
   }
}
