package kotlinx.coroutines.internal;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.collections.ArraysKt;
import kotlin.jvm.JvmClassMappingKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.reflect.KClass;
import kotlinx.coroutines.CopyableThrowable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000.\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\u001a2\u0010\u0004\u001a\u0014\u0012\u0004\u0012\u00020\u0006\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0005j\u0002`\u0007\"\b\b\u0000\u0010\b*\u00020\u00062\f\u0010\t\u001a\b\u0012\u0004\u0012\u0002H\b0\nH\u0002\u001a*\u0010\u000b\u001a\u0018\u0012\u0004\u0012\u00020\u0006\u0012\u0006\u0012\u0004\u0018\u00010\u0006\u0018\u00010\u0005j\u0004\u0018\u0001`\u00072\n\u0010\f\u001a\u0006\u0012\u0002\b\u00030\rH\u0002\u001a1\u0010\u000e\u001a\u0014\u0012\u0004\u0012\u00020\u0006\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0005j\u0002`\u00072\u0014\b\u0004\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060\u0005H\u0082\b\u001a!\u0010\u0010\u001a\u0004\u0018\u0001H\b\"\b\b\u0000\u0010\b*\u00020\u00062\u0006\u0010\u0011\u001a\u0002H\bH\u0000¢\u0006\u0002\u0010\u0012\u001a\u001b\u0010\u0013\u001a\u00020\u0003*\u0006\u0012\u0002\b\u00030\n2\b\b\u0002\u0010\u0014\u001a\u00020\u0003H\u0082\u0010\u001a\u0018\u0010\u0015\u001a\u00020\u0003*\u0006\u0012\u0002\b\u00030\n2\u0006\u0010\u0016\u001a\u00020\u0003H\u0002\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000*(\b\u0002\u0010\u0017\"\u0010\u0012\u0004\u0012\u00020\u0006\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u00052\u0010\u0012\u0004\u0012\u00020\u0006\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0005¨\u0006\u0018"},
   d2 = {"ctorCache", "Lkotlinx/coroutines/internal/CtorCache;", "throwableFields", "", "createConstructor", "Lkotlin/Function1;", "", "Lkotlinx/coroutines/internal/Ctor;", "E", "clz", "Ljava/lang/Class;", "createSafeConstructor", "constructor", "Ljava/lang/reflect/Constructor;", "safeCtor", "block", "tryCopyException", "exception", "(Ljava/lang/Throwable;)Ljava/lang/Throwable;", "fieldsCount", "accumulator", "fieldsCountOrDefault", "defaultValue", "Ctor", "kotlinx-coroutines-core"}
)
public final class ExceptionsConstructorKt {
   private static final int throwableFields = fieldsCountOrDefault(Throwable.class, -1);
   @NotNull
   private static final CtorCache ctorCache;

   @Nullable
   public static final <E extends Throwable> E tryCopyException(@NotNull E a) {
      if (a instanceof CopyableThrowable) {
         Result.Companion var10000;
         Object var1;
         try {
            var10000 = Result.Companion;
            int a = false;
            var1 = Result.constructor-impl(((CopyableThrowable)a).createCopy());
         } catch (Throwable var3) {
            var10000 = Result.Companion;
            var1 = Result.constructor-impl(ResultKt.createFailure(var3));
         }

         return (Throwable)(Result.isFailure-impl(var1) ? null : var1);
      } else {
         return (Throwable)ctorCache.get(a.getClass()).invoke(a);
      }
   }

   private static final <E extends Throwable> Function1<Throwable, Throwable> createConstructor(Class<E> a) {
      Function1 a = (Function1)null.INSTANCE;
      if (throwableFields != fieldsCountOrDefault(a, 0)) {
         return a;
      } else {
         Object[] a = a.getConstructors();
         int a = false;
         List a = ArraysKt.sortedWith(a, (Comparator)(new ExceptionsConstructorKt$createConstructor$$inlined$sortedByDescending$1()));
         Iterator var6 = a.iterator();

         Function1 a;
         do {
            if (!var6.hasNext()) {
               return a;
            }

            Constructor a = (Constructor)var6.next();
            a = createSafeConstructor(a);
         } while(a == null);

         return a;
      }
   }

   private static final Function1<Throwable, Throwable> createSafeConstructor(Constructor<?> a) {
      Class[] a = a.getParameterTypes();
      Function1 var10000;
      boolean a;
      switch(a.length) {
      case 0:
         a = false;
         var10000 = (Function1)(new ExceptionsConstructorKt$createSafeConstructor$$inlined$safeCtor$4(a));
         break;
      case 1:
         Class var4 = a[0];
         boolean a;
         if (Intrinsics.areEqual((Object)var4, (Object)Throwable.class)) {
            a = false;
            var10000 = (Function1)(new ExceptionsConstructorKt$createSafeConstructor$$inlined$safeCtor$2(a));
         } else if (Intrinsics.areEqual((Object)var4, (Object)String.class)) {
            a = false;
            var10000 = (Function1)(new ExceptionsConstructorKt$createSafeConstructor$$inlined$safeCtor$3(a));
         } else {
            var10000 = null;
         }
         break;
      case 2:
         if (Intrinsics.areEqual((Object)a[0], (Object)String.class) && Intrinsics.areEqual((Object)a[1], (Object)Throwable.class)) {
            a = false;
            var10000 = (Function1)(new ExceptionsConstructorKt$createSafeConstructor$$inlined$safeCtor$1(a));
         } else {
            var10000 = null;
         }
         break;
      default:
         var10000 = null;
      }

      return var10000;
   }

   private static final Function1<Throwable, Throwable> safeCtor(final Function1<? super Throwable, ? extends Throwable> a) {
      int a = false;
      return (Function1)(new Function1<Throwable, Throwable>() {
         @Nullable
         public final Throwable invoke(@NotNull Throwable axxx) {
            Function1 var2 = a;

            Result.Companion var10000;
            Object var3;
            try {
               var10000 = Result.Companion;
               int axx = false;
               var3 = Result.constructor-impl((Throwable)var2.invoke(axxx));
            } catch (Throwable var5) {
               var10000 = Result.Companion;
               var3 = Result.constructor-impl(ResultKt.createFailure(var5));
            }

            return (Throwable)(Result.isFailure-impl(var3) ? null : var3);
         }
      });
   }

   private static final int fieldsCountOrDefault(Class<?> a, int a) {
      KClass var2 = JvmClassMappingKt.getKotlinClass(a);

      Result.Companion var10000;
      Object var3;
      try {
         var10000 = Result.Companion;
         int a = false;
         var3 = Result.constructor-impl(fieldsCount$default(a, 0, 1, (Object)null));
      } catch (Throwable var5) {
         var10000 = Result.Companion;
         var3 = Result.constructor-impl(ResultKt.createFailure(var5));
      }

      Object var6 = var3;
      Integer var7 = a;
      return ((Number)(Result.isFailure-impl(var6) ? var7 : var6)).intValue();
   }

   private static final int fieldsCount(Class<?> a, int a) {
      Class var2 = a;
      int var3 = a;

      while(true) {
         Object[] a = var2.getDeclaredFields();
         int a = false;
         int a = 0;
         int var10 = 0;

         for(int var11 = a.length; var10 < var11; ++var10) {
            Object a = a[var10];
            int a = false;
            if (!Modifier.isStatic(a.getModifiers())) {
               ++a;
            }
         }

         int a = var3 + a;
         Class var10000 = var2.getSuperclass();
         if (var10000 == null) {
            return a;
         }

         Class a = var10000;
         var2 = a;
         var3 = a;
      }
   }

   // $FF: synthetic method
   static int fieldsCount$default(Class var0, int var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = 0;
      }

      return fieldsCount(var0, var1);
   }

   // $FF: synthetic method
   public static final Function1 access$createConstructor(Class a) {
      return createConstructor(a);
   }

   static {
      CtorCache var0;
      try {
         var0 = FastServiceLoaderKt.getANDROID_DETECTED() ? (CtorCache)WeakMapCtorCache.INSTANCE : (CtorCache)ClassValueCtorCache.INSTANCE;
      } catch (Throwable var2) {
         var0 = (CtorCache)WeakMapCtorCache.INSTANCE;
      }

      ctorCache = var0;
   }
}
