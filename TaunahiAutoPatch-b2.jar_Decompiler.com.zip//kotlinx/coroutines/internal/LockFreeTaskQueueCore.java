package kotlinx.coroutines.internal;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlinx.coroutines.DebugKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0016\b\u0000\u0018\u0000 /*\b\b\u0000\u0010\u0002*\u00020\u00012\u00020\u0001:\u0002/0B\u0017\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u0015\u0010\n\u001a\u00020\u00032\u0006\u0010\t\u001a\u00028\u0000¢\u0006\u0004\b\n\u0010\u000bJ'\u0010\u000f\u001a\u0012\u0012\u0004\u0012\u00028\u00000\u0000j\b\u0012\u0004\u0012\u00028\u0000`\u000e2\u0006\u0010\r\u001a\u00020\fH\u0002¢\u0006\u0004\b\u000f\u0010\u0010J'\u0010\u0011\u001a\u0012\u0012\u0004\u0012\u00028\u00000\u0000j\b\u0012\u0004\u0012\u00028\u0000`\u000e2\u0006\u0010\r\u001a\u00020\fH\u0002¢\u0006\u0004\b\u0011\u0010\u0010J\r\u0010\u0012\u001a\u00020\u0005¢\u0006\u0004\b\u0012\u0010\u0013J3\u0010\u0015\u001a\u0016\u0012\u0004\u0012\u00028\u0000\u0018\u00010\u0000j\n\u0012\u0004\u0012\u00028\u0000\u0018\u0001`\u000e2\u0006\u0010\u0014\u001a\u00020\u00032\u0006\u0010\t\u001a\u00028\u0000H\u0002¢\u0006\u0004\b\u0015\u0010\u0016J\r\u0010\u0017\u001a\u00020\u0005¢\u0006\u0004\b\u0017\u0010\u0013J-\u0010\u001c\u001a\b\u0012\u0004\u0012\u00028\u00010\u001b\"\u0004\b\u0001\u0010\u00182\u0012\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010\u0019¢\u0006\u0004\b\u001c\u0010\u001dJ\u000f\u0010\u001e\u001a\u00020\fH\u0002¢\u0006\u0004\b\u001e\u0010\u001fJ\u0013\u0010 \u001a\b\u0012\u0004\u0012\u00028\u00000\u0000¢\u0006\u0004\b \u0010!J\u000f\u0010\"\u001a\u0004\u0018\u00010\u0001¢\u0006\u0004\b\"\u0010#J3\u0010&\u001a\u0016\u0012\u0004\u0012\u00028\u0000\u0018\u00010\u0000j\n\u0012\u0004\u0012\u00028\u0000\u0018\u0001`\u000e2\u0006\u0010$\u001a\u00020\u00032\u0006\u0010%\u001a\u00020\u0003H\u0002¢\u0006\u0004\b&\u0010'R\u0014\u0010\u0004\u001a\u00020\u00038\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0004\u0010(R\u0011\u0010)\u001a\u00020\u00058F¢\u0006\u0006\u001a\u0004\b)\u0010\u0013R\u0014\u0010*\u001a\u00020\u00038\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b*\u0010(R\u0014\u0010\u0006\u001a\u00020\u00058\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0006\u0010+R\u0011\u0010.\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\b,\u0010-¨\u00061"},
   d2 = {"Lkotlinx/coroutines/internal/LockFreeTaskQueueCore;", "", "E", "", "capacity", "", "singleConsumer", "LockFreeTaskQueueCore", "(IZ)V", "element", "addLast", "(Ljava/lang/Object;)I", "", "state", "Lkotlinx/coroutines/internal/Core;", "allocateNextCopy", "(J)Lkotlinx/coroutines/internal/LockFreeTaskQueueCore;", "allocateOrGetNextCopy", "close", "()Z", "index", "fillPlaceholder", "(ILjava/lang/Object;)Lkotlinx/coroutines/internal/LockFreeTaskQueueCore;", "isClosed", "R", "Lkotlin/Function1;", "transform", "", "map", "(Lkotlin/jvm/functions/Function1;)Ljava/util/List;", "markFrozen", "()J", "next", "()Lkotlinx/coroutines/internal/LockFreeTaskQueueCore;", "removeFirstOrNull", "()Ljava/lang/Object;", "oldHead", "newHead", "removeSlowPath", "(II)Lkotlinx/coroutines/internal/LockFreeTaskQueueCore;", "I", "isEmpty", "mask", "Z", "getSize", "()I", "size", "Companion", "Placeholder", "kotlinx-coroutines-core"}
)
public final class LockFreeTaskQueueCore<E> {
   @NotNull
   public static final LockFreeTaskQueueCore.Companion Companion = new LockFreeTaskQueueCore.Companion((DefaultConstructorMarker)null);
   private final int capacity;
   private final boolean singleConsumer;
   private final int mask;
   // $FF: synthetic field
   @NotNull
   private volatile Object _next;
   // $FF: synthetic field
   private static final AtomicReferenceFieldUpdater _next$FU = AtomicReferenceFieldUpdater.newUpdater(LockFreeTaskQueueCore.class, Object.class, "_next");
   // $FF: synthetic field
   @NotNull
   private volatile long _state;
   // $FF: synthetic field
   private static final AtomicLongFieldUpdater _state$FU = AtomicLongFieldUpdater.newUpdater(LockFreeTaskQueueCore.class, "_state");
   // $FF: synthetic field
   @NotNull
   private AtomicReferenceArray array;
   public static final int INITIAL_CAPACITY = 8;
   public static final int CAPACITY_BITS = 30;
   public static final int MAX_CAPACITY_MASK = 1073741823;
   public static final int HEAD_SHIFT = 0;
   public static final long HEAD_MASK = 1073741823L;
   public static final int TAIL_SHIFT = 30;
   public static final long TAIL_MASK = 1152921503533105152L;
   public static final int FROZEN_SHIFT = 60;
   public static final long FROZEN_MASK = 1152921504606846976L;
   public static final int CLOSED_SHIFT = 61;
   public static final long CLOSED_MASK = 2305843009213693952L;
   public static final int MIN_ADD_SPIN_CAPACITY = 1024;
   @JvmField
   @NotNull
   public static final Symbol REMOVE_FROZEN = new Symbol("REMOVE_FROZEN");
   public static final int ADD_SUCCESS = 0;
   public static final int ADD_FROZEN = 1;
   public static final int ADD_CLOSED = 2;

   public LockFreeTaskQueueCore(int a, boolean a) {
      a.capacity = a;
      a.singleConsumer = a;
      a.mask = a.capacity - 1;
      a._next = null;
      a._state = 0L;
      a.array = new AtomicReferenceArray(a.capacity);
      String var3;
      if (a.mask > 1073741823) {
         var3 = "Check failed.";
         throw new IllegalStateException(var3.toString());
      } else if ((a.capacity & a.mask) != 0) {
         var3 = "Check failed.";
         throw new IllegalStateException(var3.toString());
      }
   }

   public final boolean isEmpty() {
      LockFreeTaskQueueCore.Companion var1 = Companion;
      long a = a._state;
      int a = false;
      int a = (int)((a & 1073741823L) >> 0);
      int a = (int)((a & 1152921503533105152L) >> 30);
      int a = false;
      return a == a;
   }

   public final int getSize() {
      LockFreeTaskQueueCore.Companion var1 = Companion;
      long a = a._state;
      int a = false;
      int a = (int)((a & 1073741823L) >> 0);
      int a = (int)((a & 1152921503533105152L) >> 30);
      int a = false;
      return a - a & 1073741823;
   }

   public final boolean close() {
      LockFreeTaskQueueCore a = a;
      boolean var2 = false;

      long a;
      long a;
      do {
         a = a._state;
         int a = false;
         if ((a & 2305843009213693952L) != 0L) {
            return true;
         }

         if ((a & 1152921504606846976L) != 0L) {
            return false;
         }

         a = a | 2305843009213693952L;
      } while(!_state$FU.compareAndSet(a, a, a));

      return true;
   }

   public final int addLast(@NotNull E a) {
      LockFreeTaskQueueCore a = a;
      boolean var3 = false;

      while(true) {
         long a = a._state;
         int a = false;
         if ((a & 3458764513820540928L) != 0L) {
            return Companion.addFailReason(a);
         }

         LockFreeTaskQueueCore.Companion var7 = Companion;
         int a = false;
         int a = (int)((a & 1073741823L) >> 0);
         int a = (int)((a & 1152921503533105152L) >> 30);
         int a = a;
         int a = false;
         int a = a.mask;
         if ((a + 2 & a) == (a & a)) {
            return 1;
         }

         if (!a.singleConsumer && a.array.get(a & a) != null) {
            if (a.capacity < 1024 || (a - a & 1073741823) > a.capacity >> 1) {
               return 1;
            }
         } else {
            int a = a + 1 & 1073741823;
            if (_state$FU.compareAndSet(a, a, Companion.updateTail(a, a))) {
               a.array.set(a & a, a);

               LockFreeTaskQueueCore var10000;
               for(LockFreeTaskQueueCore a = a; (a._state & 1152921504606846976L) != 0L; a = var10000) {
                  var10000 = a.next().fillPlaceholder(a, a);
                  if (var10000 == null) {
                     break;
                  }
               }

               return 0;
            }
         }
      }
   }

   private final LockFreeTaskQueueCore<E> fillPlaceholder(int a, E a) {
      Object a = a.array.get(a & a.mask);
      if (a instanceof LockFreeTaskQueueCore.Placeholder && ((LockFreeTaskQueueCore.Placeholder)a).index == a) {
         a.array.set(a & a.mask, a);
         return a;
      } else {
         return null;
      }
   }

   @Nullable
   public final Object removeFirstOrNull() {
      LockFreeTaskQueueCore a = a;
      boolean var2 = false;

      while(true) {
         long a = a._state;
         int a = false;
         if ((a & 1152921504606846976L) != 0L) {
            return REMOVE_FROZEN;
         }

         LockFreeTaskQueueCore.Companion var6 = Companion;
         int a = false;
         int a = (int)((a & 1073741823L) >> 0);
         int a = (int)((a & 1152921503533105152L) >> 30);
         int a = a;
         int a = false;
         if ((a & a.mask) == (a & a.mask)) {
            return null;
         }

         Object a = a.array.get(a & a.mask);
         if (a == null) {
            if (a.singleConsumer) {
               return null;
            }
         } else {
            if (a instanceof LockFreeTaskQueueCore.Placeholder) {
               return null;
            }

            int a = a + 1 & 1073741823;
            if (_state$FU.compareAndSet(a, a, Companion.updateHead(a, a))) {
               a.array.set(a & a.mask, (Object)null);
               return a;
            }

            if (a.singleConsumer) {
               LockFreeTaskQueueCore a = a;

               while(true) {
                  LockFreeTaskQueueCore var10000 = a.removeSlowPath(a, a);
                  if (var10000 == null) {
                     return a;
                  }

                  a = var10000;
               }
            }
         }
      }
   }

   private final LockFreeTaskQueueCore<E> removeSlowPath(int a, int a) {
      LockFreeTaskQueueCore a = a;
      boolean var4 = false;

      long a;
      int a;
      do {
         a = a._state;
         int a = false;
         LockFreeTaskQueueCore.Companion var8 = Companion;
         int a = false;
         a = (int)((a & 1073741823L) >> 0);
         int a = (int)((a & 1152921503533105152L) >> 30);
         int a = false;
         if (DebugKt.getASSERTIONS_ENABLED()) {
            int a = false;
            if (a != a) {
               throw new AssertionError();
            }
         }

         if ((a & 1152921504606846976L) != 0L) {
            return a.next();
         }
      } while(!_state$FU.compareAndSet(a, a, Companion.updateHead(a, a)));

      a.array.set(a & a.mask, (Object)null);
      return null;
   }

   @NotNull
   public final LockFreeTaskQueueCore<E> next() {
      return a.allocateOrGetNextCopy(a.markFrozen());
   }

   private final long markFrozen() {
      LockFreeTaskQueueCore a = a;
      boolean var2 = false;

      long a;
      long a;
      do {
         a = a._state;
         int a = false;
         if ((a & 1152921504606846976L) != 0L) {
            return a;
         }

         a = a | 1152921504606846976L;
      } while(!_state$FU.compareAndSet(a, a, a));

      return a;
   }

   private final LockFreeTaskQueueCore<E> allocateOrGetNextCopy(long a) {
      LockFreeTaskQueueCore a = a;
      boolean var4 = false;

      while(true) {
         LockFreeTaskQueueCore a = (LockFreeTaskQueueCore)a._next;
         int a = false;
         if (a != null) {
            return a;
         }

         _next$FU.compareAndSet(a, (Object)null, a.allocateNextCopy(a));
      }
   }

   private final LockFreeTaskQueueCore<E> allocateNextCopy(long a) {
      LockFreeTaskQueueCore a = new LockFreeTaskQueueCore(a.capacity * 2, a.singleConsumer);
      LockFreeTaskQueueCore.Companion var4 = Companion;
      int a = false;
      int a = (int)((a & 1073741823L) >> 0);
      int a = (int)((a & 1152921503533105152L) >> 30);
      int a = a;
      int a = false;

      for(int a = a; (a & a.mask) != (a & a.mask); ++a) {
         Object var10000 = a.array.get(a & a.mask);
         if (var10000 == null) {
            var10000 = new LockFreeTaskQueueCore.Placeholder(a);
         }

         Object a = var10000;
         a.array.set(a & a.mask, a);
      }

      a._state = Companion.wo(a, 1152921504606846976L);
      return a;
   }

   @NotNull
   public final <R> List<R> map(@NotNull Function1<? super E, ? extends R> a) {
      ArrayList a = new ArrayList(a.capacity);
      LockFreeTaskQueueCore.Companion var3 = Companion;
      long a = a._state;
      int a = false;
      int a = (int)((a & 1073741823L) >> 0);
      int a = (int)((a & 1152921503533105152L) >> 30);
      int a = a;
      int a = false;

      for(int a = a; (a & a.mask) != (a & a.mask); ++a) {
         Object a = a.array.get(a & a.mask);
         if (a != null && !(a instanceof LockFreeTaskQueueCore.Placeholder)) {
            a.add(a.invoke(a));
         }
      }

      return (List)a;
   }

   public final boolean isClosed() {
      return (a._state & 2305843009213693952L) != 0L;
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0010\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\u0005"},
      d2 = {"Lkotlinx/coroutines/internal/LockFreeTaskQueueCore$Placeholder;", "", "index", "", "(I)V", "kotlinx-coroutines-core"}
   )
   public static final class Placeholder {
      @JvmField
      public final int index;

      public Placeholder(int a) {
         a.index = a;
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0080\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\n\u0010\u0016\u001a\u00020\u0004*\u00020\tJ\u0012\u0010\u0017\u001a\u00020\t*\u00020\t2\u0006\u0010\u0018\u001a\u00020\u0004J\u0012\u0010\u0019\u001a\u00020\t*\u00020\t2\u0006\u0010\u001a\u001a\u00020\u0004JP\u0010\u001b\u001a\u0002H\u001c\"\u0004\b\u0001\u0010\u001c*\u00020\t26\u0010\u001d\u001a2\u0012\u0013\u0012\u00110\u0004¢\u0006\f\b\u001f\u0012\b\b \u0012\u0004\b\b(!\u0012\u0013\u0012\u00110\u0004¢\u0006\f\b\u001f\u0012\b\b \u0012\u0004\b\b(\"\u0012\u0004\u0012\u0002H\u001c0\u001eH\u0086\b¢\u0006\u0002\u0010#J\u0015\u0010$\u001a\u00020\t*\u00020\t2\u0006\u0010%\u001a\u00020\tH\u0086\u0004R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u00020\u00138\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006&"},
      d2 = {"Lkotlinx/coroutines/internal/LockFreeTaskQueueCore$Companion;", "", "()V", "ADD_CLOSED", "", "ADD_FROZEN", "ADD_SUCCESS", "CAPACITY_BITS", "CLOSED_MASK", "", "CLOSED_SHIFT", "FROZEN_MASK", "FROZEN_SHIFT", "HEAD_MASK", "HEAD_SHIFT", "INITIAL_CAPACITY", "MAX_CAPACITY_MASK", "MIN_ADD_SPIN_CAPACITY", "REMOVE_FROZEN", "Lkotlinx/coroutines/internal/Symbol;", "TAIL_MASK", "TAIL_SHIFT", "addFailReason", "updateHead", "newHead", "updateTail", "newTail", "withState", "T", "block", "Lkotlin/Function2;", "Lkotlin/ParameterName;", "name", "head", "tail", "(JLkotlin/jvm/functions/Function2;)Ljava/lang/Object;", "wo", "other", "kotlinx-coroutines-core"}
   )
   public static final class Companion {
      private Companion() {
      }

      public final long wo(long a, long a) {
         return a & ~a;
      }

      public final long updateHead(long a, int a) {
         return a.wo(a, 1073741823L) | (long)a << 0;
      }

      public final long updateTail(long a, int a) {
         return a.wo(a, 1152921503533105152L) | (long)a << 30;
      }

      public final <T> T withState(long a, @NotNull Function2<? super Integer, ? super Integer, ? extends T> a) {
         int a = false;
         int a = (int)((a & 1073741823L) >> 0);
         int a = (int)((a & 1152921503533105152L) >> 30);
         return a.invoke(a, a);
      }

      public final int addFailReason(long a) {
         return (a & 2305843009213693952L) != 0L ? 2 : 1;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker a1) {
         this();
      }
   }
}
