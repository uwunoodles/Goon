package kotlinx.coroutines.internal;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ServiceLoader;
import java.util.Set;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import kotlin.ExceptionsKt;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.io.CloseableKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\bÀ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J!\u0010\u0005\u001a\u0004\u0018\u00010\u00062\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\b2\u0006\u0010\t\u001a\u00020\u0004H\u0082\bJ1\u0010\n\u001a\u0002H\u000b\"\u0004\b\u0000\u0010\u000b2\u0006\u0010\f\u001a\u00020\u00042\u0006\u0010\r\u001a\u00020\u000e2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u0002H\u000b0\bH\u0002¢\u0006\u0002\u0010\u0010J*\u0010\u0011\u001a\b\u0012\u0004\u0012\u0002H\u000b0\u0012\"\u0004\b\u0000\u0010\u000b2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u0002H\u000b0\b2\u0006\u0010\r\u001a\u00020\u000eH\u0002J\u0013\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00060\u0012H\u0000¢\u0006\u0002\b\u0014J/\u0010\u0015\u001a\b\u0012\u0004\u0012\u0002H\u000b0\u0012\"\u0004\b\u0000\u0010\u000b2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u0002H\u000b0\b2\u0006\u0010\r\u001a\u00020\u000eH\u0000¢\u0006\u0002\b\u0016J\u0016\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00040\u00122\u0006\u0010\u0018\u001a\u00020\u0019H\u0002J\u0016\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00040\u00122\u0006\u0010\u001b\u001a\u00020\u001cH\u0002J,\u0010\u001d\u001a\u0002H\u001e\"\u0004\b\u0000\u0010\u001e*\u00020\u001f2\u0012\u0010 \u001a\u000e\u0012\u0004\u0012\u00020\u001f\u0012\u0004\u0012\u0002H\u001e0!H\u0082\b¢\u0006\u0002\u0010\"R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006#"},
   d2 = {"Lkotlinx/coroutines/internal/FastServiceLoader;", "", "()V", "PREFIX", "", "createInstanceOf", "Lkotlinx/coroutines/internal/MainDispatcherFactory;", "baseClass", "Ljava/lang/Class;", "serviceClass", "getProviderInstance", "S", "name", "loader", "Ljava/lang/ClassLoader;", "service", "(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/Class;)Ljava/lang/Object;", "load", "", "loadMainDispatcherFactory", "loadMainDispatcherFactory$kotlinx_coroutines_core", "loadProviders", "loadProviders$kotlinx_coroutines_core", "parse", "url", "Ljava/net/URL;", "parseFile", "r", "Ljava/io/BufferedReader;", "use", "R", "Ljava/util/jar/JarFile;", "block", "Lkotlin/Function1;", "(Ljava/util/jar/JarFile;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public final class FastServiceLoader {
   @NotNull
   public static final FastServiceLoader INSTANCE = new FastServiceLoader();
   @NotNull
   private static final String PREFIX = "META-INF/services/";

   private FastServiceLoader() {
   }

   @NotNull
   public final List<MainDispatcherFactory> loadMainDispatcherFactory$kotlinx_coroutines_core() {
      Class a = MainDispatcherFactory.class;
      if (!FastServiceLoaderKt.getANDROID_DETECTED()) {
         return a.load(a, a.getClassLoader());
      } else {
         List var2;
         try {
            ArrayList a = new ArrayList(2);
            String a = "kotlinx.coroutines.android.AndroidDispatcherFactory";
            boolean a = false;

            MainDispatcherFactory var7;
            Class a;
            try {
               a = Class.forName(a, true, a.getClassLoader());
               var7 = (MainDispatcherFactory)a.cast(a.getDeclaredConstructor().newInstance());
            } catch (ClassNotFoundException var10) {
               var7 = (MainDispatcherFactory)null;
            }

            if (var7 != null) {
               a = false;
               a.add(var7);
            }

            a = "kotlinx.coroutines.test.internal.TestMainDispatcherFactory";
            a = false;

            try {
               a = Class.forName(a, true, a.getClassLoader());
               var7 = (MainDispatcherFactory)a.cast(a.getDeclaredConstructor().newInstance());
            } catch (ClassNotFoundException var9) {
               var7 = (MainDispatcherFactory)null;
            }

            if (var7 != null) {
               a = false;
               a.add(var7);
            }

            var2 = (List)a;
         } catch (Throwable var11) {
            var2 = a.load(a, a.getClassLoader());
         }

         return var2;
      }
   }

   private final MainDispatcherFactory createInstanceOf(Class<MainDispatcherFactory> a, String a) {
      boolean var3 = false;

      MainDispatcherFactory var4;
      try {
         Class a = Class.forName(a, true, a.getClassLoader());
         var4 = (MainDispatcherFactory)a.cast(a.getDeclaredConstructor().newInstance());
      } catch (ClassNotFoundException var6) {
         var4 = (MainDispatcherFactory)null;
      }

      return var4;
   }

   private final <S> List<S> load(Class<S> a, ClassLoader a) {
      List var3;
      try {
         var3 = a.loadProviders$kotlinx_coroutines_core(a, a);
      } catch (Throwable var5) {
         var3 = CollectionsKt.toList((Iterable)ServiceLoader.load(a, a));
      }

      return var3;
   }

   @NotNull
   public final <S> List<S> loadProviders$kotlinx_coroutines_core(@NotNull Class<S> a, @NotNull ClassLoader a) {
      String a = "META-INF/services/" + a.getName();
      Enumeration a = a.getResources(a);
      ArrayList var10000 = Collections.list(a);
      Intrinsics.checkNotNullExpressionValue(var10000, "list(this)");
      Iterable a = (Iterable)((List)var10000);
      int a = false;
      Collection a = (Collection)(new ArrayList());
      int a = false;
      Iterator var11 = a.iterator();

      Object a;
      boolean a;
      while(var11.hasNext()) {
         a = var11.next();
         URL a = (URL)a;
         a = false;
         Iterable a = (Iterable)INSTANCE.parse(a);
         CollectionsKt.addAll(a, a);
      }

      Set a = CollectionsKt.toSet((Iterable)((List)a));
      if (((Collection)a).isEmpty()) {
         a = false;
         String var16 = "No providers were loaded with FastServiceLoader";
         throw new IllegalArgumentException(var16.toString());
      } else {
         a = (Iterable)a;
         a = false;
         a = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(a, 10)));
         a = false;
         var11 = a.iterator();

         while(var11.hasNext()) {
            a = var11.next();
            String a = (String)a;
            a = false;
            a.add(INSTANCE.getProviderInstance(a, a, a));
         }

         return (List)a;
      }
   }

   private final <S> S getProviderInstance(String a, ClassLoader a, Class<S> a) {
      Class a = Class.forName(a, false, a);
      if (!a.isAssignableFrom(a)) {
         int a = false;
         String var6 = "Expected service of class " + a + ", but found " + a;
         throw new IllegalArgumentException(var6.toString());
      } else {
         return a.cast(a.getDeclaredConstructor().newInstance());
      }
   }

   private final List<String> parse(URL a) {
      String a = a.toString();
      if (StringsKt.startsWith$default(a, "jar", false, 2, (Object)null)) {
         String a = StringsKt.substringBefore$default(StringsKt.substringAfter$default(a, "jar:file:", (String)null, 2, (Object)null), '!', (String)null, 2, (Object)null);
         String a = StringsKt.substringAfter$default(a, "!/", (String)null, 2, (Object)null);
         JarFile a = new JarFile(a, false);
         int a = false;
         Throwable a = null;
         boolean var33 = false;

         List var16;
         try {
            var33 = true;
            int a = false;
            Closeable var11 = (Closeable)(new BufferedReader((Reader)(new InputStreamReader(a.getInputStream(new ZipEntry(a)), "UTF-8"))));
            Throwable var12 = null;

            List var15;
            try {
               BufferedReader a = (BufferedReader)var11;
               int a = false;
               var15 = INSTANCE.parseFile(a);
            } catch (Throwable var43) {
               var12 = var43;
               throw var43;
            } finally {
               CloseableKt.closeFinally(var11, var12);
            }

            var16 = var15;
            var33 = false;
         } catch (Throwable var45) {
            a = var45;
            throw var45;
         } finally {
            if (var33) {
               try {
                  a.close();
               } catch (Throwable var48) {
                  if (a == null) {
                     throw var48;
                  }

                  ExceptionsKt.addSuppressed(a, var48);
                  throw a;
               }
            }
         }

         try {
            a.close();
            return var16;
         } catch (Throwable var42) {
            throw var42;
         }
      } else {
         Closeable var3 = (Closeable)(new BufferedReader((Reader)(new InputStreamReader(a.openStream()))));
         Throwable var4 = null;

         List var52;
         try {
            BufferedReader a = (BufferedReader)var3;
            int a = false;
            var52 = INSTANCE.parseFile(a);
         } catch (Throwable var46) {
            var4 = var46;
            throw var46;
         } finally {
            CloseableKt.closeFinally(var3, var4);
         }

         return var52;
      }
   }

   private final <R> R use(JarFile a, Function1<? super JarFile, ? extends R> a) {
      int a = false;
      Throwable a = null;
      boolean var11 = false;

      Object var5;
      try {
         var11 = true;
         var5 = a.invoke(a);
         var11 = false;
      } catch (Throwable var13) {
         a = var13;
         throw var13;
      } finally {
         if (var11) {
            InlineMarker.finallyStart(1);

            try {
               a.close();
            } catch (Throwable var14) {
               if (a == null) {
                  throw var14;
               }

               ExceptionsKt.addSuppressed(a, var14);
               throw a;
            }

            InlineMarker.finallyEnd(1);
         }
      }

      InlineMarker.finallyStart(1);

      try {
         a.close();
      } catch (Throwable var12) {
         throw var12;
      }

      InlineMarker.finallyEnd(1);
      return var5;
   }

   private final List<String> parseFile(BufferedReader a) {
      Set a = (Set)(new LinkedHashSet());

      while(true) {
         String var10000 = a.readLine();
         if (var10000 == null) {
            return CollectionsKt.toList((Iterable)a);
         }

         String a = var10000;
         String a = StringsKt.trim((CharSequence)StringsKt.substringBefore$default(a, "#", (String)null, 2, (Object)null)).toString();
         CharSequence a = (CharSequence)a;
         int a = false;
         int var7 = 0;

         boolean var12;
         while(true) {
            if (var7 >= a.length()) {
               var12 = true;
               break;
            }

            char a = a.charAt(var7);
            int a = false;
            if (a != '.' && !Character.isJavaIdentifierPart(a)) {
               var12 = false;
               break;
            }

            ++var7;
         }

         if (!var12) {
            a = false;
            String var11 = "Illegal service provider class name: " + a;
            throw new IllegalArgumentException(var11.toString());
         }

         if (((CharSequence)a).length() > 0) {
            a.add(a);
         }
      }
   }
}
