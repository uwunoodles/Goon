package kotlinx.coroutines.internal;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.PropertyReference0Impl;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.DebugStringsKt;
import kotlinx.coroutines.InternalCoroutinesApi;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u0000\n\u0002\b\f\b\u0017\u0018\u00002\u00020C:\u0005JKLMNB\u0007¢\u0006\u0004\b\u0001\u0010\u0002J\u0019\u0010\u0006\u001a\u00020\u00052\n\u0010\u0004\u001a\u00060\u0000j\u0002`\u0003¢\u0006\u0004\b\u0006\u0010\u0007J,\u0010\u000b\u001a\u00020\t2\n\u0010\u0004\u001a\u00060\u0000j\u0002`\u00032\u000e\b\u0004\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\bH\u0086\b¢\u0006\u0004\b\u000b\u0010\fJ4\u0010\u000f\u001a\u00020\t2\n\u0010\u0004\u001a\u00060\u0000j\u0002`\u00032\u0016\u0010\u000e\u001a\u0012\u0012\b\u0012\u00060\u0000j\u0002`\u0003\u0012\u0004\u0012\u00020\t0\rH\u0086\b¢\u0006\u0004\b\u000f\u0010\u0010JD\u0010\u0011\u001a\u00020\t2\n\u0010\u0004\u001a\u00060\u0000j\u0002`\u00032\u0016\u0010\u000e\u001a\u0012\u0012\b\u0012\u00060\u0000j\u0002`\u0003\u0012\u0004\u0012\u00020\t0\r2\u000e\b\u0004\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\bH\u0086\b¢\u0006\u0004\b\u0011\u0010\u0012J'\u0010\u0014\u001a\u00020\t2\n\u0010\u0004\u001a\u00060\u0000j\u0002`\u00032\n\u0010\u0013\u001a\u00060\u0000j\u0002`\u0003H\u0001¢\u0006\u0004\b\u0014\u0010\u0015J\u0019\u0010\u0016\u001a\u00020\t2\n\u0010\u0004\u001a\u00060\u0000j\u0002`\u0003¢\u0006\u0004\b\u0016\u0010\u0017J\"\u0010\u001a\u001a\n\u0018\u00010\u0000j\u0004\u0018\u0001`\u00032\b\u0010\u0019\u001a\u0004\u0018\u00010\u0018H\u0082\u0010¢\u0006\u0004\b\u001a\u0010\u001bJ)\u0010\u001e\u001a\b\u0012\u0004\u0012\u00028\u00000\u001d\"\f\b\u0000\u0010\u001c*\u00060\u0000j\u0002`\u00032\u0006\u0010\u0004\u001a\u00028\u0000¢\u0006\u0004\b\u001e\u0010\u001fJ\u0017\u0010!\u001a\f\u0012\b\u0012\u00060\u0000j\u0002`\u00030 ¢\u0006\u0004\b!\u0010\"J \u0010$\u001a\u00060\u0000j\u0002`\u00032\n\u0010#\u001a\u00060\u0000j\u0002`\u0003H\u0082\u0010¢\u0006\u0004\b$\u0010%J\u001b\u0010&\u001a\u00020\u00052\n\u0010\u0013\u001a\u00060\u0000j\u0002`\u0003H\u0002¢\u0006\u0004\b&\u0010\u0007J\r\u0010'\u001a\u00020\u0005¢\u0006\u0004\b'\u0010\u0002J\u000f\u0010(\u001a\u00020\u0005H\u0001¢\u0006\u0004\b(\u0010\u0002J,\u0010*\u001a\u00020)2\n\u0010\u0004\u001a\u00060\u0000j\u0002`\u00032\u000e\b\u0004\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\bH\u0081\b¢\u0006\u0004\b*\u0010+J\u0017\u0010,\u001a\n\u0018\u00010\u0000j\u0004\u0018\u0001`\u0003H\u0014¢\u0006\u0004\b,\u0010-J\u000f\u0010.\u001a\u00020\tH\u0016¢\u0006\u0004\b.\u0010/J.\u00100\u001a\u0004\u0018\u00018\u0000\"\u0006\b\u0000\u0010\u001c\u0018\u00012\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\t0\rH\u0086\b¢\u0006\u0004\b0\u00101J\u0015\u00102\u001a\n\u0018\u00010\u0000j\u0004\u0018\u0001`\u0003¢\u0006\u0004\b2\u0010-J\u0017\u00103\u001a\n\u0018\u00010\u0000j\u0004\u0018\u0001`\u0003H\u0001¢\u0006\u0004\b3\u0010-J\u000f\u00105\u001a\u000204H\u0002¢\u0006\u0004\b5\u00106J\u000f\u00108\u001a\u000207H\u0016¢\u0006\u0004\b8\u00109J/\u0010<\u001a\u00020;2\n\u0010\u0004\u001a\u00060\u0000j\u0002`\u00032\n\u0010\u0013\u001a\u00060\u0000j\u0002`\u00032\u0006\u0010:\u001a\u00020)H\u0001¢\u0006\u0004\b<\u0010=J'\u0010A\u001a\u00020\u00052\n\u0010>\u001a\u00060\u0000j\u0002`\u00032\n\u0010\u0013\u001a\u00060\u0000j\u0002`\u0003H\u0000¢\u0006\u0004\b?\u0010@R\u0014\u0010B\u001a\u00020\t8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\bB\u0010/R\u0011\u0010\u0013\u001a\u00020C8F¢\u0006\u0006\u001a\u0004\bD\u0010ER\u0015\u0010G\u001a\u00060\u0000j\u0002`\u00038F¢\u0006\u0006\u001a\u0004\bF\u0010-R\u0015\u0010I\u001a\u00060\u0000j\u0002`\u00038F¢\u0006\u0006\u001a\u0004\bH\u0010-¨\u0006O"},
   d2 = {"Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "LockFreeLinkedListNode", "()V", "Lkotlinx/coroutines/internal/Node;", "node", "", "addLast", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)V", "Lkotlin/Function0;", "", "condition", "addLastIf", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlin/jvm/functions/Function0;)Z", "Lkotlin/Function1;", "predicate", "addLastIfPrev", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlin/jvm/functions/Function1;)Z", "addLastIfPrevAndIf", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)Z", "next", "addNext", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)Z", "addOneIfEmpty", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)Z", "Lkotlinx/coroutines/internal/OpDescriptor;", "op", "correctPrev", "(Lkotlinx/coroutines/internal/OpDescriptor;)Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "T", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$AddLastDesc;", "describeAddLast", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)Lkotlinx/coroutines/internal/LockFreeLinkedListNode$AddLastDesc;", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$RemoveFirstDesc;", "describeRemoveFirst", "()Lkotlinx/coroutines/internal/LockFreeLinkedListNode$RemoveFirstDesc;", "current", "findPrevNonRemoved", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "finishAdd", "helpRemove", "helpRemovePrev", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$CondAddOp;", "makeCondAddOp", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlin/jvm/functions/Function0;)Lkotlinx/coroutines/internal/LockFreeLinkedListNode$CondAddOp;", "nextIfRemoved", "()Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "remove", "()Z", "removeFirstIfIsInstanceOfOrPeekIf", "(Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "removeFirstOrNull", "removeOrNext", "Lkotlinx/coroutines/internal/Removed;", "removed", "()Lkotlinx/coroutines/internal/Removed;", "", "toString", "()Ljava/lang/String;", "condAdd", "", "tryCondAddNext", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlinx/coroutines/internal/LockFreeLinkedListNode$CondAddOp;)I", "prev", "validateNode$kotlinx_coroutines_core", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)V", "validateNode", "isRemoved", "", "getNext", "()Ljava/lang/Object;", "getNextNode", "nextNode", "getPrevNode", "prevNode", "AbstractAtomicDesc", "AddLastDesc", "CondAddOp", "PrepareOp", "RemoveFirstDesc", "kotlinx-coroutines-core"}
)
@InternalCoroutinesApi
public class LockFreeLinkedListNode {
   // $FF: synthetic field
   @NotNull
   volatile Object _next;
   // $FF: synthetic field
   static final AtomicReferenceFieldUpdater _next$FU = AtomicReferenceFieldUpdater.newUpdater(LockFreeLinkedListNode.class, Object.class, "_next");
   // $FF: synthetic field
   @NotNull
   volatile Object _prev;
   // $FF: synthetic field
   static final AtomicReferenceFieldUpdater _prev$FU = AtomicReferenceFieldUpdater.newUpdater(LockFreeLinkedListNode.class, Object.class, "_prev");
   // $FF: synthetic field
   @NotNull
   private volatile Object _removedRef;
   // $FF: synthetic field
   private static final AtomicReferenceFieldUpdater _removedRef$FU = AtomicReferenceFieldUpdater.newUpdater(LockFreeLinkedListNode.class, Object.class, "_removedRef");

   public LockFreeLinkedListNode() {
      a._next = a;
      a._prev = a;
      a._removedRef = null;
   }

   private final Removed removed() {
      Removed var10000 = (Removed)a._removedRef;
      if (var10000 == null) {
         Removed var1 = new Removed(a);
         int a = false;
         _removedRef$FU.lazySet(a, var1);
         var10000 = var1;
      }

      return var10000;
   }

   @PublishedApi
   @NotNull
   public final LockFreeLinkedListNode.CondAddOp makeCondAddOp(@NotNull LockFreeLinkedListNode a, @NotNull Function0<Boolean> a) {
      int a = false;
      return (LockFreeLinkedListNode.CondAddOp)(new LockFreeLinkedListNode.CondAddOp(a, a) {
         // $FF: synthetic field
         final Function0<Boolean> $condition;

         public {
            a.$condition = axx;
         }

         @Nullable
         public Object prepare(@NotNull LockFreeLinkedListNode a1) {
            return (Boolean)a.$condition.invoke() ? null : LockFreeLinkedListKt.getCONDITION_FALSE();
         }
      });
   }

   public boolean isRemoved() {
      return a.getNext() instanceof Removed;
   }

   @NotNull
   public final Object getNext() {
      LockFreeLinkedListNode a = a;
      boolean var2 = false;

      while(true) {
         Object a = a._next;
         int a = false;
         if (!(a instanceof OpDescriptor)) {
            return a;
         }

         ((OpDescriptor)a).perform(a);
      }
   }

   @NotNull
   public final LockFreeLinkedListNode getNextNode() {
      return LockFreeLinkedListKt.unwrap(a.getNext());
   }

   @NotNull
   public final LockFreeLinkedListNode getPrevNode() {
      LockFreeLinkedListNode var10000 = a.correctPrev((OpDescriptor)null);
      if (var10000 == null) {
         var10000 = a.findPrevNonRemoved((LockFreeLinkedListNode)a._prev);
      }

      return var10000;
   }

   private final LockFreeLinkedListNode findPrevNonRemoved(LockFreeLinkedListNode a) {
      LockFreeLinkedListNode var2 = a;

      LockFreeLinkedListNode var3;
      LockFreeLinkedListNode var6;
      for(var3 = a; var3.isRemoved(); var3 = var6) {
         var6 = (LockFreeLinkedListNode)var3._prev;
         var2 = var2;
      }

      return var3;
   }

   public final boolean addOneIfEmpty(@NotNull LockFreeLinkedListNode a) {
      _prev$FU.lazySet(a, a);
      _next$FU.lazySet(a, a);

      do {
         Object a = a.getNext();
         if (a != a) {
            return false;
         }
      } while(!_next$FU.compareAndSet(a, a, a));

      a.finishAdd(a);
      return true;
   }

   public final void addLast(@NotNull LockFreeLinkedListNode a) {
      while(!a.getPrevNode().addNext(a, a)) {
      }

   }

   @NotNull
   public final <T extends LockFreeLinkedListNode> LockFreeLinkedListNode.AddLastDesc<T> describeAddLast(@NotNull T a) {
      return new LockFreeLinkedListNode.AddLastDesc(a, a);
   }

   public final boolean addLastIf(@NotNull LockFreeLinkedListNode a, @NotNull Function0<Boolean> a) {
      int a = false;
      int a = false;
      LockFreeLinkedListNode.CondAddOp a = (LockFreeLinkedListNode.CondAddOp)(new LockFreeLinkedListNode.CondAddOp(a, a) {
         // $FF: synthetic field
         final Function0<Boolean> $condition;

         public {
            a.$condition = axx;
         }

         @Nullable
         public Object prepare(@NotNull LockFreeLinkedListNode a1) {
            return (Boolean)a.$condition.invoke() ? null : LockFreeLinkedListKt.getCONDITION_FALSE();
         }
      });

      while(true) {
         LockFreeLinkedListNode a = a.getPrevNode();
         switch(a.tryCondAddNext(a, a, a)) {
         case 1:
            return true;
         case 2:
            return false;
         }
      }
   }

   public final boolean addLastIfPrev(@NotNull LockFreeLinkedListNode a, @NotNull Function1<? super LockFreeLinkedListNode, Boolean> a) {
      boolean var3 = false;

      LockFreeLinkedListNode a;
      do {
         a = a.getPrevNode();
         if (!(Boolean)a.invoke(a)) {
            return false;
         }
      } while(!a.addNext(a, a));

      return true;
   }

   public final boolean addLastIfPrevAndIf(@NotNull LockFreeLinkedListNode a, @NotNull Function1<? super LockFreeLinkedListNode, Boolean> a, @NotNull Function0<Boolean> a) {
      int a = false;
      int a = false;
      LockFreeLinkedListNode.CondAddOp a = (LockFreeLinkedListNode.CondAddOp)(new LockFreeLinkedListNode.CondAddOp(a, a) {
         // $FF: synthetic field
         final Function0<Boolean> $condition;

         public {
            a.$condition = axx;
         }

         @Nullable
         public Object prepare(@NotNull LockFreeLinkedListNode a1) {
            return (Boolean)a.$condition.invoke() ? null : LockFreeLinkedListKt.getCONDITION_FALSE();
         }
      });

      while(true) {
         LockFreeLinkedListNode a = a.getPrevNode();
         if (!(Boolean)a.invoke(a)) {
            return false;
         }

         switch(a.tryCondAddNext(a, a, a)) {
         case 1:
            return true;
         case 2:
            return false;
         }
      }
   }

   @PublishedApi
   public final boolean addNext(@NotNull LockFreeLinkedListNode a, @NotNull LockFreeLinkedListNode a) {
      _prev$FU.lazySet(a, a);
      _next$FU.lazySet(a, a);
      if (!_next$FU.compareAndSet(a, a, a)) {
         return false;
      } else {
         a.finishAdd(a);
         return true;
      }
   }

   @PublishedApi
   public final int tryCondAddNext(@NotNull LockFreeLinkedListNode a, @NotNull LockFreeLinkedListNode a, @NotNull LockFreeLinkedListNode.CondAddOp a) {
      _prev$FU.lazySet(a, a);
      _next$FU.lazySet(a, a);
      a.oldNext = a;
      if (!_next$FU.compareAndSet(a, a, a)) {
         return 0;
      } else {
         return a.perform(a) == null ? 1 : 2;
      }
   }

   public boolean remove() {
      return a.removeOrNext() == null;
   }

   @PublishedApi
   @Nullable
   public final LockFreeLinkedListNode removeOrNext() {
      Object a;
      Removed a;
      do {
         a = a.getNext();
         if (a instanceof Removed) {
            return ((Removed)a).ref;
         }

         if (a == a) {
            return (LockFreeLinkedListNode)a;
         }

         a = ((LockFreeLinkedListNode)a).removed();
      } while(!_next$FU.compareAndSet(a, a, a));

      ((LockFreeLinkedListNode)a).correctPrev((OpDescriptor)null);
      return null;
   }

   public final void helpRemove() {
      ((Removed)a.getNext()).ref.helpRemovePrev();
   }

   @PublishedApi
   public final void helpRemovePrev() {
      LockFreeLinkedListNode a = a;

      while(true) {
         Object a = a.getNext();
         if (!(a instanceof Removed)) {
            a.correctPrev((OpDescriptor)null);
            return;
         }

         a = ((Removed)a).ref;
      }
   }

   @Nullable
   public final LockFreeLinkedListNode removeFirstOrNull() {
      while(true) {
         LockFreeLinkedListNode a = (LockFreeLinkedListNode)a.getNext();
         if (a == a) {
            return null;
         }

         if (a.remove()) {
            return a;
         }

         a.helpRemove();
      }
   }

   @NotNull
   public final LockFreeLinkedListNode.RemoveFirstDesc<LockFreeLinkedListNode> describeRemoveFirst() {
      return new LockFreeLinkedListNode.RemoveFirstDesc(a);
   }

   // $FF: synthetic method
   public final <T> T removeFirstIfIsInstanceOfOrPeekIf(Function1<? super T, Boolean> a) {
      boolean var2 = false;

      while(true) {
         LockFreeLinkedListNode a = (LockFreeLinkedListNode)a.getNext();
         if (a == a) {
            return null;
         }

         Intrinsics.reifiedOperationMarker(3, "T");
         if (!(a instanceof Object)) {
            return null;
         }

         if ((Boolean)a.invoke(a) && !a.isRemoved()) {
            return a;
         }

         LockFreeLinkedListNode a = a.removeOrNext();
         if (a == null) {
            return a;
         }

         a.helpRemovePrev();
      }
   }

   private final void finishAdd(LockFreeLinkedListNode a) {
      LockFreeLinkedListNode a = a;
      boolean var3 = false;

      LockFreeLinkedListNode a;
      do {
         a = (LockFreeLinkedListNode)a._prev;
         int a = false;
         if (a.getNext() != a) {
            return;
         }
      } while(!_prev$FU.compareAndSet(a, a, a));

      if (a.isRemoved()) {
         a.correctPrev((OpDescriptor)null);
      }

   }

   @Nullable
   protected LockFreeLinkedListNode nextIfRemoved() {
      Object var1 = a.getNext();
      return (var1 instanceof Removed ? (Removed)var1 : null) != null ? (var1 instanceof Removed ? (Removed)var1 : null).ref : null;
   }

   private final LockFreeLinkedListNode correctPrev(OpDescriptor a) {
      LockFreeLinkedListNode var2 = a;
      OpDescriptor var3 = a;

      while(true) {
         LockFreeLinkedListNode var4 = var2;
         OpDescriptor var5 = var3;
         LockFreeLinkedListNode a = (LockFreeLinkedListNode)var2._prev;
         LockFreeLinkedListNode a = a;
         LockFreeLinkedListNode a = null;

         while(true) {
            Object a = a._next;
            if (a == var4) {
               if (a == a) {
                  return a;
               }

               if (_prev$FU.compareAndSet(var4, a, a)) {
                  return a;
               }

               var2 = var4;
               var3 = var5;
               break;
            }

            if (var4.isRemoved()) {
               return null;
            }

            if (a == var5) {
               return a;
            }

            if (a instanceof OpDescriptor) {
               if (var5 != null && var5.isEarlierThan((OpDescriptor)a)) {
                  return null;
               }

               ((OpDescriptor)a).perform(a);
               var2 = var4;
               var3 = var5;
               break;
            }

            if (a instanceof Removed) {
               if (a != null) {
                  if (!_next$FU.compareAndSet(a, a, ((Removed)a).ref)) {
                     var2 = var4;
                     var3 = var5;
                     break;
                  }

                  a = a;
                  a = null;
               } else {
                  a = (LockFreeLinkedListNode)a._prev;
               }
            } else {
               a = a;
               a = (LockFreeLinkedListNode)a;
            }
         }
      }
   }

   public final void validateNode$kotlinx_coroutines_core(@NotNull LockFreeLinkedListNode a, @NotNull LockFreeLinkedListNode a) {
      boolean a;
      if (DebugKt.getASSERTIONS_ENABLED()) {
         a = false;
         if (a != a._prev) {
            throw new AssertionError();
         }
      }

      if (DebugKt.getASSERTIONS_ENABLED()) {
         a = false;
         if (a != a._next) {
            throw new AssertionError();
         }
      }

   }

   @NotNull
   public String toString() {
      return "" + new PropertyReference0Impl(a) {
         @Nullable
         public Object get() {
            return DebugStringsKt.getClassSimpleName(a.receiver);
         }
      } + '@' + DebugStringsKt.getHexAddress(a);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\b!\u0018\u00002\f\u0012\b\u0012\u00060\u0002j\u0002`\u00030\u0001B\u0011\u0012\n\u0010\u0004\u001a\u00060\u0002j\u0002`\u0003¢\u0006\u0002\u0010\u0005J\u001e\u0010\u0007\u001a\u00020\b2\n\u0010\t\u001a\u00060\u0002j\u0002`\u00032\b\u0010\n\u001a\u0004\u0018\u00010\u000bH\u0016R\u0014\u0010\u0004\u001a\u00060\u0002j\u0002`\u00038\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\n\u0018\u00010\u0002j\u0004\u0018\u0001`\u00038\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000¨\u0006\f"},
      d2 = {"Lkotlinx/coroutines/internal/LockFreeLinkedListNode$CondAddOp;", "Lkotlinx/coroutines/internal/AtomicOp;", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "Lkotlinx/coroutines/internal/Node;", "newNode", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)V", "oldNext", "complete", "", "affected", "failure", "", "kotlinx-coroutines-core"}
   )
   @PublishedApi
   public abstract static class CondAddOp extends AtomicOp<LockFreeLinkedListNode> {
      @JvmField
      @NotNull
      public final LockFreeLinkedListNode newNode;
      @JvmField
      @Nullable
      public LockFreeLinkedListNode oldNext;

      public CondAddOp(@NotNull LockFreeLinkedListNode a) {
         a.newNode = a;
      }

      public void complete(@NotNull LockFreeLinkedListNode a, @Nullable Object a) {
         boolean a = a == null;
         LockFreeLinkedListNode a = a ? a.newNode : a.oldNext;
         if (a != null && LockFreeLinkedListNode._next$FU.compareAndSet(a, a, a) && a) {
            LockFreeLinkedListNode var10000 = a.newNode;
            LockFreeLinkedListNode var10001 = a.oldNext;
            Intrinsics.checkNotNull(var10001);
            var10000.finishAdd(var10001);
         }

      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\b\u0016\u0018\u0000*\f\b\u0000\u0010\u0003*\u00060\u0001j\u0002`\u00022\u00020!B\u001b\u0012\n\u0010\u0004\u001a\u00060\u0001j\u0002`\u0002\u0012\u0006\u0010\u0005\u001a\u00028\u0000¢\u0006\u0004\b\u0006\u0010\u0007J'\u0010\u000b\u001a\u00020\n2\n\u0010\b\u001a\u00060\u0001j\u0002`\u00022\n\u0010\t\u001a\u00060\u0001j\u0002`\u0002H\u0014¢\u0006\u0004\b\u000b\u0010\u0007J\u0017\u0010\u000e\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\fH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ#\u0010\u0012\u001a\u00020\u00112\n\u0010\b\u001a\u00060\u0001j\u0002`\u00022\u0006\u0010\t\u001a\u00020\u0010H\u0014¢\u0006\u0004\b\u0012\u0010\u0013J\u001f\u0010\u0016\u001a\n\u0018\u00010\u0001j\u0004\u0018\u0001`\u00022\u0006\u0010\u0015\u001a\u00020\u0014H\u0004¢\u0006\u0004\b\u0016\u0010\u0017J'\u0010\u0018\u001a\u00020\u00102\n\u0010\b\u001a\u00060\u0001j\u0002`\u00022\n\u0010\t\u001a\u00060\u0001j\u0002`\u0002H\u0016¢\u0006\u0004\b\u0018\u0010\u0019R\u001c\u0010\u001c\u001a\n\u0018\u00010\u0001j\u0004\u0018\u0001`\u00028DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\u001a\u0010\u001bR\u0014\u0010\u0005\u001a\u00028\u00008\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0005\u0010\u001dR\u0018\u0010\u001f\u001a\u00060\u0001j\u0002`\u00028DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\u001e\u0010\u001bR\u0018\u0010\u0004\u001a\u00060\u0001j\u0002`\u00028\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0004\u0010\u001d¨\u0006 "},
      d2 = {"Lkotlinx/coroutines/internal/LockFreeLinkedListNode$AddLastDesc;", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "Lkotlinx/coroutines/internal/Node;", "T", "queue", "node", "LockFreeLinkedListNode$AddLastDesc", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)V", "affected", "next", "", "finishOnSuccess", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$PrepareOp;", "prepareOp", "finishPrepare", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode$PrepareOp;)V", "", "", "retry", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Ljava/lang/Object;)Z", "Lkotlinx/coroutines/internal/OpDescriptor;", "op", "takeAffectedNode", "(Lkotlinx/coroutines/internal/OpDescriptor;)Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "updatedNext", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)Ljava/lang/Object;", "getAffectedNode", "()Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "affectedNode", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "getOriginalNext", "originalNext", "kotlinx-coroutines-core", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$AbstractAtomicDesc;"}
   )
   public static class AddLastDesc<T extends LockFreeLinkedListNode> extends LockFreeLinkedListNode.AbstractAtomicDesc {
      @JvmField
      @NotNull
      public final LockFreeLinkedListNode queue;
      @JvmField
      @NotNull
      public final T node;
      // $FF: synthetic field
      @NotNull
      private volatile Object _affectedNode;
      // $FF: synthetic field
      private static final AtomicReferenceFieldUpdater _affectedNode$FU = AtomicReferenceFieldUpdater.newUpdater(LockFreeLinkedListNode.AddLastDesc.class, Object.class, "_affectedNode");

      public AddLastDesc(@NotNull LockFreeLinkedListNode a, @NotNull T a) {
         a.queue = a;
         a.node = a;
         if (DebugKt.getASSERTIONS_ENABLED()) {
            int a = false;
            if (a.node._next != a.node || a.node._prev != a.node) {
               throw new AssertionError();
            }
         }

         a._affectedNode = null;
      }

      @Nullable
      protected final LockFreeLinkedListNode takeAffectedNode(@NotNull OpDescriptor a) {
         return a.queue.correctPrev(a);
      }

      @Nullable
      protected final LockFreeLinkedListNode getAffectedNode() {
         return (LockFreeLinkedListNode)a._affectedNode;
      }

      @NotNull
      protected final LockFreeLinkedListNode getOriginalNext() {
         return a.queue;
      }

      protected boolean retry(@NotNull LockFreeLinkedListNode a1, @NotNull Object a) {
         return a != a.queue;
      }

      public void finishPrepare(@NotNull LockFreeLinkedListNode.PrepareOp a) {
         _affectedNode$FU.compareAndSet(a, (Object)null, a.affected);
      }

      @NotNull
      public Object updatedNext(@NotNull LockFreeLinkedListNode a, @NotNull LockFreeLinkedListNode a2) {
         LockFreeLinkedListNode._prev$FU.compareAndSet(a.node, a.node, a);
         LockFreeLinkedListNode._next$FU.compareAndSet(a.node, a.node, a.queue);
         return a.node;
      }

      protected void finishOnSuccess(@NotNull LockFreeLinkedListNode a1, @NotNull LockFreeLinkedListNode a2) {
         a.node.finishAdd(a.queue);
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\b\u0016\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020(B\u0013\u0012\n\u0010\u0004\u001a\u00060\u0002j\u0002`\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\u001d\u0010\t\u001a\u0004\u0018\u00010\b2\n\u0010\u0007\u001a\u00060\u0002j\u0002`\u0003H\u0014¢\u0006\u0004\b\t\u0010\nJ'\u0010\r\u001a\u00020\f2\n\u0010\u0007\u001a\u00060\u0002j\u0002`\u00032\n\u0010\u000b\u001a\u00060\u0002j\u0002`\u0003H\u0004¢\u0006\u0004\b\r\u0010\u000eJ\u0017\u0010\u0011\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u000fH\u0016¢\u0006\u0004\b\u0011\u0010\u0012J#\u0010\u0014\u001a\u00020\u00132\n\u0010\u0007\u001a\u00060\u0002j\u0002`\u00032\u0006\u0010\u000b\u001a\u00020\bH\u0004¢\u0006\u0004\b\u0014\u0010\u0015J\u001f\u0010\u0018\u001a\n\u0018\u00010\u0002j\u0004\u0018\u0001`\u00032\u0006\u0010\u0017\u001a\u00020\u0016H\u0004¢\u0006\u0004\b\u0018\u0010\u0019J%\u0010\u001a\u001a\u00020\b2\n\u0010\u0007\u001a\u00060\u0002j\u0002`\u00032\n\u0010\u000b\u001a\u00060\u0002j\u0002`\u0003¢\u0006\u0004\b\u001a\u0010\u001bR\u001c\u0010\u001e\u001a\n\u0018\u00010\u0002j\u0004\u0018\u0001`\u00038DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\u001c\u0010\u001dR\u001c\u0010 \u001a\n\u0018\u00010\u0002j\u0004\u0018\u0001`\u00038DX\u0084\u0004¢\u0006\u0006\u001a\u0004\b\u001f\u0010\u001dR\u0018\u0010\u0004\u001a\u00060\u0002j\u0002`\u00038\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0004\u0010!R\u0017\u0010&\u001a\u00028\u00008F¢\u0006\f\u0012\u0004\b$\u0010%\u001a\u0004\b\"\u0010#¨\u0006'"},
      d2 = {"Lkotlinx/coroutines/internal/LockFreeLinkedListNode$RemoveFirstDesc;", "T", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "Lkotlinx/coroutines/internal/Node;", "queue", "LockFreeLinkedListNode$RemoveFirstDesc", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)V", "affected", "", "failure", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)Ljava/lang/Object;", "next", "", "finishOnSuccess", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)V", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$PrepareOp;", "prepareOp", "finishPrepare", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode$PrepareOp;)V", "", "retry", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Ljava/lang/Object;)Z", "Lkotlinx/coroutines/internal/OpDescriptor;", "op", "takeAffectedNode", "(Lkotlinx/coroutines/internal/OpDescriptor;)Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "updatedNext", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)Ljava/lang/Object;", "getAffectedNode", "()Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "affectedNode", "getOriginalNext", "originalNext", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "getResult", "()Ljava/lang/Object;", "getResult$annotations", "()V", "result", "kotlinx-coroutines-core", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$AbstractAtomicDesc;"}
   )
   public static class RemoveFirstDesc<T> extends LockFreeLinkedListNode.AbstractAtomicDesc {
      @JvmField
      @NotNull
      public final LockFreeLinkedListNode queue;
      // $FF: synthetic field
      @NotNull
      private volatile Object _affectedNode;
      // $FF: synthetic field
      private static final AtomicReferenceFieldUpdater _affectedNode$FU = AtomicReferenceFieldUpdater.newUpdater(LockFreeLinkedListNode.RemoveFirstDesc.class, Object.class, "_affectedNode");
      // $FF: synthetic field
      @NotNull
      private volatile Object _originalNext;
      // $FF: synthetic field
      private static final AtomicReferenceFieldUpdater _originalNext$FU = AtomicReferenceFieldUpdater.newUpdater(LockFreeLinkedListNode.RemoveFirstDesc.class, Object.class, "_originalNext");

      public RemoveFirstDesc(@NotNull LockFreeLinkedListNode a) {
         a.queue = a;
         a._affectedNode = null;
         a._originalNext = null;
      }

      public final T getResult() {
         LockFreeLinkedListNode var10000 = a.getAffectedNode();
         Intrinsics.checkNotNull(var10000);
         return (Object)var10000;
      }

      /** @deprecated */
      // $FF: synthetic method
      public static void getResult$annotations() {
      }

      @Nullable
      protected final LockFreeLinkedListNode takeAffectedNode(@NotNull OpDescriptor a) {
         LockFreeLinkedListNode a = a.queue;
         boolean var3 = false;

         while(true) {
            Object a = a._next;
            int a = false;
            if (!(a instanceof OpDescriptor)) {
               return (LockFreeLinkedListNode)a;
            }

            if (a.isEarlierThan((OpDescriptor)a)) {
               return null;
            }

            ((OpDescriptor)a).perform(a.queue);
         }
      }

      @Nullable
      protected final LockFreeLinkedListNode getAffectedNode() {
         return (LockFreeLinkedListNode)a._affectedNode;
      }

      @Nullable
      protected final LockFreeLinkedListNode getOriginalNext() {
         return (LockFreeLinkedListNode)a._originalNext;
      }

      @Nullable
      protected Object failure(@NotNull LockFreeLinkedListNode a) {
         return a == a.queue ? LockFreeLinkedListKt.getLIST_EMPTY() : null;
      }

      protected final boolean retry(@NotNull LockFreeLinkedListNode a1, @NotNull Object a) {
         if (!(a instanceof Removed)) {
            return false;
         } else {
            ((Removed)a).ref.helpRemovePrev();
            return true;
         }
      }

      public void finishPrepare(@NotNull LockFreeLinkedListNode.PrepareOp a) {
         _affectedNode$FU.compareAndSet(a, (Object)null, a.affected);
         _originalNext$FU.compareAndSet(a, (Object)null, a.next);
      }

      @NotNull
      public final Object updatedNext(@NotNull LockFreeLinkedListNode a1, @NotNull LockFreeLinkedListNode a) {
         return a.removed();
      }

      protected final void finishOnSuccess(@NotNull LockFreeLinkedListNode a1, @NotNull LockFreeLinkedListNode a) {
         a.correctPrev((OpDescriptor)null);
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\u0018\u00002\u00020\u0001B%\u0012\n\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004\u0012\n\u0010\u0005\u001a\u00060\u0003j\u0002`\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\u0006\u0010\r\u001a\u00020\u000eJ\u0014\u0010\u000f\u001a\u0004\u0018\u00010\u00102\b\u0010\u0002\u001a\u0004\u0018\u00010\u0010H\u0016J\b\u0010\u0011\u001a\u00020\u0012H\u0016R\u0014\u0010\u0002\u001a\u00060\u0003j\u0002`\u00048\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0018\u0010\t\u001a\u0006\u0012\u0002\b\u00030\n8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000b\u0010\fR\u0010\u0010\u0006\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\u00060\u0003j\u0002`\u00048\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\u0013"},
      d2 = {"Lkotlinx/coroutines/internal/LockFreeLinkedListNode$PrepareOp;", "Lkotlinx/coroutines/internal/OpDescriptor;", "affected", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "Lkotlinx/coroutines/internal/Node;", "next", "desc", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$AbstractAtomicDesc;", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlinx/coroutines/internal/LockFreeLinkedListNode;Lkotlinx/coroutines/internal/LockFreeLinkedListNode$AbstractAtomicDesc;)V", "atomicOp", "Lkotlinx/coroutines/internal/AtomicOp;", "getAtomicOp", "()Lkotlinx/coroutines/internal/AtomicOp;", "finishPrepare", "", "perform", "", "toString", "", "kotlinx-coroutines-core"}
   )
   public static final class PrepareOp extends OpDescriptor {
      @JvmField
      @NotNull
      public final LockFreeLinkedListNode affected;
      @JvmField
      @NotNull
      public final LockFreeLinkedListNode next;
      @JvmField
      @NotNull
      public final LockFreeLinkedListNode.AbstractAtomicDesc desc;

      public PrepareOp(@NotNull LockFreeLinkedListNode a, @NotNull LockFreeLinkedListNode a, @NotNull LockFreeLinkedListNode.AbstractAtomicDesc a) {
         a.affected = a;
         a.next = a;
         a.desc = a;
      }

      @NotNull
      public AtomicOp<?> getAtomicOp() {
         return a.desc.getAtomicOp();
      }

      @Nullable
      public Object perform(@Nullable Object a) {
         if (DebugKt.getASSERTIONS_ENABLED()) {
            int a = false;
            if (a != a.affected) {
               throw new AssertionError();
            }
         }

         if (a == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.internal.LockFreeLinkedListNode{ kotlinx.coroutines.internal.LockFreeLinkedListKt.Node }");
         } else {
            LockFreeLinkedListNode var10000 = (LockFreeLinkedListNode)a;
            Object a = a.desc.onPrepare(a);
            if (a == LockFreeLinkedList_commonKt.REMOVE_PREPARED) {
               LockFreeLinkedListNode a = a.next;
               Removed a = a.removed();
               if (LockFreeLinkedListNode._next$FU.compareAndSet((LockFreeLinkedListNode)a, a, a)) {
                  a.desc.onRemoved((LockFreeLinkedListNode)a);
                  a.correctPrev((OpDescriptor)null);
               }

               return LockFreeLinkedList_commonKt.REMOVE_PREPARED;
            } else {
               Object a = a != null ? a.getAtomicOp().decide(a) : a.getAtomicOp().getConsensus();
               Object a = a == AtomicKt.NO_DECISION ? a.getAtomicOp() : (a == null ? a.desc.updatedNext((LockFreeLinkedListNode)a, a.next) : a.next);
               LockFreeLinkedListNode._next$FU.compareAndSet((LockFreeLinkedListNode)a, a, a);
               return null;
            }
         }
      }

      public final void finishPrepare() {
         a.desc.finishPrepare(a);
      }

      @NotNull
      public String toString() {
         return "PrepareOp(op=" + a.getAtomicOp() + ')';
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b&\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u001c\u0010\n\u001a\u00020\u000b2\n\u0010\f\u001a\u0006\u0012\u0002\b\u00030\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fJ\u0016\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\n\u0010\u0010\u001a\u00060\u0004j\u0002`\u0005H\u0014J \u0010\u0011\u001a\u00020\u000b2\n\u0010\u0010\u001a\u00060\u0004j\u0002`\u00052\n\u0010\u0012\u001a\u00060\u0004j\u0002`\u0005H$J\u0010\u0010\u0013\u001a\u00020\u000b2\u0006\u0010\u0014\u001a\u00020\u0015H&J\u0012\u0010\u0016\u001a\u0004\u0018\u00010\u000f2\u0006\u0010\u0014\u001a\u00020\u0015H\u0016J\u0014\u0010\u0017\u001a\u00020\u000b2\n\u0010\u0010\u001a\u00060\u0004j\u0002`\u0005H\u0016J\u0014\u0010\u0018\u001a\u0004\u0018\u00010\u000f2\n\u0010\f\u001a\u0006\u0012\u0002\b\u00030\rJ\u001c\u0010\u0019\u001a\u00020\u001a2\n\u0010\u0010\u001a\u00060\u0004j\u0002`\u00052\u0006\u0010\u0012\u001a\u00020\u000fH\u0014J\u0018\u0010\u001b\u001a\n\u0018\u00010\u0004j\u0004\u0018\u0001`\u00052\u0006\u0010\f\u001a\u00020\u001cH\u0014J \u0010\u001d\u001a\u00020\u000f2\n\u0010\u0010\u001a\u00060\u0004j\u0002`\u00052\n\u0010\u0012\u001a\u00060\u0004j\u0002`\u0005H&R\u001a\u0010\u0003\u001a\n\u0018\u00010\u0004j\u0004\u0018\u0001`\u0005X¤\u0004¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007R\u001a\u0010\b\u001a\n\u0018\u00010\u0004j\u0004\u0018\u0001`\u0005X¤\u0004¢\u0006\u0006\u001a\u0004\b\t\u0010\u0007¨\u0006\u001e"},
      d2 = {"Lkotlinx/coroutines/internal/LockFreeLinkedListNode$AbstractAtomicDesc;", "Lkotlinx/coroutines/internal/AtomicDesc;", "()V", "affectedNode", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "Lkotlinx/coroutines/internal/Node;", "getAffectedNode", "()Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "originalNext", "getOriginalNext", "complete", "", "op", "Lkotlinx/coroutines/internal/AtomicOp;", "failure", "", "affected", "finishOnSuccess", "next", "finishPrepare", "prepareOp", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$PrepareOp;", "onPrepare", "onRemoved", "prepare", "retry", "", "takeAffectedNode", "Lkotlinx/coroutines/internal/OpDescriptor;", "updatedNext", "kotlinx-coroutines-core"}
   )
   public abstract static class AbstractAtomicDesc extends AtomicDesc {
      @Nullable
      protected abstract LockFreeLinkedListNode getAffectedNode();

      @Nullable
      protected abstract LockFreeLinkedListNode getOriginalNext();

      @Nullable
      protected LockFreeLinkedListNode takeAffectedNode(@NotNull OpDescriptor a1) {
         LockFreeLinkedListNode var10000 = a.getAffectedNode();
         Intrinsics.checkNotNull(var10000);
         return var10000;
      }

      @Nullable
      protected Object failure(@NotNull LockFreeLinkedListNode a1) {
         return null;
      }

      protected boolean retry(@NotNull LockFreeLinkedListNode a1, @NotNull Object a2) {
         return false;
      }

      protected abstract void finishOnSuccess(@NotNull LockFreeLinkedListNode var1, @NotNull LockFreeLinkedListNode var2);

      @NotNull
      public abstract Object updatedNext(@NotNull LockFreeLinkedListNode var1, @NotNull LockFreeLinkedListNode var2);

      public abstract void finishPrepare(@NotNull LockFreeLinkedListNode.PrepareOp var1);

      @Nullable
      public Object onPrepare(@NotNull LockFreeLinkedListNode.PrepareOp a) {
         a.finishPrepare(a);
         return null;
      }

      public void onRemoved(@NotNull LockFreeLinkedListNode a1) {
      }

      @Nullable
      public final Object prepare(@NotNull AtomicOp<?> a) {
         while(true) {
            LockFreeLinkedListNode var10000 = a.takeAffectedNode((OpDescriptor)a);
            if (var10000 == null) {
               return AtomicKt.RETRY_ATOMIC;
            }

            LockFreeLinkedListNode a = var10000;
            Object a = a._next;
            if (a == a) {
               return null;
            }

            if (a.isDecided()) {
               return null;
            }

            if (a instanceof OpDescriptor) {
               if (a.isEarlierThan((OpDescriptor)a)) {
                  return AtomicKt.RETRY_ATOMIC;
               }

               ((OpDescriptor)a).perform(a);
            } else {
               Object a = a.failure(a);
               if (a != null) {
                  return a;
               }

               if (!a.retry(a, a)) {
                  LockFreeLinkedListNode.PrepareOp a = new LockFreeLinkedListNode.PrepareOp(a, (LockFreeLinkedListNode)a, a);
                  if (LockFreeLinkedListNode._next$FU.compareAndSet(a, a, a)) {
                     try {
                        Object a = a.perform(a);
                        if (a != LockFreeLinkedList_commonKt.REMOVE_PREPARED) {
                           if (DebugKt.getASSERTIONS_ENABLED()) {
                              int a = false;
                              if (a != null) {
                                 throw new AssertionError();
                              }
                           }

                           return null;
                        }
                     } catch (Throwable var8) {
                        LockFreeLinkedListNode._next$FU.compareAndSet(a, a, a);
                        throw var8;
                     }
                  }
               }
            }
         }
      }

      public final void complete(@NotNull AtomicOp<?> a, @Nullable Object a) {
         boolean a = a == null;
         LockFreeLinkedListNode var10000 = a.getAffectedNode();
         boolean a;
         if (var10000 == null) {
            LockFreeLinkedListNode.AbstractAtomicDesc a = (LockFreeLinkedListNode.AbstractAtomicDesc)a;
            int a = false;
            if (DebugKt.getASSERTIONS_ENABLED()) {
               a = false;
               if (a) {
                  throw new AssertionError();
               }
            }

         } else {
            LockFreeLinkedListNode a = var10000;
            var10000 = a.getOriginalNext();
            if (var10000 == null) {
               LockFreeLinkedListNode.AbstractAtomicDesc a = (LockFreeLinkedListNode.AbstractAtomicDesc)a;
               a = false;
               if (DebugKt.getASSERTIONS_ENABLED()) {
                  int a = false;
                  if (a) {
                     throw new AssertionError();
                  }
               }

            } else {
               LockFreeLinkedListNode a = var10000;
               Object a = a ? a.updatedNext(a, a) : a;
               if (LockFreeLinkedListNode._next$FU.compareAndSet(a, a, a) && a) {
                  a.finishOnSuccess(a, a);
               }

            }
         }
      }
   }
}
