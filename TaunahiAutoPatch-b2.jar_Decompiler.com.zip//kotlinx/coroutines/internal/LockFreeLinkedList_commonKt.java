package kotlinx.coroutines.internal;

import kotlin.Metadata;
import kotlin.jvm.JvmField;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0003\"\u0016\u0010\u0000\u001a\u00020\u00018\u0000X\u0081\u0004¢\u0006\b\n\u0000\u0012\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
   d2 = {"REMOVE_PREPARED", "", "getREMOVE_PREPARED$annotations", "()V", "kotlinx-coroutines-core"}
)
public final class LockFreeLinkedList_commonKt {
   @JvmField
   @NotNull
   public static final Object REMOVE_PREPARED = new Symbol("REMOVE_PREPARED");

   /** @deprecated */
   // $FF: synthetic method
   public static void getREMOVE_PREPARED$annotations() {
   }
}
