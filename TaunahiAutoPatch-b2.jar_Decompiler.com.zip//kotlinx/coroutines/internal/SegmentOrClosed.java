package kotlinx.coroutines.internal;

import kotlin.Metadata;
import kotlin.jvm.JvmInline;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@JvmInline
@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\f\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0081@\u0018\u0000*\u000e\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u00022\u00020\u0003B\u0014\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003ø\u0001\u0000¢\u0006\u0004\b\u0005\u0010\u0006J\u001a\u0010\u0010\u001a\u00020\b2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0003HÖ\u0003¢\u0006\u0004\b\u0012\u0010\u0013J\u0010\u0010\u0014\u001a\u00020\u0015HÖ\u0001¢\u0006\u0004\b\u0016\u0010\u0017J\u0010\u0010\u0018\u001a\u00020\u0019HÖ\u0001¢\u0006\u0004\b\u001a\u0010\u001bR\u0011\u0010\u0007\u001a\u00020\b8F¢\u0006\u0006\u001a\u0004\b\t\u0010\nR\u0017\u0010\u000b\u001a\u00028\u00008F¢\u0006\f\u0012\u0004\b\f\u0010\r\u001a\u0004\b\u000e\u0010\u000fR\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0003X\u0082\u0004¢\u0006\u0002\n\u0000\u0088\u0001\u0004\u0092\u0001\u0004\u0018\u00010\u0003ø\u0001\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001c"},
   d2 = {"Lkotlinx/coroutines/internal/SegmentOrClosed;", "S", "Lkotlinx/coroutines/internal/Segment;", "", "value", "constructor-impl", "(Ljava/lang/Object;)Ljava/lang/Object;", "isClosed", "", "isClosed-impl", "(Ljava/lang/Object;)Z", "segment", "getSegment$annotations", "()V", "getSegment-impl", "(Ljava/lang/Object;)Lkotlinx/coroutines/internal/Segment;", "equals", "other", "equals-impl", "(Ljava/lang/Object;Ljava/lang/Object;)Z", "hashCode", "", "hashCode-impl", "(Ljava/lang/Object;)I", "toString", "", "toString-impl", "(Ljava/lang/Object;)Ljava/lang/String;", "kotlinx-coroutines-core"}
)
public final class SegmentOrClosed<S extends Segment<S>> {
   @Nullable
   private final Object value;

   public static final boolean isClosed_impl/* $FF was: isClosed-impl*/(Object a) {
      return a == ConcurrentLinkedListKt.access$getCLOSED$p();
   }

   @NotNull
   public static final S getSegment_impl/* $FF was: getSegment-impl*/(Object a) {
      if (a == ConcurrentLinkedListKt.access$getCLOSED$p()) {
         throw new IllegalStateException("Does not contain segment".toString());
      } else if (a == null) {
         throw new NullPointerException("null cannot be cast to non-null type S of kotlinx.coroutines.internal.SegmentOrClosed");
      } else {
         return (Segment)a;
      }
   }

   /** @deprecated */
   // $FF: synthetic method
   public static void getSegment$annotations() {
   }

   public static String toString_impl/* $FF was: toString-impl*/(Object a) {
      return "SegmentOrClosed(value=" + a + ')';
   }

   public String toString() {
      return toString-impl(a.value);
   }

   public static int hashCode_impl/* $FF was: hashCode-impl*/(Object a) {
      return a == null ? 0 : a.hashCode();
   }

   public int hashCode() {
      return hashCode-impl(a.value);
   }

   public static boolean equals_impl/* $FF was: equals-impl*/(Object a, Object a) {
      if (!(a instanceof SegmentOrClosed)) {
         return false;
      } else {
         return Intrinsics.areEqual(a, ((SegmentOrClosed)a).unbox-impl());
      }
   }

   public boolean equals(Object a) {
      return equals-impl(a.value, a);
   }

   // $FF: synthetic method
   private SegmentOrClosed(Object a) {
      a.value = a;
   }

   @NotNull
   public static <S extends Segment<S>> Object constructor_impl/* $FF was: constructor-impl*/(@Nullable Object a) {
      return a;
   }

   // $FF: synthetic method
   public static final SegmentOrClosed box_impl/* $FF was: box-impl*/(Object a) {
      return new SegmentOrClosed(a);
   }

   // $FF: synthetic method
   public final Object unbox_impl/* $FF was: unbox-impl*/() {
      return a.value;
   }

   public static final boolean equals_impl0/* $FF was: equals-impl0*/(Object a, Object a) {
      return Intrinsics.areEqual(a, a);
   }
}
