package kotlinx.coroutines.internal;

import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.JvmInline;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.DebugKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@JvmInline
@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0081@\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002B\u0016\u0012\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u0002ø\u0001\u0000¢\u0006\u0004\b\u0004\u0010\u0005J\u001a\u0010\u0006\u001a\u00020\u00072\b\u0010\b\u001a\u0004\u0018\u00010\u0002HÖ\u0003¢\u0006\u0004\b\t\u0010\nJ$\u0010\u000b\u001a\u00020\f2\u0012\u0010\r\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\f0\u000eH\u0086\b¢\u0006\u0004\b\u000f\u0010\u0010J\u0010\u0010\u0011\u001a\u00020\u0012HÖ\u0001¢\u0006\u0004\b\u0013\u0010\u0014J'\u0010\u0015\u001a\b\u0012\u0004\u0012\u00028\u00000\u00002\u0006\u0010\u0016\u001a\u00028\u0000H\u0086\u0002ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\u0004\b\u0017\u0010\u0018J\u0010\u0010\u0019\u001a\u00020\u001aHÖ\u0001¢\u0006\u0004\b\u001b\u0010\u001cR\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0002X\u0082\u0004¢\u0006\u0002\n\u0000\u0088\u0001\u0003\u0092\u0001\u0004\u0018\u00010\u0002ø\u0001\u0000\u0082\u0002\u000f\n\u0002\b\u0019\n\u0002\b!\n\u0005\b¡\u001e0\u0001¨\u0006\u001d"},
   d2 = {"Lkotlinx/coroutines/internal/InlineList;", "E", "", "holder", "constructor-impl", "(Ljava/lang/Object;)Ljava/lang/Object;", "equals", "", "other", "equals-impl", "(Ljava/lang/Object;Ljava/lang/Object;)Z", "forEachReversed", "", "action", "Lkotlin/Function1;", "forEachReversed-impl", "(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)V", "hashCode", "", "hashCode-impl", "(Ljava/lang/Object;)I", "plus", "element", "plus-FjFbRPM", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "toString", "", "toString-impl", "(Ljava/lang/Object;)Ljava/lang/String;", "kotlinx-coroutines-core"}
)
public final class InlineList<E> {
   @Nullable
   private final Object holder;

   @NotNull
   public static final Object plus_FjFbRPM/* $FF was: plus-FjFbRPM*/(Object a, E a) {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a instanceof List) {
            throw new AssertionError();
         }
      }

      Object var10000;
      if (a == null) {
         var10000 = constructor-impl(a);
      } else if (a instanceof ArrayList) {
         if (a == null) {
            throw new NullPointerException("null cannot be cast to non-null type java.util.ArrayList<E of kotlinx.coroutines.internal.InlineList>{ kotlin.collections.TypeAliasesKt.ArrayList<E of kotlinx.coroutines.internal.InlineList> }");
         }

         ((ArrayList)a).add(a);
         var10000 = constructor-impl(a);
      } else {
         ArrayList a = new ArrayList(4);
         a.add(a);
         a.add(a);
         var10000 = constructor-impl(a);
      }

      return var10000;
   }

   public static final void forEachReversed_impl/* $FF was: forEachReversed-impl*/(Object a, @NotNull Function1<? super E, Unit> a) {
      int a = false;
      if (a != null) {
         if (!(a instanceof ArrayList)) {
            a.invoke(a);
         } else {
            if (a == null) {
               throw new NullPointerException("null cannot be cast to non-null type java.util.ArrayList<E of kotlinx.coroutines.internal.InlineList>{ kotlin.collections.TypeAliasesKt.ArrayList<E of kotlinx.coroutines.internal.InlineList> }");
            }

            ArrayList a = (ArrayList)a;

            for(int a = a.size() - 1; -1 < a; --a) {
               a.invoke(a.get(a));
            }
         }

      }
   }

   public static String toString_impl/* $FF was: toString-impl*/(Object a) {
      return "InlineList(holder=" + a + ')';
   }

   public String toString() {
      return toString-impl(a.holder);
   }

   public static int hashCode_impl/* $FF was: hashCode-impl*/(Object a) {
      return a == null ? 0 : a.hashCode();
   }

   public int hashCode() {
      return hashCode-impl(a.holder);
   }

   public static boolean equals_impl/* $FF was: equals-impl*/(Object a, Object a) {
      if (!(a instanceof InlineList)) {
         return false;
      } else {
         return Intrinsics.areEqual(a, ((InlineList)a).unbox-impl());
      }
   }

   public boolean equals(Object a) {
      return equals-impl(a.holder, a);
   }

   // $FF: synthetic method
   private InlineList(Object a) {
      a.holder = a;
   }

   @NotNull
   public static <E> Object constructor_impl/* $FF was: constructor-impl*/(@Nullable Object a) {
      return a;
   }

   // $FF: synthetic method
   public static Object constructor_impl$default/* $FF was: constructor-impl$default*/(Object var0, int var1, DefaultConstructorMarker var2) {
      if ((var1 & 1) != 0) {
         var0 = null;
      }

      return constructor-impl(var0);
   }

   // $FF: synthetic method
   public static final InlineList box_impl/* $FF was: box-impl*/(Object a) {
      return new InlineList(a);
   }

   // $FF: synthetic method
   public final Object unbox_impl/* $FF was: unbox-impl*/() {
      return a.holder;
   }

   public static final boolean equals_impl0/* $FF was: equals-impl0*/(Object a, Object a) {
      return Intrinsics.areEqual(a, a);
   }
}
