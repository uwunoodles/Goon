package kotlinx.coroutines.internal;

import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.ThreadContextElement;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u00000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\u001a\u001a\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u0004H\u0000\u001a\u0010\u0010\u000f\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\rH\u0000\u001a\u001c\u0010\u0010\u001a\u0004\u0018\u00010\u00042\u0006\u0010\f\u001a\u00020\r2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0004H\u0000\"\u0010\u0010\u0000\u001a\u00020\u00018\u0000X\u0081\u0004¢\u0006\u0002\n\u0000\"$\u0010\u0002\u001a\u0018\u0012\u0006\u0012\u0004\u0018\u00010\u0004\u0012\u0004\u0012\u00020\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00040\u0003X\u0082\u0004¢\u0006\u0002\n\u0000\",\u0010\u0006\u001a \u0012\n\u0012\b\u0012\u0002\b\u0003\u0018\u00010\u0007\u0012\u0004\u0012\u00020\u0005\u0012\n\u0012\b\u0012\u0002\b\u0003\u0018\u00010\u00070\u0003X\u0082\u0004¢\u0006\u0002\n\u0000\" \u0010\b\u001a\u0014\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\t0\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0012"},
   d2 = {"NO_THREAD_ELEMENTS", "Lkotlinx/coroutines/internal/Symbol;", "countAll", "Lkotlin/Function2;", "", "Lkotlin/coroutines/CoroutineContext$Element;", "findOne", "Lkotlinx/coroutines/ThreadContextElement;", "updateState", "Lkotlinx/coroutines/internal/ThreadState;", "restoreThreadContext", "", "context", "Lkotlin/coroutines/CoroutineContext;", "oldState", "threadContextElements", "updateThreadContext", "countOrElement", "kotlinx-coroutines-core"}
)
public final class ThreadContextKt {
   @JvmField
   @NotNull
   public static final Symbol NO_THREAD_ELEMENTS = new Symbol("NO_THREAD_ELEMENTS");
   @NotNull
   private static final Function2<Object, CoroutineContext.Element, Object> countAll;
   @NotNull
   private static final Function2<ThreadContextElement<?>, CoroutineContext.Element, ThreadContextElement<?>> findOne;
   @NotNull
   private static final Function2<ThreadState, CoroutineContext.Element, ThreadState> updateState;

   @NotNull
   public static final Object threadContextElements(@NotNull CoroutineContext a) {
      Object var10000 = a.fold(0, countAll);
      Intrinsics.checkNotNull(var10000);
      return var10000;
   }

   @Nullable
   public static final Object updateThreadContext(@NotNull CoroutineContext a, @Nullable Object a) {
      Object var10000 = a;
      if (a == null) {
         var10000 = threadContextElements(a);
      }

      Object a = var10000;
      if (a == 0) {
         var10000 = NO_THREAD_ELEMENTS;
      } else if (a instanceof Integer) {
         var10000 = a.fold(new ThreadState(a, ((Number)a).intValue()), updateState);
      } else {
         ThreadContextElement a = (ThreadContextElement)a;
         var10000 = a.updateThreadContext(a);
      }

      return var10000;
   }

   public static final void restoreThreadContext(@NotNull CoroutineContext a, @Nullable Object a) {
      if (a != NO_THREAD_ELEMENTS) {
         if (a instanceof ThreadState) {
            ((ThreadState)a).restore(a);
         } else {
            Object var10000 = a.fold((Object)null, findOne);
            if (var10000 == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.ThreadContextElement<kotlin.Any?>");
            }

            ThreadContextElement a = (ThreadContextElement)var10000;
            a.restoreThreadContext(a, a);
         }

      }
   }

   static {
      countAll = (Function2)null.INSTANCE;
      findOne = (Function2)null.INSTANCE;
      updateState = (Function2)null.INSTANCE;
   }
}
