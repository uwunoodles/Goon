package kotlinx.coroutines.internal;

import java.util.concurrent.atomic.AtomicReferenceArray;
import kotlin.Metadata;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0000\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002B\r\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005J\u0006\u0010\b\u001a\u00020\u0004J\u0018\u0010\t\u001a\u0004\u0018\u00018\u00002\u0006\u0010\n\u001a\u00020\u0004H\u0086\u0002¢\u0006\u0002\u0010\u000bJ\u001d\u0010\f\u001a\u00020\r2\u0006\u0010\n\u001a\u00020\u00042\b\u0010\u000e\u001a\u0004\u0018\u00018\u0000¢\u0006\u0002\u0010\u000fR\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00028\u00000\u0007X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0010"},
   d2 = {"Lkotlinx/coroutines/internal/ResizableAtomicArray;", "T", "", "initialLength", "", "(I)V", "array", "Ljava/util/concurrent/atomic/AtomicReferenceArray;", "currentLength", "get", "index", "(I)Ljava/lang/Object;", "setSynchronized", "", "value", "(ILjava/lang/Object;)V", "kotlinx-coroutines-core"}
)
public final class ResizableAtomicArray<T> {
   @NotNull
   private volatile AtomicReferenceArray<T> array;

   public ResizableAtomicArray(int a) {
      a.array = new AtomicReferenceArray(a);
   }

   public final int currentLength() {
      return a.array.length();
   }

   @Nullable
   public final T get(int a) {
      AtomicReferenceArray a = a.array;
      return a < a.length() ? a.get(a) : null;
   }

   public final void setSynchronized(int a, @Nullable T a) {
      AtomicReferenceArray a = a.array;
      int a = a.length();
      if (a < a) {
         a.set(a, a);
      } else {
         AtomicReferenceArray a = new AtomicReferenceArray(RangesKt.coerceAtLeast(a + 1, 2 * a));

         for(int a = 0; a < a; ++a) {
            a.set(a, a.get(a));
         }

         a.set(a, a);
         a.array = a;
      }

   }
}
