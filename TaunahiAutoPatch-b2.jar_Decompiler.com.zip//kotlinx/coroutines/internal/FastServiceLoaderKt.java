package kotlinx.coroutines.internal;

import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\"\u0014\u0010\u0000\u001a\u00020\u0001X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
   d2 = {"ANDROID_DETECTED", "", "getANDROID_DETECTED", "()Z", "kotlinx-coroutines-core"}
)
public final class FastServiceLoaderKt {
   private static final boolean ANDROID_DETECTED;

   public static final boolean getANDROID_DETECTED() {
      return ANDROID_DETECTED;
   }

   static {
      Result.Companion var10000;
      Object var0;
      try {
         var10000 = Result.Companion;
         int a = false;
         var0 = Result.constructor-impl(Class.forName("android.os.Build"));
      } catch (Throwable var2) {
         var10000 = Result.Companion;
         var0 = Result.constructor-impl(ResultKt.createFailure(var2));
      }

      ANDROID_DETECTED = Result.isSuccess-impl(var0);
   }
}
