package kotlinx.coroutines.internal;

import java.util.Iterator;
import java.util.List;
import java.util.ServiceLoader;
import kotlin.Metadata;
import kotlin.jvm.JvmField;
import kotlin.sequences.SequencesKt;
import kotlinx.coroutines.MainCoroutineDispatcher;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\bÀ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0007\u001a\u00020\u0006H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\b"},
   d2 = {"Lkotlinx/coroutines/internal/MainDispatcherLoader;", "", "()V", "FAST_SERVICE_LOADER_ENABLED", "", "dispatcher", "Lkotlinx/coroutines/MainCoroutineDispatcher;", "loadMainDispatcher", "kotlinx-coroutines-core"}
)
public final class MainDispatcherLoader {
   @NotNull
   public static final MainDispatcherLoader INSTANCE = new MainDispatcherLoader();
   private static final boolean FAST_SERVICE_LOADER_ENABLED = SystemPropsKt.systemProp("kotlinx.coroutines.fast.service.loader", true);
   @JvmField
   @NotNull
   public static final MainCoroutineDispatcher dispatcher;

   private MainDispatcherLoader() {
   }

   private final MainCoroutineDispatcher loadMainDispatcher() {
      MainCoroutineDispatcher var1;
      try {
         List a = FAST_SERVICE_LOADER_ENABLED ? FastServiceLoader.INSTANCE.loadMainDispatcherFactory$kotlinx_coroutines_core() : SequencesKt.toList(SequencesKt.asSequence(ServiceLoader.load(MainDispatcherFactory.class, MainDispatcherFactory.class.getClassLoader()).iterator()));
         Iterable a = (Iterable)a;
         int a = false;
         Iterator a = a.iterator();
         Object var10000;
         if (!a.hasNext()) {
            var10000 = null;
         } else {
            Object a = a.next();
            if (!a.hasNext()) {
               var10000 = a;
            } else {
               MainDispatcherFactory a = (MainDispatcherFactory)a;
               int a = false;
               int a = a.getLoadPriority();

               while(true) {
                  Object a = a.next();
                  MainDispatcherFactory a = (MainDispatcherFactory)a;
                  int a = false;
                  int a = a.getLoadPriority();
                  if (a < a) {
                     a = a;
                     a = a;
                  }

                  if (!a.hasNext()) {
                     var10000 = a;
                     break;
                  }
               }
            }
         }

         MainCoroutineDispatcher var17;
         label30: {
            MainDispatcherFactory var16 = (MainDispatcherFactory)var10000;
            if (var16 != null) {
               var17 = MainDispatchersKt.tryCreateDispatcher(var16, a);
               if (var17 != null) {
                  break label30;
               }
            }

            var17 = (MainCoroutineDispatcher)MainDispatchersKt.createMissingDispatcher$default((Throwable)null, (String)null, 3, (Object)null);
         }

         var1 = var17;
      } catch (Throwable var11) {
         var1 = (MainCoroutineDispatcher)MainDispatchersKt.createMissingDispatcher$default(var11, (String)null, 2, (Object)null);
      }

      return var1;
   }

   static {
      dispatcher = INSTANCE.loadMainDispatcher();
   }
}
