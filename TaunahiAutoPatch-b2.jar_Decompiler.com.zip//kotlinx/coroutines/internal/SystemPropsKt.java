package kotlinx.coroutines.internal;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 4,
   xi = 48,
   d1 = {"kotlinx/coroutines/internal/SystemPropsKt__SystemPropsKt", "kotlinx/coroutines/internal/SystemPropsKt__SystemProps_commonKt"}
)
public final class SystemPropsKt {
   public static final int getAVAILABLE_PROCESSORS() {
      return SystemPropsKt__SystemPropsKt.getAVAILABLE_PROCESSORS();
   }

   @Nullable
   public static final String systemProp(@NotNull String a) {
      return SystemPropsKt__SystemPropsKt.systemProp(a);
   }

   public static final boolean systemProp(@NotNull String a, boolean a) {
      return SystemPropsKt__SystemProps_commonKt.systemProp(a, a);
   }

   public static final int systemProp(@NotNull String a, int a, int a, int a) {
      return SystemPropsKt__SystemProps_commonKt.systemProp(a, a, a, a);
   }

   // $FF: synthetic method
   public static int systemProp$default(String var0, int var1, int var2, int var3, int var4, Object var5) {
      return SystemPropsKt__SystemProps_commonKt.systemProp$default(var0, var1, var2, var3, var4, var5);
   }

   public static final long systemProp(@NotNull String a, long a, long a, long a) {
      return SystemPropsKt__SystemProps_commonKt.systemProp(a, a, a, a);
   }

   // $FF: synthetic method
   public static long systemProp$default(String var0, long var1, long var3, long var5, int var7, Object var8) {
      return SystemPropsKt__SystemProps_commonKt.systemProp$default(var0, var1, var3, var5, var7, var8);
   }
}
