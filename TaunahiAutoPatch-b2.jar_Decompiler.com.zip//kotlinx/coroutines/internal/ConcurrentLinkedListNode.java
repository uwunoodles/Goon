package kotlinx.coroutines.internal;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.DebugKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\b\r\n\u0002\u0010\u0000\n\u0002\b\t\b \u0018\u0000*\u000e\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u00028\u00000\u00002\u00020\u001aB\u0011\u0012\b\u0010\u0002\u001a\u0004\u0018\u00018\u0000¢\u0006\u0004\b\u0003\u0010\u0004J\r\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\r\u0010\t\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ \u0010\u000e\u001a\u0004\u0018\u00018\u00002\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\f0\u000bH\u0086\b¢\u0006\u0004\b\u000e\u0010\u000fJ\r\u0010\u0010\u001a\u00020\u0005¢\u0006\u0004\b\u0010\u0010\u0007J\u0015\u0010\u0012\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00028\u0000¢\u0006\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0014\u001a\u00020\b8F¢\u0006\u0006\u001a\u0004\b\u0014\u0010\nR\u0016\u0010\u0017\u001a\u0004\u0018\u00018\u00008BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0015\u0010\u0016R\u0013\u0010\u0019\u001a\u0004\u0018\u00018\u00008F¢\u0006\u0006\u001a\u0004\b\u0018\u0010\u0016R\u0016\u0010\u001d\u001a\u0004\u0018\u00010\u001a8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u001b\u0010\u001cR\u0013\u0010\u0002\u001a\u0004\u0018\u00018\u00008F¢\u0006\u0006\u001a\u0004\b\u001e\u0010\u0016R\u0014\u0010 \u001a\u00020\b8&X¦\u0004¢\u0006\u0006\u001a\u0004\b\u001f\u0010\nR\u0014\u0010\"\u001a\u00028\u00008BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b!\u0010\u0016¨\u0006#"},
   d2 = {"Lkotlinx/coroutines/internal/ConcurrentLinkedListNode;", "N", "prev", "ConcurrentLinkedListNode", "(Lkotlinx/coroutines/internal/ConcurrentLinkedListNode;)V", "", "cleanPrev", "()V", "", "markAsClosed", "()Z", "Lkotlin/Function0;", "", "onClosedAction", "nextOrIfClosed", "(Lkotlin/jvm/functions/Function0;)Lkotlinx/coroutines/internal/ConcurrentLinkedListNode;", "remove", "value", "trySetNext", "(Lkotlinx/coroutines/internal/ConcurrentLinkedListNode;)Z", "isTail", "getLeftmostAliveNode", "()Lkotlinx/coroutines/internal/ConcurrentLinkedListNode;", "leftmostAliveNode", "getNext", "next", "", "getNextOrClosed", "()Ljava/lang/Object;", "nextOrClosed", "getPrev", "getRemoved", "removed", "getRightmostAliveNode", "rightmostAliveNode", "kotlinx-coroutines-core"}
)
public abstract class ConcurrentLinkedListNode<N extends ConcurrentLinkedListNode<N>> {
   // $FF: synthetic field
   @NotNull
   private volatile Object _next = null;
   // $FF: synthetic field
   private static final AtomicReferenceFieldUpdater _next$FU = AtomicReferenceFieldUpdater.newUpdater(ConcurrentLinkedListNode.class, Object.class, "_next");
   // $FF: synthetic field
   @NotNull
   private volatile Object _prev;
   // $FF: synthetic field
   private static final AtomicReferenceFieldUpdater _prev$FU = AtomicReferenceFieldUpdater.newUpdater(ConcurrentLinkedListNode.class, Object.class, "_prev");

   public ConcurrentLinkedListNode(@Nullable N a) {
      a._prev = a;
   }

   private final Object getNextOrClosed() {
      return a._next;
   }

   @Nullable
   public final N nextOrIfClosed(@NotNull Function0 a) {
      int a = false;
      Object a = access$getNextOrClosed(a);
      int a = false;
      if (a == ConcurrentLinkedListKt.access$getCLOSED$p()) {
         a.invoke();
         throw new KotlinNothingValueException();
      } else {
         return (ConcurrentLinkedListNode)a;
      }
   }

   @Nullable
   public final N getNext() {
      int a = false;
      Object a = access$getNextOrClosed(a);
      int a = false;
      if (a == ConcurrentLinkedListKt.access$getCLOSED$p()) {
         int a = false;
         return null;
      } else {
         return (ConcurrentLinkedListNode)a;
      }
   }

   public final boolean trySetNext(@NotNull N a) {
      return _next$FU.compareAndSet(a, (Object)null, a);
   }

   public final boolean isTail() {
      return a.getNext() == null;
   }

   @Nullable
   public final N getPrev() {
      return (ConcurrentLinkedListNode)a._prev;
   }

   public final void cleanPrev() {
      _prev$FU.lazySet(a, (Object)null);
   }

   public final boolean markAsClosed() {
      return _next$FU.compareAndSet(a, (Object)null, ConcurrentLinkedListKt.access$getCLOSED$p());
   }

   public abstract boolean getRemoved();

   public final void remove() {
      boolean a;
      if (DebugKt.getASSERTIONS_ENABLED()) {
         a = false;
         if (!a.getRemoved()) {
            throw new AssertionError();
         }
      }

      if (DebugKt.getASSERTIONS_ENABLED()) {
         a = false;
         if (a.isTail()) {
            throw new AssertionError();
         }
      }

      ConcurrentLinkedListNode a;
      ConcurrentLinkedListNode a;
      do {
         do {
            a = a.getLeftmostAliveNode();
            a = a.getRightmostAliveNode();
            a._prev = a;
            if (a != null) {
               a._next = a;
            }
         } while(a.getRemoved());
      } while(a != null && a.getRemoved());

   }

   private final N getLeftmostAliveNode() {
      ConcurrentLinkedListNode a;
      for(a = a.getPrev(); a != null && a.getRemoved(); a = (ConcurrentLinkedListNode)a._prev) {
      }

      return a;
   }

   private final N getRightmostAliveNode() {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a.isTail()) {
            throw new AssertionError();
         }
      }

      ConcurrentLinkedListNode var10000 = a.getNext();
      Intrinsics.checkNotNull(var10000);

      ConcurrentLinkedListNode a;
      for(a = var10000; a.getRemoved(); a = var10000) {
         var10000 = a.getNext();
         Intrinsics.checkNotNull(var10000);
      }

      return a;
   }

   // $FF: synthetic method
   public static final Object access$getNextOrClosed(ConcurrentLinkedListNode a) {
      return a.getNextOrClosed();
   }
}
