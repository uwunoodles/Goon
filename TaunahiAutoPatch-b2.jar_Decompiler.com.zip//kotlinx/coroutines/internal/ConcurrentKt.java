package kotlinx.coroutines.internal;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.InlineMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000@\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010#\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a\u001d\u0010\u0002\u001a\b\u0012\u0004\u0012\u0002H\u00040\u0003\"\u0004\b\u0000\u0010\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0080\b\u001a\u0010\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0000\u001a\u001e\u0010\u000b\u001a\u0012\u0012\u0004\u0012\u0002H\u00040\fj\b\u0012\u0004\u0012\u0002H\u0004`\r\"\u0004\b\u0000\u0010\u0004H\u0000\u001a*\u0010\u000e\u001a\u0002H\u000f\"\u0004\b\u0000\u0010\u000f*\u00060\u0010j\u0002`\u00112\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\u000f0\u0013H\u0080\b¢\u0006\u0002\u0010\u0014\"\u0010\u0010\u0000\u001a\u0004\u0018\u00010\u0001X\u0082\u0004¢\u0006\u0002\n\u0000*\f\b\u0000\u0010\u0015\"\u00020\u00102\u00020\u0010¨\u0006\u0016"},
   d2 = {"REMOVE_FUTURE_ON_CANCEL", "Ljava/lang/reflect/Method;", "identitySet", "", "E", "expectedSize", "", "removeFutureOnCancel", "", "executor", "Ljava/util/concurrent/Executor;", "subscriberList", "", "Lkotlinx/coroutines/internal/SubscribersList;", "withLock", "T", "Ljava/util/concurrent/locks/ReentrantLock;", "Lkotlinx/coroutines/internal/ReentrantLock;", "action", "Lkotlin/Function0;", "(Ljava/util/concurrent/locks/ReentrantLock;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "ReentrantLock", "kotlinx-coroutines-core"}
)
public final class ConcurrentKt {
   @Nullable
   private static final Method REMOVE_FUTURE_ON_CANCEL;

   @NotNull
   public static final <E> List<E> subscriberList() {
      return (List)(new CopyOnWriteArrayList());
   }

   public static final <T> T withLock(@NotNull ReentrantLock a, @NotNull Function0<? extends T> a) {
      int a = false;
      Lock var3 = (Lock)a;
      var3.lock();

      Object var4;
      try {
         var4 = a.invoke();
      } finally {
         InlineMarker.finallyStart(1);
         var3.unlock();
         InlineMarker.finallyEnd(1);
      }

      return var4;
   }

   @NotNull
   public static final <E> Set<E> identitySet(int a) {
      int a = false;
      return Collections.newSetFromMap((Map)(new IdentityHashMap(a)));
   }

   public static final boolean removeFutureOnCancel(@NotNull Executor a) {
      try {
         ScheduledThreadPoolExecutor var10000 = a instanceof ScheduledThreadPoolExecutor ? (ScheduledThreadPoolExecutor)a : null;
         if ((a instanceof ScheduledThreadPoolExecutor ? (ScheduledThreadPoolExecutor)a : null) == null) {
            return false;
         } else {
            ScheduledThreadPoolExecutor a = var10000;
            Method var4 = REMOVE_FUTURE_ON_CANCEL;
            if (var4 == null) {
               return false;
            } else {
               Object[] var2 = new Object[]{true};
               var4.invoke(a, var2);
               return true;
            }
         }
      } catch (Throwable var3) {
         return false;
      }
   }

   /** @deprecated */
   // $FF: synthetic method
   public static void ReentrantLock$annotations() {
   }

   static {
      Method var0;
      try {
         Class[] var3 = new Class[]{Boolean.TYPE};
         var0 = ScheduledThreadPoolExecutor.class.getMethod("setRemoveOnCancelPolicy", var3);
      } catch (Throwable var2) {
         var0 = (Method)null;
      }

      REMOVE_FUTURE_ON_CANCEL = var0;
   }
}
