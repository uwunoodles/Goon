package kotlinx.coroutines.internal;

import kotlin.Metadata;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\n\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000*\u001e\b\u0000\u0010\u0000\u001a\u0004\b\u0000\u0010\u0001\"\b\u0012\u0004\u0012\u0002H\u00010\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0002¨\u0006\u0003"},
   d2 = {"CommonThreadLocal", "T", "Ljava/lang/ThreadLocal;", "kotlinx-coroutines-core"}
)
public final class ThreadLocalKt {
   /** @deprecated */
   // $FF: synthetic method
   public static void CommonThreadLocal$annotations() {
   }
}
