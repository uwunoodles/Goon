package kotlinx.coroutines.internal;

import kotlin.Metadata;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000\u001c\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\u001a\u0018\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0001H\u0000\u001a,\u0010\u0000\u001a\u00020\u00052\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u0005H\u0000\u001a,\u0010\u0000\u001a\u00020\b2\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\b2\b\b\u0002\u0010\u0006\u001a\u00020\b2\b\b\u0002\u0010\u0007\u001a\u00020\bH\u0000¨\u0006\t"},
   d2 = {"systemProp", "", "propertyName", "", "defaultValue", "", "minValue", "maxValue", "", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/internal/SystemPropsKt"
)
final class SystemPropsKt__SystemProps_commonKt {
   public static final boolean systemProp(@NotNull String a, boolean a) {
      String var10000 = SystemPropsKt.systemProp(a);
      return var10000 != null ? Boolean.parseBoolean(var10000) : a;
   }

   public static final int systemProp(@NotNull String a, int a, int a, int a) {
      return (int)SystemPropsKt.systemProp(a, (long)a, (long)a, (long)a);
   }

   // $FF: synthetic method
   public static int systemProp$default(String var0, int var1, int var2, int var3, int var4, Object var5) {
      if ((var4 & 4) != 0) {
         var2 = 1;
      }

      if ((var4 & 8) != 0) {
         var3 = Integer.MAX_VALUE;
      }

      return SystemPropsKt.systemProp(var0, var1, var2, var3);
   }

   public static final long systemProp(@NotNull String a, long a, long a, long a) {
      String var10000 = SystemPropsKt.systemProp(a);
      if (var10000 == null) {
         return a;
      } else {
         String a = var10000;
         Long var10 = StringsKt.toLongOrNull(a);
         if (var10 != null) {
            long a = var10;
            if (!(a <= a ? a <= a : false)) {
               throw new IllegalStateException(("System property '" + a + "' should be in range " + a + ".." + a + ", but is '" + a + '\'').toString());
            } else {
               return a;
            }
         } else {
            throw new IllegalStateException(("System property '" + a + "' has unrecognized value '" + a + '\'').toString());
         }
      }
   }

   // $FF: synthetic method
   public static long systemProp$default(String var0, long var1, long var3, long var5, int var7, Object var8) {
      if ((var7 & 4) != 0) {
         var3 = 1L;
      }

      if ((var7 & 8) != 0) {
         var5 = Long.MAX_VALUE;
      }

      return SystemPropsKt.systemProp(var0, var1, var3, var5);
   }
}
