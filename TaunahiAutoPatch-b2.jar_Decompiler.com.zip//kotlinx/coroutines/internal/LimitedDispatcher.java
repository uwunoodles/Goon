package kotlinx.coroutines.internal;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.jvm.functions.Function0;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlinx.coroutines.CoroutineExceptionHandlerKt;
import kotlinx.coroutines.DefaultExecutorKt;
import kotlinx.coroutines.Delay;
import kotlinx.coroutines.DisposableHandle;
import kotlinx.coroutines.ExperimentalCoroutinesApi;
import kotlinx.coroutines.InternalCoroutinesApi;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0000\u0018\u00002\u00020\u00012\u00060\u0002j\u0002`\u00032\u00020\u0004B\u0015\u0012\u0006\u0010\u0005\u001a\u00020\u0001\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\u0014\u0010\u000f\u001a\u00020\u00102\n\u0010\u0011\u001a\u00060\u0002j\u0002`\u0003H\u0002J\u0019\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0097Aø\u0001\u0000¢\u0006\u0002\u0010\u0016J\u001c\u0010\u0017\u001a\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u00192\n\u0010\u0011\u001a\u00060\u0002j\u0002`\u0003H\u0016J#\u0010\u001a\u001a\u00020\u00132\n\u0010\u0011\u001a\u00060\u0002j\u0002`\u00032\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00130\u001bH\u0082\bJ\u001c\u0010\u001c\u001a\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u00192\n\u0010\u0011\u001a\u00060\u0002j\u0002`\u0003H\u0017J%\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\u00152\n\u0010\u0011\u001a\u00060\u0002j\u0002`\u00032\u0006\u0010\u0018\u001a\u00020\u0019H\u0096\u0001J\u0010\u0010 \u001a\u00020\u00012\u0006\u0010\u0006\u001a\u00020\u0007H\u0017J\b\u0010!\u001a\u00020\u0013H\u0016J\u001f\u0010\"\u001a\u00020\u00132\u0006\u0010\u001f\u001a\u00020\u00152\f\u0010#\u001a\b\u0012\u0004\u0012\u00020\u00130$H\u0096\u0001J\b\u0010%\u001a\u00020\u0010H\u0002R\u000e\u0010\u0005\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0018\u0010\t\u001a\f\u0012\b\u0012\u00060\u0002j\u0002`\u00030\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\f\u001a\u00060\rj\u0002`\u000eX\u0082\u0004¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006&"},
   d2 = {"Lkotlinx/coroutines/internal/LimitedDispatcher;", "Lkotlinx/coroutines/CoroutineDispatcher;", "Ljava/lang/Runnable;", "Lkotlinx/coroutines/Runnable;", "Lkotlinx/coroutines/Delay;", "dispatcher", "parallelism", "", "(Lkotlinx/coroutines/CoroutineDispatcher;I)V", "queue", "Lkotlinx/coroutines/internal/LockFreeTaskQueue;", "runningWorkers", "workerAllocationLock", "", "Lkotlinx/coroutines/internal/SynchronizedObject;", "addAndTryDispatching", "", "block", "delay", "", "time", "", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "dispatch", "context", "Lkotlin/coroutines/CoroutineContext;", "dispatchInternal", "Lkotlin/Function0;", "dispatchYield", "invokeOnTimeout", "Lkotlinx/coroutines/DisposableHandle;", "timeMillis", "limitedParallelism", "run", "scheduleResumeAfterDelay", "continuation", "Lkotlinx/coroutines/CancellableContinuation;", "tryAllocateWorker", "kotlinx-coroutines-core"}
)
public final class LimitedDispatcher extends CoroutineDispatcher implements Runnable, Delay {
   @NotNull
   private final CoroutineDispatcher dispatcher;
   private final int parallelism;
   // $FF: synthetic field
   private final Delay $$delegate_0;
   private volatile int runningWorkers;
   @NotNull
   private final LockFreeTaskQueue<Runnable> queue;
   @NotNull
   private final Object workerAllocationLock;

   public LimitedDispatcher(@NotNull CoroutineDispatcher a, int a) {
      a.dispatcher = a;
      a.parallelism = a;
      Delay var10001 = a instanceof Delay ? (Delay)a : null;
      if ((a instanceof Delay ? (Delay)a : null) == null) {
         var10001 = DefaultExecutorKt.getDefaultDelay();
      }

      a.$$delegate_0 = var10001;
      a.queue = new LockFreeTaskQueue(false);
      a.workerAllocationLock = new Object();
   }

   /** @deprecated */
   @Deprecated(
      message = "Deprecated without replacement as an internal method never intended for public use",
      level = DeprecationLevel.ERROR
   )
   @Nullable
   public Object delay(long a, @NotNull Continuation<? super Unit> a) {
      return a.$$delegate_0.delay(a, a);
   }

   @NotNull
   public DisposableHandle invokeOnTimeout(long a, @NotNull Runnable a, @NotNull CoroutineContext a) {
      return a.$$delegate_0.invokeOnTimeout(a, a, a);
   }

   public void scheduleResumeAfterDelay(long a, @NotNull CancellableContinuation<? super Unit> a) {
      a.$$delegate_0.scheduleResumeAfterDelay(a, a);
   }

   @ExperimentalCoroutinesApi
   @NotNull
   public CoroutineDispatcher limitedParallelism(int a) {
      LimitedDispatcherKt.checkParallelism(a);
      return a >= a.parallelism ? (CoroutineDispatcher)a : super.limitedParallelism(a);
   }

   public void run() {
      int a = 0;

      while(true) {
         while(true) {
            Runnable a = (Runnable)a.queue.removeFirstOrNull();
            if (a == null) {
               Object a = a.workerAllocationLock;
               int a = false;
               synchronized(a){}

               try {
                  int a = false;
                  a.runningWorkers += -1;
                  int var10000 = a.runningWorkers;
                  if (a.queue.getSize() == 0) {
                     return;
                  }

                  ++a.runningWorkers;
                  var10000 = a.runningWorkers;
                  a = 0;
                  Unit var7 = Unit.INSTANCE;
               } finally {
                  ;
               }
            } else {
               try {
                  a.run();
               } catch (Throwable var10) {
                  CoroutineExceptionHandlerKt.handleCoroutineException((CoroutineContext)EmptyCoroutineContext.INSTANCE, var10);
               }

               ++a;
               if (a >= 16 && a.dispatcher.isDispatchNeeded((CoroutineContext)a)) {
                  a.dispatcher.dispatch((CoroutineContext)a, (Runnable)a);
                  return;
               }
            }
         }
      }
   }

   public void dispatch(@NotNull CoroutineContext a1, @NotNull Runnable a) {
      int a = false;
      if (!a.addAndTryDispatching(a) && a.tryAllocateWorker()) {
         int a = false;
         a.dispatcher.dispatch((CoroutineContext)a, (Runnable)a);
      }

   }

   @InternalCoroutinesApi
   public void dispatchYield(@NotNull CoroutineContext a1, @NotNull Runnable a) {
      int a = false;
      if (!a.addAndTryDispatching(a) && a.tryAllocateWorker()) {
         int a = false;
         a.dispatcher.dispatchYield((CoroutineContext)a, (Runnable)a);
      }

   }

   private final void dispatchInternal(Runnable a, Function0<Unit> a) {
      int a = false;
      if (!a.addAndTryDispatching(a)) {
         if (a.tryAllocateWorker()) {
            a.invoke();
         }
      }
   }

   private final boolean tryAllocateWorker() {
      Object a = a.workerAllocationLock;
      int a = false;
      synchronized(a){}

      boolean var5;
      try {
         int a = false;
         if (a.runningWorkers >= a.parallelism) {
            boolean var6 = false;
            return var6;
         }

         ++a.runningWorkers;
         int var10000 = a.runningWorkers;
         var5 = true;
      } finally {
         ;
      }

      return var5;
   }

   private final boolean addAndTryDispatching(Runnable a) {
      a.queue.addLast(a);
      return a.runningWorkers >= a.parallelism;
   }
}
