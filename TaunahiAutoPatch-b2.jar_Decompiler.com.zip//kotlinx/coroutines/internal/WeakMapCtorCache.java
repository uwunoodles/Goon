package kotlinx.coroutines.internal;

import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J*\u0010\u000b\u001a\u0014\u0012\u0004\u0012\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\b0\tj\u0002`\n2\u000e\u0010\f\u001a\n\u0012\u0006\b\u0001\u0012\u00020\b0\u0007H\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R4\u0010\u0005\u001a(\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\b0\u0007\u0012\u0016\u0012\u0014\u0012\u0004\u0012\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\b0\tj\u0002`\n0\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\r"},
   d2 = {"Lkotlinx/coroutines/internal/WeakMapCtorCache;", "Lkotlinx/coroutines/internal/CtorCache;", "()V", "cacheLock", "Ljava/util/concurrent/locks/ReentrantReadWriteLock;", "exceptionCtors", "Ljava/util/WeakHashMap;", "Ljava/lang/Class;", "", "Lkotlin/Function1;", "Lkotlinx/coroutines/internal/Ctor;", "get", "key", "kotlinx-coroutines-core"}
)
final class WeakMapCtorCache extends CtorCache {
   @NotNull
   public static final WeakMapCtorCache INSTANCE = new WeakMapCtorCache();
   @NotNull
   private static final ReentrantReadWriteLock cacheLock = new ReentrantReadWriteLock();
   @NotNull
   private static final WeakHashMap<Class<? extends Throwable>, Function1<Throwable, Throwable>> exceptionCtors = new WeakHashMap();

   private WeakMapCtorCache() {
   }

   @NotNull
   public Function1<Throwable, Throwable> get(@NotNull Class<? extends Throwable> a) {
      ReadLock var3 = cacheLock.readLock();
      var3.lock();

      boolean a;
      Function1 a;
      Function1 var10000;
      label207: {
         try {
            int a = false;
            var10000 = (Function1)exceptionCtors.get(a);
            if (var10000 == null) {
               Object var19 = null;
               break label207;
            }

            Function1 a = var10000;
            a = false;
            a = a;
         } finally {
            var3.unlock();
         }

         return a;
      }

      ReentrantReadWriteLock var2 = cacheLock;
      var3 = var2.readLock();
      int var20 = var2.getWriteHoldCount() == 0 ? var2.getReadHoldCount() : 0;

      for(int var21 = 0; var21 < var20; ++var21) {
         var3.unlock();
      }

      WriteLock var22 = var2.writeLock();
      var22.lock();

      Function1 var11;
      try {
         a = false;
         var10000 = (Function1)exceptionCtors.get(a);
         if (var10000 != null) {
            a = var10000;
            int a = false;
            Function1 var12 = a;
            return var12;
         }

         Function1 var9 = ExceptionsConstructorKt.access$createConstructor(a);
         int a = false;
         ((Map)exceptionCtors).put(a, var9);
         var11 = var9;
      } finally {
         for(int var24 = 0; var24 < var20; ++var24) {
            var3.lock();
         }

         var22.unlock();
      }

      return var11;
   }
}
