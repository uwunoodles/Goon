package kotlinx.coroutines.internal;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.CoroutineStackFrame;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.coroutines.CopyableThrowable;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.InternalCoroutinesApi;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000f\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0003\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010\u0001\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\b\u001a\u0014\u0010\u0006\u001a\u00060\u0007j\u0002`\b2\u0006\u0010\t\u001a\u00020\u0001H\u0007\u001a9\u0010\n\u001a\u0002H\u000b\"\b\b\u0000\u0010\u000b*\u00020\f2\u0006\u0010\r\u001a\u0002H\u000b2\u0006\u0010\u000e\u001a\u0002H\u000b2\u0010\u0010\u000f\u001a\f\u0012\b\u0012\u00060\u0007j\u0002`\b0\u0010H\u0002¢\u0006\u0002\u0010\u0011\u001a\u001e\u0010\u0012\u001a\f\u0012\b\u0012\u00060\u0007j\u0002`\b0\u00102\n\u0010\u0013\u001a\u00060\u0014j\u0002`\u0015H\u0002\u001a1\u0010\u0016\u001a\u00020\u00172\u0010\u0010\u0018\u001a\f\u0012\b\u0012\u00060\u0007j\u0002`\b0\u00192\u0010\u0010\u000e\u001a\f\u0012\b\u0012\u00060\u0007j\u0002`\b0\u0010H\u0002¢\u0006\u0002\u0010\u001a\u001a\u0019\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\fH\u0080Hø\u0001\u0000¢\u0006\u0002\u0010\u001e\u001a+\u0010\u001f\u001a\u0002H\u000b\"\b\b\u0000\u0010\u000b*\u00020\f2\u0006\u0010\u001d\u001a\u0002H\u000b2\n\u0010\u0013\u001a\u00060\u0014j\u0002`\u0015H\u0002¢\u0006\u0002\u0010 \u001a\u001f\u0010!\u001a\u0002H\u000b\"\b\b\u0000\u0010\u000b*\u00020\f2\u0006\u0010\u001d\u001a\u0002H\u000bH\u0000¢\u0006\u0002\u0010\"\u001a,\u0010!\u001a\u0002H\u000b\"\b\b\u0000\u0010\u000b*\u00020\f2\u0006\u0010\u001d\u001a\u0002H\u000b2\n\u0010\u0013\u001a\u0006\u0012\u0002\b\u00030#H\u0080\b¢\u0006\u0002\u0010$\u001a!\u0010%\u001a\u0004\u0018\u0001H\u000b\"\b\b\u0000\u0010\u000b*\u00020\f2\u0006\u0010\u001d\u001a\u0002H\u000bH\u0002¢\u0006\u0002\u0010\"\u001a \u0010&\u001a\u0002H\u000b\"\b\b\u0000\u0010\u000b*\u00020\f2\u0006\u0010\u001d\u001a\u0002H\u000bH\u0080\b¢\u0006\u0002\u0010\"\u001a\u001f\u0010'\u001a\u0002H\u000b\"\b\b\u0000\u0010\u000b*\u00020\f2\u0006\u0010\u001d\u001a\u0002H\u000bH\u0000¢\u0006\u0002\u0010\"\u001a1\u0010(\u001a\u0018\u0012\u0004\u0012\u0002H\u000b\u0012\u000e\u0012\f\u0012\b\u0012\u00060\u0007j\u0002`\b0\u00190)\"\b\b\u0000\u0010\u000b*\u00020\f*\u0002H\u000bH\u0002¢\u0006\u0002\u0010*\u001a\u001c\u0010+\u001a\u00020,*\u00060\u0007j\u0002`\b2\n\u0010-\u001a\u00060\u0007j\u0002`\bH\u0002\u001a#\u0010.\u001a\u00020/*\f\u0012\b\u0012\u00060\u0007j\u0002`\b0\u00192\u0006\u00100\u001a\u00020\u0001H\u0002¢\u0006\u0002\u00101\u001a\u0014\u00102\u001a\u00020\u0017*\u00020\f2\u0006\u0010\r\u001a\u00020\fH\u0000\u001a\u0010\u00103\u001a\u00020,*\u00060\u0007j\u0002`\bH\u0000\u001a\u001b\u00104\u001a\u0002H\u000b\"\b\b\u0000\u0010\u000b*\u00020\f*\u0002H\u000bH\u0002¢\u0006\u0002\u0010\"\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u0016\u0010\u0002\u001a\n \u0003*\u0004\u0018\u00010\u00010\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010\u0004\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u0016\u0010\u0005\u001a\n \u0003*\u0004\u0018\u00010\u00010\u0001X\u0082\u0004¢\u0006\u0002\n\u0000*\f\b\u0000\u00105\"\u00020\u00142\u00020\u0014*\f\b\u0000\u00106\"\u00020\u00072\u00020\u0007\u0082\u0002\u0004\n\u0002\b\u0019¨\u00067"},
   d2 = {"baseContinuationImplClass", "", "baseContinuationImplClassName", "kotlin.jvm.PlatformType", "stackTraceRecoveryClass", "stackTraceRecoveryClassName", "artificialFrame", "Ljava/lang/StackTraceElement;", "Lkotlinx/coroutines/internal/StackTraceElement;", "message", "createFinalException", "E", "", "cause", "result", "resultStackTrace", "Ljava/util/ArrayDeque;", "(Ljava/lang/Throwable;Ljava/lang/Throwable;Ljava/util/ArrayDeque;)Ljava/lang/Throwable;", "createStackTrace", "continuation", "Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;", "Lkotlinx/coroutines/internal/CoroutineStackFrame;", "mergeRecoveredTraces", "", "recoveredStacktrace", "", "([Ljava/lang/StackTraceElement;Ljava/util/ArrayDeque;)V", "recoverAndThrow", "", "exception", "(Ljava/lang/Throwable;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "recoverFromStackFrame", "(Ljava/lang/Throwable;Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;)Ljava/lang/Throwable;", "recoverStackTrace", "(Ljava/lang/Throwable;)Ljava/lang/Throwable;", "Lkotlin/coroutines/Continuation;", "(Ljava/lang/Throwable;Lkotlin/coroutines/Continuation;)Ljava/lang/Throwable;", "tryCopyAndVerify", "unwrap", "unwrapImpl", "causeAndStacktrace", "Lkotlin/Pair;", "(Ljava/lang/Throwable;)Lkotlin/Pair;", "elementWiseEquals", "", "e", "frameIndex", "", "methodName", "([Ljava/lang/StackTraceElement;Ljava/lang/String;)I", "initCause", "isArtificial", "sanitizeStackTrace", "CoroutineStackFrame", "StackTraceElement", "kotlinx-coroutines-core"}
)
public final class StackTraceRecoveryKt {
   @NotNull
   private static final String baseContinuationImplClass = "kotlin.coroutines.jvm.internal.BaseContinuationImpl";
   @NotNull
   private static final String stackTraceRecoveryClass = "kotlinx.coroutines.internal.StackTraceRecoveryKt";
   private static final String baseContinuationImplClassName;
   private static final String stackTraceRecoveryClassName;

   @NotNull
   public static final <E extends Throwable> E recoverStackTrace(@NotNull E a) {
      if (!DebugKt.getRECOVER_STACK_TRACES()) {
         return a;
      } else {
         Throwable var10000 = tryCopyAndVerify(a);
         if (var10000 == null) {
            return a;
         } else {
            Throwable a = var10000;
            return sanitizeStackTrace(a);
         }
      }
   }

   private static final <E extends Throwable> E sanitizeStackTrace(E a) {
      StackTraceElement[] a = a.getStackTrace();
      int a = a.length;
      int a = frameIndex(a, stackTraceRecoveryClassName);
      int a = a + 1;
      int a = frameIndex(a, baseContinuationImplClassName);
      int a = a == -1 ? 0 : a - a;
      int var8 = 0;
      int var9 = a - a - a;

      StackTraceElement[] var10;
      for(var10 = new StackTraceElement[var9]; var8 < var9; ++var8) {
         var10[var8] = var8 == 0 ? artificialFrame("Coroutine boundary") : a[a + var8 - 1];
      }

      a.setStackTrace(var10);
      return a;
   }

   @NotNull
   public static final <E extends Throwable> E recoverStackTrace(@NotNull E a, @NotNull Continuation<?> a) {
      int a = false;
      return DebugKt.getRECOVER_STACK_TRACES() && a instanceof CoroutineStackFrame ? access$recoverFromStackFrame(a, (CoroutineStackFrame)a) : a;
   }

   private static final <E extends Throwable> E recoverFromStackFrame(E a, CoroutineStackFrame a) {
      Pair var2 = causeAndStacktrace(a);
      Throwable a = (Throwable)var2.component1();
      StackTraceElement[] a = (StackTraceElement[])var2.component2();
      Throwable var10000 = tryCopyAndVerify(a);
      if (var10000 == null) {
         return a;
      } else {
         Throwable a = var10000;
         ArrayDeque a = createStackTrace(a);
         if (a.isEmpty()) {
            return a;
         } else {
            if (a != a) {
               mergeRecoveredTraces(a, a);
            }

            return createFinalException(a, a, a);
         }
      }
   }

   private static final <E extends Throwable> E tryCopyAndVerify(E a) {
      Throwable var10000 = ExceptionsConstructorKt.tryCopyException(a);
      if (var10000 == null) {
         return null;
      } else {
         Throwable a = var10000;
         return !(a instanceof CopyableThrowable) && !Intrinsics.areEqual((Object)a.getMessage(), (Object)a.getMessage()) ? null : a;
      }
   }

   private static final <E extends Throwable> E createFinalException(E a, E a, ArrayDeque<StackTraceElement> a) {
      a.addFirst(artificialFrame("Coroutine boundary"));
      StackTraceElement[] a = a.getStackTrace();
      int a = frameIndex(a, baseContinuationImplClassName);
      if (a == -1) {
         Collection a = (Collection)a;
         int a = false;
         Object[] var10001 = a.toArray(new StackTraceElement[0]);
         if (var10001 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
         } else {
            a.setStackTrace((StackTraceElement[])var10001);
            return a;
         }
      } else {
         StackTraceElement[] a = new StackTraceElement[a.size() + a];

         for(int a = 0; a < a; ++a) {
            a[a] = a[a];
         }

         Iterator var11 = a.iterator();

         int a;
         StackTraceElement a;
         for(int var7 = 0; var11.hasNext(); a[a + a] = a) {
            a = var7++;
            a = (StackTraceElement)var11.next();
         }

         a.setStackTrace(a);
         return a;
      }
   }

   private static final <E extends Throwable> Pair<E, StackTraceElement[]> causeAndStacktrace(E a) {
      Throwable a = a.getCause();
      Pair var10000;
      if (a != null && Intrinsics.areEqual((Object)a.getClass(), (Object)a.getClass())) {
         StackTraceElement[] a = a.getStackTrace();
         Object[] a = a;
         int a = false;
         int var5 = 0;
         int var6 = a.length;

         boolean var12;
         while(true) {
            if (var5 >= var6) {
               var12 = false;
               break;
            }

            Object a = a[var5];
            int a = false;
            if (isArtificial(a)) {
               var12 = true;
               break;
            }

            ++var5;
         }

         if (var12) {
            var10000 = TuplesKt.to(a, a);
         } else {
            int a = false;
            var10000 = TuplesKt.to(a, (Object[])(new StackTraceElement[0]));
         }
      } else {
         int a = false;
         var10000 = TuplesKt.to(a, (Object[])(new StackTraceElement[0]));
      }

      return var10000;
   }

   private static final void mergeRecoveredTraces(StackTraceElement[] a, ArrayDeque<StackTraceElement> a) {
      Object[] a = a;
      int a = false;
      int a = 0;
      int var6 = a.length;

      int var10000;
      while(true) {
         if (a >= var6) {
            var10000 = -1;
            break;
         }

         StackTraceElement a = a[a];
         int a = false;
         if (isArtificial(a)) {
            var10000 = a;
            break;
         }

         ++a;
      }

      int a = var10000 + 1;
      int a = a.length - 1;
      int a = a;
      if (a <= a) {
         while(true) {
            StackTraceElement a = a[a];
            if (elementWiseEquals(a, (StackTraceElement)a.getLast())) {
               a.removeLast();
            }

            a.addFirst(a[a]);
            if (a == a) {
               break;
            }

            --a;
         }
      }

   }

   @Nullable
   public static final Object recoverAndThrow(@NotNull Throwable a, @NotNull Continuation<?> a) {
      int a = false;
      if (!DebugKt.getRECOVER_STACK_TRACES()) {
         throw a;
      } else {
         int a = false;
         if (!(a instanceof CoroutineStackFrame)) {
            throw a;
         } else {
            throw access$recoverFromStackFrame(a, (CoroutineStackFrame)a);
         }
      }
   }

   private static final Object recoverAndThrow$$forInline(Throwable a, Continuation<?> a) {
      int a = false;
      if (!DebugKt.getRECOVER_STACK_TRACES()) {
         throw a;
      } else {
         InlineMarker.mark(0);
         int a = false;
         if (!(a instanceof CoroutineStackFrame)) {
            throw a;
         } else {
            throw access$recoverFromStackFrame(a, (CoroutineStackFrame)a);
         }
      }
   }

   @NotNull
   public static final <E extends Throwable> E unwrap(@NotNull E a) {
      int a = false;
      return !DebugKt.getRECOVER_STACK_TRACES() ? a : unwrapImpl(a);
   }

   @NotNull
   public static final <E extends Throwable> E unwrapImpl(@NotNull E a) {
      Throwable a = a.getCause();
      if (a != null && Intrinsics.areEqual((Object)a.getClass(), (Object)a.getClass())) {
         Object[] a = a.getStackTrace();
         int a = false;
         int var4 = 0;
         int var5 = a.length;

         boolean var10000;
         while(true) {
            if (var4 >= var5) {
               var10000 = false;
               break;
            }

            Object a = a[var4];
            int a = false;
            if (isArtificial(a)) {
               var10000 = true;
               break;
            }

            ++var4;
         }

         return var10000 ? a : a;
      } else {
         return a;
      }
   }

   private static final ArrayDeque<StackTraceElement> createStackTrace(CoroutineStackFrame a) {
      ArrayDeque a = new ArrayDeque();
      StackTraceElement var10000 = a.getStackTraceElement();
      if (var10000 != null) {
         StackTraceElement a = var10000;
         int a = false;
         a.add(a);
      }

      CoroutineStackFrame a = a;

      while(true) {
         CoroutineStackFrame var7 = a instanceof CoroutineStackFrame ? a : null;
         if ((a instanceof CoroutineStackFrame ? a : null) == null) {
            break;
         }

         var7 = var7.getCallerFrame();
         if (var7 == null) {
            break;
         }

         a = var7;
         var10000 = a.getStackTraceElement();
         if (var10000 != null) {
            StackTraceElement a = var10000;
            int a = false;
            a.add(a);
         }
      }

      return a;
   }

   @InternalCoroutinesApi
   @NotNull
   public static final StackTraceElement artificialFrame(@NotNull String a) {
      return new StackTraceElement("\b\b\b(" + a, "\b", "\b", -1);
   }

   public static final boolean isArtificial(@NotNull StackTraceElement a) {
      return StringsKt.startsWith$default(a.getClassName(), "\b\b\b", false, 2, (Object)null);
   }

   private static final int frameIndex(StackTraceElement[] a, String a) {
      Object[] a = a;
      int a = false;
      int a = 0;
      int var5 = a.length;

      int var10000;
      while(true) {
         if (a >= var5) {
            var10000 = -1;
            break;
         }

         StackTraceElement a = a[a];
         int a = false;
         if (Intrinsics.areEqual((Object)a, (Object)a.getClassName())) {
            var10000 = a;
            break;
         }

         ++a;
      }

      return var10000;
   }

   private static final boolean elementWiseEquals(StackTraceElement a, StackTraceElement a) {
      return a.getLineNumber() == a.getLineNumber() && Intrinsics.areEqual((Object)a.getMethodName(), (Object)a.getMethodName()) && Intrinsics.areEqual((Object)a.getFileName(), (Object)a.getFileName()) && Intrinsics.areEqual((Object)a.getClassName(), (Object)a.getClassName());
   }

   public static final void initCause(@NotNull Throwable a, @NotNull Throwable a) {
      a.initCause(a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static void CoroutineStackFrame$annotations() {
   }

   /** @deprecated */
   // $FF: synthetic method
   public static void StackTraceElement$annotations() {
   }

   // $FF: synthetic method
   public static final Throwable access$recoverFromStackFrame(Throwable a, CoroutineStackFrame a) {
      return recoverFromStackFrame(a, a);
   }

   static {
      Result.Companion var10000;
      Object var0;
      boolean a;
      try {
         var10000 = Result.Companion;
         a = false;
         var0 = Result.constructor-impl(Class.forName("kotlin.coroutines.jvm.internal.BaseContinuationImpl").getCanonicalName());
      } catch (Throwable var4) {
         var10000 = Result.Companion;
         var0 = Result.constructor-impl(ResultKt.createFailure(var4));
      }

      boolean a;
      Object var6;
      if (Result.exceptionOrNull-impl(var0) == null) {
         var6 = var0;
      } else {
         a = false;
         var6 = "kotlin.coroutines.jvm.internal.BaseContinuationImpl";
      }

      baseContinuationImplClassName = (String)var6;

      try {
         var10000 = Result.Companion;
         a = false;
         var0 = Result.constructor-impl(Class.forName("kotlinx.coroutines.internal.StackTraceRecoveryKt").getCanonicalName());
      } catch (Throwable var3) {
         var10000 = Result.Companion;
         var0 = Result.constructor-impl(ResultKt.createFailure(var3));
      }

      if (Result.exceptionOrNull-impl(var0) == null) {
         var6 = var0;
      } else {
         a = false;
         var6 = "kotlinx.coroutines.internal.StackTraceRecoveryKt";
      }

      stackTraceRecoveryClassName = (String)var6;
   }
}
