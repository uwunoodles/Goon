package kotlinx.coroutines.internal;

import java.util.Arrays;
import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.InternalCoroutinesApi;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0011\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0015\n\u0002\u0010\u0000\n\u0002\u0018\u0002\b\u0017\u0018\u0000*\u0012\b\u0000\u0010\u0003*\u00020\u0001*\b\u0012\u0004\u0012\u00028\u00000\u00022\u000605j\u0002`6B\u0007¢\u0006\u0004\b\u0004\u0010\u0005J\u0017\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00028\u0000H\u0001¢\u0006\u0004\b\b\u0010\tJ\u0015\u0010\n\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00028\u0000¢\u0006\u0004\b\n\u0010\tJ.\u0010\u000e\u001a\u00020\f2\u0006\u0010\u0006\u001a\u00028\u00002\u0014\u0010\r\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00018\u0000\u0012\u0004\u0012\u00020\f0\u000bH\u0086\b¢\u0006\u0004\b\u000e\u0010\u000fJ\r\u0010\u0010\u001a\u00020\u0007¢\u0006\u0004\b\u0010\u0010\u0005J2\u0010\u0015\u001a\u0004\u0018\u00018\u00002!\u0010\u0014\u001a\u001d\u0012\u0013\u0012\u00118\u0000¢\u0006\f\b\u0011\u0012\b\b\u0012\u0012\u0004\b\b(\u0013\u0012\u0004\u0012\u00020\f0\u000b¢\u0006\u0004\b\u0015\u0010\u0016J\u0011\u0010\u0017\u001a\u0004\u0018\u00018\u0000H\u0001¢\u0006\u0004\b\u0017\u0010\u0018J\u000f\u0010\u0019\u001a\u0004\u0018\u00018\u0000¢\u0006\u0004\b\u0019\u0010\u0018J\u0017\u0010\u001b\u001a\n\u0012\u0006\u0012\u0004\u0018\u00018\u00000\u001aH\u0002¢\u0006\u0004\b\u001b\u0010\u001cJ\u0015\u0010\u001d\u001a\u00020\f2\u0006\u0010\u0006\u001a\u00028\u0000¢\u0006\u0004\b\u001d\u0010\u001eJ\u0017\u0010!\u001a\u00028\u00002\u0006\u0010 \u001a\u00020\u001fH\u0001¢\u0006\u0004\b!\u0010\"J&\u0010#\u001a\u0004\u0018\u00018\u00002\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\f0\u000bH\u0086\b¢\u0006\u0004\b#\u0010\u0016J\u000f\u0010$\u001a\u0004\u0018\u00018\u0000¢\u0006\u0004\b$\u0010\u0018J\u0018\u0010&\u001a\u00020\u00072\u0006\u0010%\u001a\u00020\u001fH\u0082\u0010¢\u0006\u0004\b&\u0010'J\u0018\u0010(\u001a\u00020\u00072\u0006\u0010%\u001a\u00020\u001fH\u0082\u0010¢\u0006\u0004\b(\u0010'J\u001f\u0010*\u001a\u00020\u00072\u0006\u0010%\u001a\u00020\u001f2\u0006\u0010)\u001a\u00020\u001fH\u0002¢\u0006\u0004\b*\u0010+R \u0010,\u001a\f\u0012\u0006\u0012\u0004\u0018\u00018\u0000\u0018\u00010\u001a8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b,\u0010-R\u0011\u0010.\u001a\u00020\f8F¢\u0006\u0006\u001a\u0004\b.\u0010/R$\u00103\u001a\u00020\u001f2\u0006\u0010\u0013\u001a\u00020\u001f8F@BX\u0086\u000e¢\u0006\f\u001a\u0004\b0\u00101\"\u0004\b2\u0010'¨\u00064"},
   d2 = {"Lkotlinx/coroutines/internal/ThreadSafeHeap;", "Lkotlinx/coroutines/internal/ThreadSafeHeapNode;", "", "T", "ThreadSafeHeap", "()V", "node", "", "addImpl", "(Lkotlinx/coroutines/internal/ThreadSafeHeapNode;)V", "addLast", "Lkotlin/Function1;", "", "cond", "addLastIf", "(Lkotlinx/coroutines/internal/ThreadSafeHeapNode;Lkotlin/jvm/functions/Function1;)Z", "clear", "Lkotlin/ParameterName;", "name", "value", "predicate", "find", "(Lkotlin/jvm/functions/Function1;)Lkotlinx/coroutines/internal/ThreadSafeHeapNode;", "firstImpl", "()Lkotlinx/coroutines/internal/ThreadSafeHeapNode;", "peek", "", "realloc", "()[Lkotlinx/coroutines/internal/ThreadSafeHeapNode;", "remove", "(Lkotlinx/coroutines/internal/ThreadSafeHeapNode;)Z", "", "index", "removeAtImpl", "(I)Lkotlinx/coroutines/internal/ThreadSafeHeapNode;", "removeFirstIf", "removeFirstOrNull", "i", "siftDownFrom", "(I)V", "siftUpFrom", "j", "swap", "(II)V", "a", "[Lkotlinx/coroutines/internal/ThreadSafeHeapNode;", "isEmpty", "()Z", "getSize", "()I", "setSize", "size", "kotlinx-coroutines-core", "", "Lkotlinx/coroutines/internal/SynchronizedObject;"}
)
@InternalCoroutinesApi
public class ThreadSafeHeap<T extends ThreadSafeHeapNode & Comparable<? super T>> {
   @Nullable
   private T[] a;
   // $FF: synthetic field
   @NotNull
   private volatile int _size = 0;

   public final int getSize() {
      return a._size;
   }

   private final void setSize(int a) {
      a._size = a;
   }

   public final boolean isEmpty() {
      return a.getSize() == 0;
   }

   public final void clear() {
      int a = false;
      synchronized(a) {
         int a = false;
         ThreadSafeHeapNode[] var10000 = a.a;
         if (var10000 != null) {
            ArraysKt.fill$default(var10000, (Object)null, 0, 0, 6, (Object)null);
         }

         a._size = 0;
         Unit var5 = Unit.INSTANCE;
      }

   }

   @Nullable
   public final T find(@NotNull Function1<? super T, Boolean> param1) {
      // $FF: Couldn't be decompiled
   }

   @Nullable
   public final T peek() {
      // $FF: Couldn't be decompiled
   }

   @Nullable
   public final T removeFirstOrNull() {
      // $FF: Couldn't be decompiled
   }

   @Nullable
   public final T removeFirstIf(@NotNull Function1<? super T, Boolean> a) {
      int a = false;
      int a = false;
      synchronized(a){}
      boolean var10 = false;

      Object var8;
      label54: {
         ThreadSafeHeapNode var7;
         try {
            var10 = true;
            int a = false;
            ThreadSafeHeapNode var10000 = a.firstImpl();
            if (var10000 == null) {
               var8 = null;
               var10 = false;
               break label54;
            }

            ThreadSafeHeapNode a = var10000;
            var7 = (Boolean)a.invoke(a) ? a.removeAtImpl(0) : (ThreadSafeHeapNode)null;
            var10 = false;
         } finally {
            if (var10) {
               InlineMarker.finallyStart(1);
               InlineMarker.finallyEnd(1);
            }
         }

         InlineMarker.finallyStart(1);
         InlineMarker.finallyEnd(1);
         return var7;
      }

      InlineMarker.finallyStart(2);
      InlineMarker.finallyEnd(2);
      return (ThreadSafeHeapNode)var8;
   }

   public final void addLast(@NotNull T a) {
      int a = false;
      synchronized(a) {
         int a = false;
         a.addImpl(a);
         Unit var5 = Unit.INSTANCE;
      }

   }

   public final boolean addLastIf(@NotNull T param1, @NotNull Function1<? super T, Boolean> param2) {
      // $FF: Couldn't be decompiled
   }

   public final boolean remove(@NotNull T a) {
      int a = false;
      synchronized(a){}

      boolean var8;
      try {
         int a = false;
         boolean var10000;
         if (a.getHeap() == null) {
            var10000 = false;
         } else {
            int a = a.getIndex();
            if (DebugKt.getASSERTIONS_ENABLED()) {
               int a = false;
               if (a < 0) {
                  throw new AssertionError();
               }
            }

            a.removeAtImpl(a);
            var10000 = true;
         }

         var8 = var10000;
      } finally {
         ;
      }

      return var8;
   }

   @PublishedApi
   @Nullable
   public final T firstImpl() {
      ThreadSafeHeapNode[] var10000 = a.a;
      return var10000 != null ? var10000[0] : null;
   }

   @PublishedApi
   @NotNull
   public final T removeAtImpl(int a) {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a.getSize() <= 0) {
            throw new AssertionError();
         }
      }

      ThreadSafeHeapNode[] var10000 = a.a;
      Intrinsics.checkNotNull(var10000);
      ThreadSafeHeapNode[] a = var10000;
      int a = a.getSize();
      a.setSize(a + -1);
      ThreadSafeHeapNode var7;
      if (a < a.getSize()) {
         label34: {
            a.swap(a, a.getSize());
            a = (a - 1) / 2;
            if (a > 0) {
               var7 = a[a];
               Intrinsics.checkNotNull(a[a]);
               Comparable var8 = (Comparable)var7;
               ThreadSafeHeapNode var10001 = a[a];
               Intrinsics.checkNotNull(a[a]);
               if (var8.compareTo(var10001) < 0) {
                  a.swap(a, a);
                  a.siftUpFrom(a);
                  break label34;
               }
            }

            a.siftDownFrom(a);
         }
      }

      var7 = a[a.getSize()];
      Intrinsics.checkNotNull(var7);
      ThreadSafeHeapNode a = var7;
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a.getHeap() != a) {
            throw new AssertionError();
         }
      }

      a.setHeap((ThreadSafeHeap)null);
      a.setIndex(-1);
      a[a.getSize()] = null;
      return a;
   }

   @PublishedApi
   public final void addImpl(@NotNull T a) {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a.getHeap() != null) {
            throw new AssertionError();
         }
      }

      a.setHeap(a);
      ThreadSafeHeapNode[] a = a.realloc();
      int var4 = a.getSize();
      a.setSize(var4 + 1);
      a[var4] = a;
      a.setIndex(var4);
      a.siftUpFrom(var4);
   }

   private final void siftUpFrom(int a) {
      ThreadSafeHeap var2 = a;

      int a;
      for(int var3 = a; var3 > 0; var3 = a) {
         ThreadSafeHeapNode[] var10000 = var2.a;
         Intrinsics.checkNotNull(var10000);
         ThreadSafeHeapNode[] a = var10000;
         a = (var3 - 1) / 2;
         ThreadSafeHeapNode var8 = a[a];
         Intrinsics.checkNotNull(a[a]);
         Comparable var9 = (Comparable)var8;
         ThreadSafeHeapNode var10001 = a[var3];
         Intrinsics.checkNotNull(a[var3]);
         if (var9.compareTo(var10001) <= 0) {
            return;
         }

         var2.swap(var3, a);
         var2 = var2;
      }

   }

   private final void siftDownFrom(int a) {
      ThreadSafeHeap var2 = a;
      int var3 = a;

      while(true) {
         int a = 2 * var3 + 1;
         if (a >= var2.getSize()) {
            return;
         }

         ThreadSafeHeapNode[] var10000 = var2.a;
         Intrinsics.checkNotNull(var10000);
         ThreadSafeHeapNode[] a = var10000;
         ThreadSafeHeapNode var10001;
         ThreadSafeHeapNode var9;
         Comparable var10;
         if (a + 1 < var2.getSize()) {
            var9 = a[a + 1];
            Intrinsics.checkNotNull(a[a + 1]);
            var10 = (Comparable)var9;
            var10001 = a[a];
            Intrinsics.checkNotNull(a[a]);
            if (var10.compareTo(var10001) < 0) {
               ++a;
            }
         }

         var9 = a[var3];
         Intrinsics.checkNotNull(a[var3]);
         var10 = (Comparable)var9;
         var10001 = a[a];
         Intrinsics.checkNotNull(a[a]);
         if (var10.compareTo(var10001) <= 0) {
            return;
         }

         var2.swap(var3, a);
         var2 = var2;
         var3 = a;
      }
   }

   private final T[] realloc() {
      ThreadSafeHeapNode[] a = a.a;
      ThreadSafeHeapNode[] var10000;
      boolean a;
      if (a == null) {
         ThreadSafeHeapNode[] var2 = new ThreadSafeHeapNode[4];
         a = false;
         a.a = var2;
         var10000 = var2;
      } else if (a.getSize() >= a.length) {
         Object[] var6 = Arrays.copyOf(a, a.getSize() * 2);
         Intrinsics.checkNotNullExpressionValue(var6, "copyOf(this, newSize)");
         Object[] var5 = var6;
         ThreadSafeHeapNode[] a = (ThreadSafeHeapNode[])var5;
         a = false;
         a.a = a;
         var10000 = (ThreadSafeHeapNode[])var5;
      } else {
         var10000 = a;
      }

      return var10000;
   }

   private final void swap(int a, int a) {
      ThreadSafeHeapNode[] var10000 = a.a;
      Intrinsics.checkNotNull(var10000);
      ThreadSafeHeapNode[] a = var10000;
      ThreadSafeHeapNode var6 = a[a];
      Intrinsics.checkNotNull(a[a]);
      ThreadSafeHeapNode a = var6;
      var6 = a[a];
      Intrinsics.checkNotNull(a[a]);
      ThreadSafeHeapNode a = var6;
      a[a] = a;
      a[a] = a;
      a.setIndex(a);
      a.setIndex(a);
   }
}
