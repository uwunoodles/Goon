package kotlinx.coroutines.internal;

import java.util.concurrent.CancellationException;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;
import kotlinx.coroutines.CompletionStateKt;
import kotlinx.coroutines.CoroutineContextKt;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.DispatchedTask;
import kotlinx.coroutines.EventLoop;
import kotlinx.coroutines.InternalCoroutinesApi;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.ThreadLocalEventLoop;
import kotlinx.coroutines.UndispatchedCoroutine;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000J\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\u001a;\u0010\u0006\u001a\u00020\u0007*\u0006\u0012\u0002\b\u00030\b2\b\u0010\t\u001a\u0004\u0018\u00010\n2\u0006\u0010\u000b\u001a\u00020\f2\b\b\u0002\u0010\r\u001a\u00020\u00072\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000fH\u0082\b\u001aU\u0010\u0011\u001a\u00020\u0010\"\u0004\b\u0000\u0010\u0012*\b\u0012\u0004\u0012\u0002H\u00120\u00132\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u00120\u00152%\b\u0002\u0010\u0016\u001a\u001f\u0012\u0013\u0012\u00110\u0018¢\u0006\f\b\u0019\u0012\b\b\u001a\u0012\u0004\b\b(\u001b\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u0017H\u0007ø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001a\u0012\u0010\u001d\u001a\u00020\u0007*\b\u0012\u0004\u0012\u00020\u00100\bH\u0000\"\u0016\u0010\u0000\u001a\u00020\u00018\u0000X\u0081\u0004¢\u0006\b\n\u0000\u0012\u0004\b\u0002\u0010\u0003\"\u0016\u0010\u0004\u001a\u00020\u00018\u0002X\u0083\u0004¢\u0006\b\n\u0000\u0012\u0004\b\u0005\u0010\u0003\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001e"},
   d2 = {"REUSABLE_CLAIMED", "Lkotlinx/coroutines/internal/Symbol;", "getREUSABLE_CLAIMED$annotations", "()V", "UNDEFINED", "getUNDEFINED$annotations", "executeUnconfined", "", "Lkotlinx/coroutines/internal/DispatchedContinuation;", "contState", "", "mode", "", "doYield", "block", "Lkotlin/Function0;", "", "resumeCancellableWith", "T", "Lkotlin/coroutines/Continuation;", "result", "Lkotlin/Result;", "onCancellation", "Lkotlin/Function1;", "", "Lkotlin/ParameterName;", "name", "cause", "(Lkotlin/coroutines/Continuation;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)V", "yieldUndispatched", "kotlinx-coroutines-core"}
)
public final class DispatchedContinuationKt {
   @NotNull
   private static final Symbol UNDEFINED = new Symbol("UNDEFINED");
   @JvmField
   @NotNull
   public static final Symbol REUSABLE_CLAIMED = new Symbol("REUSABLE_CLAIMED");

   /** @deprecated */
   // $FF: synthetic method
   private static void getUNDEFINED$annotations() {
   }

   /** @deprecated */
   // $FF: synthetic method
   public static void getREUSABLE_CLAIMED$annotations() {
   }

   @InternalCoroutinesApi
   public static final <T> void resumeCancellableWith(@NotNull Continuation<? super T> a, @NotNull Object a, @Nullable Function1<? super Throwable, Unit> a) {
      if (a instanceof DispatchedContinuation) {
         DispatchedContinuation a = (DispatchedContinuation)a;
         int a = false;
         Object a = CompletionStateKt.toState(a, a);
         if (a.dispatcher.isDispatchNeeded(a.getContext())) {
            a._state = a;
            a.resumeMode = 1;
            a.dispatcher.dispatch(a.getContext(), (Runnable)a);
         } else {
            int a = 1;
            boolean a = false;
            int a = false;
            if (DebugKt.getASSERTIONS_ENABLED()) {
               int a = false;
               if (false) {
                  throw new AssertionError();
               }
            }

            EventLoop a = ThreadLocalEventLoop.INSTANCE.getEventLoop$kotlinx_coroutines_core();
            if (a.isUnconfinedLoopActive()) {
               a._state = a;
               a.resumeMode = a;
               a.dispatchUnconfined((DispatchedTask)a);
            } else {
               DispatchedTask a = (DispatchedTask)a;
               int a = false;
               a.incrementUseCount(true);

               try {
                  int a = false;
                  int a = false;
                  Job a = (Job)a.getContext().get((CoroutineContext.Key)Job.Key);
                  boolean var10000;
                  if (a != null && !a.isActive()) {
                     CancellationException a = a.getCancellationException();
                     a.cancelCompletedResult$kotlinx_coroutines_core(a, (Throwable)a);
                     Continuation var34 = (Continuation)a;
                     Result.Companion var10001 = Result.Companion;
                     var34.resumeWith(Result.constructor-impl(ResultKt.createFailure((Throwable)a)));
                     var10000 = true;
                  } else {
                     var10000 = false;
                  }

                  if (!var10000) {
                     DispatchedContinuation a = a;
                     a = false;
                     Continuation a = a.continuation;
                     Object a = a.countOrElement;
                     int a = false;
                     CoroutineContext a = a.getContext();
                     Object a = ThreadContextKt.updateThreadContext(a, a);
                     UndispatchedCoroutine a = a != ThreadContextKt.NO_THREAD_ELEMENTS ? CoroutineContextKt.updateUndispatchedCompletion(a, a, a) : (UndispatchedCoroutine)null;

                     try {
                        int a = false;
                        a.continuation.resumeWith(a);
                        Unit var37 = Unit.INSTANCE;
                     } finally {
                        if (a == null || a.clearThreadContext()) {
                           ThreadContextKt.restoreThreadContext(a, a);
                        }

                     }
                  }

                  while(a.processUnconfinedEvent()) {
                  }
               } catch (Throwable var31) {
                  a.handleFatalException(var31, (Throwable)null);
               } finally {
                  a.decrementUseCount(true);
               }
            }
         }
      } else {
         a.resumeWith(a);
      }

   }

   // $FF: synthetic method
   public static void resumeCancellableWith$default(Continuation var0, Object var1, Function1 var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = null;
      }

      resumeCancellableWith(var0, var1, var2);
   }

   public static final boolean yieldUndispatched(@NotNull DispatchedContinuation<? super Unit> a) {
      Unit a = Unit.INSTANCE;
      byte a = 1;
      boolean a = true;
      int a = false;
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (false) {
            throw new AssertionError();
         }
      }

      EventLoop a = ThreadLocalEventLoop.INSTANCE.getEventLoop$kotlinx_coroutines_core();
      boolean var10000;
      if (a.isUnconfinedQueueEmpty()) {
         var10000 = false;
      } else if (a.isUnconfinedLoopActive()) {
         a._state = a;
         a.resumeMode = a;
         a.dispatchUnconfined((DispatchedTask)a);
         var10000 = true;
      } else {
         DispatchedTask a = (DispatchedTask)a;
         int a = false;
         a.incrementUseCount(true);

         try {
            int a = false;
            a.run();

            while(a.processUnconfinedEvent()) {
            }
         } catch (Throwable var13) {
            a.handleFatalException(var13, (Throwable)null);
         } finally {
            a.decrementUseCount(true);
         }

         var10000 = false;
      }

      return var10000;
   }

   private static final boolean executeUnconfined(DispatchedContinuation<?> a, Object a, int a, boolean a, Function0<Unit> a) {
      int a = false;
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a == -1) {
            throw new AssertionError();
         }
      }

      EventLoop a = ThreadLocalEventLoop.INSTANCE.getEventLoop$kotlinx_coroutines_core();
      if (a && a.isUnconfinedQueueEmpty()) {
         return false;
      } else {
         boolean var10000;
         if (a.isUnconfinedLoopActive()) {
            a._state = a;
            a.resumeMode = a;
            a.dispatchUnconfined((DispatchedTask)a);
            var10000 = true;
         } else {
            DispatchedTask a = (DispatchedTask)a;
            int a = false;
            a.incrementUseCount(true);

            try {
               a.invoke();

               while(a.processUnconfinedEvent()) {
               }
            } catch (Throwable var12) {
               a.handleFatalException(var12, (Throwable)null);
            } finally {
               InlineMarker.finallyStart(1);
               a.decrementUseCount(true);
               InlineMarker.finallyEnd(1);
            }

            var10000 = false;
         }

         return var10000;
      }
   }

   // $FF: synthetic method
   static boolean executeUnconfined$default(DispatchedContinuation a, Object a, int a, boolean a, Function0 a, int var5, Object var6) {
      if ((var5 & 4) != 0) {
         a = false;
      }

      int a = false;
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a == -1) {
            throw new AssertionError();
         }
      }

      EventLoop a = ThreadLocalEventLoop.INSTANCE.getEventLoop$kotlinx_coroutines_core();
      if (a && a.isUnconfinedQueueEmpty()) {
         return false;
      } else {
         boolean var10000;
         if (a.isUnconfinedLoopActive()) {
            a._state = a;
            a.resumeMode = a;
            a.dispatchUnconfined((DispatchedTask)a);
            var10000 = true;
         } else {
            DispatchedTask a = (DispatchedTask)a;
            int a = false;
            a.incrementUseCount(true);

            try {
               a.invoke();

               while(a.processUnconfinedEvent()) {
               }
            } catch (Throwable var12) {
               a.handleFatalException(var12, (Throwable)null);
            } finally {
               InlineMarker.finallyStart(1);
               a.decrementUseCount(true);
               InlineMarker.finallyEnd(1);
            }

            var10000 = false;
         }

         return var10000;
      }
   }

   // $FF: synthetic method
   public static final Symbol access$getUNDEFINED$p() {
      return UNDEFINED;
   }
}
