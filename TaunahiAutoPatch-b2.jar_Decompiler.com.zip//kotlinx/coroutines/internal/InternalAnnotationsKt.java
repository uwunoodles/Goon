package kotlinx.coroutines.internal;

import kotlin.Metadata;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000*\f\b\u0000\u0010\u0000\"\u00020\u00012\u00020\u0001¨\u0006\u0002"},
   d2 = {"IgnoreJreRequirement", "Lorg/codehaus/mojo/animal_sniffer/IgnoreJRERequirement;", "kotlinx-coroutines-core"}
)
public final class InternalAnnotationsKt {
   /** @deprecated */
   // $FF: synthetic method
   public static void IgnoreJreRequirement$annotations() {
   }
}
