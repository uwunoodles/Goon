package kotlinx.coroutines.internal;

import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlinx.coroutines.Delay;
import kotlinx.coroutines.DisposableHandle;
import kotlinx.coroutines.MainCoroutineDispatcher;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0001\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0002\u0018\u00002\u00020\u00012\u00020\u0002B\u001b\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\u0002\u0010\u0007J\u0019\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u000fJ\u001c\u0010\u0010\u001a\u00020\f2\u0006\u0010\u0011\u001a\u00020\u00122\n\u0010\u0013\u001a\u00060\u0014j\u0002`\u0015H\u0016J$\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u000e2\n\u0010\u0013\u001a\u00060\u0014j\u0002`\u00152\u0006\u0010\u0011\u001a\u00020\u0012H\u0016J\u0010\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u0011\u001a\u00020\u0012H\u0016J\u0010\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001eH\u0016J\b\u0010\u001f\u001a\u00020\fH\u0002J\u001e\u0010 \u001a\u00020\f2\u0006\u0010\u0018\u001a\u00020\u000e2\f\u0010!\u001a\b\u0012\u0004\u0012\u00020#0\"H\u0016J\b\u0010$\u001a\u00020\u0006H\u0016R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\u00020\u00018VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\t\u0010\n\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006%"},
   d2 = {"Lkotlinx/coroutines/internal/MissingMainCoroutineDispatcher;", "Lkotlinx/coroutines/MainCoroutineDispatcher;", "Lkotlinx/coroutines/Delay;", "cause", "", "errorHint", "", "(Ljava/lang/Throwable;Ljava/lang/String;)V", "immediate", "getImmediate", "()Lkotlinx/coroutines/MainCoroutineDispatcher;", "delay", "", "time", "", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "dispatch", "context", "Lkotlin/coroutines/CoroutineContext;", "block", "Ljava/lang/Runnable;", "Lkotlinx/coroutines/Runnable;", "invokeOnTimeout", "Lkotlinx/coroutines/DisposableHandle;", "timeMillis", "isDispatchNeeded", "", "limitedParallelism", "Lkotlinx/coroutines/CoroutineDispatcher;", "parallelism", "", "missing", "scheduleResumeAfterDelay", "continuation", "Lkotlinx/coroutines/CancellableContinuation;", "", "toString", "kotlinx-coroutines-core"}
)
final class MissingMainCoroutineDispatcher extends MainCoroutineDispatcher implements Delay {
   @Nullable
   private final Throwable cause;
   @Nullable
   private final String errorHint;

   public MissingMainCoroutineDispatcher(@Nullable Throwable a, @Nullable String a) {
      a.cause = a;
      a.errorHint = a;
   }

   // $FF: synthetic method
   public MissingMainCoroutineDispatcher(Throwable var1, String var2, int var3, DefaultConstructorMarker var4) {
      if ((var3 & 2) != 0) {
         var2 = null;
      }

      this(var1, var2);
   }

   @NotNull
   public MainCoroutineDispatcher getImmediate() {
      return (MainCoroutineDispatcher)a;
   }

   public boolean isDispatchNeeded(@NotNull CoroutineContext a1) {
      a.missing();
      throw new KotlinNothingValueException();
   }

   @NotNull
   public CoroutineDispatcher limitedParallelism(int a1) {
      a.missing();
      throw new KotlinNothingValueException();
   }

   @Nullable
   public Object delay(long a1, @NotNull Continuation<?> a2) {
      a.missing();
      throw new KotlinNothingValueException();
   }

   @NotNull
   public DisposableHandle invokeOnTimeout(long a1, @NotNull Runnable a2, @NotNull CoroutineContext a3) {
      a.missing();
      throw new KotlinNothingValueException();
   }

   @NotNull
   public Void dispatch(@NotNull CoroutineContext a1, @NotNull Runnable a2) {
      a.missing();
      throw new KotlinNothingValueException();
   }

   @NotNull
   public Void scheduleResumeAfterDelay(long a1, @NotNull CancellableContinuation<? super Unit> a2) {
      a.missing();
      throw new KotlinNothingValueException();
   }

   private final Void missing() {
      if (a.cause == null) {
         MainDispatchersKt.throwMissingMainDispatcherException();
         throw new KotlinNothingValueException();
      } else {
         StringBuilder var10000;
         String var10001;
         label14: {
            var10000 = (new StringBuilder()).append("Module with the Main dispatcher had failed to initialize");
            var10001 = a.errorHint;
            if (var10001 != null) {
               String a = var10001;
               StringBuilder var4 = var10000;
               int a = false;
               var10001 = ". " + a;
               var10000 = var4;
               if (var10001 != null) {
                  break label14;
               }
            }

            var10001 = "";
         }

         String a = var10000.append(var10001).toString();
         throw new IllegalStateException(a, a.cause);
      }
   }

   @NotNull
   public String toString() {
      return "Dispatchers.Main[missing" + (a.cause != null ? ", cause=" + a.cause : "") + ']';
   }
}
