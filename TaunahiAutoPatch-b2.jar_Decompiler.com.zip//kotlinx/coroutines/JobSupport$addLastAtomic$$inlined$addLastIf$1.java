package kotlinx.coroutines;

import kotlin.Metadata;
import kotlinx.coroutines.internal.LockFreeLinkedListKt;
import kotlinx.coroutines.internal.LockFreeLinkedListNode;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0016\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\u0010\u0004\u001a\u00060\u0005j\u0002`\u0006H\u0016¨\u0006\u0007¸\u0006\u0000"},
   d2 = {"kotlinx/coroutines/internal/LockFreeLinkedListNode$makeCondAddOp$1", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode$CondAddOp;", "prepare", "", "affected", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "Lkotlinx/coroutines/internal/Node;", "kotlinx-coroutines-core"}
)
public final class JobSupport$addLastAtomic$$inlined$addLastIf$1 extends LockFreeLinkedListNode.CondAddOp {
   // $FF: synthetic field
   final JobSupport this$0;
   // $FF: synthetic field
   final Object $expect$inlined;

   public JobSupport$addLastAtomic$$inlined$addLastIf$1(LockFreeLinkedListNode a, JobSupport var2, Object var3) {
      super(a);
      a.this$0 = var2;
      a.$expect$inlined = var3;
   }

   @Nullable
   public Object prepare(@NotNull LockFreeLinkedListNode a1) {
      int a = false;
      return a.this$0.getState$kotlinx_coroutines_core() == a.$expect$inlined ? null : LockFreeLinkedListKt.getCONDITION_FALSE();
   }
}
