package kotlinx.coroutines.flow;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.flow.internal.ChannelFlowOperatorImpl;
import kotlinx.coroutines.flow.internal.FusibleFlow;
import org.jetbrains.annotations.NotNull;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000&\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a\u0015\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0002¢\u0006\u0002\b\u0004\u001a(\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00070\u0006\"\u0004\b\u0000\u0010\u0007*\b\u0012\u0004\u0012\u0002H\u00070\u00062\b\b\u0002\u0010\b\u001a\u00020\tH\u0007\u001a0\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00070\u0006\"\u0004\b\u0000\u0010\u0007*\b\u0012\u0004\u0012\u0002H\u00070\u00062\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u000b\u001a\u001c\u0010\f\u001a\b\u0012\u0004\u0012\u0002H\u00070\u0006\"\u0004\b\u0000\u0010\u0007*\b\u0012\u0004\u0012\u0002H\u00070\u0006\u001a\u001c\u0010\r\u001a\b\u0012\u0004\u0012\u0002H\u00070\u0006\"\u0004\b\u0000\u0010\u0007*\b\u0012\u0004\u0012\u0002H\u00070\u0006\u001a$\u0010\u000e\u001a\b\u0012\u0004\u0012\u0002H\u00070\u0006\"\u0004\b\u0000\u0010\u0007*\b\u0012\u0004\u0012\u0002H\u00070\u00062\u0006\u0010\u0002\u001a\u00020\u0003¨\u0006\u000f"},
   d2 = {"checkFlowContext", "", "context", "Lkotlin/coroutines/CoroutineContext;", "checkFlowContext$FlowKt__ContextKt", "buffer", "Lkotlinx/coroutines/flow/Flow;", "T", "capacity", "", "onBufferOverflow", "Lkotlinx/coroutines/channels/BufferOverflow;", "cancellable", "conflate", "flowOn", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/flow/FlowKt"
)
final class FlowKt__ContextKt {
   @NotNull
   public static final <T> Flow<T> buffer(@NotNull Flow<? extends T> a, int a, @NotNull BufferOverflow a) {
      boolean a;
      String var6;
      if (a < 0 && a != -2 && a != -1) {
         a = false;
         var6 = "Buffer size should be non-negative, BUFFERED, or CONFLATED, but was " + a;
         throw new IllegalArgumentException(var6.toString());
      } else if (a == -1 && a != BufferOverflow.SUSPEND) {
         a = false;
         var6 = "CONFLATED capacity cannot be used with non-default onBufferOverflow";
         throw new IllegalArgumentException(var6.toString());
      } else {
         int a = a;
         BufferOverflow a = a;
         if (a == -1) {
            a = 0;
            a = BufferOverflow.DROP_OLDEST;
         }

         return a instanceof FusibleFlow ? FusibleFlow.DefaultImpls.fuse$default((FusibleFlow)a, (CoroutineContext)null, a, a, 1, (Object)null) : (Flow)(new ChannelFlowOperatorImpl(a, (CoroutineContext)null, a, a, 2, (DefaultConstructorMarker)null));
      }
   }

   // $FF: synthetic method
   public static Flow buffer$default(Flow var0, int var1, BufferOverflow var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = -2;
      }

      if ((var3 & 2) != 0) {
         var2 = BufferOverflow.SUSPEND;
      }

      return FlowKt.buffer(var0, var1, var2);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.4.0, binary compatibility with earlier versions",
      level = DeprecationLevel.HIDDEN
   )
   public static final Flow buffer(Flow a, int a) {
      return FlowKt.buffer$default(a, a, (BufferOverflow)null, 2, (Object)null);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static Flow buffer$default(Flow var0, int var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = -2;
      }

      return FlowKt.buffer(var0, var1);
   }

   @NotNull
   public static final <T> Flow<T> conflate(@NotNull Flow<? extends T> a) {
      return FlowKt.buffer$default(a, -1, (BufferOverflow)null, 2, (Object)null);
   }

   @NotNull
   public static final <T> Flow<T> flowOn(@NotNull Flow<? extends T> a, @NotNull CoroutineContext a) {
      checkFlowContext$FlowKt__ContextKt(a);
      return Intrinsics.areEqual((Object)a, (Object)EmptyCoroutineContext.INSTANCE) ? a : (a instanceof FusibleFlow ? FusibleFlow.DefaultImpls.fuse$default((FusibleFlow)a, a, 0, (BufferOverflow)null, 6, (Object)null) : (Flow)(new ChannelFlowOperatorImpl(a, a, 0, (BufferOverflow)null, 12, (DefaultConstructorMarker)null)));
   }

   @NotNull
   public static final <T> Flow<T> cancellable(@NotNull Flow<? extends T> a) {
      return a instanceof CancellableFlow ? a : (Flow)(new CancellableFlowImpl(a));
   }

   private static final void checkFlowContext$FlowKt__ContextKt(CoroutineContext a) {
      if (a.get((CoroutineContext.Key)Job.Key) != null) {
         int a = false;
         String var2 = "Flow context cannot contain job in it. Had " + a;
         throw new IllegalArgumentException(var2.toString());
      }
   }
}
