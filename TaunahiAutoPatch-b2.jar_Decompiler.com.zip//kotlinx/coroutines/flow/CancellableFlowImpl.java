package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlinx.coroutines.JobKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0002\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B\u0013\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004¢\u0006\u0002\u0010\u0005J\u001f\u0010\u0006\u001a\u00020\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u00028\u00000\tH\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\nR\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004X\u0082\u0004¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u000b"},
   d2 = {"Lkotlinx/coroutines/flow/CancellableFlowImpl;", "T", "Lkotlinx/coroutines/flow/CancellableFlow;", "flow", "Lkotlinx/coroutines/flow/Flow;", "(Lkotlinx/coroutines/flow/Flow;)V", "collect", "", "collector", "Lkotlinx/coroutines/flow/FlowCollector;", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
final class CancellableFlowImpl<T> implements CancellableFlow<T> {
   @NotNull
   private final Flow<T> flow;

   public CancellableFlowImpl(@NotNull Flow<? extends T> a) {
      a.flow = a;
   }

   @Nullable
   public Object collect(@NotNull final FlowCollector<? super T> a, @NotNull Continuation<? super Unit> a) {
      Object var10000 = a.flow.collect((FlowCollector)(new FlowCollector() {
         @Nullable
         public final Object emit(T axx, @NotNull Continuation<? super Unit> var2) {
            Object axxxxx;
            label20: {
               if (var2 instanceof <undefinedtype>) {
                  axxxxx = (<undefinedtype>)var2;
                  if ((((<undefinedtype>)axxxxx).label & Integer.MIN_VALUE) != 0) {
                     ((<undefinedtype>)axxxxx).label -= Integer.MIN_VALUE;
                     break label20;
                  }
               }

               axxxxx = new ContinuationImpl(var2) {
                  // $FF: synthetic field
                  Object result;
                  int label;

                  @Nullable
                  public final Object invokeSuspend(@NotNull Object axxx) {
                     axx.result = axxx;
                     axx.label |= Integer.MIN_VALUE;
                     return ax.emit((Object)null, (Continuation)axx);
                  }
               };
            }

            Object axxxx = ((<undefinedtype>)axxxxx).result;
            Object var6 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(((<undefinedtype>)axxxxx).label) {
            case 0:
               ResultKt.throwOnFailure(axxxx);
               int axxx = false;
               JobKt.ensureActive(((Continuation)axxxxx).getContext());
               FlowCollector var10000 = a;
               ((<undefinedtype>)axxxxx).label = 1;
               if (var10000.emit(axx, (Continuation)axxxxx) == var6) {
                  return var6;
               }
               break;
            case 1:
               ResultKt.throwOnFailure(axxxx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            return Unit.INSTANCE;
         }
      }), a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }
}
