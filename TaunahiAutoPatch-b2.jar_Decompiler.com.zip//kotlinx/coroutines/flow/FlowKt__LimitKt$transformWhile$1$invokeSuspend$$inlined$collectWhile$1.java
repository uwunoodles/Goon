package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.InlineMarker;
import kotlinx.coroutines.flow.internal.AbortFlowException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0013\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u0019\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00028\u0000H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u0005\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0006¸\u0006\u0000"},
   d2 = {"kotlinx/coroutines/flow/FlowKt__LimitKt$collectWhile$collector$1", "Lkotlinx/coroutines/flow/FlowCollector;", "emit", "", "value", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public final class FlowKt__LimitKt$transformWhile$1$invokeSuspend$$inlined$collectWhile$1 implements FlowCollector<T> {
   // $FF: synthetic field
   final Function3 $transform$inlined;
   // $FF: synthetic field
   final FlowCollector $$this$flow$inlined;

   public FlowKt__LimitKt$transformWhile$1$invokeSuspend$$inlined$collectWhile$1(Function3 var1, FlowCollector var2) {
      a.$transform$inlined = var1;
      a.$$this$flow$inlined = var2;
   }

   @Nullable
   public Object emit(T a, @NotNull Continuation<? super Unit> var2) {
      FlowKt__LimitKt$transformWhile$1$invokeSuspend$$inlined$collectWhile$1$1 a;
      label24: {
         if (var2 instanceof FlowKt__LimitKt$transformWhile$1$invokeSuspend$$inlined$collectWhile$1$1) {
            a = (FlowKt__LimitKt$transformWhile$1$invokeSuspend$$inlined$collectWhile$1$1)var2;
            if ((a.label & Integer.MIN_VALUE) != 0) {
               a.label -= Integer.MIN_VALUE;
               break label24;
            }
         }

         a = new FlowKt__LimitKt$transformWhile$1$invokeSuspend$$inlined$collectWhile$1$1(a, var2);
      }

      Object a = a.result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      Object var10000;
      boolean a;
      switch(a.label) {
      case 0:
         ResultKt.throwOnFailure(a);
         Continuation var6 = (Continuation)a;
         a = false;
         Function3 var9 = a.$transform$inlined;
         FlowCollector var10001 = a.$$this$flow$inlined;
         a.L$0 = a;
         a.label = 1;
         InlineMarker.mark(6);
         var10000 = var9.invoke(var10001, a, a);
         InlineMarker.mark(7);
         if (var10000 == var5) {
            return var5;
         }
         break;
      case 1:
         a = false;
         a = (FlowKt__LimitKt$transformWhile$1$invokeSuspend$$inlined$collectWhile$1)a.L$0;
         ResultKt.throwOnFailure(a);
         var10000 = a;
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      if (!(Boolean)var10000) {
         throw new AbortFlowException((FlowCollector)a);
      } else {
         return Unit.INSTANCE;
      }
   }
}
