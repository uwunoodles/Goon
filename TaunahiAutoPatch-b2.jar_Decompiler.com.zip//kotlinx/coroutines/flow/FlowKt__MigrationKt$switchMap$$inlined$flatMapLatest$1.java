package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@DebugMetadata(
   f = "Migration.kt",
   l = {190, 190},
   i = {},
   s = {},
   n = {},
   m = "invokeSuspend",
   c = "kotlinx.coroutines.flow.FlowKt__MigrationKt$switchMap$$inlined$flatMapLatest$1"
)
@Metadata(
   mv = {1, 6, 0},
   k = 3,
   xi = 48,
   d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003*\b\u0012\u0004\u0012\u0002H\u00030\u00042\u0006\u0010\u0005\u001a\u0002H\u0002H\u008a@¨\u0006\u0006"},
   d2 = {"<anonymous>", "", "T", "R", "Lkotlinx/coroutines/flow/FlowCollector;", "it", "kotlinx/coroutines/flow/FlowKt__MergeKt$flatMapLatest$1"}
)
public final class FlowKt__MigrationKt$switchMap$$inlined$flatMapLatest$1 extends SuspendLambda implements Function3<FlowCollector<? super R>, T, Continuation<? super Unit>, Object> {
   int label;
   // $FF: synthetic field
   private Object L$0;
   // $FF: synthetic field
   Object L$1;
   // $FF: synthetic field
   final Function2 $transform;

   public FlowKt__MigrationKt$switchMap$$inlined$flatMapLatest$1(Function2 a, Continuation a) {
      super(3, a);
      a.$transform = a;
   }

   @Nullable
   public final Object invokeSuspend(@NotNull Object a) {
      Object var2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      Object var10000;
      FlowCollector var5;
      switch(a.label) {
      case 0:
         ResultKt.throwOnFailure(a);
         FlowCollector a = (FlowCollector)a.L$0;
         Object a = a.L$1;
         var5 = a;
         Function2 var6 = a.$transform;
         a.L$0 = a;
         a.label = 1;
         var10000 = var6.invoke(a, a);
         if (var10000 == var2) {
            return var2;
         }
         break;
      case 1:
         var5 = (FlowCollector)a.L$0;
         ResultKt.throwOnFailure(a);
         var10000 = a;
         break;
      case 2:
         ResultKt.throwOnFailure(a);
         return Unit.INSTANCE;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      Flow var10001 = (Flow)var10000;
      Continuation var10002 = (Continuation)a;
      a.L$0 = null;
      a.label = 2;
      if (FlowKt.emitAll(var5, var10001, var10002) == var2) {
         return var2;
      } else {
         return Unit.INSTANCE;
      }
   }

   @Nullable
   public final Object invoke(@NotNull FlowCollector<? super R> a, T a, @Nullable Continuation<? super Unit> a) {
      FlowKt__MigrationKt$switchMap$$inlined$flatMapLatest$1 var4 = new FlowKt__MigrationKt$switchMap$$inlined$flatMapLatest$1(a.$transform, a);
      var4.L$0 = a;
      var4.L$1 = a;
      return var4.invokeSuspend(Unit.INSTANCE);
   }
}
