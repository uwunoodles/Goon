package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.flow.internal.AbortFlowException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0013\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u0019\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00028\u0000H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u0005\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0006¸\u0006\u0000"},
   d2 = {"kotlinx/coroutines/flow/FlowKt__LimitKt$collectWhile$collector$1", "Lkotlinx/coroutines/flow/FlowCollector;", "emit", "", "value", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public final class FlowKt__ReduceKt$first$$inlined$collectWhile$2 implements FlowCollector<T> {
   // $FF: synthetic field
   final Function2 $predicate$inlined;
   // $FF: synthetic field
   final Ref.ObjectRef $result$inlined;

   public FlowKt__ReduceKt$first$$inlined$collectWhile$2(Function2 var1, Ref.ObjectRef var2) {
      a.$predicate$inlined = var1;
      a.$result$inlined = var2;
   }

   @Nullable
   public Object emit(T a, @NotNull Continuation<? super Unit> var2) {
      FlowKt__ReduceKt$first$$inlined$collectWhile$2$1 a;
      label29: {
         if (var2 instanceof FlowKt__ReduceKt$first$$inlined$collectWhile$2$1) {
            a = (FlowKt__ReduceKt$first$$inlined$collectWhile$2$1)var2;
            if ((a.label & Integer.MIN_VALUE) != 0) {
               a.label -= Integer.MIN_VALUE;
               break label29;
            }
         }

         a = new FlowKt__ReduceKt$first$$inlined$collectWhile$2$1(a, var2);
      }

      Object a = a.result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      Object var10000;
      Object a;
      boolean a;
      switch(a.label) {
      case 0:
         ResultKt.throwOnFailure(a);
         Continuation var6 = (Continuation)a;
         a = a;
         a = false;
         Function2 var9 = a.$predicate$inlined;
         a.L$0 = a;
         a.L$1 = a;
         a.label = 1;
         InlineMarker.mark(6);
         var10000 = var9.invoke(a, a);
         InlineMarker.mark(7);
         if (var10000 == var5) {
            return var5;
         }
         break;
      case 1:
         a = false;
         a = a.L$1;
         a = (FlowKt__ReduceKt$first$$inlined$collectWhile$2)a.L$0;
         ResultKt.throwOnFailure(a);
         var10000 = a;
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      boolean var10;
      if ((Boolean)var10000) {
         a.$result$inlined.element = a;
         var10 = false;
      } else {
         var10 = true;
      }

      if (!var10) {
         throw new AbortFlowException((FlowCollector)a);
      } else {
         return Unit.INSTANCE;
      }
   }
}
