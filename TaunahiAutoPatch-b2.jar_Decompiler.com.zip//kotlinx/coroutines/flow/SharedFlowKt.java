package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.JvmField;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.flow.internal.ChannelFlowOperatorImpl;
import kotlinx.coroutines.internal.Symbol;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000L\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0011\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\u001a0\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00060\u0005\"\u0004\b\u0000\u0010\u00062\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\b2\b\b\u0002\u0010\n\u001a\u00020\u000b\u001a6\u0010\f\u001a\b\u0012\u0004\u0012\u0002H\u00060\r\"\u0004\b\u0000\u0010\u0006*\b\u0012\u0004\u0012\u0002H\u00060\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u000bH\u0000\u001a#\u0010\u0012\u001a\u0004\u0018\u00010\u0013*\n\u0012\u0006\u0012\u0004\u0018\u00010\u00130\u00142\u0006\u0010\u0015\u001a\u00020\u0016H\u0002¢\u0006\u0002\u0010\u0017\u001a+\u0010\u0018\u001a\u00020\u0019*\n\u0012\u0006\u0012\u0004\u0018\u00010\u00130\u00142\u0006\u0010\u0015\u001a\u00020\u00162\b\u0010\u001a\u001a\u0004\u0018\u00010\u0013H\u0002¢\u0006\u0002\u0010\u001b\"\u0016\u0010\u0000\u001a\u00020\u00018\u0000X\u0081\u0004¢\u0006\b\n\u0000\u0012\u0004\b\u0002\u0010\u0003¨\u0006\u001c"},
   d2 = {"NO_VALUE", "Lkotlinx/coroutines/internal/Symbol;", "getNO_VALUE$annotations", "()V", "MutableSharedFlow", "Lkotlinx/coroutines/flow/MutableSharedFlow;", "T", "replay", "", "extraBufferCapacity", "onBufferOverflow", "Lkotlinx/coroutines/channels/BufferOverflow;", "fuseSharedFlow", "Lkotlinx/coroutines/flow/Flow;", "Lkotlinx/coroutines/flow/SharedFlow;", "context", "Lkotlin/coroutines/CoroutineContext;", "capacity", "getBufferAt", "", "", "index", "", "([Ljava/lang/Object;J)Ljava/lang/Object;", "setBufferAt", "", "item", "([Ljava/lang/Object;JLjava/lang/Object;)V", "kotlinx-coroutines-core"}
)
public final class SharedFlowKt {
   @JvmField
   @NotNull
   public static final Symbol NO_VALUE = new Symbol("NO_VALUE");

   @NotNull
   public static final <T> MutableSharedFlow<T> MutableSharedFlow(int a, int a, @NotNull BufferOverflow a) {
      boolean a;
      String var6;
      if (a < 0) {
         a = false;
         var6 = "replay cannot be negative, but was " + a;
         throw new IllegalArgumentException(var6.toString());
      } else if (a < 0) {
         a = false;
         var6 = "extraBufferCapacity cannot be negative, but was " + a;
         throw new IllegalArgumentException(var6.toString());
      } else if (a <= 0 && a <= 0 && a != BufferOverflow.SUSPEND) {
         a = false;
         var6 = "replay or extraBufferCapacity must be positive with non-default onBufferOverflow strategy " + a;
         throw new IllegalArgumentException(var6.toString());
      } else {
         int a = a + a;
         int a = a < 0 ? Integer.MAX_VALUE : a;
         return (MutableSharedFlow)(new SharedFlowImpl(a, a, a));
      }
   }

   // $FF: synthetic method
   public static MutableSharedFlow MutableSharedFlow$default(int var0, int var1, BufferOverflow var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var0 = 0;
      }

      if ((var3 & 2) != 0) {
         var1 = 0;
      }

      if ((var3 & 4) != 0) {
         var2 = BufferOverflow.SUSPEND;
      }

      return MutableSharedFlow(var0, var1, var2);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static void getNO_VALUE$annotations() {
   }

   private static final Object getBufferAt(Object[] a, long a) {
      return a[(int)a & a.length - 1];
   }

   private static final void setBufferAt(Object[] a, long a, Object a) {
      a[(int)a & a.length - 1] = a;
   }

   @NotNull
   public static final <T> Flow<T> fuseSharedFlow(@NotNull SharedFlow<? extends T> a, @NotNull CoroutineContext a, int a, @NotNull BufferOverflow a) {
      return (a == 0 || a == -3) && a == BufferOverflow.SUSPEND ? (Flow)a : (Flow)(new ChannelFlowOperatorImpl((Flow)a, a, a, a));
   }

   // $FF: synthetic method
   public static final Object access$getBufferAt(Object[] a, long a) {
      return getBufferAt(a, a);
   }

   // $FF: synthetic method
   public static final void access$setBufferAt(Object[] a, long a, Object a) {
      setBufferAt(a, a, a);
   }
}
