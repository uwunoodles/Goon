package kotlinx.coroutines.flow;

import java.util.Iterator;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.sequences.Sequence;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001f\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u0006\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0007¸\u0006\u0000"},
   d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Lkotlinx/coroutines/flow/Flow;", "collect", "", "collector", "Lkotlinx/coroutines/flow/FlowCollector;", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public final class FlowKt__BuildersKt$asFlow$$inlined$unsafeFlow$5 implements Flow<T> {
   // $FF: synthetic field
   final Sequence $this_asFlow$inlined;

   public FlowKt__BuildersKt$asFlow$$inlined$unsafeFlow$5(Sequence var1) {
      a.$this_asFlow$inlined = var1;
   }

   @Nullable
   public Object collect(@NotNull FlowCollector<? super T> a, @NotNull Continuation<? super Unit> var2) {
      FlowKt__BuildersKt$asFlow$$inlined$unsafeFlow$5$1 a;
      label35: {
         if (var2 instanceof FlowKt__BuildersKt$asFlow$$inlined$unsafeFlow$5$1) {
            a = (FlowKt__BuildersKt$asFlow$$inlined$unsafeFlow$5$1)var2;
            if ((a.label & Integer.MIN_VALUE) != 0) {
               a.label -= Integer.MIN_VALUE;
               break label35;
            }
         }

         a = new FlowKt__BuildersKt$asFlow$$inlined$unsafeFlow$5$1(a, var2);
      }

      Object a = a.result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      FlowCollector a;
      boolean a;
      boolean a;
      Iterator var10;
      boolean a;
      switch(a.label) {
      case 0:
         ResultKt.throwOnFailure(a);
         Continuation var10001 = (Continuation)a;
         a = a;
         a = false;
         Sequence a = a.$this_asFlow$inlined;
         a = false;
         var10 = a.iterator();
         break;
      case 1:
         a = false;
         a = false;
         a = false;
         var10 = (Iterator)a.L$1;
         a = (FlowCollector)a.L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      Object a;
      do {
         if (!var10.hasNext()) {
            return Unit.INSTANCE;
         }

         a = var10.next();
         a = false;
         a.L$0 = a;
         a.L$1 = var10;
         a.label = 1;
      } while(a.emit(a, a) != var5);

      return var5;
   }
}
