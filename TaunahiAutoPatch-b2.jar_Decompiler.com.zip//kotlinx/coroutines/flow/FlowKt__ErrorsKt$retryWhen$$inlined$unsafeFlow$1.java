package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.InlineMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001f\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u0006\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0007¸\u0006\u0000"},
   d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Lkotlinx/coroutines/flow/Flow;", "collect", "", "collector", "Lkotlinx/coroutines/flow/FlowCollector;", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public final class FlowKt__ErrorsKt$retryWhen$$inlined$unsafeFlow$1 implements Flow<T> {
   // $FF: synthetic field
   final Flow $this_retryWhen$inlined;
   // $FF: synthetic field
   final Function4 $predicate$inlined;

   public FlowKt__ErrorsKt$retryWhen$$inlined$unsafeFlow$1(Flow var1, Function4 var2) {
      a.$this_retryWhen$inlined = var1;
      a.$predicate$inlined = var2;
   }

   @Nullable
   public Object collect(@NotNull FlowCollector<? super T> a, @NotNull Continuation<? super Unit> var2) {
      FlowKt__ErrorsKt$retryWhen$$inlined$unsafeFlow$1$1 a;
      label75: {
         if (var2 instanceof FlowKt__ErrorsKt$retryWhen$$inlined$unsafeFlow$1$1) {
            a = (FlowKt__ErrorsKt$retryWhen$$inlined$unsafeFlow$1$1)var2;
            if ((a.label & Integer.MIN_VALUE) != 0) {
               a.label -= Integer.MIN_VALUE;
               break label75;
            }
         }

         a = new FlowKt__ErrorsKt$retryWhen$$inlined$unsafeFlow$1$1(a, var2);
      }

      Object a = a.result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      FlowCollector a;
      boolean a;
      long a;
      boolean a;
      Throwable a;
      int a;
      Object var16;
      Flow var10000;
      switch(a.label) {
      case 0:
         ResultKt.throwOnFailure(a);
         Continuation var6 = (Continuation)a;
         a = a;
         a = false;
         a = 0L;
         a = false;
         a = 0;
         var10000 = a.$this_retryWhen$inlined;
         a.L$0 = a;
         a.L$1 = a;
         a.L$2 = null;
         a.J$0 = a;
         a.I$0 = a;
         a.label = 1;
         var16 = FlowKt.catchImpl(var10000, a, a);
         if (var16 == var5) {
            return var5;
         }
         break;
      case 1:
         a = false;
         a = a.I$0;
         a = a.J$0;
         a = (FlowCollector)a.L$1;
         a = (FlowKt__ErrorsKt$retryWhen$$inlined$unsafeFlow$1)a.L$0;
         ResultKt.throwOnFailure(a);
         var16 = a;
         break;
      case 2:
         a = false;
         a = a.J$0;
         a = (Throwable)a.L$2;
         a = (FlowCollector)a.L$1;
         a = (FlowKt__ErrorsKt$retryWhen$$inlined$unsafeFlow$1)a.L$0;
         ResultKt.throwOnFailure(a);
         if (!(Boolean)a) {
            throw a;
         }

         a = true;
         ++a;
         if (!a) {
            return Unit.INSTANCE;
         }

         a = 0;
         var10000 = a.$this_retryWhen$inlined;
         a.L$0 = a;
         a.L$1 = a;
         a.L$2 = null;
         a.J$0 = a;
         a.I$0 = a;
         a.label = 1;
         var16 = FlowKt.catchImpl(var10000, a, a);
         if (var16 == var5) {
            return var5;
         }
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      do {
         a = (Throwable)var16;
         if (a != null) {
            Function4 var17 = a.$predicate$inlined;
            Long var10003 = Boxing.boxLong(a);
            a.L$0 = a;
            a.L$1 = a;
            a.L$2 = a;
            a.J$0 = a;
            a.label = 2;
            InlineMarker.mark(6);
            var16 = var17.invoke(a, a, var10003, a);
            InlineMarker.mark(7);
            if (var16 == var5) {
               return var5;
            }

            if (!(Boolean)var16) {
               throw a;
            }

            a = true;
            ++a;
            if (!a) {
               return Unit.INSTANCE;
            }
         } else if (a == 0) {
            return Unit.INSTANCE;
         }

         a = 0;
         var10000 = a.$this_retryWhen$inlined;
         a.L$0 = a;
         a.L$1 = a;
         a.L$2 = null;
         a.J$0 = a;
         a.I$0 = a;
         a.label = 1;
         var16 = FlowKt.catchImpl(var10000, a, a);
      } while(var16 != var5);

      return var5;
   }
}
