package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 3,
   xi = 48
)
@DebugMetadata(
   f = "Merge.kt",
   l = {223, 223},
   i = {},
   s = {},
   n = {},
   m = "emit",
   c = "kotlinx.coroutines.flow.FlowKt__MergeKt$flatMapMerge$$inlined$map$1$2"
)
public final class FlowKt__MergeKt$flatMapMerge$$inlined$map$1$2$1 extends ContinuationImpl {
   // $FF: synthetic field
   Object result;
   int label;
   Object L$0;
   // $FF: synthetic field
   final FlowKt__MergeKt$flatMapMerge$$inlined$map$1$2 this$0;

   public FlowKt__MergeKt$flatMapMerge$$inlined$map$1$2$1(FlowKt__MergeKt$flatMapMerge$$inlined$map$1$2 a, Continuation a) {
      super(a);
      a.this$0 = a;
   }

   @Nullable
   public final Object invokeSuspend(@NotNull Object a) {
      a.result = a;
      a.label |= Integer.MIN_VALUE;
      return a.this$0.emit((Object)null, (Continuation)a);
   }
}
