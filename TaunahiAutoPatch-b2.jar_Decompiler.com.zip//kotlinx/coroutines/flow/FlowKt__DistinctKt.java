package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.TypeIntrinsics;
import org.jetbrains.annotations.NotNull;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000*\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\u001a\u001c\u0010\t\u001a\b\u0012\u0004\u0012\u0002H\u000b0\n\"\u0004\b\u0000\u0010\u000b*\b\u0012\u0004\u0012\u0002H\u000b0\n\u001aT\u0010\t\u001a\b\u0012\u0004\u0012\u0002H\u000b0\n\"\u0004\b\u0000\u0010\u000b*\b\u0012\u0004\u0012\u0002H\u000b0\n26\u0010\f\u001a2\u0012\u0013\u0012\u0011H\u000b¢\u0006\f\b\r\u0012\b\b\u000e\u0012\u0004\b\b(\u000f\u0012\u0013\u0012\u0011H\u000b¢\u0006\f\b\r\u0012\b\b\u000e\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u00030\u0001\u001a6\u0010\u0011\u001a\b\u0012\u0004\u0012\u0002H\u000b0\n\"\u0004\b\u0000\u0010\u000b\"\u0004\b\u0001\u0010\u0012*\b\u0012\u0004\u0012\u0002H\u000b0\n2\u0012\u0010\u0013\u001a\u000e\u0012\u0004\u0012\u0002H\u000b\u0012\u0004\u0012\u0002H\u00120\u0007\u001au\u0010\u0011\u001a\b\u0012\u0004\u0012\u0002H\u000b0\n\"\u0004\b\u0000\u0010\u000b*\b\u0012\u0004\u0012\u0002H\u000b0\n2\u0014\u0010\u0013\u001a\u0010\u0012\u0004\u0012\u0002H\u000b\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00072:\u0010\f\u001a6\u0012\u0015\u0012\u0013\u0018\u00010\u0002¢\u0006\f\b\r\u0012\b\b\u000e\u0012\u0004\b\b(\u000f\u0012\u0015\u0012\u0013\u0018\u00010\u0002¢\u0006\f\b\r\u0012\b\b\u000e\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u00030\u0001H\u0002¢\u0006\u0002\b\u0014\",\u0010\u0000\u001a\u0018\u0012\u0006\u0012\u0004\u0018\u00010\u0002\u0012\u0006\u0012\u0004\u0018\u00010\u0002\u0012\u0004\u0012\u00020\u00030\u00018\u0002X\u0083\u0004¢\u0006\b\n\u0000\u0012\u0004\b\u0004\u0010\u0005\"&\u0010\u0006\u001a\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u0002\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00078\u0002X\u0083\u0004¢\u0006\b\n\u0000\u0012\u0004\b\b\u0010\u0005¨\u0006\u0015"},
   d2 = {"defaultAreEquivalent", "Lkotlin/Function2;", "", "", "getDefaultAreEquivalent$annotations$FlowKt__DistinctKt", "()V", "defaultKeySelector", "Lkotlin/Function1;", "getDefaultKeySelector$annotations$FlowKt__DistinctKt", "distinctUntilChanged", "Lkotlinx/coroutines/flow/Flow;", "T", "areEquivalent", "Lkotlin/ParameterName;", "name", "old", "new", "distinctUntilChangedBy", "K", "keySelector", "distinctUntilChangedBy$FlowKt__DistinctKt", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/flow/FlowKt"
)
final class FlowKt__DistinctKt {
   @NotNull
   private static final Function1<Object, Object> defaultKeySelector;
   @NotNull
   private static final Function2<Object, Object, Boolean> defaultAreEquivalent;

   @NotNull
   public static final <T> Flow<T> distinctUntilChanged(@NotNull Flow<? extends T> a) {
      return a instanceof StateFlow ? a : distinctUntilChangedBy$FlowKt__DistinctKt(a, defaultKeySelector, defaultAreEquivalent);
   }

   @NotNull
   public static final <T> Flow<T> distinctUntilChanged(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super T, Boolean> a) {
      return distinctUntilChangedBy$FlowKt__DistinctKt(a, defaultKeySelector, (Function2)TypeIntrinsics.beforeCheckcastToFunctionOfArity(a, 2));
   }

   @NotNull
   public static final <T, K> Flow<T> distinctUntilChangedBy(@NotNull Flow<? extends T> a, @NotNull Function1<? super T, ? extends K> a) {
      return distinctUntilChangedBy$FlowKt__DistinctKt(a, a, defaultAreEquivalent);
   }

   /** @deprecated */
   // $FF: synthetic method
   private static void getDefaultKeySelector$annotations$FlowKt__DistinctKt() {
   }

   /** @deprecated */
   // $FF: synthetic method
   private static void getDefaultAreEquivalent$annotations$FlowKt__DistinctKt() {
   }

   private static final <T> Flow<T> distinctUntilChangedBy$FlowKt__DistinctKt(Flow<? extends T> a, Function1<? super T, ? extends Object> a, Function2<Object, Object, Boolean> a) {
      return a instanceof DistinctFlowImpl && ((DistinctFlowImpl)a).keySelector == a && ((DistinctFlowImpl)a).areEquivalent == a ? a : (Flow)(new DistinctFlowImpl(a, a, a));
   }

   static {
      defaultKeySelector = (Function1)null.INSTANCE;
      defaultAreEquivalent = (Function2)null.INSTANCE;
   }
}
