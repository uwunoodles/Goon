package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 3,
   xi = 48
)
@DebugMetadata(
   f = "Builders.kt",
   l = {114},
   i = {0, 0},
   s = {"L$0", "L$1"},
   n = {"this", "$this$flowOf_u24lambda_u2d8"},
   m = "collect",
   c = "kotlinx.coroutines.flow.FlowKt__BuildersKt$flowOf$$inlined$unsafeFlow$1"
)
public final class FlowKt__BuildersKt$flowOf$$inlined$unsafeFlow$1$1 extends ContinuationImpl {
   // $FF: synthetic field
   Object result;
   int label;
   // $FF: synthetic field
   final FlowKt__BuildersKt$flowOf$$inlined$unsafeFlow$1 this$0;
   Object L$0;
   Object L$1;
   int I$0;
   int I$1;

   public FlowKt__BuildersKt$flowOf$$inlined$unsafeFlow$1$1(FlowKt__BuildersKt$flowOf$$inlined$unsafeFlow$1 a, Continuation a) {
      super(a);
      a.this$0 = a;
   }

   @Nullable
   public final Object invokeSuspend(@NotNull Object a) {
      a.result = a;
      a.label |= Integer.MIN_VALUE;
      return a.this$0.collect((FlowCollector)null, (Continuation)a);
   }
}
