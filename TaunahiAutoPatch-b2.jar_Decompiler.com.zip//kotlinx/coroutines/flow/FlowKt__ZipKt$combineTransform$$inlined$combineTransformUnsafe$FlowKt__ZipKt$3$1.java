package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.internal.InlineMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@DebugMetadata(
   f = "Zip.kt",
   l = {333},
   i = {},
   s = {},
   n = {},
   m = "invokeSuspend",
   c = "kotlinx.coroutines.flow.FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$3$1"
)
@Metadata(
   mv = {1, 6, 0},
   k = 3,
   xi = 48,
   d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0000\u0010\u0000\u001a\u00020\u0001\"\u0006\b\u0000\u0010\u0002\u0018\u0001\"\u0004\b\u0001\u0010\u0003*\b\u0012\u0004\u0012\u0002H\u00030\u00042\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0006H\u008a@¨\u0006\u0007"},
   d2 = {"<anonymous>", "", "T", "R", "Lkotlinx/coroutines/flow/FlowCollector;", "it", "", "kotlinx/coroutines/flow/FlowKt__ZipKt$combineTransformUnsafe$1$1"}
)
public final class FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$3$1 extends SuspendLambda implements Function3<FlowCollector<? super R>, Object[], Continuation<? super Unit>, Object> {
   int label;
   // $FF: synthetic field
   private Object L$0;
   // $FF: synthetic field
   Object L$1;
   // $FF: synthetic field
   final Function5 $transform$inlined;

   public FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$3$1(Continuation a, Function5 var2) {
      super(3, a);
      a.$transform$inlined = var2;
   }

   @Nullable
   public final Object invokeSuspend(@NotNull Object a) {
      Object var2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      boolean a;
      switch(a.label) {
      case 0:
         ResultKt.throwOnFailure(a);
         FlowCollector a = (FlowCollector)a.L$0;
         Object[] a = (Object[])a.L$1;
         Continuation var5 = (Continuation)a;
         a = false;
         Function5 var10000 = a.$transform$inlined;
         Object var10002 = a[0];
         Object var10003 = a[1];
         Object var10004 = a[2];
         a.label = 1;
         InlineMarker.mark(6);
         Object var9 = var10000.invoke(a, var10002, var10003, var10004, a);
         InlineMarker.mark(7);
         if (var9 == var2) {
            return var2;
         }
         break;
      case 1:
         a = false;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      return Unit.INSTANCE;
   }

   @Nullable
   public final Object invoke(@NotNull FlowCollector<? super R> a, @NotNull Object[] a, @Nullable Continuation<? super Unit> a) {
      FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$3$1 var4 = new FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$3$1(a, a.$transform$inlined);
      var4.L$0 = a;
      var4.L$1 = a;
      return var4.invokeSuspend(Unit.INSTANCE);
   }
}
