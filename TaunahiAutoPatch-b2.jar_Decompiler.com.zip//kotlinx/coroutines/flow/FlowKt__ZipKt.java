package kotlinx.coroutines.flow;

import java.util.Collection;
import kotlin.BuilderInference;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.JvmName;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.functions.Function6;
import kotlin.jvm.functions.Function7;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.flow.internal.CombineKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000d\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u001c\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0006\u001aq\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0006\b\u0000\u0010\u0003\u0018\u0001\"\u0004\b\u0001\u0010\u00022\u001e\u0010\u0004\u001a\u0010\u0012\f\b\u0001\u0012\b\u0012\u0004\u0012\u0002H\u00030\u00010\u0005\"\b\u0012\u0004\u0012\u0002H\u00030\u00012*\b\u0004\u0010\u0006\u001a$\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00030\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0007H\u0086\bø\u0001\u0000¢\u0006\u0002\u0010\n\u001ae\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0006\b\u0000\u0010\u0003\u0018\u0001\"\u0004\b\u0001\u0010\u00022\u0012\u0010\u0004\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00030\u00010\u000b2*\b\u0004\u0010\u0006\u001a$\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00030\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0007H\u0086\bø\u0001\u0000¢\u0006\u0002\u0010\f\u001aº\u0001\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\r\"\u0004\b\u0001\u0010\u000e\"\u0004\b\u0002\u0010\u000f\"\u0004\b\u0003\u0010\u0010\"\u0004\b\u0004\u0010\u0011\"\u0004\b\u0005\u0010\u00022\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\r0\u00012\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u00012\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u000f0\u00012\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u0002H\u00100\u00012\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u0002H\u00110\u00012:\u0010\u0006\u001a6\b\u0001\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u000e\u0012\u0004\u0012\u0002H\u000f\u0012\u0004\u0012\u0002H\u0010\u0012\u0004\u0012\u0002H\u0011\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0017ø\u0001\u0000¢\u0006\u0002\u0010\u0018\u001a \u0001\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\r\"\u0004\b\u0001\u0010\u000e\"\u0004\b\u0002\u0010\u000f\"\u0004\b\u0003\u0010\u0010\"\u0004\b\u0004\u0010\u00022\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\r0\u00012\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u00012\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u000f0\u00012\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u0002H\u00100\u000124\u0010\u0006\u001a0\b\u0001\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u000e\u0012\u0004\u0012\u0002H\u000f\u0012\u0004\u0012\u0002H\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0019ø\u0001\u0000¢\u0006\u0002\u0010\u001a\u001a\u0088\u0001\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\r\"\u0004\b\u0001\u0010\u000e\"\u0004\b\u0002\u0010\u000f\"\u0004\b\u0003\u0010\u00022\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\r0\u00012\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u00012\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u000f0\u000120\b\u0001\u0010\u0006\u001a*\b\u0001\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u000e\u0012\u0004\u0012\u0002H\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u001bø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001a\u008a\u0001\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\r\"\u0004\b\u0001\u0010\u000e\"\u0004\b\u0002\u0010\u00022\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\r0\u00012\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u00012F\u0010\u0006\u001aB\b\u0001\u0012\u0013\u0012\u0011H\r¢\u0006\f\b\u001e\u0012\b\b\u001f\u0012\u0004\b\b( \u0012\u0013\u0012\u0011H\u000e¢\u0006\f\b\u001e\u0012\b\b\u001f\u0012\u0004\b\b(!\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u001dø\u0001\u0000¢\u0006\u0002\u0010\"\u001a\u0082\u0001\u0010#\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0006\b\u0000\u0010\u0003\u0018\u0001\"\u0004\b\u0001\u0010\u00022\u001e\u0010\u0004\u001a\u0010\u0012\f\b\u0001\u0012\b\u0012\u0004\u0012\u0002H\u00030\u00010\u0005\"\b\u0012\u0004\u0012\u0002H\u00030\u00012;\b\u0005\u0010\u0006\u001a5\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020$\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00030\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020%0\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u001d¢\u0006\u0002\b&H\u0086\bø\u0001\u0000¢\u0006\u0002\u0010'\u001av\u0010#\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0006\b\u0000\u0010\u0003\u0018\u0001\"\u0004\b\u0001\u0010\u00022\u0012\u0010\u0004\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00030\u00010\u000b2;\b\u0005\u0010\u0006\u001a5\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020$\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00030\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020%0\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u001d¢\u0006\u0002\b&H\u0086\bø\u0001\u0000¢\u0006\u0002\u0010(\u001aÍ\u0001\u0010#\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\r\"\u0004\b\u0001\u0010\u000e\"\u0004\b\u0002\u0010\u000f\"\u0004\b\u0003\u0010\u0010\"\u0004\b\u0004\u0010\u0011\"\u0004\b\u0005\u0010\u00022\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\r0\u00012\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u00012\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u000f0\u00012\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u0002H\u00100\u00012\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u0002H\u00110\u00012M\b\u0001\u0010\u0006\u001aG\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020$\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u000e\u0012\u0004\u0012\u0002H\u000f\u0012\u0004\u0012\u0002H\u0010\u0012\u0004\u0012\u0002H\u0011\u0012\n\u0012\b\u0012\u0004\u0012\u00020%0\b\u0012\u0006\u0012\u0004\u0018\u00010\t0)¢\u0006\u0002\b&ø\u0001\u0000¢\u0006\u0002\u0010*\u001a³\u0001\u0010#\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\r\"\u0004\b\u0001\u0010\u000e\"\u0004\b\u0002\u0010\u000f\"\u0004\b\u0003\u0010\u0010\"\u0004\b\u0004\u0010\u00022\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\r0\u00012\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u00012\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u000f0\u00012\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u0002H\u00100\u00012G\b\u0001\u0010\u0006\u001aA\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020$\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u000e\u0012\u0004\u0012\u0002H\u000f\u0012\u0004\u0012\u0002H\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020%0\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0017¢\u0006\u0002\b&ø\u0001\u0000¢\u0006\u0002\u0010+\u001a\u0099\u0001\u0010#\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\r\"\u0004\b\u0001\u0010\u000e\"\u0004\b\u0002\u0010\u000f\"\u0004\b\u0003\u0010\u00022\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\r0\u00012\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u00012\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u000f0\u00012A\b\u0001\u0010\u0006\u001a;\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020$\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u000e\u0012\u0004\u0012\u0002H\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u00020%0\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0019¢\u0006\u0002\b&ø\u0001\u0000¢\u0006\u0002\u0010,\u001a\u009d\u0001\u0010#\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\r\"\u0004\b\u0001\u0010\u000e\"\u0004\b\u0002\u0010\u00022\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\r0\u00012\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u00012Y\b\u0001\u0010\u0006\u001aS\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020$\u0012\u0013\u0012\u0011H\r¢\u0006\f\b\u001e\u0012\b\b\u001f\u0012\u0004\b\b( \u0012\u0013\u0012\u0011H\u000e¢\u0006\f\b\u001e\u0012\b\b\u001f\u0012\u0004\b\b(!\u0012\n\u0012\b\u0012\u0004\u0012\u00020%0\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u001b¢\u0006\u0002\b&ø\u0001\u0000¢\u0006\u0002\u0010-\u001a\u0084\u0001\u0010.\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0006\b\u0000\u0010\u0003\u0018\u0001\"\u0004\b\u0001\u0010\u00022\u001e\u0010\u0004\u001a\u0010\u0012\f\b\u0001\u0012\b\u0012\u0004\u0012\u0002H\u00030\u00010\u0005\"\b\u0012\u0004\u0012\u0002H\u00030\u00012;\b\u0005\u0010\u0006\u001a5\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020$\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00030\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020%0\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u001d¢\u0006\u0002\b&H\u0082\bø\u0001\u0000¢\u0006\u0004\b/\u0010'\u001as\u00100\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0006\b\u0000\u0010\u0003\u0018\u0001\"\u0004\b\u0001\u0010\u00022\u001e\u0010\u0004\u001a\u0010\u0012\f\b\u0001\u0012\b\u0012\u0004\u0012\u0002H\u00030\u00010\u0005\"\b\u0012\u0004\u0012\u0002H\u00030\u00012*\b\u0004\u0010\u0006\u001a$\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00030\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0007H\u0082\bø\u0001\u0000¢\u0006\u0004\b1\u0010\n\u001a!\u00102\u001a\u0010\u0012\f\u0012\n\u0012\u0004\u0012\u0002H\u0003\u0018\u00010\u000503\"\u0004\b\u0000\u0010\u0003H\u0002¢\u0006\u0002\b4\u001a\u008a\u0001\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\r\"\u0004\b\u0001\u0010\u000e\"\u0004\b\u0002\u0010\u0002*\b\u0012\u0004\u0012\u0002H\r0\u00012\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u00012F\u0010\u0006\u001aB\b\u0001\u0012\u0013\u0012\u0011H\r¢\u0006\f\b\u001e\u0012\b\b\u001f\u0012\u0004\b\b( \u0012\u0013\u0012\u0011H\u000e¢\u0006\f\b\u001e\u0012\b\b\u001f\u0012\u0004\b\b(!\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u001dH\u0007ø\u0001\u0000¢\u0006\u0004\b5\u0010\"\u001a\u009d\u0001\u0010#\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\r\"\u0004\b\u0001\u0010\u000e\"\u0004\b\u0002\u0010\u0002*\b\u0012\u0004\u0012\u0002H\r0\u00012\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u00012Y\b\u0001\u0010\u0006\u001aS\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020$\u0012\u0013\u0012\u0011H\r¢\u0006\f\b\u001e\u0012\b\b\u001f\u0012\u0004\b\b( \u0012\u0013\u0012\u0011H\u000e¢\u0006\f\b\u001e\u0012\b\b\u001f\u0012\u0004\b\b(!\u0012\n\u0012\b\u0012\u0004\u0012\u00020%0\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u001b¢\u0006\u0002\b&H\u0007ø\u0001\u0000¢\u0006\u0004\b6\u0010-\u001ah\u00107\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\r\"\u0004\b\u0001\u0010\u000e\"\u0004\b\u0002\u0010\u0002*\b\u0012\u0004\u0012\u0002H\r0\u00012\f\u00108\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u00012(\u0010\u0006\u001a$\b\u0001\u0012\u0004\u0012\u0002H\r\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u001dø\u0001\u0000¢\u0006\u0002\u0010\"\u0082\u0002\u0004\n\u0002\b\u0019¨\u00069"},
   d2 = {"combine", "Lkotlinx/coroutines/flow/Flow;", "R", "T", "flows", "", "transform", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "([Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/flow/Flow;", "", "(Ljava/lang/Iterable;Lkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/flow/Flow;", "T1", "T2", "T3", "T4", "T5", "flow", "flow2", "flow3", "flow4", "flow5", "Lkotlin/Function6;", "(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function6;)Lkotlinx/coroutines/flow/Flow;", "Lkotlin/Function5;", "(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function5;)Lkotlinx/coroutines/flow/Flow;", "Lkotlin/Function4;", "(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function4;)Lkotlinx/coroutines/flow/Flow;", "Lkotlin/Function3;", "Lkotlin/ParameterName;", "name", "a", "b", "(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function3;)Lkotlinx/coroutines/flow/Flow;", "combineTransform", "Lkotlinx/coroutines/flow/FlowCollector;", "", "Lkotlin/ExtensionFunctionType;", "([Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function3;)Lkotlinx/coroutines/flow/Flow;", "(Ljava/lang/Iterable;Lkotlin/jvm/functions/Function3;)Lkotlinx/coroutines/flow/Flow;", "Lkotlin/Function7;", "(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function7;)Lkotlinx/coroutines/flow/Flow;", "(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function6;)Lkotlinx/coroutines/flow/Flow;", "(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function5;)Lkotlinx/coroutines/flow/Flow;", "(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function4;)Lkotlinx/coroutines/flow/Flow;", "combineTransformUnsafe", "combineTransformUnsafe$FlowKt__ZipKt", "combineUnsafe", "combineUnsafe$FlowKt__ZipKt", "nullArrayFactory", "Lkotlin/Function0;", "nullArrayFactory$FlowKt__ZipKt", "flowCombine", "flowCombineTransform", "zip", "other", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/flow/FlowKt"
)
final class FlowKt__ZipKt {
   @JvmName(
      name = "flowCombine"
   )
   @NotNull
   public static final <T1, T2, R> Flow<R> flowCombine(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Function3<? super T1, ? super T2, ? super Continuation<? super R>, ? extends Object> a) {
      int a = false;
      return (Flow)(new FlowKt__ZipKt$combine$$inlined$unsafeFlow$1(a, a, a));
   }

   @NotNull
   public static final <T1, T2, R> Flow<R> combine(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Function3<? super T1, ? super T2, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt.flowCombine(a, a, a);
   }

   @JvmName(
      name = "flowCombineTransform"
   )
   @NotNull
   public static final <T1, T2, R> Flow<R> flowCombineTransform(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @BuilderInference @NotNull Function4<? super FlowCollector<? super R>, ? super T1, ? super T2, ? super Continuation<? super Unit>, ? extends Object> a) {
      Flow[] var3 = new Flow[]{a, a};
      int a = false;
      return FlowKt.flow((Function2)(new FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$1(var3, (Continuation)null, a)));
   }

   @NotNull
   public static final <T1, T2, R> Flow<R> combineTransform(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @BuilderInference @NotNull Function4<? super FlowCollector<? super R>, ? super T1, ? super T2, ? super Continuation<? super Unit>, ? extends Object> a) {
      Flow[] var3 = new Flow[]{a, a};
      int a = false;
      return FlowKt.flow((Function2)(new FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$2(var3, (Continuation)null, a)));
   }

   @NotNull
   public static final <T1, T2, T3, R> Flow<R> combine(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @BuilderInference @NotNull Function4<? super T1, ? super T2, ? super T3, ? super Continuation<? super R>, ? extends Object> a) {
      Flow[] var4 = new Flow[]{a, a, a};
      int a = false;
      int a = false;
      return (Flow)(new FlowKt__ZipKt$combine$$inlined$combineUnsafe$FlowKt__ZipKt$1(var4, a));
   }

   @NotNull
   public static final <T1, T2, T3, R> Flow<R> combineTransform(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @BuilderInference @NotNull Function5<? super FlowCollector<? super R>, ? super T1, ? super T2, ? super T3, ? super Continuation<? super Unit>, ? extends Object> a) {
      Flow[] var4 = new Flow[]{a, a, a};
      int a = false;
      return FlowKt.flow((Function2)(new FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$3(var4, (Continuation)null, a)));
   }

   @NotNull
   public static final <T1, T2, T3, T4, R> Flow<R> combine(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @NotNull Flow<? extends T4> a, @NotNull Function5<? super T1, ? super T2, ? super T3, ? super T4, ? super Continuation<? super R>, ? extends Object> a) {
      Flow[] var5 = new Flow[]{a, a, a, a};
      int a = false;
      int a = false;
      return (Flow)(new FlowKt__ZipKt$combine$$inlined$combineUnsafe$FlowKt__ZipKt$2(var5, a));
   }

   @NotNull
   public static final <T1, T2, T3, T4, R> Flow<R> combineTransform(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @NotNull Flow<? extends T4> a, @BuilderInference @NotNull Function6<? super FlowCollector<? super R>, ? super T1, ? super T2, ? super T3, ? super T4, ? super Continuation<? super Unit>, ? extends Object> a) {
      Flow[] var5 = new Flow[]{a, a, a, a};
      int a = false;
      return FlowKt.flow((Function2)(new FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$4(var5, (Continuation)null, a)));
   }

   @NotNull
   public static final <T1, T2, T3, T4, T5, R> Flow<R> combine(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @NotNull Flow<? extends T4> a, @NotNull Flow<? extends T5> a, @NotNull Function6<? super T1, ? super T2, ? super T3, ? super T4, ? super T5, ? super Continuation<? super R>, ? extends Object> a) {
      Flow[] var6 = new Flow[]{a, a, a, a, a};
      int a = false;
      int a = false;
      return (Flow)(new FlowKt__ZipKt$combine$$inlined$combineUnsafe$FlowKt__ZipKt$3(var6, a));
   }

   @NotNull
   public static final <T1, T2, T3, T4, T5, R> Flow<R> combineTransform(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @NotNull Flow<? extends T4> a, @NotNull Flow<? extends T5> a, @BuilderInference @NotNull Function7<? super FlowCollector<? super R>, ? super T1, ? super T2, ? super T3, ? super T4, ? super T5, ? super Continuation<? super Unit>, ? extends Object> a) {
      Flow[] var6 = new Flow[]{a, a, a, a, a};
      int a = false;
      return FlowKt.flow((Function2)(new FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$5(var6, (Continuation)null, a)));
   }

   // $FF: synthetic method
   public static final <T, R> Flow<R> combine(Flow<? extends T>[] a, Function2<? super T[], ? super Continuation<? super R>, ? extends Object> a) {
      int a = false;
      int a = false;
      Intrinsics.needClassReification();
      return (Flow)(new FlowKt__ZipKt$combine$$inlined$unsafeFlow$2(a, a));
   }

   // $FF: synthetic method
   public static final <T, R> Flow<R> combineTransform(final Flow<? extends T>[] a, @BuilderInference final Function3<? super FlowCollector<? super R>, ? super T[], ? super Continuation<? super Unit>, ? extends Object> a) {
      int a = false;
      Intrinsics.needClassReification();
      return FlowKt.flow((Function2)(new Function2<FlowCollector<? super R>, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               FlowCollector axxx = (FlowCollector)ax.L$0;
               Flow[] var10001 = a;
               Intrinsics.needClassReification();
               Function0 var10002 = (Function0)(new Function0<T[]>(a) {
                  // $FF: synthetic field
                  final Flow<T>[] $flows;

                  public {
                     ax.$flows = axx;
                  }

                  @Nullable
                  public final T[] invoke() {
                     int var10000 = ax.$flows.length;
                     Intrinsics.reifiedOperationMarker(0, "T?");
                     return new Object[var10000];
                  }
               });
               Intrinsics.needClassReification();
               Function3 var10003 = (Function3)(new Function3<FlowCollector<? super R>, T[], Continuation<? super Unit>, Object>(a, (Continuation)null) {
                  int label;
                  // $FF: synthetic field
                  private Object L$0;
                  // $FF: synthetic field
                  Object L$1;
                  // $FF: synthetic field
                  final Function3<FlowCollector<? super R>, T[], Continuation<? super Unit>, Object> $transform;

                  public {
                     ax.$transform = axx;
                  }

                  @Nullable
                  public final Object invokeSuspend(@NotNull Object axx) {
                     Object var4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                     switch(ax.label) {
                     case 0:
                        ResultKt.throwOnFailure(axx);
                        FlowCollector axxx = (FlowCollector)ax.L$0;
                        Object[] axxxx = (Object[])ax.L$1;
                        Function3 var10000 = ax.$transform;
                        ax.L$0 = null;
                        ax.label = 1;
                        if (var10000.invoke(axxx, axxxx, ax) == var4) {
                           return var4;
                        }
                        break;
                     case 1:
                        ResultKt.throwOnFailure(axx);
                        break;
                     default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                     }

                     return Unit.INSTANCE;
                  }

                  @Nullable
                  public final Object invokeSuspend$$forInline(@NotNull Object a1) {
                     FlowCollector axxx = (FlowCollector)ax.L$0;
                     Object[] axx = (Object[])ax.L$1;
                     ax.$transform.invoke(axxx, axx, ax);
                     return Unit.INSTANCE;
                  }

                  @Nullable
                  public final Object invoke(@NotNull FlowCollector<? super R> axxx, @NotNull T[] axxxx, @Nullable Continuation<? super Unit> axx) {
                     Function3 var4 = new <anonymous constructor>(ax.$transform, axx);
                     var4.L$0 = axxx;
                     var4.L$1 = axxxx;
                     return var4.invokeSuspend(Unit.INSTANCE);
                  }
               });
               Continuation var10004 = (Continuation)ax;
               ax.label = 1;
               if (CombineKt.combineInternal(axxx, var10001, var10002, var10003, var10004) == var3) {
                  return var3;
               }
               break;
            case 1:
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            return Unit.INSTANCE;
         }

         @Nullable
         public final Object invokeSuspend$$forInline(@NotNull Object a1) {
            FlowCollector axx = (FlowCollector)ax.L$0;
            Flow[] var10001 = a;
            Intrinsics.needClassReification();
            Function0 var10002 = (Function0)(new Function0<T[]>(a) {
               // $FF: synthetic field
               final Flow<T>[] $flows;

               public {
                  ax.$flows = axx;
               }

               @Nullable
               public final T[] invoke() {
                  int var10000 = ax.$flows.length;
                  Intrinsics.reifiedOperationMarker(0, "T?");
                  return new Object[var10000];
               }
            });
            Intrinsics.needClassReification();
            Function3 var10003 = (Function3)(new Function3<FlowCollector<? super R>, T[], Continuation<? super Unit>, Object>(a, (Continuation)null) {
               int label;
               // $FF: synthetic field
               private Object L$0;
               // $FF: synthetic field
               Object L$1;
               // $FF: synthetic field
               final Function3<FlowCollector<? super R>, T[], Continuation<? super Unit>, Object> $transform;

               public {
                  ax.$transform = axx;
               }

               @Nullable
               public final Object invokeSuspend(@NotNull Object axx) {
                  Object var4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                  switch(ax.label) {
                  case 0:
                     ResultKt.throwOnFailure(axx);
                     FlowCollector axxx = (FlowCollector)ax.L$0;
                     Object[] axxxx = (Object[])ax.L$1;
                     Function3 var10000 = ax.$transform;
                     ax.L$0 = null;
                     ax.label = 1;
                     if (var10000.invoke(axxx, axxxx, ax) == var4) {
                        return var4;
                     }
                     break;
                  case 1:
                     ResultKt.throwOnFailure(axx);
                     break;
                  default:
                     throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                  }

                  return Unit.INSTANCE;
               }

               @Nullable
               public final Object invokeSuspend$$forInline(@NotNull Object a1) {
                  FlowCollector axxx = (FlowCollector)ax.L$0;
                  Object[] axx = (Object[])ax.L$1;
                  ax.$transform.invoke(axxx, axx, ax);
                  return Unit.INSTANCE;
               }

               @Nullable
               public final Object invoke(@NotNull FlowCollector<? super R> axxx, @NotNull T[] axxxx, @Nullable Continuation<? super Unit> axx) {
                  Function3 var4 = new <anonymous constructor>(ax.$transform, axx);
                  var4.L$0 = axxx;
                  var4.L$1 = axxxx;
                  return var4.invokeSuspend(Unit.INSTANCE);
               }
            });
            Continuation var10004 = (Continuation)ax;
            InlineMarker.mark(0);
            CombineKt.combineInternal(axx, var10001, var10002, var10003, var10004);
            InlineMarker.mark(1);
            return Unit.INSTANCE;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull FlowCollector<? super R> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }));
   }

   // $FF: synthetic method
   private static final <T, R> Flow<R> combineUnsafe$FlowKt__ZipKt(Flow<? extends T>[] a, Function2<? super T[], ? super Continuation<? super R>, ? extends Object> a) {
      int a = false;
      int a = false;
      Intrinsics.needClassReification();
      return (Flow)(new FlowKt__ZipKt$combineUnsafe$$inlined$unsafeFlow$1(a, a));
   }

   // $FF: synthetic method
   private static final <T, R> Flow<R> combineTransformUnsafe$FlowKt__ZipKt(final Flow<? extends T>[] a, @BuilderInference final Function3<? super FlowCollector<? super R>, ? super T[], ? super Continuation<? super Unit>, ? extends Object> a) {
      int a = false;
      Intrinsics.needClassReification();
      return FlowKt.flow((Function2)(new Function2<FlowCollector<? super R>, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               FlowCollector axxx = (FlowCollector)ax.L$0;
               Flow[] var10001 = a;
               Function0 var10002 = FlowKt__ZipKt.nullArrayFactory$FlowKt__ZipKt();
               Intrinsics.needClassReification();
               Function3 var10003 = (Function3)(new Function3<FlowCollector<? super R>, T[], Continuation<? super Unit>, Object>(a, (Continuation)null) {
                  int label;
                  // $FF: synthetic field
                  private Object L$0;
                  // $FF: synthetic field
                  Object L$1;
                  // $FF: synthetic field
                  final Function3<FlowCollector<? super R>, T[], Continuation<? super Unit>, Object> $transform;

                  public {
                     ax.$transform = axx;
                  }

                  @Nullable
                  public final Object invokeSuspend(@NotNull Object axx) {
                     Object var4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                     switch(ax.label) {
                     case 0:
                        ResultKt.throwOnFailure(axx);
                        FlowCollector axxx = (FlowCollector)ax.L$0;
                        Object[] axxxx = (Object[])ax.L$1;
                        Function3 var10000 = ax.$transform;
                        ax.L$0 = null;
                        ax.label = 1;
                        if (var10000.invoke(axxx, axxxx, ax) == var4) {
                           return var4;
                        }
                        break;
                     case 1:
                        ResultKt.throwOnFailure(axx);
                        break;
                     default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                     }

                     return Unit.INSTANCE;
                  }

                  @Nullable
                  public final Object invokeSuspend$$forInline(@NotNull Object a1) {
                     FlowCollector axxx = (FlowCollector)ax.L$0;
                     Object[] axx = (Object[])ax.L$1;
                     ax.$transform.invoke(axxx, axx, ax);
                     return Unit.INSTANCE;
                  }

                  @Nullable
                  public final Object invoke(@NotNull FlowCollector<? super R> axxx, @NotNull T[] axxxx, @Nullable Continuation<? super Unit> axx) {
                     Function3 var4 = new <anonymous constructor>(ax.$transform, axx);
                     var4.L$0 = axxx;
                     var4.L$1 = axxxx;
                     return var4.invokeSuspend(Unit.INSTANCE);
                  }
               });
               Continuation var10004 = (Continuation)ax;
               ax.label = 1;
               if (CombineKt.combineInternal(axxx, var10001, var10002, var10003, var10004) == var3) {
                  return var3;
               }
               break;
            case 1:
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            return Unit.INSTANCE;
         }

         @Nullable
         public final Object invokeSuspend$$forInline(@NotNull Object a1) {
            FlowCollector axx = (FlowCollector)ax.L$0;
            Flow[] var10001 = a;
            Function0 var10002 = FlowKt__ZipKt.nullArrayFactory$FlowKt__ZipKt();
            Intrinsics.needClassReification();
            Function3 var10003 = (Function3)(new Function3<FlowCollector<? super R>, T[], Continuation<? super Unit>, Object>(a, (Continuation)null) {
               int label;
               // $FF: synthetic field
               private Object L$0;
               // $FF: synthetic field
               Object L$1;
               // $FF: synthetic field
               final Function3<FlowCollector<? super R>, T[], Continuation<? super Unit>, Object> $transform;

               public {
                  ax.$transform = axx;
               }

               @Nullable
               public final Object invokeSuspend(@NotNull Object axx) {
                  Object var4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                  switch(ax.label) {
                  case 0:
                     ResultKt.throwOnFailure(axx);
                     FlowCollector axxx = (FlowCollector)ax.L$0;
                     Object[] axxxx = (Object[])ax.L$1;
                     Function3 var10000 = ax.$transform;
                     ax.L$0 = null;
                     ax.label = 1;
                     if (var10000.invoke(axxx, axxxx, ax) == var4) {
                        return var4;
                     }
                     break;
                  case 1:
                     ResultKt.throwOnFailure(axx);
                     break;
                  default:
                     throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                  }

                  return Unit.INSTANCE;
               }

               @Nullable
               public final Object invokeSuspend$$forInline(@NotNull Object a1) {
                  FlowCollector axxx = (FlowCollector)ax.L$0;
                  Object[] axx = (Object[])ax.L$1;
                  ax.$transform.invoke(axxx, axx, ax);
                  return Unit.INSTANCE;
               }

               @Nullable
               public final Object invoke(@NotNull FlowCollector<? super R> axxx, @NotNull T[] axxxx, @Nullable Continuation<? super Unit> axx) {
                  Function3 var4 = new <anonymous constructor>(ax.$transform, axx);
                  var4.L$0 = axxx;
                  var4.L$1 = axxxx;
                  return var4.invokeSuspend(Unit.INSTANCE);
               }
            });
            Continuation var10004 = (Continuation)ax;
            InlineMarker.mark(0);
            CombineKt.combineInternal(axx, var10001, var10002, var10003, var10004);
            InlineMarker.mark(1);
            return Unit.INSTANCE;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull FlowCollector<? super R> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }));
   }

   private static final <T> Function0<T[]> nullArrayFactory$FlowKt__ZipKt() {
      return (Function0)null.INSTANCE;
   }

   // $FF: synthetic method
   public static final <T, R> Flow<R> combine(Iterable<? extends Flow<? extends T>> a, Function2<? super T[], ? super Continuation<? super R>, ? extends Object> a) {
      int a = false;
      Collection a = (Collection)CollectionsKt.toList(a);
      int a = false;
      Object[] var10000 = a.toArray(new Flow[0]);
      if (var10000 == null) {
         throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
      } else {
         Flow[] a = (Flow[])var10000;
         int a = false;
         Intrinsics.needClassReification();
         return (Flow)(new FlowKt__ZipKt$combine$$inlined$unsafeFlow$3(a, a));
      }
   }

   // $FF: synthetic method
   public static final <T, R> Flow<R> combineTransform(Iterable<? extends Flow<? extends T>> a, @BuilderInference final Function3<? super FlowCollector<? super R>, ? super T[], ? super Continuation<? super Unit>, ? extends Object> a) {
      int a = false;
      Collection a = (Collection)CollectionsKt.toList(a);
      int a = false;
      Object[] var10000 = a.toArray(new Flow[0]);
      if (var10000 == null) {
         throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
      } else {
         final Flow[] a = (Flow[])var10000;
         Intrinsics.needClassReification();
         return FlowKt.flow((Function2)(new Function2<FlowCollector<? super R>, Continuation<? super Unit>, Object>((Continuation)null) {
            int label;
            // $FF: synthetic field
            private Object L$0;

            @Nullable
            public final Object invokeSuspend(@NotNull Object axx) {
               Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
               switch(ax.label) {
               case 0:
                  ResultKt.throwOnFailure(axx);
                  FlowCollector axxx = (FlowCollector)ax.L$0;
                  Flow[] var10001 = a;
                  Intrinsics.needClassReification();
                  Function0 var10002 = (Function0)(new Function0<T[]>(a) {
                     // $FF: synthetic field
                     final Flow<T>[] $flowArray;

                     public {
                        ax.$flowArray = axx;
                     }

                     @Nullable
                     public final T[] invoke() {
                        int var10000 = ax.$flowArray.length;
                        Intrinsics.reifiedOperationMarker(0, "T?");
                        return new Object[var10000];
                     }
                  });
                  Intrinsics.needClassReification();
                  Function3 var10003 = (Function3)(new Function3<FlowCollector<? super R>, T[], Continuation<? super Unit>, Object>(a, (Continuation)null) {
                     int label;
                     // $FF: synthetic field
                     private Object L$0;
                     // $FF: synthetic field
                     Object L$1;
                     // $FF: synthetic field
                     final Function3<FlowCollector<? super R>, T[], Continuation<? super Unit>, Object> $transform;

                     public {
                        ax.$transform = axx;
                     }

                     @Nullable
                     public final Object invokeSuspend(@NotNull Object axx) {
                        Object var4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch(ax.label) {
                        case 0:
                           ResultKt.throwOnFailure(axx);
                           FlowCollector axxx = (FlowCollector)ax.L$0;
                           Object[] axxxx = (Object[])ax.L$1;
                           Function3 var10000 = ax.$transform;
                           ax.L$0 = null;
                           ax.label = 1;
                           if (var10000.invoke(axxx, axxxx, ax) == var4) {
                              return var4;
                           }
                           break;
                        case 1:
                           ResultKt.throwOnFailure(axx);
                           break;
                        default:
                           throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }

                        return Unit.INSTANCE;
                     }

                     @Nullable
                     public final Object invokeSuspend$$forInline(@NotNull Object a1) {
                        FlowCollector axxx = (FlowCollector)ax.L$0;
                        Object[] axx = (Object[])ax.L$1;
                        ax.$transform.invoke(axxx, axx, ax);
                        return Unit.INSTANCE;
                     }

                     @Nullable
                     public final Object invoke(@NotNull FlowCollector<? super R> axxx, @NotNull T[] axxxx, @Nullable Continuation<? super Unit> axx) {
                        Function3 var4 = new <anonymous constructor>(ax.$transform, axx);
                        var4.L$0 = axxx;
                        var4.L$1 = axxxx;
                        return var4.invokeSuspend(Unit.INSTANCE);
                     }
                  });
                  Continuation var10004 = (Continuation)ax;
                  ax.label = 1;
                  if (CombineKt.combineInternal(axxx, var10001, var10002, var10003, var10004) == var3) {
                     return var3;
                  }
                  break;
               case 1:
                  ResultKt.throwOnFailure(axx);
                  break;
               default:
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
               }

               return Unit.INSTANCE;
            }

            @Nullable
            public final Object invokeSuspend$$forInline(@NotNull Object a1) {
               FlowCollector axx = (FlowCollector)ax.L$0;
               Flow[] var10001 = a;
               Intrinsics.needClassReification();
               Function0 var10002 = (Function0)(new Function0<T[]>(a) {
                  // $FF: synthetic field
                  final Flow<T>[] $flowArray;

                  public {
                     ax.$flowArray = axx;
                  }

                  @Nullable
                  public final T[] invoke() {
                     int var10000 = ax.$flowArray.length;
                     Intrinsics.reifiedOperationMarker(0, "T?");
                     return new Object[var10000];
                  }
               });
               Intrinsics.needClassReification();
               Function3 var10003 = (Function3)(new Function3<FlowCollector<? super R>, T[], Continuation<? super Unit>, Object>(a, (Continuation)null) {
                  int label;
                  // $FF: synthetic field
                  private Object L$0;
                  // $FF: synthetic field
                  Object L$1;
                  // $FF: synthetic field
                  final Function3<FlowCollector<? super R>, T[], Continuation<? super Unit>, Object> $transform;

                  public {
                     ax.$transform = axx;
                  }

                  @Nullable
                  public final Object invokeSuspend(@NotNull Object axx) {
                     Object var4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                     switch(ax.label) {
                     case 0:
                        ResultKt.throwOnFailure(axx);
                        FlowCollector axxx = (FlowCollector)ax.L$0;
                        Object[] axxxx = (Object[])ax.L$1;
                        Function3 var10000 = ax.$transform;
                        ax.L$0 = null;
                        ax.label = 1;
                        if (var10000.invoke(axxx, axxxx, ax) == var4) {
                           return var4;
                        }
                        break;
                     case 1:
                        ResultKt.throwOnFailure(axx);
                        break;
                     default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                     }

                     return Unit.INSTANCE;
                  }

                  @Nullable
                  public final Object invokeSuspend$$forInline(@NotNull Object a1) {
                     FlowCollector axxx = (FlowCollector)ax.L$0;
                     Object[] axx = (Object[])ax.L$1;
                     ax.$transform.invoke(axxx, axx, ax);
                     return Unit.INSTANCE;
                  }

                  @Nullable
                  public final Object invoke(@NotNull FlowCollector<? super R> axxx, @NotNull T[] axxxx, @Nullable Continuation<? super Unit> axx) {
                     Function3 var4 = new <anonymous constructor>(ax.$transform, axx);
                     var4.L$0 = axxx;
                     var4.L$1 = axxxx;
                     return var4.invokeSuspend(Unit.INSTANCE);
                  }
               });
               Continuation var10004 = (Continuation)ax;
               InlineMarker.mark(0);
               CombineKt.combineInternal(axx, var10001, var10002, var10003, var10004);
               InlineMarker.mark(1);
               return Unit.INSTANCE;
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
               Function2 var3 = new <anonymous constructor>(axxx);
               var3.L$0 = axx;
               return (Continuation)var3;
            }

            @Nullable
            public final Object invoke(@NotNull FlowCollector<? super R> axx, @Nullable Continuation<? super Unit> axxx) {
               return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
            }
         }));
      }
   }

   @NotNull
   public static final <T1, T2, R> Flow<R> zip(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Function3<? super T1, ? super T2, ? super Continuation<? super R>, ? extends Object> a) {
      return CombineKt.zipImpl(a, a, a);
   }
}
