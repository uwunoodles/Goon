package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.InlineMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001f\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u0006\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0007¸\u0006\u0000"},
   d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Lkotlinx/coroutines/flow/Flow;", "collect", "", "collector", "Lkotlinx/coroutines/flow/FlowCollector;", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public final class FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1 implements Flow<T> {
   // $FF: synthetic field
   final Flow $this_catch$inlined;
   // $FF: synthetic field
   final Function3 $action$inlined;

   public FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1(Flow var1, Function3 var2) {
      a.$this_catch$inlined = var1;
      a.$action$inlined = var2;
   }

   @Nullable
   public Object collect(@NotNull FlowCollector<? super T> a, @NotNull Continuation<? super Unit> var2) {
      FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1$1 a;
      label37: {
         if (var2 instanceof FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1$1) {
            a = (FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1$1)var2;
            if ((a.label & Integer.MIN_VALUE) != 0) {
               a.label -= Integer.MIN_VALUE;
               break label37;
            }
         }

         a = new FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1$1(a, var2);
      }

      Object a = a.result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      FlowCollector a;
      boolean a;
      Object var10000;
      switch(a.label) {
      case 0:
         ResultKt.throwOnFailure(a);
         Continuation var6 = (Continuation)a;
         a = a;
         a = false;
         Flow var10 = a.$this_catch$inlined;
         a.L$0 = a;
         a.L$1 = a;
         a.label = 1;
         var10000 = FlowKt.catchImpl(var10, a, a);
         if (var10000 == var5) {
            return var5;
         }
         break;
      case 1:
         a = false;
         a = (FlowCollector)a.L$1;
         a = (FlowKt__ErrorsKt$catch$$inlined$unsafeFlow$1)a.L$0;
         ResultKt.throwOnFailure(a);
         var10000 = a;
         break;
      case 2:
         a = false;
         ResultKt.throwOnFailure(a);
         return Unit.INSTANCE;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      Throwable a = (Throwable)var10000;
      if (a != null) {
         Function3 var11 = a.$action$inlined;
         a.L$0 = null;
         a.L$1 = null;
         a.label = 2;
         InlineMarker.mark(6);
         var10000 = var11.invoke(a, a, a);
         InlineMarker.mark(7);
         if (var10000 == var5) {
            return var5;
         }
      }

      return Unit.INSTANCE;
   }
}
