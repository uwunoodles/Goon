package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function1;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.flow.internal.NullSurrogateKt;
import kotlinx.coroutines.internal.Symbol;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000@\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u001a\u001f\u0010\u0006\u001a\b\u0012\u0004\u0012\u0002H\b0\u0007\"\u0004\b\u0000\u0010\b2\u0006\u0010\t\u001a\u0002H\b¢\u0006\u0002\u0010\n\u001a6\u0010\u000b\u001a\b\u0012\u0004\u0012\u0002H\b0\f\"\u0004\b\u0000\u0010\b*\b\u0012\u0004\u0012\u0002H\b0\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013H\u0000\u001a2\u0010\u0014\u001a\u0002H\b\"\u0004\b\u0000\u0010\b*\b\u0012\u0004\u0012\u0002H\b0\u00072\u0012\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u0002H\b\u0012\u0004\u0012\u0002H\b0\u0016H\u0086\b¢\u0006\u0002\u0010\u0017\u001a-\u0010\u0018\u001a\u00020\u0019\"\u0004\b\u0000\u0010\b*\b\u0012\u0004\u0012\u0002H\b0\u00072\u0012\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u0002H\b\u0012\u0004\u0012\u0002H\b0\u0016H\u0086\b\u001a2\u0010\u001a\u001a\u0002H\b\"\u0004\b\u0000\u0010\b*\b\u0012\u0004\u0012\u0002H\b0\u00072\u0012\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u0002H\b\u0012\u0004\u0012\u0002H\b0\u0016H\u0086\b¢\u0006\u0002\u0010\u0017\"\u0016\u0010\u0000\u001a\u00020\u00018\u0002X\u0083\u0004¢\u0006\b\n\u0000\u0012\u0004\b\u0002\u0010\u0003\"\u0016\u0010\u0004\u001a\u00020\u00018\u0002X\u0083\u0004¢\u0006\b\n\u0000\u0012\u0004\b\u0005\u0010\u0003¨\u0006\u001b"},
   d2 = {"NONE", "Lkotlinx/coroutines/internal/Symbol;", "getNONE$annotations", "()V", "PENDING", "getPENDING$annotations", "MutableStateFlow", "Lkotlinx/coroutines/flow/MutableStateFlow;", "T", "value", "(Ljava/lang/Object;)Lkotlinx/coroutines/flow/MutableStateFlow;", "fuseStateFlow", "Lkotlinx/coroutines/flow/Flow;", "Lkotlinx/coroutines/flow/StateFlow;", "context", "Lkotlin/coroutines/CoroutineContext;", "capacity", "", "onBufferOverflow", "Lkotlinx/coroutines/channels/BufferOverflow;", "getAndUpdate", "function", "Lkotlin/Function1;", "(Lkotlinx/coroutines/flow/MutableStateFlow;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "update", "", "updateAndGet", "kotlinx-coroutines-core"}
)
public final class StateFlowKt {
   @NotNull
   private static final Symbol NONE = new Symbol("NONE");
   @NotNull
   private static final Symbol PENDING = new Symbol("PENDING");

   @NotNull
   public static final <T> MutableStateFlow<T> MutableStateFlow(T a) {
      StateFlowImpl var10000 = new StateFlowImpl;
      Object var10002 = a;
      if (a == null) {
         var10002 = NullSurrogateKt.NULL;
      }

      var10000.<init>(var10002);
      return (MutableStateFlow)var10000;
   }

   public static final <T> T updateAndGet(@NotNull MutableStateFlow<T> a, @NotNull Function1<? super T, ? extends T> a) {
      boolean var2 = false;

      Object a;
      Object a;
      do {
         a = a.getValue();
         a = a.invoke(a);
      } while(!a.compareAndSet(a, a));

      return a;
   }

   public static final <T> T getAndUpdate(@NotNull MutableStateFlow<T> a, @NotNull Function1<? super T, ? extends T> a) {
      boolean var2 = false;

      Object a;
      Object a;
      do {
         a = a.getValue();
         a = a.invoke(a);
      } while(!a.compareAndSet(a, a));

      return a;
   }

   public static final <T> void update(@NotNull MutableStateFlow<T> a, @NotNull Function1<? super T, ? extends T> a) {
      boolean var2 = false;

      Object a;
      Object a;
      do {
         a = a.getValue();
         a = a.invoke(a);
      } while(!a.compareAndSet(a, a));

   }

   /** @deprecated */
   // $FF: synthetic method
   private static void getNONE$annotations() {
   }

   /** @deprecated */
   // $FF: synthetic method
   private static void getPENDING$annotations() {
   }

   @NotNull
   public static final <T> Flow<T> fuseStateFlow(@NotNull StateFlow<? extends T> a, @NotNull CoroutineContext a, int a, @NotNull BufferOverflow a) {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a == -1) {
            throw new AssertionError();
         }
      }

      return ((0 <= a ? a < 2 : false) || a == -2) && a == BufferOverflow.DROP_OLDEST ? (Flow)a : SharedFlowKt.fuseSharedFlow((SharedFlow)a, a, a, a);
   }

   // $FF: synthetic method
   public static final Symbol access$getNONE$p() {
      return NONE;
   }

   // $FF: synthetic method
   public static final Symbol access$getPENDING$p() {
      return PENDING;
   }
}
