package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 3,
   xi = 48,
   d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0007\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u00032\u0006\u0010\u0004\u001a\u0002H\u0002H\u008a@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\b"},
   d2 = {"<anonymous>", "", "T", "R", "value", "emit", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$1$1", "kotlinx/coroutines/flow/FlowKt__TransformKt$map$$inlined$unsafeTransform$1$2"}
)
public final class FlowKt__MergeKt$flatMapConcat$$inlined$map$1$2<T> implements FlowCollector {
   // $FF: synthetic field
   final FlowCollector $this_unsafeFlow;
   // $FF: synthetic field
   final Function2 $transform$inlined;

   public FlowKt__MergeKt$flatMapConcat$$inlined$map$1$2(FlowCollector a, Function2 var2) {
      a.$this_unsafeFlow = a;
      a.$transform$inlined = var2;
   }

   @Nullable
   public final Object emit(Object a, @NotNull Continuation var2) {
      FlowKt__MergeKt$flatMapConcat$$inlined$map$1$2$1 a;
      label27: {
         if (var2 instanceof FlowKt__MergeKt$flatMapConcat$$inlined$map$1$2$1) {
            a = (FlowKt__MergeKt$flatMapConcat$$inlined$map$1$2$1)var2;
            if ((a.label & Integer.MIN_VALUE) != 0) {
               a.label -= Integer.MIN_VALUE;
               break label27;
            }
         }

         a = new FlowKt__MergeKt$flatMapConcat$$inlined$map$1$2$1(a, var2);
      }

      Object a = a.result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      Object var10000;
      boolean a;
      FlowCollector var9;
      switch(a.label) {
      case 0:
         ResultKt.throwOnFailure(a);
         FlowCollector a = a.$this_unsafeFlow;
         a = false;
         var9 = a;
         Function2 var10 = a.$transform$inlined;
         a.L$0 = a;
         a.label = 1;
         var10000 = var10.invoke(a, a);
         if (var10000 == var5) {
            return var5;
         }
         break;
      case 1:
         a = false;
         var9 = (FlowCollector)a.L$0;
         ResultKt.throwOnFailure(a);
         var10000 = a;
         break;
      case 2:
         a = false;
         ResultKt.throwOnFailure(a);
         return Unit.INSTANCE;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      a.L$0 = null;
      a.label = 2;
      if (var9.emit(var10000, a) == var5) {
         return var5;
      } else {
         return Unit.INSTANCE;
      }
   }
}
