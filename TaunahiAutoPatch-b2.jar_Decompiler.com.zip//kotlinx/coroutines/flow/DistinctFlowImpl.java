package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.flow.internal.NullSurrogateKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0002\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002Be\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002\u0012\u0014\u0010\u0004\u001a\u0010\u0012\u0004\u0012\u00028\u0000\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0005\u0012:\u0010\u0007\u001a6\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b\t\u0012\b\b\n\u0012\u0004\b\b(\u000b\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b\t\u0012\b\b\n\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\r0\b¢\u0006\u0002\u0010\u000eJ\u001f\u0010\u000f\u001a\u00020\u00102\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00028\u00000\u0012H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u0013RD\u0010\u0007\u001a6\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b\t\u0012\b\b\n\u0012\u0004\b\b(\u000b\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b\t\u0012\b\b\n\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\r0\b8\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u0004\u001a\u0010\u0012\u0004\u0012\u00028\u0000\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002X\u0082\u0004¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0014"},
   d2 = {"Lkotlinx/coroutines/flow/DistinctFlowImpl;", "T", "Lkotlinx/coroutines/flow/Flow;", "upstream", "keySelector", "Lkotlin/Function1;", "", "areEquivalent", "Lkotlin/Function2;", "Lkotlin/ParameterName;", "name", "old", "new", "", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;)V", "collect", "", "collector", "Lkotlinx/coroutines/flow/FlowCollector;", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
final class DistinctFlowImpl<T> implements Flow<T> {
   @NotNull
   private final Flow<T> upstream;
   @JvmField
   @NotNull
   public final Function1<T, Object> keySelector;
   @JvmField
   @NotNull
   public final Function2<Object, Object, Boolean> areEquivalent;

   public DistinctFlowImpl(@NotNull Flow<? extends T> a, @NotNull Function1<? super T, ? extends Object> a, @NotNull Function2<Object, Object, Boolean> a) {
      a.upstream = a;
      a.keySelector = a;
      a.areEquivalent = a;
   }

   @Nullable
   public Object collect(@NotNull final FlowCollector<? super T> a, @NotNull Continuation<? super Unit> a) {
      final Ref.ObjectRef a = new Ref.ObjectRef();
      a.element = NullSurrogateKt.NULL;
      Object var10000 = a.upstream.collect((FlowCollector)(new FlowCollector() {
         @Nullable
         public final Object emit(T axx, @NotNull Continuation<? super Unit> var2) {
            Object axxxxx;
            label26: {
               if (var2 instanceof <undefinedtype>) {
                  axxxxx = (<undefinedtype>)var2;
                  if ((((<undefinedtype>)axxxxx).label & Integer.MIN_VALUE) != 0) {
                     ((<undefinedtype>)axxxxx).label -= Integer.MIN_VALUE;
                     break label26;
                  }
               }

               axxxxx = new ContinuationImpl(var2) {
                  // $FF: synthetic field
                  Object result;
                  int label;

                  @Nullable
                  public final Object invokeSuspend(@NotNull Object axxx) {
                     axx.result = axxx;
                     axx.label |= Integer.MIN_VALUE;
                     return ax.emit((Object)null, (Continuation)axx);
                  }
               };
            }

            Object axxxx = ((<undefinedtype>)axxxxx).result;
            Object var6 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(((<undefinedtype>)axxxxx).label) {
            case 0:
               ResultKt.throwOnFailure(axxxx);
               Object axxx = a.keySelector.invoke(axx);
               if (a.element != NullSurrogateKt.NULL && (Boolean)a.areEquivalent.invoke(a.element, axxx)) {
                  return Unit.INSTANCE;
               }

               a.element = axxx;
               FlowCollector var10000 = a;
               ((<undefinedtype>)axxxxx).label = 1;
               if (var10000.emit(axx, (Continuation)axxxxx) == var6) {
                  return var6;
               }
               break;
            case 1:
               ResultKt.throwOnFailure(axxxx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            return Unit.INSTANCE;
         }
      }), a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }
}
