package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.InlineMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 3,
   xi = 176,
   d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u00032\u0006\u0010\u0004\u001a\u0002H\u0002H\u008a@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"},
   d2 = {"<anonymous>", "", "T", "R", "value", "emit", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$1$1"}
)
public final class FlowKt__TransformKt$filterNot$$inlined$unsafeTransform$1$2<T> implements FlowCollector {
   // $FF: synthetic field
   final FlowCollector $this_unsafeFlow;
   // $FF: synthetic field
   final Function2 $predicate$inlined;

   public FlowKt__TransformKt$filterNot$$inlined$unsafeTransform$1$2(FlowCollector a, Function2 var2) {
      a.$this_unsafeFlow = a;
      a.$predicate$inlined = var2;
   }

   @Nullable
   public final Object emit(T a, @NotNull Continuation<? super Unit> var2) {
      FlowKt__TransformKt$filterNot$$inlined$unsafeTransform$1$2$1 a;
      label38: {
         if (var2 instanceof FlowKt__TransformKt$filterNot$$inlined$unsafeTransform$1$2$1) {
            a = (FlowKt__TransformKt$filterNot$$inlined$unsafeTransform$1$2$1)var2;
            if ((a.label & Integer.MIN_VALUE) != 0) {
               a.label -= Integer.MIN_VALUE;
               break label38;
            }
         }

         a = new FlowKt__TransformKt$filterNot$$inlined$unsafeTransform$1$2$1(a, var2);
      }

      Object a = a.result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      Object var10000;
      Object a;
      FlowCollector a;
      boolean a;
      switch(a.label) {
      case 0:
         ResultKt.throwOnFailure(a);
         Continuation var10002 = (Continuation)a;
         a = a;
         a = a.$this_unsafeFlow;
         a = false;
         Function2 var9 = a.$predicate$inlined;
         a.L$0 = a;
         a.L$1 = a;
         a.label = 1;
         var10000 = var9.invoke(a, a);
         if (var10000 == var5) {
            return var5;
         }
         break;
      case 1:
         a = false;
         a = (FlowCollector)a.L$1;
         a = a.L$0;
         ResultKt.throwOnFailure(a);
         var10000 = a;
         break;
      case 2:
         a = false;
         ResultKt.throwOnFailure(a);
         return Unit.INSTANCE;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      if (!(Boolean)var10000) {
         a.L$0 = null;
         a.L$1 = null;
         a.label = 2;
         if (a.emit(a, a) == var5) {
            return var5;
         }
      }

      return Unit.INSTANCE;
   }

   @Nullable
   public final Object emit$$forInline(Object a, @NotNull Continuation a) {
      InlineMarker.mark(4);
      new FlowKt__TransformKt$filterNot$$inlined$unsafeTransform$1$2$1(a, a);
      InlineMarker.mark(5);
      FlowCollector a = a.$this_unsafeFlow;
      int a = false;
      if (!(Boolean)a.$predicate$inlined.invoke(a, a)) {
         InlineMarker.mark(0);
         a.emit(a, a);
         InlineMarker.mark(1);
      }

      return Unit.INSTANCE;
   }
}
