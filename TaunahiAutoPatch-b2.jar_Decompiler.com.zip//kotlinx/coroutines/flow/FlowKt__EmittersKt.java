package kotlinx.coroutines.flow;

import kotlin.BuilderInference;
import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.InlineMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000>\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u001a\u0010\u0010\u0000\u001a\u00020\u0001*\u0006\u0012\u0002\b\u00030\u0002H\u0000\u001as\u0010\u0003\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0004*\b\u0012\u0004\u0012\u0002H\u00040\u00022D\u0010\u0005\u001a@\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00040\u0002\u0012\u0015\u0012\u0013\u0018\u00010\u0007¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f0\u0006¢\u0006\u0002\b\r2\b\u0010\n\u001a\u0004\u0018\u00010\u0007H\u0082@ø\u0001\u0000¢\u0006\u0004\b\u000e\u0010\u000f\u001aj\u0010\u0010\u001a\b\u0012\u0004\u0012\u0002H\u00040\u0011\"\u0004\b\u0000\u0010\u0004*\b\u0012\u0004\u0012\u0002H\u00040\u00112D\u0010\u0005\u001a@\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00040\u0002\u0012\u0015\u0012\u0013\u0018\u00010\u0007¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f0\u0006¢\u0006\u0002\b\rø\u0001\u0000¢\u0006\u0002\u0010\u0012\u001aS\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u00040\u0011\"\u0004\b\u0000\u0010\u0004*\b\u0012\u0004\u0012\u0002H\u00040\u00112-\u0010\u0005\u001a)\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00040\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f0\u0014¢\u0006\u0002\b\rø\u0001\u0000¢\u0006\u0002\u0010\u0015\u001aS\u0010\u0016\u001a\b\u0012\u0004\u0012\u0002H\u00040\u0011\"\u0004\b\u0000\u0010\u0004*\b\u0012\u0004\u0012\u0002H\u00040\u00112-\u0010\u0005\u001a)\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00040\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f0\u0014¢\u0006\u0002\b\rø\u0001\u0000¢\u0006\u0002\u0010\u0015\u001as\u0010\u0017\u001a\b\u0012\u0004\u0012\u0002H\u00180\u0011\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0018*\b\u0012\u0004\u0012\u0002H\u00040\u00112D\b\u0005\u0010\u0017\u001a>\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00180\u0002\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u0019\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f0\u0006¢\u0006\u0002\b\rH\u0086\bø\u0001\u0000¢\u0006\u0002\u0010\u0012\u001as\u0010\u001a\u001a\b\u0012\u0004\u0012\u0002H\u00180\u0011\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0018*\b\u0012\u0004\u0012\u0002H\u00040\u00112D\b\u0005\u0010\u0017\u001a>\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00180\u0002\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u0019\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f0\u0006¢\u0006\u0002\b\rH\u0081\bø\u0001\u0000¢\u0006\u0002\u0010\u0012\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001b"},
   d2 = {"ensureActive", "", "Lkotlinx/coroutines/flow/FlowCollector;", "invokeSafely", "T", "action", "Lkotlin/Function3;", "", "Lkotlin/ParameterName;", "name", "cause", "Lkotlin/coroutines/Continuation;", "", "Lkotlin/ExtensionFunctionType;", "invokeSafely$FlowKt__EmittersKt", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/jvm/functions/Function3;Ljava/lang/Throwable;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "onCompletion", "Lkotlinx/coroutines/flow/Flow;", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function3;)Lkotlinx/coroutines/flow/Flow;", "onEmpty", "Lkotlin/Function2;", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/flow/Flow;", "onStart", "transform", "R", "value", "unsafeTransform", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/flow/FlowKt"
)
final class FlowKt__EmittersKt {
   @NotNull
   public static final <T, R> Flow<R> transform(@NotNull final Flow<? extends T> a, @BuilderInference @NotNull final Function3<? super FlowCollector<? super R>, ? super T, ? super Continuation<? super Unit>, ? extends Object> a) {
      int a = false;
      return FlowKt.flow((Function2)(new Function2<FlowCollector<? super R>, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               FlowCollector axxx = (FlowCollector)ax.L$0;
               Flow var10000 = a;
               FlowCollector var10001 = (FlowCollector)(new FlowCollector(a) {
                  // $FF: synthetic field
                  final Function3<FlowCollector<? super R>, T, Continuation<? super Unit>, Object> $transform;

                  public {
                     ax.$transform = axxx;
                  }

                  @Nullable
                  public final Object emit(T axxx, @NotNull Continuation<? super Unit> var2) {
                     Object axxxxx;
                     label20: {
                        if (var2 instanceof <undefinedtype>) {
                           axxxxx = (<undefinedtype>)var2;
                           if ((((<undefinedtype>)axxxxx).label & Integer.MIN_VALUE) != 0) {
                              ((<undefinedtype>)axxxxx).label -= Integer.MIN_VALUE;
                              break label20;
                           }
                        }

                        axxxxx = new ContinuationImpl(var2) {
                           // $FF: synthetic field
                           Object result;
                           int label;

                           @Nullable
                           public final Object invokeSuspend(@NotNull Object axxxx) {
                              axxx.result = axxxx;
                              axxx.label |= Integer.MIN_VALUE;
                              return ax.emit((Object)null, (Continuation)axxx);
                           }
                        };
                     }

                     Object axxxx = ((<undefinedtype>)axxxxx).result;
                     Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                     switch(((<undefinedtype>)axxxxx).label) {
                     case 0:
                        ResultKt.throwOnFailure(axxxx);
                        Function3 var10000 = ax.$transform;
                        FlowCollector var10001 = axx;
                        ((<undefinedtype>)axxxxx).label = 1;
                        if (var10000.invoke(var10001, axxx, axxxxx) == var5) {
                           return var5;
                        }
                        break;
                     case 1:
                        ResultKt.throwOnFailure(axxxx);
                        break;
                     default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                     }

                     return Unit.INSTANCE;
                  }

                  @Nullable
                  public final Object emit$$forInline(T axxx, @NotNull Continuation<? super Unit> axxxx) {
                     InlineMarker.mark(4);
                     ContinuationImpl var10001 = new ContinuationImpl(axxxx) {
                        // $FF: synthetic field
                        Object result;
                        int label;

                        @Nullable
                        public final Object invokeSuspend(@NotNull Object axxxx) {
                           axxx.result = axxxx;
                           axxx.label |= Integer.MIN_VALUE;
                           return ax.emit((Object)null, (Continuation)axxx);
                        }
                     };
                     InlineMarker.mark(5);
                     ax.$transform.invoke(axx, axxx, axxxx);
                     return Unit.INSTANCE;
                  }
               });
               Continuation var10002 = (Continuation)ax;
               ax.label = 1;
               if (var10000.collect(var10001, var10002) == var3) {
                  return var3;
               }
               break;
            case 1:
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            return Unit.INSTANCE;
         }

         @Nullable
         public final Object invokeSuspend$$forInline(@NotNull Object a1) {
            final FlowCollector axx = (FlowCollector)ax.L$0;
            Flow var10000 = a;
            FlowCollector var10001 = (FlowCollector)(new FlowCollector(a) {
               // $FF: synthetic field
               final Function3<FlowCollector<? super R>, T, Continuation<? super Unit>, Object> $transform;

               public {
                  ax.$transform = axxx;
               }

               @Nullable
               public final Object emit(T axxx, @NotNull Continuation<? super Unit> var2) {
                  Object axxxxx;
                  label20: {
                     if (var2 instanceof <undefinedtype>) {
                        axxxxx = (<undefinedtype>)var2;
                        if ((((<undefinedtype>)axxxxx).label & Integer.MIN_VALUE) != 0) {
                           ((<undefinedtype>)axxxxx).label -= Integer.MIN_VALUE;
                           break label20;
                        }
                     }

                     axxxxx = new ContinuationImpl(var2) {
                        // $FF: synthetic field
                        Object result;
                        int label;

                        @Nullable
                        public final Object invokeSuspend(@NotNull Object axxxx) {
                           axxx.result = axxxx;
                           axxx.label |= Integer.MIN_VALUE;
                           return ax.emit((Object)null, (Continuation)axxx);
                        }
                     };
                  }

                  Object axxxx = ((<undefinedtype>)axxxxx).result;
                  Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                  switch(((<undefinedtype>)axxxxx).label) {
                  case 0:
                     ResultKt.throwOnFailure(axxxx);
                     Function3 var10000 = ax.$transform;
                     FlowCollector var10001 = axx;
                     ((<undefinedtype>)axxxxx).label = 1;
                     if (var10000.invoke(var10001, axxx, axxxxx) == var5) {
                        return var5;
                     }
                     break;
                  case 1:
                     ResultKt.throwOnFailure(axxxx);
                     break;
                  default:
                     throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                  }

                  return Unit.INSTANCE;
               }

               @Nullable
               public final Object emit$$forInline(T axxx, @NotNull Continuation<? super Unit> axxxx) {
                  InlineMarker.mark(4);
                  ContinuationImpl var10001 = new ContinuationImpl(axxxx) {
                     // $FF: synthetic field
                     Object result;
                     int label;

                     @Nullable
                     public final Object invokeSuspend(@NotNull Object axxxx) {
                        axxx.result = axxxx;
                        axxx.label |= Integer.MIN_VALUE;
                        return ax.emit((Object)null, (Continuation)axxx);
                     }
                  };
                  InlineMarker.mark(5);
                  ax.$transform.invoke(axx, axxx, axxxx);
                  return Unit.INSTANCE;
               }
            });
            Continuation var10002 = (Continuation)ax;
            InlineMarker.mark(0);
            var10000.collect(var10001, var10002);
            InlineMarker.mark(1);
            return Unit.INSTANCE;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull FlowCollector<? super R> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }));
   }

   @PublishedApi
   @NotNull
   public static final <T, R> Flow<R> unsafeTransform(@NotNull Flow<? extends T> a, @BuilderInference @NotNull Function3<? super FlowCollector<? super R>, ? super T, ? super Continuation<? super Unit>, ? extends Object> a) {
      int a = false;
      int a = false;
      return (Flow)(new FlowKt__EmittersKt$unsafeTransform$$inlined$unsafeFlow$1(a, a));
   }

   @NotNull
   public static final <T> Flow<T> onStart(@NotNull Flow<? extends T> a, @NotNull Function2<? super FlowCollector<? super T>, ? super Continuation<? super Unit>, ? extends Object> a) {
      int a = false;
      return (Flow)(new FlowKt__EmittersKt$onStart$$inlined$unsafeFlow$1(a, a));
   }

   @NotNull
   public static final <T> Flow<T> onCompletion(@NotNull Flow<? extends T> a, @NotNull Function3<? super FlowCollector<? super T>, ? super Throwable, ? super Continuation<? super Unit>, ? extends Object> a) {
      int a = false;
      return (Flow)(new FlowKt__EmittersKt$onCompletion$$inlined$unsafeFlow$1(a, a));
   }

   @NotNull
   public static final <T> Flow<T> onEmpty(@NotNull Flow<? extends T> a, @NotNull Function2<? super FlowCollector<? super T>, ? super Continuation<? super Unit>, ? extends Object> a) {
      int a = false;
      return (Flow)(new FlowKt__EmittersKt$onEmpty$$inlined$unsafeFlow$1(a, a));
   }

   public static final void ensureActive(@NotNull FlowCollector<?> a) {
      if (a instanceof ThrowingCollector) {
         throw ((ThrowingCollector)a).e;
      }
   }

   private static final <T> Object invokeSafely$FlowKt__EmittersKt(FlowCollector<? super T> param0, Function3<? super FlowCollector<? super T>, ? super Throwable, ? super Continuation<? super Unit>, ? extends Object> param1, Throwable param2, Continuation<? super Unit> param3) {
      // $FF: Couldn't be decompiled
   }
}
