package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 3,
   xi = 176
)
@DebugMetadata(
   f = "Transform.kt",
   l = {223, 223},
   i = {0, 0},
   s = {"L$0", "L$1"},
   n = {"value", "$this$filter_u24lambda_u2d0"},
   m = "emit",
   c = "kotlinx.coroutines.flow.FlowKt__TransformKt$filter$$inlined$unsafeTransform$1$2"
)
public final class FlowKt__TransformKt$filter$$inlined$unsafeTransform$1$2$1 extends ContinuationImpl {
   // $FF: synthetic field
   Object result;
   int label;
   // $FF: synthetic field
   final FlowKt__TransformKt$filter$$inlined$unsafeTransform$1$2 this$0;
   Object L$0;
   Object L$1;

   public FlowKt__TransformKt$filter$$inlined$unsafeTransform$1$2$1(FlowKt__TransformKt$filter$$inlined$unsafeTransform$1$2 a, Continuation a) {
      super(a);
      a.this$0 = a;
   }

   @Nullable
   public final Object invokeSuspend(@NotNull Object a) {
      a.result = a;
      a.label |= Integer.MIN_VALUE;
      return a.this$0.emit((Object)null, (Continuation)a);
   }
}
