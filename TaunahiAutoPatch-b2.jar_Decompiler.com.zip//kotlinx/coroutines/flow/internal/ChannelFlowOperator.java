package kotlinx.coroutines.flow.internal;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.ContinuationInterceptor;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.channels.ProducerScope;
import kotlinx.coroutines.channels.SendChannel;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0000\b \u0018\u0000*\u0004\b\u0000\u0010\u0001*\u0004\b\u0001\u0010\u00022\b\u0012\u0004\u0012\u0002H\u00020\u0003B+\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b¢\u0006\u0002\u0010\fJ\u001f\u0010\r\u001a\u00020\u000e2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00028\u00010\u0010H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u0011J\u001f\u0010\u0012\u001a\u00020\u000e2\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00028\u00010\u0014H\u0094@ø\u0001\u0000¢\u0006\u0002\u0010\u0015J'\u0010\u0016\u001a\u00020\u000e2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00028\u00010\u00102\u0006\u0010\u0017\u001a\u00020\u0007H\u0082@ø\u0001\u0000¢\u0006\u0002\u0010\u0018J\u001f\u0010\u0019\u001a\u00020\u000e2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00028\u00010\u0010H¤@ø\u0001\u0000¢\u0006\u0002\u0010\u0011J\b\u0010\u001a\u001a\u00020\u001bH\u0016R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u00058\u0004X\u0085\u0004¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001c"},
   d2 = {"Lkotlinx/coroutines/flow/internal/ChannelFlowOperator;", "S", "T", "Lkotlinx/coroutines/flow/internal/ChannelFlow;", "flow", "Lkotlinx/coroutines/flow/Flow;", "context", "Lkotlin/coroutines/CoroutineContext;", "capacity", "", "onBufferOverflow", "Lkotlinx/coroutines/channels/BufferOverflow;", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/coroutines/CoroutineContext;ILkotlinx/coroutines/channels/BufferOverflow;)V", "collect", "", "collector", "Lkotlinx/coroutines/flow/FlowCollector;", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "collectTo", "scope", "Lkotlinx/coroutines/channels/ProducerScope;", "(Lkotlinx/coroutines/channels/ProducerScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "collectWithContextUndispatched", "newContext", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "flowCollect", "toString", "", "kotlinx-coroutines-core"}
)
public abstract class ChannelFlowOperator<S, T> extends ChannelFlow<T> {
   @JvmField
   @NotNull
   protected final Flow<S> flow;

   public ChannelFlowOperator(@NotNull Flow<? extends S> a, @NotNull CoroutineContext a, int a, @NotNull BufferOverflow a) {
      super(a, a, a);
      a.flow = a;
   }

   @Nullable
   protected abstract Object flowCollect(@NotNull FlowCollector<? super T> var1, @NotNull Continuation<? super Unit> var2);

   private final Object collectWithContextUndispatched(FlowCollector<? super T> a, CoroutineContext a, Continuation<? super Unit> a) {
      FlowCollector a = ChannelFlowKt.access$withUndispatchedContextCollector(a, a.getContext());
      Object var10000 = ChannelFlowKt.withContextUndispatched$default(a, a, (Object)null, (Function2)(new Function2<FlowCollector<? super T>, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               FlowCollector axxx = (FlowCollector)ax.L$0;
               ChannelFlowOperator var10000 = a;
               Continuation var10002 = (Continuation)ax;
               ax.label = 1;
               if (var10000.flowCollect(axxx, var10002) == var3) {
                  return var3;
               }
               break;
            case 1:
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            return Unit.INSTANCE;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull FlowCollector<? super T> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), a, 4, (Object)null);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   @Nullable
   protected Object collectTo(@NotNull ProducerScope<? super T> a, @NotNull Continuation<? super Unit> a) {
      return collectTo$suspendImpl(a, a, a);
   }

   // $FF: synthetic method
   static Object collectTo$suspendImpl(ChannelFlowOperator a, ProducerScope a, Continuation a) {
      Object var10000 = a.flowCollect((FlowCollector)(new SendingCollector((SendChannel)a)), a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   @Nullable
   public Object collect(@NotNull FlowCollector<? super T> a, @NotNull Continuation<? super Unit> a) {
      return collect$suspendImpl(a, a, a);
   }

   // $FF: synthetic method
   static Object collect$suspendImpl(ChannelFlowOperator a, FlowCollector a, Continuation a) {
      Object var10000;
      if (a.capacity == -3) {
         CoroutineContext a = a.getContext();
         CoroutineContext a = a.plus(a.context);
         if (Intrinsics.areEqual((Object)a, (Object)a)) {
            var10000 = a.flowCollect(a, a);
            if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
               return var10000;
            }

            return Unit.INSTANCE;
         }

         if (Intrinsics.areEqual((Object)a.get((CoroutineContext.Key)ContinuationInterceptor.Key), (Object)a.get((CoroutineContext.Key)ContinuationInterceptor.Key))) {
            var10000 = a.collectWithContextUndispatched(a, a, a);
            if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
               return var10000;
            }

            return Unit.INSTANCE;
         }
      }

      var10000 = a.collect(a, a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   @NotNull
   public String toString() {
      return a.flow + " -> " + super.toString();
   }

   // $FF: synthetic method
   public static final Object access$collectWithContextUndispatched(ChannelFlowOperator a, FlowCollector a, CoroutineContext a, Continuation a) {
      return a.collectWithContextUndispatched(a, a, a);
   }
}
