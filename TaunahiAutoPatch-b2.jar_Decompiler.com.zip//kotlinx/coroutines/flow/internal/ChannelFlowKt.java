package kotlinx.coroutines.flow.internal;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.TypeIntrinsics;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.internal.ThreadContextKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u00000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a[\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0001\"\u0004\b\u0001\u0010\u00022\u0006\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u0002H\u00022\b\b\u0002\u0010\u0006\u001a\u00020\u00072\"\u0010\b\u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00010\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\tH\u0080@ø\u0001\u0000¢\u0006\u0002\u0010\u000b\u001a\u001e\u0010\f\u001a\b\u0012\u0004\u0012\u0002H\u00010\r\"\u0004\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u000eH\u0000\u001a&\u0010\u000f\u001a\b\u0012\u0004\u0012\u0002H\u00010\u0010\"\u0004\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u00102\u0006\u0010\u0011\u001a\u00020\u0004H\u0002\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0012"},
   d2 = {"withContextUndispatched", "T", "V", "newContext", "Lkotlin/coroutines/CoroutineContext;", "value", "countOrElement", "", "block", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "(Lkotlin/coroutines/CoroutineContext;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "asChannelFlow", "Lkotlinx/coroutines/flow/internal/ChannelFlow;", "Lkotlinx/coroutines/flow/Flow;", "withUndispatchedContextCollector", "Lkotlinx/coroutines/flow/FlowCollector;", "emitContext", "kotlinx-coroutines-core"}
)
public final class ChannelFlowKt {
   @NotNull
   public static final <T> ChannelFlow<T> asChannelFlow(@NotNull Flow<? extends T> a) {
      ChannelFlow var10000 = a instanceof ChannelFlow ? (ChannelFlow)a : null;
      if ((a instanceof ChannelFlow ? (ChannelFlow)a : null) == null) {
         var10000 = (ChannelFlow)(new ChannelFlowOperatorImpl(a, (CoroutineContext)null, 0, (BufferOverflow)null, 14, (DefaultConstructorMarker)null));
      }

      return var10000;
   }

   private static final <T> FlowCollector<T> withUndispatchedContextCollector(FlowCollector<? super T> a, CoroutineContext a) {
      return (a instanceof SendingCollector ? true : a instanceof NopCollector) ? a : (FlowCollector)(new UndispatchedContextCollector(a, a));
   }

   @Nullable
   public static final <T, V> Object withContextUndispatched(@NotNull CoroutineContext a, V a, @NotNull Object a, @NotNull Function2<? super V, ? super Continuation<? super T>, ? extends Object> a, @NotNull Continuation<? super T> a) {
      Continuation a = a;
      int a = false;
      int a = false;
      Object a = ThreadContextKt.updateThreadContext(a, a);

      Object var12;
      try {
         int a = false;
         Continuation var11 = (Continuation)(new StackFrameContinuation(a, a));
         var12 = ((Function2)TypeIntrinsics.beforeCheckcastToFunctionOfArity(a, 2)).invoke(a, var11);
      } finally {
         ThreadContextKt.restoreThreadContext(a, a);
      }

      if (var12 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         DebugProbesKt.probeCoroutineSuspended(a);
      }

      return var12;
   }

   // $FF: synthetic method
   public static Object withContextUndispatched$default(CoroutineContext var0, Object var1, Object var2, Function2 var3, Continuation var4, int var5, Object var6) {
      if ((var5 & 4) != 0) {
         var2 = ThreadContextKt.threadContextElements(var0);
      }

      return withContextUndispatched(var0, var1, var2, var3, var4);
   }

   // $FF: synthetic method
   public static final FlowCollector access$withUndispatchedContextCollector(FlowCollector a, CoroutineContext a) {
      return withUndispatchedContextCollector(a, a);
   }
}
