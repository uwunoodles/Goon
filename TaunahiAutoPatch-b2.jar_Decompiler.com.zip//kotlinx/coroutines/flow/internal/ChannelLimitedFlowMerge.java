package kotlinx.coroutines.flow.internal;

import java.util.Iterator;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.channels.ProduceKt;
import kotlinx.coroutines.channels.ProducerScope;
import kotlinx.coroutines.channels.ReceiveChannel;
import kotlinx.coroutines.channels.SendChannel;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0000\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B7\u0012\u0012\u0010\u0003\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00050\u0004\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\t\u0012\b\b\u0002\u0010\n\u001a\u00020\u000b¢\u0006\u0002\u0010\fJ\u001f\u0010\r\u001a\u00020\u000e2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00028\u00000\u0010H\u0094@ø\u0001\u0000¢\u0006\u0002\u0010\u0011J&\u0010\u0012\u001a\b\u0012\u0004\u0012\u00028\u00000\u00022\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0014J\u0016\u0010\u0013\u001a\b\u0012\u0004\u0012\u00028\u00000\u00142\u0006\u0010\u000f\u001a\u00020\u0015H\u0016R\u001a\u0010\u0003\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0016"},
   d2 = {"Lkotlinx/coroutines/flow/internal/ChannelLimitedFlowMerge;", "T", "Lkotlinx/coroutines/flow/internal/ChannelFlow;", "flows", "", "Lkotlinx/coroutines/flow/Flow;", "context", "Lkotlin/coroutines/CoroutineContext;", "capacity", "", "onBufferOverflow", "Lkotlinx/coroutines/channels/BufferOverflow;", "(Ljava/lang/Iterable;Lkotlin/coroutines/CoroutineContext;ILkotlinx/coroutines/channels/BufferOverflow;)V", "collectTo", "", "scope", "Lkotlinx/coroutines/channels/ProducerScope;", "(Lkotlinx/coroutines/channels/ProducerScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "create", "produceImpl", "Lkotlinx/coroutines/channels/ReceiveChannel;", "Lkotlinx/coroutines/CoroutineScope;", "kotlinx-coroutines-core"}
)
public final class ChannelLimitedFlowMerge<T> extends ChannelFlow<T> {
   @NotNull
   private final Iterable<Flow<T>> flows;

   public ChannelLimitedFlowMerge(@NotNull Iterable<? extends Flow<? extends T>> a, @NotNull CoroutineContext a, int a, @NotNull BufferOverflow a) {
      super(a, a, a);
      a.flows = a;
   }

   // $FF: synthetic method
   public ChannelLimitedFlowMerge(Iterable var1, CoroutineContext var2, int var3, BufferOverflow var4, int var5, DefaultConstructorMarker var6) {
      if ((var5 & 2) != 0) {
         var2 = (CoroutineContext)EmptyCoroutineContext.INSTANCE;
      }

      if ((var5 & 4) != 0) {
         var3 = -2;
      }

      if ((var5 & 8) != 0) {
         var4 = BufferOverflow.SUSPEND;
      }

      this(var1, var2, var3, var4);
   }

   @NotNull
   protected ChannelFlow<T> create(@NotNull CoroutineContext a, int a, @NotNull BufferOverflow a) {
      return (ChannelFlow)(new ChannelLimitedFlowMerge(a.flows, a, a, a));
   }

   @NotNull
   public ReceiveChannel<T> produceImpl(@NotNull CoroutineScope a) {
      return ProduceKt.produce(a, a.context, a.capacity, a.getCollectToFun$kotlinx_coroutines_core());
   }

   @Nullable
   protected Object collectTo(@NotNull ProducerScope<? super T> a, @NotNull Continuation<? super Unit> a2) {
      final SendingCollector a = new SendingCollector((SendChannel)a);
      Iterable a = a.flows;
      int a = false;
      Iterator var6 = a.iterator();

      while(var6.hasNext()) {
         Object a = var6.next();
         final Flow a = (Flow)a;
         int a = false;
         BuildersKt.launch$default((CoroutineScope)a, (CoroutineContext)null, (CoroutineStart)null, (Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object axx) {
               Object var2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
               switch(ax.label) {
               case 0:
                  ResultKt.throwOnFailure(axx);
                  Flow var10000 = a;
                  FlowCollector var10001 = (FlowCollector)a;
                  Continuation var10002 = (Continuation)ax;
                  ax.label = 1;
                  if (var10000.collect(var10001, var10002) == var2) {
                     return var2;
                  }
                  break;
               case 1:
                  ResultKt.throwOnFailure(axx);
                  break;
               default:
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
               }

               return Unit.INSTANCE;
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object a1, @NotNull Continuation<?> axx) {
               return (Continuation)(new <anonymous constructor>(axx));
            }

            @Nullable
            public final Object invoke(@NotNull CoroutineScope axx, @Nullable Continuation<? super Unit> axxx) {
               return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
            }
         }), 3, (Object)null);
      }

      return Unit.INSTANCE;
   }
}
