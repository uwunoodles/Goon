package kotlinx.coroutines.flow.internal;

import java.util.concurrent.CancellationException;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u0000*\u0004\b\u0000\u0010\u0001*\u0004\b\u0001\u0010\u00022\u000e\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u00020\u0003Bx\u0012B\u0010\u0004\u001a>\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00010\u0006\u0012\u0013\u0012\u00118\u0000¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\t\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\n\u0012\u0006\u0012\u0004\u0018\u00010\f0\u0005¢\u0006\u0002\b\r\u0012\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00028\u00000\u000f\u0012\b\b\u0002\u0010\u0010\u001a\u00020\u0011\u0012\b\b\u0002\u0010\u0012\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u0014\u001a\u00020\u0015ø\u0001\u0000¢\u0006\u0002\u0010\u0016J&\u0010\u0018\u001a\b\u0012\u0004\u0012\u00028\u00010\u00192\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0014J\u001f\u0010\u001a\u001a\u00020\u000b2\f\u0010\u001b\u001a\b\u0012\u0004\u0012\u00028\u00010\u0006H\u0094@ø\u0001\u0000¢\u0006\u0002\u0010\u001cRO\u0010\u0004\u001a>\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00010\u0006\u0012\u0013\u0012\u00118\u0000¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\t\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\n\u0012\u0006\u0012\u0004\u0018\u00010\f0\u0005¢\u0006\u0002\b\rX\u0082\u0004ø\u0001\u0000¢\u0006\u0004\n\u0002\u0010\u0017\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001d"},
   d2 = {"Lkotlinx/coroutines/flow/internal/ChannelFlowTransformLatest;", "T", "R", "Lkotlinx/coroutines/flow/internal/ChannelFlowOperator;", "transform", "Lkotlin/Function3;", "Lkotlinx/coroutines/flow/FlowCollector;", "Lkotlin/ParameterName;", "name", "value", "Lkotlin/coroutines/Continuation;", "", "", "Lkotlin/ExtensionFunctionType;", "flow", "Lkotlinx/coroutines/flow/Flow;", "context", "Lkotlin/coroutines/CoroutineContext;", "capacity", "", "onBufferOverflow", "Lkotlinx/coroutines/channels/BufferOverflow;", "(Lkotlin/jvm/functions/Function3;Lkotlinx/coroutines/flow/Flow;Lkotlin/coroutines/CoroutineContext;ILkotlinx/coroutines/channels/BufferOverflow;)V", "Lkotlin/jvm/functions/Function3;", "create", "Lkotlinx/coroutines/flow/internal/ChannelFlow;", "flowCollect", "collector", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public final class ChannelFlowTransformLatest<T, R> extends ChannelFlowOperator<T, R> {
   @NotNull
   private final Function3<FlowCollector<? super R>, T, Continuation<? super Unit>, Object> transform;

   public ChannelFlowTransformLatest(@NotNull Function3<? super FlowCollector<? super R>, ? super T, ? super Continuation<? super Unit>, ? extends Object> a, @NotNull Flow<? extends T> a, @NotNull CoroutineContext a, int a, @NotNull BufferOverflow a) {
      super(a, a, a, a);
      a.transform = a;
   }

   // $FF: synthetic method
   public ChannelFlowTransformLatest(Function3 var1, Flow var2, CoroutineContext var3, int var4, BufferOverflow var5, int var6, DefaultConstructorMarker var7) {
      if ((var6 & 4) != 0) {
         var3 = (CoroutineContext)EmptyCoroutineContext.INSTANCE;
      }

      if ((var6 & 8) != 0) {
         var4 = -2;
      }

      if ((var6 & 16) != 0) {
         var5 = BufferOverflow.SUSPEND;
      }

      this(var1, var2, var3, var4, var5);
   }

   @NotNull
   protected ChannelFlow<R> create(@NotNull CoroutineContext a, int a, @NotNull BufferOverflow a) {
      return (ChannelFlow)(new ChannelFlowTransformLatest(a.transform, a.flow, a, a, a));
   }

   @Nullable
   protected Object flowCollect(@NotNull final FlowCollector<? super R> a, @NotNull Continuation<? super Unit> a) {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (!(a instanceof SendingCollector)) {
            throw new AssertionError();
         }
      }

      Object var10000 = CoroutineScopeKt.coroutineScope((Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               final CoroutineScope axxx = (CoroutineScope)ax.L$0;
               final Ref.ObjectRef axxxx = new Ref.ObjectRef();
               Flow var10000 = a.flow;
               FlowCollector var10001 = (FlowCollector)(new FlowCollector() {
                  @Nullable
                  public final Object emit(final T axxxxx, @NotNull Continuation<? super Unit> var2) {
                     Object axxxxxx;
                     label28: {
                        if (var2 instanceof <undefinedtype>) {
                           axxxxxx = (<undefinedtype>)var2;
                           if ((((<undefinedtype>)axxxxxx).label & Integer.MIN_VALUE) != 0) {
                              ((<undefinedtype>)axxxxxx).label -= Integer.MIN_VALUE;
                              break label28;
                           }
                        }

                        axxxxxx = new ContinuationImpl(var2) {
                           Object L$0;
                           Object L$1;
                           Object L$2;
                           // $FF: synthetic field
                           Object result;
                           int label;

                           @Nullable
                           public final Object invokeSuspend(@NotNull Object axxxxx) {
                              axx.result = axxxxx;
                              axx.label |= Integer.MIN_VALUE;
                              return ax.emit((Object)null, (Continuation)axx);
                           }
                        };
                     }

                     Object axx = ((<undefinedtype>)axxxxxx).result;
                     Object var8 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                     Job var3;
                     boolean axxxxxxx;
                     switch(((<undefinedtype>)axxxxxx).label) {
                     case 0:
                        ResultKt.throwOnFailure(axx);
                        Job var10000 = (Job)axxxx.element;
                        if (var10000 != null) {
                           var3 = var10000;
                           axxxxxxx = false;
                           var3.cancel((CancellationException)(new ChildCancelledException()));
                           ((<undefinedtype>)axxxxxx).L$0 = ax;
                           ((<undefinedtype>)axxxxxx).L$1 = axxxxx;
                           ((<undefinedtype>)axxxxxx).L$2 = var3;
                           ((<undefinedtype>)axxxxxx).label = 1;
                           if (var3.join((Continuation)axxxxxx) == var8) {
                              return var8;
                           }
                        }
                        break;
                     case 1:
                        axxxxxxx = false;
                        var3 = (Job)((<undefinedtype>)axxxxxx).L$2;
                        axxxxx = ((<undefinedtype>)axxxxxx).L$1;
                        ax = (<undefinedtype>)((<undefinedtype>)axxxxxx).L$0;
                        ResultKt.throwOnFailure(axx);
                        break;
                     default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                     }

                     axxxx.element = BuildersKt.launch$default(axxx, (CoroutineContext)null, CoroutineStart.UNDISPATCHED, (Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
                        int label;

                        @Nullable
                        public final Object invokeSuspend(@NotNull Object axx) {
                           Object var2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                           switch(ax.label) {
                           case 0:
                              ResultKt.throwOnFailure(axx);
                              Function3 var10000 = a.transform;
                              FlowCollector var10001 = a;
                              Object var10002 = axxxxx;
                              ax.label = 1;
                              if (var10000.invoke(var10001, var10002, ax) == var2) {
                                 return var2;
                              }
                              break;
                           case 1:
                              ResultKt.throwOnFailure(axx);
                              break;
                           default:
                              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                           }

                           return Unit.INSTANCE;
                        }

                        @NotNull
                        public final Continuation<Unit> create(@Nullable Object a1, @NotNull Continuation<?> axx) {
                           return (Continuation)(new <anonymous constructor>(axx));
                        }

                        @Nullable
                        public final Object invoke(@NotNull CoroutineScope axx, @Nullable Continuation<? super Unit> axxxxxx) {
                           return ((<undefinedtype>)ax.create(axx, axxxxxx)).invokeSuspend(Unit.INSTANCE);
                        }
                     }), 1, (Object)null);
                     return Unit.INSTANCE;
                  }
               });
               Continuation var10002 = (Continuation)ax;
               ax.label = 1;
               if (var10000.collect(var10001, var10002) == var4) {
                  return var4;
               }
               break;
            case 1:
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            return Unit.INSTANCE;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull CoroutineScope axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }
}
