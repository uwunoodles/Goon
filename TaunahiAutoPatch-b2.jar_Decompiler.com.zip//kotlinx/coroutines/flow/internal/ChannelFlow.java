package kotlinx.coroutines.flow.internal;

import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.DebugStringsKt;
import kotlinx.coroutines.InternalCoroutinesApi;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.channels.ProduceKt;
import kotlinx.coroutines.channels.ProducerScope;
import kotlinx.coroutines.channels.ReceiveChannel;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0010\u0000\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B\u001d\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tJ\n\u0010\u0015\u001a\u0004\u0018\u00010\u0016H\u0014J\u001f\u0010\u0017\u001a\u00020\u000e2\f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00028\u00000\u0019H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u001aJ\u001f\u0010\u001b\u001a\u00020\u000e2\f\u0010\u001c\u001a\b\u0012\u0004\u0012\u00028\u00000\fH¤@ø\u0001\u0000¢\u0006\u0002\u0010\u001dJ&\u0010\u001e\u001a\b\u0012\u0004\u0012\u00028\u00000\u00002\u0006\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH$J\u0010\u0010\u001f\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010 H\u0016J&\u0010!\u001a\b\u0012\u0004\u0012\u00028\u00000 2\u0006\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0016J\u0016\u0010\"\u001a\b\u0012\u0004\u0012\u00028\u00000#2\u0006\u0010\u001c\u001a\u00020$H\u0016J\b\u0010%\u001a\u00020\u0016H\u0016R\u0010\u0010\u0005\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R9\u0010\n\u001a$\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\f\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000e0\r\u0012\u0006\u0012\u0004\u0018\u00010\u000f0\u000b8@X\u0080\u0004ø\u0001\u0000¢\u0006\u0006\u001a\u0004\b\u0010\u0010\u0011R\u0010\u0010\u0003\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u00020\b8\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0012\u001a\u00020\u00068@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0013\u0010\u0014\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006&"},
   d2 = {"Lkotlinx/coroutines/flow/internal/ChannelFlow;", "T", "Lkotlinx/coroutines/flow/internal/FusibleFlow;", "context", "Lkotlin/coroutines/CoroutineContext;", "capacity", "", "onBufferOverflow", "Lkotlinx/coroutines/channels/BufferOverflow;", "(Lkotlin/coroutines/CoroutineContext;ILkotlinx/coroutines/channels/BufferOverflow;)V", "collectToFun", "Lkotlin/Function2;", "Lkotlinx/coroutines/channels/ProducerScope;", "Lkotlin/coroutines/Continuation;", "", "", "getCollectToFun$kotlinx_coroutines_core", "()Lkotlin/jvm/functions/Function2;", "produceCapacity", "getProduceCapacity$kotlinx_coroutines_core", "()I", "additionalToStringProps", "", "collect", "collector", "Lkotlinx/coroutines/flow/FlowCollector;", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "collectTo", "scope", "(Lkotlinx/coroutines/channels/ProducerScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "create", "dropChannelOperators", "Lkotlinx/coroutines/flow/Flow;", "fuse", "produceImpl", "Lkotlinx/coroutines/channels/ReceiveChannel;", "Lkotlinx/coroutines/CoroutineScope;", "toString", "kotlinx-coroutines-core"}
)
@InternalCoroutinesApi
public abstract class ChannelFlow<T> implements FusibleFlow<T> {
   @JvmField
   @NotNull
   public final CoroutineContext context;
   @JvmField
   public final int capacity;
   @JvmField
   @NotNull
   public final BufferOverflow onBufferOverflow;

   public ChannelFlow(@NotNull CoroutineContext a, int a, @NotNull BufferOverflow a) {
      a.context = a;
      a.capacity = a;
      a.onBufferOverflow = a;
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a.capacity == -1) {
            throw new AssertionError();
         }
      }

   }

   @NotNull
   public final Function2<ProducerScope<? super T>, Continuation<? super Unit>, Object> getCollectToFun$kotlinx_coroutines_core() {
      return (Function2)(new Function2<ProducerScope<? super T>, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               ProducerScope axxx = (ProducerScope)ax.L$0;
               ChannelFlow var10000 = a;
               Continuation var10002 = (Continuation)ax;
               ax.label = 1;
               if (var10000.collectTo(axxx, var10002) == var3) {
                  return var3;
               }
               break;
            case 1:
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            return Unit.INSTANCE;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull ProducerScope<? super T> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      });
   }

   public final int getProduceCapacity$kotlinx_coroutines_core() {
      return a.capacity == -3 ? -2 : a.capacity;
   }

   @Nullable
   public Flow<T> dropChannelOperators() {
      return null;
   }

   @NotNull
   public Flow<T> fuse(@NotNull CoroutineContext a, int a, @NotNull BufferOverflow a) {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a == -1) {
            throw new AssertionError();
         }
      }

      CoroutineContext a = a.plus(a.context);
      int a = false;
      BufferOverflow a = null;
      int a;
      if (a != BufferOverflow.SUSPEND) {
         a = a;
         a = a;
      } else {
         int var10000;
         if (a.capacity == -3) {
            var10000 = a;
         } else if (a == -3) {
            var10000 = a.capacity;
         } else if (a.capacity == -2) {
            var10000 = a;
         } else if (a == -2) {
            var10000 = a.capacity;
         } else {
            boolean a;
            if (DebugKt.getASSERTIONS_ENABLED()) {
               a = false;
               if (a.capacity < 0) {
                  throw new AssertionError();
               }
            }

            if (DebugKt.getASSERTIONS_ENABLED()) {
               a = false;
               if (a < 0) {
                  throw new AssertionError();
               }
            }

            int a = a.capacity + a;
            var10000 = a >= 0 ? a : Integer.MAX_VALUE;
         }

         a = var10000;
         a = a.onBufferOverflow;
      }

      return Intrinsics.areEqual((Object)a, (Object)a.context) && a == a.capacity && a == a.onBufferOverflow ? (Flow)a : (Flow)a.create(a, a, a);
   }

   @NotNull
   protected abstract ChannelFlow<T> create(@NotNull CoroutineContext var1, int var2, @NotNull BufferOverflow var3);

   @Nullable
   protected abstract Object collectTo(@NotNull ProducerScope<? super T> var1, @NotNull Continuation<? super Unit> var2);

   @NotNull
   public ReceiveChannel<T> produceImpl(@NotNull CoroutineScope a) {
      return ProduceKt.produce$default(a, a.context, a.getProduceCapacity$kotlinx_coroutines_core(), a.onBufferOverflow, CoroutineStart.ATOMIC, (Function1)null, a.getCollectToFun$kotlinx_coroutines_core(), 16, (Object)null);
   }

   @Nullable
   public Object collect(@NotNull FlowCollector<? super T> a, @NotNull Continuation<? super Unit> a) {
      return collect$suspendImpl(a, a, a);
   }

   // $FF: synthetic method
   static Object collect$suspendImpl(final ChannelFlow a, final FlowCollector a, Continuation a) {
      Object var10000 = CoroutineScopeKt.coroutineScope((Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               CoroutineScope axxx = (CoroutineScope)ax.L$0;
               FlowCollector var10000 = a;
               ReceiveChannel var10001 = a.produceImpl(axxx);
               Continuation var10002 = (Continuation)ax;
               ax.label = 1;
               if (FlowKt.emitAll(var10000, var10001, var10002) == var3) {
                  return var3;
               }
               break;
            case 1:
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            return Unit.INSTANCE;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull CoroutineScope axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   @Nullable
   protected String additionalToStringProps() {
      return null;
   }

   @NotNull
   public String toString() {
      ArrayList a = new ArrayList(4);
      String var10000 = a.additionalToStringProps();
      if (var10000 != null) {
         String a = var10000;
         int a = false;
         a.add(a);
      }

      if (a.context != EmptyCoroutineContext.INSTANCE) {
         a.add("context=" + a.context);
      }

      if (a.capacity != -3) {
         a.add("capacity=" + a.capacity);
      }

      if (a.onBufferOverflow != BufferOverflow.SUSPEND) {
         a.add("onBufferOverflow=" + a.onBufferOverflow);
      }

      return DebugStringsKt.getClassSimpleName(a) + '[' + CollectionsKt.joinToString$default((Iterable)a, (CharSequence)", ", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 62, (Object)null) + ']';
   }
}
