package kotlinx.coroutines.flow.internal;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.JobKt;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.channels.ProduceKt;
import kotlinx.coroutines.channels.ProducerScope;
import kotlinx.coroutines.channels.ReceiveChannel;
import kotlinx.coroutines.channels.SendChannel;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.sync.Semaphore;
import kotlinx.coroutines.sync.SemaphoreKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0000\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B?\u0012\u0012\u0010\u0003\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00040\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u0012\b\b\u0002\u0010\t\u001a\u00020\u0006\u0012\b\b\u0002\u0010\n\u001a\u00020\u000b¢\u0006\u0002\u0010\fJ\b\u0010\r\u001a\u00020\u000eH\u0014J\u001f\u0010\u000f\u001a\u00020\u00102\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00028\u00000\u0012H\u0094@ø\u0001\u0000¢\u0006\u0002\u0010\u0013J&\u0010\u0014\u001a\b\u0012\u0004\u0012\u00028\u00000\u00022\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u000bH\u0014J\u0016\u0010\u0015\u001a\b\u0012\u0004\u0012\u00028\u00000\u00162\u0006\u0010\u0011\u001a\u00020\u0017H\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0003\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00040\u0004X\u0082\u0004¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0018"},
   d2 = {"Lkotlinx/coroutines/flow/internal/ChannelFlowMerge;", "T", "Lkotlinx/coroutines/flow/internal/ChannelFlow;", "flow", "Lkotlinx/coroutines/flow/Flow;", "concurrency", "", "context", "Lkotlin/coroutines/CoroutineContext;", "capacity", "onBufferOverflow", "Lkotlinx/coroutines/channels/BufferOverflow;", "(Lkotlinx/coroutines/flow/Flow;ILkotlin/coroutines/CoroutineContext;ILkotlinx/coroutines/channels/BufferOverflow;)V", "additionalToStringProps", "", "collectTo", "", "scope", "Lkotlinx/coroutines/channels/ProducerScope;", "(Lkotlinx/coroutines/channels/ProducerScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "create", "produceImpl", "Lkotlinx/coroutines/channels/ReceiveChannel;", "Lkotlinx/coroutines/CoroutineScope;", "kotlinx-coroutines-core"}
)
public final class ChannelFlowMerge<T> extends ChannelFlow<T> {
   @NotNull
   private final Flow<Flow<T>> flow;
   private final int concurrency;

   public ChannelFlowMerge(@NotNull Flow<? extends Flow<? extends T>> a, int a, @NotNull CoroutineContext a, int a, @NotNull BufferOverflow a) {
      super(a, a, a);
      a.flow = a;
      a.concurrency = a;
   }

   // $FF: synthetic method
   public ChannelFlowMerge(Flow var1, int var2, CoroutineContext var3, int var4, BufferOverflow var5, int var6, DefaultConstructorMarker var7) {
      if ((var6 & 4) != 0) {
         var3 = (CoroutineContext)EmptyCoroutineContext.INSTANCE;
      }

      if ((var6 & 8) != 0) {
         var4 = -2;
      }

      if ((var6 & 16) != 0) {
         var5 = BufferOverflow.SUSPEND;
      }

      this(var1, var2, var3, var4, var5);
   }

   @NotNull
   protected ChannelFlow<T> create(@NotNull CoroutineContext a, int a, @NotNull BufferOverflow a) {
      return (ChannelFlow)(new ChannelFlowMerge(a.flow, a.concurrency, a, a, a));
   }

   @NotNull
   public ReceiveChannel<T> produceImpl(@NotNull CoroutineScope a) {
      return ProduceKt.produce(a, a.context, a.capacity, a.getCollectToFun$kotlinx_coroutines_core());
   }

   @Nullable
   protected Object collectTo(@NotNull final ProducerScope<? super T> a, @NotNull Continuation<? super Unit> a) {
      final Semaphore a = SemaphoreKt.Semaphore$default(a.concurrency, 0, 2, (Object)null);
      final SendingCollector a = new SendingCollector((SendChannel)a);
      final Job a = (Job)a.getContext().get((CoroutineContext.Key)Job.Key);
      Object var10000 = a.flow.collect((FlowCollector)(new FlowCollector() {
         @Nullable
         public final Object emit(@NotNull final Flow<? extends T> axx, @NotNull Continuation<? super Unit> var2) {
            Object axxxx;
            label25: {
               if (var2 instanceof <undefinedtype>) {
                  axxxx = (<undefinedtype>)var2;
                  if ((((<undefinedtype>)axxxx).label & Integer.MIN_VALUE) != 0) {
                     ((<undefinedtype>)axxxx).label -= Integer.MIN_VALUE;
                     break label25;
                  }
               }

               axxxx = new ContinuationImpl(var2) {
                  Object L$0;
                  Object L$1;
                  // $FF: synthetic field
                  Object result;
                  int label;

                  @Nullable
                  public final Object invokeSuspend(@NotNull Object axxx) {
                     axx.result = axxx;
                     axx.label |= Integer.MIN_VALUE;
                     return ax.emit((Flow)null, (Continuation)axx);
                  }
               };
            }

            Object axxx = ((<undefinedtype>)axxxx).result;
            Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(((<undefinedtype>)axxxx).label) {
            case 0:
               ResultKt.throwOnFailure(axxx);
               Job var10000 = a;
               if (var10000 != null) {
                  JobKt.ensureActive(var10000);
               }

               Semaphore var6 = a;
               ((<undefinedtype>)axxxx).L$0 = ax;
               ((<undefinedtype>)axxxx).L$1 = axx;
               ((<undefinedtype>)axxxx).label = 1;
               if (var6.acquire((Continuation)axxxx) == var5) {
                  return var5;
               }
               break;
            case 1:
               axx = (Flow)((<undefinedtype>)axxxx).L$1;
               ax = (<undefinedtype>)((<undefinedtype>)axxxx).L$0;
               ResultKt.throwOnFailure(axxx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            BuildersKt.launch$default((CoroutineScope)a, (CoroutineContext)null, (CoroutineStart)null, (Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
               int label;

               @Nullable
               public final Object invokeSuspend(@NotNull Object param1) {
                  // $FF: Couldn't be decompiled
               }

               @NotNull
               public final Continuation<Unit> create(@Nullable Object a1, @NotNull Continuation<?> axxx) {
                  return (Continuation)(new <anonymous constructor>(axxx));
               }

               @Nullable
               public final Object invoke(@NotNull CoroutineScope axxx, @Nullable Continuation<? super Unit> axxxx) {
                  return ((<undefinedtype>)ax.create(axxx, axxxx)).invokeSuspend(Unit.INSTANCE);
               }
            }), 3, (Object)null);
            return Unit.INSTANCE;
         }
      }), a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   @NotNull
   protected String additionalToStringProps() {
      return "concurrency=" + a.concurrency;
   }
}
