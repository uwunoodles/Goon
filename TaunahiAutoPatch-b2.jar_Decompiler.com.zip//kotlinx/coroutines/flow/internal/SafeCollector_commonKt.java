package kotlinx.coroutines.flow.internal;

import kotlin.BuilderInference;
import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.JvmName;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.InlineMarker;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.internal.ScopeCoroutine;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000:\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001aN\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u00022/\b\u0005\u0010\u0003\u001a)\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070\u0006\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0004¢\u0006\u0002\b\tH\u0081\bø\u0001\u0000¢\u0006\u0002\u0010\n\u001a\u0018\u0010\u000b\u001a\u00020\u0007*\u0006\u0012\u0002\b\u00030\f2\u0006\u0010\r\u001a\u00020\u000eH\u0001\u001a\u001b\u0010\u000f\u001a\u0004\u0018\u00010\u0010*\u0004\u0018\u00010\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0010H\u0080\u0010\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0012"},
   d2 = {"unsafeFlow", "Lkotlinx/coroutines/flow/Flow;", "T", "block", "Lkotlin/Function2;", "Lkotlinx/coroutines/flow/FlowCollector;", "Lkotlin/coroutines/Continuation;", "", "", "Lkotlin/ExtensionFunctionType;", "(Lkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/flow/Flow;", "checkContext", "Lkotlinx/coroutines/flow/internal/SafeCollector;", "currentContext", "Lkotlin/coroutines/CoroutineContext;", "transitiveCoroutineParent", "Lkotlinx/coroutines/Job;", "collectJob", "kotlinx-coroutines-core"}
)
public final class SafeCollector_commonKt {
   @JvmName(
      name = "checkContext"
   )
   public static final void checkContext(@NotNull final SafeCollector<?> a, @NotNull CoroutineContext a) {
      int a = ((Number)a.fold(0, (Function2)(new Function2<Integer, CoroutineContext.Element, Integer>() {
         @NotNull
         public final Integer invoke(int axxx, @NotNull CoroutineContext.Element axxxx) {
            CoroutineContext.Key axxxxx = axxxx.getKey();
            CoroutineContext.Element axxxxxx = a.collectContext.get(axxxxx);
            if (axxxxx != Job.Key) {
               return axxxx != axxxxxx ? Integer.MIN_VALUE : axxx + 1;
            } else {
               Job axxxxxxx = (Job)axxxxxx;
               Job axx = SafeCollector_commonKt.transitiveCoroutineParent((Job)axxxx, axxxxxxx);
               if (axx != axxxxxxx) {
                  throw new IllegalStateException(("Flow invariant is violated:\n\t\tEmission from another coroutine is detected.\n\t\tChild of " + axx + ", expected child of " + axxxxxxx + ".\n\t\tFlowCollector is not thread-safe and concurrent emissions are prohibited.\n\t\tTo mitigate this restriction please use 'channelFlow' builder instead of 'flow'").toString());
               } else {
                  return axxxxxxx == null ? axxx : axxx + 1;
               }
            }
         }
      }))).intValue();
      if (a != a.collectContextSize) {
         throw new IllegalStateException(("Flow invariant is violated:\n\t\tFlow was collected in " + a.collectContext + ",\n\t\tbut emission happened in " + a + ".\n\t\tPlease refer to 'flow' documentation or use 'flowOn' instead").toString());
      }
   }

   @Nullable
   public static final Job transitiveCoroutineParent(@Nullable Job a, @Nullable Job a) {
      Job var2 = a;

      for(Job var3 = a; var2 != null; var3 = var3) {
         if (var2 == var3) {
            return var2;
         }

         if (!(var2 instanceof ScopeCoroutine)) {
            return var2;
         }

         var2 = ((ScopeCoroutine)var2).getParent$kotlinx_coroutines_core();
      }

      return null;
   }

   @PublishedApi
   @NotNull
   public static final <T> Flow<T> unsafeFlow(@BuilderInference @NotNull final Function2<? super FlowCollector<? super T>, ? super Continuation<? super Unit>, ? extends Object> a) {
      int a = false;
      return (Flow)(new Flow<T>() {
         @Nullable
         public Object collect(@NotNull FlowCollector<? super T> axx, @NotNull Continuation<? super Unit> axxx) {
            Object var10000 = a.invoke(axx, axxx);
            return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
         }

         @Nullable
         public Object collect$$forInline(@NotNull FlowCollector<? super T> axx, @NotNull Continuation<? super Unit> axxx) {
            InlineMarker.mark(4);
            ContinuationImpl var10001 = new ContinuationImpl(axxx) {
               // $FF: synthetic field
               Object result;
               int label;

               @Nullable
               public final Object invokeSuspend(@NotNull Object axxx) {
                  axx.result = axxx;
                  axx.label |= Integer.MIN_VALUE;
                  return ax.collect((FlowCollector)null, (Continuation)axx);
               }
            };
            InlineMarker.mark(5);
            a.invoke(axx, axxx);
            return Unit.INSTANCE;
         }
      });
   }
}
