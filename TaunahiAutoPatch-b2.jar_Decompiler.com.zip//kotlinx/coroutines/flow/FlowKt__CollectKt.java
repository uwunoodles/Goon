package kotlinx.coroutines.flow;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.InlineMarker;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.flow.internal.NopCollector;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000F\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0019\u0010\u0000\u001a\u00020\u0001*\u0006\u0012\u0002\b\u00030\u0002H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0003\u001aV\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0004*\b\u0012\u0004\u0012\u0002H\u00040\u000223\b\u0004\u0010\u0005\u001a-\b\u0001\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\t\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\u0006H\u0087Hø\u0001\u0000¢\u0006\u0002\u0010\f\u001ak\u0010\r\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0004*\b\u0012\u0004\u0012\u0002H\u00040\u00022H\b\u0004\u0010\u0005\u001aB\b\u0001\u0012\u0013\u0012\u00110\u000f¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\u0010\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\t\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\u000eH\u0086Hø\u0001\u0000¢\u0006\u0002\u0010\u0011\u001aT\u0010\u0012\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0004*\b\u0012\u0004\u0012\u0002H\u00040\u000221\u0010\u0005\u001a-\b\u0001\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\u0007\u0012\b\b\b\u0012\u0004\b\b(\t\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\u0006H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\f\u001a/\u0010\u0013\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0004*\b\u0012\u0004\u0012\u0002H\u00040\u00142\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u0002H\u00040\u0002H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0016\u001a\u001e\u0010\u0017\u001a\u00020\u0018\"\u0004\b\u0000\u0010\u0004*\b\u0012\u0004\u0012\u0002H\u00040\u00022\u0006\u0010\u0019\u001a\u00020\u001a\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001b"},
   d2 = {"collect", "", "Lkotlinx/coroutines/flow/Flow;", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "T", "action", "Lkotlin/Function2;", "Lkotlin/ParameterName;", "name", "value", "Lkotlin/coroutines/Continuation;", "", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "collectIndexed", "Lkotlin/Function3;", "", "index", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function3;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "collectLatest", "emitAll", "Lkotlinx/coroutines/flow/FlowCollector;", "flow", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlinx/coroutines/flow/Flow;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "launchIn", "Lkotlinx/coroutines/Job;", "scope", "Lkotlinx/coroutines/CoroutineScope;", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/flow/FlowKt"
)
final class FlowKt__CollectKt {
   @Nullable
   public static final Object collect(@NotNull Flow<?> a, @NotNull Continuation<? super Unit> a) {
      Object var10000 = a.collect((FlowCollector)NopCollector.INSTANCE, a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   @NotNull
   public static final <T> Job launchIn(@NotNull final Flow<? extends T> a, @NotNull CoroutineScope a) {
      return BuildersKt.launch$default(a, (CoroutineContext)null, (CoroutineStart)null, (Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               Flow var10000 = a;
               Continuation var10001 = (Continuation)ax;
               ax.label = 1;
               if (FlowKt.collect(var10000, var10001) == var2) {
                  return var2;
               }
               break;
            case 1:
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            return Unit.INSTANCE;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object a1, @NotNull Continuation<?> axx) {
            return (Continuation)(new <anonymous constructor>(axx));
         }

         @Nullable
         public final Object invoke(@NotNull CoroutineScope axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }), 3, (Object)null);
   }

   @Nullable
   public static final <T> Object collectIndexed(@NotNull Flow<? extends T> a, @NotNull Function3<? super Integer, ? super T, ? super Continuation<? super Unit>, ? extends Object> a, @NotNull Continuation<? super Unit> a) {
      int a = false;
      Object var10000 = a.collect((FlowCollector)(new FlowCollector<T>() {
         private int index;

         @Nullable
         public Object emit(T axx, @NotNull Continuation<? super Unit> axxx) {
            Function3 var10000 = a;
            int var3 = ax.index++;
            int axxxx = false;
            if (var3 < 0) {
               throw new ArithmeticException("Index overflow has happened");
            } else {
               Object var5 = var10000.invoke(Boxing.boxInt(var3), axx, axxx);
               return var5 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var5 : Unit.INSTANCE;
            }
         }

         @Nullable
         public Object emit$$forInline(T axx, @NotNull Continuation<? super Unit> axxx) {
            InlineMarker.mark(4);
            ContinuationImpl var10001 = new ContinuationImpl(axxx) {
               // $FF: synthetic field
               Object result;
               int label;

               @Nullable
               public final Object invokeSuspend(@NotNull Object axxx) {
                  axx.result = axxx;
                  axx.label |= Integer.MIN_VALUE;
                  return ax.emit((Object)null, (Continuation)axx);
               }
            };
            InlineMarker.mark(5);
            Function3 var10000 = a;
            int var3 = ax.index++;
            int axxxx = false;
            if (var3 < 0) {
               throw new ArithmeticException("Index overflow has happened");
            } else {
               var10000.invoke(var3, axx, axxx);
               return Unit.INSTANCE;
            }
         }
      }), a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   private static final <T> Object collectIndexed$$forInline(Flow<? extends T> a, final Function3<? super Integer, ? super T, ? super Continuation<? super Unit>, ? extends Object> a, Continuation<? super Unit> a) {
      int a = false;
      FlowCollector var10001 = (FlowCollector)(new FlowCollector<T>() {
         private int index;

         @Nullable
         public Object emit(T axx, @NotNull Continuation<? super Unit> axxx) {
            Function3 var10000 = a;
            int var3 = ax.index++;
            int axxxx = false;
            if (var3 < 0) {
               throw new ArithmeticException("Index overflow has happened");
            } else {
               Object var5 = var10000.invoke(Boxing.boxInt(var3), axx, axxx);
               return var5 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var5 : Unit.INSTANCE;
            }
         }

         @Nullable
         public Object emit$$forInline(T axx, @NotNull Continuation<? super Unit> axxx) {
            InlineMarker.mark(4);
            ContinuationImpl var10001 = new ContinuationImpl(axxx) {
               // $FF: synthetic field
               Object result;
               int label;

               @Nullable
               public final Object invokeSuspend(@NotNull Object axxx) {
                  axx.result = axxx;
                  axx.label |= Integer.MIN_VALUE;
                  return ax.emit((Object)null, (Continuation)axx);
               }
            };
            InlineMarker.mark(5);
            Function3 var10000 = a;
            int var3 = ax.index++;
            int axxxx = false;
            if (var3 < 0) {
               throw new ArithmeticException("Index overflow has happened");
            } else {
               var10000.invoke(var3, axx, axxx);
               return Unit.INSTANCE;
            }
         }
      });
      InlineMarker.mark(0);
      a.collect(var10001, a);
      InlineMarker.mark(1);
      return Unit.INSTANCE;
   }

   @Nullable
   public static final <T> Object collectLatest(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Unit>, ? extends Object> a, @NotNull Continuation<? super Unit> a) {
      Object var10000 = FlowKt.collect(FlowKt.buffer$default(FlowKt.mapLatest(a, a), 0, (BufferOverflow)null, 2, (Object)null), a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   @Nullable
   public static final <T> Object emitAll(@NotNull FlowCollector<? super T> a, @NotNull Flow<? extends T> a, @NotNull Continuation<? super Unit> a) {
      FlowKt.ensureActive(a);
      Object var10000 = a.collect(a, a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Backwards compatibility with JS and K/N",
      level = DeprecationLevel.HIDDEN
   )
   public static final <T> Object collect(Flow<? extends T> a, Function2<? super T, ? super Continuation<? super Unit>, ? extends Object> a, Continuation<? super Unit> a) {
      int a = false;
      Object var10000 = a.collect((FlowCollector)(new FlowCollector<T>() {
         @Nullable
         public Object emit(T axx, @NotNull Continuation<? super Unit> axxx) {
            Object var10000 = a.invoke(axx, axxx);
            return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
         }

         @Nullable
         public Object emit$$forInline(T axx, @NotNull Continuation<? super Unit> axxx) {
            InlineMarker.mark(4);
            ContinuationImpl var10001 = new ContinuationImpl(axxx) {
               // $FF: synthetic field
               Object result;
               int label;

               @Nullable
               public final Object invokeSuspend(@NotNull Object axxx) {
                  axx.result = axxx;
                  axx.label |= Integer.MIN_VALUE;
                  return ax.emit((Object)null, (Continuation)axx);
               }
            };
            InlineMarker.mark(5);
            a.invoke(axx, axxx);
            return Unit.INSTANCE;
         }
      }), a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Backwards compatibility with JS and K/N",
      level = DeprecationLevel.HIDDEN
   )
   private static final <T> Object collect$$forInline(Flow<? extends T> a, final Function2<? super T, ? super Continuation<? super Unit>, ? extends Object> a, Continuation<? super Unit> a) {
      int a = false;
      FlowCollector var10001 = (FlowCollector)(new FlowCollector<T>() {
         @Nullable
         public Object emit(T axx, @NotNull Continuation<? super Unit> axxx) {
            Object var10000 = a.invoke(axx, axxx);
            return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
         }

         @Nullable
         public Object emit$$forInline(T axx, @NotNull Continuation<? super Unit> axxx) {
            InlineMarker.mark(4);
            ContinuationImpl var10001 = new ContinuationImpl(axxx) {
               // $FF: synthetic field
               Object result;
               int label;

               @Nullable
               public final Object invokeSuspend(@NotNull Object axxx) {
                  axx.result = axxx;
                  axx.label |= Integer.MIN_VALUE;
                  return ax.emit((Object)null, (Continuation)axx);
               }
            };
            InlineMarker.mark(5);
            a.invoke(axx, axxx);
            return Unit.INSTANCE;
         }
      });
      InlineMarker.mark(0);
      a.collect(var10001, a);
      InlineMarker.mark(1);
      return Unit.INSTANCE;
   }
}
