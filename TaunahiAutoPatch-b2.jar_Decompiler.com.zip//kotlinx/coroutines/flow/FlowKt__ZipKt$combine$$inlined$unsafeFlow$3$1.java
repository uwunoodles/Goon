package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 3,
   xi = 176
)
public final class FlowKt__ZipKt$combine$$inlined$unsafeFlow$3$1 extends ContinuationImpl {
   // $FF: synthetic field
   Object result;
   int label;
   // $FF: synthetic field
   final FlowKt__ZipKt$combine$$inlined$unsafeFlow$3 this$0;

   public FlowKt__ZipKt$combine$$inlined$unsafeFlow$3$1(FlowKt__ZipKt$combine$$inlined$unsafeFlow$3 a, Continuation a) {
      super(a);
      a.this$0 = a;
   }

   @Nullable
   public final Object invokeSuspend(@NotNull Object a) {
      a.result = a;
      a.label |= Integer.MIN_VALUE;
      return a.this$0.collect((FlowCollector)null, (Continuation)a);
   }
}
