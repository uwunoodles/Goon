package kotlinx.coroutines.flow;

import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Ref;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u001c\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u00042\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007H\u0016J\b\u0010\t\u001a\u00020\nH\u0016¨\u0006\u000b"},
   d2 = {"Lkotlinx/coroutines/flow/StartedLazily;", "Lkotlinx/coroutines/flow/SharingStarted;", "()V", "command", "Lkotlinx/coroutines/flow/Flow;", "Lkotlinx/coroutines/flow/SharingCommand;", "subscriptionCount", "Lkotlinx/coroutines/flow/StateFlow;", "", "toString", "", "kotlinx-coroutines-core"}
)
final class StartedLazily implements SharingStarted {
   public StartedLazily() {
   }

   @NotNull
   public Flow<SharingCommand> command(@NotNull final StateFlow<Integer> a) {
      return FlowKt.flow((Function2)(new Function2<FlowCollector<? super SharingCommand>, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               final FlowCollector axxx = (FlowCollector)ax.L$0;
               final Ref.BooleanRef axxxx = new Ref.BooleanRef();
               StateFlow var10000 = a;
               FlowCollector var10001 = (FlowCollector)(new FlowCollector() {
                  @Nullable
                  public final Object emit(int axx, @NotNull Continuation<? super Unit> var2) {
                     Object axxxxxx;
                     label28: {
                        if (var2 instanceof <undefinedtype>) {
                           axxxxxx = (<undefinedtype>)var2;
                           if ((((<undefinedtype>)axxxxxx).label & Integer.MIN_VALUE) != 0) {
                              ((<undefinedtype>)axxxxxx).label -= Integer.MIN_VALUE;
                              break label28;
                           }
                        }

                        axxxxxx = new ContinuationImpl(var2) {
                           // $FF: synthetic field
                           Object result;
                           int label;

                           @Nullable
                           public final Object invokeSuspend(@NotNull Object axxxxx) {
                              axx.result = axxxxx;
                              axx.label |= Integer.MIN_VALUE;
                              return ax.emit(0, (Continuation)axx);
                           }
                        };
                     }

                     Object axxxxx = ((<undefinedtype>)axxxxxx).result;
                     Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                     switch(((<undefinedtype>)axxxxxx).label) {
                     case 0:
                        ResultKt.throwOnFailure(axxxxx);
                        if (axx > 0 && !axxxx.element) {
                           axxxx.element = true;
                           FlowCollector var10000 = axxx;
                           SharingCommand var10001 = SharingCommand.START;
                           ((<undefinedtype>)axxxxxx).label = 1;
                           if (var10000.emit(var10001, (Continuation)axxxxxx) == var5) {
                              return var5;
                           }
                           break;
                        }

                        return Unit.INSTANCE;
                     case 1:
                        ResultKt.throwOnFailure(axxxxx);
                        break;
                     default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                     }

                     return Unit.INSTANCE;
                  }
               });
               Continuation var10002 = (Continuation)ax;
               ax.label = 1;
               if (var10000.collect(var10001, var10002) == var4) {
                  return var4;
               }
               break;
            case 1:
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            throw new KotlinNothingValueException();
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull FlowCollector<? super SharingCommand> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }));
   }

   @NotNull
   public String toString() {
      return "SharingStarted.Lazily";
   }
}
