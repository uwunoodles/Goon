package kotlinx.coroutines.flow;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import kotlin.BuilderInference;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.OverloadResolutionByLambdaReturnType;
import kotlin.PublishedApi;
import kotlin.ReplaceWith;
import kotlin.Unit;
import kotlin.collections.IndexedValue;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.JvmName;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.functions.Function6;
import kotlin.jvm.functions.Function7;
import kotlin.ranges.IntRange;
import kotlin.ranges.LongRange;
import kotlin.sequences.Sequence;
import kotlin.time.Duration;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.ExperimentalCoroutinesApi;
import kotlinx.coroutines.FlowPreview;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.channels.BroadcastChannel;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.channels.ProducerScope;
import kotlinx.coroutines.channels.ReceiveChannel;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 4,
   xi = 48,
   d1 = {"kotlinx/coroutines/flow/FlowKt__BuildersKt", "kotlinx/coroutines/flow/FlowKt__ChannelsKt", "kotlinx/coroutines/flow/FlowKt__CollectKt", "kotlinx/coroutines/flow/FlowKt__CollectionKt", "kotlinx/coroutines/flow/FlowKt__ContextKt", "kotlinx/coroutines/flow/FlowKt__CountKt", "kotlinx/coroutines/flow/FlowKt__DelayKt", "kotlinx/coroutines/flow/FlowKt__DistinctKt", "kotlinx/coroutines/flow/FlowKt__EmittersKt", "kotlinx/coroutines/flow/FlowKt__ErrorsKt", "kotlinx/coroutines/flow/FlowKt__LimitKt", "kotlinx/coroutines/flow/FlowKt__MergeKt", "kotlinx/coroutines/flow/FlowKt__MigrationKt", "kotlinx/coroutines/flow/FlowKt__ReduceKt", "kotlinx/coroutines/flow/FlowKt__ShareKt", "kotlinx/coroutines/flow/FlowKt__TransformKt", "kotlinx/coroutines/flow/FlowKt__ZipKt"}
)
public final class FlowKt {
   @NotNull
   public static final String DEFAULT_CONCURRENCY_PROPERTY_NAME = "kotlinx.coroutines.flow.defaultConcurrency";

   @NotNull
   public static final <T> Flow<T> flow(@BuilderInference @NotNull Function2<? super FlowCollector<? super T>, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__BuildersKt.flow(a);
   }

   @FlowPreview
   @NotNull
   public static final <T> Flow<T> asFlow(@NotNull Function0<? extends T> a) {
      return FlowKt__BuildersKt.asFlow(a);
   }

   @FlowPreview
   @NotNull
   public static final <T> Flow<T> asFlow(@NotNull Function1<? super Continuation<? super T>, ? extends Object> a) {
      return FlowKt__BuildersKt.asFlow(a);
   }

   @NotNull
   public static final <T> Flow<T> asFlow(@NotNull Iterable<? extends T> a) {
      return FlowKt__BuildersKt.asFlow(a);
   }

   @NotNull
   public static final <T> Flow<T> asFlow(@NotNull Iterator<? extends T> a) {
      return FlowKt__BuildersKt.asFlow(a);
   }

   @NotNull
   public static final <T> Flow<T> asFlow(@NotNull Sequence<? extends T> a) {
      return FlowKt__BuildersKt.asFlow(a);
   }

   @NotNull
   public static final <T> Flow<T> flowOf(@NotNull T... a) {
      return FlowKt__BuildersKt.flowOf(a);
   }

   @NotNull
   public static final <T> Flow<T> flowOf(T a) {
      return FlowKt__BuildersKt.flowOf(a);
   }

   @NotNull
   public static final <T> Flow<T> emptyFlow() {
      return FlowKt__BuildersKt.emptyFlow();
   }

   @NotNull
   public static final <T> Flow<T> asFlow(@NotNull T[] a) {
      return FlowKt__BuildersKt.asFlow(a);
   }

   @NotNull
   public static final Flow<Integer> asFlow(@NotNull int[] a) {
      return FlowKt__BuildersKt.asFlow(a);
   }

   @NotNull
   public static final Flow<Long> asFlow(@NotNull long[] a) {
      return FlowKt__BuildersKt.asFlow(a);
   }

   @NotNull
   public static final Flow<Integer> asFlow(@NotNull IntRange a) {
      return FlowKt__BuildersKt.asFlow(a);
   }

   @NotNull
   public static final Flow<Long> asFlow(@NotNull LongRange a) {
      return FlowKt__BuildersKt.asFlow(a);
   }

   @NotNull
   public static final <T> Flow<T> channelFlow(@BuilderInference @NotNull Function2<? super ProducerScope<? super T>, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__BuildersKt.channelFlow(a);
   }

   @NotNull
   public static final <T> Flow<T> callbackFlow(@BuilderInference @NotNull Function2<? super ProducerScope<? super T>, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__BuildersKt.callbackFlow(a);
   }

   @Nullable
   public static final <T> Object emitAll(@NotNull FlowCollector<? super T> a, @NotNull ReceiveChannel<? extends T> a, @NotNull Continuation<? super Unit> a) {
      return FlowKt__ChannelsKt.emitAll(a, a, a);
   }

   @NotNull
   public static final <T> Flow<T> receiveAsFlow(@NotNull ReceiveChannel<? extends T> a) {
      return FlowKt__ChannelsKt.receiveAsFlow(a);
   }

   @NotNull
   public static final <T> Flow<T> consumeAsFlow(@NotNull ReceiveChannel<? extends T> a) {
      return FlowKt__ChannelsKt.consumeAsFlow(a);
   }

   /** @deprecated */
   @Deprecated(
      message = "'BroadcastChannel' is obsolete and all corresponding operators are deprecated in the favour of StateFlow and SharedFlow",
      level = DeprecationLevel.WARNING
   )
   @NotNull
   public static final <T> Flow<T> asFlow(@NotNull BroadcastChannel<T> a) {
      return FlowKt__ChannelsKt.asFlow(a);
   }

   @FlowPreview
   @NotNull
   public static final <T> ReceiveChannel<T> produceIn(@NotNull Flow<? extends T> a, @NotNull CoroutineScope a) {
      return FlowKt__ChannelsKt.produceIn(a, a);
   }

   @Nullable
   public static final Object collect(@NotNull Flow<?> a, @NotNull Continuation<? super Unit> a) {
      return FlowKt__CollectKt.collect(a, a);
   }

   @NotNull
   public static final <T> Job launchIn(@NotNull Flow<? extends T> a, @NotNull CoroutineScope a) {
      return FlowKt__CollectKt.launchIn(a, a);
   }

   @Nullable
   public static final <T> Object collectIndexed(@NotNull Flow<? extends T> a, @NotNull Function3<? super Integer, ? super T, ? super Continuation<? super Unit>, ? extends Object> a, @NotNull Continuation<? super Unit> a) {
      return FlowKt__CollectKt.collectIndexed(a, a, a);
   }

   @Nullable
   public static final <T> Object collectLatest(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Unit>, ? extends Object> a, @NotNull Continuation<? super Unit> a) {
      return FlowKt__CollectKt.collectLatest(a, a, a);
   }

   @Nullable
   public static final <T> Object emitAll(@NotNull FlowCollector<? super T> a, @NotNull Flow<? extends T> a, @NotNull Continuation<? super Unit> a) {
      return FlowKt__CollectKt.emitAll(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Backwards compatibility with JS and K/N",
      level = DeprecationLevel.HIDDEN
   )
   public static final <T> Object collect(Flow<? extends T> a, Function2<? super T, ? super Continuation<? super Unit>, ? extends Object> a, Continuation<? super Unit> a) {
      return FlowKt__CollectKt.collect(a, a, a);
   }

   @Nullable
   public static final <T> Object toList(@NotNull Flow<? extends T> a, @NotNull List<T> a, @NotNull Continuation<? super List<? extends T>> a) {
      return FlowKt__CollectionKt.toList(a, a, a);
   }

   // $FF: synthetic method
   public static Object toList$default(Flow var0, List var1, Continuation var2, int var3, Object var4) {
      return FlowKt__CollectionKt.toList$default(var0, var1, var2, var3, var4);
   }

   @Nullable
   public static final <T> Object toSet(@NotNull Flow<? extends T> a, @NotNull Set<T> a, @NotNull Continuation<? super Set<? extends T>> a) {
      return FlowKt__CollectionKt.toSet(a, a, a);
   }

   // $FF: synthetic method
   public static Object toSet$default(Flow var0, Set var1, Continuation var2, int var3, Object var4) {
      return FlowKt__CollectionKt.toSet$default(var0, var1, var2, var3, var4);
   }

   @Nullable
   public static final <T, C extends Collection<? super T>> Object toCollection(@NotNull Flow<? extends T> a, @NotNull C a, @NotNull Continuation<? super C> a) {
      return FlowKt__CollectionKt.toCollection(a, a, a);
   }

   @NotNull
   public static final <T> Flow<T> buffer(@NotNull Flow<? extends T> a, int a, @NotNull BufferOverflow a) {
      return FlowKt__ContextKt.buffer(a, a, a);
   }

   // $FF: synthetic method
   public static Flow buffer$default(Flow var0, int var1, BufferOverflow var2, int var3, Object var4) {
      return FlowKt__ContextKt.buffer$default(var0, var1, var2, var3, var4);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.4.0, binary compatibility with earlier versions",
      level = DeprecationLevel.HIDDEN
   )
   public static final Flow buffer(Flow a, int a) {
      return FlowKt__ContextKt.buffer(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static Flow buffer$default(Flow var0, int var1, int var2, Object var3) {
      return FlowKt__ContextKt.buffer$default(var0, var1, var2, var3);
   }

   @NotNull
   public static final <T> Flow<T> conflate(@NotNull Flow<? extends T> a) {
      return FlowKt__ContextKt.conflate(a);
   }

   @NotNull
   public static final <T> Flow<T> flowOn(@NotNull Flow<? extends T> a, @NotNull CoroutineContext a) {
      return FlowKt__ContextKt.flowOn(a, a);
   }

   @NotNull
   public static final <T> Flow<T> cancellable(@NotNull Flow<? extends T> a) {
      return FlowKt__ContextKt.cancellable(a);
   }

   @Nullable
   public static final <T> Object count(@NotNull Flow<? extends T> a, @NotNull Continuation<? super Integer> a) {
      return FlowKt__CountKt.count(a, a);
   }

   @Nullable
   public static final <T> Object count(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> a, @NotNull Continuation<? super Integer> a) {
      return FlowKt__CountKt.count(a, a, a);
   }

   @FlowPreview
   @NotNull
   public static final <T> Flow<T> debounce(@NotNull Flow<? extends T> a, long a) {
      return FlowKt__DelayKt.debounce(a, a);
   }

   @FlowPreview
   @OverloadResolutionByLambdaReturnType
   @NotNull
   public static final <T> Flow<T> debounce(@NotNull Flow<? extends T> a, @NotNull Function1<? super T, Long> a) {
      return FlowKt__DelayKt.debounce(a, a);
   }

   @FlowPreview
   @NotNull
   public static final <T> Flow<T> debounce_HG0u8IE/* $FF was: debounce-HG0u8IE*/(@NotNull Flow<? extends T> a, long a) {
      return FlowKt__DelayKt.debounce-HG0u8IE(a, a);
   }

   @FlowPreview
   @JvmName(
      name = "debounceDuration"
   )
   @OverloadResolutionByLambdaReturnType
   @NotNull
   public static final <T> Flow<T> debounceDuration(@NotNull Flow<? extends T> a, @NotNull Function1<? super T, Duration> a) {
      return FlowKt__DelayKt.debounceDuration(a, a);
   }

   @FlowPreview
   @NotNull
   public static final <T> Flow<T> sample(@NotNull Flow<? extends T> a, long a) {
      return FlowKt__DelayKt.sample(a, a);
   }

   @NotNull
   public static final ReceiveChannel<Unit> fixedPeriodTicker(@NotNull CoroutineScope a, long a, long a) {
      return FlowKt__DelayKt.fixedPeriodTicker(a, a, a);
   }

   // $FF: synthetic method
   public static ReceiveChannel fixedPeriodTicker$default(CoroutineScope var0, long var1, long var3, int var5, Object var6) {
      return FlowKt__DelayKt.fixedPeriodTicker$default(var0, var1, var3, var5, var6);
   }

   @FlowPreview
   @NotNull
   public static final <T> Flow<T> sample_HG0u8IE/* $FF was: sample-HG0u8IE*/(@NotNull Flow<? extends T> a, long a) {
      return FlowKt__DelayKt.sample-HG0u8IE(a, a);
   }

   @NotNull
   public static final <T> Flow<T> distinctUntilChanged(@NotNull Flow<? extends T> a) {
      return FlowKt__DistinctKt.distinctUntilChanged(a);
   }

   @NotNull
   public static final <T> Flow<T> distinctUntilChanged(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super T, Boolean> a) {
      return FlowKt__DistinctKt.distinctUntilChanged(a, a);
   }

   @NotNull
   public static final <T, K> Flow<T> distinctUntilChangedBy(@NotNull Flow<? extends T> a, @NotNull Function1<? super T, ? extends K> a) {
      return FlowKt__DistinctKt.distinctUntilChangedBy(a, a);
   }

   @NotNull
   public static final <T, R> Flow<R> transform(@NotNull Flow<? extends T> a, @BuilderInference @NotNull Function3<? super FlowCollector<? super R>, ? super T, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__EmittersKt.transform(a, a);
   }

   @PublishedApi
   @NotNull
   public static final <T, R> Flow<R> unsafeTransform(@NotNull Flow<? extends T> a, @BuilderInference @NotNull Function3<? super FlowCollector<? super R>, ? super T, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__EmittersKt.unsafeTransform(a, a);
   }

   @NotNull
   public static final <T> Flow<T> onStart(@NotNull Flow<? extends T> a, @NotNull Function2<? super FlowCollector<? super T>, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__EmittersKt.onStart(a, a);
   }

   @NotNull
   public static final <T> Flow<T> onCompletion(@NotNull Flow<? extends T> a, @NotNull Function3<? super FlowCollector<? super T>, ? super Throwable, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__EmittersKt.onCompletion(a, a);
   }

   @NotNull
   public static final <T> Flow<T> onEmpty(@NotNull Flow<? extends T> a, @NotNull Function2<? super FlowCollector<? super T>, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__EmittersKt.onEmpty(a, a);
   }

   public static final void ensureActive(@NotNull FlowCollector<?> a) {
      FlowKt__EmittersKt.ensureActive(a);
   }

   @NotNull
   public static final <T> Flow<T> catch(@NotNull Flow<? extends T> a, @NotNull Function3<? super FlowCollector<? super T>, ? super Throwable, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__ErrorsKt.catch(a, a);
   }

   @NotNull
   public static final <T> Flow<T> retry(@NotNull Flow<? extends T> a, long a, @NotNull Function2<? super Throwable, ? super Continuation<? super Boolean>, ? extends Object> a) {
      return FlowKt__ErrorsKt.retry(a, a, a);
   }

   // $FF: synthetic method
   public static Flow retry$default(Flow var0, long var1, Function2 var3, int var4, Object var5) {
      return FlowKt__ErrorsKt.retry$default(var0, var1, var3, var4, var5);
   }

   @NotNull
   public static final <T> Flow<T> retryWhen(@NotNull Flow<? extends T> a, @NotNull Function4<? super FlowCollector<? super T>, ? super Throwable, ? super Long, ? super Continuation<? super Boolean>, ? extends Object> a) {
      return FlowKt__ErrorsKt.retryWhen(a, a);
   }

   @Nullable
   public static final <T> Object catchImpl(@NotNull Flow<? extends T> a, @NotNull FlowCollector<? super T> a, @NotNull Continuation<? super Throwable> a) {
      return FlowKt__ErrorsKt.catchImpl(a, a, a);
   }

   @NotNull
   public static final <T> Flow<T> drop(@NotNull Flow<? extends T> a, int a) {
      return FlowKt__LimitKt.drop(a, a);
   }

   @NotNull
   public static final <T> Flow<T> dropWhile(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> a) {
      return FlowKt__LimitKt.dropWhile(a, a);
   }

   @NotNull
   public static final <T> Flow<T> take(@NotNull Flow<? extends T> a, int a) {
      return FlowKt__LimitKt.take(a, a);
   }

   @NotNull
   public static final <T> Flow<T> takeWhile(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> a) {
      return FlowKt__LimitKt.takeWhile(a, a);
   }

   @NotNull
   public static final <T, R> Flow<R> transformWhile(@NotNull Flow<? extends T> a, @BuilderInference @NotNull Function3<? super FlowCollector<? super R>, ? super T, ? super Continuation<? super Boolean>, ? extends Object> a) {
      return FlowKt__LimitKt.transformWhile(a, a);
   }

   @Nullable
   public static final <T> Object collectWhile(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> a, @NotNull Continuation<? super Unit> a) {
      return FlowKt__LimitKt.collectWhile(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @FlowPreview
   public static void getDEFAULT_CONCURRENCY_PROPERTY_NAME$annotations() {
      FlowKt__MergeKt.getDEFAULT_CONCURRENCY_PROPERTY_NAME$annotations();
   }

   public static final int getDEFAULT_CONCURRENCY() {
      return FlowKt__MergeKt.getDEFAULT_CONCURRENCY();
   }

   @FlowPreview
   @NotNull
   public static final <T, R> Flow<R> flatMapConcat(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Flow<? extends R>>, ? extends Object> a) {
      return FlowKt__MergeKt.flatMapConcat(a, a);
   }

   @FlowPreview
   @NotNull
   public static final <T, R> Flow<R> flatMapMerge(@NotNull Flow<? extends T> a, int a, @NotNull Function2<? super T, ? super Continuation<? super Flow<? extends R>>, ? extends Object> a) {
      return FlowKt__MergeKt.flatMapMerge(a, a, a);
   }

   // $FF: synthetic method
   public static Flow flatMapMerge$default(Flow var0, int var1, Function2 var2, int var3, Object var4) {
      return FlowKt__MergeKt.flatMapMerge$default(var0, var1, var2, var3, var4);
   }

   @FlowPreview
   @NotNull
   public static final <T> Flow<T> flattenConcat(@NotNull Flow<? extends Flow<? extends T>> a) {
      return FlowKt__MergeKt.flattenConcat(a);
   }

   @NotNull
   public static final <T> Flow<T> merge(@NotNull Iterable<? extends Flow<? extends T>> a) {
      return FlowKt__MergeKt.merge(a);
   }

   @NotNull
   public static final <T> Flow<T> merge(@NotNull Flow<? extends T>... a) {
      return FlowKt__MergeKt.merge(a);
   }

   @FlowPreview
   @NotNull
   public static final <T> Flow<T> flattenMerge(@NotNull Flow<? extends Flow<? extends T>> a, int a) {
      return FlowKt__MergeKt.flattenMerge(a, a);
   }

   // $FF: synthetic method
   public static Flow flattenMerge$default(Flow var0, int var1, int var2, Object var3) {
      return FlowKt__MergeKt.flattenMerge$default(var0, var1, var2, var3);
   }

   @ExperimentalCoroutinesApi
   @NotNull
   public static final <T, R> Flow<R> transformLatest(@NotNull Flow<? extends T> a, @BuilderInference @NotNull Function3<? super FlowCollector<? super R>, ? super T, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__MergeKt.transformLatest(a, a);
   }

   @ExperimentalCoroutinesApi
   @NotNull
   public static final <T, R> Flow<R> flatMapLatest(@NotNull Flow<? extends T> a, @BuilderInference @NotNull Function2<? super T, ? super Continuation<? super Flow<? extends R>>, ? extends Object> a) {
      return FlowKt__MergeKt.flatMapLatest(a, a);
   }

   @ExperimentalCoroutinesApi
   @NotNull
   public static final <T, R> Flow<R> mapLatest(@NotNull Flow<? extends T> a, @BuilderInference @NotNull Function2<? super T, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__MergeKt.mapLatest(a, a);
   }

   @NotNull
   public static final Void noImpl() {
      return FlowKt__MigrationKt.noImpl();
   }

   /** @deprecated */
   @Deprecated(
      message = "Collect flow in the desired context instead",
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> observeOn(@NotNull Flow<? extends T> a, @NotNull CoroutineContext a) {
      return FlowKt__MigrationKt.observeOn(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Collect flow in the desired context instead",
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> publishOn(@NotNull Flow<? extends T> a, @NotNull CoroutineContext a) {
      return FlowKt__MigrationKt.publishOn(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Use 'flowOn' instead",
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> subscribeOn(@NotNull Flow<? extends T> a, @NotNull CoroutineContext a) {
      return FlowKt__MigrationKt.subscribeOn(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'onErrorXxx' is 'catch'. Use 'catch { emitAll(fallback) }'",
      replaceWith = @ReplaceWith(
   expression = "catch { emitAll(fallback) }",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> onErrorResume(@NotNull Flow<? extends T> a, @NotNull Flow<? extends T> a) {
      return FlowKt__MigrationKt.onErrorResume(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'onErrorXxx' is 'catch'. Use 'catch { emitAll(fallback) }'",
      replaceWith = @ReplaceWith(
   expression = "catch { emitAll(fallback) }",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> onErrorResumeNext(@NotNull Flow<? extends T> a, @NotNull Flow<? extends T> a) {
      return FlowKt__MigrationKt.onErrorResumeNext(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Use 'launchIn' with 'onEach', 'onCompletion' and 'catch' instead",
      level = DeprecationLevel.ERROR
   )
   public static final <T> void subscribe(@NotNull Flow<? extends T> a) {
      FlowKt__MigrationKt.subscribe(a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Use 'launchIn' with 'onEach', 'onCompletion' and 'catch' instead",
      level = DeprecationLevel.ERROR
   )
   public static final <T> void subscribe(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Unit>, ? extends Object> a) {
      FlowKt__MigrationKt.subscribe(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Use 'launchIn' with 'onEach', 'onCompletion' and 'catch' instead",
      level = DeprecationLevel.ERROR
   )
   public static final <T> void subscribe(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Unit>, ? extends Object> a, @NotNull Function2<? super Throwable, ? super Continuation<? super Unit>, ? extends Object> a) {
      FlowKt__MigrationKt.subscribe(a, a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue is 'flatMapConcat'",
      replaceWith = @ReplaceWith(
   expression = "flatMapConcat(mapper)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T, R> Flow<R> flatMap(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Flow<? extends R>>, ? extends Object> a) {
      return FlowKt__MigrationKt.flatMap(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'concatMap' is 'flatMapConcat'",
      replaceWith = @ReplaceWith(
   expression = "flatMapConcat(mapper)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T, R> Flow<R> concatMap(@NotNull Flow<? extends T> a, @NotNull Function1<? super T, ? extends Flow<? extends R>> a) {
      return FlowKt__MigrationKt.concatMap(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'merge' is 'flattenConcat'",
      replaceWith = @ReplaceWith(
   expression = "flattenConcat()",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> merge(@NotNull Flow<? extends Flow<? extends T>> a) {
      return FlowKt__MigrationKt.merge(a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'flatten' is 'flattenConcat'",
      replaceWith = @ReplaceWith(
   expression = "flattenConcat()",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> flatten(@NotNull Flow<? extends Flow<? extends T>> a) {
      return FlowKt__MigrationKt.flatten(a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'compose' is 'let'",
      replaceWith = @ReplaceWith(
   expression = "let(transformer)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T, R> Flow<R> compose(@NotNull Flow<? extends T> a, @NotNull Function1<? super Flow<? extends T>, ? extends Flow<? extends R>> a) {
      return FlowKt__MigrationKt.compose(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'skip' is 'drop'",
      replaceWith = @ReplaceWith(
   expression = "drop(count)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> skip(@NotNull Flow<? extends T> a, int a) {
      return FlowKt__MigrationKt.skip(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'forEach' is 'collect'",
      replaceWith = @ReplaceWith(
   expression = "collect(action)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   public static final <T> void forEach(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Unit>, ? extends Object> a) {
      FlowKt__MigrationKt.forEach(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow has less verbose 'scan' shortcut",
      replaceWith = @ReplaceWith(
   expression = "scan(initial, operation)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T, R> Flow<R> scanFold(@NotNull Flow<? extends T> a, R a, @BuilderInference @NotNull Function3<? super R, ? super T, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__MigrationKt.scanFold(a, a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'onErrorXxx' is 'catch'. Use 'catch { emit(fallback) }'",
      replaceWith = @ReplaceWith(
   expression = "catch { emit(fallback) }",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> onErrorReturn(@NotNull Flow<? extends T> a, T a) {
      return FlowKt__MigrationKt.onErrorReturn(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'onErrorXxx' is 'catch'. Use 'catch { e -> if (predicate(e)) emit(fallback) else throw e }'",
      replaceWith = @ReplaceWith(
   expression = "catch { e -> if (predicate(e)) emit(fallback) else throw e }",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> onErrorReturn(@NotNull Flow<? extends T> a, T a, @NotNull Function1<? super Throwable, Boolean> a) {
      return FlowKt__MigrationKt.onErrorReturn(a, a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static Flow onErrorReturn$default(Flow var0, Object var1, Function1 var2, int var3, Object var4) {
      return FlowKt__MigrationKt.onErrorReturn$default(var0, var1, var2, var3, var4);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'startWith' is 'onStart'. Use 'onStart { emit(value) }'",
      replaceWith = @ReplaceWith(
   expression = "onStart { emit(value) }",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> startWith(@NotNull Flow<? extends T> a, T a) {
      return FlowKt__MigrationKt.startWith(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'startWith' is 'onStart'. Use 'onStart { emitAll(other) }'",
      replaceWith = @ReplaceWith(
   expression = "onStart { emitAll(other) }",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> startWith(@NotNull Flow<? extends T> a, @NotNull Flow<? extends T> a) {
      return FlowKt__MigrationKt.startWith(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'concatWith' is 'onCompletion'. Use 'onCompletion { emit(value) }'",
      replaceWith = @ReplaceWith(
   expression = "onCompletion { emit(value) }",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> concatWith(@NotNull Flow<? extends T> a, T a) {
      return FlowKt__MigrationKt.concatWith(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'concatWith' is 'onCompletion'. Use 'onCompletion { if (it == null) emitAll(other) }'",
      replaceWith = @ReplaceWith(
   expression = "onCompletion { if (it == null) emitAll(other) }",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> concatWith(@NotNull Flow<? extends T> a, @NotNull Flow<? extends T> a) {
      return FlowKt__MigrationKt.concatWith(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'combineLatest' is 'combine'",
      replaceWith = @ReplaceWith(
   expression = "this.combine(other, transform)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T1, T2, R> Flow<R> combineLatest(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Function3<? super T1, ? super T2, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__MigrationKt.combineLatest(a, a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'combineLatest' is 'combine'",
      replaceWith = @ReplaceWith(
   expression = "combine(this, other, other2, transform)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T1, T2, T3, R> Flow<R> combineLatest(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @NotNull Function4<? super T1, ? super T2, ? super T3, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__MigrationKt.combineLatest(a, a, a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'combineLatest' is 'combine'",
      replaceWith = @ReplaceWith(
   expression = "combine(this, other, other2, other3, transform)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T1, T2, T3, T4, R> Flow<R> combineLatest(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @NotNull Flow<? extends T4> a, @NotNull Function5<? super T1, ? super T2, ? super T3, ? super T4, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__MigrationKt.combineLatest(a, a, a, a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'combineLatest' is 'combine'",
      replaceWith = @ReplaceWith(
   expression = "combine(this, other, other2, other3, transform)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T1, T2, T3, T4, T5, R> Flow<R> combineLatest(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @NotNull Flow<? extends T4> a, @NotNull Flow<? extends T5> a, @NotNull Function6<? super T1, ? super T2, ? super T3, ? super T4, ? super T5, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__MigrationKt.combineLatest(a, a, a, a, a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Use 'onStart { delay(timeMillis) }'",
      replaceWith = @ReplaceWith(
   expression = "onStart { delay(timeMillis) }",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> delayFlow(@NotNull Flow<? extends T> a, long a) {
      return FlowKt__MigrationKt.delayFlow(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Use 'onEach { delay(timeMillis) }'",
      replaceWith = @ReplaceWith(
   expression = "onEach { delay(timeMillis) }",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> delayEach(@NotNull Flow<? extends T> a, long a) {
      return FlowKt__MigrationKt.delayEach(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogues of 'switchMap' are 'transformLatest', 'flatMapLatest' and 'mapLatest'",
      replaceWith = @ReplaceWith(
   expression = "this.flatMapLatest(transform)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T, R> Flow<R> switchMap(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Flow<? extends R>>, ? extends Object> a) {
      return FlowKt__MigrationKt.switchMap(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "'scanReduce' was renamed to 'runningReduce' to be consistent with Kotlin standard library",
      replaceWith = @ReplaceWith(
   expression = "runningReduce(operation)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> scanReduce(@NotNull Flow<? extends T> a, @NotNull Function3<? super T, ? super T, ? super Continuation<? super T>, ? extends Object> a) {
      return FlowKt__MigrationKt.scanReduce(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'publish()' is 'shareIn'. \npublish().connect() is the default strategy (no extra call is needed), \npublish().autoConnect() translates to 'started = SharingStared.Lazily' argument, \npublish().refCount() translates to 'started = SharingStared.WhileSubscribed()' argument.",
      replaceWith = @ReplaceWith(
   expression = "this.shareIn(scope, 0)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> publish(@NotNull Flow<? extends T> a) {
      return FlowKt__MigrationKt.publish(a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'publish(bufferSize)' is 'buffer' followed by 'shareIn'. \npublish().connect() is the default strategy (no extra call is needed), \npublish().autoConnect() translates to 'started = SharingStared.Lazily' argument, \npublish().refCount() translates to 'started = SharingStared.WhileSubscribed()' argument.",
      replaceWith = @ReplaceWith(
   expression = "this.buffer(bufferSize).shareIn(scope, 0)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> publish(@NotNull Flow<? extends T> a, int a) {
      return FlowKt__MigrationKt.publish(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'replay()' is 'shareIn' with unlimited replay. \nreplay().connect() is the default strategy (no extra call is needed), \nreplay().autoConnect() translates to 'started = SharingStared.Lazily' argument, \nreplay().refCount() translates to 'started = SharingStared.WhileSubscribed()' argument.",
      replaceWith = @ReplaceWith(
   expression = "this.shareIn(scope, Int.MAX_VALUE)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> replay(@NotNull Flow<? extends T> a) {
      return FlowKt__MigrationKt.replay(a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'replay(bufferSize)' is 'shareIn' with the specified replay parameter. \nreplay().connect() is the default strategy (no extra call is needed), \nreplay().autoConnect() translates to 'started = SharingStared.Lazily' argument, \nreplay().refCount() translates to 'started = SharingStared.WhileSubscribed()' argument.",
      replaceWith = @ReplaceWith(
   expression = "this.shareIn(scope, bufferSize)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> replay(@NotNull Flow<? extends T> a, int a) {
      return FlowKt__MigrationKt.replay(a, a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Flow analogue of 'cache()' is 'shareIn' with unlimited replay and 'started = SharingStared.Lazily' argument'",
      replaceWith = @ReplaceWith(
   expression = "this.shareIn(scope, Int.MAX_VALUE, started = SharingStared.Lazily)",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public static final <T> Flow<T> cache(@NotNull Flow<? extends T> a) {
      return FlowKt__MigrationKt.cache(a);
   }

   @Nullable
   public static final <S, T extends S> Object reduce(@NotNull Flow<? extends T> a, @NotNull Function3<? super S, ? super T, ? super Continuation<? super S>, ? extends Object> a, @NotNull Continuation<? super S> a) {
      return FlowKt__ReduceKt.reduce(a, a, a);
   }

   @Nullable
   public static final <T, R> Object fold(@NotNull Flow<? extends T> a, R a, @NotNull Function3<? super R, ? super T, ? super Continuation<? super R>, ? extends Object> a, @NotNull Continuation<? super R> a) {
      return FlowKt__ReduceKt.fold(a, a, a, a);
   }

   @Nullable
   public static final <T> Object single(@NotNull Flow<? extends T> a, @NotNull Continuation<? super T> a) {
      return FlowKt__ReduceKt.single(a, a);
   }

   @Nullable
   public static final <T> Object singleOrNull(@NotNull Flow<? extends T> a, @NotNull Continuation<? super T> a) {
      return FlowKt__ReduceKt.singleOrNull(a, a);
   }

   @Nullable
   public static final <T> Object first(@NotNull Flow<? extends T> a, @NotNull Continuation<? super T> a) {
      return FlowKt__ReduceKt.first(a, a);
   }

   @Nullable
   public static final <T> Object first(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> a, @NotNull Continuation<? super T> a) {
      return FlowKt__ReduceKt.first(a, a, a);
   }

   @Nullable
   public static final <T> Object firstOrNull(@NotNull Flow<? extends T> a, @NotNull Continuation<? super T> a) {
      return FlowKt__ReduceKt.firstOrNull(a, a);
   }

   @Nullable
   public static final <T> Object firstOrNull(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> a, @NotNull Continuation<? super T> a) {
      return FlowKt__ReduceKt.firstOrNull(a, a, a);
   }

   @Nullable
   public static final <T> Object last(@NotNull Flow<? extends T> a, @NotNull Continuation<? super T> a) {
      return FlowKt__ReduceKt.last(a, a);
   }

   @Nullable
   public static final <T> Object lastOrNull(@NotNull Flow<? extends T> a, @NotNull Continuation<? super T> a) {
      return FlowKt__ReduceKt.lastOrNull(a, a);
   }

   @NotNull
   public static final <T> SharedFlow<T> shareIn(@NotNull Flow<? extends T> a, @NotNull CoroutineScope a, @NotNull SharingStarted a, int a) {
      return FlowKt__ShareKt.shareIn(a, a, a, a);
   }

   // $FF: synthetic method
   public static SharedFlow shareIn$default(Flow var0, CoroutineScope var1, SharingStarted var2, int var3, int var4, Object var5) {
      return FlowKt__ShareKt.shareIn$default(var0, var1, var2, var3, var4, var5);
   }

   @NotNull
   public static final <T> StateFlow<T> stateIn(@NotNull Flow<? extends T> a, @NotNull CoroutineScope a, @NotNull SharingStarted a, T a) {
      return FlowKt__ShareKt.stateIn(a, a, a, a);
   }

   @Nullable
   public static final <T> Object stateIn(@NotNull Flow<? extends T> a, @NotNull CoroutineScope a, @NotNull Continuation<? super StateFlow<? extends T>> a) {
      return FlowKt__ShareKt.stateIn(a, a, a);
   }

   @NotNull
   public static final <T> SharedFlow<T> asSharedFlow(@NotNull MutableSharedFlow<T> a) {
      return FlowKt__ShareKt.asSharedFlow(a);
   }

   @NotNull
   public static final <T> StateFlow<T> asStateFlow(@NotNull MutableStateFlow<T> a) {
      return FlowKt__ShareKt.asStateFlow(a);
   }

   @NotNull
   public static final <T> SharedFlow<T> onSubscription(@NotNull SharedFlow<? extends T> a, @NotNull Function2<? super FlowCollector<? super T>, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__ShareKt.onSubscription(a, a);
   }

   @NotNull
   public static final <T> Flow<T> filter(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> a) {
      return FlowKt__TransformKt.filter(a, a);
   }

   @NotNull
   public static final <T> Flow<T> filterNot(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> a) {
      return FlowKt__TransformKt.filterNot(a, a);
   }

   // $FF: synthetic method
   public static final <R> Flow<R> filterIsInstance(Flow<?> a) {
      return FlowKt__TransformKt.filterIsInstance(a);
   }

   @NotNull
   public static final <T> Flow<T> filterNotNull(@NotNull Flow<? extends T> a) {
      return FlowKt__TransformKt.filterNotNull(a);
   }

   @NotNull
   public static final <T, R> Flow<R> map(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__TransformKt.map(a, a);
   }

   @NotNull
   public static final <T, R> Flow<R> mapNotNull(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__TransformKt.mapNotNull(a, a);
   }

   @NotNull
   public static final <T> Flow<IndexedValue<T>> withIndex(@NotNull Flow<? extends T> a) {
      return FlowKt__TransformKt.withIndex(a);
   }

   @NotNull
   public static final <T> Flow<T> onEach(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__TransformKt.onEach(a, a);
   }

   @NotNull
   public static final <T, R> Flow<R> scan(@NotNull Flow<? extends T> a, R a, @BuilderInference @NotNull Function3<? super R, ? super T, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__TransformKt.scan(a, a, a);
   }

   @NotNull
   public static final <T, R> Flow<R> runningFold(@NotNull Flow<? extends T> a, R a, @BuilderInference @NotNull Function3<? super R, ? super T, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__TransformKt.runningFold(a, a, a);
   }

   @NotNull
   public static final <T> Flow<T> runningReduce(@NotNull Flow<? extends T> a, @NotNull Function3<? super T, ? super T, ? super Continuation<? super T>, ? extends Object> a) {
      return FlowKt__TransformKt.runningReduce(a, a);
   }

   @JvmName(
      name = "flowCombine"
   )
   @NotNull
   public static final <T1, T2, R> Flow<R> flowCombine(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Function3<? super T1, ? super T2, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__ZipKt.flowCombine(a, a, a);
   }

   @NotNull
   public static final <T1, T2, R> Flow<R> combine(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Function3<? super T1, ? super T2, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__ZipKt.combine(a, a, a);
   }

   @JvmName(
      name = "flowCombineTransform"
   )
   @NotNull
   public static final <T1, T2, R> Flow<R> flowCombineTransform(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @BuilderInference @NotNull Function4<? super FlowCollector<? super R>, ? super T1, ? super T2, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__ZipKt.flowCombineTransform(a, a, a);
   }

   @NotNull
   public static final <T1, T2, R> Flow<R> combineTransform(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @BuilderInference @NotNull Function4<? super FlowCollector<? super R>, ? super T1, ? super T2, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__ZipKt.combineTransform(a, a, a);
   }

   @NotNull
   public static final <T1, T2, T3, R> Flow<R> combine(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @BuilderInference @NotNull Function4<? super T1, ? super T2, ? super T3, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__ZipKt.combine(a, a, a, a);
   }

   @NotNull
   public static final <T1, T2, T3, R> Flow<R> combineTransform(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @BuilderInference @NotNull Function5<? super FlowCollector<? super R>, ? super T1, ? super T2, ? super T3, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__ZipKt.combineTransform(a, a, a, a);
   }

   @NotNull
   public static final <T1, T2, T3, T4, R> Flow<R> combine(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @NotNull Flow<? extends T4> a, @NotNull Function5<? super T1, ? super T2, ? super T3, ? super T4, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__ZipKt.combine(a, a, a, a, a);
   }

   @NotNull
   public static final <T1, T2, T3, T4, R> Flow<R> combineTransform(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @NotNull Flow<? extends T4> a, @BuilderInference @NotNull Function6<? super FlowCollector<? super R>, ? super T1, ? super T2, ? super T3, ? super T4, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__ZipKt.combineTransform(a, a, a, a, a);
   }

   @NotNull
   public static final <T1, T2, T3, T4, T5, R> Flow<R> combine(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @NotNull Flow<? extends T4> a, @NotNull Flow<? extends T5> a, @NotNull Function6<? super T1, ? super T2, ? super T3, ? super T4, ? super T5, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__ZipKt.combine(a, a, a, a, a, a);
   }

   @NotNull
   public static final <T1, T2, T3, T4, T5, R> Flow<R> combineTransform(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Flow<? extends T3> a, @NotNull Flow<? extends T4> a, @NotNull Flow<? extends T5> a, @BuilderInference @NotNull Function7<? super FlowCollector<? super R>, ? super T1, ? super T2, ? super T3, ? super T4, ? super T5, ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__ZipKt.combineTransform(a, a, a, a, a, a);
   }

   // $FF: synthetic method
   public static final <T, R> Flow<R> combine(Flow<? extends T>[] a, Function2<? super T[], ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__ZipKt.combine(a, a);
   }

   // $FF: synthetic method
   public static final <T, R> Flow<R> combineTransform(Flow<? extends T>[] a, @BuilderInference Function3<? super FlowCollector<? super R>, ? super T[], ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__ZipKt.combineTransform(a, a);
   }

   // $FF: synthetic method
   public static final <T, R> Flow<R> combine(Iterable<? extends Flow<? extends T>> a, Function2<? super T[], ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__ZipKt.combine(a, a);
   }

   // $FF: synthetic method
   public static final <T, R> Flow<R> combineTransform(Iterable<? extends Flow<? extends T>> a, @BuilderInference Function3<? super FlowCollector<? super R>, ? super T[], ? super Continuation<? super Unit>, ? extends Object> a) {
      return FlowKt__ZipKt.combineTransform(a, a);
   }

   @NotNull
   public static final <T1, T2, R> Flow<R> zip(@NotNull Flow<? extends T1> a, @NotNull Flow<? extends T2> a, @NotNull Function3<? super T1, ? super T2, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt__ZipKt.zip(a, a, a);
   }
}
