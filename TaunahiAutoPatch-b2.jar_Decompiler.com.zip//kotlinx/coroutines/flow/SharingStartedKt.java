package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.time.Duration;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a+\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u0005\u001a\u00020\u0004ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\u0006\u0010\u0007\u0082\u0002\u000b\n\u0002\b\u0019\n\u0005\b¡\u001e0\u0001¨\u0006\b"},
   d2 = {"WhileSubscribed", "Lkotlinx/coroutines/flow/SharingStarted;", "Lkotlinx/coroutines/flow/SharingStarted$Companion;", "stopTimeout", "Lkotlin/time/Duration;", "replayExpiration", "WhileSubscribed-5qebJ5I", "(Lkotlinx/coroutines/flow/SharingStarted$Companion;JJ)Lkotlinx/coroutines/flow/SharingStarted;", "kotlinx-coroutines-core"}
)
public final class SharingStartedKt {
   @NotNull
   public static final SharingStarted WhileSubscribed_5qebJ5I/* $FF was: WhileSubscribed-5qebJ5I*/(@NotNull SharingStarted.Companion a, long a, long a) {
      return (SharingStarted)(new StartedWhileSubscribed(Duration.getInWholeMilliseconds-impl(a), Duration.getInWholeMilliseconds-impl(a)));
   }

   // $FF: synthetic method
   public static SharingStarted WhileSubscribed_5qebJ5I$default/* $FF was: WhileSubscribed-5qebJ5I$default*/(SharingStarted.Companion var0, long var1, long var3, int var5, Object var6) {
      if ((var5 & 1) != 0) {
         var1 = Duration.Companion.getZERO-UwyO8pc();
      }

      if ((var5 & 2) != 0) {
         var3 = Duration.Companion.getINFINITE-UwyO8pc();
      }

      return WhileSubscribed-5qebJ5I(var0, var1, var3);
   }
}
