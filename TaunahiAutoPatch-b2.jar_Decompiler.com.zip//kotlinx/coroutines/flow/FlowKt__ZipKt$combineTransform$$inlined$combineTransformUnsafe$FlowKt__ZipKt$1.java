package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlinx.coroutines.flow.internal.CombineKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@DebugMetadata(
   f = "Zip.kt",
   l = {273},
   i = {},
   s = {},
   n = {},
   m = "invokeSuspend",
   c = "kotlinx.coroutines.flow.FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$1"
)
@Metadata(
   mv = {1, 6, 0},
   k = 3,
   xi = 48,
   d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001\"\u0006\b\u0000\u0010\u0002\u0018\u0001\"\u0004\b\u0001\u0010\u0003*\b\u0012\u0004\u0012\u0002H\u00030\u0004H\u008a@¨\u0006\u0005"},
   d2 = {"<anonymous>", "", "T", "R", "Lkotlinx/coroutines/flow/FlowCollector;", "kotlinx/coroutines/flow/FlowKt__ZipKt$combineTransformUnsafe$1"}
)
public final class FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$1 extends SuspendLambda implements Function2<FlowCollector<? super R>, Continuation<? super Unit>, Object> {
   int label;
   // $FF: synthetic field
   private Object L$0;
   // $FF: synthetic field
   final Flow[] $flows;
   // $FF: synthetic field
   final Function4 $transform$inlined;

   public FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$1(Flow[] a, Continuation a, Function4 var3) {
      super(2, a);
      a.$flows = a;
      a.$transform$inlined = var3;
   }

   @Nullable
   public final Object invokeSuspend(@NotNull Object a) {
      Object var2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      switch(a.label) {
      case 0:
         ResultKt.throwOnFailure(a);
         FlowCollector a = (FlowCollector)a.L$0;
         Flow[] var10001 = a.$flows;
         Function0 var10002 = FlowKt__ZipKt.access$nullArrayFactory();
         Function3 var10003 = (Function3)(new FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$1$1((Continuation)null, a.$transform$inlined));
         Continuation var10004 = (Continuation)a;
         a.label = 1;
         if (CombineKt.combineInternal(a, var10001, var10002, var10003, var10004) == var2) {
            return var2;
         }
         break;
      case 1:
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      return Unit.INSTANCE;
   }

   @NotNull
   public final Continuation<Unit> create(@Nullable Object a, @NotNull Continuation<?> a) {
      FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$1 var3 = new FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$1(a.$flows, a, a.$transform$inlined);
      var3.L$0 = a;
      return (Continuation)var3;
   }

   @Nullable
   public final Object invoke(@NotNull FlowCollector<? super R> a, @Nullable Continuation<? super Unit> a) {
      return ((FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$1)a.create(a, a)).invokeSuspend(Unit.INSTANCE);
   }
}
