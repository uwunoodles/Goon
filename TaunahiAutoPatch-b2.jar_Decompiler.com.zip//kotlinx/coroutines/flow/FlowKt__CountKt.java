package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Ref;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000$\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\b\u0002\u001a!\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u0003H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0004\u001aE\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00032\"\u0010\u0005\u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0006H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\n\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u000b"},
   d2 = {"count", "", "T", "Lkotlinx/coroutines/flow/Flow;", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "predicate", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/flow/FlowKt"
)
final class FlowKt__CountKt {
   @Nullable
   public static final <T> Object count(@NotNull Flow<? extends T> a, @NotNull Continuation<? super Integer> var1) {
      Object a;
      label20: {
         if (var1 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var1;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label20;
            }
         }

         a = new ContinuationImpl(var1) {
            Object L$0;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return FlowKt.count((Flow)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      final Ref.IntRef a;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         a = new Ref.IntRef();
         FlowCollector var10001 = (FlowCollector)(new FlowCollector() {
            @Nullable
            public final Object emit(T a1, @NotNull Continuation<? super Unit> a2) {
               ++a.element;
               int var10000 = a.element;
               return Unit.INSTANCE;
            }
         });
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).label = 1;
         if (a.collect(var10001, (Continuation)a) == var5) {
            return var5;
         }
         break;
      case 1:
         a = (Ref.IntRef)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      return Boxing.boxInt(a.element);
   }

   @Nullable
   public static final <T> Object count(@NotNull Flow<? extends T> a, @NotNull final Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> a, @NotNull Continuation<? super Integer> var2) {
      Object a;
      label20: {
         if (var2 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var2;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label20;
            }
         }

         a = new ContinuationImpl(var2) {
            Object L$0;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return FlowKt.count((Flow)null, (Function2)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var6 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      final Ref.IntRef a;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         a = new Ref.IntRef();
         FlowCollector var10001 = (FlowCollector)(new FlowCollector() {
            @Nullable
            public final Object emit(T axx, @NotNull Continuation<? super Unit> var2) {
               Object axxxx;
               label24: {
                  if (var2 instanceof <undefinedtype>) {
                     axxxx = (<undefinedtype>)var2;
                     if ((((<undefinedtype>)axxxx).label & Integer.MIN_VALUE) != 0) {
                        ((<undefinedtype>)axxxx).label -= Integer.MIN_VALUE;
                        break label24;
                     }
                  }

                  axxxx = new ContinuationImpl(var2) {
                     Object L$0;
                     // $FF: synthetic field
                     Object result;
                     int label;

                     @Nullable
                     public final Object invokeSuspend(@NotNull Object axxx) {
                        axx.result = axxx;
                        axx.label |= Integer.MIN_VALUE;
                        return ax.emit((Object)null, (Continuation)axx);
                     }
                  };
               }

               Object axxx = ((<undefinedtype>)axxxx).result;
               Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
               Object var10000;
               switch(((<undefinedtype>)axxxx).label) {
               case 0:
                  ResultKt.throwOnFailure(axxx);
                  Function2 var6 = a;
                  ((<undefinedtype>)axxxx).L$0 = ax;
                  ((<undefinedtype>)axxxx).label = 1;
                  var10000 = var6.invoke(axx, axxxx);
                  if (var10000 == var5) {
                     return var5;
                  }
                  break;
               case 1:
                  ax = (<undefinedtype>)((<undefinedtype>)axxxx).L$0;
                  ResultKt.throwOnFailure(axxx);
                  var10000 = axxx;
                  break;
               default:
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
               }

               if ((Boolean)var10000) {
                  ++a.element;
                  int var7 = a.element;
               }

               return Unit.INSTANCE;
            }
         });
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).label = 1;
         if (a.collect(var10001, (Continuation)a) == var6) {
            return var6;
         }
         break;
      case 1:
         a = (Ref.IntRef)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      return Boxing.boxInt(a.element);
   }
}
