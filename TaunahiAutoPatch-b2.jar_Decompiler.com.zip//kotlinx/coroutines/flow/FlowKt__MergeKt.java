package kotlinx.coroutines.flow;

import kotlin.BuilderInference;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.InlineMarker;
import kotlinx.coroutines.ExperimentalCoroutinesApi;
import kotlinx.coroutines.FlowPreview;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.flow.internal.ChannelFlowMerge;
import kotlinx.coroutines.flow.internal.ChannelFlowTransformLatest;
import kotlinx.coroutines.flow.internal.ChannelLimitedFlowMerge;
import kotlinx.coroutines.internal.SystemPropsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000T\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\b\n\u0002\u0010\u001c\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a7\u0010\t\u001a\b\u0012\u0004\u0012\u0002H\u000b0\n\"\u0004\b\u0000\u0010\u000b2\u001e\u0010\f\u001a\u0010\u0012\f\b\u0001\u0012\b\u0012\u0004\u0012\u0002H\u000b0\n0\r\"\b\u0012\u0004\u0012\u0002H\u000b0\n¢\u0006\u0002\u0010\u000e\u001ae\u0010\u000f\u001a\b\u0012\u0004\u0012\u0002H\u00100\n\"\u0004\b\u0000\u0010\u000b\"\u0004\b\u0001\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u000b0\n27\u0010\u0011\u001a3\b\u0001\u0012\u0013\u0012\u0011H\u000b¢\u0006\f\b\u0013\u0012\b\b\u0014\u0012\u0004\b\b(\u0015\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00100\n0\u0016\u0012\u0006\u0012\u0004\u0018\u00010\u00170\u0012H\u0007ø\u0001\u0000¢\u0006\u0002\u0010\u0018\u001ah\u0010\u0019\u001a\b\u0012\u0004\u0012\u0002H\u00100\n\"\u0004\b\u0000\u0010\u000b\"\u0004\b\u0001\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u000b0\n29\b\u0005\u0010\u0011\u001a3\b\u0001\u0012\u0013\u0012\u0011H\u000b¢\u0006\f\b\u0013\u0012\b\b\u0014\u0012\u0004\b\b(\u0015\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00100\n0\u0016\u0012\u0006\u0012\u0004\u0018\u00010\u00170\u0012H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u0018\u001ao\u0010\u001a\u001a\b\u0012\u0004\u0012\u0002H\u00100\n\"\u0004\b\u0000\u0010\u000b\"\u0004\b\u0001\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u000b0\n2\b\b\u0002\u0010\u001b\u001a\u00020\u000127\u0010\u0011\u001a3\b\u0001\u0012\u0013\u0012\u0011H\u000b¢\u0006\f\b\u0013\u0012\b\b\u0014\u0012\u0004\b\b(\u0015\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00100\n0\u0016\u0012\u0006\u0012\u0004\u0018\u00010\u00170\u0012H\u0007ø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001a$\u0010\u001d\u001a\b\u0012\u0004\u0012\u0002H\u000b0\n\"\u0004\b\u0000\u0010\u000b*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u000b0\n0\nH\u0007\u001a.\u0010\u001e\u001a\b\u0012\u0004\u0012\u0002H\u000b0\n\"\u0004\b\u0000\u0010\u000b*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u000b0\n0\n2\b\b\u0002\u0010\u001b\u001a\u00020\u0001H\u0007\u001aa\u0010\u001f\u001a\b\u0012\u0004\u0012\u0002H\u00100\n\"\u0004\b\u0000\u0010\u000b\"\u0004\b\u0001\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u000b0\n23\b\u0001\u0010\u0011\u001a-\b\u0001\u0012\u0013\u0012\u0011H\u000b¢\u0006\f\b\u0013\u0012\b\b\u0014\u0012\u0004\b\b(\u0015\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00100\u0016\u0012\u0006\u0012\u0004\u0018\u00010\u00170\u0012H\u0007ø\u0001\u0000¢\u0006\u0002\u0010\u0018\u001a\"\u0010\t\u001a\b\u0012\u0004\u0012\u0002H\u000b0\n\"\u0004\b\u0000\u0010\u000b*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u000b0\n0 \u001ar\u0010!\u001a\b\u0012\u0004\u0012\u0002H\u00100\n\"\u0004\b\u0000\u0010\u000b\"\u0004\b\u0001\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u000b0\n2D\b\u0001\u0010\u0011\u001a>\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00100#\u0012\u0013\u0012\u0011H\u000b¢\u0006\f\b\u0013\u0012\b\b\u0014\u0012\u0004\b\b(\u0015\u0012\n\u0012\b\u0012\u0004\u0012\u00020$0\u0016\u0012\u0006\u0012\u0004\u0018\u00010\u00170\"¢\u0006\u0002\b%H\u0007ø\u0001\u0000¢\u0006\u0002\u0010&\"\u001c\u0010\u0000\u001a\u00020\u00018\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u0002\u0010\u0003\u001a\u0004\b\u0004\u0010\u0005\"\u0016\u0010\u0006\u001a\u00020\u00078\u0006X\u0087T¢\u0006\b\n\u0000\u0012\u0004\b\b\u0010\u0003\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006'"},
   d2 = {"DEFAULT_CONCURRENCY", "", "getDEFAULT_CONCURRENCY$annotations", "()V", "getDEFAULT_CONCURRENCY", "()I", "DEFAULT_CONCURRENCY_PROPERTY_NAME", "", "getDEFAULT_CONCURRENCY_PROPERTY_NAME$annotations", "merge", "Lkotlinx/coroutines/flow/Flow;", "T", "flows", "", "([Lkotlinx/coroutines/flow/Flow;)Lkotlinx/coroutines/flow/Flow;", "flatMapConcat", "R", "transform", "Lkotlin/Function2;", "Lkotlin/ParameterName;", "name", "value", "Lkotlin/coroutines/Continuation;", "", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/flow/Flow;", "flatMapLatest", "flatMapMerge", "concurrency", "(Lkotlinx/coroutines/flow/Flow;ILkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/flow/Flow;", "flattenConcat", "flattenMerge", "mapLatest", "", "transformLatest", "Lkotlin/Function3;", "Lkotlinx/coroutines/flow/FlowCollector;", "", "Lkotlin/ExtensionFunctionType;", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function3;)Lkotlinx/coroutines/flow/Flow;", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/flow/FlowKt"
)
final class FlowKt__MergeKt {
   private static final int DEFAULT_CONCURRENCY = SystemPropsKt.systemProp("kotlinx.coroutines.flow.defaultConcurrency", 16, 1, Integer.MAX_VALUE);

   /** @deprecated */
   // $FF: synthetic method
   @FlowPreview
   public static void getDEFAULT_CONCURRENCY_PROPERTY_NAME$annotations() {
   }

   public static final int getDEFAULT_CONCURRENCY() {
      return DEFAULT_CONCURRENCY;
   }

   /** @deprecated */
   // $FF: synthetic method
   @FlowPreview
   public static void getDEFAULT_CONCURRENCY$annotations() {
   }

   @FlowPreview
   @NotNull
   public static final <T, R> Flow<R> flatMapConcat(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Flow<? extends R>>, ? extends Object> a) {
      int a = false;
      int a = false;
      int a = false;
      return FlowKt.flattenConcat((Flow)(new FlowKt__MergeKt$flatMapConcat$$inlined$map$1(a, a)));
   }

   @FlowPreview
   @NotNull
   public static final <T, R> Flow<R> flatMapMerge(@NotNull Flow<? extends T> a, int a, @NotNull Function2<? super T, ? super Continuation<? super Flow<? extends R>>, ? extends Object> a) {
      int a = false;
      int a = false;
      int a = false;
      return FlowKt.flattenMerge((Flow)(new FlowKt__MergeKt$flatMapMerge$$inlined$map$1(a, a)), a);
   }

   // $FF: synthetic method
   public static Flow flatMapMerge$default(Flow var0, int var1, Function2 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = DEFAULT_CONCURRENCY;
      }

      return FlowKt.flatMapMerge(var0, var1, var2);
   }

   @FlowPreview
   @NotNull
   public static final <T> Flow<T> flattenConcat(@NotNull Flow<? extends Flow<? extends T>> a) {
      int a = false;
      return (Flow)(new FlowKt__MergeKt$flattenConcat$$inlined$unsafeFlow$1(a));
   }

   @NotNull
   public static final <T> Flow<T> merge(@NotNull Iterable<? extends Flow<? extends T>> a) {
      return (Flow)(new ChannelLimitedFlowMerge(a, (CoroutineContext)null, 0, (BufferOverflow)null, 14, (DefaultConstructorMarker)null));
   }

   @NotNull
   public static final <T> Flow<T> merge(@NotNull Flow<? extends T>... a) {
      return FlowKt.merge(ArraysKt.asIterable(a));
   }

   @FlowPreview
   @NotNull
   public static final <T> Flow<T> flattenMerge(@NotNull Flow<? extends Flow<? extends T>> a, int a) {
      if (a <= 0) {
         int a = false;
         String var3 = "Expected positive concurrency level, but had " + a;
         throw new IllegalArgumentException(var3.toString());
      } else {
         return a == 1 ? FlowKt.flattenConcat(a) : (Flow)(new ChannelFlowMerge(a, a, (CoroutineContext)null, 0, (BufferOverflow)null, 28, (DefaultConstructorMarker)null));
      }
   }

   // $FF: synthetic method
   public static Flow flattenMerge$default(Flow var0, int var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = DEFAULT_CONCURRENCY;
      }

      return FlowKt.flattenMerge(var0, var1);
   }

   @ExperimentalCoroutinesApi
   @NotNull
   public static final <T, R> Flow<R> transformLatest(@NotNull Flow<? extends T> a, @BuilderInference @NotNull Function3<? super FlowCollector<? super R>, ? super T, ? super Continuation<? super Unit>, ? extends Object> a) {
      return (Flow)(new ChannelFlowTransformLatest(a, a, (CoroutineContext)null, 0, (BufferOverflow)null, 28, (DefaultConstructorMarker)null));
   }

   @ExperimentalCoroutinesApi
   @NotNull
   public static final <T, R> Flow<R> flatMapLatest(@NotNull Flow<? extends T> a, @BuilderInference @NotNull final Function2<? super T, ? super Continuation<? super Flow<? extends R>>, ? extends Object> a) {
      int a = false;
      return FlowKt.transformLatest(a, (Function3)(new Function3<FlowCollector<? super R>, T, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         private Object L$0;
         // $FF: synthetic field
         Object L$1;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            Object var10000;
            FlowCollector var4;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               FlowCollector axxx = (FlowCollector)ax.L$0;
               Object axxxx = ax.L$1;
               var4 = axxx;
               Function2 var6 = a;
               ax.L$0 = axxx;
               ax.label = 1;
               var10000 = var6.invoke(axxxx, ax);
               if (var10000 == var5) {
                  return var5;
               }
               break;
            case 1:
               var4 = (FlowCollector)ax.L$0;
               ResultKt.throwOnFailure(axx);
               var10000 = axx;
               break;
            case 2:
               ResultKt.throwOnFailure(axx);
               return Unit.INSTANCE;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            Flow var10001 = (Flow)var10000;
            Continuation var10002 = (Continuation)ax;
            ax.L$0 = null;
            ax.label = 2;
            if (FlowKt.emitAll(var4, var10001, var10002) == var5) {
               return var5;
            } else {
               return Unit.INSTANCE;
            }
         }

         @Nullable
         public final Object invokeSuspend$$forInline(@NotNull Object a1) {
            FlowCollector axx = (FlowCollector)ax.L$0;
            Object axxx = ax.L$1;
            Object var5 = a.invoke(axxx, ax);
            Flow var10001 = (Flow)var5;
            Continuation var10002 = (Continuation)ax;
            InlineMarker.mark(0);
            FlowKt.emitAll(axx, var10001, var10002);
            InlineMarker.mark(1);
            return Unit.INSTANCE;
         }

         @Nullable
         public final Object invoke(@NotNull FlowCollector<? super R> axxx, T axxxx, @Nullable Continuation<? super Unit> axx) {
            Function3 var4 = new <anonymous constructor>(axx);
            var4.L$0 = axxx;
            var4.L$1 = axxxx;
            return var4.invokeSuspend(Unit.INSTANCE);
         }
      }));
   }

   @ExperimentalCoroutinesApi
   @NotNull
   public static final <T, R> Flow<R> mapLatest(@NotNull Flow<? extends T> a, @BuilderInference @NotNull final Function2<? super T, ? super Continuation<? super R>, ? extends Object> a) {
      return FlowKt.transformLatest(a, (Function3)(new Function3<FlowCollector<? super R>, T, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         private Object L$0;
         // $FF: synthetic field
         Object L$1;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            Object var10000;
            FlowCollector var4;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               FlowCollector axxx = (FlowCollector)ax.L$0;
               Object axxxx = ax.L$1;
               var4 = axxx;
               Function2 var6 = a;
               ax.L$0 = axxx;
               ax.label = 1;
               var10000 = var6.invoke(axxxx, ax);
               if (var10000 == var5) {
                  return var5;
               }
               break;
            case 1:
               var4 = (FlowCollector)ax.L$0;
               ResultKt.throwOnFailure(axx);
               var10000 = axx;
               break;
            case 2:
               ResultKt.throwOnFailure(axx);
               return Unit.INSTANCE;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            Continuation var10002 = (Continuation)ax;
            ax.L$0 = null;
            ax.label = 2;
            if (var4.emit(var10000, var10002) == var5) {
               return var5;
            } else {
               return Unit.INSTANCE;
            }
         }

         @Nullable
         public final Object invoke(@NotNull FlowCollector<? super R> axxx, T axxxx, @Nullable Continuation<? super Unit> axx) {
            Function3 var4 = new <anonymous constructor>(axx);
            var4.L$0 = axxx;
            var4.L$1 = axxxx;
            return var4.invokeSuspend(Unit.INSTANCE);
         }
      }));
   }
}
