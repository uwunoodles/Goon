package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.InlineMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 3,
   xi = 48,
   d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u00032\u0006\u0010\u0004\u001a\u0002H\u0002H\u008a@¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"},
   d2 = {"<anonymous>", "", "T", "R", "value", "emit", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$1$1"}
)
public final class FlowKt__TransformKt$onEach$$inlined$unsafeTransform$1$2<T> implements FlowCollector {
   // $FF: synthetic field
   final FlowCollector $this_unsafeFlow;
   // $FF: synthetic field
   final Function2 $action$inlined;

   public FlowKt__TransformKt$onEach$$inlined$unsafeTransform$1$2(FlowCollector a, Function2 var2) {
      a.$this_unsafeFlow = a;
      a.$action$inlined = var2;
   }

   @Nullable
   public final Object emit(T a, @NotNull Continuation<? super Unit> var2) {
      FlowKt__TransformKt$onEach$$inlined$unsafeTransform$1$2$1 a;
      label27: {
         if (var2 instanceof FlowKt__TransformKt$onEach$$inlined$unsafeTransform$1$2$1) {
            a = (FlowKt__TransformKt$onEach$$inlined$unsafeTransform$1$2$1)var2;
            if ((a.label & Integer.MIN_VALUE) != 0) {
               a.label -= Integer.MIN_VALUE;
               break label27;
            }
         }

         a = new FlowKt__TransformKt$onEach$$inlined$unsafeTransform$1$2$1(a, var2);
      }

      Object a = a.result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      Object a;
      FlowCollector a;
      boolean a;
      switch(a.label) {
      case 0:
         ResultKt.throwOnFailure(a);
         Continuation var6 = (Continuation)a;
         a = a;
         a = a.$this_unsafeFlow;
         a = false;
         Function2 var10000 = a.$action$inlined;
         a.L$0 = a;
         a.L$1 = a;
         a.label = 1;
         InlineMarker.mark(6);
         Object var10 = var10000.invoke(a, a);
         InlineMarker.mark(7);
         if (var10 == var5) {
            return var5;
         }
         break;
      case 1:
         a = false;
         a = (FlowCollector)a.L$1;
         a = a.L$0;
         ResultKt.throwOnFailure(a);
         break;
      case 2:
         a = false;
         ResultKt.throwOnFailure(a);
         return Unit.INSTANCE;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      a.L$0 = null;
      a.L$1 = null;
      a.label = 2;
      if (a.emit(a, a) == var5) {
         return var5;
      } else {
         return Unit.INSTANCE;
      }
   }
}
