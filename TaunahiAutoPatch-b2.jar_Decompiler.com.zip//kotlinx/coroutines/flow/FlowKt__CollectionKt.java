package kotlinx.coroutines.flow;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000(\n\u0002\b\u0003\n\u0002\u0010\u001f\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0010!\n\u0002\b\u0002\n\u0002\u0010\"\n\u0002\u0010#\n\u0002\b\u0002\u001a;\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0002\"\u0010\b\u0001\u0010\u0001*\n\u0012\u0006\b\u0000\u0012\u0002H\u00020\u0003*\b\u0012\u0004\u0012\u0002H\u00020\u00042\u0006\u0010\u0005\u001a\u0002H\u0001H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0006\u001a7\u0010\u0007\u001a\b\u0012\u0004\u0012\u0002H\u00020\b\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00042\u000e\b\u0002\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00020\tH\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\n\u001a7\u0010\u000b\u001a\b\u0012\u0004\u0012\u0002H\u00020\f\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00042\u000e\b\u0002\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00020\rH\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u000e\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u000f"},
   d2 = {"toCollection", "C", "T", "", "Lkotlinx/coroutines/flow/Flow;", "destination", "(Lkotlinx/coroutines/flow/Flow;Ljava/util/Collection;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "toList", "", "", "(Lkotlinx/coroutines/flow/Flow;Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "toSet", "", "", "(Lkotlinx/coroutines/flow/Flow;Ljava/util/Set;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/flow/FlowKt"
)
final class FlowKt__CollectionKt {
   @Nullable
   public static final <T> Object toList(@NotNull Flow<? extends T> a, @NotNull List<T> a, @NotNull Continuation<? super List<? extends T>> a) {
      return FlowKt.toCollection(a, (Collection)a, a);
   }

   // $FF: synthetic method
   public static Object toList$default(Flow var0, List var1, Continuation var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = (List)(new ArrayList());
      }

      return FlowKt.toList(var0, var1, var2);
   }

   @Nullable
   public static final <T> Object toSet(@NotNull Flow<? extends T> a, @NotNull Set<T> a, @NotNull Continuation<? super Set<? extends T>> a) {
      return FlowKt.toCollection(a, (Collection)a, a);
   }

   // $FF: synthetic method
   public static Object toSet$default(Flow var0, Set var1, Continuation var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = (Set)(new LinkedHashSet());
      }

      return FlowKt.toSet(var0, var1, var2);
   }

   @Nullable
   public static final <T, C extends Collection<? super T>> Object toCollection(@NotNull Flow<? extends T> a, @NotNull final C a, @NotNull Continuation<? super C> var2) {
      Object a;
      label20: {
         if (var2 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var2;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label20;
            }
         }

         a = new ContinuationImpl(var2) {
            Object L$0;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return FlowKt.toCollection((Flow)null, (Collection)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         FlowCollector var10001 = (FlowCollector)(new FlowCollector() {
            @Nullable
            public final Object emit(T axx, @NotNull Continuation<? super Unit> a2) {
               a.add(axx);
               return Unit.INSTANCE;
            }
         });
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).label = 1;
         if (a.collect(var10001, (Continuation)a) == var5) {
            return var5;
         }
         break;
      case 1:
         a = (Collection)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      return a;
   }
}
