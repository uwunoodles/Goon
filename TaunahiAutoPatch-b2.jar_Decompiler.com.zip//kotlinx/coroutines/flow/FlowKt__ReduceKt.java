package kotlinx.coroutines.flow;

import java.util.NoSuchElementException;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.flow.internal.NullSurrogateKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000,\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\r\u001a!\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u0002H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0003\u001aE\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u00022\"\u0010\u0004\u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070\u0006\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0005H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\t\u001a#\u0010\n\u001a\u0004\u0018\u0001H\u0001\"\u0004\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u0002H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0003\u001aG\u0010\n\u001a\u0004\u0018\u0001H\u0001\"\u0004\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u00022\"\u0010\u0004\u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070\u0006\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0005H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\t\u001ay\u0010\u000b\u001a\u0002H\f\"\u0004\b\u0000\u0010\u0001\"\u0004\b\u0001\u0010\f*\b\u0012\u0004\u0012\u0002H\u00010\u00022\u0006\u0010\r\u001a\u0002H\f2H\b\u0004\u0010\u000e\u001aB\b\u0001\u0012\u0013\u0012\u0011H\f¢\u0006\f\b\u0010\u0012\b\b\u0011\u0012\u0004\b\b(\u0012\u0012\u0013\u0012\u0011H\u0001¢\u0006\f\b\u0010\u0012\b\b\u0011\u0012\u0004\b\b(\u0013\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\f0\u0006\u0012\u0006\u0012\u0004\u0018\u00010\b0\u000fH\u0086Hø\u0001\u0000¢\u0006\u0002\u0010\u0014\u001a!\u0010\u0015\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u0002H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0003\u001a#\u0010\u0016\u001a\u0004\u0018\u0001H\u0001\"\u0004\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u0002H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0003\u001as\u0010\u0017\u001a\u0002H\u0018\"\u0004\b\u0000\u0010\u0018\"\b\b\u0001\u0010\u0001*\u0002H\u0018*\b\u0012\u0004\u0012\u0002H\u00010\u00022F\u0010\u000e\u001aB\b\u0001\u0012\u0013\u0012\u0011H\u0018¢\u0006\f\b\u0010\u0012\b\b\u0011\u0012\u0004\b\b(\u0019\u0012\u0013\u0012\u0011H\u0001¢\u0006\f\b\u0010\u0012\b\b\u0011\u0012\u0004\b\b(\u0013\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00180\u0006\u0012\u0006\u0012\u0004\u0018\u00010\b0\u000fH\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u001a\u001a!\u0010\u001b\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u0002H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0003\u001a#\u0010\u001c\u001a\u0004\u0018\u0001H\u0001\"\u0004\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u0002H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0003\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001d"},
   d2 = {"first", "T", "Lkotlinx/coroutines/flow/Flow;", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "predicate", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "firstOrNull", "fold", "R", "initial", "operation", "Lkotlin/Function3;", "Lkotlin/ParameterName;", "name", "acc", "value", "(Lkotlinx/coroutines/flow/Flow;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "last", "lastOrNull", "reduce", "S", "accumulator", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function3;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "single", "singleOrNull", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/flow/FlowKt"
)
final class FlowKt__ReduceKt {
   @Nullable
   public static final <S, T extends S> Object reduce(@NotNull Flow<? extends T> a, @NotNull final Function3<? super S, ? super T, ? super Continuation<? super S>, ? extends Object> a, @NotNull Continuation<? super S> var2) {
      Object a;
      label24: {
         if (var2 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var2;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label24;
            }
         }

         a = new ContinuationImpl(var2) {
            Object L$0;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return FlowKt.reduce((Flow)null, (Function3)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var6 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      final Ref.ObjectRef a;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         a = new Ref.ObjectRef();
         a.element = NullSurrogateKt.NULL;
         FlowCollector var10001 = (FlowCollector)(new FlowCollector() {
            @Nullable
            public final Object emit(T axx, @NotNull Continuation<? super Unit> var2) {
               Object axxxx;
               label28: {
                  if (var2 instanceof <undefinedtype>) {
                     axxxx = (<undefinedtype>)var2;
                     if ((((<undefinedtype>)axxxx).label & Integer.MIN_VALUE) != 0) {
                        ((<undefinedtype>)axxxx).label -= Integer.MIN_VALUE;
                        break label28;
                     }
                  }

                  axxxx = new ContinuationImpl(var2) {
                     Object L$0;
                     // $FF: synthetic field
                     Object result;
                     int label;

                     @Nullable
                     public final Object invokeSuspend(@NotNull Object axxx) {
                        axx.result = axxx;
                        axx.label |= Integer.MIN_VALUE;
                        return ax.emit((Object)null, (Continuation)axx);
                     }
                  };
               }

               Object var10001;
               Ref.ObjectRef var7;
               label23: {
                  Object axxx = ((<undefinedtype>)axxxx).result;
                  Object var6 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                  Object var10000;
                  Ref.ObjectRef var3;
                  switch(((<undefinedtype>)axxxx).label) {
                  case 0:
                     ResultKt.throwOnFailure(axxx);
                     var7 = a;
                     if (a.element == NullSurrogateKt.NULL) {
                        var10001 = axx;
                        break label23;
                     }

                     var3 = var7;
                     Function3 var8 = a;
                     var10001 = a.element;
                     ((<undefinedtype>)axxxx).L$0 = var3;
                     ((<undefinedtype>)axxxx).label = 1;
                     var10000 = var8.invoke(var10001, axx, axxxx);
                     if (var10000 == var6) {
                        return var6;
                     }
                     break;
                  case 1:
                     var3 = (Ref.ObjectRef)((<undefinedtype>)axxxx).L$0;
                     ResultKt.throwOnFailure(axxx);
                     var10000 = axxx;
                     break;
                  default:
                     throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                  }

                  var10001 = var10000;
                  var7 = var3;
               }

               var7.element = var10001;
               return Unit.INSTANCE;
            }
         });
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).label = 1;
         if (a.collect(var10001, (Continuation)a) == var6) {
            return var6;
         }
         break;
      case 1:
         a = (Ref.ObjectRef)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      if (a.element == NullSurrogateKt.NULL) {
         throw new NoSuchElementException("Empty flow can't be reduced");
      } else {
         return a.element;
      }
   }

   @Nullable
   public static final <T, R> Object fold(@NotNull Flow<? extends T> a, R a, @NotNull Function3<? super R, ? super T, ? super Continuation<? super R>, ? extends Object> a, @NotNull Continuation<? super R> var3) {
      Object a;
      label20: {
         if (var3 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var3;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label20;
            }
         }

         a = new ContinuationImpl(var3) {
            Object L$0;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return FlowKt__ReduceKt.fold((Flow)null, (Object)null, (Function3)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var8 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      boolean a;
      Ref.ObjectRef a;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         a = false;
         a = new Ref.ObjectRef();
         a.element = a;
         FlowCollector var10001 = (FlowCollector)(new FlowCollector() {
            @Nullable
            public final Object emit(T axx, @NotNull Continuation<? super Unit> var2) {
               Object axxxx;
               label20: {
                  if (var2 instanceof <undefinedtype>) {
                     axxxx = (<undefinedtype>)var2;
                     if ((((<undefinedtype>)axxxx).label & Integer.MIN_VALUE) != 0) {
                        ((<undefinedtype>)axxxx).label -= Integer.MIN_VALUE;
                        break label20;
                     }
                  }

                  axxxx = new ContinuationImpl(var2) {
                     Object L$0;
                     // $FF: synthetic field
                     Object result;
                     int label;

                     @Nullable
                     public final Object invokeSuspend(@NotNull Object axxx) {
                        axx.result = axxx;
                        axx.label |= Integer.MIN_VALUE;
                        return ax.emit((Object)null, (Continuation)axx);
                     }
                  };
               }

               Object axxx = ((<undefinedtype>)axxxx).result;
               Object var6 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
               Object var10000;
               Ref.ObjectRef var3;
               switch(((<undefinedtype>)axxxx).label) {
               case 0:
                  ResultKt.throwOnFailure(axxx);
                  var3 = a;
                  Function3 var7 = a;
                  Object var10001 = a.element;
                  ((<undefinedtype>)axxxx).L$0 = var3;
                  ((<undefinedtype>)axxxx).label = 1;
                  var10000 = var7.invoke(var10001, axx, axxxx);
                  if (var10000 == var6) {
                     return var6;
                  }
                  break;
               case 1:
                  var3 = (Ref.ObjectRef)((<undefinedtype>)axxxx).L$0;
                  ResultKt.throwOnFailure(axxx);
                  var10000 = axxx;
                  break;
               default:
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
               }

               var3.element = var10000;
               return Unit.INSTANCE;
            }

            @Nullable
            public final Object emit$$forInline(T axx, @NotNull Continuation<? super Unit> axxx) {
               InlineMarker.mark(4);
               ContinuationImpl var10001 = new ContinuationImpl(axxx) {
                  Object L$0;
                  // $FF: synthetic field
                  Object result;
                  int label;

                  @Nullable
                  public final Object invokeSuspend(@NotNull Object axxx) {
                     axx.result = axxx;
                     axx.label |= Integer.MIN_VALUE;
                     return ax.emit((Object)null, (Continuation)axx);
                  }
               };
               InlineMarker.mark(5);
               Ref.ObjectRef var3 = a;
               Object var4 = a.invoke(a.element, axx, axxx);
               var3.element = var4;
               return Unit.INSTANCE;
            }
         });
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).label = 1;
         if (a.collect(var10001, (Continuation)a) == var8) {
            return var8;
         }
         break;
      case 1:
         a = false;
         a = (Ref.ObjectRef)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      return a.element;
   }

   private static final <T, R> Object fold$$forInline(Flow<? extends T> a, R a, final Function3<? super R, ? super T, ? super Continuation<? super R>, ? extends Object> a, Continuation<? super R> a) {
      int a = false;
      final Ref.ObjectRef a = new Ref.ObjectRef();
      a.element = a;
      FlowCollector var10001 = (FlowCollector)(new FlowCollector() {
         @Nullable
         public final Object emit(T axx, @NotNull Continuation<? super Unit> var2) {
            Object axxxx;
            label20: {
               if (var2 instanceof <undefinedtype>) {
                  axxxx = (<undefinedtype>)var2;
                  if ((((<undefinedtype>)axxxx).label & Integer.MIN_VALUE) != 0) {
                     ((<undefinedtype>)axxxx).label -= Integer.MIN_VALUE;
                     break label20;
                  }
               }

               axxxx = new ContinuationImpl(var2) {
                  Object L$0;
                  // $FF: synthetic field
                  Object result;
                  int label;

                  @Nullable
                  public final Object invokeSuspend(@NotNull Object axxx) {
                     axx.result = axxx;
                     axx.label |= Integer.MIN_VALUE;
                     return ax.emit((Object)null, (Continuation)axx);
                  }
               };
            }

            Object axxx = ((<undefinedtype>)axxxx).result;
            Object var6 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            Object var10000;
            Ref.ObjectRef var3;
            switch(((<undefinedtype>)axxxx).label) {
            case 0:
               ResultKt.throwOnFailure(axxx);
               var3 = a;
               Function3 var7 = a;
               Object var10001 = a.element;
               ((<undefinedtype>)axxxx).L$0 = var3;
               ((<undefinedtype>)axxxx).label = 1;
               var10000 = var7.invoke(var10001, axx, axxxx);
               if (var10000 == var6) {
                  return var6;
               }
               break;
            case 1:
               var3 = (Ref.ObjectRef)((<undefinedtype>)axxxx).L$0;
               ResultKt.throwOnFailure(axxx);
               var10000 = axxx;
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            var3.element = var10000;
            return Unit.INSTANCE;
         }

         @Nullable
         public final Object emit$$forInline(T axx, @NotNull Continuation<? super Unit> axxx) {
            InlineMarker.mark(4);
            ContinuationImpl var10001 = new ContinuationImpl(axxx) {
               Object L$0;
               // $FF: synthetic field
               Object result;
               int label;

               @Nullable
               public final Object invokeSuspend(@NotNull Object axxx) {
                  axx.result = axxx;
                  axx.label |= Integer.MIN_VALUE;
                  return ax.emit((Object)null, (Continuation)axx);
               }
            };
            InlineMarker.mark(5);
            Ref.ObjectRef var3 = a;
            Object var4 = a.invoke(a.element, axx, axxx);
            var3.element = var4;
            return Unit.INSTANCE;
         }
      });
      InlineMarker.mark(0);
      a.collect(var10001, a);
      InlineMarker.mark(1);
      return a.element;
   }

   @Nullable
   public static final <T> Object single(@NotNull Flow<? extends T> a, @NotNull Continuation<? super T> var1) {
      Object a;
      label24: {
         if (var1 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var1;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label24;
            }
         }

         a = new ContinuationImpl(var1) {
            Object L$0;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return FlowKt.single((Flow)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      final Ref.ObjectRef a;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         a = new Ref.ObjectRef();
         a.element = NullSurrogateKt.NULL;
         FlowCollector var10001 = (FlowCollector)(new FlowCollector() {
            @Nullable
            public final Object emit(T axxx, @NotNull Continuation<? super Unit> a2) {
               if (a.element != NullSurrogateKt.NULL) {
                  int axx = false;
                  String var4 = "Flow has more than one element";
                  throw new IllegalArgumentException(var4.toString());
               } else {
                  a.element = axxx;
                  return Unit.INSTANCE;
               }
            }
         });
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).label = 1;
         if (a.collect(var10001, (Continuation)a) == var5) {
            return var5;
         }
         break;
      case 1:
         a = (Ref.ObjectRef)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      if (a.element == NullSurrogateKt.NULL) {
         throw new NoSuchElementException("Flow is empty");
      } else {
         return a.element;
      }
   }

   @Nullable
   public static final <T> Object singleOrNull(@NotNull Flow<? extends T> param0, @NotNull Continuation<? super T> param1) {
      // $FF: Couldn't be decompiled
   }

   @Nullable
   public static final <T> Object first(@NotNull Flow<? extends T> param0, @NotNull Continuation<? super T> param1) {
      // $FF: Couldn't be decompiled
   }

   @Nullable
   public static final <T> Object first(@NotNull Flow<? extends T> param0, @NotNull Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> param1, @NotNull Continuation<? super T> param2) {
      // $FF: Couldn't be decompiled
   }

   @Nullable
   public static final <T> Object firstOrNull(@NotNull Flow<? extends T> param0, @NotNull Continuation<? super T> param1) {
      // $FF: Couldn't be decompiled
   }

   @Nullable
   public static final <T> Object firstOrNull(@NotNull Flow<? extends T> param0, @NotNull Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> param1, @NotNull Continuation<? super T> param2) {
      // $FF: Couldn't be decompiled
   }

   @Nullable
   public static final <T> Object last(@NotNull Flow<? extends T> a, @NotNull Continuation<? super T> var1) {
      Object a;
      label24: {
         if (var1 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var1;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label24;
            }
         }

         a = new ContinuationImpl(var1) {
            Object L$0;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return FlowKt.last((Flow)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      final Ref.ObjectRef a;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         a = new Ref.ObjectRef();
         a.element = NullSurrogateKt.NULL;
         FlowCollector var10001 = (FlowCollector)(new FlowCollector() {
            @Nullable
            public final Object emit(T axx, @NotNull Continuation<? super Unit> a2) {
               a.element = axx;
               return Unit.INSTANCE;
            }
         });
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).label = 1;
         if (a.collect(var10001, (Continuation)a) == var5) {
            return var5;
         }
         break;
      case 1:
         a = (Ref.ObjectRef)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      if (a.element == NullSurrogateKt.NULL) {
         throw new NoSuchElementException("Expected at least one element");
      } else {
         return a.element;
      }
   }

   @Nullable
   public static final <T> Object lastOrNull(@NotNull Flow<? extends T> a, @NotNull Continuation<? super T> var1) {
      Object a;
      label20: {
         if (var1 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var1;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label20;
            }
         }

         a = new ContinuationImpl(var1) {
            Object L$0;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return FlowKt.lastOrNull((Flow)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      final Ref.ObjectRef a;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         a = new Ref.ObjectRef();
         FlowCollector var10001 = (FlowCollector)(new FlowCollector() {
            @Nullable
            public final Object emit(T axx, @NotNull Continuation<? super Unit> a2) {
               a.element = axx;
               return Unit.INSTANCE;
            }
         });
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).label = 1;
         if (a.collect(var10001, (Continuation)a) == var5) {
            return var5;
         }
         break;
      case 1:
         a = (Ref.ObjectRef)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      return a.element;
   }
}
