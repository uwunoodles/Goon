package kotlinx.coroutines.flow;

import kotlin.BuilderInference;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.InlineMarker;
import kotlinx.coroutines.flow.internal.AbortFlowException;
import kotlinx.coroutines.flow.internal.FlowExceptions_commonKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000F\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001aV\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u000323\b\u0004\u0010\u0004\u001a-\b\u0001\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\u0006\u0012\b\b\u0007\u0012\u0004\b\b(\b\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\u0005H\u0080Hø\u0001\u0000¢\u0006\u0002\u0010\f\u001a$\u0010\r\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0003\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00032\u0006\u0010\u000e\u001a\u00020\u000f\u001aH\u0010\u0010\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0003\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00032\"\u0010\u0004\u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\u0005ø\u0001\u0000¢\u0006\u0002\u0010\u0011\u001a+\u0010\u0012\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00132\u0006\u0010\b\u001a\u0002H\u0002H\u0082@ø\u0001\u0000¢\u0006\u0004\b\u0014\u0010\u0015\u001a$\u0010\u0016\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0003\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00032\u0006\u0010\u000e\u001a\u00020\u000f\u001aH\u0010\u0017\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0003\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00032\"\u0010\u0004\u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\u0005ø\u0001\u0000¢\u0006\u0002\u0010\u0011\u001ap\u0010\u0018\u001a\b\u0012\u0004\u0012\u0002H\u00190\u0003\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0019*\b\u0012\u0004\u0012\u0002H\u00020\u00032D\b\u0001\u0010\u001a\u001a>\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00190\u0013\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\u0006\u0012\b\b\u0007\u0012\u0004\b\b(\b\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\u001b¢\u0006\u0002\b\u001cø\u0001\u0000¢\u0006\u0002\u0010\u001d\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001e"},
   d2 = {"collectWhile", "", "T", "Lkotlinx/coroutines/flow/Flow;", "predicate", "Lkotlin/Function2;", "Lkotlin/ParameterName;", "name", "value", "Lkotlin/coroutines/Continuation;", "", "", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "drop", "count", "", "dropWhile", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/flow/Flow;", "emitAbort", "Lkotlinx/coroutines/flow/FlowCollector;", "emitAbort$FlowKt__LimitKt", "(Lkotlinx/coroutines/flow/FlowCollector;Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "take", "takeWhile", "transformWhile", "R", "transform", "Lkotlin/Function3;", "Lkotlin/ExtensionFunctionType;", "(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function3;)Lkotlinx/coroutines/flow/Flow;", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/flow/FlowKt"
)
final class FlowKt__LimitKt {
   @NotNull
   public static final <T> Flow<T> drop(@NotNull Flow<? extends T> a, int a) {
      if (a < 0) {
         int a = false;
         String var4 = "Drop count should be non-negative, but had " + a;
         throw new IllegalArgumentException(var4.toString());
      } else {
         int a = false;
         return (Flow)(new FlowKt__LimitKt$drop$$inlined$unsafeFlow$1(a, a));
      }
   }

   @NotNull
   public static final <T> Flow<T> dropWhile(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> a) {
      int a = false;
      return (Flow)(new FlowKt__LimitKt$dropWhile$$inlined$unsafeFlow$1(a, a));
   }

   @NotNull
   public static final <T> Flow<T> take(@NotNull Flow<? extends T> a, int a) {
      if (a <= 0) {
         int a = false;
         String var4 = "Requested element count " + a + " should be positive";
         throw new IllegalArgumentException(var4.toString());
      } else {
         int a = false;
         return (Flow)(new FlowKt__LimitKt$take$$inlined$unsafeFlow$1(a, a));
      }
   }

   private static final <T> Object emitAbort$FlowKt__LimitKt(FlowCollector<? super T> a, T a, Continuation<? super Unit> var2) {
      Object a;
      label20: {
         if (var2 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var2;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label20;
            }
         }

         a = new ContinuationImpl(var2) {
            Object L$0;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return FlowKt__LimitKt.emitAbort$FlowKt__LimitKt((FlowCollector)null, (Object)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).label = 1;
         if (a.emit(a, (Continuation)a) == var5) {
            return var5;
         }
         break;
      case 1:
         a = (FlowCollector)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      throw new AbortFlowException(a);
   }

   @NotNull
   public static final <T> Flow<T> takeWhile(@NotNull Flow<? extends T> a, @NotNull Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> a) {
      int a = false;
      return (Flow)(new FlowKt__LimitKt$takeWhile$$inlined$unsafeFlow$1(a, a));
   }

   @NotNull
   public static final <T, R> Flow<R> transformWhile(@NotNull final Flow<? extends T> a, @BuilderInference @NotNull final Function3<? super FlowCollector<? super R>, ? super T, ? super Continuation<? super Boolean>, ? extends Object> a) {
      return FlowKt.flow((Function2)(new Function2<FlowCollector<? super R>, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object param1) {
            // $FF: Couldn't be decompiled
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull FlowCollector<? super R> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }));
   }

   @Nullable
   public static final <T> Object collectWhile(@NotNull Flow<? extends T> param0, @NotNull Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> param1, @NotNull Continuation<? super Unit> param2) {
      // $FF: Couldn't be decompiled
   }

   private static final <T> Object collectWhile$$forInline(Flow<? extends T> a, final Function2<? super T, ? super Continuation<? super Boolean>, ? extends Object> a, Continuation<? super Unit> a) {
      int a = false;
      FlowCollector a = new FlowCollector<T>() {
         @Nullable
         public Object emit(T axx, @NotNull Continuation<? super Unit> var2) {
            Object axxxx;
            label24: {
               if (var2 instanceof <undefinedtype>) {
                  axxxx = (<undefinedtype>)var2;
                  if ((((<undefinedtype>)axxxx).label & Integer.MIN_VALUE) != 0) {
                     ((<undefinedtype>)axxxx).label -= Integer.MIN_VALUE;
                     break label24;
                  }
               }

               axxxx = new ContinuationImpl(var2) {
                  Object L$0;
                  // $FF: synthetic field
                  Object result;
                  int label;

                  @Nullable
                  public final Object invokeSuspend(@NotNull Object axxx) {
                     axx.result = axxx;
                     axx.label |= Integer.MIN_VALUE;
                     return ax.emit((Object)null, (Continuation)axx);
                  }
               };
            }

            Object axxx = ((<undefinedtype>)axxxx).result;
            Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            Object var10000;
            switch(((<undefinedtype>)axxxx).label) {
            case 0:
               ResultKt.throwOnFailure(axxx);
               Function2 var6 = a;
               ((<undefinedtype>)axxxx).L$0 = ax;
               ((<undefinedtype>)axxxx).label = 1;
               var10000 = var6.invoke(axx, axxxx);
               if (var10000 == var5) {
                  return var5;
               }
               break;
            case 1:
               ax = (<undefinedtype>)((<undefinedtype>)axxxx).L$0;
               ResultKt.throwOnFailure(axxx);
               var10000 = axxx;
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            if (!(Boolean)var10000) {
               throw new AbortFlowException((FlowCollector)ax);
            } else {
               return Unit.INSTANCE;
            }
         }

         @Nullable
         public Object emit$$forInline(T axx, @NotNull Continuation<? super Unit> axxx) {
            InlineMarker.mark(4);
            ContinuationImpl var10001 = new ContinuationImpl(axxx) {
               Object L$0;
               // $FF: synthetic field
               Object result;
               int label;

               @Nullable
               public final Object invokeSuspend(@NotNull Object axxx) {
                  axx.result = axxx;
                  axx.label |= Integer.MIN_VALUE;
                  return ax.emit((Object)null, (Continuation)axx);
               }
            };
            InlineMarker.mark(5);
            if (!(Boolean)a.invoke(axx, axxx)) {
               throw new AbortFlowException((FlowCollector)ax);
            } else {
               return Unit.INSTANCE;
            }
         }
      };

      try {
         FlowCollector var10001 = (FlowCollector)a;
         InlineMarker.mark(0);
         a.collect(var10001, a);
         InlineMarker.mark(1);
      } catch (AbortFlowException var6) {
         FlowExceptions_commonKt.checkOwnership(var6, (FlowCollector)a);
      }

      return Unit.INSTANCE;
   }
}
