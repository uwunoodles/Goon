package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.InlineMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 176,
   d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u001f\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005H\u0096@ø\u0001\u0000¢\u0006\u0002\u0010\u0006\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0007¸\u0006\b"},
   d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Lkotlinx/coroutines/flow/Flow;", "collect", "", "collector", "Lkotlinx/coroutines/flow/FlowCollector;", "(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core", "kotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$$inlined$unsafeFlow$1"}
)
public final class FlowKt__TransformKt$filterNot$$inlined$unsafeTransform$1 implements Flow<T> {
   // $FF: synthetic field
   final Flow $this_unsafeTransform$inlined;
   // $FF: synthetic field
   final Function2 $predicate$inlined;

   public FlowKt__TransformKt$filterNot$$inlined$unsafeTransform$1(Flow var1, Function2 var2) {
      a.$this_unsafeTransform$inlined = var1;
      a.$predicate$inlined = var2;
   }

   @Nullable
   public Object collect(@NotNull FlowCollector a, @NotNull Continuation a) {
      int a = false;
      Object var10000 = a.$this_unsafeTransform$inlined.collect((FlowCollector)(new FlowKt__TransformKt$filterNot$$inlined$unsafeTransform$1$2(a, a.$predicate$inlined)), a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   @Nullable
   public Object collect$$forInline(@NotNull FlowCollector a, @NotNull Continuation a) {
      InlineMarker.mark(4);
      new FlowKt__TransformKt$filterNot$$inlined$unsafeTransform$1$1(a, a);
      InlineMarker.mark(5);
      int a = false;
      Flow var10000 = a.$this_unsafeTransform$inlined;
      FlowCollector var10001 = (FlowCollector)(new FlowKt__TransformKt$filterNot$$inlined$unsafeTransform$1$2(a, a.$predicate$inlined));
      InlineMarker.mark(0);
      var10000.collect(var10001, a);
      InlineMarker.mark(1);
      return Unit.INSTANCE;
   }
}
