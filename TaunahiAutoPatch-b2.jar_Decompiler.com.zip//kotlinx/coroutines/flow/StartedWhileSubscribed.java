package kotlinx.coroutines.flow;

import java.util.List;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlinx.coroutines.DelayKt;
import org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J\u001c\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nH\u0016J\u0013\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0096\u0002J\b\u0010\u0010\u001a\u00020\u000bH\u0017J\b\u0010\u0011\u001a\u00020\u0012H\u0016R\u000e\u0010\u0004\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0013"},
   d2 = {"Lkotlinx/coroutines/flow/StartedWhileSubscribed;", "Lkotlinx/coroutines/flow/SharingStarted;", "stopTimeout", "", "replayExpiration", "(JJ)V", "command", "Lkotlinx/coroutines/flow/Flow;", "Lkotlinx/coroutines/flow/SharingCommand;", "subscriptionCount", "Lkotlinx/coroutines/flow/StateFlow;", "", "equals", "", "other", "", "hashCode", "toString", "", "kotlinx-coroutines-core"}
)
final class StartedWhileSubscribed implements SharingStarted {
   private final long stopTimeout;
   private final long replayExpiration;

   public StartedWhileSubscribed(long a, long a) {
      a.stopTimeout = a;
      a.replayExpiration = a;
      boolean a;
      String var6;
      if (a.stopTimeout < 0L) {
         a = false;
         var6 = "stopTimeout(" + a.stopTimeout + " ms) cannot be negative";
         throw new IllegalArgumentException(var6.toString());
      } else if (a.replayExpiration < 0L) {
         a = false;
         var6 = "replayExpiration(" + a.replayExpiration + " ms) cannot be negative";
         throw new IllegalArgumentException(var6.toString());
      }
   }

   @NotNull
   public Flow<SharingCommand> command(@NotNull StateFlow<Integer> a) {
      return FlowKt.distinctUntilChanged(FlowKt.dropWhile(FlowKt.transformLatest((Flow)a, (Function3)(new Function3<FlowCollector<? super SharingCommand>, Integer, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         private Object L$0;
         // $FF: synthetic field
         int I$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            FlowCollector axxx;
            Continuation var10002;
            Object var4;
            SharingCommand var5;
            label56: {
               long var10000;
               Continuation var10001;
               label66: {
                  var4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                  switch(ax.label) {
                  case 0:
                     ResultKt.throwOnFailure(axx);
                     axxx = (FlowCollector)ax.L$0;
                     int axxxx = ax.I$0;
                     if (axxxx > 0) {
                        var5 = SharingCommand.START;
                        var10002 = (Continuation)ax;
                        ax.label = 1;
                        if (axxx.emit(var5, var10002) == var4) {
                           return var4;
                        }

                        return Unit.INSTANCE;
                     }

                     var10000 = a.stopTimeout;
                     var10001 = (Continuation)ax;
                     ax.L$0 = axxx;
                     ax.label = 2;
                     if (DelayKt.delay(var10000, var10001) == var4) {
                        return var4;
                     }
                     break;
                  case 1:
                     ResultKt.throwOnFailure(axx);
                     return Unit.INSTANCE;
                  case 2:
                     axxx = (FlowCollector)ax.L$0;
                     ResultKt.throwOnFailure(axx);
                     break;
                  case 3:
                     axxx = (FlowCollector)ax.L$0;
                     ResultKt.throwOnFailure(axx);
                     break label66;
                  case 4:
                     axxx = (FlowCollector)ax.L$0;
                     ResultKt.throwOnFailure(axx);
                     break label56;
                  case 5:
                     ResultKt.throwOnFailure(axx);
                     return Unit.INSTANCE;
                  default:
                     throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                  }

                  if (a.replayExpiration <= 0L) {
                     break label56;
                  }

                  var5 = SharingCommand.STOP;
                  var10002 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.label = 3;
                  if (axxx.emit(var5, var10002) == var4) {
                     return var4;
                  }
               }

               var10000 = a.replayExpiration;
               var10001 = (Continuation)ax;
               ax.L$0 = axxx;
               ax.label = 4;
               if (DelayKt.delay(var10000, var10001) == var4) {
                  return var4;
               }
            }

            var5 = SharingCommand.STOP_AND_RESET_REPLAY_CACHE;
            var10002 = (Continuation)ax;
            ax.L$0 = null;
            ax.label = 5;
            if (axxx.emit(var5, var10002) == var4) {
               return var4;
            } else {
               return Unit.INSTANCE;
            }
         }

         @Nullable
         public final Object invoke(@NotNull FlowCollector<? super SharingCommand> axxx, int axxxx, @Nullable Continuation<? super Unit> axx) {
            Function3 var4 = new <anonymous constructor>(axx);
            var4.L$0 = axxx;
            var4.I$0 = axxxx;
            return var4.invokeSuspend(Unit.INSTANCE);
         }
      })), (Function2)(new Function2<SharingCommand, Continuation<? super Boolean>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object var1) {
            IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(a.label) {
            case 0:
               ResultKt.throwOnFailure(var1);
               SharingCommand ax = (SharingCommand)a.L$0;
               return Boxing.boxBoolean(ax != SharingCommand.START);
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object ax, @NotNull Continuation<?> axx) {
            Function2 var3 = new <anonymous constructor>(axx);
            var3.L$0 = ax;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull SharingCommand ax, @Nullable Continuation<? super Boolean> axx) {
            return ((<undefinedtype>)a.create(ax, axx)).invokeSuspend(Unit.INSTANCE);
         }
      })));
   }

   @NotNull
   public String toString() {
      List var2 = CollectionsKt.createListBuilder(2);
      int a = false;
      if (a.stopTimeout > 0L) {
         var2.add("stopTimeout=" + a.stopTimeout + "ms");
      }

      if (a.replayExpiration < Long.MAX_VALUE) {
         var2.add("replayExpiration=" + a.replayExpiration + "ms");
      }

      List a = CollectionsKt.build(var2);
      return "SharingStarted.WhileSubscribed(" + CollectionsKt.joinToString$default((Iterable)a, (CharSequence)null, (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 63, (Object)null) + ')';
   }

   public boolean equals(@Nullable Object a) {
      return a instanceof StartedWhileSubscribed && a.stopTimeout == ((StartedWhileSubscribed)a).stopTimeout && a.replayExpiration == ((StartedWhileSubscribed)a).replayExpiration;
   }

   @IgnoreJRERequirement
   public int hashCode() {
      return Long.hashCode(a.stopTimeout) * 31 + Long.hashCode(a.replayExpiration);
   }
}
