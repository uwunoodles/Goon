package kotlinx.coroutines.flow;

import java.util.concurrent.CancellationException;
import kotlin.Metadata;
import kotlin.OverloadResolutionByLambdaReturnType;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.JvmName;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Ref;
import kotlin.time.Duration;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.FlowPreview;
import kotlinx.coroutines.channels.ChannelResult;
import kotlinx.coroutines.channels.ProduceKt;
import kotlinx.coroutines.channels.ProducerScope;
import kotlinx.coroutines.channels.ReceiveChannel;
import kotlinx.coroutines.channels.SendChannel;
import kotlinx.coroutines.flow.internal.ChildCancelledException;
import kotlinx.coroutines.flow.internal.FlowCoroutineKt;
import kotlinx.coroutines.flow.internal.NullSurrogateKt;
import kotlinx.coroutines.internal.Symbol;
import kotlinx.coroutines.selects.SelectBuilder;
import kotlinx.coroutines.selects.SelectBuilderImpl;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000,\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u001a2\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0012\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00050\u0004H\u0007\u001a:\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00070\u0004H\u0007ø\u0001\u0000¢\u0006\u0002\b\b\u001a&\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0005H\u0007\u001a3\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0006\u0010\u0006\u001a\u00020\u0007H\u0007ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\t\u0010\n\u001a7\u0010\u000b\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0012\u0010\f\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00050\u0004H\u0002¢\u0006\u0002\b\r\u001a$\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000f*\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00052\b\b\u0002\u0010\u0013\u001a\u00020\u0005H\u0000\u001a&\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0006\u0010\u0015\u001a\u00020\u0005H\u0007\u001a3\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0006\u0010\u0016\u001a\u00020\u0007H\u0007ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\u0017\u0010\n\u0082\u0002\u000b\n\u0002\b\u0019\n\u0005\b¡\u001e0\u0001¨\u0006\u0018"},
   d2 = {"debounce", "Lkotlinx/coroutines/flow/Flow;", "T", "timeoutMillis", "Lkotlin/Function1;", "", "timeout", "Lkotlin/time/Duration;", "debounceDuration", "debounce-HG0u8IE", "(Lkotlinx/coroutines/flow/Flow;J)Lkotlinx/coroutines/flow/Flow;", "debounceInternal", "timeoutMillisSelector", "debounceInternal$FlowKt__DelayKt", "fixedPeriodTicker", "Lkotlinx/coroutines/channels/ReceiveChannel;", "", "Lkotlinx/coroutines/CoroutineScope;", "delayMillis", "initialDelayMillis", "sample", "periodMillis", "period", "sample-HG0u8IE", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/flow/FlowKt"
)
final class FlowKt__DelayKt {
   @FlowPreview
   @NotNull
   public static final <T> Flow<T> debounce(@NotNull Flow<? extends T> a, final long a) {
      if (a < 0L) {
         int a = false;
         String var4 = "Debounce timeout should not be negative";
         throw new IllegalArgumentException(var4.toString());
      } else {
         return a == 0L ? a : debounceInternal$FlowKt__DelayKt(a, (Function1)(new Function1<T, Long>() {
            @NotNull
            public final Long invoke(T a1) {
               return a;
            }
         }));
      }
   }

   @FlowPreview
   @OverloadResolutionByLambdaReturnType
   @NotNull
   public static final <T> Flow<T> debounce(@NotNull Flow<? extends T> a, @NotNull Function1<? super T, Long> a) {
      return debounceInternal$FlowKt__DelayKt(a, a);
   }

   @FlowPreview
   @NotNull
   public static final <T> Flow<T> debounce_HG0u8IE/* $FF was: debounce-HG0u8IE*/(@NotNull Flow<? extends T> a, long a) {
      return FlowKt.debounce(a, DelayKt.toDelayMillis-LRDsOJo(a));
   }

   @FlowPreview
   @JvmName(
      name = "debounceDuration"
   )
   @OverloadResolutionByLambdaReturnType
   @NotNull
   public static final <T> Flow<T> debounceDuration(@NotNull Flow<? extends T> a, @NotNull final Function1<? super T, Duration> a) {
      return debounceInternal$FlowKt__DelayKt(a, (Function1)(new Function1<T, Long>() {
         @NotNull
         public final Long invoke(T axx) {
            return DelayKt.toDelayMillis-LRDsOJo(((Duration)a.invoke(axx)).unbox-impl());
         }
      }));
   }

   private static final <T> Flow<T> debounceInternal$FlowKt__DelayKt(final Flow<? extends T> a, final Function1<? super T, Long> a) {
      return FlowCoroutineKt.scopedFlow((Function3)(new Function3<CoroutineScope, FlowCollector<? super T>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$2;
         Object L$3;
         int label;
         // $FF: synthetic field
         private Object L$0;
         // $FF: synthetic field
         Object L$1;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var14 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            final FlowCollector axxxx;
            ReceiveChannel axxxxx;
            final Ref.ObjectRef axxxxxx;
            Ref.LongRef axxxxxxx;
            boolean axxxxxxxx;
            Continuation axxxxxxxxx;
            boolean axxxxxxxxxx;
            SelectBuilderImpl axxxxxxxxxxx;
            SelectBuilder axxxxxxxxxxxx;
            boolean axxxxxxxxxxxxx;
            Object var21;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               CoroutineScope axxx = (CoroutineScope)ax.L$0;
               axxxx = (FlowCollector)ax.L$1;
               axxxxx = ProduceKt.produce$default(axxx, (CoroutineContext)null, 0, (Function2)(new Function2<ProducerScope<? super Object>, Continuation<? super Unit>, Object>((Continuation)null) {
                  int label;
                  // $FF: synthetic field
                  private Object L$0;

                  @Nullable
                  public final Object invokeSuspend(@NotNull Object axx) {
                     Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                     switch(ax.label) {
                     case 0:
                        ResultKt.throwOnFailure(axx);
                        final ProducerScope axxx = (ProducerScope)ax.L$0;
                        Flow var10000 = a;
                        FlowCollector var10001 = (FlowCollector)(new FlowCollector() {
                           @Nullable
                           public final Object emit(T axx, @NotNull Continuation<? super Unit> var2) {
                              Object axxxxx;
                              label24: {
                                 if (var2 instanceof <undefinedtype>) {
                                    axxxxx = (<undefinedtype>)var2;
                                    if ((((<undefinedtype>)axxxxx).label & Integer.MIN_VALUE) != 0) {
                                       ((<undefinedtype>)axxxxx).label -= Integer.MIN_VALUE;
                                       break label24;
                                    }
                                 }

                                 axxxxx = new ContinuationImpl(var2) {
                                    // $FF: synthetic field
                                    Object result;
                                    int label;

                                    @Nullable
                                    public final Object invokeSuspend(@NotNull Object axxxx) {
                                       axx.result = axxxx;
                                       axx.label |= Integer.MIN_VALUE;
                                       return ax.emit((Object)null, (Continuation)axx);
                                    }
                                 };
                              }

                              Object axxxx = ((<undefinedtype>)axxxxx).result;
                              Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                              switch(((<undefinedtype>)axxxxx).label) {
                              case 0:
                                 ResultKt.throwOnFailure(axxxx);
                                 ProducerScope var10000 = axxx;
                                 Object var10001 = axx;
                                 if (axx == null) {
                                    var10001 = NullSurrogateKt.NULL;
                                 }

                                 ((<undefinedtype>)axxxxx).label = 1;
                                 if (var10000.send(var10001, (Continuation)axxxxx) == var5) {
                                    return var5;
                                 }
                                 break;
                              case 1:
                                 ResultKt.throwOnFailure(axxxx);
                                 break;
                              default:
                                 throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                              }

                              return Unit.INSTANCE;
                           }
                        });
                        Continuation var10002 = (Continuation)ax;
                        ax.label = 1;
                        if (var10000.collect(var10001, var10002) == var3) {
                           return var3;
                        }
                        break;
                     case 1:
                        ResultKt.throwOnFailure(axx);
                        break;
                     default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                     }

                     return Unit.INSTANCE;
                  }

                  @NotNull
                  public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
                     Function2 var3 = new <anonymous constructor>(axxx);
                     var3.L$0 = axx;
                     return (Continuation)var3;
                  }

                  @Nullable
                  public final Object invoke(@NotNull ProducerScope<Object> axx, @Nullable Continuation<? super Unit> axxx) {
                     return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
                  }
               }), 3, (Object)null);
               axxxxxx = new Ref.ObjectRef();
               break;
            case 1:
               axxxxxxx = (Ref.LongRef)ax.L$3;
               axxxxxx = (Ref.ObjectRef)ax.L$2;
               axxxxx = (ReceiveChannel)ax.L$1;
               axxxx = (FlowCollector)ax.L$0;
               ResultKt.throwOnFailure(axx);
               axxxxxx.element = null;
               if (DebugKt.getASSERTIONS_ENABLED()) {
                  axxxxxxxx = false;
                  if (!(axxxxxx.element != null ? axxxxxxx.element > 0L : true)) {
                     throw new AssertionError();
                  }
               }

               axxxxxxxx = false;
               ax.L$0 = axxxx;
               ax.L$1 = axxxxx;
               ax.L$2 = axxxxxx;
               ax.L$3 = axxxxxxx;
               ax.label = 2;
               axxxxxxxxx = (Continuation)ax;
               axxxxxxxxxx = false;
               axxxxxxxxxxx = new SelectBuilderImpl(axxxxxxxxx);

               try {
                  axxxxxxxxxxxx = (SelectBuilder)axxxxxxxxxxx;
                  axxxxxxxxxxxxx = false;
                  if (axxxxxx.element != null) {
                     axxxxxxxxxxxx.onTimeout(axxxxxxx.element, (Function1)(new Function1<Continuation<? super Unit>, Object>((Continuation)null) {
                        int label;

                        @Nullable
                        public final Object invokeSuspend(@NotNull Object axx) {
                           Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                           switch(ax.label) {
                           case 0:
                              ResultKt.throwOnFailure(axx);
                              FlowCollector var10000 = axxxx;
                              Symbol axxx = NullSurrogateKt.NULL;
                              Object axxxxx = axxxxxx.element;
                              int axxxxxxx = false;
                              Object var10001 = axxxxx == axxx ? null : axxxxx;
                              Continuation var10002 = (Continuation)ax;
                              ax.label = 1;
                              if (var10000.emit(var10001, var10002) == var5) {
                                 return var5;
                              }
                              break;
                           case 1:
                              ResultKt.throwOnFailure(axx);
                              break;
                           default:
                              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                           }

                           axxxxxx.element = null;
                           return Unit.INSTANCE;
                        }

                        @NotNull
                        public final Continuation<Unit> create(@NotNull Continuation<?> axx) {
                           return (Continuation)(new <anonymous constructor>(axx));
                        }

                        @Nullable
                        public final Object invoke(@Nullable Continuation<? super Unit> axx) {
                           return ((<undefinedtype>)ax.create(axx)).invokeSuspend(Unit.INSTANCE);
                        }
                     }));
                  }

                  axxxxxxxxxxxx.invoke(axxxxx.getOnReceiveCatching(), (Function2)(new Function2<ChannelResult<? extends Object>, Continuation<? super Unit>, Object>((Continuation)null) {
                     Object L$1;
                     int label;
                     // $FF: synthetic field
                     Object L$0;

                     @Nullable
                     public final Object invokeSuspend(@NotNull Object axxx) {
                        Object var12 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        Ref.ObjectRef var4;
                        boolean axxxxxxxxxx;
                        boolean axxxxxxxxxxxx;
                        switch(ax.label) {
                        case 0:
                           ResultKt.throwOnFailure(axxx);
                           Object axxxxx = ((ChannelResult)ax.L$0).unbox-impl();
                           var4 = axxxxxx;
                           int axxxxxxxxx = false;
                           if (!(axxxxx instanceof ChannelResult.Failed)) {
                              int axxxxxxxxxxx = false;
                              var4.element = axxxxx;
                           }

                           var4 = axxxxxx;
                           FlowCollector var13 = axxxx;
                           axxxxxxxxxx = false;
                           if (!(axxxxx instanceof ChannelResult.Failed)) {
                              return Unit.INSTANCE;
                           }

                           Throwable axxxxxxxx = ChannelResult.exceptionOrNull-impl(axxxxx);
                           axxxxxxxxxxxx = false;
                           boolean axx;
                           if (axxxxxxxx != null) {
                              axx = false;
                              throw axxxxxxxx;
                           }

                           if (var4.element != null) {
                              Symbol axxxxxxxxxxxxx = NullSurrogateKt.NULL;
                              Object axxxxxxxxxxxxxx = var4.element;
                              axx = false;
                              Object var10001 = axxxxxxxxxxxxxx == axxxxxxxxxxxxx ? null : axxxxxxxxxxxxxx;
                              ax.L$0 = axxxxx;
                              ax.L$1 = var4;
                              ax.label = 1;
                              if (var13.emit(var10001, ax) == var12) {
                                 return var12;
                              }
                           }
                           break;
                        case 1:
                           axxxxxxxxxx = false;
                           axxxxxxxxxxxx = false;
                           var4 = (Ref.ObjectRef)ax.L$1;
                           Object axxxxxxx = ax.L$0;
                           ResultKt.throwOnFailure(axxx);
                           break;
                        default:
                           throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }

                        var4.element = NullSurrogateKt.DONE;
                        return Unit.INSTANCE;
                     }

                     @NotNull
                     public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
                        Function2 var3 = new <anonymous constructor>(axxx);
                        var3.L$0 = axx;
                        return (Continuation)var3;
                     }

                     @Nullable
                     public final Object invoke_WpGqRn0/* $FF was: invoke-WpGqRn0*/(@NotNull Object axx, @Nullable Continuation<? super Unit> axxx) {
                        return ((<undefinedtype>)ax.create(ChannelResult.box-impl(axx), axxx)).invokeSuspend(Unit.INSTANCE);
                     }
                  }));
               } catch (Throwable var15) {
                  axxxxxxxxxxx.handleBuilderException(var15);
               }

               var21 = axxxxxxxxxxx.getResult();
               if (var21 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
                  DebugProbesKt.probeCoroutineSuspended((Continuation)ax);
               }

               if (var21 == var14) {
                  return var14;
               }
               break;
            case 2:
               axxxxxxxx = false;
               Ref.LongRef var10000 = (Ref.LongRef)ax.L$3;
               axxxxxx = (Ref.ObjectRef)ax.L$2;
               axxxxx = (ReceiveChannel)ax.L$1;
               axxxx = (FlowCollector)ax.L$0;
               ResultKt.throwOnFailure(axx);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            do {
               if (axxxxxx.element == NullSurrogateKt.DONE) {
                  return Unit.INSTANCE;
               }

               axxxxxxx = new Ref.LongRef();
               if (axxxxxx.element != null) {
                  Symbol axxxxxxxxxxxxxx = NullSurrogateKt.NULL;
                  Object axxxxxxxxxxxxxxx = axxxxxx.element;
                  axxxxxxxxxx = false;
                  axxxxxxx.element = ((Number)a.invoke(axxxxxxxxxxxxxxx == axxxxxxxxxxxxxx ? null : axxxxxxxxxxxxxxx)).longValue();
                  if (axxxxxxx.element < 0L) {
                     int axxxxxxxxxxxxxxxx = false;
                     String var20 = "Debounce timeout should not be negative";
                     throw new IllegalArgumentException(var20.toString());
                  }

                  if (axxxxxxx.element == 0L) {
                     axxxxxxxxxxxxxx = NullSurrogateKt.NULL;
                     axxxxxxxxxxxxxxx = axxxxxx.element;
                     axxxxxxxxxx = false;
                     Object var10001 = axxxxxxxxxxxxxxx == axxxxxxxxxxxxxx ? null : axxxxxxxxxxxxxxx;
                     Continuation var10002 = (Continuation)ax;
                     ax.L$0 = axxxx;
                     ax.L$1 = axxxxx;
                     ax.L$2 = axxxxxx;
                     ax.L$3 = axxxxxxx;
                     ax.label = 1;
                     if (axxxx.emit(var10001, var10002) == var14) {
                        return var14;
                     }

                     axxxxxx.element = null;
                  }
               }

               if (DebugKt.getASSERTIONS_ENABLED()) {
                  axxxxxxxx = false;
                  if (!(axxxxxx.element != null ? axxxxxxx.element > 0L : true)) {
                     throw new AssertionError();
                  }
               }

               axxxxxxxx = false;
               ax.L$0 = axxxx;
               ax.L$1 = axxxxx;
               ax.L$2 = axxxxxx;
               ax.L$3 = axxxxxxx;
               ax.label = 2;
               axxxxxxxxx = (Continuation)ax;
               axxxxxxxxxx = false;
               axxxxxxxxxxx = new SelectBuilderImpl(axxxxxxxxx);

               try {
                  axxxxxxxxxxxx = (SelectBuilder)axxxxxxxxxxx;
                  axxxxxxxxxxxxx = false;
                  if (axxxxxx.element != null) {
                     axxxxxxxxxxxx.onTimeout(axxxxxxx.element, (Function1)(new Function1<Continuation<? super Unit>, Object>((Continuation)null) {
                        int label;

                        @Nullable
                        public final Object invokeSuspend(@NotNull Object axx) {
                           Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                           switch(ax.label) {
                           case 0:
                              ResultKt.throwOnFailure(axx);
                              FlowCollector var10000 = axxxx;
                              Symbol axxx = NullSurrogateKt.NULL;
                              Object axxxxx = axxxxxx.element;
                              int axxxxxxx = false;
                              Object var10001 = axxxxx == axxx ? null : axxxxx;
                              Continuation var10002 = (Continuation)ax;
                              ax.label = 1;
                              if (var10000.emit(var10001, var10002) == var5) {
                                 return var5;
                              }
                              break;
                           case 1:
                              ResultKt.throwOnFailure(axx);
                              break;
                           default:
                              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                           }

                           axxxxxx.element = null;
                           return Unit.INSTANCE;
                        }

                        @NotNull
                        public final Continuation<Unit> create(@NotNull Continuation<?> axx) {
                           return (Continuation)(new <anonymous constructor>(axx));
                        }

                        @Nullable
                        public final Object invoke(@Nullable Continuation<? super Unit> axx) {
                           return ((<undefinedtype>)ax.create(axx)).invokeSuspend(Unit.INSTANCE);
                        }
                     }));
                  }

                  axxxxxxxxxxxx.invoke(axxxxx.getOnReceiveCatching(), (Function2)(new Function2<ChannelResult<? extends Object>, Continuation<? super Unit>, Object>((Continuation)null) {
                     Object L$1;
                     int label;
                     // $FF: synthetic field
                     Object L$0;

                     @Nullable
                     public final Object invokeSuspend(@NotNull Object axxx) {
                        Object var12 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        Ref.ObjectRef var4;
                        boolean axxxxxxxxxx;
                        boolean axxxxxxxxxxxx;
                        switch(ax.label) {
                        case 0:
                           ResultKt.throwOnFailure(axxx);
                           Object axxxxx = ((ChannelResult)ax.L$0).unbox-impl();
                           var4 = axxxxxx;
                           int axxxxxxxxx = false;
                           if (!(axxxxx instanceof ChannelResult.Failed)) {
                              int axxxxxxxxxxx = false;
                              var4.element = axxxxx;
                           }

                           var4 = axxxxxx;
                           FlowCollector var13 = axxxx;
                           axxxxxxxxxx = false;
                           if (!(axxxxx instanceof ChannelResult.Failed)) {
                              return Unit.INSTANCE;
                           }

                           Throwable axxxxxxxx = ChannelResult.exceptionOrNull-impl(axxxxx);
                           axxxxxxxxxxxx = false;
                           boolean axx;
                           if (axxxxxxxx != null) {
                              axx = false;
                              throw axxxxxxxx;
                           }

                           if (var4.element != null) {
                              Symbol axxxxxxxxxxxxx = NullSurrogateKt.NULL;
                              Object axxxxxxxxxxxxxx = var4.element;
                              axx = false;
                              Object var10001 = axxxxxxxxxxxxxx == axxxxxxxxxxxxx ? null : axxxxxxxxxxxxxx;
                              ax.L$0 = axxxxx;
                              ax.L$1 = var4;
                              ax.label = 1;
                              if (var13.emit(var10001, ax) == var12) {
                                 return var12;
                              }
                           }
                           break;
                        case 1:
                           axxxxxxxxxx = false;
                           axxxxxxxxxxxx = false;
                           var4 = (Ref.ObjectRef)ax.L$1;
                           Object axxxxxxx = ax.L$0;
                           ResultKt.throwOnFailure(axxx);
                           break;
                        default:
                           throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }

                        var4.element = NullSurrogateKt.DONE;
                        return Unit.INSTANCE;
                     }

                     @NotNull
                     public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
                        Function2 var3 = new <anonymous constructor>(axxx);
                        var3.L$0 = axx;
                        return (Continuation)var3;
                     }

                     @Nullable
                     public final Object invoke_WpGqRn0/* $FF was: invoke-WpGqRn0*/(@NotNull Object axx, @Nullable Continuation<? super Unit> axxx) {
                        return ((<undefinedtype>)ax.create(ChannelResult.box-impl(axx), axxx)).invokeSuspend(Unit.INSTANCE);
                     }
                  }));
               } catch (Throwable var16) {
                  axxxxxxxxxxx.handleBuilderException(var16);
               }

               var21 = axxxxxxxxxxx.getResult();
               if (var21 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
                  DebugProbesKt.probeCoroutineSuspended((Continuation)ax);
               }
            } while(var21 != var14);

            return var14;
         }

         @Nullable
         public final Object invoke(@NotNull CoroutineScope axxx, @NotNull FlowCollector<? super T> axxxx, @Nullable Continuation<? super Unit> axx) {
            Function3 var4 = new <anonymous constructor>(axx);
            var4.L$0 = axxx;
            var4.L$1 = axxxx;
            return var4.invokeSuspend(Unit.INSTANCE);
         }
      }));
   }

   @FlowPreview
   @NotNull
   public static final <T> Flow<T> sample(@NotNull final Flow<? extends T> a, final long a) {
      if (a <= 0L) {
         int a = false;
         String var4 = "Sample period should be positive";
         throw new IllegalArgumentException(var4.toString());
      } else {
         return FlowCoroutineKt.scopedFlow((Function3)(new Function3<CoroutineScope, FlowCollector<? super T>, Continuation<? super Unit>, Object>((Continuation)null) {
            Object L$2;
            Object L$3;
            int label;
            // $FF: synthetic field
            private Object L$0;
            // $FF: synthetic field
            Object L$1;

            @Nullable
            public final Object invokeSuspend(@NotNull Object axxx) {
               Object var14 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
               final FlowCollector axxxxxx;
               ReceiveChannel axxxxxxx;
               final Ref.ObjectRef axxxxxxxx;
               final ReceiveChannel axxxxxxxxx;
               boolean axxxxxxxxxx;
               switch(ax.label) {
               case 0:
                  ResultKt.throwOnFailure(axxx);
                  CoroutineScope axxxxx = (CoroutineScope)ax.L$0;
                  axxxxxx = (FlowCollector)ax.L$1;
                  axxxxxxx = ProduceKt.produce$default(axxxxx, (CoroutineContext)null, -1, (Function2)(new Function2<ProducerScope<? super Object>, Continuation<? super Unit>, Object>((Continuation)null) {
                     int label;
                     // $FF: synthetic field
                     private Object L$0;

                     @Nullable
                     public final Object invokeSuspend(@NotNull Object axx) {
                        Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch(ax.label) {
                        case 0:
                           ResultKt.throwOnFailure(axx);
                           final ProducerScope axxx = (ProducerScope)ax.L$0;
                           Flow var10000 = a;
                           FlowCollector var10001 = (FlowCollector)(new FlowCollector() {
                              @Nullable
                              public final Object emit(T axx, @NotNull Continuation<? super Unit> var2) {
                                 Object axxxxx;
                                 label24: {
                                    if (var2 instanceof <undefinedtype>) {
                                       axxxxx = (<undefinedtype>)var2;
                                       if ((((<undefinedtype>)axxxxx).label & Integer.MIN_VALUE) != 0) {
                                          ((<undefinedtype>)axxxxx).label -= Integer.MIN_VALUE;
                                          break label24;
                                       }
                                    }

                                    axxxxx = new ContinuationImpl(var2) {
                                       // $FF: synthetic field
                                       Object result;
                                       int label;

                                       @Nullable
                                       public final Object invokeSuspend(@NotNull Object axxxx) {
                                          axx.result = axxxx;
                                          axx.label |= Integer.MIN_VALUE;
                                          return ax.emit((Object)null, (Continuation)axx);
                                       }
                                    };
                                 }

                                 Object axxxx = ((<undefinedtype>)axxxxx).result;
                                 Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                 switch(((<undefinedtype>)axxxxx).label) {
                                 case 0:
                                    ResultKt.throwOnFailure(axxxx);
                                    ProducerScope var10000 = axxx;
                                    Object var10001 = axx;
                                    if (axx == null) {
                                       var10001 = NullSurrogateKt.NULL;
                                    }

                                    ((<undefinedtype>)axxxxx).label = 1;
                                    if (var10000.send(var10001, (Continuation)axxxxx) == var5) {
                                       return var5;
                                    }
                                    break;
                                 case 1:
                                    ResultKt.throwOnFailure(axxxx);
                                    break;
                                 default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                 }

                                 return Unit.INSTANCE;
                              }
                           });
                           Continuation var10002 = (Continuation)ax;
                           ax.label = 1;
                           if (var10000.collect(var10001, var10002) == var3) {
                              return var3;
                           }
                           break;
                        case 1:
                           ResultKt.throwOnFailure(axx);
                           break;
                        default:
                           throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }

                        return Unit.INSTANCE;
                     }

                     @NotNull
                     public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
                        Function2 var3 = new <anonymous constructor>(axxx);
                        var3.L$0 = axx;
                        return (Continuation)var3;
                     }

                     @Nullable
                     public final Object invoke(@NotNull ProducerScope<Object> axx, @Nullable Continuation<? super Unit> axxx) {
                        return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
                     }
                  }), 1, (Object)null);
                  axxxxxxxx = new Ref.ObjectRef();
                  axxxxxxxxx = FlowKt.fixedPeriodTicker$default(axxxxx, a, 0L, 2, (Object)null);
                  break;
               case 1:
                  axxxxxxxxxx = false;
                  axxxxxxxxx = (ReceiveChannel)ax.L$3;
                  axxxxxxxx = (Ref.ObjectRef)ax.L$2;
                  axxxxxxx = (ReceiveChannel)ax.L$1;
                  axxxxxx = (FlowCollector)ax.L$0;
                  ResultKt.throwOnFailure(axxx);
                  break;
               default:
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
               }

               Object var10000;
               do {
                  if (axxxxxxxx.element == NullSurrogateKt.DONE) {
                     return Unit.INSTANCE;
                  }

                  axxxxxxxxxx = false;
                  ax.L$0 = axxxxxx;
                  ax.L$1 = axxxxxxx;
                  ax.L$2 = axxxxxxxx;
                  ax.L$3 = axxxxxxxxx;
                  ax.label = 1;
                  Continuation axxxxxxxxxxx = (Continuation)ax;
                  int axxxxxxxxxxxx = false;
                  SelectBuilderImpl axxxxxxxxxxxxx = new SelectBuilderImpl(axxxxxxxxxxx);

                  try {
                     SelectBuilder axx = (SelectBuilder)axxxxxxxxxxxxx;
                     int axxxx = false;
                     axx.invoke(axxxxxxx.getOnReceiveCatching(), (Function2)(new Function2<ChannelResult<? extends Object>, Continuation<? super Unit>, Object>((Continuation)null) {
                        int label;
                        // $FF: synthetic field
                        Object L$0;

                        @Nullable
                        public final Object invokeSuspend(@NotNull Object var1) {
                           IntrinsicsKt.getCOROUTINE_SUSPENDED();
                           switch(ax.label) {
                           case 0:
                              ResultKt.throwOnFailure(var1);
                              Object axx = ((ChannelResult)ax.L$0).unbox-impl();
                              Ref.ObjectRef var4 = axxxxxxxx;
                              int axxxx = false;
                              if (!(axx instanceof ChannelResult.Failed)) {
                                 int axxxxxx = false;
                                 var4.element = axx;
                              }

                              ReceiveChannel var11 = axxxxxxxxx;
                              Ref.ObjectRef var12 = axxxxxxxx;
                              int axxxxx = false;
                              if (axx instanceof ChannelResult.Failed) {
                                 Throwable axxx = ChannelResult.exceptionOrNull-impl(axx);
                                 int axxxxxxx = false;
                                 if (axxx != null) {
                                    int axxxxxxxxxx = false;
                                    throw axxx;
                                 }

                                 var11.cancel((CancellationException)(new ChildCancelledException()));
                                 var12.element = NullSurrogateKt.DONE;
                              }

                              return Unit.INSTANCE;
                           default:
                              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                           }
                        }

                        @NotNull
                        public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
                           Function2 var3 = new <anonymous constructor>(axxx);
                           var3.L$0 = axx;
                           return (Continuation)var3;
                        }

                        @Nullable
                        public final Object invoke_WpGqRn0/* $FF was: invoke-WpGqRn0*/(@NotNull Object axx, @Nullable Continuation<? super Unit> axxx) {
                           return ((<undefinedtype>)ax.create(ChannelResult.box-impl(axx), axxx)).invokeSuspend(Unit.INSTANCE);
                        }
                     }));
                     axx.invoke(axxxxxxxxx.getOnReceive(), (Function2)(new Function2<Unit, Continuation<? super Unit>, Object>((Continuation)null) {
                        int label;

                        @Nullable
                        public final Object invokeSuspend(@NotNull Object axx) {
                           Object var5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                           switch(ax.label) {
                           case 0:
                              ResultKt.throwOnFailure(axx);
                              Object var10000 = axxxxxxxx.element;
                              if (var10000 == null) {
                                 return Unit.INSTANCE;
                              }

                              Object axxx = var10000;
                              axxxxxxxx.element = null;
                              FlowCollector var6 = axxxxxx;
                              Symbol axxxx = NullSurrogateKt.NULL;
                              int axxxxx = false;
                              Object var10001 = axxx == axxxx ? null : axxx;
                              Continuation var10002 = (Continuation)ax;
                              ax.label = 1;
                              if (var6.emit(var10001, var10002) == var5) {
                                 return var5;
                              }
                              break;
                           case 1:
                              ResultKt.throwOnFailure(axx);
                              break;
                           default:
                              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                           }

                           return Unit.INSTANCE;
                        }

                        @NotNull
                        public final Continuation<Unit> create(@Nullable Object a1, @NotNull Continuation<?> axx) {
                           return (Continuation)(new <anonymous constructor>(axx));
                        }

                        @Nullable
                        public final Object invoke(@NotNull Unit axx, @Nullable Continuation<? super Unit> axxx) {
                           return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
                        }
                     }));
                  } catch (Throwable var15) {
                     axxxxxxxxxxxxx.handleBuilderException(var15);
                  }

                  var10000 = axxxxxxxxxxxxx.getResult();
                  if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
                     DebugProbesKt.probeCoroutineSuspended((Continuation)ax);
                  }
               } while(var10000 != var14);

               return var14;
            }

            @Nullable
            public final Object invoke(@NotNull CoroutineScope axxx, @NotNull FlowCollector<? super T> axxxx, @Nullable Continuation<? super Unit> axx) {
               Function3 var4 = new <anonymous constructor>(axx);
               var4.L$0 = axxx;
               var4.L$1 = axxxx;
               return var4.invokeSuspend(Unit.INSTANCE);
            }
         }));
      }
   }

   @NotNull
   public static final ReceiveChannel<Unit> fixedPeriodTicker(@NotNull CoroutineScope a, final long a, final long a) {
      boolean a;
      String var6;
      if (a < 0L) {
         a = false;
         var6 = "Expected non-negative delay, but has " + a + " ms";
         throw new IllegalArgumentException(var6.toString());
      } else if (a < 0L) {
         a = false;
         var6 = "Expected non-negative initial delay, but has " + a + " ms";
         throw new IllegalArgumentException(var6.toString());
      } else {
         return ProduceKt.produce$default(a, (CoroutineContext)null, 0, (Function2)(new Function2<ProducerScope<? super Unit>, Continuation<? super Unit>, Object>((Continuation)null) {
            int label;
            // $FF: synthetic field
            private Object L$0;

            @Nullable
            public final Object invokeSuspend(@NotNull Object axx) {
               Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
               long var10000;
               Continuation var10001;
               ProducerScope axxx;
               switch(ax.label) {
               case 0:
                  ResultKt.throwOnFailure(axx);
                  axxx = (ProducerScope)ax.L$0;
                  var10000 = a;
                  var10001 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.label = 1;
                  if (DelayKt.delay(var10000, var10001) == var3) {
                     return var3;
                  }
                  break;
               case 1:
                  axxx = (ProducerScope)ax.L$0;
                  ResultKt.throwOnFailure(axx);
                  break;
               case 2:
                  axxx = (ProducerScope)ax.L$0;
                  ResultKt.throwOnFailure(axx);
                  var10000 = a;
                  var10001 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.label = 3;
                  if (DelayKt.delay(var10000, var10001) == var3) {
                     return var3;
                  }
                  break;
               case 3:
                  axxx = (ProducerScope)ax.L$0;
                  ResultKt.throwOnFailure(axx);
                  break;
               default:
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
               }

               do {
                  SendChannel var4 = axxx.getChannel();
                  Unit var5 = Unit.INSTANCE;
                  Continuation var10002 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.label = 2;
                  if (var4.send(var5, var10002) == var3) {
                     return var3;
                  }

                  var10000 = a;
                  var10001 = (Continuation)ax;
                  ax.L$0 = axxx;
                  ax.label = 3;
               } while(DelayKt.delay(var10000, var10001) != var3);

               return var3;
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
               Function2 var3 = new <anonymous constructor>(axxx);
               var3.L$0 = axx;
               return (Continuation)var3;
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super Unit> axx, @Nullable Continuation<? super Unit> axxx) {
               return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
            }
         }), 1, (Object)null);
      }
   }

   // $FF: synthetic method
   public static ReceiveChannel fixedPeriodTicker$default(CoroutineScope var0, long var1, long var3, int var5, Object var6) {
      if ((var5 & 2) != 0) {
         var3 = var1;
      }

      return FlowKt.fixedPeriodTicker(var0, var1, var3);
   }

   @FlowPreview
   @NotNull
   public static final <T> Flow<T> sample_HG0u8IE/* $FF was: sample-HG0u8IE*/(@NotNull Flow<? extends T> a, long a) {
      return FlowKt.sample(a, DelayKt.toDelayMillis-LRDsOJo(a));
   }
}
