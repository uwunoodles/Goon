package kotlinx.coroutines;

import java.util.concurrent.atomic.AtomicLong;
import kotlin.Metadata;
import kotlin.internal.InlineOnly;
import kotlin.jvm.functions.Function0;
import kotlinx.coroutines.internal.SystemPropsKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000(\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0017\u0010\u0012\u001a\u00020\u00132\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00010\u0015H\u0081\b\u001a\b\u0010\u0016\u001a\u00020\u0013H\u0000\"\u0014\u0010\u0000\u001a\u00020\u0001X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003\"\u0014\u0010\u0004\u001a\u00020\u0005X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0014\u0010\b\u001a\u00020\u0001X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0003\"\u000e\u0010\n\u001a\u00020\u000bX\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\f\u001a\u00020\u000bX\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\r\u001a\u00020\u000bX\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u000e\u001a\u00020\u000bX\u0086T¢\u0006\u0002\n\u0000\"\u0014\u0010\u000f\u001a\u00020\u0001X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0003\"\u000e\u0010\u0011\u001a\u00020\u000bX\u0080T¢\u0006\u0002\n\u0000¨\u0006\u0017"},
   d2 = {"ASSERTIONS_ENABLED", "", "getASSERTIONS_ENABLED", "()Z", "COROUTINE_ID", "Ljava/util/concurrent/atomic/AtomicLong;", "getCOROUTINE_ID", "()Ljava/util/concurrent/atomic/AtomicLong;", "DEBUG", "getDEBUG", "DEBUG_PROPERTY_NAME", "", "DEBUG_PROPERTY_VALUE_AUTO", "DEBUG_PROPERTY_VALUE_OFF", "DEBUG_PROPERTY_VALUE_ON", "RECOVER_STACK_TRACES", "getRECOVER_STACK_TRACES", "STACKTRACE_RECOVERY_PROPERTY_NAME", "assert", "", "value", "Lkotlin/Function0;", "resetCoroutineId", "kotlinx-coroutines-core"}
)
public final class DebugKt {
   @NotNull
   public static final String DEBUG_PROPERTY_NAME = "kotlinx.coroutines.debug";
   @NotNull
   public static final String STACKTRACE_RECOVERY_PROPERTY_NAME = "kotlinx.coroutines.stacktrace.recovery";
   @NotNull
   public static final String DEBUG_PROPERTY_VALUE_AUTO = "auto";
   @NotNull
   public static final String DEBUG_PROPERTY_VALUE_ON = "on";
   @NotNull
   public static final String DEBUG_PROPERTY_VALUE_OFF = "off";
   private static final boolean ASSERTIONS_ENABLED;
   private static final boolean DEBUG;
   private static final boolean RECOVER_STACK_TRACES;
   @NotNull
   private static final AtomicLong COROUTINE_ID;

   public static final boolean getASSERTIONS_ENABLED() {
      return ASSERTIONS_ENABLED;
   }

   public static final boolean getDEBUG() {
      return DEBUG;
   }

   public static final boolean getRECOVER_STACK_TRACES() {
      return RECOVER_STACK_TRACES;
   }

   @NotNull
   public static final AtomicLong getCOROUTINE_ID() {
      return COROUTINE_ID;
   }

   public static final void resetCoroutineId() {
      COROUTINE_ID.set(0L);
   }

   @InlineOnly
   private static final void assert(Function0<Boolean> a) {
      if (getASSERTIONS_ENABLED() && !(Boolean)a.invoke()) {
         throw new AssertionError();
      }
   }

   static {
      boolean var10000;
      label42: {
         String a;
         label47: {
            ASSERTIONS_ENABLED = CoroutineId.class.desiredAssertionStatus();
            a = SystemPropsKt.systemProp("kotlinx.coroutines.debug");
            int a = false;
            if (a != null) {
               label46: {
                  switch(a.hashCode()) {
                  case 0:
                     if (!a.equals("")) {
                        break label47;
                     }
                     break;
                  case 3551:
                     if (!a.equals("on")) {
                        break label47;
                     }
                     break;
                  case 109935:
                     if (a.equals("off")) {
                        var10000 = false;
                        break label42;
                     }
                     break label47;
                  case 3005871:
                     if (!a.equals("auto")) {
                        break label47;
                     }
                     break label46;
                  default:
                     break label47;
                  }

                  var10000 = true;
                  break label42;
               }
            }

            var10000 = ASSERTIONS_ENABLED;
            break label42;
         }

         throw new IllegalStateException(("System property 'kotlinx.coroutines.debug' has unrecognized value '" + a + '\'').toString());
      }

      DEBUG = var10000;
      RECOVER_STACK_TRACES = DEBUG && SystemPropsKt.systemProp("kotlinx.coroutines.stacktrace.recovery", true);
      COROUTINE_ID = new AtomicLong(0L);
   }
}
