package kotlinx.coroutines;

import java.util.concurrent.CancellationException;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.CoroutineStackFrame;
import kotlin.jvm.JvmField;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.internal.DispatchedContinuation;
import kotlinx.coroutines.internal.StackTraceRecoveryKt;
import kotlinx.coroutines.internal.ThreadContextKt;
import kotlinx.coroutines.scheduling.Task;
import kotlinx.coroutines.scheduling.TaskContext;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u000e\b \u0018\u0000*\u0006\b\u0000\u0010\u0001 \u00002\u00060\u0002j\u0002`\u0003B\r\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u001f\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0010¢\u0006\u0002\b\u0011J\u0019\u0010\u0012\u001a\u0004\u0018\u00010\u00102\b\u0010\u0013\u001a\u0004\u0018\u00010\u000eH\u0010¢\u0006\u0002\b\u0014J\u001f\u0010\u0015\u001a\u0002H\u0001\"\u0004\b\u0001\u0010\u00012\b\u0010\u0013\u001a\u0004\u0018\u00010\u000eH\u0010¢\u0006\u0004\b\u0016\u0010\u0017J\u001a\u0010\u0018\u001a\u00020\f2\b\u0010\u0019\u001a\u0004\u0018\u00010\u00102\b\u0010\u001a\u001a\u0004\u0018\u00010\u0010J\u0006\u0010\u001b\u001a\u00020\fJ\u000f\u0010\u001c\u001a\u0004\u0018\u00010\u000eH ¢\u0006\u0002\b\u001dR\u0018\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\bX \u0004¢\u0006\u0006\u001a\u0004\b\t\u0010\nR\u0012\u0010\u0004\u001a\u00020\u00058\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000¨\u0006\u001e"},
   d2 = {"Lkotlinx/coroutines/DispatchedTask;", "T", "Lkotlinx/coroutines/scheduling/Task;", "Lkotlinx/coroutines/SchedulerTask;", "resumeMode", "", "(I)V", "delegate", "Lkotlin/coroutines/Continuation;", "getDelegate$kotlinx_coroutines_core", "()Lkotlin/coroutines/Continuation;", "cancelCompletedResult", "", "takenState", "", "cause", "", "cancelCompletedResult$kotlinx_coroutines_core", "getExceptionalResult", "state", "getExceptionalResult$kotlinx_coroutines_core", "getSuccessfulResult", "getSuccessfulResult$kotlinx_coroutines_core", "(Ljava/lang/Object;)Ljava/lang/Object;", "handleFatalException", "exception", "finallyException", "run", "takeState", "takeState$kotlinx_coroutines_core", "kotlinx-coroutines-core"}
)
public abstract class DispatchedTask<T> extends Task {
   @JvmField
   public int resumeMode;

   public DispatchedTask(int a) {
      a.resumeMode = a;
   }

   @NotNull
   public abstract Continuation<T> getDelegate$kotlinx_coroutines_core();

   @Nullable
   public abstract Object takeState$kotlinx_coroutines_core();

   public void cancelCompletedResult$kotlinx_coroutines_core(@Nullable Object a1, @NotNull Throwable a2) {
   }

   public <T> T getSuccessfulResult$kotlinx_coroutines_core(@Nullable Object a) {
      return a;
   }

   @Nullable
   public Throwable getExceptionalResult$kotlinx_coroutines_core(@Nullable Object a) {
      return (a instanceof CompletedExceptionally ? (CompletedExceptionally)a : null) != null ? (a instanceof CompletedExceptionally ? (CompletedExceptionally)a : null).cause : null;
   }

   public final void run() {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a.resumeMode == -1) {
            throw new AssertionError();
         }
      }

      TaskContext a = a.taskContext;
      Throwable a = null;
      boolean var25 = false;

      Object a;
      boolean a;
      Result.Companion var10000;
      label355: {
         try {
            var25 = true;
            DispatchedContinuation a = (DispatchedContinuation)a.getDelegate$kotlinx_coroutines_core();
            Continuation a = a.continuation;
            a = a.countOrElement;
            a = false;
            CoroutineContext a = a.getContext();
            Object a = ThreadContextKt.updateThreadContext(a, a);
            UndispatchedCoroutine a = a != ThreadContextKt.NO_THREAD_ELEMENTS ? CoroutineContextKt.updateUndispatchedCompletion(a, a, a) : (UndispatchedCoroutine)null;

            try {
               int a = false;
               CoroutineContext a = a.getContext();
               Object a = a.takeState$kotlinx_coroutines_core();
               Throwable a = a.getExceptionalResult$kotlinx_coroutines_core(a);
               Job a = a == null && DispatchedTaskKt.isCancellableMode(a.resumeMode) ? (Job)a.get((CoroutineContext.Key)Job.Key) : null;
               Result.Companion var10001;
               if (a != null && !a.isActive()) {
                  CancellationException a = a.getCancellationException();
                  a.cancelCompletedResult$kotlinx_coroutines_core(a, (Throwable)a);
                  int a = false;
                  var10001 = Result.Companion;
                  int a = false;
                  a.resumeWith(Result.constructor-impl(ResultKt.createFailure(DebugKt.getRECOVER_STACK_TRACES() && a instanceof CoroutineStackFrame ? StackTraceRecoveryKt.access$recoverFromStackFrame((Throwable)a, (CoroutineStackFrame)a) : (Throwable)a)));
               } else if (a != null) {
                  var10001 = Result.Companion;
                  a.resumeWith(Result.constructor-impl(ResultKt.createFailure(a)));
               } else {
                  var10001 = Result.Companion;
                  a.resumeWith(Result.constructor-impl(a.getSuccessfulResult$kotlinx_coroutines_core(a)));
               }

               Unit var43 = Unit.INSTANCE;
            } finally {
               if (a == null || a.clearThreadContext()) {
                  ThreadContextKt.restoreThreadContext(a, a);
               }

            }

            var25 = false;
            break label355;
         } catch (Throwable var36) {
            a = var36;
            var25 = false;
         } finally {
            if (var25) {
               Object var40;
               try {
                  var10000 = Result.Companion;
                  int a = false;
                  a.afterTask();
                  var40 = Result.constructor-impl(Unit.INSTANCE);
               } catch (Throwable var32) {
                  var10000 = Result.Companion;
                  var40 = Result.constructor-impl(ResultKt.createFailure(var32));
               }

               a.handleFatalException(a, Result.exceptionOrNull-impl(var40));
            }
         }

         try {
            var10000 = Result.Companion;
            a = false;
            a.afterTask();
            a = Result.constructor-impl(Unit.INSTANCE);
         } catch (Throwable var33) {
            var10000 = Result.Companion;
            a = Result.constructor-impl(ResultKt.createFailure(var33));
         }

         a.handleFatalException(a, Result.exceptionOrNull-impl(a));
         return;
      }

      DispatchedTask var39 = a;

      try {
         var10000 = Result.Companion;
         DispatchedTask a = (DispatchedTask)var39;
         a = false;
         a.afterTask();
         a = Result.constructor-impl(Unit.INSTANCE);
      } catch (Throwable var34) {
         var10000 = Result.Companion;
         a = Result.constructor-impl(ResultKt.createFailure(var34));
      }

      a.handleFatalException(a, Result.exceptionOrNull-impl(a));
   }

   public final void handleFatalException(@Nullable Throwable a, @Nullable Throwable a) {
      if (a != null || a != null) {
         if (a != null && a != null) {
            int a = false;
            kotlin.ExceptionsKt.addSuppressed(a, a);
         }

         Throwable var10000 = a;
         if (a == null) {
            var10000 = a;
         }

         Throwable a = var10000;
         String var10002 = "Fatal exception in coroutines machinery for " + a + ". Please read KDoc to 'handleFatalException' method and report this incident to maintainers";
         Intrinsics.checkNotNull(a);
         CoroutinesInternalError a = new CoroutinesInternalError(var10002, a);
         CoroutineExceptionHandlerKt.handleCoroutineException(a.getDelegate$kotlinx_coroutines_core().getContext(), (Throwable)a);
      }
   }
}
