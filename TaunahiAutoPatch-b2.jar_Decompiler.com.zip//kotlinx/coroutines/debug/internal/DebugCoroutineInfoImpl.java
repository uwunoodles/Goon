package kotlinx.coroutines.debug.internal;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.CoroutineStackFrame;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.sequences.SequenceScope;
import kotlin.sequences.SequencesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0000\u0018\u00002\u00020\u0001B!\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\u000e\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00150\u0014H\u0002J\f\u0010#\u001a\b\u0012\u0004\u0012\u00020\u00150\u0014J\b\u0010$\u001a\u00020\u000eH\u0016J!\u0010%\u001a\u00020&2\u0006\u0010 \u001a\u00020\u000e2\n\u0010'\u001a\u0006\u0012\u0002\b\u00030(H\u0000¢\u0006\u0002\b)J%\u0010*\u001a\u00020&*\b\u0012\u0004\u0012\u00020\u00150+2\b\u0010'\u001a\u0004\u0018\u00010\fH\u0082Pø\u0001\u0000¢\u0006\u0002\u0010,R\u0016\u0010\t\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00030\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u00038F¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0017\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00150\u00148F¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0017R(\u0010\u0019\u001a\u0004\u0018\u00010\f2\b\u0010\u0018\u001a\u0004\u0018\u00010\f8@@@X\u0080\u000e¢\u0006\f\u001a\u0004\b\u001a\u0010\u001b\"\u0004\b\u001c\u0010\u001dR\u0014\u0010\u001e\u001a\u0004\u0018\u00010\u001f8\u0000@\u0000X\u0081\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u00020\u00078\u0000X\u0081\u0004¢\u0006\u0002\n\u0000R\u0011\u0010 \u001a\u00020\u000e8F¢\u0006\u0006\u001a\u0004\b!\u0010\"\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006-"},
   d2 = {"Lkotlinx/coroutines/debug/internal/DebugCoroutineInfoImpl;", "", "context", "Lkotlin/coroutines/CoroutineContext;", "creationStackBottom", "Lkotlinx/coroutines/debug/internal/StackTraceFrame;", "sequenceNumber", "", "(Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/debug/internal/StackTraceFrame;J)V", "_context", "Ljava/lang/ref/WeakReference;", "_lastObservedFrame", "Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;", "_state", "", "getContext", "()Lkotlin/coroutines/CoroutineContext;", "getCreationStackBottom", "()Lkotlinx/coroutines/debug/internal/StackTraceFrame;", "creationStackTrace", "", "Ljava/lang/StackTraceElement;", "getCreationStackTrace", "()Ljava/util/List;", "value", "lastObservedFrame", "getLastObservedFrame$kotlinx_coroutines_core", "()Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;", "setLastObservedFrame$kotlinx_coroutines_core", "(Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;)V", "lastObservedThread", "Ljava/lang/Thread;", "state", "getState", "()Ljava/lang/String;", "lastObservedStackTrace", "toString", "updateState", "", "frame", "Lkotlin/coroutines/Continuation;", "updateState$kotlinx_coroutines_core", "yieldFrames", "Lkotlin/sequences/SequenceScope;", "(Lkotlin/sequences/SequenceScope;Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public final class DebugCoroutineInfoImpl {
   @Nullable
   private final StackTraceFrame creationStackBottom;
   @JvmField
   public final long sequenceNumber;
   @NotNull
   private final WeakReference<CoroutineContext> _context;
   @NotNull
   private String _state;
   @JvmField
   @Nullable
   public Thread lastObservedThread;
   @Nullable
   private WeakReference<CoroutineStackFrame> _lastObservedFrame;

   public DebugCoroutineInfoImpl(@Nullable CoroutineContext a, @Nullable StackTraceFrame a, long a) {
      a.creationStackBottom = a;
      a.sequenceNumber = a;
      a._context = new WeakReference(a);
      a._state = "CREATED";
   }

   @Nullable
   public final StackTraceFrame getCreationStackBottom() {
      return a.creationStackBottom;
   }

   @Nullable
   public final CoroutineContext getContext() {
      return (CoroutineContext)a._context.get();
   }

   @NotNull
   public final List<StackTraceElement> getCreationStackTrace() {
      return a.creationStackTrace();
   }

   @NotNull
   public final String getState() {
      return a._state;
   }

   @Nullable
   public final CoroutineStackFrame getLastObservedFrame$kotlinx_coroutines_core() {
      WeakReference var10000 = a._lastObservedFrame;
      return var10000 != null ? (CoroutineStackFrame)var10000.get() : null;
   }

   public final void setLastObservedFrame$kotlinx_coroutines_core(@Nullable CoroutineStackFrame a) {
      DebugCoroutineInfoImpl var10000 = a;
      WeakReference var10001;
      if (a != null) {
         int a = false;
         var10001 = new WeakReference(a);
         var10000 = a;
      } else {
         var10001 = null;
      }

      var10000._lastObservedFrame = var10001;
   }

   @NotNull
   public final List<StackTraceElement> lastObservedStackTrace() {
      CoroutineStackFrame var10000 = a.getLastObservedFrame$kotlinx_coroutines_core();
      if (var10000 == null) {
         return CollectionsKt.emptyList();
      } else {
         CoroutineStackFrame a = var10000;

         ArrayList a;
         for(a = new ArrayList(); a != null; a = a.getCallerFrame()) {
            StackTraceElement var5 = a.getStackTraceElement();
            if (var5 != null) {
               StackTraceElement a = var5;
               int a = false;
               a.add(a);
            }
         }

         return (List)a;
      }
   }

   private final List<StackTraceElement> creationStackTrace() {
      StackTraceFrame var10000 = a.creationStackBottom;
      if (var10000 == null) {
         return CollectionsKt.emptyList();
      } else {
         final StackTraceFrame a = var10000;
         return SequencesKt.toList(SequencesKt.sequence((Function2)(new Function2<SequenceScope<? super StackTraceElement>, Continuation<? super Unit>, Object>((Continuation)null) {
            int label;
            // $FF: synthetic field
            private Object L$0;

            @Nullable
            public final Object invokeSuspend(@NotNull Object axx) {
               Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
               switch(ax.label) {
               case 0:
                  ResultKt.throwOnFailure(axx);
                  SequenceScope axxx = (SequenceScope)ax.L$0;
                  DebugCoroutineInfoImpl var10000 = a;
                  CoroutineStackFrame var10002 = a.getCallerFrame();
                  Continuation var10003 = (Continuation)ax;
                  ax.label = 1;
                  if (var10000.yieldFrames(axxx, var10002, var10003) == var3) {
                     return var3;
                  }
                  break;
               case 1:
                  ResultKt.throwOnFailure(axx);
                  break;
               default:
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
               }

               return Unit.INSTANCE;
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
               Function2 var3 = new <anonymous constructor>(axxx);
               var3.L$0 = axx;
               return (Continuation)var3;
            }

            @Nullable
            public final Object invoke(@NotNull SequenceScope<? super StackTraceElement> axx, @Nullable Continuation<? super Unit> axxx) {
               return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
            }
         })));
      }
   }

   private final Object yieldFrames(SequenceScope<? super StackTraceElement> a, CoroutineStackFrame a, Continuation<? super Unit> var3) {
      Object a;
      label53: {
         if (var3 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var3;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label53;
            }
         }

         a = new ContinuationImpl(var3) {
            Object L$0;
            Object L$1;
            Object L$2;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object axx) {
               ax.result = axx;
               ax.label |= Integer.MIN_VALUE;
               return a.yieldFrames((SequenceScope)null, (CoroutineStackFrame)null, (Continuation)ax);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var15 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      DebugCoroutineInfoImpl var4;
      SequenceScope var5;
      CoroutineStackFrame var6;
      CoroutineStackFrame a;
      boolean a;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         var4 = a;
         var5 = a;
         var6 = a;
         break;
      case 1:
         a = false;
         CoroutineStackFrame var9 = (CoroutineStackFrame)((<undefinedtype>)a).L$2;
         SequenceScope var8 = (SequenceScope)((<undefinedtype>)a).L$1;
         DebugCoroutineInfoImpl var7 = (DebugCoroutineInfoImpl)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         a = var9.getCallerFrame();
         if (a == null) {
            return Unit.INSTANCE;
         }

         var4 = var7;
         var5 = var8;
         var6 = a;
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      while(var6 != null) {
         StackTraceElement var10000 = var6.getStackTraceElement();
         if (var10000 != null) {
            StackTraceElement a = var10000;
            a = false;
            ((<undefinedtype>)a).L$0 = var4;
            ((<undefinedtype>)a).L$1 = var5;
            ((<undefinedtype>)a).L$2 = var6;
            ((<undefinedtype>)a).label = 1;
            if (var5.yield(a, (Continuation)a) == var15) {
               return var15;
            }
         }

         a = var6.getCallerFrame();
         if (a == null) {
            return Unit.INSTANCE;
         }

         var4 = var4;
         var5 = var5;
         var6 = a;
      }

      return Unit.INSTANCE;
   }

   public final void updateState$kotlinx_coroutines_core(@NotNull String a, @NotNull Continuation<?> a) {
      if (!Intrinsics.areEqual((Object)a._state, (Object)a) || !Intrinsics.areEqual((Object)a, (Object)"SUSPENDED") || a.getLastObservedFrame$kotlinx_coroutines_core() == null) {
         a._state = a;
         a.setLastObservedFrame$kotlinx_coroutines_core(a instanceof CoroutineStackFrame ? (CoroutineStackFrame)a : null);
         a.lastObservedThread = Intrinsics.areEqual((Object)a, (Object)"RUNNING") ? Thread.currentThread() : (Thread)null;
      }
   }

   @NotNull
   public String toString() {
      return "DebugCoroutineInfo(state=" + a.getState() + ",context=" + a.getContext() + ')';
   }
}
