package kotlinx.coroutines.debug.internal;

import java.io.Serializable;
import java.lang.Thread.State;
import java.util.List;
import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.coroutines.ContinuationInterceptor;
import kotlin.coroutines.CoroutineContext;
import kotlinx.coroutines.CoroutineId;
import kotlinx.coroutines.CoroutineName;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u000e\b\u0001\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006R\u0015\u0010\u0007\u001a\u0004\u0018\u00010\b¢\u0006\n\n\u0002\u0010\u000b\u001a\u0004\b\t\u0010\nR\u0013\u0010\f\u001a\u0004\u0018\u00010\r¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0017\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0013\u0010\u0015\u001a\u0004\u0018\u00010\r¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u000fR\u0013\u0010\u0017\u001a\u0004\u0018\u00010\r¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u000fR\u0013\u0010\u0019\u001a\u0004\u0018\u00010\r¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u000fR\u0011\u0010\u001b\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0011\u0010\u001e\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u000f¨\u0006 "},
   d2 = {"Lkotlinx/coroutines/debug/internal/DebuggerInfo;", "Ljava/io/Serializable;", "source", "Lkotlinx/coroutines/debug/internal/DebugCoroutineInfoImpl;", "context", "Lkotlin/coroutines/CoroutineContext;", "(Lkotlinx/coroutines/debug/internal/DebugCoroutineInfoImpl;Lkotlin/coroutines/CoroutineContext;)V", "coroutineId", "", "getCoroutineId", "()Ljava/lang/Long;", "Ljava/lang/Long;", "dispatcher", "", "getDispatcher", "()Ljava/lang/String;", "lastObservedStackTrace", "", "Ljava/lang/StackTraceElement;", "getLastObservedStackTrace", "()Ljava/util/List;", "lastObservedThreadName", "getLastObservedThreadName", "lastObservedThreadState", "getLastObservedThreadState", "name", "getName", "sequenceNumber", "getSequenceNumber", "()J", "state", "getState", "kotlinx-coroutines-core"}
)
@PublishedApi
public final class DebuggerInfo implements Serializable {
   @Nullable
   private final Long coroutineId;
   @Nullable
   private final String dispatcher;
   @Nullable
   private final String name;
   @NotNull
   private final String state;
   @Nullable
   private final String lastObservedThreadState;
   @Nullable
   private final String lastObservedThreadName;
   @NotNull
   private final List<StackTraceElement> lastObservedStackTrace;
   private final long sequenceNumber;

   public DebuggerInfo(@NotNull DebugCoroutineInfoImpl a, @NotNull CoroutineContext a) {
      Thread var5;
      String var7;
      label31: {
         super();
         CoroutineId var10001 = (CoroutineId)a.get((CoroutineContext.Key)CoroutineId.Key);
         a.coroutineId = var10001 != null ? var10001.getId() : null;
         ContinuationInterceptor var3 = (ContinuationInterceptor)a.get((CoroutineContext.Key)ContinuationInterceptor.Key);
         a.dispatcher = var3 != null ? var3.toString() : null;
         CoroutineName var4 = (CoroutineName)a.get((CoroutineContext.Key)CoroutineName.Key);
         a.name = var4 != null ? var4.getName() : null;
         a.state = a.getState();
         var5 = a.lastObservedThread;
         if (var5 != null) {
            State var6 = var5.getState();
            if (var6 != null) {
               var7 = var6.toString();
               break label31;
            }
         }

         var7 = null;
      }

      a.lastObservedThreadState = var7;
      var5 = a.lastObservedThread;
      a.lastObservedThreadName = var5 != null ? var5.getName() : null;
      a.lastObservedStackTrace = a.lastObservedStackTrace();
      a.sequenceNumber = a.sequenceNumber;
   }

   @Nullable
   public final Long getCoroutineId() {
      return a.coroutineId;
   }

   @Nullable
   public final String getDispatcher() {
      return a.dispatcher;
   }

   @Nullable
   public final String getName() {
      return a.name;
   }

   @NotNull
   public final String getState() {
      return a.state;
   }

   @Nullable
   public final String getLastObservedThreadState() {
      return a.lastObservedThreadState;
   }

   @Nullable
   public final String getLastObservedThreadName() {
      return a.lastObservedThreadName;
   }

   @NotNull
   public final List<StackTraceElement> getLastObservedStackTrace() {
      return a.lastObservedStackTrace;
   }

   public final long getSequenceNumber() {
      return a.sequenceNumber;
   }
}
