package kotlinx.coroutines.debug.internal;

import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.concurrent.ThreadsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.CoroutineStackFrame;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.TypeIntrinsics;
import kotlin.ranges.RangesKt;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.StringsKt;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlinx.coroutines.CoroutineId;
import kotlinx.coroutines.CoroutineName;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.JobKt;
import kotlinx.coroutines.JobSupport;
import kotlinx.coroutines.internal.ScopeCoroutine;
import kotlinx.coroutines.internal.StackTraceRecoveryKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000Ö\u0001\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0010\u0003\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\"\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u001b\bÀ\u0002\u0018\u00002\u00020\u0014:\u0002\u0095\u0001B\t\b\u0002¢\u0006\u0004\b\u0001\u0010\u0002J3\u0010\b\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004\"\u0004\b\u0000\u0010\u00032\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u00042\b\u0010\u0007\u001a\u0004\u0018\u00010\u0006H\u0002¢\u0006\u0004\b\b\u0010\tJ\u0015\u0010\r\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\r\u0010\u000eJ\u0013\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00100\u000f¢\u0006\u0004\b\u0011\u0010\u0012J\u0013\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00140\u0013¢\u0006\u0004\b\u0015\u0010\u0016J@\u0010\u001c\u001a\b\u0012\u0004\u0012\u00028\u00000\u000f\"\b\b\u0000\u0010\u0017*\u00020\u00142\u001e\b\u0004\u0010\u001b\u001a\u0018\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0019\u0012\u0004\u0012\u00020\u001a\u0012\u0004\u0012\u00028\u00000\u0018H\u0082\b¢\u0006\u0004\b\u001c\u0010\u001dJ\u0017\u0010\u001e\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\nH\u0002¢\u0006\u0004\b\u001e\u0010\u000eJ\u0013\u0010 \u001a\b\u0012\u0004\u0012\u00020\u001f0\u000f¢\u0006\u0004\b \u0010\u0012J)\u0010$\u001a\b\u0012\u0004\u0012\u00020\"0\u000f2\u0006\u0010!\u001a\u00020\u00102\f\u0010#\u001a\b\u0012\u0004\u0012\u00020\"0\u000f¢\u0006\u0004\b$\u0010%J\u0015\u0010'\u001a\u00020&2\u0006\u0010!\u001a\u00020\u0010¢\u0006\u0004\b'\u0010(J5\u0010,\u001a\b\u0012\u0004\u0012\u00020\"0\u000f2\u0006\u0010)\u001a\u00020&2\b\u0010+\u001a\u0004\u0018\u00010*2\f\u0010#\u001a\b\u0012\u0004\u0012\u00020\"0\u000fH\u0002¢\u0006\u0004\b,\u0010-J?\u00102\u001a\u000e\u0012\u0004\u0012\u00020.\u0012\u0004\u0012\u00020.012\u0006\u0010/\u001a\u00020.2\f\u00100\u001a\b\u0012\u0004\u0012\u00020\"0\u00132\f\u0010#\u001a\b\u0012\u0004\u0012\u00020\"0\u000fH\u0002¢\u0006\u0004\b2\u00103J3\u00105\u001a\u00020.2\u0006\u00104\u001a\u00020.2\f\u00100\u001a\b\u0012\u0004\u0012\u00020\"0\u00132\f\u0010#\u001a\b\u0012\u0004\u0012\u00020\"0\u000fH\u0002¢\u0006\u0004\b5\u00106J\u001d\u00109\u001a\u0010\u0012\u0004\u0012\u000208\u0012\u0004\u0012\u00020\f\u0018\u000107H\u0002¢\u0006\u0004\b9\u0010:J\u0015\u0010=\u001a\u00020&2\u0006\u0010<\u001a\u00020;¢\u0006\u0004\b=\u0010>J\r\u0010?\u001a\u00020\f¢\u0006\u0004\b?\u0010\u0002J%\u0010A\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\n2\f\u0010@\u001a\b\u0012\u0004\u0012\u00020\"0\u000fH\u0002¢\u0006\u0004\bA\u0010BJ\u001b\u0010D\u001a\u00020\f2\n\u0010C\u001a\u0006\u0012\u0002\b\u00030\u0019H\u0002¢\u0006\u0004\bD\u0010EJ)\u0010H\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004\"\u0004\b\u0000\u0010\u00032\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004H\u0000¢\u0006\u0004\bF\u0010GJ\u001b\u0010K\u001a\u00020\f2\n\u0010\u0007\u001a\u0006\u0012\u0002\b\u00030\u0004H\u0000¢\u0006\u0004\bI\u0010JJ\u001b\u0010M\u001a\u00020\f2\n\u0010\u0007\u001a\u0006\u0012\u0002\b\u00030\u0004H\u0000¢\u0006\u0004\bL\u0010JJ'\u0010P\u001a\b\u0012\u0004\u0012\u00020\"0\u000f\"\b\b\u0000\u0010\u0003*\u00020N2\u0006\u0010O\u001a\u00028\u0000H\u0002¢\u0006\u0004\bP\u0010QJ\u000f\u0010R\u001a\u00020\fH\u0002¢\u0006\u0004\bR\u0010\u0002J\u000f\u0010S\u001a\u00020\fH\u0002¢\u0006\u0004\bS\u0010\u0002J\r\u0010T\u001a\u00020\f¢\u0006\u0004\bT\u0010\u0002J\u001f\u0010V\u001a\u00020\f2\u0006\u0010\u0007\u001a\u00020U2\u0006\u0010)\u001a\u00020&H\u0002¢\u0006\u0004\bV\u0010WJ#\u0010X\u001a\u00020\f2\n\u0010\u0007\u001a\u0006\u0012\u0002\b\u00030\u00042\u0006\u0010)\u001a\u00020&H\u0002¢\u0006\u0004\bX\u0010YJ/\u0010X\u001a\u00020\f2\n\u0010C\u001a\u0006\u0012\u0002\b\u00030\u00192\n\u0010\u0007\u001a\u0006\u0012\u0002\b\u00030\u00042\u0006\u0010)\u001a\u00020&H\u0002¢\u0006\u0004\bX\u0010ZJ;\u0010b\u001a\u00020\f*\u00020;2\u0012\u0010]\u001a\u000e\u0012\u0004\u0012\u00020;\u0012\u0004\u0012\u00020\\0[2\n\u0010`\u001a\u00060^j\u0002`_2\u0006\u0010a\u001a\u00020&H\u0002¢\u0006\u0004\bb\u0010cJ\u0017\u0010d\u001a\u000208*\u0006\u0012\u0002\b\u00030\u0019H\u0002¢\u0006\u0004\bd\u0010eJ\u001d\u0010C\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u0019*\u0006\u0012\u0002\b\u00030\u0004H\u0002¢\u0006\u0004\bC\u0010fJ\u001a\u0010C\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u0019*\u00020UH\u0082\u0010¢\u0006\u0004\bC\u0010gJ\u0016\u0010h\u001a\u0004\u0018\u00010U*\u00020UH\u0082\u0010¢\u0006\u0004\bh\u0010iJ\u001b\u0010j\u001a\u0004\u0018\u00010\u0006*\b\u0012\u0004\u0012\u00020\"0\u000fH\u0002¢\u0006\u0004\bj\u0010kJ\u0013\u0010l\u001a\u00020&*\u00020\u0014H\u0002¢\u0006\u0004\bl\u0010mR\u0014\u0010n\u001a\u00020&8\u0002X\u0082T¢\u0006\u0006\n\u0004\bn\u0010oR \u0010q\u001a\u000e\u0012\u0004\u0012\u00020U\u0012\u0004\u0012\u00020\\0p8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bq\u0010rR\u001e\u0010v\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00190s8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\bt\u0010uR$\u0010w\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0019\u0012\u0004\u0012\u0002080p8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bw\u0010rR\u0014\u0010y\u001a\u00020x8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\by\u0010zR\u0014\u0010|\u001a\u00020{8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b|\u0010}R\"\u0010~\u001a\u0010\u0012\u0004\u0012\u000208\u0012\u0004\u0012\u00020\f\u0018\u0001078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b~\u0010\u007fR)\u0010\u0080\u0001\u001a\u0002088\u0006@\u0006X\u0086\u000e¢\u0006\u0018\n\u0006\b\u0080\u0001\u0010\u0081\u0001\u001a\u0006\b\u0082\u0001\u0010\u0083\u0001\"\u0006\b\u0084\u0001\u0010\u0085\u0001R\u0019\u0010\u0086\u0001\u001a\u00020.8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0086\u0001\u0010\u0087\u0001R\u0017\u0010\u0089\u0001\u001a\u0002088@X\u0080\u0004¢\u0006\b\u001a\u0006\b\u0088\u0001\u0010\u0083\u0001R)\u0010\u008a\u0001\u001a\u0002088\u0006@\u0006X\u0086\u000e¢\u0006\u0018\n\u0006\b\u008a\u0001\u0010\u0081\u0001\u001a\u0006\b\u008b\u0001\u0010\u0083\u0001\"\u0006\b\u008c\u0001\u0010\u0085\u0001R\u001b\u0010\u008d\u0001\u001a\u0004\u0018\u00010*8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u008d\u0001\u0010\u008e\u0001R\"\u0010\u0092\u0001\u001a\u00020&*\u00020;8BX\u0082\u0004¢\u0006\u000f\u0012\u0006\b\u0090\u0001\u0010\u0091\u0001\u001a\u0005\b\u008f\u0001\u0010>R\u001b\u0010\u0093\u0001\u001a\u000208*\u00020\"8BX\u0082\u0004¢\u0006\b\u001a\u0006\b\u0093\u0001\u0010\u0094\u0001¨\u0006\u0096\u0001"},
   d2 = {"Lkotlinx/coroutines/debug/internal/DebugProbesImpl;", "DebugProbesImpl", "()V", "T", "Lkotlin/coroutines/Continuation;", "completion", "Lkotlinx/coroutines/debug/internal/StackTraceFrame;", "frame", "createOwner", "(Lkotlin/coroutines/Continuation;Lkotlinx/coroutines/debug/internal/StackTraceFrame;)Lkotlin/coroutines/Continuation;", "Ljava/io/PrintStream;", "out", "", "dumpCoroutines", "(Ljava/io/PrintStream;)V", "", "Lkotlinx/coroutines/debug/internal/DebugCoroutineInfo;", "dumpCoroutinesInfo", "()Ljava/util/List;", "", "", "dumpCoroutinesInfoAsJsonAndReferences", "()[Ljava/lang/Object;", "R", "Lkotlin/Function2;", "Lkotlinx/coroutines/debug/internal/DebugProbesImpl$CoroutineOwner;", "Lkotlin/coroutines/CoroutineContext;", "create", "dumpCoroutinesInfoImpl", "(Lkotlin/jvm/functions/Function2;)Ljava/util/List;", "dumpCoroutinesSynchronized", "Lkotlinx/coroutines/debug/internal/DebuggerInfo;", "dumpDebuggerInfo", "info", "Ljava/lang/StackTraceElement;", "coroutineTrace", "enhanceStackTraceWithThreadDump", "(Lkotlinx/coroutines/debug/internal/DebugCoroutineInfo;Ljava/util/List;)Ljava/util/List;", "", "enhanceStackTraceWithThreadDumpAsJson", "(Lkotlinx/coroutines/debug/internal/DebugCoroutineInfo;)Ljava/lang/String;", "state", "Ljava/lang/Thread;", "thread", "enhanceStackTraceWithThreadDumpImpl", "(Ljava/lang/String;Ljava/lang/Thread;Ljava/util/List;)Ljava/util/List;", "", "indexOfResumeWith", "actualTrace", "Lkotlin/Pair;", "findContinuationStartIndex", "(I[Ljava/lang/StackTraceElement;Ljava/util/List;)Lkotlin/Pair;", "frameIndex", "findIndexOfFrame", "(I[Ljava/lang/StackTraceElement;Ljava/util/List;)I", "Lkotlin/Function1;", "", "getDynamicAttach", "()Lkotlin/jvm/functions/Function1;", "Lkotlinx/coroutines/Job;", "job", "hierarchyToString", "(Lkotlinx/coroutines/Job;)Ljava/lang/String;", "install", "frames", "printStackTrace", "(Ljava/io/PrintStream;Ljava/util/List;)V", "owner", "probeCoroutineCompleted", "(Lkotlinx/coroutines/debug/internal/DebugProbesImpl$CoroutineOwner;)V", "probeCoroutineCreated$kotlinx_coroutines_core", "(Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;", "probeCoroutineCreated", "probeCoroutineResumed$kotlinx_coroutines_core", "(Lkotlin/coroutines/Continuation;)V", "probeCoroutineResumed", "probeCoroutineSuspended$kotlinx_coroutines_core", "probeCoroutineSuspended", "", "throwable", "sanitizeStackTrace", "(Ljava/lang/Throwable;)Ljava/util/List;", "startWeakRefCleanerThread", "stopWeakRefCleanerThread", "uninstall", "Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;", "updateRunningState", "(Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;Ljava/lang/String;)V", "updateState", "(Lkotlin/coroutines/Continuation;Ljava/lang/String;)V", "(Lkotlinx/coroutines/debug/internal/DebugProbesImpl$CoroutineOwner;Lkotlin/coroutines/Continuation;Ljava/lang/String;)V", "", "Lkotlinx/coroutines/debug/internal/DebugCoroutineInfoImpl;", "map", "Ljava/lang/StringBuilder;", "Lkotlin/text/StringBuilder;", "builder", "indent", "build", "(Lkotlinx/coroutines/Job;Ljava/util/Map;Ljava/lang/StringBuilder;Ljava/lang/String;)V", "isFinished", "(Lkotlinx/coroutines/debug/internal/DebugProbesImpl$CoroutineOwner;)Z", "(Lkotlin/coroutines/Continuation;)Lkotlinx/coroutines/debug/internal/DebugProbesImpl$CoroutineOwner;", "(Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;)Lkotlinx/coroutines/debug/internal/DebugProbesImpl$CoroutineOwner;", "realCaller", "(Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;)Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;", "toStackTraceFrame", "(Ljava/util/List;)Lkotlinx/coroutines/debug/internal/StackTraceFrame;", "toStringWithQuotes", "(Ljava/lang/Object;)Ljava/lang/String;", "ARTIFICIAL_FRAME_MESSAGE", "Ljava/lang/String;", "Lkotlinx/coroutines/debug/internal/ConcurrentWeakMap;", "callerInfoCache", "Lkotlinx/coroutines/debug/internal/ConcurrentWeakMap;", "", "getCapturedCoroutines", "()Ljava/util/Set;", "capturedCoroutines", "capturedCoroutinesMap", "Ljava/util/concurrent/locks/ReentrantReadWriteLock;", "coroutineStateLock", "Ljava/util/concurrent/locks/ReentrantReadWriteLock;", "Ljava/text/SimpleDateFormat;", "dateFormat", "Ljava/text/SimpleDateFormat;", "dynamicAttach", "Lkotlin/jvm/functions/Function1;", "enableCreationStackTraces", "Z", "getEnableCreationStackTraces", "()Z", "setEnableCreationStackTraces", "(Z)V", "installations", "I", "isInstalled$kotlinx_coroutines_core", "isInstalled", "sanitizeStackTraces", "getSanitizeStackTraces", "setSanitizeStackTraces", "weakRefCleanerThread", "Ljava/lang/Thread;", "getDebugString", "getDebugString$annotations", "(Lkotlinx/coroutines/Job;)V", "debugString", "isInternalMethod", "(Ljava/lang/StackTraceElement;)Z", "CoroutineOwner", "kotlinx-coroutines-core"}
)
public final class DebugProbesImpl {
   @NotNull
   public static final DebugProbesImpl INSTANCE = new DebugProbesImpl();
   @NotNull
   private static final String ARTIFICIAL_FRAME_MESSAGE = "Coroutine creation stacktrace";
   @NotNull
   private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
   @Nullable
   private static Thread weakRefCleanerThread;
   @NotNull
   private static final ConcurrentWeakMap<DebugProbesImpl.CoroutineOwner<?>, Boolean> capturedCoroutinesMap = new ConcurrentWeakMap(false, 1, (DefaultConstructorMarker)null);
   private static volatile int installations;
   // $FF: synthetic field
   @NotNull
   private static final DebugProbesImpl$SequenceNumberRefVolatile debugProbesImpl$SequenceNumberRefVolatile = new DebugProbesImpl$SequenceNumberRefVolatile(0L);
   // $FF: synthetic field
   private static final AtomicLongFieldUpdater sequenceNumber$FU;
   @NotNull
   private static final ReentrantReadWriteLock coroutineStateLock = new ReentrantReadWriteLock();
   private static boolean sanitizeStackTraces = true;
   private static boolean enableCreationStackTraces = true;
   @Nullable
   private static final Function1<Boolean, Unit> dynamicAttach;
   @NotNull
   private static final ConcurrentWeakMap<CoroutineStackFrame, DebugCoroutineInfoImpl> callerInfoCache;

   private DebugProbesImpl() {
   }

   private final Set<DebugProbesImpl.CoroutineOwner<?>> getCapturedCoroutines() {
      return capturedCoroutinesMap.keySet();
   }

   public final boolean isInstalled$kotlinx_coroutines_core() {
      return installations > 0;
   }

   public final boolean getSanitizeStackTraces() {
      return sanitizeStackTraces;
   }

   public final void setSanitizeStackTraces(boolean a) {
      sanitizeStackTraces = a;
   }

   public final boolean getEnableCreationStackTraces() {
      return enableCreationStackTraces;
   }

   public final void setEnableCreationStackTraces(boolean a) {
      enableCreationStackTraces = a;
   }

   private final Function1<Boolean, Unit> getDynamicAttach() {
      DebugProbesImpl var1 = a;

      Result.Companion var10000;
      Object var2;
      try {
         var10000 = Result.Companion;
         DebugProbesImpl a = (DebugProbesImpl)var1;
         int a = false;
         Class a = Class.forName("kotlinx.coroutines.debug.internal.ByteBuddyDynamicAttach");
         Constructor a = a.getConstructors()[0];
         Object var8 = a.newInstance();
         if (var8 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Function1<kotlin.Boolean, kotlin.Unit>");
         }

         var2 = Result.constructor-impl((Function1)TypeIntrinsics.beforeCheckcastToFunctionOfArity(var8, 1));
      } catch (Throwable var6) {
         var10000 = Result.Companion;
         var2 = Result.constructor-impl(ResultKt.createFailure(var6));
      }

      return (Function1)(Result.isFailure-impl(var2) ? null : var2);
   }

   public final void install() {
      ReentrantReadWriteLock var1 = coroutineStateLock;
      ReadLock var2 = var1.readLock();
      int var3 = var1.getWriteHoldCount() == 0 ? var1.getReadHoldCount() : 0;

      for(int var4 = 0; var4 < var3; ++var4) {
         var2.unlock();
      }

      WriteLock var9 = var1.writeLock();
      var9.lock();

      try {
         int a = false;
         DebugProbesImpl var10000 = INSTANCE;
         ++installations;
         if (installations > 1) {
            return;
         }

         INSTANCE.startWeakRefCleanerThread();
         if (AgentInstallationType.INSTANCE.isInstalledStatically$kotlinx_coroutines_core()) {
            return;
         }

         Function1 var11 = dynamicAttach;
         if (var11 != null) {
            var11.invoke(true);
         }

         Unit var10 = Unit.INSTANCE;
      } finally {
         for(int var6 = 0; var6 < var3; ++var6) {
            var2.lock();
         }

         var9.unlock();
      }

   }

   public final void uninstall() {
      ReentrantReadWriteLock var1 = coroutineStateLock;
      ReadLock var2 = var1.readLock();
      int var3 = var1.getWriteHoldCount() == 0 ? var1.getReadHoldCount() : 0;

      for(int var4 = 0; var4 < var3; ++var4) {
         var2.unlock();
      }

      WriteLock var9 = var1.writeLock();
      var9.lock();

      try {
         int a = false;
         if (!INSTANCE.isInstalled$kotlinx_coroutines_core()) {
            int a = false;
            String var11 = "Agent was not installed";
            throw new IllegalStateException(var11.toString());
         }

         DebugProbesImpl var10000 = INSTANCE;
         installations += -1;
         if (installations != 0) {
            return;
         }

         INSTANCE.stopWeakRefCleanerThread();
         capturedCoroutinesMap.clear();
         callerInfoCache.clear();
         if (!AgentInstallationType.INSTANCE.isInstalledStatically$kotlinx_coroutines_core()) {
            Function1 var13 = dynamicAttach;
            if (var13 != null) {
               var13.invoke(false);
            }

            Unit var10 = Unit.INSTANCE;
            return;
         }
      } finally {
         for(int var12 = 0; var12 < var3; ++var12) {
            var2.lock();
         }

         var9.unlock();
      }

   }

   private final void startWeakRefCleanerThread() {
      weakRefCleanerThread = ThreadsKt.thread$default(false, true, (ClassLoader)null, "Coroutines Debugger Cleaner", 0, (Function0)null.INSTANCE, 21, (Object)null);
   }

   private final void stopWeakRefCleanerThread() {
      Thread var10000 = weakRefCleanerThread;
      if (var10000 != null) {
         Thread a = var10000;
         weakRefCleanerThread = null;
         a.interrupt();
         a.join();
      }
   }

   @NotNull
   public final String hierarchyToString(@NotNull Job a) {
      ReentrantReadWriteLock var2 = coroutineStateLock;
      ReadLock var3 = var2.readLock();
      int var4 = var2.getWriteHoldCount() == 0 ? var2.getReadHoldCount() : 0;

      for(int var5 = 0; var5 < var4; ++var5) {
         var3.unlock();
      }

      WriteLock var24 = var2.writeLock();
      var24.lock();

      try {
         int a = false;
         if (!INSTANCE.isInstalled$kotlinx_coroutines_core()) {
            int a = false;
            String var27 = "Debug probes are not installed";
            throw new IllegalStateException(var27.toString());
         } else {
            Iterable a = (Iterable)INSTANCE.getCapturedCoroutines();
            int a = false;
            Collection a = (Collection)(new ArrayList());
            int a = false;
            Iterator var12 = a.iterator();

            while(var12.hasNext()) {
               Object a = var12.next();
               DebugProbesImpl.CoroutineOwner a = (DebugProbesImpl.CoroutineOwner)a;
               int a = false;
               if (a.delegate.getContext().get((CoroutineContext.Key)Job.Key) != null) {
                  a.add(a);
               }
            }

            a = (Iterable)((List)a);
            a = false;
            int a = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(a, 10)), 16);
            Map a = (Map)(new LinkedHashMap(a));
            int a = false;
            Iterator var32 = a.iterator();

            while(var32.hasNext()) {
               Object a = var32.next();
               DebugProbesImpl.CoroutineOwner a = (DebugProbesImpl.CoroutineOwner)a;
               int a = false;
               Job var10001 = JobKt.getJob(a.delegate.getContext());
               a = (DebugProbesImpl.CoroutineOwner)a;
               Job var18 = var10001;
               a = false;
               DebugCoroutineInfoImpl var19 = a.info;
               a.put(var18, var19);
            }

            StringBuilder var25 = new StringBuilder();
            int a = false;
            INSTANCE.build(a, a, var25, "");
            String var10000 = var25.toString();
            Intrinsics.checkNotNullExpressionValue(var10000, "StringBuilder().apply(builderAction).toString()");
            String var21 = var10000;
            return var21;
         }
      } finally {
         for(int var28 = 0; var28 < var4; ++var28) {
            var3.lock();
         }

         var24.unlock();
      }
   }

   private final void build(Job a, Map<Job, DebugCoroutineInfoImpl> a, StringBuilder a, String a) {
      DebugCoroutineInfoImpl a = (DebugCoroutineInfoImpl)a.get(a);
      String a = null;
      if (a == null) {
         if (!(a instanceof ScopeCoroutine)) {
            a.append(a + a.getDebugString(a) + '\n');
            a = a + '\t';
         } else {
            a = a;
         }
      } else {
         StackTraceElement a = (StackTraceElement)CollectionsKt.firstOrNull(a.lastObservedStackTrace());
         String a = a.getState();
         a.append(a + a.getDebugString(a) + ", continuation is " + a + " at line " + a + '\n');
         a = a + '\t';
      }

      Iterator var9 = a.getChildren().iterator();

      while(var9.hasNext()) {
         Job a = (Job)var9.next();
         a.build(a, a, a, a);
      }

   }

   private final String getDebugString(Job a) {
      return a instanceof JobSupport ? ((JobSupport)a).toDebugString() : a.toString();
   }

   /** @deprecated */
   // $FF: synthetic method
   private static void getDebugString$annotations(Job a) {
   }

   private final <R> List<R> dumpCoroutinesInfoImpl(final Function2<? super DebugProbesImpl.CoroutineOwner<?>, ? super CoroutineContext, ? extends R> a) {
      int a = false;
      ReentrantReadWriteLock var3 = coroutineStateLock;
      ReadLock var4 = var3.readLock();
      int var5 = var3.getWriteHoldCount() == 0 ? var3.getReadHoldCount() : 0;

      for(int var6 = 0; var6 < var5; ++var6) {
         var4.unlock();
      }

      WriteLock var12 = var3.writeLock();
      var12.lock();

      List var13;
      try {
         int a = false;
         boolean a;
         if (!INSTANCE.isInstalled$kotlinx_coroutines_core()) {
            a = false;
            String var14 = "Debug probes are not installed";
            throw new IllegalStateException(var14.toString());
         }

         Sequence a = CollectionsKt.asSequence((Iterable)INSTANCE.getCapturedCoroutines());
         a = false;
         var13 = SequencesKt.toList(SequencesKt.mapNotNull(SequencesKt.sortedWith(a, (Comparator)(new DebugProbesImpl$dumpCoroutinesInfoImpl$lambda-12$$inlined$sortedBy$1())), (Function1)(new Function1<DebugProbesImpl.CoroutineOwner<?>, R>() {
            @Nullable
            public final R invoke(@NotNull DebugProbesImpl.CoroutineOwner<?> axx) {
               Object var10000;
               if (DebugProbesImpl.INSTANCE.isFinished(axx)) {
                  var10000 = null;
               } else {
                  CoroutineContext var6 = axx.info.getContext();
                  if (var6 != null) {
                     CoroutineContext var2 = var6;
                     Function2 var3 = a;
                     int axxx = false;
                     var10000 = var3.invoke(axx, var2);
                  } else {
                     var10000 = null;
                  }
               }

               return var10000;
            }
         })));
      } finally {
         InlineMarker.finallyStart(1);

         for(int var15 = 0; var15 < var5; ++var15) {
            var4.lock();
         }

         var12.unlock();
         InlineMarker.finallyEnd(1);
      }

      return var13;
   }

   @NotNull
   public final Object[] dumpCoroutinesInfoAsJsonAndReferences() {
      List a = a.dumpCoroutinesInfo();
      int a = a.size();
      ArrayList a = new ArrayList(a);
      ArrayList a = new ArrayList(a);
      ArrayList a = new ArrayList(a);
      Iterator var6 = a.iterator();

      while(var6.hasNext()) {
         DebugCoroutineInfo a;
         CoroutineContext a;
         String var14;
         label38: {
            a = (DebugCoroutineInfo)var6.next();
            a = a.getContext();
            CoroutineName var10000 = (CoroutineName)a.get((CoroutineContext.Key)CoroutineName.Key);
            if (var10000 != null) {
               var14 = var10000.getName();
               if (var14 != null) {
                  var14 = a.toStringWithQuotes(var14);
                  break label38;
               }
            }

            var14 = null;
         }

         String a = var14;
         CoroutineDispatcher var15 = (CoroutineDispatcher)a.get((CoroutineContext.Key)CoroutineDispatcher.Key);
         String a = var15 != null ? a.toStringWithQuotes(var15) : null;
         StringBuilder var10001 = (new StringBuilder()).append("\n                {\n                    \"name\": ").append(a).append(",\n                    \"id\": ");
         CoroutineId var10002 = (CoroutineId)a.get((CoroutineContext.Key)CoroutineId.Key);
         a.add(StringsKt.trimIndent(var10001.append(var10002 != null ? var10002.getId() : null).append(",\n                    \"dispatcher\": ").append(a).append(",\n                    \"sequenceNumber\": ").append(a.getSequenceNumber()).append(",\n                    \"state\": \"").append(a.getState()).append("\"\n                } \n                ").toString()));
         a.add(a.getLastObservedFrame());
         a.add(a.getLastObservedThread());
      }

      Object[] var11 = new Object[4];
      var11[0] = '[' + CollectionsKt.joinToString$default((Iterable)a, (CharSequence)null, (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 63, (Object)null) + ']';
      Collection a = (Collection)a;
      int a = false;
      Object[] var16 = a.toArray(new Thread[0]);
      if (var16 == null) {
         throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
      } else {
         var11[1] = var16;
         a = (Collection)a;
         a = false;
         var16 = a.toArray(new CoroutineStackFrame[0]);
         if (var16 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
         } else {
            var11[2] = var16;
            a = (Collection)a;
            a = false;
            var16 = a.toArray(new DebugCoroutineInfo[0]);
            if (var16 == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
            } else {
               var11[3] = var16;
               return var11;
            }
         }
      }
   }

   @NotNull
   public final String enhanceStackTraceWithThreadDumpAsJson(@NotNull DebugCoroutineInfo a) {
      List a = a.enhanceStackTraceWithThreadDump(a, a.lastObservedStackTrace());
      List a = (List)(new ArrayList());
      Iterator var4 = a.iterator();

      while(var4.hasNext()) {
         StackTraceElement a = (StackTraceElement)var4.next();
         StringBuilder var10001 = (new StringBuilder()).append("\n                {\n                    \"declaringClass\": \"").append(a.getClassName()).append("\",\n                    \"methodName\": \"").append(a.getMethodName()).append("\",\n                    \"fileName\": ");
         String var10002 = a.getFileName();
         a.add(StringsKt.trimIndent(var10001.append(var10002 != null ? a.toStringWithQuotes(var10002) : null).append(",\n                    \"lineNumber\": ").append(a.getLineNumber()).append("\n                }\n                ").toString()));
      }

      return '[' + CollectionsKt.joinToString$default((Iterable)a, (CharSequence)null, (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 63, (Object)null) + ']';
   }

   private final String toStringWithQuotes(Object a) {
      return "" + '"' + a + '"';
   }

   @NotNull
   public final List<DebugCoroutineInfo> dumpCoroutinesInfo() {
      int a = false;
      ReentrantReadWriteLock var3 = coroutineStateLock;
      ReadLock var4 = var3.readLock();
      int var5 = var3.getWriteHoldCount() == 0 ? var3.getReadHoldCount() : 0;

      for(int var6 = 0; var6 < var5; ++var6) {
         var4.unlock();
      }

      WriteLock var12 = var3.writeLock();
      var12.lock();

      List var13;
      try {
         int a = false;
         boolean a;
         if (!INSTANCE.isInstalled$kotlinx_coroutines_core()) {
            a = false;
            String var14 = "Debug probes are not installed";
            throw new IllegalStateException(var14.toString());
         }

         Sequence a = CollectionsKt.asSequence((Iterable)INSTANCE.getCapturedCoroutines());
         a = false;
         var13 = SequencesKt.toList(SequencesKt.mapNotNull(SequencesKt.sortedWith(a, (Comparator)(new DebugProbesImpl$dumpCoroutinesInfoImpl$lambda-12$$inlined$sortedBy$1())), (Function1)(new DebugProbesImpl$dumpCoroutinesInfo$$inlined$dumpCoroutinesInfoImpl$1())));
      } finally {
         for(int var15 = 0; var15 < var5; ++var15) {
            var4.lock();
         }

         var12.unlock();
      }

      return var13;
   }

   @NotNull
   public final List<DebuggerInfo> dumpDebuggerInfo() {
      int a = false;
      ReentrantReadWriteLock var3 = coroutineStateLock;
      ReadLock var4 = var3.readLock();
      int var5 = var3.getWriteHoldCount() == 0 ? var3.getReadHoldCount() : 0;

      for(int var6 = 0; var6 < var5; ++var6) {
         var4.unlock();
      }

      WriteLock var12 = var3.writeLock();
      var12.lock();

      List var13;
      try {
         int a = false;
         boolean a;
         if (!INSTANCE.isInstalled$kotlinx_coroutines_core()) {
            a = false;
            String var14 = "Debug probes are not installed";
            throw new IllegalStateException(var14.toString());
         }

         Sequence a = CollectionsKt.asSequence((Iterable)INSTANCE.getCapturedCoroutines());
         a = false;
         var13 = SequencesKt.toList(SequencesKt.mapNotNull(SequencesKt.sortedWith(a, (Comparator)(new DebugProbesImpl$dumpCoroutinesInfoImpl$lambda-12$$inlined$sortedBy$1())), (Function1)(new DebugProbesImpl$dumpDebuggerInfo$$inlined$dumpCoroutinesInfoImpl$1())));
      } finally {
         for(int var15 = 0; var15 < var5; ++var15) {
            var4.lock();
         }

         var12.unlock();
      }

      return var13;
   }

   public final void dumpCoroutines(@NotNull PrintStream a) {
      synchronized(a) {
         int a = false;
         INSTANCE.dumpCoroutinesSynchronized(a);
         Unit var5 = Unit.INSTANCE;
      }
   }

   private final boolean isFinished(DebugProbesImpl.CoroutineOwner<?> a) {
      CoroutineContext var10000 = a.info.getContext();
      if (var10000 != null) {
         Job var3 = (Job)var10000.get((CoroutineContext.Key)Job.Key);
         if (var3 != null) {
            Job a = var3;
            if (!a.isCompleted()) {
               return false;
            }

            capturedCoroutinesMap.remove(a);
            return true;
         }
      }

      return false;
   }

   private final void dumpCoroutinesSynchronized(PrintStream a) {
      ReentrantReadWriteLock var2 = coroutineStateLock;
      ReadLock var3 = var2.readLock();
      int var4 = var2.getWriteHoldCount() == 0 ? var2.getReadHoldCount() : 0;

      for(int var5 = 0; var5 < var4; ++var5) {
         var3.unlock();
      }

      WriteLock var19 = var2.writeLock();
      var19.lock();

      try {
         int a = false;
         boolean a;
         if (!INSTANCE.isInstalled$kotlinx_coroutines_core()) {
            a = false;
            String var21 = "Debug probes are not installed";
            throw new IllegalStateException(var21.toString());
         }

         a.print("Coroutines dump " + dateFormat.format(System.currentTimeMillis()));
         Sequence a = SequencesKt.filter(CollectionsKt.asSequence((Iterable)INSTANCE.getCapturedCoroutines()), (Function1)null.INSTANCE);
         a = false;
         a = SequencesKt.sortedWith(a, (Comparator)(new DebugProbesImpl$dumpCoroutinesSynchronized$lambda-19$$inlined$sortedBy$1()));
         a = false;
         Iterator var9 = a.iterator();

         while(var9.hasNext()) {
            Object a = var9.next();
            DebugProbesImpl.CoroutineOwner a = (DebugProbesImpl.CoroutineOwner)a;
            int a = false;
            DebugCoroutineInfoImpl a = a.info;
            List a = a.lastObservedStackTrace();
            List a = INSTANCE.enhanceStackTraceWithThreadDumpImpl(a.getState(), a.lastObservedThread, a);
            String a = Intrinsics.areEqual((Object)a.getState(), (Object)"RUNNING") && a == a ? a.getState() + " (Last suspension stacktrace, not an actual stacktrace)" : a.getState();
            a.print("\n\nCoroutine " + a.delegate + ", state: " + a);
            if (a.isEmpty()) {
               a.print("\n\tat " + StackTraceRecoveryKt.artificialFrame("Coroutine creation stacktrace"));
               INSTANCE.printStackTrace(a, a.getCreationStackTrace());
            } else {
               INSTANCE.printStackTrace(a, a);
            }
         }

         Unit var20 = Unit.INSTANCE;
      } finally {
         for(int var22 = 0; var22 < var4; ++var22) {
            var3.lock();
         }

         var19.unlock();
      }

   }

   private final void printStackTrace(PrintStream a, List<StackTraceElement> a) {
      Iterable a = (Iterable)a;
      int a = false;
      Iterator var5 = a.iterator();

      while(var5.hasNext()) {
         Object a = var5.next();
         StackTraceElement a = (StackTraceElement)a;
         int a = false;
         a.print("\n\tat " + a);
      }

   }

   @NotNull
   public final List<StackTraceElement> enhanceStackTraceWithThreadDump(@NotNull DebugCoroutineInfo a, @NotNull List<StackTraceElement> a) {
      return a.enhanceStackTraceWithThreadDumpImpl(a.getState(), a.getLastObservedThread(), a);
   }

   private final List<StackTraceElement> enhanceStackTraceWithThreadDumpImpl(String a, Thread a, List<StackTraceElement> a) {
      if (Intrinsics.areEqual((Object)a, (Object)"RUNNING") && a != null) {
         DebugProbesImpl var6 = a;

         Object var7;
         Result.Companion var10000;
         try {
            var10000 = Result.Companion;
            DebugProbesImpl a = (DebugProbesImpl)var6;
            int a = false;
            var7 = Result.constructor-impl(a.getStackTrace());
         } catch (Throwable var13) {
            var10000 = Result.Companion;
            var7 = Result.constructor-impl(ResultKt.createFailure(var13));
         }

         StackTraceElement[] var22 = (StackTraceElement[])(Result.isFailure-impl(var7) ? null : var7);
         if (var22 == null) {
            return a;
         } else {
            StackTraceElement[] a = var22;
            Object[] a = a;
            int a = false;
            int a = 0;
            int a = a.length;

            int var23;
            while(true) {
               if (a >= a) {
                  var23 = -1;
                  break;
               }

               StackTraceElement a = a[a];
               int a = false;
               if (Intrinsics.areEqual((Object)a.getClassName(), (Object)"kotlin.coroutines.jvm.internal.BaseContinuationImpl") && Intrinsics.areEqual((Object)a.getMethodName(), (Object)"resumeWith") && Intrinsics.areEqual((Object)a.getFileName(), (Object)"ContinuationImpl.kt")) {
                  var23 = a;
                  break;
               }

               ++a;
            }

            int a = var23;
            Pair var15 = a.findContinuationStartIndex(a, a, a);
            int a = ((Number)var15.component1()).intValue();
            a = ((Number)var15.component2()).intValue();
            if (a == -1) {
               return a;
            } else {
               a = a + a.size() - a - 1 - a;
               ArrayList a = new ArrayList(a);
               int a = 0;

               int var12;
               for(var12 = a - a; a < var12; ++a) {
                  ((Collection)a).add(a[a]);
               }

               a = a + 1;

               for(var12 = a.size(); a < var12; ++a) {
                  ((Collection)a).add(a.get(a));
               }

               return (List)a;
            }
         }
      } else {
         return a;
      }
   }

   private final Pair<Integer, Integer> findContinuationStartIndex(int a, StackTraceElement[] a, List<StackTraceElement> a) {
      byte var4 = 3;

      for(int var5 = 0; var5 < var4; ++var5) {
         int a = false;
         int a = INSTANCE.findIndexOfFrame(a - 1 - var5, a, a);
         if (a != -1) {
            return TuplesKt.to(a, var5);
         }
      }

      return TuplesKt.to(-1, 0);
   }

   private final int findIndexOfFrame(int a, StackTraceElement[] a, List<StackTraceElement> a) {
      StackTraceElement var10000 = (StackTraceElement)ArraysKt.getOrNull(a, a);
      if (var10000 == null) {
         return -1;
      } else {
         StackTraceElement a = var10000;
         int a = false;
         int a = 0;
         Iterator var8 = a.iterator();

         int var12;
         while(true) {
            if (!var8.hasNext()) {
               var12 = -1;
               break;
            }

            Object a = var8.next();
            StackTraceElement a = (StackTraceElement)a;
            int a = false;
            if (Intrinsics.areEqual((Object)a.getFileName(), (Object)a.getFileName()) && Intrinsics.areEqual((Object)a.getClassName(), (Object)a.getClassName()) && Intrinsics.areEqual((Object)a.getMethodName(), (Object)a.getMethodName())) {
               var12 = a;
               break;
            }

            ++a;
         }

         return var12;
      }
   }

   public final void probeCoroutineResumed$kotlinx_coroutines_core(@NotNull Continuation<?> a) {
      a.updateState(a, "RUNNING");
   }

   public final void probeCoroutineSuspended$kotlinx_coroutines_core(@NotNull Continuation<?> a) {
      a.updateState(a, "SUSPENDED");
   }

   private final void updateState(Continuation<?> a, String a) {
      if (a.isInstalled$kotlinx_coroutines_core()) {
         if (Intrinsics.areEqual((Object)a, (Object)"RUNNING") && KotlinVersion.CURRENT.isAtLeast(1, 3, 30)) {
            CoroutineStackFrame var5 = a instanceof CoroutineStackFrame ? (CoroutineStackFrame)a : null;
            if ((a instanceof CoroutineStackFrame ? (CoroutineStackFrame)a : null) != null) {
               CoroutineStackFrame a = var5;
               a.updateRunningState(a, a);
            }
         } else {
            DebugProbesImpl.CoroutineOwner var10000 = a.owner(a);
            if (var10000 != null) {
               DebugProbesImpl.CoroutineOwner a = var10000;
               a.updateState(a, a, a);
            }
         }
      }
   }

   private final void updateRunningState(CoroutineStackFrame a, String a) {
      ReadLock var3 = coroutineStateLock.readLock();
      var3.lock();

      try {
         int a = false;
         if (INSTANCE.isInstalled$kotlinx_coroutines_core()) {
            DebugCoroutineInfoImpl a = null;
            DebugCoroutineInfoImpl a = (DebugCoroutineInfoImpl)callerInfoCache.remove(a);
            CoroutineStackFrame a;
            CoroutineStackFrame var12;
            if (a != null) {
               a = a;
            } else {
               DebugProbesImpl.CoroutineOwner var10000 = INSTANCE.owner(a);
               if (var10000 == null) {
                  return;
               }

               DebugCoroutineInfoImpl var11 = var10000.info;
               if (var11 == null) {
                  return;
               }

               a = var11;
               var12 = a.getLastObservedFrame$kotlinx_coroutines_core();
               a = var12 != null ? INSTANCE.realCaller(var12) : null;
               if (a != null) {
                  callerInfoCache.remove(a);
               }
            }

            a.updateState$kotlinx_coroutines_core(a, (Continuation)a);
            var12 = INSTANCE.realCaller(a);
            if (var12 != null) {
               a = var12;
               ((Map)callerInfoCache).put(a, a);
               Unit var10 = Unit.INSTANCE;
            }
         }
      } finally {
         var3.unlock();
      }
   }

   private final CoroutineStackFrame realCaller(CoroutineStackFrame a) {
      DebugProbesImpl var2 = a;
      CoroutineStackFrame var3 = a;

      while(true) {
         CoroutineStackFrame var10000 = var3.getCallerFrame();
         if (var10000 == null) {
            return null;
         }

         CoroutineStackFrame a = var10000;
         if (a.getStackTraceElement() != null) {
            return a;
         }

         var2 = var2;
         var3 = a;
      }
   }

   private final void updateState(DebugProbesImpl.CoroutineOwner<?> a, Continuation<?> a, String a) {
      ReadLock var4 = coroutineStateLock.readLock();
      var4.lock();

      try {
         int a = false;
         if (INSTANCE.isInstalled$kotlinx_coroutines_core()) {
            a.info.updateState$kotlinx_coroutines_core(a, a);
            Unit var8 = Unit.INSTANCE;
            return;
         }
      } finally {
         var4.unlock();
      }

   }

   private final DebugProbesImpl.CoroutineOwner<?> owner(Continuation<?> a) {
      return (a instanceof CoroutineStackFrame ? (CoroutineStackFrame)a : null) != null ? a.owner(a instanceof CoroutineStackFrame ? (CoroutineStackFrame)a : null) : null;
   }

   private final DebugProbesImpl.CoroutineOwner<?> owner(CoroutineStackFrame a) {
      DebugProbesImpl var2 = a;
      CoroutineStackFrame var3 = a;

      DebugProbesImpl.CoroutineOwner var10000;
      while(true) {
         if (var3 instanceof DebugProbesImpl.CoroutineOwner) {
            var10000 = (DebugProbesImpl.CoroutineOwner)var3;
            break;
         }

         CoroutineStackFrame var6 = var3.getCallerFrame();
         if (var6 == null) {
            var10000 = null;
            break;
         }

         var2 = var2;
         var3 = var6;
      }

      return var10000;
   }

   @NotNull
   public final <T> Continuation<T> probeCoroutineCreated$kotlinx_coroutines_core(@NotNull Continuation<? super T> a) {
      if (!a.isInstalled$kotlinx_coroutines_core()) {
         return a;
      } else {
         DebugProbesImpl.CoroutineOwner a = a.owner(a);
         if (a != null) {
            return a;
         } else {
            StackTraceFrame a = enableCreationStackTraces ? a.toStackTraceFrame(a.sanitizeStackTrace((Throwable)(new Exception()))) : (StackTraceFrame)null;
            return a.createOwner(a, a);
         }
      }
   }

   private final StackTraceFrame toStackTraceFrame(List<StackTraceElement> a) {
      Object a = null;
      int a = false;
      Object a = (StackTraceFrame)a;
      StackTraceElement a;
      if (!a.isEmpty()) {
         for(ListIterator a = a.listIterator(a.size()); a.hasPrevious(); a = new StackTraceFrame((CoroutineStackFrame)a, a)) {
            a = (StackTraceElement)a.previous();
            int a = false;
         }
      }

      return a;
   }

   private final <T> Continuation<T> createOwner(Continuation<? super T> a, StackTraceFrame a) {
      if (!a.isInstalled$kotlinx_coroutines_core()) {
         return a;
      } else {
         DebugCoroutineInfoImpl a = new DebugCoroutineInfoImpl(a.getContext(), a, sequenceNumber$FU.incrementAndGet(debugProbesImpl$SequenceNumberRefVolatile));
         DebugProbesImpl.CoroutineOwner a = new DebugProbesImpl.CoroutineOwner(a, a, (CoroutineStackFrame)a);
         ((Map)capturedCoroutinesMap).put(a, true);
         if (!a.isInstalled$kotlinx_coroutines_core()) {
            capturedCoroutinesMap.clear();
         }

         return (Continuation)a;
      }
   }

   private final void probeCoroutineCompleted(DebugProbesImpl.CoroutineOwner<?> a) {
      capturedCoroutinesMap.remove(a);
      CoroutineStackFrame var10000 = a.info.getLastObservedFrame$kotlinx_coroutines_core();
      if (var10000 != null) {
         var10000 = a.realCaller(var10000);
         if (var10000 != null) {
            CoroutineStackFrame a = var10000;
            callerInfoCache.remove(a);
            return;
         }
      }

   }

   private final <T extends Throwable> List<StackTraceElement> sanitizeStackTrace(T a) {
      StackTraceElement[] a;
      int a;
      int a;
      int a;
      boolean a;
      int var10000;
      label77: {
         a = a.getStackTrace();
         a = a.length;
         Object[] a = a;
         int a = false;
         a = a.length + -1;
         if (0 <= a) {
            do {
               a = a--;
               StackTraceElement a = a[a];
               a = false;
               if (Intrinsics.areEqual((Object)a.getClassName(), (Object)"kotlin.coroutines.jvm.internal.DebugProbesKt")) {
                  var10000 = a;
                  break label77;
               }
            } while(0 <= a);
         }

         var10000 = -1;
      }

      int a = var10000;
      if (!sanitizeStackTraces) {
         int var13 = a - a;
         ArrayList var15 = new ArrayList(var13);

         for(a = 0; a < var13; ++a) {
            a = false;
            var15.add(a == 0 ? StackTraceRecoveryKt.artificialFrame("Coroutine creation stacktrace") : a[a + a]);
         }

         return (List)var15;
      } else {
         ArrayList a = new ArrayList(a - a + 1);
         ((Collection)a).add(StackTraceRecoveryKt.artificialFrame("Coroutine creation stacktrace"));
         int a = a + 1;

         while(true) {
            while(a < a) {
               if (a.isInternalMethod(a[a])) {
                  ((Collection)a).add(a[a]);

                  for(a = a + 1; a < a && a.isInternalMethod(a[a]); ++a) {
                  }

                  for(a = a - 1; a > a && a[a].getFileName() == null; --a) {
                  }

                  if (a > a && a < a - 1) {
                     ((Collection)a).add(a[a]);
                  }

                  ((Collection)a).add(a[a - 1]);
                  a = a;
               } else {
                  ((Collection)a).add(a[a]);
                  ++a;
               }
            }

            return (List)a;
         }
      }
   }

   private final boolean isInternalMethod(StackTraceElement a) {
      return StringsKt.startsWith$default(a.getClassName(), "kotlinx.coroutines", false, 2, (Object)null);
   }

   static {
      dynamicAttach = INSTANCE.getDynamicAttach();
      callerInfoCache = new ConcurrentWeakMap(true);
      sequenceNumber$FU = AtomicLongFieldUpdater.newUpdater(DebugProbesImpl$SequenceNumberRefVolatile.class, "sequenceNumber");
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0002\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u00022\u00020\u0003B%\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0003¢\u0006\u0002\u0010\bJ\n\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0016J\u001e\u0010\u0012\u001a\u00020\u00132\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u00028\u00000\u0015H\u0016ø\u0001\u0000¢\u0006\u0002\u0010\u0016J\b\u0010\u0017\u001a\u00020\u0018H\u0016R\u0016\u0010\t\u001a\u0004\u0018\u00010\u00038VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000bR\u0012\u0010\f\u001a\u00020\rX\u0096\u0005¢\u0006\u0006\u001a\u0004\b\u000e\u0010\u000fR\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u00028\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0019"},
      d2 = {"Lkotlinx/coroutines/debug/internal/DebugProbesImpl$CoroutineOwner;", "T", "Lkotlin/coroutines/Continuation;", "Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;", "delegate", "info", "Lkotlinx/coroutines/debug/internal/DebugCoroutineInfoImpl;", "frame", "(Lkotlin/coroutines/Continuation;Lkotlinx/coroutines/debug/internal/DebugCoroutineInfoImpl;Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;)V", "callerFrame", "getCallerFrame", "()Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;", "context", "Lkotlin/coroutines/CoroutineContext;", "getContext", "()Lkotlin/coroutines/CoroutineContext;", "getStackTraceElement", "Ljava/lang/StackTraceElement;", "resumeWith", "", "result", "Lkotlin/Result;", "(Ljava/lang/Object;)V", "toString", "", "kotlinx-coroutines-core"}
   )
   private static final class CoroutineOwner<T> implements Continuation<T>, CoroutineStackFrame {
      @JvmField
      @NotNull
      public final Continuation<T> delegate;
      @JvmField
      @NotNull
      public final DebugCoroutineInfoImpl info;
      @Nullable
      private final CoroutineStackFrame frame;

      public CoroutineOwner(@NotNull Continuation<? super T> a, @NotNull DebugCoroutineInfoImpl a, @Nullable CoroutineStackFrame a) {
         a.delegate = a;
         a.info = a;
         a.frame = a;
      }

      @NotNull
      public CoroutineContext getContext() {
         return a.delegate.getContext();
      }

      @Nullable
      public CoroutineStackFrame getCallerFrame() {
         CoroutineStackFrame var10000 = a.frame;
         return var10000 != null ? var10000.getCallerFrame() : null;
      }

      @Nullable
      public StackTraceElement getStackTraceElement() {
         CoroutineStackFrame var10000 = a.frame;
         return var10000 != null ? var10000.getStackTraceElement() : null;
      }

      public void resumeWith(@NotNull Object a) {
         DebugProbesImpl.INSTANCE.probeCoroutineCompleted(a);
         a.delegate.resumeWith(a);
      }

      @NotNull
      public String toString() {
         return a.delegate.toString();
      }
   }
}
