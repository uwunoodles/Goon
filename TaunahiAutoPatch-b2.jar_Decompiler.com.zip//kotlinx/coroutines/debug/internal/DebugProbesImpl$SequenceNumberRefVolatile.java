package kotlinx.coroutines.debug.internal;

// $FF: synthetic class
class DebugProbesImpl$SequenceNumberRefVolatile {
   volatile long sequenceNumber;

   public DebugProbesImpl$SequenceNumberRefVolatile(long var1) {
      this.sequenceNumber = var1;
   }
}
