package kotlinx.coroutines;

import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.CoroutineStackFrame;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequenceScope;
import kotlin.sequences.SequencesKt;
import kotlinx.coroutines.internal.LockFreeLinkedListHead;
import kotlinx.coroutines.internal.LockFreeLinkedListNode;
import kotlinx.coroutines.internal.OpDescriptor;
import kotlinx.coroutines.internal.StackTraceRecoveryKt;
import kotlinx.coroutines.internal.Symbol;
import kotlinx.coroutines.intrinsics.CancellableKt;
import kotlinx.coroutines.intrinsics.UndispatchedKt;
import kotlinx.coroutines.selects.SelectClause0;
import kotlinx.coroutines.selects.SelectInstance;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** @deprecated */
@Deprecated(
   message = "This is internal API and may be removed in the future releases",
   level = DeprecationLevel.ERROR
)
@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000è\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0003\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0001\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\b\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0012\b\u0017\u0018\u00002\u00020X2\u00020\u00172\u00020\u007f2\u00030Ã\u0001:\u0006Ò\u0001Ó\u0001Ô\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0004\b\u0003\u0010\u0004J'\u0010\u000b\u001a\u00020\u00012\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\tH\u0002¢\u0006\u0004\b\u000b\u0010\fJ%\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u000e\u001a\u00020\r2\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\r0\u000fH\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u0019\u0010\u0015\u001a\u00020\u00112\b\u0010\u0014\u001a\u0004\u0018\u00010\u0005H\u0014¢\u0006\u0004\b\u0015\u0010\u0016J\u0015\u0010\u001a\u001a\u00020\u00192\u0006\u0010\u0018\u001a\u00020\u0017¢\u0006\u0004\b\u001a\u0010\u001bJ\u0015\u0010\u001e\u001a\u0004\u0018\u00010\u0005H\u0080@ø\u0001\u0000¢\u0006\u0004\b\u001c\u0010\u001dJ\u0015\u0010\u001f\u001a\u0004\u0018\u00010\u0005H\u0082@ø\u0001\u0000¢\u0006\u0004\b\u001f\u0010\u001dJ\u0019\u0010!\u001a\u00020\u00012\b\u0010 \u001a\u0004\u0018\u00010\rH\u0017¢\u0006\u0004\b!\u0010\"J\u001f\u0010!\u001a\u00020\u00112\u000e\u0010 \u001a\n\u0018\u00010#j\u0004\u0018\u0001`$H\u0016¢\u0006\u0004\b!\u0010%J\u0017\u0010&\u001a\u00020\u00012\b\u0010 \u001a\u0004\u0018\u00010\r¢\u0006\u0004\b&\u0010\"J\u0019\u0010)\u001a\u00020\u00012\b\u0010 \u001a\u0004\u0018\u00010\u0005H\u0000¢\u0006\u0004\b'\u0010(J\u0017\u0010*\u001a\u00020\u00112\u0006\u0010 \u001a\u00020\rH\u0016¢\u0006\u0004\b*\u0010+J\u001b\u0010,\u001a\u0004\u0018\u00010\u00052\b\u0010 \u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0004\b,\u0010-J\u0017\u0010.\u001a\u00020\u00012\u0006\u0010 \u001a\u00020\rH\u0002¢\u0006\u0004\b.\u0010\"J\u000f\u00100\u001a\u00020/H\u0014¢\u0006\u0004\b0\u00101J\u0017\u00102\u001a\u00020\u00012\u0006\u0010 \u001a\u00020\rH\u0016¢\u0006\u0004\b2\u0010\"J!\u00105\u001a\u00020\u00112\u0006\u0010\u0014\u001a\u0002032\b\u00104\u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0004\b5\u00106J)\u0010;\u001a\u00020\u00112\u0006\u0010\u0014\u001a\u0002072\u0006\u00109\u001a\u0002082\b\u0010:\u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0004\b;\u0010<J\u0019\u0010=\u001a\u00020\r2\b\u0010 \u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0004\b=\u0010>J(\u0010C\u001a\u00020@2\n\b\u0002\u0010?\u001a\u0004\u0018\u00010/2\n\b\u0002\u0010 \u001a\u0004\u0018\u00010\rH\u0080\b¢\u0006\u0004\bA\u0010BJ#\u0010D\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0014\u001a\u0002072\b\u0010:\u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0004\bD\u0010EJ\u0019\u0010F\u001a\u0004\u0018\u0001082\u0006\u0010\u0014\u001a\u000203H\u0002¢\u0006\u0004\bF\u0010GJ\u0011\u0010H\u001a\u00060#j\u0002`$¢\u0006\u0004\bH\u0010IJ\u0013\u0010J\u001a\u00060#j\u0002`$H\u0016¢\u0006\u0004\bJ\u0010IJ\u0011\u0010M\u001a\u0004\u0018\u00010\u0005H\u0000¢\u0006\u0004\bK\u0010LJ\u000f\u0010N\u001a\u0004\u0018\u00010\r¢\u0006\u0004\bN\u0010OJ'\u0010P\u001a\u0004\u0018\u00010\r2\u0006\u0010\u0014\u001a\u0002072\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\r0\u000fH\u0002¢\u0006\u0004\bP\u0010QJ\u0019\u0010R\u001a\u0004\u0018\u00010\u00072\u0006\u0010\u0014\u001a\u000203H\u0002¢\u0006\u0004\bR\u0010SJ\u0017\u0010U\u001a\u00020\u00012\u0006\u0010T\u001a\u00020\rH\u0014¢\u0006\u0004\bU\u0010\"J\u0017\u0010W\u001a\u00020\u00112\u0006\u0010T\u001a\u00020\rH\u0010¢\u0006\u0004\bV\u0010+J\u0019\u0010Z\u001a\u00020\u00112\b\u0010Y\u001a\u0004\u0018\u00010XH\u0004¢\u0006\u0004\bZ\u0010[JF\u0010d\u001a\u00020c2\u0006\u0010\\\u001a\u00020\u00012\u0006\u0010]\u001a\u00020\u00012'\u0010b\u001a#\u0012\u0015\u0012\u0013\u0018\u00010\r¢\u0006\f\b_\u0012\b\b`\u0012\u0004\b\b( \u0012\u0004\u0012\u00020\u00110^j\u0002`a¢\u0006\u0004\bd\u0010eJ6\u0010d\u001a\u00020c2'\u0010b\u001a#\u0012\u0015\u0012\u0013\u0018\u00010\r¢\u0006\f\b_\u0012\b\b`\u0012\u0004\b\b( \u0012\u0004\u0012\u00020\u00110^j\u0002`a¢\u0006\u0004\bd\u0010fJ\u0013\u0010g\u001a\u00020\u0011H\u0086@ø\u0001\u0000¢\u0006\u0004\bg\u0010\u001dJ\u000f\u0010h\u001a\u00020\u0001H\u0002¢\u0006\u0004\bh\u0010iJ\u0013\u0010j\u001a\u00020\u0011H\u0082@ø\u0001\u0000¢\u0006\u0004\bj\u0010\u001dJ&\u0010m\u001a\u00020l2\u0014\u0010k\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0004\u0012\u00020\u00110^H\u0082\b¢\u0006\u0004\bm\u0010nJ\u001b\u0010o\u001a\u0004\u0018\u00010\u00052\b\u0010 \u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0004\bo\u0010-J\u0019\u0010q\u001a\u00020\u00012\b\u0010:\u001a\u0004\u0018\u00010\u0005H\u0000¢\u0006\u0004\bp\u0010(J\u001b\u0010s\u001a\u0004\u0018\u00010\u00052\b\u0010:\u001a\u0004\u0018\u00010\u0005H\u0000¢\u0006\u0004\br\u0010-J@\u0010t\u001a\u00020\t2'\u0010b\u001a#\u0012\u0015\u0012\u0013\u0018\u00010\r¢\u0006\f\b_\u0012\b\b`\u0012\u0004\b\b( \u0012\u0004\u0012\u00020\u00110^j\u0002`a2\u0006\u0010\\\u001a\u00020\u0001H\u0002¢\u0006\u0004\bt\u0010uJ\u000f\u0010w\u001a\u00020/H\u0010¢\u0006\u0004\bv\u00101J\u001f\u0010x\u001a\u00020\u00112\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\rH\u0002¢\u0006\u0004\bx\u0010yJ.\u0010{\u001a\u00020\u0011\"\n\b\u0000\u0010z\u0018\u0001*\u00020\t2\u0006\u0010\b\u001a\u00020\u00072\b\u0010 \u001a\u0004\u0018\u00010\rH\u0082\b¢\u0006\u0004\b{\u0010yJ\u0019\u0010\\\u001a\u00020\u00112\b\u0010 \u001a\u0004\u0018\u00010\rH\u0014¢\u0006\u0004\b\\\u0010+J\u0019\u0010|\u001a\u00020\u00112\b\u0010\u0014\u001a\u0004\u0018\u00010\u0005H\u0014¢\u0006\u0004\b|\u0010\u0016J\u000f\u0010}\u001a\u00020\u0011H\u0014¢\u0006\u0004\b}\u0010~J\u0019\u0010\u0081\u0001\u001a\u00020\u00112\u0007\u0010\u0080\u0001\u001a\u00020\u007f¢\u0006\u0006\b\u0081\u0001\u0010\u0082\u0001J\u001b\u0010\u0084\u0001\u001a\u00020\u00112\u0007\u0010\u0014\u001a\u00030\u0083\u0001H\u0002¢\u0006\u0006\b\u0084\u0001\u0010\u0085\u0001J\u001a\u0010\u0086\u0001\u001a\u00020\u00112\u0006\u0010\u0014\u001a\u00020\tH\u0002¢\u0006\u0006\b\u0086\u0001\u0010\u0087\u0001JI\u0010\u008c\u0001\u001a\u00020\u0011\"\u0005\b\u0000\u0010\u0088\u00012\u000e\u0010\u008a\u0001\u001a\t\u0012\u0004\u0012\u00028\u00000\u0089\u00012\u001d\u0010k\u001a\u0019\b\u0001\u0012\u000b\u0012\t\u0012\u0004\u0012\u00028\u00000\u008b\u0001\u0012\u0006\u0012\u0004\u0018\u00010\u00050^ø\u0001\u0000¢\u0006\u0006\b\u008c\u0001\u0010\u008d\u0001JX\u0010\u0091\u0001\u001a\u00020\u0011\"\u0004\b\u0000\u0010z\"\u0005\b\u0001\u0010\u0088\u00012\u000e\u0010\u008a\u0001\u001a\t\u0012\u0004\u0012\u00028\u00010\u0089\u00012$\u0010k\u001a \b\u0001\u0012\u0004\u0012\u00028\u0000\u0012\u000b\u0012\t\u0012\u0004\u0012\u00028\u00010\u008b\u0001\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u008e\u0001H\u0000ø\u0001\u0000¢\u0006\u0006\b\u008f\u0001\u0010\u0090\u0001J\u001a\u0010\u0093\u0001\u001a\u00020\u00112\u0006\u0010\n\u001a\u00020\tH\u0000¢\u0006\u0006\b\u0092\u0001\u0010\u0087\u0001JX\u0010\u0095\u0001\u001a\u00020\u0011\"\u0004\b\u0000\u0010z\"\u0005\b\u0001\u0010\u0088\u00012\u000e\u0010\u008a\u0001\u001a\t\u0012\u0004\u0012\u00028\u00010\u0089\u00012$\u0010k\u001a \b\u0001\u0012\u0004\u0012\u00028\u0000\u0012\u000b\u0012\t\u0012\u0004\u0012\u00028\u00010\u008b\u0001\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u008e\u0001H\u0000ø\u0001\u0000¢\u0006\u0006\b\u0094\u0001\u0010\u0090\u0001J\u000f\u0010\u0096\u0001\u001a\u00020\u0001¢\u0006\u0005\b\u0096\u0001\u0010iJ\u001d\u0010\u0098\u0001\u001a\u00030\u0097\u00012\b\u0010\u0014\u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0006\b\u0098\u0001\u0010\u0099\u0001J\u001c\u0010\u009a\u0001\u001a\u00020/2\b\u0010\u0014\u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0006\b\u009a\u0001\u0010\u009b\u0001J\u0011\u0010\u009c\u0001\u001a\u00020/H\u0007¢\u0006\u0005\b\u009c\u0001\u00101J\u0011\u0010\u009d\u0001\u001a\u00020/H\u0016¢\u0006\u0005\b\u009d\u0001\u00101J$\u0010\u009e\u0001\u001a\u00020\u00012\u0006\u0010\u0014\u001a\u0002032\b\u00104\u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0006\b\u009e\u0001\u0010\u009f\u0001J\"\u0010 \u0001\u001a\u00020\u00012\u0006\u0010\u0014\u001a\u0002032\u0006\u0010\u000e\u001a\u00020\rH\u0002¢\u0006\u0006\b \u0001\u0010¡\u0001J(\u0010¢\u0001\u001a\u0004\u0018\u00010\u00052\b\u0010\u0014\u001a\u0004\u0018\u00010\u00052\b\u0010:\u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0006\b¢\u0001\u0010£\u0001J&\u0010¤\u0001\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0014\u001a\u0002032\b\u0010:\u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0006\b¤\u0001\u0010¥\u0001J-\u0010¦\u0001\u001a\u00020\u00012\u0006\u0010\u0014\u001a\u0002072\u0006\u0010\u0018\u001a\u0002082\b\u0010:\u001a\u0004\u0018\u00010\u0005H\u0082\u0010¢\u0006\u0006\b¦\u0001\u0010§\u0001J\u0019\u0010©\u0001\u001a\u0004\u0018\u000108*\u00030¨\u0001H\u0002¢\u0006\u0006\b©\u0001\u0010ª\u0001J\u001f\u0010«\u0001\u001a\u00020\u0011*\u00020\u00072\b\u0010 \u001a\u0004\u0018\u00010\rH\u0002¢\u0006\u0005\b«\u0001\u0010yJ&\u0010¬\u0001\u001a\u00060#j\u0002`$*\u00020\r2\n\b\u0002\u0010?\u001a\u0004\u0018\u00010/H\u0004¢\u0006\u0006\b¬\u0001\u0010\u00ad\u0001R\u001b\u0010±\u0001\u001a\t\u0012\u0004\u0012\u00020X0®\u00018F¢\u0006\b\u001a\u0006\b¯\u0001\u0010°\u0001R\u0018\u0010³\u0001\u001a\u0004\u0018\u00010\r8DX\u0084\u0004¢\u0006\u0007\u001a\u0005\b²\u0001\u0010OR\u0016\u0010µ\u0001\u001a\u00020\u00018DX\u0084\u0004¢\u0006\u0007\u001a\u0005\b´\u0001\u0010iR\u0016\u0010·\u0001\u001a\u00020\u00018PX\u0090\u0004¢\u0006\u0007\u001a\u0005\b¶\u0001\u0010iR\u0016\u0010¸\u0001\u001a\u00020\u00018VX\u0096\u0004¢\u0006\u0007\u001a\u0005\b¸\u0001\u0010iR\u0013\u0010¹\u0001\u001a\u00020\u00018F¢\u0006\u0007\u001a\u0005\b¹\u0001\u0010iR\u0013\u0010º\u0001\u001a\u00020\u00018F¢\u0006\u0007\u001a\u0005\bº\u0001\u0010iR\u0013\u0010»\u0001\u001a\u00020\u00018F¢\u0006\u0007\u001a\u0005\b»\u0001\u0010iR\u0016\u0010¼\u0001\u001a\u00020\u00018TX\u0094\u0004¢\u0006\u0007\u001a\u0005\b¼\u0001\u0010iR\u0019\u0010À\u0001\u001a\u0007\u0012\u0002\b\u00030½\u00018F¢\u0006\b\u001a\u0006\b¾\u0001\u0010¿\u0001R\u0016\u0010Â\u0001\u001a\u00020\u00018PX\u0090\u0004¢\u0006\u0007\u001a\u0005\bÁ\u0001\u0010iR\u0015\u0010Æ\u0001\u001a\u00030Ã\u00018F¢\u0006\b\u001a\u0006\bÄ\u0001\u0010Å\u0001R.\u0010Ì\u0001\u001a\u0004\u0018\u00010\u00192\t\u0010Ç\u0001\u001a\u0004\u0018\u00010\u00198@@@X\u0080\u000e¢\u0006\u0010\u001a\u0006\bÈ\u0001\u0010É\u0001\"\u0006\bÊ\u0001\u0010Ë\u0001R\u0017\u0010\u0014\u001a\u0004\u0018\u00010\u00058@X\u0080\u0004¢\u0006\u0007\u001a\u0005\bÍ\u0001\u0010LR\u001e\u0010Ï\u0001\u001a\u0004\u0018\u00010\r*\u0004\u0018\u00010\u00058BX\u0082\u0004¢\u0006\u0007\u001a\u0005\bÎ\u0001\u0010>R\u001b\u0010Ð\u0001\u001a\u00020\u0001*\u0002038BX\u0082\u0004¢\u0006\b\u001a\u0006\bÐ\u0001\u0010Ñ\u0001\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006Õ\u0001"},
   d2 = {"Lkotlinx/coroutines/JobSupport;", "", "active", "JobSupport", "(Z)V", "", "expect", "Lkotlinx/coroutines/NodeList;", "list", "Lkotlinx/coroutines/JobNode;", "node", "addLastAtomic", "(Ljava/lang/Object;Lkotlinx/coroutines/NodeList;Lkotlinx/coroutines/JobNode;)Z", "", "rootCause", "", "exceptions", "", "addSuppressedExceptions", "(Ljava/lang/Throwable;Ljava/util/List;)V", "state", "afterCompletion", "(Ljava/lang/Object;)V", "Lkotlinx/coroutines/ChildJob;", "child", "Lkotlinx/coroutines/ChildHandle;", "attachChild", "(Lkotlinx/coroutines/ChildJob;)Lkotlinx/coroutines/ChildHandle;", "awaitInternal$kotlinx_coroutines_core", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "awaitInternal", "awaitSuspend", "cause", "cancel", "(Ljava/lang/Throwable;)Z", "Ljava/util/concurrent/CancellationException;", "Lkotlinx/coroutines/CancellationException;", "(Ljava/util/concurrent/CancellationException;)V", "cancelCoroutine", "cancelImpl$kotlinx_coroutines_core", "(Ljava/lang/Object;)Z", "cancelImpl", "cancelInternal", "(Ljava/lang/Throwable;)V", "cancelMakeCompleting", "(Ljava/lang/Object;)Ljava/lang/Object;", "cancelParent", "", "cancellationExceptionMessage", "()Ljava/lang/String;", "childCancelled", "Lkotlinx/coroutines/Incomplete;", "update", "completeStateFinalization", "(Lkotlinx/coroutines/Incomplete;Ljava/lang/Object;)V", "Lkotlinx/coroutines/JobSupport$Finishing;", "Lkotlinx/coroutines/ChildHandleNode;", "lastChild", "proposedUpdate", "continueCompleting", "(Lkotlinx/coroutines/JobSupport$Finishing;Lkotlinx/coroutines/ChildHandleNode;Ljava/lang/Object;)V", "createCauseException", "(Ljava/lang/Object;)Ljava/lang/Throwable;", "message", "Lkotlinx/coroutines/JobCancellationException;", "defaultCancellationException$kotlinx_coroutines_core", "(Ljava/lang/String;Ljava/lang/Throwable;)Lkotlinx/coroutines/JobCancellationException;", "defaultCancellationException", "finalizeFinishingState", "(Lkotlinx/coroutines/JobSupport$Finishing;Ljava/lang/Object;)Ljava/lang/Object;", "firstChild", "(Lkotlinx/coroutines/Incomplete;)Lkotlinx/coroutines/ChildHandleNode;", "getCancellationException", "()Ljava/util/concurrent/CancellationException;", "getChildJobCancellationCause", "getCompletedInternal$kotlinx_coroutines_core", "()Ljava/lang/Object;", "getCompletedInternal", "getCompletionExceptionOrNull", "()Ljava/lang/Throwable;", "getFinalRootCause", "(Lkotlinx/coroutines/JobSupport$Finishing;Ljava/util/List;)Ljava/lang/Throwable;", "getOrPromoteCancellingList", "(Lkotlinx/coroutines/Incomplete;)Lkotlinx/coroutines/NodeList;", "exception", "handleJobException", "handleOnCompletionException$kotlinx_coroutines_core", "handleOnCompletionException", "Lkotlinx/coroutines/Job;", "parent", "initParentJob", "(Lkotlinx/coroutines/Job;)V", "onCancelling", "invokeImmediately", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "Lkotlinx/coroutines/CompletionHandler;", "handler", "Lkotlinx/coroutines/DisposableHandle;", "invokeOnCompletion", "(ZZLkotlin/jvm/functions/Function1;)Lkotlinx/coroutines/DisposableHandle;", "(Lkotlin/jvm/functions/Function1;)Lkotlinx/coroutines/DisposableHandle;", "join", "joinInternal", "()Z", "joinSuspend", "block", "", "loopOnState", "(Lkotlin/jvm/functions/Function1;)Ljava/lang/Void;", "makeCancelling", "makeCompleting$kotlinx_coroutines_core", "makeCompleting", "makeCompletingOnce$kotlinx_coroutines_core", "makeCompletingOnce", "makeNode", "(Lkotlin/jvm/functions/Function1;Z)Lkotlinx/coroutines/JobNode;", "nameString$kotlinx_coroutines_core", "nameString", "notifyCancelling", "(Lkotlinx/coroutines/NodeList;Ljava/lang/Throwable;)V", "T", "notifyHandlers", "onCompletionInternal", "onStart", "()V", "Lkotlinx/coroutines/ParentJob;", "parentJob", "parentCancelled", "(Lkotlinx/coroutines/ParentJob;)V", "Lkotlinx/coroutines/Empty;", "promoteEmptyToNodeList", "(Lkotlinx/coroutines/Empty;)V", "promoteSingleToNodeList", "(Lkotlinx/coroutines/JobNode;)V", "R", "Lkotlinx/coroutines/selects/SelectInstance;", "select", "Lkotlin/coroutines/Continuation;", "registerSelectClause0", "(Lkotlinx/coroutines/selects/SelectInstance;Lkotlin/jvm/functions/Function1;)V", "Lkotlin/Function2;", "registerSelectClause1Internal$kotlinx_coroutines_core", "(Lkotlinx/coroutines/selects/SelectInstance;Lkotlin/jvm/functions/Function2;)V", "registerSelectClause1Internal", "removeNode$kotlinx_coroutines_core", "removeNode", "selectAwaitCompletion$kotlinx_coroutines_core", "selectAwaitCompletion", "start", "", "startInternal", "(Ljava/lang/Object;)I", "stateString", "(Ljava/lang/Object;)Ljava/lang/String;", "toDebugString", "toString", "tryFinalizeSimpleState", "(Lkotlinx/coroutines/Incomplete;Ljava/lang/Object;)Z", "tryMakeCancelling", "(Lkotlinx/coroutines/Incomplete;Ljava/lang/Throwable;)Z", "tryMakeCompleting", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "tryMakeCompletingSlowPath", "(Lkotlinx/coroutines/Incomplete;Ljava/lang/Object;)Ljava/lang/Object;", "tryWaitForChild", "(Lkotlinx/coroutines/JobSupport$Finishing;Lkotlinx/coroutines/ChildHandleNode;Ljava/lang/Object;)Z", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "nextChild", "(Lkotlinx/coroutines/internal/LockFreeLinkedListNode;)Lkotlinx/coroutines/ChildHandleNode;", "notifyCompletion", "toCancellationException", "(Ljava/lang/Throwable;Ljava/lang/String;)Ljava/util/concurrent/CancellationException;", "Lkotlin/sequences/Sequence;", "getChildren", "()Lkotlin/sequences/Sequence;", "children", "getCompletionCause", "completionCause", "getCompletionCauseHandled", "completionCauseHandled", "getHandlesException$kotlinx_coroutines_core", "handlesException", "isActive", "isCancelled", "isCompleted", "isCompletedExceptionally", "isScopedCoroutine", "Lkotlin/coroutines/CoroutineContext$Key;", "getKey", "()Lkotlin/coroutines/CoroutineContext$Key;", "key", "getOnCancelComplete$kotlinx_coroutines_core", "onCancelComplete", "Lkotlinx/coroutines/selects/SelectClause0;", "getOnJoin", "()Lkotlinx/coroutines/selects/SelectClause0;", "onJoin", "value", "getParentHandle$kotlinx_coroutines_core", "()Lkotlinx/coroutines/ChildHandle;", "setParentHandle$kotlinx_coroutines_core", "(Lkotlinx/coroutines/ChildHandle;)V", "parentHandle", "getState$kotlinx_coroutines_core", "getExceptionOrNull", "exceptionOrNull", "isCancelling", "(Lkotlinx/coroutines/Incomplete;)Z", "AwaitContinuation", "ChildCompletion", "Finishing", "kotlinx-coroutines-core"}
)
public class JobSupport implements Job, ChildJob, ParentJob, SelectClause0 {
   // $FF: synthetic field
   @NotNull
   private volatile Object _state;
   // $FF: synthetic field
   private static final AtomicReferenceFieldUpdater _state$FU = AtomicReferenceFieldUpdater.newUpdater(JobSupport.class, Object.class, "_state");
   // $FF: synthetic field
   @NotNull
   private volatile Object _parentHandle;

   public JobSupport(boolean a) {
      a._state = a ? JobSupportKt.access$getEMPTY_ACTIVE$p() : JobSupportKt.access$getEMPTY_NEW$p();
      a._parentHandle = null;
   }

   @NotNull
   public final CoroutineContext.Key<?> getKey() {
      return (CoroutineContext.Key)Job.Key;
   }

   @Nullable
   public final ChildHandle getParentHandle$kotlinx_coroutines_core() {
      return (ChildHandle)a._parentHandle;
   }

   public final void setParentHandle$kotlinx_coroutines_core(@Nullable ChildHandle a) {
      a._parentHandle = a;
   }

   protected final void initParentJob(@Nullable Job a) {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a.getParentHandle$kotlinx_coroutines_core() != null) {
            throw new AssertionError();
         }
      }

      if (a == null) {
         a.setParentHandle$kotlinx_coroutines_core((ChildHandle)NonDisposableHandle.INSTANCE);
      } else {
         a.start();
         ChildHandle a = a.attachChild((ChildJob)a);
         a.setParentHandle$kotlinx_coroutines_core(a);
         if (a.isCompleted()) {
            a.dispose();
            a.setParentHandle$kotlinx_coroutines_core((ChildHandle)NonDisposableHandle.INSTANCE);
         }

      }
   }

   @Nullable
   public final Object getState$kotlinx_coroutines_core() {
      JobSupport a = a;
      boolean var2 = false;

      while(true) {
         Object a = a._state;
         int a = false;
         if (!(a instanceof OpDescriptor)) {
            return a;
         }

         ((OpDescriptor)a).perform(a);
      }
   }

   private final Void loopOnState(Function1<Object, Unit> a) {
      boolean var2 = false;

      while(true) {
         a.invoke(a.getState$kotlinx_coroutines_core());
      }
   }

   public boolean isActive() {
      Object a = a.getState$kotlinx_coroutines_core();
      return a instanceof Incomplete && ((Incomplete)a).isActive();
   }

   public final boolean isCompleted() {
      return !(a.getState$kotlinx_coroutines_core() instanceof Incomplete);
   }

   public final boolean isCancelled() {
      Object a = a.getState$kotlinx_coroutines_core();
      return a instanceof CompletedExceptionally || a instanceof JobSupport.Finishing && ((JobSupport.Finishing)a).isCancelling();
   }

   private final Object finalizeFinishingState(JobSupport.Finishing param1, Object param2) {
      // $FF: Couldn't be decompiled
   }

   private final Throwable getFinalRootCause(JobSupport.Finishing a, List<? extends Throwable> a) {
      Throwable a;
      Iterable a;
      boolean a;
      if (a.isEmpty()) {
         if (a.isCancelling()) {
            a = null;
            a = null;
            a = false;
            return (Throwable)(new JobCancellationException(access$cancellationExceptionMessage(a), a, (Job)a));
         } else {
            return null;
         }
      } else {
         a = (Iterable)a;
         a = false;
         Iterator var6 = a.iterator();

         Object var10000;
         while(true) {
            if (var6.hasNext()) {
               Object a = var6.next();
               Throwable a = (Throwable)a;
               int a = false;
               if (a instanceof CancellationException) {
                  continue;
               }

               var10000 = a;
               break;
            }

            var10000 = null;
            break;
         }

         a = (Throwable)var10000;
         if (a != null) {
            return a;
         } else {
            Throwable a = (Throwable)a.get(0);
            if (a instanceof TimeoutCancellationException) {
               Iterable a = (Iterable)a;
               int a = false;
               Iterator var16 = a.iterator();

               while(true) {
                  if (!var16.hasNext()) {
                     var10000 = null;
                     break;
                  }

                  Object a = var16.next();
                  Throwable a = (Throwable)a;
                  int a = false;
                  if (a != a && a instanceof TimeoutCancellationException) {
                     var10000 = a;
                     break;
                  }
               }

               Throwable a = (Throwable)var10000;
               if (a != null) {
                  return a;
               }
            }

            return a;
         }
      }
   }

   private final void addSuppressedExceptions(Throwable a, List<? extends Throwable> a) {
      if (a.size() > 1) {
         int a = a.size();
         int a = false;
         Set a = Collections.newSetFromMap((Map)(new IdentityHashMap(a)));
         a = false;
         Throwable a = !DebugKt.getRECOVER_STACK_TRACES() ? a : StackTraceRecoveryKt.unwrapImpl(a);
         Iterator var11 = a.iterator();

         while(var11.hasNext()) {
            Throwable a = (Throwable)var11.next();
            int a = false;
            Throwable a = !DebugKt.getRECOVER_STACK_TRACES() ? a : StackTraceRecoveryKt.unwrapImpl(a);
            if (a != a && a != a && !(a instanceof CancellationException) && a.add(a)) {
               int a = false;
               kotlin.ExceptionsKt.addSuppressed(a, a);
            }
         }

      }
   }

   private final boolean tryFinalizeSimpleState(Incomplete a, Object a) {
      boolean a;
      if (DebugKt.getASSERTIONS_ENABLED()) {
         a = false;
         if (!(a instanceof Empty) && !(a instanceof JobNode)) {
            throw new AssertionError();
         }
      }

      if (DebugKt.getASSERTIONS_ENABLED()) {
         a = false;
         if (a instanceof CompletedExceptionally) {
            throw new AssertionError();
         }
      }

      if (!_state$FU.compareAndSet(a, a, JobSupportKt.boxIncomplete(a))) {
         return false;
      } else {
         a.onCancelling((Throwable)null);
         a.onCompletionInternal(a);
         a.completeStateFinalization(a, a);
         return true;
      }
   }

   private final void completeStateFinalization(Incomplete a, Object a) {
      ChildHandle var10000 = a.getParentHandle$kotlinx_coroutines_core();
      if (var10000 != null) {
         ChildHandle a = var10000;
         int a = false;
         a.dispose();
         a.setParentHandle$kotlinx_coroutines_core((ChildHandle)NonDisposableHandle.INSTANCE);
      }

      Throwable a = (a instanceof CompletedExceptionally ? (CompletedExceptionally)a : null) != null ? (a instanceof CompletedExceptionally ? (CompletedExceptionally)a : null).cause : null;
      if (a instanceof JobNode) {
         try {
            ((JobNode)a).invoke(a);
         } catch (Throwable var7) {
            a.handleOnCompletionException$kotlinx_coroutines_core((Throwable)(new CompletionHandlerException("Exception in completion handler " + a + " for " + a, var7)));
         }
      } else {
         NodeList var8 = a.getList();
         if (var8 != null) {
            a.notifyCompletion(var8, a);
         }
      }

   }

   private final void notifyCancelling(NodeList a, Throwable a) {
      a.onCancelling(a);
      JobSupport a = a;
      int a = false;
      Object a = null;
      LockFreeLinkedListHead a = (LockFreeLinkedListHead)a;
      int a = false;

      Throwable var10000;
      for(LockFreeLinkedListNode a = (LockFreeLinkedListNode)a.getNext(); !Intrinsics.areEqual((Object)a, (Object)a); a = a.getNextNode()) {
         if (a instanceof JobCancellingNode) {
            JobNode a = (JobNode)a;
            boolean var10 = false;

            try {
               a.invoke(a);
            } catch (Throwable var17) {
               var10000 = (Throwable)a;
               boolean a;
               if ((Throwable)a != null) {
                  Throwable var12 = var10000;
                  a = false;
                  int a = false;
                  kotlin.ExceptionsKt.addSuppressed(var12, var17);
                  if (var12 != null) {
                     continue;
                  }
               }

               a = false;
               a = new CompletionHandlerException("Exception in completion handler " + a + " for " + a, var17);
               Unit var20 = Unit.INSTANCE;
            }
         }
      }

      var10000 = (Throwable)a;
      if ((Throwable)a != null) {
         Throwable a = var10000;
         int a = false;
         a.handleOnCompletionException$kotlinx_coroutines_core(a);
      }

      a.cancelParent(a);
   }

   private final boolean cancelParent(Throwable a) {
      if (a.isScopedCoroutine()) {
         return true;
      } else {
         boolean a = a instanceof CancellationException;
         ChildHandle a = a.getParentHandle$kotlinx_coroutines_core();
         if (a != null && a != NonDisposableHandle.INSTANCE) {
            return a.childCancelled(a) || a;
         } else {
            return a;
         }
      }
   }

   private final void notifyCompletion(NodeList a, Throwable a) {
      JobSupport a = a;
      int a = false;
      Object a = null;
      LockFreeLinkedListHead a = (LockFreeLinkedListHead)a;
      int a = false;

      Throwable var10000;
      for(LockFreeLinkedListNode a = (LockFreeLinkedListNode)a.getNext(); !Intrinsics.areEqual((Object)a, (Object)a); a = a.getNextNode()) {
         if (a instanceof JobNode) {
            JobNode a = (JobNode)a;
            boolean var10 = false;

            try {
               a.invoke(a);
            } catch (Throwable var17) {
               var10000 = (Throwable)a;
               boolean a;
               if ((Throwable)a != null) {
                  Throwable var12 = var10000;
                  a = false;
                  int a = false;
                  kotlin.ExceptionsKt.addSuppressed(var12, var17);
                  if (var12 != null) {
                     continue;
                  }
               }

               a = false;
               a = new CompletionHandlerException("Exception in completion handler " + a + " for " + a, var17);
               Unit var20 = Unit.INSTANCE;
            }
         }
      }

      var10000 = (Throwable)a;
      if ((Throwable)a != null) {
         Throwable a = var10000;
         int a = false;
         a.handleOnCompletionException$kotlinx_coroutines_core(a);
      }

   }

   // $FF: synthetic method
   private final <T extends JobNode> void notifyHandlers(NodeList a, Throwable a) {
      int a = false;
      Object a = null;
      LockFreeLinkedListHead a = (LockFreeLinkedListHead)a;
      int a = false;

      Throwable var10000;
      for(LockFreeLinkedListNode a = (LockFreeLinkedListNode)a.getNext(); !Intrinsics.areEqual((Object)a, (Object)a); a = a.getNextNode()) {
         Intrinsics.reifiedOperationMarker(3, "T");
         if (a instanceof LockFreeLinkedListNode) {
            JobNode a = (JobNode)a;
            boolean var9 = false;

            try {
               a.invoke(a);
            } catch (Throwable var16) {
               var10000 = (Throwable)a;
               boolean a;
               if ((Throwable)a != null) {
                  Throwable var11 = var10000;
                  Throwable a = (Throwable)var11;
                  a = false;
                  int a = false;
                  kotlin.ExceptionsKt.addSuppressed(a, var16);
                  if ((Throwable)var11 != null) {
                     continue;
                  }
               }

               JobSupport a = (JobSupport)a;
               a = false;
               a = new CompletionHandlerException("Exception in completion handler " + a + " for " + a, var16);
               Unit var20 = Unit.INSTANCE;
            }
         }
      }

      var10000 = (Throwable)a;
      if ((Throwable)a != null) {
         Throwable a = (Throwable)var10000;
         int a = false;
         a.handleOnCompletionException$kotlinx_coroutines_core(a);
      }

   }

   public final boolean start() {
      JobSupport a = a;
      boolean var2 = false;

      while(true) {
         Object a = a.getState$kotlinx_coroutines_core();
         int a = false;
         switch(a.startInternal(a)) {
         case 0:
            return false;
         case 1:
            return true;
         }
      }
   }

   private final int startInternal(Object a) {
      if (a instanceof Empty) {
         if (((Empty)a).isActive()) {
            return 0;
         } else if (!_state$FU.compareAndSet(a, a, JobSupportKt.access$getEMPTY_ACTIVE$p())) {
            return -1;
         } else {
            a.onStart();
            return 1;
         }
      } else if (a instanceof InactiveNodeList) {
         if (!_state$FU.compareAndSet(a, a, ((InactiveNodeList)a).getList())) {
            return -1;
         } else {
            a.onStart();
            return 1;
         }
      } else {
         return 0;
      }
   }

   protected void onStart() {
   }

   @NotNull
   public final CancellationException getCancellationException() {
      Object a = a.getState$kotlinx_coroutines_core();
      CancellationException var2;
      if (a instanceof JobSupport.Finishing) {
         Throwable var10000 = ((JobSupport.Finishing)a).getRootCause();
         if (var10000 == null) {
            throw new IllegalStateException(("Job is still new or active: " + a).toString());
         }

         var2 = a.toCancellationException(var10000, DebugStringsKt.getClassSimpleName(a) + " is cancelling");
         if (var2 == null) {
            throw new IllegalStateException(("Job is still new or active: " + a).toString());
         }
      } else {
         if (a instanceof Incomplete) {
            throw new IllegalStateException(("Job is still new or active: " + a).toString());
         }

         var2 = a instanceof CompletedExceptionally ? toCancellationException$default(a, ((CompletedExceptionally)a).cause, (String)null, 1, (Object)null) : (CancellationException)(new JobCancellationException(DebugStringsKt.getClassSimpleName(a) + " has completed normally", (Throwable)null, (Job)a));
      }

      return var2;
   }

   @NotNull
   protected final CancellationException toCancellationException(@NotNull Throwable a, @Nullable String a) {
      CancellationException var10000 = a instanceof CancellationException ? (CancellationException)a : null;
      if ((a instanceof CancellationException ? (CancellationException)a : null) == null) {
         int a = false;
         JobCancellationException var5 = new JobCancellationException;
         String var10002 = a;
         if (a == null) {
            var10002 = access$cancellationExceptionMessage(a);
         }

         var5.<init>(var10002, a, (Job)a);
         var10000 = (CancellationException)var5;
      }

      return var10000;
   }

   // $FF: synthetic method
   public static CancellationException toCancellationException$default(JobSupport var0, Throwable var1, String var2, int var3, Object var4) {
      if (var4 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: toCancellationException");
      } else {
         if ((var3 & 1) != 0) {
            var2 = null;
         }

         return var0.toCancellationException(var1, var2);
      }
   }

   @Nullable
   protected final Throwable getCompletionCause() {
      Object a = a.getState$kotlinx_coroutines_core();
      Throwable var10000;
      if (a instanceof JobSupport.Finishing) {
         var10000 = ((JobSupport.Finishing)a).getRootCause();
         if (var10000 == null) {
            throw new IllegalStateException(("Job is still new or active: " + a).toString());
         }
      } else {
         if (a instanceof Incomplete) {
            throw new IllegalStateException(("Job is still new or active: " + a).toString());
         }

         var10000 = a instanceof CompletedExceptionally ? ((CompletedExceptionally)a).cause : null;
      }

      return var10000;
   }

   protected final boolean getCompletionCauseHandled() {
      Object a = a.getState$kotlinx_coroutines_core();
      int a = false;
      return a instanceof CompletedExceptionally && ((CompletedExceptionally)a).getHandled();
   }

   @NotNull
   public final DisposableHandle invokeOnCompletion(@NotNull Function1<? super Throwable, Unit> a) {
      return a.invokeOnCompletion(false, true, a);
   }

   @NotNull
   public final DisposableHandle invokeOnCompletion(boolean a, boolean a, @NotNull Function1<? super Throwable, Unit> a) {
      JobNode a = a.makeNode(a, a);
      JobSupport a = a;
      boolean var6 = false;

      while(true) {
         Object a = a.getState$kotlinx_coroutines_core();
         int a = false;
         if (a instanceof Empty) {
            if (((Empty)a).isActive()) {
               if (_state$FU.compareAndSet(a, a, a)) {
                  return (DisposableHandle)a;
               }
            } else {
               a.promoteEmptyToNodeList((Empty)a);
            }
         } else {
            Throwable a;
            if (!(a instanceof Incomplete)) {
               if (a) {
                  a = (a instanceof CompletedExceptionally ? (CompletedExceptionally)a : null) != null ? (a instanceof CompletedExceptionally ? (CompletedExceptionally)a : null).cause : null;
                  int a = false;
                  a.invoke(a);
               }

               return (DisposableHandle)NonDisposableHandle.INSTANCE;
            }

            NodeList a = ((Incomplete)a).getList();
            if (a == null) {
               if (a == null) {
                  throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.JobNode");
               }

               a.promoteSingleToNodeList((JobNode)a);
            } else {
               a = null;
               Object a = null;
               a = NonDisposableHandle.INSTANCE;
               boolean a;
               if (a && a instanceof JobSupport.Finishing) {
                  int a = false;
                  synchronized(a){}

                  try {
                     label197: {
                        a = false;
                        a = ((JobSupport.Finishing)a).getRootCause();
                        if (a != null) {
                           int a = false;
                           if (!(a instanceof ChildHandleNode) || ((JobSupport.Finishing)a).isCompleting()) {
                              break label197;
                           }
                        }

                        if (!a.addLastAtomic(a, a, a)) {
                           continue;
                        }

                        if (a == null) {
                           DisposableHandle var18 = (DisposableHandle)a;
                           return var18;
                        }

                        a = a;
                     }

                     Unit var19 = Unit.INSTANCE;
                  } finally {
                     ;
                  }
               }

               if (a != null) {
                  if (a) {
                     a = false;
                     a.invoke(a);
                  }

                  return (DisposableHandle)a;
               }

               if (a.addLastAtomic(a, a, a)) {
                  return (DisposableHandle)a;
               }
            }
         }
      }
   }

   private final JobNode makeNode(Function1<? super Throwable, Unit> a, boolean a) {
      JobNode var9;
      if (a) {
         JobCancellingNode var10000 = a instanceof JobCancellingNode ? (JobCancellingNode)a : null;
         if ((a instanceof JobCancellingNode ? (JobCancellingNode)a : null) == null) {
            var10000 = (JobCancellingNode)(new InvokeOnCancelling(a));
         }

         var9 = (JobNode)var10000;
      } else {
         JobNode var4 = a instanceof JobNode ? (JobNode)a : null;
         if (var4 != null) {
            int a = false;
            if (DebugKt.getASSERTIONS_ENABLED()) {
               int a = false;
               if (var4 instanceof JobCancellingNode) {
                  throw new AssertionError();
               }
            }

            var9 = var4;
         } else {
            var9 = (JobNode)(new InvokeOnCompletion(a));
         }
      }

      JobNode a = var9;
      a.setJob(a);
      return a;
   }

   private final boolean addLastAtomic(Object a, NodeList a, JobNode a) {
      LockFreeLinkedListNode a = (LockFreeLinkedListNode)a;
      int a = false;
      int a = false;
      LockFreeLinkedListNode.CondAddOp a = (LockFreeLinkedListNode.CondAddOp)(new JobSupport$addLastAtomic$$inlined$addLastIf$1((LockFreeLinkedListNode)a, a, a));

      while(true) {
         LockFreeLinkedListNode a = a.getPrevNode();
         boolean var10000;
         switch(a.tryCondAddNext((LockFreeLinkedListNode)a, a, a)) {
         case 1:
            var10000 = true;
            return var10000;
         case 2:
            var10000 = false;
            return var10000;
         }
      }
   }

   private final void promoteEmptyToNodeList(Empty a) {
      NodeList a = new NodeList();
      Incomplete a = a.isActive() ? (Incomplete)a : (Incomplete)(new InactiveNodeList(a));
      _state$FU.compareAndSet(a, a, a);
   }

   private final void promoteSingleToNodeList(JobNode a) {
      a.addOneIfEmpty((LockFreeLinkedListNode)(new NodeList()));
      LockFreeLinkedListNode a = a.getNextNode();
      _state$FU.compareAndSet(a, a, a);
   }

   @Nullable
   public final Object join(@NotNull Continuation<? super Unit> a) {
      if (!a.joinInternal()) {
         JobKt.ensureActive(a.getContext());
         return Unit.INSTANCE;
      } else {
         Object var10000 = a.joinSuspend(a);
         return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
      }
   }

   private final boolean joinInternal() {
      JobSupport a = a;
      boolean var2 = false;

      Object a;
      do {
         a = a.getState$kotlinx_coroutines_core();
         int a = false;
         if (!(a instanceof Incomplete)) {
            return false;
         }
      } while(a.startInternal(a) < 0);

      return true;
   }

   private final Object joinSuspend(Continuation<? super Unit> a) {
      int a = false;
      int a = false;
      CancellableContinuationImpl a = new CancellableContinuationImpl(IntrinsicsKt.intercepted(a), 1);
      a.initCancellability();
      CancellableContinuation a = (CancellableContinuation)a;
      int a = false;
      CompletionHandlerBase a = (CompletionHandlerBase)(new ResumeOnCompletion((Continuation)a));
      int a = false;
      CancellableContinuationKt.disposeOnCancellation(a, a.invokeOnCompletion((Function1)a));
      Object var10000 = a.getResult();
      if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         DebugProbesKt.probeCoroutineSuspended(a);
      }

      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   @NotNull
   public final SelectClause0 getOnJoin() {
      return (SelectClause0)a;
   }

   public final <R> void registerSelectClause0(@NotNull SelectInstance<? super R> a, @NotNull Function1<? super Continuation<? super R>, ? extends Object> a) {
      JobSupport a = a;
      boolean var4 = false;

      Object a;
      do {
         a = a.getState$kotlinx_coroutines_core();
         int a = false;
         if (a.isSelected()) {
            return;
         }

         if (!(a instanceof Incomplete)) {
            if (a.trySelect()) {
               UndispatchedKt.startCoroutineUnintercepted(a, a.getCompletion());
            }

            return;
         }
      } while(a.startInternal(a) != 0);

      CompletionHandlerBase a = (CompletionHandlerBase)(new SelectJoinOnCompletion(a, a));
      int a = false;
      a.disposeOnSelect(a.invokeOnCompletion((Function1)a));
   }

   public final void removeNode$kotlinx_coroutines_core(@NotNull JobNode a) {
      JobSupport a = a;
      boolean var3 = false;

      Object a;
      do {
         a = a.getState$kotlinx_coroutines_core();
         int a = false;
         if (!(a instanceof JobNode)) {
            if (a instanceof Incomplete) {
               if (((Incomplete)a).getList() != null) {
                  a.remove();
               }

               return;
            }

            return;
         }

         if (a != a) {
            return;
         }
      } while(!_state$FU.compareAndSet(a, a, JobSupportKt.access$getEMPTY_ACTIVE$p()));

   }

   public boolean getOnCancelComplete$kotlinx_coroutines_core() {
      return false;
   }

   public void cancel(@Nullable CancellationException a) {
      CancellationException var10001 = a;
      if (a == null) {
         String a = null;
         Throwable a = null;
         int a = false;
         var10001 = (CancellationException)(new JobCancellationException(access$cancellationExceptionMessage(a), (Throwable)a, (Job)a));
      }

      a.cancelInternal((Throwable)var10001);
   }

   @NotNull
   protected String cancellationExceptionMessage() {
      return "Job was cancelled";
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Added since 1.2.0 for binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public boolean cancel(Throwable a) {
      CancellationException var10001;
      label11: {
         if (a != null) {
            var10001 = toCancellationException$default(a, a, (String)null, 1, (Object)null);
            if (var10001 != null) {
               break label11;
            }
         }

         String a = null;
         Throwable a = null;
         int a = false;
         var10001 = (CancellationException)(new JobCancellationException(access$cancellationExceptionMessage(a), (Throwable)a, (Job)a));
      }

      a.cancelInternal((Throwable)var10001);
      return true;
   }

   public void cancelInternal(@NotNull Throwable a) {
      a.cancelImpl$kotlinx_coroutines_core(a);
   }

   public final void parentCancelled(@NotNull ParentJob a) {
      a.cancelImpl$kotlinx_coroutines_core(a);
   }

   public boolean childCancelled(@NotNull Throwable a) {
      if (a instanceof CancellationException) {
         return true;
      } else {
         return a.cancelImpl$kotlinx_coroutines_core(a) && a.getHandlesException$kotlinx_coroutines_core();
      }
   }

   public final boolean cancelCoroutine(@Nullable Throwable a) {
      return a.cancelImpl$kotlinx_coroutines_core(a);
   }

   public final boolean cancelImpl$kotlinx_coroutines_core(@Nullable Object a) {
      Object a = JobSupportKt.access$getCOMPLETING_ALREADY$p();
      if (a.getOnCancelComplete$kotlinx_coroutines_core()) {
         a = a.cancelMakeCompleting(a);
         if (a == JobSupportKt.COMPLETING_WAITING_CHILDREN) {
            return true;
         }
      }

      if (a == JobSupportKt.access$getCOMPLETING_ALREADY$p()) {
         a = a.makeCancelling(a);
      }

      boolean var10000;
      if (a == JobSupportKt.access$getCOMPLETING_ALREADY$p()) {
         var10000 = true;
      } else if (a == JobSupportKt.COMPLETING_WAITING_CHILDREN) {
         var10000 = true;
      } else if (a == JobSupportKt.access$getTOO_LATE_TO_CANCEL$p()) {
         var10000 = false;
      } else {
         a.afterCompletion(a);
         var10000 = true;
      }

      return var10000;
   }

   private final Object cancelMakeCompleting(Object a) {
      JobSupport a = a;
      boolean var3 = false;

      Object a;
      do {
         Object a = a.getState$kotlinx_coroutines_core();
         int a = false;
         if (!(a instanceof Incomplete) || a instanceof JobSupport.Finishing && ((JobSupport.Finishing)a).isCompleting()) {
            return JobSupportKt.access$getCOMPLETING_ALREADY$p();
         }

         CompletedExceptionally a = new CompletedExceptionally(a.createCauseException(a), false, 2, (DefaultConstructorMarker)null);
         a = a.tryMakeCompleting(a, a);
      } while(a == JobSupportKt.access$getCOMPLETING_RETRY$p());

      return a;
   }

   @NotNull
   public final JobCancellationException defaultCancellationException$kotlinx_coroutines_core(@Nullable String a, @Nullable Throwable a) {
      int a = false;
      JobCancellationException var10000 = new JobCancellationException;
      String var10002 = a;
      if (a == null) {
         var10002 = access$cancellationExceptionMessage(a);
      }

      var10000.<init>(var10002, a, (Job)a);
      return var10000;
   }

   // $FF: synthetic method
   public static JobCancellationException defaultCancellationException$kotlinx_coroutines_core$default(JobSupport a, String a, Throwable a, int var3, Object var4) {
      if (var4 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: defaultCancellationException");
      } else {
         if ((var3 & 1) != 0) {
            a = null;
         }

         if ((var3 & 2) != 0) {
            a = null;
         }

         int a = false;
         JobCancellationException var10000 = new JobCancellationException;
         String var10002 = a;
         if (a == null) {
            var10002 = access$cancellationExceptionMessage(a);
         }

         var10000.<init>(var10002, a, (Job)a);
         return var10000;
      }
   }

   @NotNull
   public CancellationException getChildJobCancellationCause() {
      Object a = a.getState$kotlinx_coroutines_core();
      Throwable var10000;
      if (a instanceof JobSupport.Finishing) {
         var10000 = ((JobSupport.Finishing)a).getRootCause();
      } else if (a instanceof CompletedExceptionally) {
         var10000 = ((CompletedExceptionally)a).cause;
      } else {
         if (a instanceof Incomplete) {
            throw new IllegalStateException(("Cannot be cancelling child in this state: " + a).toString());
         }

         var10000 = null;
      }

      Throwable a = var10000;
      CancellationException var4 = a instanceof CancellationException ? (CancellationException)a : null;
      if ((a instanceof CancellationException ? (CancellationException)a : null) == null) {
         var4 = (CancellationException)(new JobCancellationException("Parent job is " + a.stateString(a), a, (Job)a));
      }

      return var4;
   }

   private final Throwable createCauseException(Object a) {
      Throwable var10000;
      if (a == null ? true : a instanceof Throwable) {
         var10000 = (Throwable)a;
         if ((Throwable)a == null) {
            String a = null;
            Throwable a = null;
            int a = false;
            var10000 = (Throwable)(new JobCancellationException(access$cancellationExceptionMessage(a), (Throwable)a, (Job)a));
         }
      } else {
         if (a == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.ParentJob");
         }

         var10000 = (Throwable)((ParentJob)a).getChildJobCancellationCause();
      }

      return var10000;
   }

   private final Object makeCancelling(Object a) {
      Object a = null;
      JobSupport a = a;
      boolean var4 = false;

      while(true) {
         Object a = a.getState$kotlinx_coroutines_core();
         int a = false;
         boolean a;
         Throwable var10000;
         if (a instanceof JobSupport.Finishing) {
            int a = false;
            synchronized(a){}

            boolean a;
            Throwable var18;
            try {
               a = false;
               if (((JobSupport.Finishing)a).isSealed()) {
                  Symbol var11 = JobSupportKt.access$getTOO_LATE_TO_CANCEL$p();
                  return var11;
               }

               a = ((JobSupport.Finishing)a).isCancelling();
               Throwable a;
               if (a != null || !a) {
                  var10000 = a;
                  if (a == null) {
                     Throwable var13 = a.createCauseException(a);
                     int a = false;
                     var10000 = var13;
                  }

                  a = var10000;
                  ((JobSupport.Finishing)a).addExceptionLocked(a);
               }

               a = ((JobSupport.Finishing)a).getRootCause();
               int a = false;
               var18 = !a ? a : null;
            } finally {
               ;
            }

            if (var18 != null) {
               a = false;
               a.notifyCancelling(((JobSupport.Finishing)a).getList(), var18);
            }

            return JobSupportKt.access$getCOMPLETING_ALREADY$p();
         }

         if (!(a instanceof Incomplete)) {
            return JobSupportKt.access$getTOO_LATE_TO_CANCEL$p();
         }

         var10000 = a;
         if (a == null) {
            Throwable var9 = a.createCauseException(a);
            a = false;
            a = var9;
            var10000 = var9;
         }

         Throwable a = var10000;
         if (((Incomplete)a).isActive()) {
            if (a.tryMakeCancelling((Incomplete)a, a)) {
               return JobSupportKt.access$getCOMPLETING_ALREADY$p();
            }
         } else {
            Object a = a.tryMakeCompleting(a, new CompletedExceptionally(a, false, 2, (DefaultConstructorMarker)null));
            if (a == JobSupportKt.access$getCOMPLETING_ALREADY$p()) {
               throw new IllegalStateException(("Cannot happen in " + a).toString());
            }

            if (a != JobSupportKt.access$getCOMPLETING_RETRY$p()) {
               return a;
            }
         }
      }
   }

   private final NodeList getOrPromoteCancellingList(Incomplete a) {
      NodeList var10000 = a.getList();
      if (var10000 == null) {
         if (a instanceof Empty) {
            var10000 = new NodeList();
         } else {
            if (!(a instanceof JobNode)) {
               throw new IllegalStateException(("State should have list: " + a).toString());
            }

            a.promoteSingleToNodeList((JobNode)a);
            var10000 = (NodeList)null;
         }
      }

      return var10000;
   }

   private final boolean tryMakeCancelling(Incomplete a, Throwable a) {
      boolean a;
      if (DebugKt.getASSERTIONS_ENABLED()) {
         a = false;
         if (a instanceof JobSupport.Finishing) {
            throw new AssertionError();
         }
      }

      if (DebugKt.getASSERTIONS_ENABLED()) {
         a = false;
         if (!a.isActive()) {
            throw new AssertionError();
         }
      }

      NodeList var10000 = a.getOrPromoteCancellingList(a);
      if (var10000 == null) {
         return false;
      } else {
         NodeList a = var10000;
         JobSupport.Finishing a = new JobSupport.Finishing(a, false, a);
         if (!_state$FU.compareAndSet(a, a, a)) {
            return false;
         } else {
            a.notifyCancelling(a, a);
            return true;
         }
      }
   }

   public final boolean makeCompleting$kotlinx_coroutines_core(@Nullable Object a) {
      JobSupport a = a;
      boolean var3 = false;

      Object a;
      do {
         Object a = a.getState$kotlinx_coroutines_core();
         int a = false;
         a = a.tryMakeCompleting(a, a);
         if (a == JobSupportKt.access$getCOMPLETING_ALREADY$p()) {
            return false;
         }

         if (a == JobSupportKt.COMPLETING_WAITING_CHILDREN) {
            return true;
         }
      } while(a == JobSupportKt.access$getCOMPLETING_RETRY$p());

      a.afterCompletion(a);
      return true;
   }

   @Nullable
   public final Object makeCompletingOnce$kotlinx_coroutines_core(@Nullable Object a) {
      JobSupport a = a;
      boolean var3 = false;

      Object a;
      do {
         Object a = a.getState$kotlinx_coroutines_core();
         int a = false;
         a = a.tryMakeCompleting(a, a);
         if (a == JobSupportKt.access$getCOMPLETING_ALREADY$p()) {
            throw new IllegalStateException("Job " + a + " is already complete or completing, but is being completed with " + a, a.getExceptionOrNull(a));
         }
      } while(a == JobSupportKt.access$getCOMPLETING_RETRY$p());

      return a;
   }

   private final Object tryMakeCompleting(Object a, Object a) {
      if (!(a instanceof Incomplete)) {
         return JobSupportKt.access$getCOMPLETING_ALREADY$p();
      } else if ((a instanceof Empty || a instanceof JobNode) && !(a instanceof ChildHandleNode) && !(a instanceof CompletedExceptionally)) {
         return a.tryFinalizeSimpleState((Incomplete)a, a) ? a : JobSupportKt.access$getCOMPLETING_RETRY$p();
      } else {
         return a.tryMakeCompletingSlowPath((Incomplete)a, a);
      }
   }

   private final Object tryMakeCompletingSlowPath(Incomplete a, Object a) {
      NodeList var10000 = a.getOrPromoteCancellingList(a);
      if (var10000 == null) {
         return JobSupportKt.access$getCOMPLETING_RETRY$p();
      } else {
         NodeList a = var10000;
         JobSupport.Finishing var23 = a instanceof JobSupport.Finishing ? (JobSupport.Finishing)a : null;
         if ((a instanceof JobSupport.Finishing ? (JobSupport.Finishing)a : null) == null) {
            var23 = new JobSupport.Finishing(a, false, (Throwable)null);
         }

         JobSupport.Finishing a = var23;
         Ref.ObjectRef a = new Ref.ObjectRef();
         int a = false;
         synchronized(a){}

         boolean a;
         try {
            int a = false;
            if (a.isCompleting()) {
               Symbol var17 = JobSupportKt.access$getCOMPLETING_ALREADY$p();
               return var17;
            }

            a.setCompleting(true);
            if (a != a && !_state$FU.compareAndSet(a, a, a)) {
               Symbol var16 = JobSupportKt.access$getCOMPLETING_RETRY$p();
               return var16;
            }

            if (DebugKt.getASSERTIONS_ENABLED()) {
               a = false;
               if (a.isSealed()) {
                  throw new AssertionError();
               }
            }

            a = a.isCancelling();
            CompletedExceptionally var24 = a instanceof CompletedExceptionally ? (CompletedExceptionally)a : null;
            if ((a instanceof CompletedExceptionally ? (CompletedExceptionally)a : null) != null) {
               CompletedExceptionally a = var24;
               int a = false;
               a.addExceptionLocked(a.cause);
            }

            Throwable var12 = a.getRootCause();
            int a = false;
            a.element = Boolean.valueOf(!a) ? var12 : null;
            Unit var15 = Unit.INSTANCE;
         } finally {
            ;
         }

         Throwable var25 = (Throwable)a.element;
         if (var25 != null) {
            Throwable a = var25;
            a = false;
            a.notifyCancelling(a, a);
         }

         ChildHandleNode a = a.firstChild(a);
         if (a != null && a.tryWaitForChild(a, a, a)) {
            return JobSupportKt.COMPLETING_WAITING_CHILDREN;
         } else {
            return a.finalizeFinishingState(a, a);
         }
      }
   }

   private final Throwable getExceptionOrNull(Object a) {
      return (a instanceof CompletedExceptionally ? (CompletedExceptionally)a : null) != null ? (a instanceof CompletedExceptionally ? (CompletedExceptionally)a : null).cause : null;
   }

   private final ChildHandleNode firstChild(Incomplete a) {
      ChildHandleNode var10000 = a instanceof ChildHandleNode ? (ChildHandleNode)a : null;
      if ((a instanceof ChildHandleNode ? (ChildHandleNode)a : null) == null) {
         NodeList var2 = a.getList();
         var10000 = var2 != null ? a.nextChild((LockFreeLinkedListNode)var2) : null;
      }

      return var10000;
   }

   private final boolean tryWaitForChild(JobSupport.Finishing a, ChildHandleNode a, Object a) {
      JobSupport var4 = a;
      JobSupport.Finishing var5 = a;
      ChildHandleNode var6 = a;
      Object var7 = a;

      while(true) {
         Job var10000 = (Job)var6.childJob;
         CompletionHandlerBase a = (CompletionHandlerBase)(new JobSupport.ChildCompletion(var4, var5, var6, var7));
         int a = false;
         DisposableHandle a = Job.DefaultImpls.invokeOnCompletion$default(var10000, false, false, (Function1)a, 1, (Object)null);
         if (a != NonDisposableHandle.INSTANCE) {
            return true;
         }

         ChildHandleNode var16 = var4.nextChild((LockFreeLinkedListNode)var6);
         if (var16 == null) {
            return false;
         }

         ChildHandleNode a = var16;
         var4 = var4;
         var5 = var5;
         var6 = a;
         var7 = var7;
      }
   }

   private final void continueCompleting(JobSupport.Finishing a, ChildHandleNode a, Object a) {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a.getState$kotlinx_coroutines_core() != a) {
            throw new AssertionError();
         }
      }

      ChildHandleNode a = a.nextChild((LockFreeLinkedListNode)a);
      if (a == null || !a.tryWaitForChild(a, a, a)) {
         Object a = a.finalizeFinishingState(a, a);
         a.afterCompletion(a);
      }
   }

   private final ChildHandleNode nextChild(LockFreeLinkedListNode a) {
      LockFreeLinkedListNode a;
      for(a = a; a.isRemoved(); a = a.getPrevNode()) {
      }

      do {
         do {
            a = a.getNextNode();
         } while(a.isRemoved());

         if (a instanceof ChildHandleNode) {
            return (ChildHandleNode)a;
         }
      } while(!(a instanceof NodeList));

      return null;
   }

   @NotNull
   public final Sequence<Job> getChildren() {
      return SequencesKt.sequence((Function2)(new Function2<SequenceScope<? super Job>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         Object L$2;
         int label;
         // $FF: synthetic field
         private Object L$0;

         @Nullable
         public final Object invokeSuspend(@NotNull Object axx) {
            Object var11 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            SequenceScope axxx;
            boolean axxxxxx;
            LockFreeLinkedListHead axxxxxxx;
            boolean axxxxxxxx;
            LockFreeLinkedListNode axxxxxxxxx;
            boolean axxxxxxxxxxx;
            ChildJob var10001;
            switch(ax.label) {
            case 0:
               ResultKt.throwOnFailure(axx);
               axxx = (SequenceScope)ax.L$0;
               Object axxxx = a.getState$kotlinx_coroutines_core();
               if (axxxx instanceof ChildHandleNode) {
                  var10001 = ((ChildHandleNode)axxxx).childJob;
                  Continuation var10002 = (Continuation)ax;
                  ax.label = 1;
                  if (axxx.yield(var10001, var10002) == var11) {
                     return var11;
                  }

                  return Unit.INSTANCE;
               }

               if (!(axxxx instanceof Incomplete)) {
                  return Unit.INSTANCE;
               }

               NodeList var10000 = ((Incomplete)axxxx).getList();
               if (var10000 == null) {
                  return Unit.INSTANCE;
               }

               NodeList axxxxx = var10000;
               axxxxxx = false;
               axxxxxxx = (LockFreeLinkedListHead)axxxxx;
               axxxxxxxx = false;
               axxxxxxxxx = (LockFreeLinkedListNode)axxxxxxx.getNext();
               break;
            case 1:
               ResultKt.throwOnFailure(axx);
               return Unit.INSTANCE;
            case 2:
               axxxxxx = false;
               axxxxxxxx = false;
               axxxxxxxxxxx = false;
               axxxxxxxxx = (LockFreeLinkedListNode)ax.L$2;
               axxxxxxx = (LockFreeLinkedListHead)ax.L$1;
               axxx = (SequenceScope)ax.L$0;
               ResultKt.throwOnFailure(axx);
               axxxxxxxxx = axxxxxxxxx.getNextNode();
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            for(; !Intrinsics.areEqual((Object)axxxxxxxxx, (Object)axxxxxxx); axxxxxxxxx = axxxxxxxxx.getNextNode()) {
               if (axxxxxxxxx instanceof ChildHandleNode) {
                  ChildHandleNode axxxxxxxxxx = (ChildHandleNode)axxxxxxxxx;
                  axxxxxxxxxxx = false;
                  var10001 = axxxxxxxxxx.childJob;
                  ax.L$0 = axxx;
                  ax.L$1 = axxxxxxx;
                  ax.L$2 = axxxxxxxxx;
                  ax.label = 2;
                  if (axxx.yield(var10001, ax) == var11) {
                     return var11;
                  }
               }
            }

            return Unit.INSTANCE;
         }

         @NotNull
         public final Continuation<Unit> create(@Nullable Object axx, @NotNull Continuation<?> axxx) {
            Function2 var3 = new <anonymous constructor>(axxx);
            var3.L$0 = axx;
            return (Continuation)var3;
         }

         @Nullable
         public final Object invoke(@NotNull SequenceScope<? super Job> axx, @Nullable Continuation<? super Unit> axxx) {
            return ((<undefinedtype>)ax.create(axx, axxx)).invokeSuspend(Unit.INSTANCE);
         }
      }));
   }

   @NotNull
   public final ChildHandle attachChild(@NotNull ChildJob a) {
      Job var10000 = (Job)a;
      CompletionHandlerBase a = (CompletionHandlerBase)(new ChildHandleNode(a));
      int a = false;
      return (ChildHandle)Job.DefaultImpls.invokeOnCompletion$default(var10000, true, false, (Function1)a, 2, (Object)null);
   }

   public void handleOnCompletionException$kotlinx_coroutines_core(@NotNull Throwable a) {
      throw a;
   }

   protected void onCancelling(@Nullable Throwable a1) {
   }

   protected boolean isScopedCoroutine() {
      return false;
   }

   public boolean getHandlesException$kotlinx_coroutines_core() {
      return true;
   }

   protected boolean handleJobException(@NotNull Throwable a1) {
      return false;
   }

   protected void onCompletionInternal(@Nullable Object a1) {
   }

   protected void afterCompletion(@Nullable Object a1) {
   }

   @NotNull
   public String toString() {
      return a.toDebugString() + '@' + DebugStringsKt.getHexAddress(a);
   }

   @InternalCoroutinesApi
   @NotNull
   public final String toDebugString() {
      return a.nameString$kotlinx_coroutines_core() + '{' + a.stateString(a.getState$kotlinx_coroutines_core()) + '}';
   }

   @NotNull
   public String nameString$kotlinx_coroutines_core() {
      return DebugStringsKt.getClassSimpleName(a);
   }

   private final String stateString(Object a) {
      return a instanceof JobSupport.Finishing ? (((JobSupport.Finishing)a).isCancelling() ? "Cancelling" : (((JobSupport.Finishing)a).isCompleting() ? "Completing" : "Active")) : (a instanceof Incomplete ? (((Incomplete)a).isActive() ? "Active" : "New") : (a instanceof CompletedExceptionally ? "Cancelled" : "Completed"));
   }

   private final boolean isCancelling(Incomplete a) {
      return a instanceof JobSupport.Finishing && ((JobSupport.Finishing)a).isCancelling();
   }

   public final boolean isCompletedExceptionally() {
      return a.getState$kotlinx_coroutines_core() instanceof CompletedExceptionally;
   }

   @Nullable
   public final Throwable getCompletionExceptionOrNull() {
      Object a = a.getState$kotlinx_coroutines_core();
      if (a instanceof Incomplete) {
         int a = false;
         String var3 = "This job has not completed yet";
         throw new IllegalStateException(var3.toString());
      } else {
         return a.getExceptionOrNull(a);
      }
   }

   @Nullable
   public final Object getCompletedInternal$kotlinx_coroutines_core() {
      Object a = a.getState$kotlinx_coroutines_core();
      if (a instanceof Incomplete) {
         int a = false;
         String var3 = "This job has not completed yet";
         throw new IllegalStateException(var3.toString());
      } else if (a instanceof CompletedExceptionally) {
         throw ((CompletedExceptionally)a).cause;
      } else {
         return JobSupportKt.unboxState(a);
      }
   }

   @Nullable
   public final Object awaitInternal$kotlinx_coroutines_core(@NotNull Continuation<Object> a) {
      Object a;
      do {
         a = a.getState$kotlinx_coroutines_core();
         if (!(a instanceof Incomplete)) {
            if (a instanceof CompletedExceptionally) {
               Throwable a = ((CompletedExceptionally)a).cause;
               int a = false;
               if (!DebugKt.getRECOVER_STACK_TRACES()) {
                  throw a;
               }

               int a = false;
               if (!(a instanceof CoroutineStackFrame)) {
                  throw a;
               }

               throw StackTraceRecoveryKt.access$recoverFromStackFrame(a, (CoroutineStackFrame)a);
            }

            return JobSupportKt.unboxState(a);
         }
      } while(a.startInternal(a) < 0);

      return a.awaitSuspend(a);
   }

   private final Object awaitSuspend(Continuation<Object> a) {
      int a = false;
      JobSupport.AwaitContinuation a = new JobSupport.AwaitContinuation(IntrinsicsKt.intercepted(a), a);
      a.initCancellability();
      CancellableContinuation var10000 = (CancellableContinuation)a;
      CompletionHandlerBase a = (CompletionHandlerBase)(new ResumeAwaitOnCompletion((CancellableContinuationImpl)a));
      int a = false;
      CancellableContinuationKt.disposeOnCancellation(var10000, a.invokeOnCompletion((Function1)a));
      Object var7 = a.getResult();
      if (var7 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         DebugProbesKt.probeCoroutineSuspended(a);
      }

      return var7;
   }

   public final <T, R> void registerSelectClause1Internal$kotlinx_coroutines_core(@NotNull SelectInstance<? super R> a, @NotNull Function2<? super T, ? super Continuation<? super R>, ? extends Object> a) {
      JobSupport a = a;
      boolean var4 = false;

      Object a;
      do {
         a = a.getState$kotlinx_coroutines_core();
         int a = false;
         if (a.isSelected()) {
            return;
         }

         if (!(a instanceof Incomplete)) {
            if (a.trySelect()) {
               if (a instanceof CompletedExceptionally) {
                  a.resumeSelectWithException(((CompletedExceptionally)a).cause);
               } else {
                  UndispatchedKt.startCoroutineUnintercepted(a, JobSupportKt.unboxState(a), a.getCompletion());
               }
            }

            return;
         }
      } while(a.startInternal(a) != 0);

      CompletionHandlerBase a = (CompletionHandlerBase)(new SelectAwaitOnCompletion(a, a));
      int a = false;
      a.disposeOnSelect(a.invokeOnCompletion((Function1)a));
   }

   public final <T, R> void selectAwaitCompletion$kotlinx_coroutines_core(@NotNull SelectInstance<? super R> a, @NotNull Function2<? super T, ? super Continuation<? super R>, ? extends Object> a) {
      Object a = a.getState$kotlinx_coroutines_core();
      if (a instanceof CompletedExceptionally) {
         a.resumeSelectWithException(((CompletedExceptionally)a).cause);
      } else {
         CancellableKt.startCoroutineCancellable$default(a, JobSupportKt.unboxState(a), a.getCompletion(), (Function1)null, 4, (Object)null);
      }

   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public void cancel() {
      Job.DefaultImpls.cancel(a);
   }

   /** @deprecated */
   @Deprecated(
      message = "Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.",
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public Job plus(@NotNull Job a) {
      return Job.DefaultImpls.plus(a, (Job)a);
   }

   @NotNull
   public CoroutineContext plus(@NotNull CoroutineContext a) {
      return Job.DefaultImpls.plus(a, (CoroutineContext)a);
   }

   public <R> R fold(R a, @NotNull Function2<? super R, ? super CoroutineContext.Element, ? extends R> a) {
      return Job.DefaultImpls.fold(a, a, a);
   }

   @Nullable
   public <E extends CoroutineContext.Element> E get(@NotNull CoroutineContext.Key<E> a) {
      return Job.DefaultImpls.get(a, a);
   }

   @NotNull
   public CoroutineContext minusKey(@NotNull CoroutineContext.Key<?> a) {
      return Job.DefaultImpls.minusKey(a, a);
   }

   // $FF: synthetic method
   public static final Object access$joinSuspend(JobSupport a, Continuation a) {
      return a.joinSuspend(a);
   }

   // $FF: synthetic method
   public static final String access$cancellationExceptionMessage(JobSupport a) {
      return a.cancellationExceptionMessage();
   }

   // $FF: synthetic method
   public static final Object access$awaitSuspend(JobSupport a, Continuation a) {
      return a.awaitSuspend(a);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0013\n\u0002\u0018\u0002\n\u0002\u0018\u0002\b\u0002\u0018\u00002\u00060\u0018j\u0002`,2\u00020-B!\u0012\u0006\u0010\u0002\u001a\u00020\u0001\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u0015\u0010\u000b\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\u0005¢\u0006\u0004\b\u000b\u0010\fJ\u001f\u0010\u000f\u001a\u0012\u0012\u0004\u0012\u00020\u00050\rj\b\u0012\u0004\u0012\u00020\u0005`\u000eH\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u001d\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00050\u00122\b\u0010\u0011\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u0013\u0010\u0014J\u000f\u0010\u0016\u001a\u00020\u0015H\u0016¢\u0006\u0004\b\u0016\u0010\u0017R(\u0010\u001e\u001a\u0004\u0018\u00010\u00182\b\u0010\u0019\u001a\u0004\u0018\u00010\u00188B@BX\u0082\u000e¢\u0006\f\u001a\u0004\b\u001a\u0010\u001b\"\u0004\b\u001c\u0010\u001dR\u0014\u0010\u001f\u001a\u00020\u00038VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001f\u0010 R\u0011\u0010!\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\b!\u0010 R$\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0019\u001a\u00020\u00038F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u0004\u0010 \"\u0004\b\"\u0010#R\u0011\u0010$\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\b$\u0010 R\u001a\u0010\u0002\u001a\u00020\u00018\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u0002\u0010%\u001a\u0004\b&\u0010'R(\u0010\u0006\u001a\u0004\u0018\u00010\u00052\b\u0010\u0019\u001a\u0004\u0018\u00010\u00058F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b(\u0010)\"\u0004\b*\u0010\f¨\u0006+"},
      d2 = {"Lkotlinx/coroutines/JobSupport$Finishing;", "Lkotlinx/coroutines/NodeList;", "list", "", "isCompleting", "", "rootCause", "JobSupport$Finishing", "(Lkotlinx/coroutines/NodeList;ZLjava/lang/Throwable;)V", "exception", "", "addExceptionLocked", "(Ljava/lang/Throwable;)V", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "allocateList", "()Ljava/util/ArrayList;", "proposedException", "", "sealLocked", "(Ljava/lang/Throwable;)Ljava/util/List;", "", "toString", "()Ljava/lang/String;", "", "value", "getExceptionsHolder", "()Ljava/lang/Object;", "setExceptionsHolder", "(Ljava/lang/Object;)V", "exceptionsHolder", "isActive", "()Z", "isCancelling", "setCompleting", "(Z)V", "isSealed", "Lkotlinx/coroutines/NodeList;", "getList", "()Lkotlinx/coroutines/NodeList;", "getRootCause", "()Ljava/lang/Throwable;", "setRootCause", "kotlinx-coroutines-core", "Lkotlinx/coroutines/internal/SynchronizedObject;", "Lkotlinx/coroutines/Incomplete;"}
   )
   private static final class Finishing implements Incomplete {
      @NotNull
      private final NodeList list;
      // $FF: synthetic field
      @NotNull
      private volatile int _isCompleting;
      // $FF: synthetic field
      @NotNull
      private volatile Object _rootCause;
      // $FF: synthetic field
      @NotNull
      private volatile Object _exceptionsHolder;

      public Finishing(@NotNull NodeList a, boolean a, @Nullable Throwable a) {
         a.list = a;
         a._isCompleting = a;
         a._rootCause = a;
         a._exceptionsHolder = null;
      }

      @NotNull
      public NodeList getList() {
         return a.list;
      }

      public final boolean isCompleting() {
         return (boolean)a._isCompleting;
      }

      public final void setCompleting(boolean a) {
         a._isCompleting = a;
      }

      @Nullable
      public final Throwable getRootCause() {
         return (Throwable)a._rootCause;
      }

      public final void setRootCause(@Nullable Throwable a) {
         a._rootCause = a;
      }

      private final Object getExceptionsHolder() {
         return a._exceptionsHolder;
      }

      private final void setExceptionsHolder(Object a) {
         a._exceptionsHolder = a;
      }

      public final boolean isSealed() {
         return a.getExceptionsHolder() == JobSupportKt.access$getSEALED$p();
      }

      public final boolean isCancelling() {
         return a.getRootCause() != null;
      }

      public boolean isActive() {
         return a.getRootCause() == null;
      }

      @NotNull
      public final List<Throwable> sealLocked(@Nullable Throwable a) {
         Object a = a.getExceptionsHolder();
         ArrayList var10000;
         boolean a;
         if (a == null) {
            var10000 = a.allocateList();
         } else if (a instanceof Throwable) {
            ArrayList var4 = a.allocateList();
            a = false;
            var4.add(a);
            var10000 = var4;
         } else {
            if (!(a instanceof ArrayList)) {
               throw new IllegalStateException(("State is " + a).toString());
            }

            var10000 = (ArrayList)a;
         }

         ArrayList a = var10000;
         Throwable a = a.getRootCause();
         if (a != null) {
            a = false;
            a.add(0, a);
         }

         if (a != null && !Intrinsics.areEqual((Object)a, (Object)a)) {
            a.add(a);
         }

         a.setExceptionsHolder(JobSupportKt.access$getSEALED$p());
         return (List)a;
      }

      public final void addExceptionLocked(@NotNull Throwable a) {
         Throwable a = a.getRootCause();
         if (a == null) {
            a.setRootCause(a);
         } else if (a != a) {
            Object a = a.getExceptionsHolder();
            if (a == null) {
               a.setExceptionsHolder(a);
            } else if (a instanceof Throwable) {
               if (a == a) {
                  return;
               }

               ArrayList var4 = a.allocateList();
               int a = false;
               var4.add(a);
               var4.add(a);
               a.setExceptionsHolder(var4);
            } else {
               if (!(a instanceof ArrayList)) {
                  throw new IllegalStateException(("State is " + a).toString());
               }

               ((ArrayList)a).add(a);
            }

         }
      }

      private final ArrayList<Throwable> allocateList() {
         return new ArrayList(4);
      }

      @NotNull
      public String toString() {
         return "Finishing[cancelling=" + a.isCancelling() + ", completing=" + a.isCompleting() + ", rootCause=" + a.getRootCause() + ", exceptions=" + a.getExceptionsHolder() + ", list=" + a.getList() + ']';
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0003\n\u0000\b\u0002\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\b\u0010\b\u001a\u0004\u0018\u00010\t¢\u0006\u0002\u0010\nJ\u0013\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0096\u0002R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000f"},
      d2 = {"Lkotlinx/coroutines/JobSupport$ChildCompletion;", "Lkotlinx/coroutines/JobNode;", "parent", "Lkotlinx/coroutines/JobSupport;", "state", "Lkotlinx/coroutines/JobSupport$Finishing;", "child", "Lkotlinx/coroutines/ChildHandleNode;", "proposedUpdate", "", "(Lkotlinx/coroutines/JobSupport;Lkotlinx/coroutines/JobSupport$Finishing;Lkotlinx/coroutines/ChildHandleNode;Ljava/lang/Object;)V", "invoke", "", "cause", "", "kotlinx-coroutines-core"}
   )
   private static final class ChildCompletion extends JobNode {
      @NotNull
      private final JobSupport parent;
      @NotNull
      private final JobSupport.Finishing state;
      @NotNull
      private final ChildHandleNode child;
      @Nullable
      private final Object proposedUpdate;

      public ChildCompletion(@NotNull JobSupport a, @NotNull JobSupport.Finishing a, @NotNull ChildHandleNode a, @Nullable Object a) {
         a.parent = a;
         a.state = a;
         a.child = a;
         a.proposedUpdate = a;
      }

      public void invoke(@Nullable Throwable a1) {
         a.parent.continueCompleting(a.state, a.child, a.proposedUpdate);
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0002\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B\u001b\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0016J\b\u0010\f\u001a\u00020\rH\u0014R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"},
      d2 = {"Lkotlinx/coroutines/JobSupport$AwaitContinuation;", "T", "Lkotlinx/coroutines/CancellableContinuationImpl;", "delegate", "Lkotlin/coroutines/Continuation;", "job", "Lkotlinx/coroutines/JobSupport;", "(Lkotlin/coroutines/Continuation;Lkotlinx/coroutines/JobSupport;)V", "getContinuationCancellationCause", "", "parent", "Lkotlinx/coroutines/Job;", "nameString", "", "kotlinx-coroutines-core"}
   )
   private static final class AwaitContinuation<T> extends CancellableContinuationImpl<T> {
      @NotNull
      private final JobSupport job;

      public AwaitContinuation(@NotNull Continuation<? super T> a, @NotNull JobSupport a) {
         super(a, 1);
         a.job = a;
      }

      @NotNull
      public Throwable getContinuationCancellationCause(@NotNull Job a) {
         Object a = a.job.getState$kotlinx_coroutines_core();
         if (a instanceof JobSupport.Finishing) {
            Throwable var3 = ((JobSupport.Finishing)a).getRootCause();
            if (var3 != null) {
               int a = false;
               return var3;
            }
         }

         return a instanceof CompletedExceptionally ? ((CompletedExceptionally)a).cause : (Throwable)a.getCancellationException();
      }

      @NotNull
      protected String nameString() {
         return "AwaitContinuation";
      }
   }
}
