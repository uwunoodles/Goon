package kotlinx.coroutines;

import java.util.concurrent.locks.LockSupport;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0002\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\b¢\u0006\u0002\u0010\tJ\u0012\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0014J\u000b\u0010\u0011\u001a\u00028\u0000¢\u0006\u0002\u0010\u0012R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\n\u001a\u00020\u000b8TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\f¨\u0006\u0013"},
   d2 = {"Lkotlinx/coroutines/BlockingCoroutine;", "T", "Lkotlinx/coroutines/AbstractCoroutine;", "parentContext", "Lkotlin/coroutines/CoroutineContext;", "blockedThread", "Ljava/lang/Thread;", "eventLoop", "Lkotlinx/coroutines/EventLoop;", "(Lkotlin/coroutines/CoroutineContext;Ljava/lang/Thread;Lkotlinx/coroutines/EventLoop;)V", "isScopedCoroutine", "", "()Z", "afterCompletion", "", "state", "", "joinBlocking", "()Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
final class BlockingCoroutine<T> extends AbstractCoroutine<T> {
   @NotNull
   private final Thread blockedThread;
   @Nullable
   private final EventLoop eventLoop;

   public BlockingCoroutine(@NotNull CoroutineContext a, @NotNull Thread a, @Nullable EventLoop a) {
      super(a, true, true);
      a.blockedThread = a;
      a.eventLoop = a;
   }

   protected boolean isScopedCoroutine() {
      return true;
   }

   protected void afterCompletion(@Nullable Object a1) {
      if (!Intrinsics.areEqual((Object)Thread.currentThread(), (Object)a.blockedThread)) {
         Thread var2 = a.blockedThread;
         AbstractTimeSource var10000 = AbstractTimeSourceKt.getTimeSource();
         Unit var3;
         if (var10000 != null) {
            var10000.unpark(var2);
            var3 = Unit.INSTANCE;
         } else {
            var3 = null;
         }

         if (var3 == null) {
            LockSupport.unpark(var2);
         }
      }

   }

   public final T joinBlocking() {
      AbstractTimeSource var10000 = AbstractTimeSourceKt.getTimeSource();
      if (var10000 != null) {
         var10000.registerTimeLoopThread();
      }

      try {
         EventLoop var14 = a.eventLoop;
         if (var14 != null) {
            EventLoop.incrementUseCount$default(var14, false, 1, (Object)null);
         }

         try {
            label244: {
               while(!Thread.interrupted()) {
                  var14 = a.eventLoop;
                  long a = var14 != null ? var14.processNextEvent() : Long.MAX_VALUE;
                  if (a.isCompleted()) {
                     break label244;
                  }

                  var10000 = AbstractTimeSourceKt.getTimeSource();
                  Unit var15;
                  if (var10000 != null) {
                     var10000.parkNanos(a, a);
                     var15 = Unit.INSTANCE;
                  } else {
                     var15 = null;
                  }

                  if (var15 == null) {
                     LockSupport.parkNanos(a, a);
                  }
               }

               InterruptedException var12 = new InterruptedException();
               int a = false;
               a.cancelCoroutine((Throwable)var12);
               throw (Throwable)var12;
            }
         } finally {
            var14 = a.eventLoop;
            if (var14 != null) {
               EventLoop.decrementUseCount$default(var14, false, 1, (Object)null);
            }

         }
      } finally {
         var10000 = AbstractTimeSourceKt.getTimeSource();
         if (var10000 != null) {
            var10000.unregisterTimeLoopThread();
         }

      }

      Object a = JobSupportKt.unboxState(a.getState$kotlinx_coroutines_core());
      CompletedExceptionally var2 = a instanceof CompletedExceptionally ? (CompletedExceptionally)a : null;
      if (var2 != null) {
         int a = false;
         throw var2.cause;
      } else {
         return a;
      }
   }
}
