package kotlinx.coroutines;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u000b\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001BZ\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0001\u0012\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u0012%\b\u0002\u0010\u0005\u001a\u001f\u0012\u0013\u0012\u00110\u0007¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\u0006\u0012\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0001\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u0007¢\u0006\u0002\u0010\u000eJ\u000b\u0010\u0013\u001a\u0004\u0018\u00010\u0001HÆ\u0003J\u000b\u0010\u0014\u001a\u0004\u0018\u00010\u0004HÆ\u0003J&\u0010\u0015\u001a\u001f\u0012\u0013\u0012\u00110\u0007¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\u0006HÆ\u0003J\u000b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÆ\u0003J\u000b\u0010\u0017\u001a\u0004\u0018\u00010\u0007HÆ\u0003J`\u0010\u0018\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00012\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00042%\b\u0002\u0010\u0005\u001a\u001f\u0012\u0013\u0012\u00110\u0007¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\u00062\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u00012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u0007HÆ\u0001J\u0013\u0010\u0019\u001a\u00020\u00102\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001b\u001a\u00020\u001cHÖ\u0001J\u001a\u0010\u001d\u001a\u00020\u000b2\n\u0010\u001e\u001a\u0006\u0012\u0002\b\u00030\u001f2\u0006\u0010\n\u001a\u00020\u0007J\t\u0010 \u001a\u00020!HÖ\u0001R\u0012\u0010\r\u001a\u0004\u0018\u00010\u00078\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\u0003\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u000f\u001a\u00020\u00108F¢\u0006\u0006\u001a\u0004\b\u0011\u0010\u0012R\u0012\u0010\f\u001a\u0004\u0018\u00010\u00018\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R-\u0010\u0005\u001a\u001f\u0012\u0013\u0012\u00110\u0007¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\u00068\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\u0002\u001a\u0004\u0018\u00010\u00018\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\""},
   d2 = {"Lkotlinx/coroutines/CompletedContinuation;", "", "result", "cancelHandler", "Lkotlinx/coroutines/CancelHandler;", "onCancellation", "Lkotlin/Function1;", "", "Lkotlin/ParameterName;", "name", "cause", "", "idempotentResume", "cancelCause", "(Ljava/lang/Object;Lkotlinx/coroutines/CancelHandler;Lkotlin/jvm/functions/Function1;Ljava/lang/Object;Ljava/lang/Throwable;)V", "cancelled", "", "getCancelled", "()Z", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "other", "hashCode", "", "invokeHandlers", "cont", "Lkotlinx/coroutines/CancellableContinuationImpl;", "toString", "", "kotlinx-coroutines-core"}
)
final class CompletedContinuation {
   @JvmField
   @Nullable
   public final Object result;
   @JvmField
   @Nullable
   public final CancelHandler cancelHandler;
   @JvmField
   @Nullable
   public final Function1<Throwable, Unit> onCancellation;
   @JvmField
   @Nullable
   public final Object idempotentResume;
   @JvmField
   @Nullable
   public final Throwable cancelCause;

   public CompletedContinuation(@Nullable Object a, @Nullable CancelHandler a, @Nullable Function1<? super Throwable, Unit> a, @Nullable Object a, @Nullable Throwable a) {
      a.result = a;
      a.cancelHandler = a;
      a.onCancellation = a;
      a.idempotentResume = a;
      a.cancelCause = a;
   }

   // $FF: synthetic method
   public CompletedContinuation(Object var1, CancelHandler var2, Function1 var3, Object var4, Throwable var5, int var6, DefaultConstructorMarker var7) {
      if ((var6 & 2) != 0) {
         var2 = null;
      }

      if ((var6 & 4) != 0) {
         var3 = null;
      }

      if ((var6 & 8) != 0) {
         var4 = null;
      }

      if ((var6 & 16) != 0) {
         var5 = null;
      }

      this(var1, var2, var3, var4, var5);
   }

   public final boolean getCancelled() {
      return a.cancelCause != null;
   }

   public final void invokeHandlers(@NotNull CancellableContinuationImpl<?> a, @NotNull Throwable a) {
      CancelHandler var10000 = a.cancelHandler;
      boolean a;
      if (var10000 != null) {
         CancelHandler a = var10000;
         a = false;
         a.callCancelHandler(a, a);
      }

      Function1 var5 = a.onCancellation;
      if (var5 != null) {
         Function1 a = var5;
         a = false;
         a.callOnCancellation(a, a);
      }

   }

   @Nullable
   public final Object component1() {
      return a.result;
   }

   @Nullable
   public final CancelHandler component2() {
      return a.cancelHandler;
   }

   @Nullable
   public final Function1<Throwable, Unit> component3() {
      return a.onCancellation;
   }

   @Nullable
   public final Object component4() {
      return a.idempotentResume;
   }

   @Nullable
   public final Throwable component5() {
      return a.cancelCause;
   }

   @NotNull
   public final CompletedContinuation copy(@Nullable Object a, @Nullable CancelHandler a, @Nullable Function1<? super Throwable, Unit> a, @Nullable Object a, @Nullable Throwable a) {
      return new CompletedContinuation(a, a, a, a, a);
   }

   // $FF: synthetic method
   public static CompletedContinuation copy$default(CompletedContinuation var0, Object var1, CancelHandler var2, Function1 var3, Object var4, Throwable var5, int var6, Object var7) {
      if ((var6 & 1) != 0) {
         var1 = var0.result;
      }

      if ((var6 & 2) != 0) {
         var2 = var0.cancelHandler;
      }

      if ((var6 & 4) != 0) {
         var3 = var0.onCancellation;
      }

      if ((var6 & 8) != 0) {
         var4 = var0.idempotentResume;
      }

      if ((var6 & 16) != 0) {
         var5 = var0.cancelCause;
      }

      return var0.copy(var1, var2, var3, var4, var5);
   }

   @NotNull
   public String toString() {
      return "CompletedContinuation(result=" + a.result + ", cancelHandler=" + a.cancelHandler + ", onCancellation=" + a.onCancellation + ", idempotentResume=" + a.idempotentResume + ", cancelCause=" + a.cancelCause + ')';
   }

   public int hashCode() {
      int a = a.result == null ? 0 : a.result.hashCode();
      a = a * 31 + (a.cancelHandler == null ? 0 : a.cancelHandler.hashCode());
      a = a * 31 + (a.onCancellation == null ? 0 : a.onCancellation.hashCode());
      a = a * 31 + (a.idempotentResume == null ? 0 : a.idempotentResume.hashCode());
      a = a * 31 + (a.cancelCause == null ? 0 : a.cancelCause.hashCode());
      return a;
   }

   public boolean equals(@Nullable Object a) {
      if (a == a) {
         return true;
      } else if (!(a instanceof CompletedContinuation)) {
         return false;
      } else {
         CompletedContinuation var2 = (CompletedContinuation)a;
         if (!Intrinsics.areEqual(a.result, var2.result)) {
            return false;
         } else if (!Intrinsics.areEqual((Object)a.cancelHandler, (Object)var2.cancelHandler)) {
            return false;
         } else if (!Intrinsics.areEqual((Object)a.onCancellation, (Object)var2.onCancellation)) {
            return false;
         } else if (!Intrinsics.areEqual(a.idempotentResume, var2.idempotentResume)) {
            return false;
         } else {
            return Intrinsics.areEqual((Object)a.cancelCause, (Object)var2.cancelCause);
         }
      }
   }
}
