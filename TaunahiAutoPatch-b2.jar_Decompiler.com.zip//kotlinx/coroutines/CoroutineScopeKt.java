package kotlinx.coroutines;

import java.util.concurrent.CancellationException;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.InlineMarker;
import kotlinx.coroutines.internal.ContextScope;
import kotlinx.coroutines.internal.ScopeCoroutine;
import kotlinx.coroutines.intrinsics.UndispatchedKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000F\n\u0000\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a\u000e\u0010\u0006\u001a\u00020\u00022\u0006\u0010\u0007\u001a\u00020\b\u001a\u0006\u0010\t\u001a\u00020\u0002\u001aM\u0010\n\u001a\u0002H\u000b\"\u0004\b\u0000\u0010\u000b2'\u0010\f\u001a#\b\u0001\u0012\u0004\u0012\u00020\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u000b0\u000e\u0012\u0006\u0012\u0004\u0018\u00010\u000f0\r¢\u0006\u0002\b\u0010H\u0086@ø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0002\u0010\u0011\u001a\u0011\u0010\u0012\u001a\u00020\bH\u0086Hø\u0001\u0000¢\u0006\u0002\u0010\u0013\u001a\u001e\u0010\u0014\u001a\u00020\u0015*\u00020\u00022\u0006\u0010\u0016\u001a\u00020\u00172\n\b\u0002\u0010\u0018\u001a\u0004\u0018\u00010\u0019\u001a\u001c\u0010\u0014\u001a\u00020\u0015*\u00020\u00022\u0010\b\u0002\u0010\u0018\u001a\n\u0018\u00010\u001aj\u0004\u0018\u0001`\u001b\u001a\n\u0010\u001c\u001a\u00020\u0015*\u00020\u0002\u001a\u0015\u0010\u001d\u001a\u00020\u0002*\u00020\u00022\u0006\u0010\u0007\u001a\u00020\bH\u0086\u0002\"\u001b\u0010\u0000\u001a\u00020\u0001*\u00020\u00028F¢\u0006\f\u0012\u0004\b\u0003\u0010\u0004\u001a\u0004\b\u0000\u0010\u0005\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001e"},
   d2 = {"isActive", "", "Lkotlinx/coroutines/CoroutineScope;", "isActive$annotations", "(Lkotlinx/coroutines/CoroutineScope;)V", "(Lkotlinx/coroutines/CoroutineScope;)Z", "CoroutineScope", "context", "Lkotlin/coroutines/CoroutineContext;", "MainScope", "coroutineScope", "R", "block", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "Lkotlin/ExtensionFunctionType;", "(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "currentCoroutineContext", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "cancel", "", "message", "", "cause", "", "Ljava/util/concurrent/CancellationException;", "Lkotlinx/coroutines/CancellationException;", "ensureActive", "plus", "kotlinx-coroutines-core"}
)
public final class CoroutineScopeKt {
   @NotNull
   public static final CoroutineScope plus(@NotNull CoroutineScope a, @NotNull CoroutineContext a) {
      return (CoroutineScope)(new ContextScope(a.getCoroutineContext().plus(a)));
   }

   @NotNull
   public static final CoroutineScope MainScope() {
      return (CoroutineScope)(new ContextScope(SupervisorKt.SupervisorJob$default((Job)null, 1, (Object)null).plus((CoroutineContext)Dispatchers.getMain())));
   }

   public static final boolean isActive(@NotNull CoroutineScope a) {
      Job var10000 = (Job)a.getCoroutineContext().get((CoroutineContext.Key)Job.Key);
      return var10000 != null ? var10000.isActive() : true;
   }

   /** @deprecated */
   // $FF: synthetic method
   public static void isActive$annotations(CoroutineScope a) {
   }

   @Nullable
   public static final <R> Object coroutineScope(@NotNull Function2<? super CoroutineScope, ? super Continuation<? super R>, ? extends Object> a, @NotNull Continuation<? super R> a) {
      int a = false;
      ScopeCoroutine a = new ScopeCoroutine(a.getContext(), a);
      Object var10000 = UndispatchedKt.startUndispatchedOrReturn(a, a, a);
      if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         DebugProbesKt.probeCoroutineSuspended(a);
      }

      return var10000;
   }

   @NotNull
   public static final CoroutineScope CoroutineScope(@NotNull CoroutineContext a) {
      return (CoroutineScope)(new ContextScope(a.get((CoroutineContext.Key)Job.Key) != null ? a : a.plus((CoroutineContext)JobKt.Job$default((Job)null, 1, (Object)null))));
   }

   public static final void cancel(@NotNull CoroutineScope a, @Nullable CancellationException a) {
      Job var10000 = (Job)a.getCoroutineContext().get((CoroutineContext.Key)Job.Key);
      if (var10000 == null) {
         throw new IllegalStateException(("Scope cannot be cancelled because it does not have a job: " + a).toString());
      } else {
         Job a = var10000;
         a.cancel(a);
      }
   }

   // $FF: synthetic method
   public static void cancel$default(CoroutineScope var0, CancellationException var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = null;
      }

      cancel(var0, var1);
   }

   public static final void cancel(@NotNull CoroutineScope a, @NotNull String a, @Nullable Throwable a) {
      cancel(a, ExceptionsKt.CancellationException(a, a));
   }

   // $FF: synthetic method
   public static void cancel$default(CoroutineScope var0, String var1, Throwable var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = null;
      }

      cancel(var0, var1, var2);
   }

   public static final void ensureActive(@NotNull CoroutineScope a) {
      JobKt.ensureActive(a.getCoroutineContext());
   }

   @Nullable
   public static final Object currentCoroutineContext(@NotNull Continuation<? super CoroutineContext> a) {
      int a = false;
      return a.getContext();
   }

   private static final Object currentCoroutineContext$$forInline(Continuation<? super CoroutineContext> a) {
      int a = false;
      InlineMarker.mark(3);
      return null.getContext();
   }
}
