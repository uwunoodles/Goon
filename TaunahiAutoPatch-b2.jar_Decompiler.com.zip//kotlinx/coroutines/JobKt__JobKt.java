package kotlinx.coroutines;

import java.util.Iterator;
import java.util.concurrent.CancellationException;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.JvmName;
import kotlin.jvm.functions.Function1;
import kotlin.sequences.Sequence;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000B\n\u0000\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\u001a\u0012\u0010\b\u001a\u00020\t2\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u0005\u001a\u0019\u0010\u000b\u001a\u00020\u00052\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u0005H\u0007¢\u0006\u0002\b\b\u001a\f\u0010\f\u001a\u00020\r*\u00020\u0002H\u0007\u001a\u0018\u0010\f\u001a\u00020\u0001*\u00020\u00022\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0007\u001a\u001c\u0010\f\u001a\u00020\r*\u00020\u00022\u0010\b\u0002\u0010\u000e\u001a\n\u0018\u00010\u0010j\u0004\u0018\u0001`\u0011\u001a\u001e\u0010\f\u001a\u00020\r*\u00020\u00052\u0006\u0010\u0012\u001a\u00020\u00132\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u000f\u001a\u0015\u0010\u0014\u001a\u00020\r*\u00020\u0005H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0015\u001a\f\u0010\u0016\u001a\u00020\r*\u00020\u0002H\u0007\u001a\u0018\u0010\u0016\u001a\u00020\r*\u00020\u00022\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0007\u001a\u001c\u0010\u0016\u001a\u00020\r*\u00020\u00022\u0010\b\u0002\u0010\u000e\u001a\n\u0018\u00010\u0010j\u0004\u0018\u0001`\u0011\u001a\f\u0010\u0016\u001a\u00020\r*\u00020\u0005H\u0007\u001a\u0018\u0010\u0016\u001a\u00020\r*\u00020\u00052\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0007\u001a\u001c\u0010\u0016\u001a\u00020\r*\u00020\u00052\u0010\b\u0002\u0010\u000e\u001a\n\u0018\u00010\u0010j\u0004\u0018\u0001`\u0011\u001a\u0014\u0010\u0017\u001a\u00020\u0018*\u00020\u00052\u0006\u0010\u0019\u001a\u00020\u0018H\u0000\u001a\n\u0010\u001a\u001a\u00020\r*\u00020\u0002\u001a\n\u0010\u001a\u001a\u00020\r*\u00020\u0005\u001a\u001b\u0010\u001b\u001a\u00020\u000f*\u0004\u0018\u00010\u000f2\u0006\u0010\u0004\u001a\u00020\u0005H\u0002¢\u0006\u0002\b\u001c\"\u0015\u0010\u0000\u001a\u00020\u0001*\u00020\u00028F¢\u0006\u0006\u001a\u0004\b\u0000\u0010\u0003\"\u0015\u0010\u0004\u001a\u00020\u0005*\u00020\u00028F¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001d"},
   d2 = {"isActive", "", "Lkotlin/coroutines/CoroutineContext;", "(Lkotlin/coroutines/CoroutineContext;)Z", "job", "Lkotlinx/coroutines/Job;", "getJob", "(Lkotlin/coroutines/CoroutineContext;)Lkotlinx/coroutines/Job;", "Job", "Lkotlinx/coroutines/CompletableJob;", "parent", "Job0", "cancel", "", "cause", "", "Ljava/util/concurrent/CancellationException;", "Lkotlinx/coroutines/CancellationException;", "message", "", "cancelAndJoin", "(Lkotlinx/coroutines/Job;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "cancelChildren", "disposeOnCompletion", "Lkotlinx/coroutines/DisposableHandle;", "handle", "ensureActive", "orCancellation", "orCancellation$JobKt__JobKt", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/JobKt"
)
final class JobKt__JobKt {
   @NotNull
   public static final CompletableJob Job(@Nullable Job a) {
      return (CompletableJob)(new JobImpl(a));
   }

   // $FF: synthetic method
   public static CompletableJob Job$default(Job var0, int var1, Object var2) {
      if ((var1 & 1) != 0) {
         var0 = null;
      }

      return JobKt.Job(var0);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   @JvmName(
      name = "Job"
   )
   public static final Job Job(Job a) {
      return (Job)JobKt.Job(a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static Job Job$default(Job var0, int var1, Object var2) {
      if ((var1 & 1) != 0) {
         var0 = null;
      }

      return JobKt.Job(var0);
   }

   @NotNull
   public static final DisposableHandle disposeOnCompletion(@NotNull Job a, @NotNull DisposableHandle a) {
      CompletionHandlerBase a = (CompletionHandlerBase)(new DisposeOnCompletion(a));
      int a = false;
      return a.invokeOnCompletion((Function1)a);
   }

   @Nullable
   public static final Object cancelAndJoin(@NotNull Job a, @NotNull Continuation<? super Unit> a) {
      Job.DefaultImpls.cancel$default(a, (CancellationException)null, 1, (Object)null);
      Object var10000 = a.join(a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   public static final void cancelChildren(@NotNull Job a, @Nullable CancellationException a) {
      Sequence a = a.getChildren();
      int a = false;
      Iterator var4 = a.iterator();

      while(var4.hasNext()) {
         Object a = var4.next();
         Job a = (Job)a;
         int a = false;
         a.cancel(a);
      }

   }

   // $FF: synthetic method
   public static void cancelChildren$default(Job var0, CancellationException var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = null;
      }

      JobKt.cancelChildren(var0, var1);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public static final void cancelChildren(Job a) {
      JobKt.cancelChildren((Job)a, (CancellationException)null);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public static final void cancelChildren(Job a, Throwable a) {
      Sequence a = a.getChildren();
      int a = false;
      Iterator var4 = a.iterator();

      while(var4.hasNext()) {
         Object a = var4.next();
         Job a = (Job)a;
         int a = false;
         JobSupport var10000 = a instanceof JobSupport ? (JobSupport)a : null;
         if ((a instanceof JobSupport ? (JobSupport)a : null) != null) {
            var10000.cancelInternal(orCancellation$JobKt__JobKt(a, a));
         }
      }

   }

   /** @deprecated */
   // $FF: synthetic method
   public static void cancelChildren$default(Job var0, Throwable var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = null;
      }

      JobKt.cancelChildren(var0, var1);
   }

   public static final boolean isActive(@NotNull CoroutineContext a) {
      Job var10000 = (Job)a.get((CoroutineContext.Key)Job.Key);
      return var10000 != null ? var10000.isActive() : false;
   }

   public static final void cancel(@NotNull CoroutineContext a, @Nullable CancellationException a) {
      Job var10000 = (Job)a.get((CoroutineContext.Key)Job.Key);
      if (var10000 != null) {
         var10000.cancel(a);
      }

   }

   // $FF: synthetic method
   public static void cancel$default(CoroutineContext var0, CancellationException var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = null;
      }

      JobKt.cancel(var0, var1);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public static final void cancel(CoroutineContext a) {
      JobKt.cancel(a, (CancellationException)null);
   }

   public static final void ensureActive(@NotNull Job a) {
      if (!a.isActive()) {
         throw a.getCancellationException();
      }
   }

   public static final void ensureActive(@NotNull CoroutineContext a) {
      Job var10000 = (Job)a.get((CoroutineContext.Key)Job.Key);
      if (var10000 != null) {
         JobKt.ensureActive(var10000);
      }

   }

   public static final void cancel(@NotNull Job a, @NotNull String a, @Nullable Throwable a) {
      a.cancel(ExceptionsKt.CancellationException(a, a));
   }

   // $FF: synthetic method
   public static void cancel$default(Job var0, String var1, Throwable var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = null;
      }

      JobKt.cancel(var0, var1, var2);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public static final boolean cancel(CoroutineContext a, Throwable a) {
      CoroutineContext.Element var3 = a.get((CoroutineContext.Key)Job.Key);
      JobSupport var10000 = var3 instanceof JobSupport ? (JobSupport)var3 : null;
      if ((var3 instanceof JobSupport ? (JobSupport)var3 : null) == null) {
         return false;
      } else {
         JobSupport a = var10000;
         a.cancelInternal(orCancellation$JobKt__JobKt(a, (Job)a));
         return true;
      }
   }

   /** @deprecated */
   // $FF: synthetic method
   public static boolean cancel$default(CoroutineContext var0, Throwable var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = null;
      }

      return JobKt.cancel(var0, var1);
   }

   public static final void cancelChildren(@NotNull CoroutineContext a, @Nullable CancellationException a) {
      Job var10000 = (Job)a.get((CoroutineContext.Key)Job.Key);
      if (var10000 != null) {
         Sequence var8 = var10000.getChildren();
         if (var8 != null) {
            Sequence a = var8;
            int a = false;
            Iterator var4 = a.iterator();

            while(var4.hasNext()) {
               Object a = var4.next();
               Job a = (Job)a;
               int a = false;
               a.cancel(a);
            }
         }
      }

   }

   // $FF: synthetic method
   public static void cancelChildren$default(CoroutineContext var0, CancellationException var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = null;
      }

      JobKt.cancelChildren(var0, var1);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public static final void cancelChildren(CoroutineContext a) {
      JobKt.cancelChildren((CoroutineContext)a, (CancellationException)null);
   }

   @NotNull
   public static final Job getJob(@NotNull CoroutineContext a) {
      return (Job)a.get((CoroutineContext.Key)Job.Key);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public static final void cancelChildren(CoroutineContext a, Throwable a) {
      Job var10000 = (Job)a.get((CoroutineContext.Key)Job.Key);
      if (var10000 != null) {
         Job a = var10000;
         Sequence a = a.getChildren();
         int a = false;
         Iterator var5 = a.iterator();

         while(var5.hasNext()) {
            Object a = var5.next();
            Job a = (Job)a;
            int a = false;
            JobSupport var9 = a instanceof JobSupport ? (JobSupport)a : null;
            if ((a instanceof JobSupport ? (JobSupport)a : null) != null) {
               var9.cancelInternal(orCancellation$JobKt__JobKt(a, a));
            }
         }

      }
   }

   /** @deprecated */
   // $FF: synthetic method
   public static void cancelChildren$default(CoroutineContext var0, Throwable var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = null;
      }

      JobKt.cancelChildren(var0, var1);
   }

   private static final Throwable orCancellation$JobKt__JobKt(Throwable a, Job a) {
      Throwable var10000 = a;
      if (a == null) {
         var10000 = (Throwable)(new JobCancellationException("Job was cancelled", (Throwable)null, a));
      }

      return var10000;
   }
}
