package kotlinx.coroutines;

import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.ContinuationInterceptor;
import kotlin.coroutines.CoroutineContext;
import kotlinx.coroutines.internal.ScopeCoroutine;
import kotlinx.coroutines.internal.ThreadContextKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00008\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0000\u0018\u0000*\u0006\b\u0000\u0010\u0001 \u00002\b\u0012\u0004\u0012\u0002H\u00010\u0002B\u001b\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u0006¢\u0006\u0002\u0010\u0007J\u0012\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000bH\u0014J\u0006\u0010\u000f\u001a\u00020\u0010J\u0018\u0010\u0011\u001a\u00020\r2\u0006\u0010\u0003\u001a\u00020\u00042\b\u0010\u0012\u001a\u0004\u0018\u00010\u000bR\"\u0010\b\u001a\u0016\u0012\u0012\u0012\u0010\u0012\u0004\u0012\u00020\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\n0\tX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0013"},
   d2 = {"Lkotlinx/coroutines/UndispatchedCoroutine;", "T", "Lkotlinx/coroutines/internal/ScopeCoroutine;", "context", "Lkotlin/coroutines/CoroutineContext;", "uCont", "Lkotlin/coroutines/Continuation;", "(Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;)V", "threadStateToRecover", "Ljava/lang/ThreadLocal;", "Lkotlin/Pair;", "", "afterResume", "", "state", "clearThreadContext", "", "saveThreadContext", "oldValue", "kotlinx-coroutines-core"}
)
public final class UndispatchedCoroutine<T> extends ScopeCoroutine<T> {
   @NotNull
   private ThreadLocal<Pair<CoroutineContext, Object>> threadStateToRecover = new ThreadLocal();

   public UndispatchedCoroutine(@NotNull CoroutineContext a, @NotNull Continuation<? super T> a) {
      super(a.get((CoroutineContext.Key)UndispatchedMarker.INSTANCE) == null ? a.plus((CoroutineContext)UndispatchedMarker.INSTANCE) : a, a);
      if (!(a.getContext().get((CoroutineContext.Key)ContinuationInterceptor.Key) instanceof CoroutineDispatcher)) {
         Object a = ThreadContextKt.updateThreadContext(a, (Object)null);
         ThreadContextKt.restoreThreadContext(a, a);
         a.saveThreadContext(a, a);
      }

   }

   public final void saveThreadContext(@NotNull CoroutineContext a, @Nullable Object a) {
      a.threadStateToRecover.set(TuplesKt.to(a, a));
   }

   public final boolean clearThreadContext() {
      if (a.threadStateToRecover.get() == null) {
         return false;
      } else {
         a.threadStateToRecover.set((Object)null);
         return true;
      }
   }

   protected void afterResume(@Nullable Object a) {
      Pair var10000 = (Pair)a.threadStateToRecover.get();
      Pair a;
      boolean a;
      CoroutineContext a;
      Object a;
      if (var10000 != null) {
         a = var10000;
         a = false;
         a = (CoroutineContext)a.component1();
         a = a.component2();
         ThreadContextKt.restoreThreadContext(a, a);
         a.threadStateToRecover.set((Object)null);
      }

      Object a = CompletionStateKt.recoverResult(a, a.uCont);
      Continuation a = a.uCont;
      a = null;
      a = false;
      a = a.getContext();
      a = ThreadContextKt.updateThreadContext(a, a);
      UndispatchedCoroutine a = a != ThreadContextKt.NO_THREAD_ELEMENTS ? CoroutineContextKt.updateUndispatchedCompletion(a, a, a) : (UndispatchedCoroutine)null;

      try {
         int a = false;
         a.uCont.resumeWith(a);
         Unit var12 = Unit.INSTANCE;
      } finally {
         if (a == null || a.clearThreadContext()) {
            ThreadContextKt.restoreThreadContext(a, a);
         }

      }

   }
}
