package kotlinx.coroutines;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001a\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\u001a\b\u0010\u0000\u001a\u00020\u0001H\u0000\u001a\u0019\u0010\u0002\u001a\u00020\u00032\u000e\b\u0004\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005H\u0080\b\u001a\b\u0010\u0006\u001a\u00020\u0007H\u0007¨\u0006\b"},
   d2 = {"createEventLoop", "Lkotlinx/coroutines/EventLoop;", "platformAutoreleasePool", "", "block", "Lkotlin/Function0;", "processNextEventInCurrentThread", "", "kotlinx-coroutines-core"}
)
public final class EventLoopKt {
   @NotNull
   public static final EventLoop createEventLoop() {
      return (EventLoop)(new BlockingEventLoop(Thread.currentThread()));
   }

   @InternalCoroutinesApi
   public static final long processNextEventInCurrentThread() {
      EventLoop var10000 = ThreadLocalEventLoop.INSTANCE.currentOrNull$kotlinx_coroutines_core();
      return var10000 != null ? var10000.processNextEvent() : Long.MAX_VALUE;
   }

   public static final void platformAutoreleasePool(@NotNull Function0<Unit> a) {
      int a = false;
      a.invoke();
   }
}
