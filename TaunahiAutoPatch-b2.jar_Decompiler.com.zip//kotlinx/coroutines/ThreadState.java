package kotlinx.coroutines;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0001\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\b\u0002\u0018\u00002#\u0012\u0015\u0012\u0013\u0018\u00010\r¢\u0006\f\b\u001c\u0012\b\b\u001d\u0012\u0004\b\b(\u000e\u0012\u0004\u0012\u00020\u00050\u001bj\u0002`\u001eB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0004\b\u0003\u0010\u0004J\r\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0017\u0010\u000b\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\bH\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u001a\u0010\u000f\u001a\u00020\u00052\b\u0010\u000e\u001a\u0004\u0018\u00010\rH\u0096\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\r\u0010\u0011\u001a\u00020\u0005¢\u0006\u0004\b\u0011\u0010\u0007R\u0018\u0010\u0013\u001a\u0004\u0018\u00010\u00128\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0013\u0010\u0014R\u0014\u0010\u0002\u001a\u00020\u00018\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0002\u0010\u0015R\u001c\u0010\u0018\u001a\n \u0017*\u0004\u0018\u00010\u00160\u00168\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0018\u0010\u0019¨\u0006\u001a"},
   d2 = {"Lkotlinx/coroutines/ThreadState;", "Lkotlinx/coroutines/Job;", "job", "ThreadState", "(Lkotlinx/coroutines/Job;)V", "", "clearInterrupt", "()V", "", "state", "", "invalidState", "(I)Ljava/lang/Void;", "", "cause", "invoke", "(Ljava/lang/Throwable;)V", "setup", "Lkotlinx/coroutines/DisposableHandle;", "cancelHandle", "Lkotlinx/coroutines/DisposableHandle;", "Lkotlinx/coroutines/Job;", "Ljava/lang/Thread;", "kotlin.jvm.PlatformType", "targetThread", "Ljava/lang/Thread;", "kotlinx-coroutines-core", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "Lkotlinx/coroutines/CompletionHandler;"}
)
final class ThreadState implements Function1<Throwable, Unit> {
   @NotNull
   private final Job job;
   // $FF: synthetic field
   @NotNull
   private volatile int _state;
   // $FF: synthetic field
   private static final AtomicIntegerFieldUpdater _state$FU = AtomicIntegerFieldUpdater.newUpdater(ThreadState.class, "_state");
   private final Thread targetThread;
   @Nullable
   private DisposableHandle cancelHandle;

   public ThreadState(@NotNull Job a) {
      a.job = a;
      a._state = 0;
      a.targetThread = Thread.currentThread();
   }

   public final void setup() {
      a.cancelHandle = a.job.invokeOnCompletion(true, true, (Function1)a);
      ThreadState a = a;
      boolean var2 = false;

      int a;
      do {
         a = a._state;
         int a = false;
         switch(a) {
         case 0:
            break;
         case 1:
         default:
            a.invalidState(a);
            throw new KotlinNothingValueException();
         case 2:
         case 3:
            return;
         }
      } while(!_state$FU.compareAndSet(a, a, 0));

   }

   public final void clearInterrupt() {
      ThreadState a = a;
      boolean var2 = false;

      while(true) {
         int a = a._state;
         int a = false;
         switch(a) {
         case 0:
            if (_state$FU.compareAndSet(a, a, 1)) {
               DisposableHandle var10000 = a.cancelHandle;
               if (var10000 != null) {
                  var10000.dispose();
               }

               return;
            }
         case 2:
            break;
         case 1:
         default:
            a.invalidState(a);
            throw new KotlinNothingValueException();
         case 3:
            Thread.interrupted();
            return;
         }
      }
   }

   public void invoke(@Nullable Throwable a1) {
      ThreadState a = a;
      boolean var3 = false;

      int a;
      do {
         a = a._state;
         int a = false;
         switch(a) {
         case 0:
            break;
         case 1:
         case 2:
         case 3:
            return;
         default:
            a.invalidState(a);
            throw new KotlinNothingValueException();
         }
      } while(!_state$FU.compareAndSet(a, a, 2));

      a.targetThread.interrupt();
      a._state = 3;
   }

   private final Void invalidState(int a) {
      throw new IllegalStateException(("Illegal state " + a).toString());
   }
}
