package kotlinx.coroutines;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 4,
   xi = 48,
   d1 = {"kotlinx/coroutines/BuildersKt__BuildersKt", "kotlinx/coroutines/BuildersKt__Builders_commonKt"}
)
public final class BuildersKt {
   public static final <T> T runBlocking(@NotNull CoroutineContext a, @NotNull Function2<? super CoroutineScope, ? super Continuation<? super T>, ? extends Object> a) throws InterruptedException {
      return BuildersKt__BuildersKt.runBlocking(a, a);
   }

   // $FF: synthetic method
   public static Object runBlocking$default(CoroutineContext var0, Function2 var1, int var2, Object var3) throws InterruptedException {
      return BuildersKt__BuildersKt.runBlocking$default(var0, var1, var2, var3);
   }

   @NotNull
   public static final Job launch(@NotNull CoroutineScope a, @NotNull CoroutineContext a, @NotNull CoroutineStart a, @NotNull Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object> a) {
      return BuildersKt__Builders_commonKt.launch(a, a, a, a);
   }

   // $FF: synthetic method
   public static Job launch$default(CoroutineScope var0, CoroutineContext var1, CoroutineStart var2, Function2 var3, int var4, Object var5) {
      return BuildersKt__Builders_commonKt.launch$default(var0, var1, var2, var3, var4, var5);
   }

   @NotNull
   public static final <T> Deferred<T> async(@NotNull CoroutineScope a, @NotNull CoroutineContext a, @NotNull CoroutineStart a, @NotNull Function2<? super CoroutineScope, ? super Continuation<? super T>, ? extends Object> a) {
      return BuildersKt__Builders_commonKt.async(a, a, a, a);
   }

   // $FF: synthetic method
   public static Deferred async$default(CoroutineScope var0, CoroutineContext var1, CoroutineStart var2, Function2 var3, int var4, Object var5) {
      return BuildersKt__Builders_commonKt.async$default(var0, var1, var2, var3, var4, var5);
   }

   @Nullable
   public static final <T> Object withContext(@NotNull CoroutineContext a, @NotNull Function2<? super CoroutineScope, ? super Continuation<? super T>, ? extends Object> a, @NotNull Continuation<? super T> a) {
      return BuildersKt__Builders_commonKt.withContext(a, a, a);
   }

   @Nullable
   public static final <T> Object invoke(@NotNull CoroutineDispatcher a, @NotNull Function2<? super CoroutineScope, ? super Continuation<? super T>, ? extends Object> a, @NotNull Continuation<? super T> a) {
      return BuildersKt__Builders_commonKt.invoke(a, a, a);
   }
}
