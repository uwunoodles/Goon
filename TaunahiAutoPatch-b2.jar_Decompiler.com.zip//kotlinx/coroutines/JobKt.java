package kotlinx.coroutines;

import java.util.concurrent.CancellationException;
import java.util.concurrent.Future;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.JvmName;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 4,
   xi = 48,
   d1 = {"kotlinx/coroutines/JobKt__FutureKt", "kotlinx/coroutines/JobKt__JobKt"}
)
public final class JobKt {
   @InternalCoroutinesApi
   @NotNull
   public static final DisposableHandle cancelFutureOnCompletion(@NotNull Job a, @NotNull Future<?> a) {
      return JobKt__FutureKt.cancelFutureOnCompletion(a, a);
   }

   public static final void cancelFutureOnCancellation(@NotNull CancellableContinuation<?> a, @NotNull Future<?> a) {
      JobKt__FutureKt.cancelFutureOnCancellation(a, a);
   }

   @NotNull
   public static final CompletableJob Job(@Nullable Job a) {
      return JobKt__JobKt.Job(a);
   }

   // $FF: synthetic method
   public static CompletableJob Job$default(Job var0, int var1, Object var2) {
      return JobKt__JobKt.Job$default(var0, var1, var2);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   @JvmName(
      name = "Job"
   )
   public static final Job Job(Job a) {
      return JobKt__JobKt.Job(a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static Job Job$default(Job var0, int var1, Object var2) {
      return JobKt__JobKt.Job$default(var0, var1, var2);
   }

   @NotNull
   public static final DisposableHandle disposeOnCompletion(@NotNull Job a, @NotNull DisposableHandle a) {
      return JobKt__JobKt.disposeOnCompletion(a, a);
   }

   @Nullable
   public static final Object cancelAndJoin(@NotNull Job a, @NotNull Continuation<? super Unit> a) {
      return JobKt__JobKt.cancelAndJoin(a, a);
   }

   public static final void cancelChildren(@NotNull Job a, @Nullable CancellationException a) {
      JobKt__JobKt.cancelChildren(a, a);
   }

   // $FF: synthetic method
   public static void cancelChildren$default(Job var0, CancellationException var1, int var2, Object var3) {
      JobKt__JobKt.cancelChildren$default(var0, var1, var2, var3);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public static final void cancelChildren(Job a) {
      JobKt__JobKt.cancelChildren(a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public static final void cancelChildren(Job a, Throwable a) {
      JobKt__JobKt.cancelChildren(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static void cancelChildren$default(Job var0, Throwable var1, int var2, Object var3) {
      JobKt__JobKt.cancelChildren$default(var0, var1, var2, var3);
   }

   public static final boolean isActive(@NotNull CoroutineContext a) {
      return JobKt__JobKt.isActive(a);
   }

   public static final void cancel(@NotNull CoroutineContext a, @Nullable CancellationException a) {
      JobKt__JobKt.cancel(a, a);
   }

   // $FF: synthetic method
   public static void cancel$default(CoroutineContext var0, CancellationException var1, int var2, Object var3) {
      JobKt__JobKt.cancel$default(var0, var1, var2, var3);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public static final void cancel(CoroutineContext a) {
      JobKt__JobKt.cancel(a);
   }

   public static final void ensureActive(@NotNull Job a) {
      JobKt__JobKt.ensureActive(a);
   }

   public static final void ensureActive(@NotNull CoroutineContext a) {
      JobKt__JobKt.ensureActive(a);
   }

   public static final void cancel(@NotNull Job a, @NotNull String a, @Nullable Throwable a) {
      JobKt__JobKt.cancel(a, a, a);
   }

   // $FF: synthetic method
   public static void cancel$default(Job var0, String var1, Throwable var2, int var3, Object var4) {
      JobKt__JobKt.cancel$default(var0, var1, var2, var3, var4);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public static final boolean cancel(CoroutineContext a, Throwable a) {
      return JobKt__JobKt.cancel(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static boolean cancel$default(CoroutineContext var0, Throwable var1, int var2, Object var3) {
      return JobKt__JobKt.cancel$default(var0, var1, var2, var3);
   }

   public static final void cancelChildren(@NotNull CoroutineContext a, @Nullable CancellationException a) {
      JobKt__JobKt.cancelChildren(a, a);
   }

   // $FF: synthetic method
   public static void cancelChildren$default(CoroutineContext var0, CancellationException var1, int var2, Object var3) {
      JobKt__JobKt.cancelChildren$default(var0, var1, var2, var3);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public static final void cancelChildren(CoroutineContext a) {
      JobKt__JobKt.cancelChildren(a);
   }

   @NotNull
   public static final Job getJob(@NotNull CoroutineContext a) {
      return JobKt__JobKt.getJob(a);
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Since 1.2.0, binary compatibility with versions <= 1.1.x",
      level = DeprecationLevel.HIDDEN
   )
   public static final void cancelChildren(CoroutineContext a, Throwable a) {
      JobKt__JobKt.cancelChildren(a, a);
   }

   /** @deprecated */
   // $FF: synthetic method
   public static void cancelChildren$default(CoroutineContext var0, Throwable var1, int var2, Object var3) {
      JobKt__JobKt.cancelChildren$default(var0, var1, var2, var3);
   }
}
