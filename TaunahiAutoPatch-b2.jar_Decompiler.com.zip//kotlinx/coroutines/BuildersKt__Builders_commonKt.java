package kotlinx.coroutines;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.ContinuationInterceptor;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.internal.ScopeCoroutine;
import kotlinx.coroutines.internal.ThreadContextKt;
import kotlinx.coroutines.intrinsics.CancellableKt;
import kotlinx.coroutines.intrinsics.UndispatchedKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

// $FF: synthetic class
@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 48,
   d1 = {"\u0000J\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u001aU\u0010\u0004\u001a\u0002H\u0005\"\u0004\b\u0000\u0010\u00052\u0006\u0010\u0006\u001a\u00020\u00072'\u0010\b\u001a#\b\u0001\u0012\u0004\u0012\u00020\n\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00050\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f0\t¢\u0006\u0002\b\rH\u0086@ø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0001¢\u0006\u0002\u0010\u000e\u001a[\u0010\u000f\u001a\b\u0012\u0004\u0012\u0002H\u00050\u0010\"\u0004\b\u0000\u0010\u0005*\u00020\n2\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\u0011\u001a\u00020\u00122'\u0010\b\u001a#\b\u0001\u0012\u0004\u0012\u00020\n\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00050\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f0\t¢\u0006\u0002\b\rø\u0001\u0000¢\u0006\u0002\u0010\u0013\u001aF\u0010\u0014\u001a\u0002H\u0005\"\u0004\b\u0000\u0010\u0005*\u00020\u00152)\b\b\u0010\b\u001a#\b\u0001\u0012\u0004\u0012\u00020\n\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00050\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f0\t¢\u0006\u0002\b\rH\u0086Jø\u0001\u0000¢\u0006\u0002\u0010\u0016\u001aO\u0010\u0017\u001a\u00020\u0018*\u00020\n2\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\u0011\u001a\u00020\u00122'\u0010\b\u001a#\b\u0001\u0012\u0004\u0012\u00020\n\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00190\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f0\t¢\u0006\u0002\b\rø\u0001\u0000¢\u0006\u0002\u0010\u001a\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0003\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001b"},
   d2 = {"RESUMED", "", "SUSPENDED", "UNDECIDED", "withContext", "T", "context", "Lkotlin/coroutines/CoroutineContext;", "block", "Lkotlin/Function2;", "Lkotlinx/coroutines/CoroutineScope;", "Lkotlin/coroutines/Continuation;", "", "Lkotlin/ExtensionFunctionType;", "(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "async", "Lkotlinx/coroutines/Deferred;", "start", "Lkotlinx/coroutines/CoroutineStart;", "(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/Deferred;", "invoke", "Lkotlinx/coroutines/CoroutineDispatcher;", "(Lkotlinx/coroutines/CoroutineDispatcher;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "launch", "Lkotlinx/coroutines/Job;", "", "(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/Job;", "kotlinx-coroutines-core"},
   xs = "kotlinx/coroutines/BuildersKt"
)
final class BuildersKt__Builders_commonKt {
   private static final int UNDECIDED = 0;
   private static final int SUSPENDED = 1;
   private static final int RESUMED = 2;

   @NotNull
   public static final Job launch(@NotNull CoroutineScope a, @NotNull CoroutineContext a, @NotNull CoroutineStart a, @NotNull Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object> a) {
      CoroutineContext a = CoroutineContextKt.newCoroutineContext(a, a);
      StandaloneCoroutine a = a.isLazy() ? (StandaloneCoroutine)(new LazyStandaloneCoroutine(a, a)) : new StandaloneCoroutine(a, true);
      a.start(a, a, a);
      return (Job)a;
   }

   // $FF: synthetic method
   public static Job launch$default(CoroutineScope var0, CoroutineContext var1, CoroutineStart var2, Function2 var3, int var4, Object var5) {
      if ((var4 & 1) != 0) {
         var1 = (CoroutineContext)EmptyCoroutineContext.INSTANCE;
      }

      if ((var4 & 2) != 0) {
         var2 = CoroutineStart.DEFAULT;
      }

      return BuildersKt.launch(var0, var1, var2, var3);
   }

   @NotNull
   public static final <T> Deferred<T> async(@NotNull CoroutineScope a, @NotNull CoroutineContext a, @NotNull CoroutineStart a, @NotNull Function2<? super CoroutineScope, ? super Continuation<? super T>, ? extends Object> a) {
      CoroutineContext a = CoroutineContextKt.newCoroutineContext(a, a);
      DeferredCoroutine a = a.isLazy() ? (DeferredCoroutine)(new LazyDeferredCoroutine(a, a)) : new DeferredCoroutine(a, true);
      a.start(a, a, a);
      return (Deferred)a;
   }

   // $FF: synthetic method
   public static Deferred async$default(CoroutineScope var0, CoroutineContext var1, CoroutineStart var2, Function2 var3, int var4, Object var5) {
      if ((var4 & 1) != 0) {
         var1 = (CoroutineContext)EmptyCoroutineContext.INSTANCE;
      }

      if ((var4 & 2) != 0) {
         var2 = CoroutineStart.DEFAULT;
      }

      return BuildersKt.async(var0, var1, var2, var3);
   }

   @Nullable
   public static final <T> Object withContext(@NotNull CoroutineContext a, @NotNull Function2<? super CoroutineScope, ? super Continuation<? super T>, ? extends Object> a, @NotNull Continuation<? super T> a) {
      int a = false;
      CoroutineContext a = a.getContext();
      CoroutineContext a = CoroutineContextKt.newCoroutineContext(a, a);
      JobKt.ensureActive(a);
      Object var10000;
      if (a == a) {
         ScopeCoroutine a = new ScopeCoroutine(a, a);
         var10000 = UndispatchedKt.startUndispatchedOrReturn(a, a, a);
      } else if (Intrinsics.areEqual((Object)a.get((CoroutineContext.Key)ContinuationInterceptor.Key), (Object)a.get((CoroutineContext.Key)ContinuationInterceptor.Key))) {
         UndispatchedCoroutine a = new UndispatchedCoroutine(a, a);
         Object a = null;
         int a = false;
         Object a = ThreadContextKt.updateThreadContext(a, a);

         Object var12;
         try {
            int a = false;
            var12 = UndispatchedKt.startUndispatchedOrReturn((ScopeCoroutine)a, a, a);
         } finally {
            ThreadContextKt.restoreThreadContext(a, a);
         }

         var10000 = var12;
      } else {
         DispatchedCoroutine a = new DispatchedCoroutine(a, a);
         CancellableKt.startCoroutineCancellable$default(a, a, (Continuation)a, (Function1)null, 4, (Object)null);
         var10000 = a.getResult();
      }

      if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         DebugProbesKt.probeCoroutineSuspended(a);
      }

      return var10000;
   }

   @Nullable
   public static final <T> Object invoke(@NotNull CoroutineDispatcher a, @NotNull Function2<? super CoroutineScope, ? super Continuation<? super T>, ? extends Object> a, @NotNull Continuation<? super T> a) {
      int a = false;
      return BuildersKt.withContext((CoroutineContext)a, a, a);
   }

   private static final <T> Object invoke$$forInline(CoroutineDispatcher a, Function2<? super CoroutineScope, ? super Continuation<? super T>, ? extends Object> a, Continuation<? super T> a) {
      int a = false;
      CoroutineContext var10000 = (CoroutineContext)a;
      InlineMarker.mark(0);
      Object var4 = BuildersKt.withContext(var10000, a, a);
      InlineMarker.mark(1);
      return var4;
   }
}
