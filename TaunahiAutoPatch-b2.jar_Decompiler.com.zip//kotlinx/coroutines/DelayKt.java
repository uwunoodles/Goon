package kotlinx.coroutines;

import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.ContinuationInterceptor;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.ranges.RangesKt;
import kotlin.time.Duration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000*\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0001\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u001a\u0011\u0010\u0005\u001a\u00020\u0006H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0007\u001a\u0019\u0010\u0000\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u000b\u001a!\u0010\u0000\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\rH\u0086@ø\u0001\u0000ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\u000e\u0010\u000b\u001a\u0019\u0010\u000f\u001a\u00020\n*\u00020\rH\u0000ø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\u0010\u0010\u0011\"\u0018\u0010\u0000\u001a\u00020\u0001*\u00020\u00028@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0003\u0010\u0004\u0082\u0002\u000b\n\u0002\b\u0019\n\u0005\b¡\u001e0\u0001¨\u0006\u0012"},
   d2 = {"delay", "Lkotlinx/coroutines/Delay;", "Lkotlin/coroutines/CoroutineContext;", "getDelay", "(Lkotlin/coroutines/CoroutineContext;)Lkotlinx/coroutines/Delay;", "awaitCancellation", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "", "timeMillis", "", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "duration", "Lkotlin/time/Duration;", "delay-VtjQ1oo", "toDelayMillis", "toDelayMillis-LRDsOJo", "(J)J", "kotlinx-coroutines-core"}
)
public final class DelayKt {
   @Nullable
   public static final Object awaitCancellation(@NotNull Continuation<?> var0) {
      Object a;
      label24: {
         if (var0 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var0;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label24;
            }
         }

         a = new ContinuationImpl(var0) {
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return DelayKt.awaitCancellation((Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var8 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      boolean a;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         a = false;
         ((<undefinedtype>)a).label = 1;
         Continuation a = (Continuation)a;
         int a = false;
         CancellableContinuationImpl a = new CancellableContinuationImpl(IntrinsicsKt.intercepted(a), 1);
         a.initCancellability();
         CancellableContinuation var10000 = (CancellableContinuation)a;
         boolean var5 = false;
         Object var9 = a.getResult();
         if (var9 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            DebugProbesKt.probeCoroutineSuspended((Continuation)a);
         }

         if (var9 == var8) {
            return var8;
         }
         break;
      case 1:
         a = false;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      throw new KotlinNothingValueException();
   }

   @Nullable
   public static final Object delay(long a, @NotNull Continuation<? super Unit> a) {
      if (a <= 0L) {
         return Unit.INSTANCE;
      } else {
         int a = false;
         int a = false;
         CancellableContinuationImpl a = new CancellableContinuationImpl(IntrinsicsKt.intercepted(a), 1);
         a.initCancellability();
         CancellableContinuation a = (CancellableContinuation)a;
         int a = false;
         if (a < Long.MAX_VALUE) {
            getDelay(a.getContext()).scheduleResumeAfterDelay(a, a);
         }

         Object var10000 = a.getResult();
         if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            DebugProbesKt.probeCoroutineSuspended(a);
         }

         return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
      }
   }

   @Nullable
   public static final Object delay_VtjQ1oo/* $FF was: delay-VtjQ1oo*/(long a, @NotNull Continuation<? super Unit> a) {
      Object var10000 = delay(toDelayMillis-LRDsOJo(a), a);
      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   @NotNull
   public static final Delay getDelay(@NotNull CoroutineContext a) {
      CoroutineContext.Element var1 = a.get((CoroutineContext.Key)ContinuationInterceptor.Key);
      Delay var10000 = var1 instanceof Delay ? (Delay)var1 : null;
      if ((var1 instanceof Delay ? (Delay)var1 : null) == null) {
         var10000 = DefaultExecutorKt.getDefaultDelay();
      }

      return var10000;
   }

   public static final long toDelayMillis_LRDsOJo/* $FF was: toDelayMillis-LRDsOJo*/(long a) {
      return Duration.compareTo-LRDsOJo(a, Duration.Companion.getZERO-UwyO8pc()) > 0 ? RangesKt.coerceAtLeast(Duration.getInWholeMilliseconds-impl(a), 1L) : 0L;
   }
}
