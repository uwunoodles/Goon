package kotlinx.coroutines;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlinx.coroutines.internal.DispatchedContinuation;
import kotlinx.coroutines.internal.DispatchedContinuationKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\u001a\u0011\u0010\u0000\u001a\u00020\u0001H\u0086@ø\u0001\u0000¢\u0006\u0002\u0010\u0002\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0003"},
   d2 = {"yield", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public final class YieldKt {
   @Nullable
   public static final Object yield(@NotNull Continuation<? super Unit> a) {
      int a = false;
      CoroutineContext a = a.getContext();
      JobKt.ensureActive(a);
      Continuation var4 = IntrinsicsKt.intercepted(a);
      DispatchedContinuation var10000 = var4 instanceof DispatchedContinuation ? (DispatchedContinuation)var4 : null;
      Object var7;
      if ((var4 instanceof DispatchedContinuation ? (DispatchedContinuation)var4 : null) == null) {
         var7 = Unit.INSTANCE;
      } else {
         label30: {
            DispatchedContinuation a = var10000;
            if (a.dispatcher.isDispatchNeeded(a)) {
               a.dispatchYield$kotlinx_coroutines_core(a, Unit.INSTANCE);
            } else {
               YieldContext a = new YieldContext();
               a.dispatchYield$kotlinx_coroutines_core(a.plus((CoroutineContext)a), Unit.INSTANCE);
               if (a.dispatcherWasUnconfined) {
                  var7 = DispatchedContinuationKt.yieldUndispatched(a) ? IntrinsicsKt.getCOROUTINE_SUSPENDED() : Unit.INSTANCE;
                  break label30;
               }
            }

            var7 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
         }
      }

      if (var7 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         DebugProbesKt.probeCoroutineSuspended(a);
      }

      return var7 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var7 : Unit.INSTANCE;
   }
}
