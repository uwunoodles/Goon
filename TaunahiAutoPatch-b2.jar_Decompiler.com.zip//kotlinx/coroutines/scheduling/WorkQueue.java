package kotlinx.coroutines.scheduling;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import kotlinx.coroutines.DebugKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\t\n\u0002\u0010\t\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u0000\b\u0000\u0018\u00002\u00020*B\u0007¢\u0006\u0004\b\u0001\u0010\u0002J!\u0010\u0007\u001a\u0004\u0018\u00010\u00032\u0006\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u0019\u0010\t\u001a\u0004\u0018\u00010\u00032\u0006\u0010\u0004\u001a\u00020\u0003H\u0002¢\u0006\u0004\b\t\u0010\nJ\u0015\u0010\u000e\u001a\u00020\r2\u0006\u0010\f\u001a\u00020\u000b¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0010\u001a\u0004\u0018\u00010\u0003¢\u0006\u0004\b\u0010\u0010\u0011J\u0011\u0010\u0012\u001a\u0004\u0018\u00010\u0003H\u0002¢\u0006\u0004\b\u0012\u0010\u0011J\u0017\u0010\u0014\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\u000bH\u0002¢\u0006\u0004\b\u0014\u0010\u0015J\u0015\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u0000¢\u0006\u0004\b\u0018\u0010\u0019J\u0015\u0010\u001a\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u0000¢\u0006\u0004\b\u001a\u0010\u0019J\u001f\u0010\u001c\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\u0005H\u0002¢\u0006\u0004\b\u001c\u0010\u001dJ\u0015\u0010\u001e\u001a\u00020\r*\u0004\u0018\u00010\u0003H\u0002¢\u0006\u0004\b\u001e\u0010\u001fR\u001c\u0010!\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00030 8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b!\u0010\"R\u0014\u0010&\u001a\u00020#8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b$\u0010%R\u0014\u0010(\u001a\u00020#8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b'\u0010%¨\u0006)"},
   d2 = {"Lkotlinx/coroutines/scheduling/WorkQueue;", "WorkQueue", "()V", "Lkotlinx/coroutines/scheduling/Task;", "task", "", "fair", "add", "(Lkotlinx/coroutines/scheduling/Task;Z)Lkotlinx/coroutines/scheduling/Task;", "addLast", "(Lkotlinx/coroutines/scheduling/Task;)Lkotlinx/coroutines/scheduling/Task;", "Lkotlinx/coroutines/scheduling/GlobalQueue;", "globalQueue", "", "offloadAllWorkTo", "(Lkotlinx/coroutines/scheduling/GlobalQueue;)V", "poll", "()Lkotlinx/coroutines/scheduling/Task;", "pollBuffer", "queue", "pollTo", "(Lkotlinx/coroutines/scheduling/GlobalQueue;)Z", "victim", "", "tryStealBlockingFrom", "(Lkotlinx/coroutines/scheduling/WorkQueue;)J", "tryStealFrom", "blockingOnly", "tryStealLastScheduled", "(Lkotlinx/coroutines/scheduling/WorkQueue;Z)J", "decrementIfBlocking", "(Lkotlinx/coroutines/scheduling/Task;)V", "Ljava/util/concurrent/atomic/AtomicReferenceArray;", "buffer", "Ljava/util/concurrent/atomic/AtomicReferenceArray;", "", "getBufferSize$kotlinx_coroutines_core", "()I", "bufferSize", "getSize$kotlinx_coroutines_core", "size", "kotlinx-coroutines-core", ""}
)
public final class WorkQueue {
   @NotNull
   private final AtomicReferenceArray<Task> buffer = new AtomicReferenceArray(128);
   // $FF: synthetic field
   @NotNull
   private volatile Object lastScheduledTask = null;
   // $FF: synthetic field
   private static final AtomicReferenceFieldUpdater lastScheduledTask$FU = AtomicReferenceFieldUpdater.newUpdater(WorkQueue.class, Object.class, "lastScheduledTask");
   // $FF: synthetic field
   @NotNull
   private volatile int producerIndex = 0;
   // $FF: synthetic field
   private static final AtomicIntegerFieldUpdater producerIndex$FU = AtomicIntegerFieldUpdater.newUpdater(WorkQueue.class, "producerIndex");
   // $FF: synthetic field
   @NotNull
   private volatile int consumerIndex = 0;
   // $FF: synthetic field
   private static final AtomicIntegerFieldUpdater consumerIndex$FU = AtomicIntegerFieldUpdater.newUpdater(WorkQueue.class, "consumerIndex");
   // $FF: synthetic field
   @NotNull
   private volatile int blockingTasksInBuffer = 0;
   // $FF: synthetic field
   private static final AtomicIntegerFieldUpdater blockingTasksInBuffer$FU = AtomicIntegerFieldUpdater.newUpdater(WorkQueue.class, "blockingTasksInBuffer");

   public final int getBufferSize$kotlinx_coroutines_core() {
      return a.producerIndex - a.consumerIndex;
   }

   public final int getSize$kotlinx_coroutines_core() {
      return a.lastScheduledTask != null ? a.getBufferSize$kotlinx_coroutines_core() + 1 : a.getBufferSize$kotlinx_coroutines_core();
   }

   @Nullable
   public final Task poll() {
      Task var10000 = (Task)lastScheduledTask$FU.getAndSet(a, (Object)null);
      if (var10000 == null) {
         var10000 = a.pollBuffer();
      }

      return var10000;
   }

   @Nullable
   public final Task add(@NotNull Task a, boolean a) {
      if (a) {
         return a.addLast(a);
      } else {
         Task var10000 = (Task)lastScheduledTask$FU.getAndSet(a, a);
         if (var10000 == null) {
            return null;
         } else {
            Task a = var10000;
            return a.addLast(a);
         }
      }
   }

   // $FF: synthetic method
   public static Task add$default(WorkQueue var0, Task var1, boolean var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = false;
      }

      return var0.add(var1, var2);
   }

   private final Task addLast(Task a) {
      int a = false;
      if (a.taskContext.getTaskMode() == 1) {
         blockingTasksInBuffer$FU.incrementAndGet(a);
      }

      if (a.getBufferSize$kotlinx_coroutines_core() == 127) {
         return a;
      } else {
         int a = a.producerIndex & 127;

         while(a.buffer.get(a) != null) {
            Thread.yield();
         }

         a.buffer.lazySet(a, a);
         producerIndex$FU.incrementAndGet(a);
         return null;
      }
   }

   public final long tryStealFrom(@NotNull WorkQueue a) {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a.getBufferSize$kotlinx_coroutines_core() != 0) {
            throw new AssertionError();
         }
      }

      Task a = a.pollBuffer();
      if (a != null) {
         Task a = add$default(a, a, false, 2, (Object)null);
         if (DebugKt.getASSERTIONS_ENABLED()) {
            int a = false;
            if (a != null) {
               throw new AssertionError();
            }
         }

         return -1L;
      } else {
         return a.tryStealLastScheduled(a, false);
      }
   }

   public final long tryStealBlockingFrom(@NotNull WorkQueue a) {
      if (DebugKt.getASSERTIONS_ENABLED()) {
         int a = false;
         if (a.getBufferSize$kotlinx_coroutines_core() != 0) {
            throw new AssertionError();
         }
      }

      int a = a.consumerIndex;
      int a = a.producerIndex;

      for(AtomicReferenceArray a = a.buffer; a != a; ++a) {
         int a = a & 127;
         if (a.blockingTasksInBuffer == 0) {
            break;
         }

         Task a = (Task)a.get(a);
         if (a != null) {
            int a = false;
            if (a.taskContext.getTaskMode() == 1 && a.compareAndSet(a, a, (Object)null)) {
               blockingTasksInBuffer$FU.decrementAndGet(a);
               add$default(a, a, false, 2, (Object)null);
               return -1L;
            }
         }
      }

      return a.tryStealLastScheduled(a, true);
   }

   public final void offloadAllWorkTo(@NotNull GlobalQueue a) {
      Task var10000 = (Task)lastScheduledTask$FU.getAndSet(a, (Object)null);
      if (var10000 != null) {
         Task a = var10000;
         int a = false;
         a.addLast(a);
      }

      while(a.pollTo(a)) {
      }

   }

   private final long tryStealLastScheduled(WorkQueue a, boolean a) {
      Task a;
      do {
         Task var10000 = (Task)a.lastScheduledTask;
         if (var10000 == null) {
            return -2L;
         }

         a = var10000;
         if (a) {
            int a = false;
            if (a.taskContext.getTaskMode() != 1) {
               return -2L;
            }
         }

         long a = TasksKt.schedulerTimeSource.nanoTime();
         long a = a - a.submissionTime;
         if (a < TasksKt.WORK_STEALING_TIME_RESOLUTION_NS) {
            return TasksKt.WORK_STEALING_TIME_RESOLUTION_NS - a;
         }
      } while(!lastScheduledTask$FU.compareAndSet(a, a, (Object)null));

      add$default(a, a, false, 2, (Object)null);
      return -1L;
   }

   private final boolean pollTo(GlobalQueue a) {
      Task var10000 = a.pollBuffer();
      if (var10000 == null) {
         return false;
      } else {
         Task a = var10000;
         a.addLast(a);
         return true;
      }
   }

   private final Task pollBuffer() {
      while(true) {
         int a = a.consumerIndex;
         if (a - a.producerIndex == 0) {
            return null;
         }

         int a = a & 127;
         if (consumerIndex$FU.compareAndSet(a, a, a + 1)) {
            Task var10000 = (Task)a.buffer.getAndSet(a, (Object)null);
            if (var10000 != null) {
               Task a = var10000;
               a.decrementIfBlocking(a);
               return a;
            }
         }
      }
   }

   private final void decrementIfBlocking(Task a) {
      if (a != null) {
         int a = false;
         if (a.taskContext.getTaskMode() == 1) {
            int a = blockingTasksInBuffer$FU.decrementAndGet(a);
            if (DebugKt.getASSERTIONS_ENABLED()) {
               a = false;
               if (a < 0) {
                  throw new AssertionError();
               }
            }
         }
      }

   }
}
