package kotlinx.coroutines.scheduling;

import java.util.concurrent.Executor;
import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlinx.coroutines.ExecutorCoroutineDispatcher;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\n\b\u0010\u0018\u00002\u00020\u0001B-\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tJ\b\u0010\u0010\u001a\u00020\u0011H\u0016J\b\u0010\u0012\u001a\u00020\u000bH\u0002J\u001c\u0010\u0013\u001a\u00020\u00112\u0006\u0010\u0014\u001a\u00020\u00152\n\u0010\u0016\u001a\u00060\u0017j\u0002`\u0018H\u0016J)\u0010\u0019\u001a\u00020\u00112\n\u0010\u0016\u001a\u00060\u0017j\u0002`\u00182\u0006\u0010\u0014\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001cH\u0000¢\u0006\u0002\b\u001dJ\u001c\u0010\u001e\u001a\u00020\u00112\u0006\u0010\u0014\u001a\u00020\u00152\n\u0010\u0016\u001a\u00060\u0017j\u0002`\u0018H\u0016J\r\u0010\u001f\u001a\u00020\u0011H\u0000¢\u0006\u0002\b J\u0015\u0010!\u001a\u00020\u00112\u0006\u0010\"\u001a\u00020\u0006H\u0000¢\u0006\u0002\b#J\r\u0010$\u001a\u00020\u0011H\u0000¢\u0006\u0002\b%R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\r8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000e\u0010\u000fR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006&"},
   d2 = {"Lkotlinx/coroutines/scheduling/SchedulerCoroutineDispatcher;", "Lkotlinx/coroutines/ExecutorCoroutineDispatcher;", "corePoolSize", "", "maxPoolSize", "idleWorkerKeepAliveNs", "", "schedulerName", "", "(IIJLjava/lang/String;)V", "coroutineScheduler", "Lkotlinx/coroutines/scheduling/CoroutineScheduler;", "executor", "Ljava/util/concurrent/Executor;", "getExecutor", "()Ljava/util/concurrent/Executor;", "close", "", "createScheduler", "dispatch", "context", "Lkotlin/coroutines/CoroutineContext;", "block", "Ljava/lang/Runnable;", "Lkotlinx/coroutines/Runnable;", "dispatchWithContext", "Lkotlinx/coroutines/scheduling/TaskContext;", "tailDispatch", "", "dispatchWithContext$kotlinx_coroutines_core", "dispatchYield", "restore", "restore$kotlinx_coroutines_core", "shutdown", "timeout", "shutdown$kotlinx_coroutines_core", "usePrivateScheduler", "usePrivateScheduler$kotlinx_coroutines_core", "kotlinx-coroutines-core"}
)
public class SchedulerCoroutineDispatcher extends ExecutorCoroutineDispatcher {
   private final int corePoolSize;
   private final int maxPoolSize;
   private final long idleWorkerKeepAliveNs;
   @NotNull
   private final String schedulerName;
   @NotNull
   private CoroutineScheduler coroutineScheduler;

   public SchedulerCoroutineDispatcher(int a, int a, long a, @NotNull String a) {
      a.corePoolSize = a;
      a.maxPoolSize = a;
      a.idleWorkerKeepAliveNs = a;
      a.schedulerName = a;
      a.coroutineScheduler = a.createScheduler();
   }

   // $FF: synthetic method
   public SchedulerCoroutineDispatcher(int var1, int var2, long var3, String var5, int var6, DefaultConstructorMarker var7) {
      if ((var6 & 1) != 0) {
         var1 = TasksKt.CORE_POOL_SIZE;
      }

      if ((var6 & 2) != 0) {
         var2 = TasksKt.MAX_POOL_SIZE;
      }

      if ((var6 & 4) != 0) {
         var3 = TasksKt.IDLE_WORKER_KEEP_ALIVE_NS;
      }

      if ((var6 & 8) != 0) {
         var5 = "CoroutineScheduler";
      }

      this(var1, var2, var3, var5);
   }

   @NotNull
   public Executor getExecutor() {
      return (Executor)a.coroutineScheduler;
   }

   private final CoroutineScheduler createScheduler() {
      return new CoroutineScheduler(a.corePoolSize, a.maxPoolSize, a.idleWorkerKeepAliveNs, a.schedulerName);
   }

   public void dispatch(@NotNull CoroutineContext a1, @NotNull Runnable a) {
      CoroutineScheduler.dispatch$default(a.coroutineScheduler, a, (TaskContext)null, false, 6, (Object)null);
   }

   public void dispatchYield(@NotNull CoroutineContext a1, @NotNull Runnable a) {
      CoroutineScheduler.dispatch$default(a.coroutineScheduler, a, (TaskContext)null, true, 2, (Object)null);
   }

   public final void dispatchWithContext$kotlinx_coroutines_core(@NotNull Runnable a, @NotNull TaskContext a, boolean a) {
      a.coroutineScheduler.dispatch(a, a, a);
   }

   public void close() {
      a.coroutineScheduler.close();
   }

   public final synchronized void usePrivateScheduler$kotlinx_coroutines_core() {
      a.coroutineScheduler.shutdown(1000L);
      a.coroutineScheduler = a.createScheduler();
   }

   public final synchronized void shutdown$kotlinx_coroutines_core(long a) {
      a.coroutineScheduler.shutdown(a);
   }

   public final void restore$kotlinx_coroutines_core() {
      a.usePrivateScheduler$kotlinx_coroutines_core();
   }

   public SchedulerCoroutineDispatcher() {
      this(0, 0, 0L, (String)null, 15, (DefaultConstructorMarker)null);
   }
}
