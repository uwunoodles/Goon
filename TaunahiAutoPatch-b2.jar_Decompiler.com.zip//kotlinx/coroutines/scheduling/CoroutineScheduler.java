package kotlinx.coroutines.scheduling;

import java.io.Closeable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.JvmField;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.Random;
import kotlin.ranges.RangesKt;
import kotlinx.coroutines.AbstractTimeSource;
import kotlinx.coroutines.AbstractTimeSourceKt;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.DebugStringsKt;
import kotlinx.coroutines.internal.ResizableAtomicArray;
import kotlinx.coroutines.internal.Symbol;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b-\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\b\u0000\u0018\u0000 X2\u00020\\2\u00020]:\u0003XYZB+\u0012\u0006\u0010\u0002\u001a\u00020\u0001\u0012\u0006\u0010\u0003\u001a\u00020\u0001\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u0017\u0010\r\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\nH\u0002¢\u0006\u0004\b\r\u0010\u000eJ\u0018\u0010\u0010\u001a\u00020\u00012\u0006\u0010\u000f\u001a\u00020\u0004H\u0086\b¢\u0006\u0004\b\u0010\u0010\u0011J\u0018\u0010\u0012\u001a\u00020\u00012\u0006\u0010\u000f\u001a\u00020\u0004H\u0082\b¢\u0006\u0004\b\u0012\u0010\u0011J\u000f\u0010\u0014\u001a\u00020\u0013H\u0016¢\u0006\u0004\b\u0014\u0010\u0015J\u000f\u0010\u0016\u001a\u00020\u0001H\u0002¢\u0006\u0004\b\u0016\u0010\u0017J!\u0010\u001d\u001a\u00020\n2\n\u0010\u001a\u001a\u00060\u0018j\u0002`\u00192\u0006\u0010\u001c\u001a\u00020\u001b¢\u0006\u0004\b\u001d\u0010\u001eJ\u0018\u0010\u001f\u001a\u00020\u00012\u0006\u0010\u000f\u001a\u00020\u0004H\u0082\b¢\u0006\u0004\b\u001f\u0010\u0011J\u0015\u0010!\u001a\b\u0018\u00010 R\u00020\u0000H\u0002¢\u0006\u0004\b!\u0010\"J\u0010\u0010#\u001a\u00020\u0013H\u0082\b¢\u0006\u0004\b#\u0010\u0015J\u0010\u0010$\u001a\u00020\u0001H\u0082\b¢\u0006\u0004\b$\u0010\u0017J-\u0010&\u001a\u00020\u00132\n\u0010\u001a\u001a\u00060\u0018j\u0002`\u00192\b\b\u0002\u0010\u001c\u001a\u00020\u001b2\b\b\u0002\u0010%\u001a\u00020\f¢\u0006\u0004\b&\u0010'J\u001b\u0010)\u001a\u00020\u00132\n\u0010(\u001a\u00060\u0018j\u0002`\u0019H\u0016¢\u0006\u0004\b)\u0010*J\u0010\u0010+\u001a\u00020\u0004H\u0082\b¢\u0006\u0004\b+\u0010,J\u0010\u0010-\u001a\u00020\u0001H\u0082\b¢\u0006\u0004\b-\u0010\u0017J\u001b\u0010/\u001a\u00020\u00012\n\u0010.\u001a\u00060 R\u00020\u0000H\u0002¢\u0006\u0004\b/\u00100J\u0015\u00101\u001a\b\u0018\u00010 R\u00020\u0000H\u0002¢\u0006\u0004\b1\u0010\"J\u0019\u00102\u001a\u00020\f2\n\u0010.\u001a\u00060 R\u00020\u0000¢\u0006\u0004\b2\u00103J)\u00106\u001a\u00020\u00132\n\u0010.\u001a\u00060 R\u00020\u00002\u0006\u00104\u001a\u00020\u00012\u0006\u00105\u001a\u00020\u0001¢\u0006\u0004\b6\u00107J\u0010\u00108\u001a\u00020\u0004H\u0082\b¢\u0006\u0004\b8\u0010,J\u0015\u00109\u001a\u00020\u00132\u0006\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b9\u0010:J\u0015\u0010<\u001a\u00020\u00132\u0006\u0010;\u001a\u00020\u0004¢\u0006\u0004\b<\u0010=J\u0017\u0010?\u001a\u00020\u00132\u0006\u0010>\u001a\u00020\fH\u0002¢\u0006\u0004\b?\u0010@J\r\u0010A\u001a\u00020\u0013¢\u0006\u0004\bA\u0010\u0015J\u000f\u0010B\u001a\u00020\u0006H\u0016¢\u0006\u0004\bB\u0010CJ\u0010\u0010D\u001a\u00020\fH\u0082\b¢\u0006\u0004\bD\u0010EJ\u0019\u0010F\u001a\u00020\f2\b\b\u0002\u0010\u000f\u001a\u00020\u0004H\u0002¢\u0006\u0004\bF\u0010GJ\u000f\u0010H\u001a\u00020\fH\u0002¢\u0006\u0004\bH\u0010EJ+\u0010I\u001a\u0004\u0018\u00010\n*\b\u0018\u00010 R\u00020\u00002\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010%\u001a\u00020\fH\u0002¢\u0006\u0004\bI\u0010JR\u0015\u0010\u0010\u001a\u00020\u00018Â\u0002X\u0082\u0004¢\u0006\u0006\u001a\u0004\bK\u0010\u0017R\u0014\u0010\u0002\u001a\u00020\u00018\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0002\u0010LR\u0015\u0010\u001f\u001a\u00020\u00018Â\u0002X\u0082\u0004¢\u0006\u0006\u001a\u0004\bM\u0010\u0017R\u0014\u0010O\u001a\u00020N8\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\bO\u0010PR\u0014\u0010Q\u001a\u00020N8\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\bQ\u0010PR\u0014\u0010\u0005\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0005\u0010RR\u0011\u0010S\u001a\u00020\f8F¢\u0006\u0006\u001a\u0004\bS\u0010ER\u0014\u0010\u0003\u001a\u00020\u00018\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0003\u0010LR\u0014\u0010\u0007\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0007\u0010TR\u001e\u0010V\u001a\f\u0012\b\u0012\u00060 R\u00020\u00000U8\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\bV\u0010W¨\u0006["},
   d2 = {"Lkotlinx/coroutines/scheduling/CoroutineScheduler;", "", "corePoolSize", "maxPoolSize", "", "idleWorkerKeepAliveNs", "", "schedulerName", "CoroutineScheduler", "(IIJLjava/lang/String;)V", "Lkotlinx/coroutines/scheduling/Task;", "task", "", "addToGlobalQueue", "(Lkotlinx/coroutines/scheduling/Task;)Z", "state", "availableCpuPermits", "(J)I", "blockingTasks", "", "close", "()V", "createNewWorker", "()I", "Ljava/lang/Runnable;", "Lkotlinx/coroutines/Runnable;", "block", "Lkotlinx/coroutines/scheduling/TaskContext;", "taskContext", "createTask", "(Ljava/lang/Runnable;Lkotlinx/coroutines/scheduling/TaskContext;)Lkotlinx/coroutines/scheduling/Task;", "createdWorkers", "Lkotlinx/coroutines/scheduling/CoroutineScheduler$Worker;", "currentWorker", "()Lkotlinx/coroutines/scheduling/CoroutineScheduler$Worker;", "decrementBlockingTasks", "decrementCreatedWorkers", "tailDispatch", "dispatch", "(Ljava/lang/Runnable;Lkotlinx/coroutines/scheduling/TaskContext;Z)V", "command", "execute", "(Ljava/lang/Runnable;)V", "incrementBlockingTasks", "()J", "incrementCreatedWorkers", "worker", "parkedWorkersStackNextIndex", "(Lkotlinx/coroutines/scheduling/CoroutineScheduler$Worker;)I", "parkedWorkersStackPop", "parkedWorkersStackPush", "(Lkotlinx/coroutines/scheduling/CoroutineScheduler$Worker;)Z", "oldIndex", "newIndex", "parkedWorkersStackTopUpdate", "(Lkotlinx/coroutines/scheduling/CoroutineScheduler$Worker;II)V", "releaseCpuPermit", "runSafely", "(Lkotlinx/coroutines/scheduling/Task;)V", "timeout", "shutdown", "(J)V", "skipUnpark", "signalBlockingWork", "(Z)V", "signalCpuWork", "toString", "()Ljava/lang/String;", "tryAcquireCpuPermit", "()Z", "tryCreateWorker", "(J)Z", "tryUnpark", "submitToLocalQueue", "(Lkotlinx/coroutines/scheduling/CoroutineScheduler$Worker;Lkotlinx/coroutines/scheduling/Task;Z)Lkotlinx/coroutines/scheduling/Task;", "getAvailableCpuPermits", "I", "getCreatedWorkers", "Lkotlinx/coroutines/scheduling/GlobalQueue;", "globalBlockingQueue", "Lkotlinx/coroutines/scheduling/GlobalQueue;", "globalCpuQueue", "J", "isTerminated", "Ljava/lang/String;", "Lkotlinx/coroutines/internal/ResizableAtomicArray;", "workers", "Lkotlinx/coroutines/internal/ResizableAtomicArray;", "Companion", "Worker", "WorkerState", "kotlinx-coroutines-core", "Ljava/util/concurrent/Executor;", "Ljava/io/Closeable;"}
)
public final class CoroutineScheduler implements Executor, Closeable {
   @NotNull
   public static final CoroutineScheduler.Companion Companion = new CoroutineScheduler.Companion((DefaultConstructorMarker)null);
   @JvmField
   public final int corePoolSize;
   @JvmField
   public final int maxPoolSize;
   @JvmField
   public final long idleWorkerKeepAliveNs;
   @JvmField
   @NotNull
   public final String schedulerName;
   @JvmField
   @NotNull
   public final GlobalQueue globalCpuQueue;
   @JvmField
   @NotNull
   public final GlobalQueue globalBlockingQueue;
   // $FF: synthetic field
   @NotNull
   private volatile long parkedWorkersStack;
   // $FF: synthetic field
   private static final AtomicLongFieldUpdater parkedWorkersStack$FU = AtomicLongFieldUpdater.newUpdater(CoroutineScheduler.class, "parkedWorkersStack");
   @JvmField
   @NotNull
   public final ResizableAtomicArray<CoroutineScheduler.Worker> workers;
   // $FF: synthetic field
   @NotNull
   volatile long controlState;
   // $FF: synthetic field
   static final AtomicLongFieldUpdater controlState$FU = AtomicLongFieldUpdater.newUpdater(CoroutineScheduler.class, "controlState");
   // $FF: synthetic field
   @NotNull
   private volatile int _isTerminated;
   // $FF: synthetic field
   private static final AtomicIntegerFieldUpdater _isTerminated$FU = AtomicIntegerFieldUpdater.newUpdater(CoroutineScheduler.class, "_isTerminated");
   @JvmField
   @NotNull
   public static final Symbol NOT_IN_STACK = new Symbol("NOT_IN_STACK");
   private static final int PARKED = -1;
   private static final int CLAIMED = 0;
   private static final int TERMINATED = 1;
   private static final int BLOCKING_SHIFT = 21;
   private static final long CREATED_MASK = 2097151L;
   private static final long BLOCKING_MASK = 4398044413952L;
   private static final int CPU_PERMITS_SHIFT = 42;
   private static final long CPU_PERMITS_MASK = 9223367638808264704L;
   public static final int MIN_SUPPORTED_POOL_SIZE = 1;
   public static final int MAX_SUPPORTED_POOL_SIZE = 2097150;
   private static final long PARKED_INDEX_MASK = 2097151L;
   private static final long PARKED_VERSION_MASK = -2097152L;
   private static final long PARKED_VERSION_INC = 2097152L;

   public CoroutineScheduler(int a, int a, long a, @NotNull String a) {
      a.corePoolSize = a;
      a.maxPoolSize = a;
      a.idleWorkerKeepAliveNs = a;
      a.schedulerName = a;
      boolean a;
      String var7;
      if (a.corePoolSize < 1) {
         a = false;
         var7 = "Core pool size " + a.corePoolSize + " should be at least 1";
         throw new IllegalArgumentException(var7.toString());
      } else if (a.maxPoolSize < a.corePoolSize) {
         a = false;
         var7 = "Max pool size " + a.maxPoolSize + " should be greater than or equals to core pool size " + a.corePoolSize;
         throw new IllegalArgumentException(var7.toString());
      } else if (a.maxPoolSize > 2097150) {
         a = false;
         var7 = "Max pool size " + a.maxPoolSize + " should not exceed maximal supported number of threads 2097150";
         throw new IllegalArgumentException(var7.toString());
      } else if (a.idleWorkerKeepAliveNs <= 0L) {
         a = false;
         var7 = "Idle worker keep alive time " + a.idleWorkerKeepAliveNs + " must be positive";
         throw new IllegalArgumentException(var7.toString());
      } else {
         a.globalCpuQueue = new GlobalQueue();
         a.globalBlockingQueue = new GlobalQueue();
         a.parkedWorkersStack = 0L;
         a.workers = new ResizableAtomicArray(a.corePoolSize + 1);
         a.controlState = (long)a.corePoolSize << 42;
         a._isTerminated = 0;
      }
   }

   // $FF: synthetic method
   public CoroutineScheduler(int var1, int var2, long var3, String var5, int var6, DefaultConstructorMarker var7) {
      if ((var6 & 4) != 0) {
         var3 = TasksKt.IDLE_WORKER_KEEP_ALIVE_NS;
      }

      if ((var6 & 8) != 0) {
         var5 = "DefaultDispatcher";
      }

      this(var1, var2, var3, var5);
   }

   private final boolean addToGlobalQueue(Task a) {
      int a = false;
      return a.taskContext.getTaskMode() == 1 ? a.globalBlockingQueue.addLast(a) : a.globalCpuQueue.addLast(a);
   }

   public final void parkedWorkersStackTopUpdate(@NotNull CoroutineScheduler.Worker a, int a, int a) {
      CoroutineScheduler a = a;
      boolean var5 = false;

      long a;
      long a;
      int a;
      do {
         a = a.parkedWorkersStack;
         int a = false;
         int a = (int)(a & 2097151L);
         a = a + 2097152L & -2097152L;
         a = a == a ? (a == 0 ? a.parkedWorkersStackNextIndex(a) : a) : a;
      } while(a < 0 || !parkedWorkersStack$FU.compareAndSet(a, a, a | (long)a));

   }

   public final boolean parkedWorkersStackPush(@NotNull CoroutineScheduler.Worker a) {
      if (a.getNextParkedWorker() != NOT_IN_STACK) {
         return false;
      } else {
         CoroutineScheduler a = a;
         boolean var3 = false;

         long a;
         long a;
         int a;
         do {
            a = a.parkedWorkersStack;
            int a = false;
            int a = (int)(a & 2097151L);
            a = a + 2097152L & -2097152L;
            a = a.getIndexInArray();
            if (DebugKt.getASSERTIONS_ENABLED()) {
               int a = false;
               if (a == 0) {
                  throw new AssertionError();
               }
            }

            a.setNextParkedWorker(a.workers.get(a));
         } while(!parkedWorkersStack$FU.compareAndSet(a, a, a | (long)a));

         return true;
      }
   }

   private final CoroutineScheduler.Worker parkedWorkersStackPop() {
      CoroutineScheduler a = a;
      boolean var2 = false;

      long a;
      CoroutineScheduler.Worker a;
      long a;
      int a;
      do {
         a = a.parkedWorkersStack;
         int a = false;
         int a = (int)(a & 2097151L);
         CoroutineScheduler.Worker var10000 = (CoroutineScheduler.Worker)a.workers.get(a);
         if (var10000 == null) {
            return null;
         }

         a = var10000;
         a = a + 2097152L & -2097152L;
         a = a.parkedWorkersStackNextIndex(a);
      } while(a < 0 || !parkedWorkersStack$FU.compareAndSet(a, a, a | (long)a));

      a.setNextParkedWorker(NOT_IN_STACK);
      return a;
   }

   private final int parkedWorkersStackNextIndex(CoroutineScheduler.Worker a) {
      CoroutineScheduler.Worker a;
      for(Object a = a.getNextParkedWorker(); a != NOT_IN_STACK; a = a.getNextParkedWorker()) {
         if (a == null) {
            return 0;
         }

         a = (CoroutineScheduler.Worker)a;
         int a = a.getIndexInArray();
         if (a != 0) {
            return a;
         }
      }

      return -1;
   }

   private final int getCreatedWorkers() {
      int a = false;
      return (int)(a.controlState & 2097151L);
   }

   private final int getAvailableCpuPermits() {
      int a = false;
      long a = a.controlState;
      int a = false;
      return (int)((a & 9223367638808264704L) >> 42);
   }

   private final int createdWorkers(long a) {
      int a = false;
      return (int)(a & 2097151L);
   }

   private final int blockingTasks(long a) {
      int a = false;
      return (int)((a & 4398044413952L) >> 21);
   }

   public final int availableCpuPermits(long a) {
      int a = false;
      return (int)((a & 9223367638808264704L) >> 42);
   }

   private final int incrementCreatedWorkers() {
      int a = false;
      long a = controlState$FU.incrementAndGet(a);
      int a = false;
      return (int)(a & 2097151L);
   }

   private final int decrementCreatedWorkers() {
      int a = false;
      long a = controlState$FU.getAndDecrement(a);
      int a = false;
      return (int)(a & 2097151L);
   }

   private final long incrementBlockingTasks() {
      int a = false;
      return controlState$FU.addAndGet(a, 2097152L);
   }

   private final void decrementBlockingTasks() {
      int a = false;
      controlState$FU.addAndGet(a, -2097152L);
   }

   private final boolean tryAcquireCpuPermit() {
      int a = false;
      CoroutineScheduler a = a;
      boolean var3 = false;

      long a;
      long a;
      do {
         a = a.controlState;
         int a = false;
         int a = false;
         int a = (int)((a & 9223367638808264704L) >> 42);
         if (a == 0) {
            return false;
         }

         a = a - 4398046511104L;
      } while(!controlState$FU.compareAndSet(a, a, a));

      return true;
   }

   private final long releaseCpuPermit() {
      int a = false;
      return controlState$FU.addAndGet(a, 4398046511104L);
   }

   public final boolean isTerminated() {
      return (boolean)a._isTerminated;
   }

   public void execute(@NotNull Runnable a) {
      dispatch$default(a, a, (TaskContext)null, false, 6, (Object)null);
   }

   public void close() {
      a.shutdown(10000L);
   }

   public final void shutdown(long param1) {
      // $FF: Couldn't be decompiled
   }

   public final void dispatch(@NotNull Runnable a, @NotNull TaskContext a, boolean a) {
      AbstractTimeSource var10000 = AbstractTimeSourceKt.getTimeSource();
      if (var10000 != null) {
         var10000.trackTask();
      }

      Task a = a.createTask(a, a);
      CoroutineScheduler.Worker a = a.currentWorker();
      Task a = a.submitToLocalQueue(a, a, a);
      if (a != null && !a.addToGlobalQueue(a)) {
         throw new RejectedExecutionException(a.schedulerName + " was terminated");
      } else {
         boolean a = a && a != null;
         int a = false;
         if (a.taskContext.getTaskMode() == 0) {
            if (a) {
               return;
            }

            a.signalCpuWork();
         } else {
            a.signalBlockingWork(a);
         }

      }
   }

   // $FF: synthetic method
   public static void dispatch$default(CoroutineScheduler var0, Runnable var1, TaskContext var2, boolean var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = TasksKt.NonBlockingContext;
      }

      if ((var4 & 4) != 0) {
         var3 = false;
      }

      var0.dispatch(var1, var2, var3);
   }

   @NotNull
   public final Task createTask(@NotNull Runnable a, @NotNull TaskContext a) {
      long a = TasksKt.schedulerTimeSource.nanoTime();
      if (a instanceof Task) {
         ((Task)a).submissionTime = a;
         ((Task)a).taskContext = a;
         return (Task)a;
      } else {
         return (Task)(new TaskImpl(a, a, a));
      }
   }

   private final void signalBlockingWork(boolean a) {
      int a = false;
      long a = controlState$FU.addAndGet(a, 2097152L);
      if (!a) {
         if (!a.tryUnpark()) {
            if (!a.tryCreateWorker(a)) {
               a.tryUnpark();
            }
         }
      }
   }

   public final void signalCpuWork() {
      if (!a.tryUnpark()) {
         if (!tryCreateWorker$default(a, 0L, 1, (Object)null)) {
            a.tryUnpark();
         }
      }
   }

   private final boolean tryCreateWorker(long a) {
      int a = false;
      int a = (int)(a & 2097151L);
      int a = false;
      int a = (int)((a & 4398044413952L) >> 21);
      int a = RangesKt.coerceAtLeast(a - a, 0);
      if (a < a.corePoolSize) {
         int a = a.createNewWorker();
         if (a == 1 && a.corePoolSize > 1) {
            a.createNewWorker();
         }

         if (a > 0) {
            return true;
         }
      }

      return false;
   }

   // $FF: synthetic method
   static boolean tryCreateWorker$default(CoroutineScheduler var0, long var1, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = var0.controlState;
      }

      return var0.tryCreateWorker(var1);
   }

   private final boolean tryUnpark() {
      CoroutineScheduler.Worker a;
      do {
         CoroutineScheduler.Worker var10000 = a.parkedWorkersStackPop();
         if (var10000 == null) {
            return false;
         }

         a = var10000;
      } while(!CoroutineScheduler.Worker.workerCtl$FU.compareAndSet(a, -1, 0));

      LockSupport.unpark((Thread)a);
      return true;
   }

   private final int createNewWorker() {
      Object a = a.workers;
      int a = false;
      synchronized(a){}

      byte var20;
      try {
         int a = false;
         if (a.isTerminated()) {
            byte var21 = -1;
            return var21;
         }

         long a = a.controlState;
         int a = false;
         int a = (int)(a & 2097151L);
         int a = false;
         int a = (int)((a & 4398044413952L) >> 21);
         int a = RangesKt.coerceAtLeast(a - a, 0);
         if (a < a.corePoolSize) {
            if (a >= a.maxPoolSize) {
               byte var19 = 0;
               return var19;
            }

            int a = false;
            int a = (int)(a.controlState & 2097151L) + 1;
            if (a <= 0 || a.workers.get(a) != null) {
               String var26 = "Failed requirement.";
               throw new IllegalArgumentException(var26.toString());
            }

            CoroutineScheduler.Worker a = new CoroutineScheduler.Worker(a);
            a.workers.setSynchronized(a, a);
            int a = false;
            long a = controlState$FU.incrementAndGet(a);
            int a = false;
            if (a != (int)(a & 2097151L)) {
               String var27 = "Failed requirement.";
               throw new IllegalArgumentException(var27.toString());
            }

            a.start();
            int var18 = a + 1;
            return var18;
         }

         var20 = 0;
      } finally {
         ;
      }

      return var20;
   }

   private final Task submitToLocalQueue(CoroutineScheduler.Worker a, Task a, boolean a) {
      if (a == null) {
         return a;
      } else if (a.state == CoroutineScheduler.WorkerState.TERMINATED) {
         return a;
      } else {
         int a = false;
         if (a.taskContext.getTaskMode() == 0 && a.state == CoroutineScheduler.WorkerState.BLOCKING) {
            return a;
         } else {
            a.mayHaveLocalTasks = true;
            return a.localQueue.add(a, a);
         }
      }
   }

   private final CoroutineScheduler.Worker currentWorker() {
      Thread var1 = Thread.currentThread();
      CoroutineScheduler.Worker var10000 = var1 instanceof CoroutineScheduler.Worker ? (CoroutineScheduler.Worker)var1 : null;
      if ((var1 instanceof CoroutineScheduler.Worker ? (CoroutineScheduler.Worker)var1 : null) != null) {
         CoroutineScheduler.Worker var6 = var10000;
         int ax = false;
         int axx = false;
         var10000 = Intrinsics.areEqual((Object)CoroutineScheduler.this, (Object)a) ? var6 : null;
      } else {
         var10000 = null;
      }

      return var10000;
   }

   @NotNull
   public String toString() {
      int a = 0;
      int a = 0;
      int a = 0;
      int a = 0;
      int a = 0;
      ArrayList a = new ArrayList();
      int a = 1;

      for(int var8 = a.workers.currentLength(); a < var8; ++a) {
         CoroutineScheduler.Worker var10000 = (CoroutineScheduler.Worker)a.workers.get(a);
         if (var10000 != null) {
            CoroutineScheduler.Worker a = var10000;
            int a = a.localQueue.getSize$kotlinx_coroutines_core();
            switch(CoroutineScheduler.WhenMappings.$EnumSwitchMapping$0[a.state.ordinal()]) {
            case 1:
               ++a;
               break;
            case 2:
               ++a;
               ((Collection)a).add("" + a + 'b');
               break;
            case 3:
               ++a;
               ((Collection)a).add("" + a + 'c');
               break;
            case 4:
               ++a;
               if (a > 0) {
                  ((Collection)a).add("" + a + 'd');
               }
               break;
            case 5:
               ++a;
            }
         }
      }

      long a = a.controlState;
      StringBuilder var13 = new StringBuilder();
      var13.append(a.schedulerName).append('@').append(DebugStringsKt.getHexAddress(a)).append("[Pool Size {core = ").append(a.corePoolSize).append(", max = ").append(a.maxPoolSize).append("}, Worker States {CPU = ").append(a).append(", blocking = ").append(a).append(", parked = ").append(a).append(", dormant = ").append(a).append(", terminated = ").append(a).append("}, running workers queues = ").append(a).append(", global CPU queue size = ").append(a.globalCpuQueue.getSize()).append(", global blocking queue size = ").append(a.globalBlockingQueue.getSize());
      StringBuilder var14 = var13.append(", Control State {created workers= ");
      int a = false;
      var14 = var14.append((int)(a & 2097151L)).append(", blocking tasks = ");
      a = false;
      var14 = var14.append((int)((a & 4398044413952L) >> 21)).append(", CPUs acquired = ");
      a = false;
      var14.append(a.corePoolSize - (int)((a & 9223367638808264704L) >> 42)).append("}]");
      return var13.toString();
   }

   public final void runSafely(@NotNull Task a) {
      try {
         a.run();
      } catch (Throwable var6) {
         Thread a = Thread.currentThread();
         a.getUncaughtExceptionHandler().uncaughtException(a, var6);
      } finally {
         AbstractTimeSource var10000 = AbstractTimeSourceKt.getTimeSource();
         if (var10000 != null) {
            var10000.unTrackTask();
         }

      }

   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0006X\u0080T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0006X\u0080T¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u00020\u000e8\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0014"},
      d2 = {"Lkotlinx/coroutines/scheduling/CoroutineScheduler$Companion;", "", "()V", "BLOCKING_MASK", "", "BLOCKING_SHIFT", "", "CLAIMED", "CPU_PERMITS_MASK", "CPU_PERMITS_SHIFT", "CREATED_MASK", "MAX_SUPPORTED_POOL_SIZE", "MIN_SUPPORTED_POOL_SIZE", "NOT_IN_STACK", "Lkotlinx/coroutines/internal/Symbol;", "PARKED", "PARKED_INDEX_MASK", "PARKED_VERSION_INC", "PARKED_VERSION_MASK", "TERMINATED", "kotlinx-coroutines-core"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker a1) {
         this();
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0013\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\b\u0080\u0004\u0018\u00002\u00020GB\u0011\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0004\b\u0003\u0010\u0004B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0005J\u0017\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0001H\u0002¢\u0006\u0004\b\b\u0010\tJ\u0017\u0010\n\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0001H\u0002¢\u0006\u0004\b\n\u0010\tJ\u0017\u0010\r\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\u000bH\u0002¢\u0006\u0004\b\r\u0010\u000eJ\u0019\u0010\u0011\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\u0010\u001a\u00020\u000fH\u0002¢\u0006\u0004\b\u0011\u0010\u0012J\u0017\u0010\u0013\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\u0010\u001a\u00020\u000f¢\u0006\u0004\b\u0013\u0010\u0012J\u0017\u0010\u0015\u001a\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u0001H\u0002¢\u0006\u0004\b\u0015\u0010\tJ\u000f\u0010\u0016\u001a\u00020\u000fH\u0002¢\u0006\u0004\b\u0016\u0010\u0017J\u0015\u0010\u0019\u001a\u00020\u00012\u0006\u0010\u0018\u001a\u00020\u0001¢\u0006\u0004\b\u0019\u0010\u001aJ\u000f\u0010\u001b\u001a\u00020\u0007H\u0002¢\u0006\u0004\b\u001b\u0010\u001cJ\u0011\u0010\u001d\u001a\u0004\u0018\u00010\u000bH\u0002¢\u0006\u0004\b\u001d\u0010\u001eJ\u000f\u0010\u001f\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u001f\u0010\u001cJ\u000f\u0010 \u001a\u00020\u0007H\u0002¢\u0006\u0004\b \u0010\u001cJ\u000f\u0010!\u001a\u00020\u000fH\u0002¢\u0006\u0004\b!\u0010\u0017J\u000f\u0010\"\u001a\u00020\u0007H\u0002¢\u0006\u0004\b\"\u0010\u001cJ\u0015\u0010%\u001a\u00020\u000f2\u0006\u0010$\u001a\u00020#¢\u0006\u0004\b%\u0010&J\u0019\u0010(\u001a\u0004\u0018\u00010\u000b2\u0006\u0010'\u001a\u00020\u000fH\u0002¢\u0006\u0004\b(\u0010\u0012J\u000f\u0010)\u001a\u00020\u0007H\u0002¢\u0006\u0004\b)\u0010\u001cR*\u0010*\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00018\u0006@FX\u0086\u000e¢\u0006\u0012\n\u0004\b*\u0010+\u001a\u0004\b,\u0010-\"\u0004\b.\u0010\tR\u0014\u00100\u001a\u00020/8\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b0\u00101R\u0016\u00102\u001a\u00020\u000f8\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b2\u00103R\u0016\u00105\u001a\u0002048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b5\u00106R$\u00108\u001a\u0004\u0018\u0001078\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b8\u00109\u001a\u0004\b:\u0010;\"\u0004\b<\u0010=R\u0016\u0010>\u001a\u00020\u00018\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b>\u0010+R\u0012\u0010B\u001a\u00020?8Æ\u0002¢\u0006\u0006\u001a\u0004\b@\u0010AR\u0016\u0010C\u001a\u00020#8\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\bC\u0010DR\u0016\u0010E\u001a\u0002048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bE\u00106¨\u0006F"},
      d2 = {"Lkotlinx/coroutines/scheduling/CoroutineScheduler$Worker;", "", "index", "CoroutineScheduler$Worker", "(Lkotlinx/coroutines/scheduling/CoroutineScheduler;I)V", "(Lkotlinx/coroutines/scheduling/CoroutineScheduler;)V", "taskMode", "", "afterTask", "(I)V", "beforeTask", "Lkotlinx/coroutines/scheduling/Task;", "task", "executeTask", "(Lkotlinx/coroutines/scheduling/Task;)V", "", "scanLocalQueue", "findAnyTask", "(Z)Lkotlinx/coroutines/scheduling/Task;", "findTask", "mode", "idleReset", "inStack", "()Z", "upperBound", "nextInt", "(I)I", "park", "()V", "pollGlobalQueues", "()Lkotlinx/coroutines/scheduling/Task;", "run", "runWorker", "tryAcquireCpuPermit", "tryPark", "Lkotlinx/coroutines/scheduling/CoroutineScheduler$WorkerState;", "newState", "tryReleaseCpu", "(Lkotlinx/coroutines/scheduling/CoroutineScheduler$WorkerState;)Z", "blockingOnly", "trySteal", "tryTerminateWorker", "indexInArray", "I", "getIndexInArray", "()I", "setIndexInArray", "Lkotlinx/coroutines/scheduling/WorkQueue;", "localQueue", "Lkotlinx/coroutines/scheduling/WorkQueue;", "mayHaveLocalTasks", "Z", "", "minDelayUntilStealableTaskNs", "J", "", "nextParkedWorker", "Ljava/lang/Object;", "getNextParkedWorker", "()Ljava/lang/Object;", "setNextParkedWorker", "(Ljava/lang/Object;)V", "rngState", "Lkotlinx/coroutines/scheduling/CoroutineScheduler;", "getScheduler", "()Lkotlinx/coroutines/scheduling/CoroutineScheduler;", "scheduler", "state", "Lkotlinx/coroutines/scheduling/CoroutineScheduler$WorkerState;", "terminationDeadline", "kotlinx-coroutines-core", "Ljava/lang/Thread;"}
   )
   public final class Worker extends Thread {
      private volatile int indexInArray;
      @JvmField
      @NotNull
      public final WorkQueue localQueue;
      @JvmField
      @NotNull
      public CoroutineScheduler.WorkerState state;
      // $FF: synthetic field
      @NotNull
      volatile int workerCtl;
      // $FF: synthetic field
      static final AtomicIntegerFieldUpdater workerCtl$FU = AtomicIntegerFieldUpdater.newUpdater(CoroutineScheduler.Worker.class, "workerCtl");
      private long terminationDeadline;
      @Nullable
      private volatile Object nextParkedWorker;
      private long minDelayUntilStealableTaskNs;
      private int rngState;
      @JvmField
      public boolean mayHaveLocalTasks;

      private Worker() {
         a.setDaemon(true);
         a.localQueue = new WorkQueue();
         a.state = CoroutineScheduler.WorkerState.DORMANT;
         a.workerCtl = 0;
         a.nextParkedWorker = CoroutineScheduler.NOT_IN_STACK;
         a.rngState = Random.Default.nextInt();
      }

      public final int getIndexInArray() {
         return a.indexInArray;
      }

      public final void setIndexInArray(int ax) {
         a.setName(CoroutineScheduler.this.schedulerName + "-worker-" + (ax == 0 ? "TERMINATED" : String.valueOf(ax)));
         a.indexInArray = ax;
      }

      public Worker(int axx) {
         this();
         a.setIndexInArray(axx);
      }

      @NotNull
      public final CoroutineScheduler getScheduler() {
         int ax = false;
         return access$getThis$0$p(a);
      }

      @Nullable
      public final Object getNextParkedWorker() {
         return a.nextParkedWorker;
      }

      public final void setNextParkedWorker(@Nullable Object ax) {
         a.nextParkedWorker = ax;
      }

      private final boolean tryAcquireCpuPermit() {
         boolean var10000;
         if (a.state == CoroutineScheduler.WorkerState.CPU_ACQUIRED) {
            var10000 = true;
         } else {
            CoroutineScheduler axx = CoroutineScheduler.this;
            int axxxx = false;
            CoroutineScheduler axxxxx = axx;
            boolean var4 = false;

            while(true) {
               long axxxxxxxx = axxxxx.controlState;
               int axxx = false;
               int axxxxxx = false;
               int axxxxxxx = (int)((axxxxxxxx & 9223367638808264704L) >> 42);
               if (axxxxxxx == 0) {
                  var10000 = false;
                  break;
               }

               long ax = axxxxxxxx - 4398046511104L;
               if (CoroutineScheduler.controlState$FU.compareAndSet(axx, axxxxxxxx, ax)) {
                  var10000 = true;
                  break;
               }
            }

            if (var10000) {
               a.state = CoroutineScheduler.WorkerState.CPU_ACQUIRED;
               var10000 = true;
            } else {
               var10000 = false;
            }
         }

         return var10000;
      }

      public final boolean tryReleaseCpu(@NotNull CoroutineScheduler.WorkerState ax) {
         CoroutineScheduler.WorkerState axx = a.state;
         boolean axxx = axx == CoroutineScheduler.WorkerState.CPU_ACQUIRED;
         if (axxx) {
            CoroutineScheduler axxxx = CoroutineScheduler.this;
            int axxxxx = false;
            CoroutineScheduler.controlState$FU.addAndGet(axxxx, 4398046511104L);
         }

         if (axx != ax) {
            a.state = ax;
         }

         return axxx;
      }

      public void run() {
         a.runWorker();
      }

      private final void runWorker() {
         boolean ax = false;

         while(!CoroutineScheduler.this.isTerminated() && a.state != CoroutineScheduler.WorkerState.TERMINATED) {
            Task axx = a.findTask(a.mayHaveLocalTasks);
            if (axx != null) {
               ax = false;
               a.minDelayUntilStealableTaskNs = 0L;
               a.executeTask(axx);
            } else {
               a.mayHaveLocalTasks = false;
               if (a.minDelayUntilStealableTaskNs != 0L) {
                  if (!ax) {
                     ax = true;
                  } else {
                     ax = false;
                     a.tryReleaseCpu(CoroutineScheduler.WorkerState.PARKING);
                     Thread.interrupted();
                     LockSupport.parkNanos(a.minDelayUntilStealableTaskNs);
                     a.minDelayUntilStealableTaskNs = 0L;
                  }
               } else {
                  a.tryPark();
               }
            }
         }

         a.tryReleaseCpu(CoroutineScheduler.WorkerState.TERMINATED);
      }

      private final void tryPark() {
         if (!a.inStack()) {
            CoroutineScheduler.this.parkedWorkersStackPush(a);
         } else {
            if (DebugKt.getASSERTIONS_ENABLED()) {
               int ax = false;
               if (a.localQueue.getSize$kotlinx_coroutines_core() != 0) {
                  throw new AssertionError();
               }
            }

            a.workerCtl = -1;

            while(a.inStack() && a.workerCtl == -1 && !CoroutineScheduler.this.isTerminated() && a.state != CoroutineScheduler.WorkerState.TERMINATED) {
               a.tryReleaseCpu(CoroutineScheduler.WorkerState.PARKING);
               Thread.interrupted();
               a.park();
            }

         }
      }

      private final boolean inStack() {
         return a.nextParkedWorker != CoroutineScheduler.NOT_IN_STACK;
      }

      private final void executeTask(Task ax) {
         int axx = false;
         int axxx = ax.taskContext.getTaskMode();
         a.idleReset(axxx);
         a.beforeTask(axxx);
         CoroutineScheduler.this.runSafely(ax);
         a.afterTask(axxx);
      }

      private final void beforeTask(int ax) {
         if (ax != 0) {
            if (a.tryReleaseCpu(CoroutineScheduler.WorkerState.BLOCKING)) {
               CoroutineScheduler.this.signalCpuWork();
            }

         }
      }

      private final void afterTask(int axx) {
         if (axx != 0) {
            CoroutineScheduler axxxx = CoroutineScheduler.this;
            int ax = false;
            CoroutineScheduler.controlState$FU.addAndGet(axxxx, -2097152L);
            CoroutineScheduler.WorkerState axxx = a.state;
            if (axxx != CoroutineScheduler.WorkerState.TERMINATED) {
               if (DebugKt.getASSERTIONS_ENABLED()) {
                  ax = false;
                  if (axxx != CoroutineScheduler.WorkerState.BLOCKING) {
                     throw new AssertionError();
                  }
               }

               a.state = CoroutineScheduler.WorkerState.DORMANT;
            }

         }
      }

      public final int nextInt(int axx) {
         int axxx = a.rngState;
         axxx ^= axxx << 13;
         axxx ^= axxx >> 17;
         axxx ^= axxx << 5;
         a.rngState = axxx;
         int ax = axx - 1;
         return (ax & axx) == 0 ? axxx & ax : (axxx & Integer.MAX_VALUE) % axx;
      }

      private final void park() {
         if (a.terminationDeadline == 0L) {
            a.terminationDeadline = System.nanoTime() + CoroutineScheduler.this.idleWorkerKeepAliveNs;
         }

         LockSupport.parkNanos(CoroutineScheduler.this.idleWorkerKeepAliveNs);
         if (System.nanoTime() - a.terminationDeadline >= 0L) {
            a.terminationDeadline = 0L;
            a.tryTerminateWorker();
         }

      }

      private final void tryTerminateWorker() {
         ResizableAtomicArray axx = CoroutineScheduler.this.workers;
         CoroutineScheduler var2 = CoroutineScheduler.this;
         int axxxx = false;
         synchronized(axx){}

         label86: {
            try {
               int axxxxx = false;
               if (var2.isTerminated()) {
                  return;
               }

               int axxxxxxxx = false;
               if ((int)(var2.controlState & 2097151L) > var2.corePoolSize) {
                  if (!workerCtl$FU.compareAndSet(a, -1, 1)) {
                     return;
                  }

                  int axxxxxx = a.indexInArray;
                  a.setIndexInArray(0);
                  var2.parkedWorkersStackTopUpdate(a, axxxxxx, 0);
                  int axxxxxxxxxx = false;
                  long ax = CoroutineScheduler.controlState$FU.getAndDecrement(var2);
                  int axxx = false;
                  int axxxxxxx = (int)(ax & 2097151L);
                  if (axxxxxxx != axxxxxx) {
                     Object var10000 = var2.workers.get(axxxxxxx);
                     Intrinsics.checkNotNull(var10000);
                     CoroutineScheduler.Worker axxxxxxxxx = (CoroutineScheduler.Worker)var10000;
                     var2.workers.setSynchronized(axxxxxx, axxxxxxxxx);
                     axxxxxxxxx.setIndexInArray(axxxxxx);
                     var2.parkedWorkersStackTopUpdate(axxxxxxxxx, axxxxxxx, axxxxxx);
                  }

                  var2.workers.setSynchronized(axxxxxxx, (Object)null);
                  Unit var14 = Unit.INSTANCE;
                  break label86;
               }
            } finally {
               ;
            }

            return;
         }

         a.state = CoroutineScheduler.WorkerState.TERMINATED;
      }

      private final void idleReset(int ax) {
         a.terminationDeadline = 0L;
         if (a.state == CoroutineScheduler.WorkerState.PARKING) {
            if (DebugKt.getASSERTIONS_ENABLED()) {
               int axx = false;
               if (ax != 1) {
                  throw new AssertionError();
               }
            }

            a.state = CoroutineScheduler.WorkerState.BLOCKING;
         }

      }

      @Nullable
      public final Task findTask(boolean ax) {
         if (a.tryAcquireCpuPermit()) {
            return a.findAnyTask(ax);
         } else {
            Task var10000;
            if (ax) {
               var10000 = a.localQueue.poll();
               if (var10000 == null) {
                  var10000 = (Task)CoroutineScheduler.this.globalBlockingQueue.removeFirstOrNull();
               }
            } else {
               var10000 = (Task)CoroutineScheduler.this.globalBlockingQueue.removeFirstOrNull();
            }

            Task axx = var10000;
            var10000 = axx;
            if (axx == null) {
               var10000 = a.trySteal(true);
            }

            return var10000;
         }
      }

      private final Task findAnyTask(boolean axx) {
         if (axx) {
            boolean axxx = a.nextInt(2 * CoroutineScheduler.this.corePoolSize) == 0;
            Task var3;
            boolean ax;
            if (axxx) {
               var3 = a.pollGlobalQueues();
               if (var3 != null) {
                  ax = false;
                  return var3;
               }
            }

            var3 = a.localQueue.poll();
            if (var3 != null) {
               ax = false;
               return var3;
            }

            if (!axxx) {
               var3 = a.pollGlobalQueues();
               if (var3 != null) {
                  ax = false;
                  return var3;
               }
            }
         } else {
            Task var7 = a.pollGlobalQueues();
            if (var7 != null) {
               int axxxx = false;
               return var7;
            }
         }

         return a.trySteal(false);
      }

      private final Task pollGlobalQueues() {
         Task var1;
         boolean ax;
         if (a.nextInt(2) == 0) {
            var1 = (Task)CoroutineScheduler.this.globalCpuQueue.removeFirstOrNull();
            if (var1 != null) {
               ax = false;
               return var1;
            } else {
               return (Task)CoroutineScheduler.this.globalBlockingQueue.removeFirstOrNull();
            }
         } else {
            var1 = (Task)CoroutineScheduler.this.globalBlockingQueue.removeFirstOrNull();
            if (var1 != null) {
               ax = false;
               return var1;
            } else {
               return (Task)CoroutineScheduler.this.globalCpuQueue.removeFirstOrNull();
            }
         }
      }

      private final Task trySteal(boolean axx) {
         if (DebugKt.getASSERTIONS_ENABLED()) {
            int axxx = false;
            if (a.localQueue.getSize$kotlinx_coroutines_core() != 0) {
               throw new AssertionError();
            }
         }

         CoroutineScheduler axxxxx = CoroutineScheduler.this;
         int axxxxxx = false;
         int axxxxxxx = (int)(axxxxx.controlState & 2097151L);
         if (axxxxxxx < 2) {
            return null;
         } else {
            int axxxxxxxx = false;
            int axxxxxxxxx = a.nextInt(axxxxxxx);
            long axxxx = 0L;
            axxxx = Long.MAX_VALUE;
            CoroutineScheduler var5 = CoroutineScheduler.this;

            for(int var6 = 0; var6 < axxxxxxx; ++var6) {
               int axxxxxxxxxx = false;
               ++axxxxxxxxx;
               if (axxxxxxxxx > axxxxxxx) {
                  axxxxxxxxx = 1;
               }

               CoroutineScheduler.Worker axxxxxxxxxxx = (CoroutineScheduler.Worker)var5.workers.get(axxxxxxxxx);
               if (axxxxxxxxxxx != null && axxxxxxxxxxx != a) {
                  if (DebugKt.getASSERTIONS_ENABLED()) {
                     int axxxxxxxxxxxx = false;
                     if (a.localQueue.getSize$kotlinx_coroutines_core() != 0) {
                        throw new AssertionError();
                     }
                  }

                  long ax = axx ? a.localQueue.tryStealBlockingFrom(axxxxxxxxxxx.localQueue) : a.localQueue.tryStealFrom(axxxxxxxxxxx.localQueue);
                  if (ax == -1L) {
                     return a.localQueue.poll();
                  }

                  if (ax > 0L) {
                     axxxx = Math.min(axxxx, ax);
                  }
               }
            }

            a.minDelayUntilStealableTaskNs = axxxx != Long.MAX_VALUE ? axxxx : 0L;
            return null;
         }
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0007\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007¨\u0006\b"},
      d2 = {"Lkotlinx/coroutines/scheduling/CoroutineScheduler$WorkerState;", "", "(Ljava/lang/String;I)V", "CPU_ACQUIRED", "BLOCKING", "PARKING", "DORMANT", "TERMINATED", "kotlinx-coroutines-core"}
   )
   public static enum WorkerState {
      CPU_ACQUIRED,
      BLOCKING,
      PARKING,
      DORMANT,
      TERMINATED;

      // $FF: synthetic method
      private static final CoroutineScheduler.WorkerState[] $values() {
         CoroutineScheduler.WorkerState[] var0 = new CoroutineScheduler.WorkerState[]{CPU_ACQUIRED, BLOCKING, PARKING, DORMANT, TERMINATED};
         return var0;
      }
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 6, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[CoroutineScheduler.WorkerState.values().length];
         var0[CoroutineScheduler.WorkerState.PARKING.ordinal()] = 1;
         var0[CoroutineScheduler.WorkerState.BLOCKING.ordinal()] = 2;
         var0[CoroutineScheduler.WorkerState.CPU_ACQUIRED.ordinal()] = 3;
         var0[CoroutineScheduler.WorkerState.DORMANT.ordinal()] = 4;
         var0[CoroutineScheduler.WorkerState.TERMINATED.ordinal()] = 5;
         $EnumSwitchMapping$0 = var0;
      }
   }
}
