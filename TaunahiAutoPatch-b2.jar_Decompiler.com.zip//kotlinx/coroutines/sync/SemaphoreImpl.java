package kotlinx.coroutines.sync;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function1;
import kotlinx.coroutines.CancelHandlerBase;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CancellableContinuationImpl;
import kotlinx.coroutines.CancellableContinuationKt;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.internal.ConcurrentLinkedListKt;
import kotlinx.coroutines.internal.ConcurrentLinkedListNode;
import kotlinx.coroutines.internal.Segment;
import kotlinx.coroutines.internal.SegmentOrClosed;
import kotlinx.coroutines.internal.Symbol;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\b\u0004\n\u0002\u0018\u0002\b\u0002\u0018\u00002\u00020\u001eB\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0001\u0012\u0006\u0010\u0003\u001a\u00020\u0001¢\u0006\u0004\b\u0004\u0010\u0005J\u0013\u0010\u0007\u001a\u00020\u0006H\u0096@ø\u0001\u0000¢\u0006\u0004\b\u0007\u0010\bJ\u0013\u0010\t\u001a\u00020\u0006H\u0082@ø\u0001\u0000¢\u0006\u0004\b\t\u0010\bJ\u001d\u0010\r\u001a\u00020\f2\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00060\nH\u0002¢\u0006\u0004\b\r\u0010\u000eJ\u000f\u0010\u000f\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u000f\u0010\u0010J\u000f\u0010\u0011\u001a\u00020\fH\u0016¢\u0006\u0004\b\u0011\u0010\u0012J\u000f\u0010\u0013\u001a\u00020\fH\u0002¢\u0006\u0004\b\u0013\u0010\u0012J\u0019\u0010\u0014\u001a\u00020\f*\b\u0012\u0004\u0012\u00020\u00060\nH\u0002¢\u0006\u0004\b\u0014\u0010\u000eR\u0014\u0010\u0017\u001a\u00020\u00018VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0015\u0010\u0016R \u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\u0019\u0012\u0004\u0012\u00020\u00060\u00188\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001a\u0010\u001bR\u0014\u0010\u0002\u001a\u00020\u00018\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0002\u0010\u001c\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001d"},
   d2 = {"Lkotlinx/coroutines/sync/SemaphoreImpl;", "", "permits", "acquiredPermits", "SemaphoreImpl", "(II)V", "", "acquire", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "acquireSlowPath", "Lkotlinx/coroutines/CancellableContinuation;", "cont", "", "addAcquireToQueue", "(Lkotlinx/coroutines/CancellableContinuation;)Z", "release", "()V", "tryAcquire", "()Z", "tryResumeNextFromQueue", "tryResumeAcquire", "getAvailablePermits", "()I", "availablePermits", "Lkotlin/Function1;", "", "onCancellationRelease", "Lkotlin/jvm/functions/Function1;", "I", "kotlinx-coroutines-core", "Lkotlinx/coroutines/sync/Semaphore;"}
)
final class SemaphoreImpl implements Semaphore {
   private final int permits;
   // $FF: synthetic field
   @NotNull
   private volatile Object head;
   // $FF: synthetic field
   private static final AtomicReferenceFieldUpdater head$FU = AtomicReferenceFieldUpdater.newUpdater(SemaphoreImpl.class, Object.class, "head");
   // $FF: synthetic field
   @NotNull
   private volatile long deqIdx;
   // $FF: synthetic field
   private static final AtomicLongFieldUpdater deqIdx$FU = AtomicLongFieldUpdater.newUpdater(SemaphoreImpl.class, "deqIdx");
   // $FF: synthetic field
   @NotNull
   private volatile Object tail;
   // $FF: synthetic field
   private static final AtomicReferenceFieldUpdater tail$FU = AtomicReferenceFieldUpdater.newUpdater(SemaphoreImpl.class, Object.class, "tail");
   // $FF: synthetic field
   @NotNull
   private volatile long enqIdx;
   // $FF: synthetic field
   private static final AtomicLongFieldUpdater enqIdx$FU = AtomicLongFieldUpdater.newUpdater(SemaphoreImpl.class, "enqIdx");
   // $FF: synthetic field
   @NotNull
   volatile int _availablePermits;
   // $FF: synthetic field
   static final AtomicIntegerFieldUpdater _availablePermits$FU = AtomicIntegerFieldUpdater.newUpdater(SemaphoreImpl.class, "_availablePermits");
   @NotNull
   private final Function1<Throwable, Unit> onCancellationRelease;

   public SemaphoreImpl(int a, int a) {
      a.permits = a;
      a.deqIdx = 0L;
      a.enqIdx = 0L;
      boolean a;
      String var5;
      if (a.permits <= 0) {
         a = false;
         var5 = "Semaphore should have at least 1 permit, but had " + a.permits;
         throw new IllegalArgumentException(var5.toString());
      } else if (!(0 <= a ? a <= a.permits : false)) {
         a = false;
         var5 = "The number of acquired permits should be in 0.." + a.permits;
         throw new IllegalArgumentException(var5.toString());
      } else {
         SemaphoreSegment a = new SemaphoreSegment(0L, (SemaphoreSegment)null, 2);
         a.head = a;
         a.tail = a;
         a._availablePermits = a.permits - a;
         a.onCancellationRelease = (Function1)(new Function1<Throwable, Unit>() {
            public final void invoke(@NotNull Throwable var1) {
               a.release();
            }
         });
      }
   }

   public int getAvailablePermits() {
      return Math.max(a._availablePermits, 0);
   }

   public boolean tryAcquire() {
      SemaphoreImpl a = a;
      boolean var2 = false;

      int a;
      do {
         a = a._availablePermits;
         int a = false;
         if (a <= 0) {
            return false;
         }
      } while(!_availablePermits$FU.compareAndSet(a, a, a - 1));

      return true;
   }

   @Nullable
   public Object acquire(@NotNull Continuation<? super Unit> a) {
      int a = _availablePermits$FU.getAndDecrement(a);
      if (a > 0) {
         return Unit.INSTANCE;
      } else {
         Object var10000 = a.acquireSlowPath(a);
         return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
      }
   }

   private final Object acquireSlowPath(Continuation<? super Unit> a) {
      int a = false;
      int a = false;
      CancellableContinuationImpl a = CancellableContinuationKt.getOrCreateCancellableContinuation(IntrinsicsKt.intercepted(a));
      CancellableContinuation a = (CancellableContinuation)a;
      boolean var7 = false;

      while(!access$addAcquireToQueue(a, a)) {
         int a = _availablePermits$FU.getAndDecrement(a);
         if (a > 0) {
            a.resume(Unit.INSTANCE, access$getOnCancellationRelease$p(a));
            break;
         }
      }

      Object var10000 = a.getResult();
      if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         DebugProbesKt.probeCoroutineSuspended(a);
      }

      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   public void release() {
      do {
         SemaphoreImpl a = a;
         boolean var3 = false;

         int a;
         int a;
         do {
            a = a._availablePermits;
            int a = false;
            if (a >= a.permits) {
               int a = false;
               String var8 = "The number of released permits cannot be greater than " + a.permits;
               throw new IllegalStateException(var8.toString());
            }

            a = a + 1;
         } while(!_availablePermits$FU.compareAndSet(a, a, a));

         if (a >= 0) {
            return;
         }
      } while(!a.tryResumeNextFromQueue());

   }

   private final boolean addAcquireToQueue(CancellableContinuation<? super Unit> a) {
      SemaphoreSegment a = (SemaphoreSegment)a.tail;
      long a = enqIdx$FU.getAndIncrement(a);
      SemaphoreImpl a = a;
      long a = a / (long)SemaphoreKt.access$getSEGMENT_SIZE$p();
      boolean a = false;

      Object a;
      boolean var37;
      do {
         Segment a = (Segment)a;
         int a = false;
         Segment a = a;

         boolean a;
         boolean a;
         Object var36;
         while(true) {
            if (a.getId() >= a && !a.getRemoved()) {
               var36 = SegmentOrClosed.constructor-impl(a);
               break;
            }

            ConcurrentLinkedListNode a = (ConcurrentLinkedListNode)a;
            a = false;
            Object a = ConcurrentLinkedListNode.access$getNextOrClosed(a);
            a = false;
            if (a == ConcurrentLinkedListKt.access$getCLOSED$p()) {
               int a = false;
               var36 = SegmentOrClosed.constructor-impl(ConcurrentLinkedListKt.access$getCLOSED$p());
               break;
            }

            Segment a = (Segment)((ConcurrentLinkedListNode)a);
            if (a != null) {
               a = a;
            } else {
               long var10000 = a.getId() + 1L;
               SemaphoreSegment a = (SemaphoreSegment)a;
               long a = var10000;
               int a = false;
               Segment a = (Segment)SemaphoreKt.access$createSegment(a, a);
               if (a.trySetNext((ConcurrentLinkedListNode)a)) {
                  if (a.getRemoved()) {
                     a.remove();
                  }

                  a = a;
               }
            }
         }

         a = var36;
         if (SegmentOrClosed.isClosed-impl(a)) {
            break;
         }

         SemaphoreImpl a = a;
         Segment a = SegmentOrClosed.getSegment-impl(a);
         int a = false;
         SemaphoreImpl a = a;
         a = false;

         while(true) {
            Segment a = (Segment)a.tail;
            a = false;
            if (a.getId() >= a.getId()) {
               var37 = true;
               break;
            }

            if (!a.tryIncPointers$kotlinx_coroutines_core()) {
               var37 = false;
               break;
            }

            if (tail$FU.compareAndSet(a, a, a)) {
               if (a.decPointers$kotlinx_coroutines_core()) {
                  a.remove();
               }

               var37 = true;
               break;
            }

            if (a.decPointers$kotlinx_coroutines_core()) {
               a.remove();
            }
         }
      } while(!var37);

      SemaphoreSegment a = (SemaphoreSegment)SegmentOrClosed.getSegment-impl(a);
      int a = (int)(a % (long)SemaphoreKt.access$getSEGMENT_SIZE$p());
      Symbol a = null;
      a = false;
      if (a.acquirers.compareAndSet(a, a, a)) {
         CancelHandlerBase a = (CancelHandlerBase)(new CancelSemaphoreAcquisitionHandler(a, a));
         int a = false;
         a.invokeOnCancellation((Function1)a);
         return true;
      } else {
         a = SemaphoreKt.access$getPERMIT$p();
         Object a = SemaphoreKt.access$getTAKEN$p();
         int a = false;
         if (a.acquirers.compareAndSet(a, a, a)) {
            a.resume(Unit.INSTANCE, a.onCancellationRelease);
            return true;
         } else {
            if (DebugKt.getASSERTIONS_ENABLED()) {
               int a = false;
               a = false;
               if (a.acquirers.get(a) != SemaphoreKt.access$getBROKEN$p()) {
                  throw new AssertionError();
               }
            }

            return false;
         }
      }
   }

   private final boolean tryResumeNextFromQueue() {
      SemaphoreSegment a = (SemaphoreSegment)a.head;
      long a = deqIdx$FU.getAndIncrement(a);
      long a = a / (long)SemaphoreKt.access$getSEGMENT_SIZE$p();
      SemaphoreImpl a = a;
      boolean var8 = false;

      Object a;
      boolean a;
      boolean var38;
      do {
         Segment a = (Segment)a;
         int a = false;
         Segment a = a;

         boolean a;
         boolean a;
         Object var37;
         while(true) {
            if (a.getId() >= a && !a.getRemoved()) {
               var37 = SegmentOrClosed.constructor-impl(a);
               break;
            }

            ConcurrentLinkedListNode a = (ConcurrentLinkedListNode)a;
            a = false;
            Object a = ConcurrentLinkedListNode.access$getNextOrClosed(a);
            a = false;
            if (a == ConcurrentLinkedListKt.access$getCLOSED$p()) {
               int a = false;
               var37 = SegmentOrClosed.constructor-impl(ConcurrentLinkedListKt.access$getCLOSED$p());
               break;
            }

            Segment a = (Segment)((ConcurrentLinkedListNode)a);
            if (a != null) {
               a = a;
            } else {
               long var10000 = a.getId() + 1L;
               SemaphoreSegment a = (SemaphoreSegment)a;
               long a = var10000;
               int a = false;
               Segment a = (Segment)SemaphoreKt.access$createSegment(a, a);
               if (a.trySetNext((ConcurrentLinkedListNode)a)) {
                  if (a.getRemoved()) {
                     a.remove();
                  }

                  a = a;
               }
            }
         }

         a = var37;
         if (SegmentOrClosed.isClosed-impl(a)) {
            break;
         }

         SemaphoreImpl a = a;
         Segment a = SegmentOrClosed.getSegment-impl(a);
         a = false;
         SemaphoreImpl a = a;
         a = false;

         while(true) {
            Segment a = (Segment)a.head;
            a = false;
            if (a.getId() >= a.getId()) {
               var38 = true;
               break;
            }

            if (!a.tryIncPointers$kotlinx_coroutines_core()) {
               var38 = false;
               break;
            }

            if (head$FU.compareAndSet(a, a, a)) {
               if (a.decPointers$kotlinx_coroutines_core()) {
                  a.remove();
               }

               var38 = true;
               break;
            }

            if (a.decPointers$kotlinx_coroutines_core()) {
               a.remove();
            }
         }
      } while(!var38);

      SemaphoreSegment a = (SemaphoreSegment)SegmentOrClosed.getSegment-impl(a);
      a.cleanPrev();
      if (a.getId() > a) {
         return false;
      } else {
         int a = (int)(a % (long)SemaphoreKt.access$getSEGMENT_SIZE$p());
         Object a = SemaphoreKt.access$getPERMIT$p();
         a = false;
         Object a = a.acquirers.getAndSet(a, a);
         if (a == null) {
            int var26 = SemaphoreKt.access$getMAX_SPIN_CYCLES$p();

            boolean a;
            for(int var29 = 0; var29 < var26; ++var29) {
               a = false;
               int a = false;
               if (a.acquirers.get(a) == SemaphoreKt.access$getTAKEN$p()) {
                  return true;
               }
            }

            a = SemaphoreKt.access$getPERMIT$p();
            Object a = SemaphoreKt.access$getBROKEN$p();
            a = false;
            return !a.acquirers.compareAndSet(a, a, a);
         } else {
            return a == SemaphoreKt.access$getCANCELLED$p() ? false : a.tryResumeAcquire((CancellableContinuation)a);
         }
      }
   }

   private final boolean tryResumeAcquire(CancellableContinuation<? super Unit> a) {
      Object var10000 = a.tryResume(Unit.INSTANCE, (Object)null, a.onCancellationRelease);
      if (var10000 == null) {
         return false;
      } else {
         Object a = var10000;
         a.completeResume(a);
         return true;
      }
   }

   // $FF: synthetic method
   public static final Object access$acquireSlowPath(SemaphoreImpl a, Continuation a) {
      return a.acquireSlowPath(a);
   }

   // $FF: synthetic method
   public static final boolean access$addAcquireToQueue(SemaphoreImpl a, CancellableContinuation a) {
      return a.addAcquireToQueue(a);
   }

   // $FF: synthetic method
   public static final Function1 access$getOnCancellationRelease$p(SemaphoreImpl a) {
      return a.onCancellationRelease;
   }
}
