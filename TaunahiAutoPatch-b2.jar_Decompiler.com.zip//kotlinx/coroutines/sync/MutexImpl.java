package kotlinx.coroutines.sync;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CancellableContinuationImpl;
import kotlinx.coroutines.CancellableContinuationImplKt;
import kotlinx.coroutines.CancellableContinuationKt;
import kotlinx.coroutines.DisposableHandle;
import kotlinx.coroutines.internal.AtomicDesc;
import kotlinx.coroutines.internal.AtomicKt;
import kotlinx.coroutines.internal.AtomicOp;
import kotlinx.coroutines.internal.LockFreeLinkedListHead;
import kotlinx.coroutines.internal.LockFreeLinkedListNode;
import kotlinx.coroutines.internal.OpDescriptor;
import kotlinx.coroutines.intrinsics.CancellableKt;
import kotlinx.coroutines.intrinsics.UndispatchedKt;
import kotlinx.coroutines.selects.SelectClause2;
import kotlinx.coroutines.selects.SelectInstance;
import kotlinx.coroutines.selects.SelectKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\n\b\u0000\u0018\u00002\u00020\u00112\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0004\u0012\u00020\u00110 :\u0006$%&'()B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0004\b\u0003\u0010\u0004J\u0017\u0010\u0007\u001a\u00020\u00012\u0006\u0010\u0006\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u0007\u0010\bJ\u001d\u0010\n\u001a\u00020\t2\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005H\u0096@ø\u0001\u0000¢\u0006\u0004\b\n\u0010\u000bJ\u001d\u0010\f\u001a\u00020\t2\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005H\u0082@ø\u0001\u0000¢\u0006\u0004\b\f\u0010\u000bJT\u0010\u0014\u001a\u00020\t\"\u0004\b\u0000\u0010\r2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00028\u00000\u000e2\b\u0010\u0006\u001a\u0004\u0018\u00010\u00052\"\u0010\u0013\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\u0011\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u0010H\u0016ø\u0001\u0000¢\u0006\u0004\b\u0014\u0010\u0015J\u000f\u0010\u0017\u001a\u00020\u0016H\u0016¢\u0006\u0004\b\u0017\u0010\u0018J\u0019\u0010\u0019\u001a\u00020\u00012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005H\u0016¢\u0006\u0004\b\u0019\u0010\bJ\u0019\u0010\u001a\u001a\u00020\t2\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005H\u0016¢\u0006\u0004\b\u001a\u0010\u001bR\u0014\u0010\u001c\u001a\u00020\u00018VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001c\u0010\u001dR\u0014\u0010\u001f\u001a\u00020\u00018@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u001e\u0010\u001dR\"\u0010#\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0004\u0012\u00020\u00110 8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b!\u0010\"\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006*"},
   d2 = {"Lkotlinx/coroutines/sync/MutexImpl;", "", "locked", "MutexImpl", "(Z)V", "", "owner", "holdsLock", "(Ljava/lang/Object;)Z", "", "lock", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "lockSuspend", "R", "Lkotlinx/coroutines/selects/SelectInstance;", "select", "Lkotlin/Function2;", "Lkotlinx/coroutines/sync/Mutex;", "Lkotlin/coroutines/Continuation;", "block", "registerSelectClause2", "(Lkotlinx/coroutines/selects/SelectInstance;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V", "", "toString", "()Ljava/lang/String;", "tryLock", "unlock", "(Ljava/lang/Object;)V", "isLocked", "()Z", "isLockedEmptyQueueState$kotlinx_coroutines_core", "isLockedEmptyQueueState", "Lkotlinx/coroutines/selects/SelectClause2;", "getOnLock", "()Lkotlinx/coroutines/selects/SelectClause2;", "onLock", "LockCont", "LockSelect", "LockWaiter", "LockedQueue", "TryLockDesc", "UnlockOp", "kotlinx-coroutines-core"}
)
public final class MutexImpl implements Mutex, SelectClause2<Object, Mutex> {
   // $FF: synthetic field
   @NotNull
   volatile Object _state;
   // $FF: synthetic field
   static final AtomicReferenceFieldUpdater _state$FU = AtomicReferenceFieldUpdater.newUpdater(MutexImpl.class, Object.class, "_state");

   public MutexImpl(boolean a) {
      a._state = a ? MutexKt.access$getEMPTY_LOCKED$p() : MutexKt.access$getEMPTY_UNLOCKED$p();
   }

   public boolean isLocked() {
      MutexImpl a = a;
      boolean var2 = false;

      while(true) {
         Object a = a._state;
         int a = false;
         if (a instanceof Empty) {
            return ((Empty)a).locked != MutexKt.access$getUNLOCKED$p();
         }

         if (a instanceof MutexImpl.LockedQueue) {
            return true;
         }

         if (!(a instanceof OpDescriptor)) {
            throw new IllegalStateException(("Illegal state " + a).toString());
         }

         ((OpDescriptor)a).perform(a);
      }
   }

   public final boolean isLockedEmptyQueueState$kotlinx_coroutines_core() {
      Object a = a._state;
      return a instanceof MutexImpl.LockedQueue && ((MutexImpl.LockedQueue)a).isEmpty();
   }

   public boolean tryLock(@Nullable Object a) {
      MutexImpl a = a;
      boolean var3 = false;

      while(true) {
         Object a = a._state;
         int a = false;
         if (a instanceof Empty) {
            if (((Empty)a).locked != MutexKt.access$getUNLOCKED$p()) {
               return false;
            }

            Empty a = a == null ? MutexKt.access$getEMPTY_LOCKED$p() : new Empty(a);
            if (_state$FU.compareAndSet(a, a, a)) {
               return true;
            }
         } else {
            if (a instanceof MutexImpl.LockedQueue) {
               if (((MutexImpl.LockedQueue)a).owner == a) {
                  int a = false;
                  String var9 = "Already locked by " + a;
                  throw new IllegalStateException(var9.toString());
               }

               return false;
            }

            if (!(a instanceof OpDescriptor)) {
               throw new IllegalStateException(("Illegal state " + a).toString());
            }

            ((OpDescriptor)a).perform(a);
         }
      }
   }

   @Nullable
   public Object lock(@Nullable Object a, @NotNull Continuation<? super Unit> a) {
      if (a.tryLock(a)) {
         return Unit.INSTANCE;
      } else {
         Object var10000 = a.lockSuspend(a, a);
         return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
      }
   }

   private final Object lockSuspend(final Object a, Continuation<? super Unit> a) {
      int a = false;
      int a = false;
      CancellableContinuationImpl a = CancellableContinuationKt.getOrCreateCancellableContinuation(IntrinsicsKt.intercepted(a));
      CancellableContinuation a = (CancellableContinuation)a;
      int a = false;
      Object a = null;
      a = new MutexImpl.LockCont(a, a);
      MutexImpl a = a;
      boolean var11 = false;

      while(true) {
         Object a = a._state;
         int a = false;
         if (a instanceof Empty) {
            if (((Empty)a).locked != MutexKt.access$getUNLOCKED$p()) {
               _state$FU.compareAndSet(a, a, new MutexImpl.LockedQueue(((Empty)a).locked));
            } else {
               Empty a = a == null ? MutexKt.access$getEMPTY_LOCKED$p() : new Empty(a);
               if (_state$FU.compareAndSet(a, a, a)) {
                  a.resume(Unit.INSTANCE, (Function1)(new Function1<Throwable, Unit>() {
                     public final void invoke(@NotNull Throwable a1) {
                        a.unlock(a);
                     }
                  }));
                  break;
               }
            }
         } else if (a instanceof MutexImpl.LockedQueue) {
            Object a = ((MutexImpl.LockedQueue)a).owner;
            if (a == a) {
               int a = false;
               String var18 = "Already locked by " + a;
               throw new IllegalStateException(var18.toString());
            }

            ((MutexImpl.LockedQueue)a).addLast((LockFreeLinkedListNode)a);
            if (a._state == a || !a.take()) {
               CancellableContinuationKt.removeOnCancellation(a, (LockFreeLinkedListNode)a);
               break;
            }

            a = new MutexImpl.LockCont(a, a);
         } else {
            if (!(a instanceof OpDescriptor)) {
               throw new IllegalStateException(("Illegal state " + a).toString());
            }

            ((OpDescriptor)a).perform(a);
         }
      }

      Object var10000 = a.getResult();
      if (var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         DebugProbesKt.probeCoroutineSuspended(a);
      }

      return var10000 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? var10000 : Unit.INSTANCE;
   }

   @NotNull
   public SelectClause2<Object, Mutex> getOnLock() {
      return (SelectClause2)a;
   }

   public <R> void registerSelectClause2(@NotNull SelectInstance<? super R> a, @Nullable Object a, @NotNull Function2<? super Mutex, ? super Continuation<? super R>, ? extends Object> a) {
      while(!a.isSelected()) {
         Object a = a._state;
         if (a instanceof Empty) {
            if (((Empty)a).locked != MutexKt.access$getUNLOCKED$p()) {
               _state$FU.compareAndSet(a, a, new MutexImpl.LockedQueue(((Empty)a).locked));
            } else {
               Object a = a.performAtomicTrySelect((AtomicDesc)(new MutexImpl.TryLockDesc(a, a)));
               if (a == null) {
                  UndispatchedKt.startCoroutineUnintercepted(a, a, a.getCompletion());
                  return;
               }

               if (a == SelectKt.getALREADY_SELECTED()) {
                  return;
               }

               if (a != MutexKt.access$getLOCK_FAIL$p() && a != AtomicKt.RETRY_ATOMIC) {
                  throw new IllegalStateException(("performAtomicTrySelect(TryLockDesc) returned " + a).toString());
               }
            }
         } else if (a instanceof MutexImpl.LockedQueue) {
            if (((MutexImpl.LockedQueue)a).owner == a) {
               int a = false;
               String var8 = "Already locked by " + a;
               throw new IllegalStateException(var8.toString());
            }

            MutexImpl.LockSelect a = new MutexImpl.LockSelect(a, a, a);
            ((MutexImpl.LockedQueue)a).addLast((LockFreeLinkedListNode)a);
            if (a._state == a || !a.take()) {
               a.disposeOnSelect((DisposableHandle)a);
               return;
            }
         } else {
            if (!(a instanceof OpDescriptor)) {
               throw new IllegalStateException(("Illegal state " + a).toString());
            }

            ((OpDescriptor)a).perform(a);
         }
      }

   }

   public boolean holdsLock(@NotNull Object a) {
      Object a = a._state;
      int a = false;
      return a instanceof Empty ? ((Empty)a).locked == a : (a instanceof MutexImpl.LockedQueue ? ((MutexImpl.LockedQueue)a).owner == a : false);
   }

   public void unlock(@Nullable Object a) {
      MutexImpl a = a;
      boolean var3 = false;

      while(true) {
         Object a = a._state;
         int a = false;
         boolean a;
         String var9;
         if (a instanceof Empty) {
            if (a == null) {
               if (((Empty)a).locked == MutexKt.access$getUNLOCKED$p()) {
                  a = false;
                  var9 = "Mutex is not locked";
                  throw new IllegalStateException(var9.toString());
               }
            } else if (((Empty)a).locked != a) {
               a = false;
               var9 = "Mutex is locked by " + ((Empty)a).locked + " but expected " + a;
               throw new IllegalStateException(var9.toString());
            }

            if (_state$FU.compareAndSet(a, a, MutexKt.access$getEMPTY_UNLOCKED$p())) {
               return;
            }
         } else if (a instanceof OpDescriptor) {
            ((OpDescriptor)a).perform(a);
         } else {
            if (!(a instanceof MutexImpl.LockedQueue)) {
               throw new IllegalStateException(("Illegal state " + a).toString());
            }

            if (a != null && ((MutexImpl.LockedQueue)a).owner != a) {
               a = false;
               var9 = "Mutex is locked by " + ((MutexImpl.LockedQueue)a).owner + " but expected " + a;
               throw new IllegalStateException(var9.toString());
            }

            LockFreeLinkedListNode a = ((MutexImpl.LockedQueue)a).removeFirstOrNull();
            if (a == null) {
               MutexImpl.UnlockOp a = new MutexImpl.UnlockOp((MutexImpl.LockedQueue)a);
               if (_state$FU.compareAndSet(a, a, a) && a.perform(a) == null) {
                  return;
               }
            } else if (((MutexImpl.LockWaiter)a).tryResumeLockWaiter()) {
               MutexImpl.LockedQueue var10000 = (MutexImpl.LockedQueue)a;
               Object var10001 = ((MutexImpl.LockWaiter)a).owner;
               if (var10001 == null) {
                  var10001 = MutexKt.access$getLOCKED$p();
               }

               var10000.owner = var10001;
               ((MutexImpl.LockWaiter)a).completeResumeLockWaiter();
               return;
            }
         }
      }
   }

   @NotNull
   public String toString() {
      MutexImpl a = a;
      boolean var2 = false;

      while(true) {
         Object a = a._state;
         int a = false;
         if (a instanceof Empty) {
            return "Mutex[" + ((Empty)a).locked + ']';
         }

         if (!(a instanceof OpDescriptor)) {
            if (a instanceof MutexImpl.LockedQueue) {
               return "Mutex[" + ((MutexImpl.LockedQueue)a).owner + ']';
            }

            throw new IllegalStateException(("Illegal state " + a).toString());
         }

         ((OpDescriptor)a).perform(a);
      }
   }

   // $FF: synthetic method
   public static final Object access$lockSuspend(MutexImpl a, Object a, Continuation a) {
      return a.lockSuspend(a, a);
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0002\u0018\u00002\u00020\u0001:\u0001\rB\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\u0002\u0010\u0006J\u001e\u0010\u0007\u001a\u00020\b2\n\u0010\t\u001a\u0006\u0012\u0002\b\u00030\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\u0005H\u0016J\u0016\u0010\f\u001a\u0004\u0018\u00010\u00052\n\u0010\t\u001a\u0006\u0012\u0002\b\u00030\nH\u0016R\u0010\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\u0004\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"},
      d2 = {"Lkotlinx/coroutines/sync/MutexImpl$TryLockDesc;", "Lkotlinx/coroutines/internal/AtomicDesc;", "mutex", "Lkotlinx/coroutines/sync/MutexImpl;", "owner", "", "(Lkotlinx/coroutines/sync/MutexImpl;Ljava/lang/Object;)V", "complete", "", "op", "Lkotlinx/coroutines/internal/AtomicOp;", "failure", "prepare", "PrepareOp", "kotlinx-coroutines-core"}
   )
   private static final class TryLockDesc extends AtomicDesc {
      @JvmField
      @NotNull
      public final MutexImpl mutex;
      @JvmField
      @Nullable
      public final Object owner;

      public TryLockDesc(@NotNull MutexImpl a, @Nullable Object a) {
         a.mutex = a;
         a.owner = a;
      }

      @Nullable
      public Object prepare(@NotNull AtomicOp<?> a) {
         MutexImpl.TryLockDesc.PrepareOp a = new MutexImpl.TryLockDesc.PrepareOp(a);
         return !MutexImpl._state$FU.compareAndSet(a.mutex, MutexKt.access$getEMPTY_UNLOCKED$p(), a) ? MutexKt.access$getLOCK_FAIL$p() : a.perform(a.mutex);
      }

      public void complete(@NotNull AtomicOp<?> a, @Nullable Object a) {
         Empty a = a != null ? MutexKt.access$getEMPTY_UNLOCKED$p() : (a.owner == null ? MutexKt.access$getEMPTY_LOCKED$p() : new Empty(a.owner));
         MutexImpl._state$FU.compareAndSet(a.mutex, a, a);
      }

      @Metadata(
         mv = {1, 6, 0},
         k = 1,
         xi = 48,
         d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0002\b\u0002\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0011\u0012\n\u0010\u0002\u001a\u0006\u0012\u0002\b\u00030\u0003¢\u0006\u0002\u0010\u0004J\u0014\u0010\u0007\u001a\u0004\u0018\u00010\b2\b\u0010\t\u001a\u0004\u0018\u00010\bH\u0016R\u0018\u0010\u0002\u001a\u0006\u0012\u0002\b\u00030\u0003X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\n"},
         d2 = {"Lkotlinx/coroutines/sync/MutexImpl$TryLockDesc$PrepareOp;", "Lkotlinx/coroutines/internal/OpDescriptor;", "atomicOp", "Lkotlinx/coroutines/internal/AtomicOp;", "(Lkotlinx/coroutines/sync/MutexImpl$TryLockDesc;Lkotlinx/coroutines/internal/AtomicOp;)V", "getAtomicOp", "()Lkotlinx/coroutines/internal/AtomicOp;", "perform", "", "affected", "kotlinx-coroutines-core"}
      )
      private final class PrepareOp extends OpDescriptor {
         @NotNull
         private final AtomicOp<?> atomicOp;

         public PrepareOp(@NotNull AtomicOp<?> axx) {
            a.atomicOp = axx;
         }

         @NotNull
         public AtomicOp<?> getAtomicOp() {
            return a.atomicOp;
         }

         @Nullable
         public Object perform(@Nullable Object ax) {
            Object axx = a.getAtomicOp().isDecided() ? MutexKt.access$getEMPTY_UNLOCKED$p() : a.getAtomicOp();
            if (ax == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.sync.MutexImpl");
            } else {
               MutexImpl._state$FU.compareAndSet((MutexImpl)ax, a, axx);
               return null;
            }
         }
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u0005\u001a\u00020\u0006H\u0016R\u0012\u0010\u0002\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000¨\u0006\u0007"},
      d2 = {"Lkotlinx/coroutines/sync/MutexImpl$LockedQueue;", "Lkotlinx/coroutines/internal/LockFreeLinkedListHead;", "owner", "", "(Ljava/lang/Object;)V", "toString", "", "kotlinx-coroutines-core"}
   )
   private static final class LockedQueue extends LockFreeLinkedListHead {
      @JvmField
      @NotNull
      public volatile Object owner;

      public LockedQueue(@NotNull Object a) {
         a.owner = a;
      }

      @NotNull
      public String toString() {
         return "LockedQueue[" + a.owner + ']';
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\b¢\u0004\u0018\u00002\u00020\u000f2\u00020\u0010B\u0011\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0001¢\u0006\u0004\b\u0003\u0010\u0004J\u000f\u0010\u0006\u001a\u00020\u0005H&¢\u0006\u0004\b\u0006\u0010\u0007J\r\u0010\b\u001a\u00020\u0005¢\u0006\u0004\b\b\u0010\u0007J\r\u0010\n\u001a\u00020\t¢\u0006\u0004\b\n\u0010\u000bJ\u000f\u0010\f\u001a\u00020\tH&¢\u0006\u0004\b\f\u0010\u000bR\u0016\u0010\u0002\u001a\u0004\u0018\u00010\u00018\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0002\u0010\r¨\u0006\u000e"},
      d2 = {"Lkotlinx/coroutines/sync/MutexImpl$LockWaiter;", "", "owner", "MutexImpl$LockWaiter", "(Lkotlinx/coroutines/sync/MutexImpl;Ljava/lang/Object;)V", "", "completeResumeLockWaiter", "()V", "dispose", "", "take", "()Z", "tryResumeLockWaiter", "Ljava/lang/Object;", "kotlinx-coroutines-core", "Lkotlinx/coroutines/internal/LockFreeLinkedListNode;", "Lkotlinx/coroutines/DisposableHandle;"}
   )
   private abstract class LockWaiter extends LockFreeLinkedListNode implements DisposableHandle {
      @JvmField
      @Nullable
      public final Object owner;
      // $FF: synthetic field
      @NotNull
      private volatile int isTaken;
      // $FF: synthetic field
      private static final AtomicIntegerFieldUpdater isTaken$FU = AtomicIntegerFieldUpdater.newUpdater(MutexImpl.LockWaiter.class, "isTaken");

      public LockWaiter(@Nullable Object axx) {
         a.owner = axx;
         a.isTaken = 0;
      }

      public final boolean take() {
         return isTaken$FU.compareAndSet(a, 0, 1);
      }

      public final void dispose() {
         a.remove();
      }

      public abstract boolean tryResumeLockWaiter();

      public abstract void completeResumeLockWaiter();
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\b\u0082\u0004\u0018\u00002\u00060\u0001R\u00020\u0002B\u001d\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006¢\u0006\u0002\u0010\bJ\b\u0010\t\u001a\u00020\u0007H\u0016J\b\u0010\n\u001a\u00020\u000bH\u0016J\b\u0010\f\u001a\u00020\rH\u0016R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"},
      d2 = {"Lkotlinx/coroutines/sync/MutexImpl$LockCont;", "Lkotlinx/coroutines/sync/MutexImpl$LockWaiter;", "Lkotlinx/coroutines/sync/MutexImpl;", "owner", "", "cont", "Lkotlinx/coroutines/CancellableContinuation;", "", "(Lkotlinx/coroutines/sync/MutexImpl;Ljava/lang/Object;Lkotlinx/coroutines/CancellableContinuation;)V", "completeResumeLockWaiter", "toString", "", "tryResumeLockWaiter", "", "kotlinx-coroutines-core"}
   )
   private final class LockCont extends MutexImpl.LockWaiter {
      @NotNull
      private final CancellableContinuation<Unit> cont;

      public LockCont(@Nullable Object axxx, @NotNull CancellableContinuation<? super Unit> ax) {
         super(axxx);
         a.cont = ax;
      }

      public boolean tryResumeLockWaiter() {
         if (!a.take()) {
            return false;
         } else {
            return a.cont.tryResume(Unit.INSTANCE, (Object)null, (Function1)(new Function1<Throwable, Unit>() {
               public final void invoke(@NotNull Throwable a1) {
                  MutexImpl.this.unlock(a.owner);
               }
            })) != null;
         }
      }

      public void completeResumeLockWaiter() {
         a.cont.completeResume(CancellableContinuationImplKt.RESUME_TOKEN);
      }

      @NotNull
      public String toString() {
         return "LockCont[" + a.owner + ", " + a.cont + "] for " + MutexImpl.this;
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\b\u0082\u0004\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00060\u0002R\u00020\u0003BD\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00028\u00000\u0007\u0012\"\u0010\b\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\n\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u000b\u0012\u0006\u0012\u0004\u0018\u00010\u00050\tø\u0001\u0000¢\u0006\u0002\u0010\fJ\b\u0010\u000e\u001a\u00020\u000fH\u0016J\b\u0010\u0010\u001a\u00020\u0011H\u0016J\b\u0010\u0012\u001a\u00020\u0013H\u0016R1\u0010\b\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\n\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u000b\u0012\u0006\u0012\u0004\u0018\u00010\u00050\t8\u0006X\u0087\u0004ø\u0001\u0000¢\u0006\u0004\n\u0002\u0010\rR\u0016\u0010\u0006\u001a\b\u0012\u0004\u0012\u00028\u00000\u00078\u0006X\u0087\u0004¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0014"},
      d2 = {"Lkotlinx/coroutines/sync/MutexImpl$LockSelect;", "R", "Lkotlinx/coroutines/sync/MutexImpl$LockWaiter;", "Lkotlinx/coroutines/sync/MutexImpl;", "owner", "", "select", "Lkotlinx/coroutines/selects/SelectInstance;", "block", "Lkotlin/Function2;", "Lkotlinx/coroutines/sync/Mutex;", "Lkotlin/coroutines/Continuation;", "(Lkotlinx/coroutines/sync/MutexImpl;Ljava/lang/Object;Lkotlinx/coroutines/selects/SelectInstance;Lkotlin/jvm/functions/Function2;)V", "Lkotlin/jvm/functions/Function2;", "completeResumeLockWaiter", "", "toString", "", "tryResumeLockWaiter", "", "kotlinx-coroutines-core"}
   )
   private final class LockSelect<R> extends MutexImpl.LockWaiter {
      @JvmField
      @NotNull
      public final SelectInstance<R> select;
      @JvmField
      @NotNull
      public final Function2<Mutex, Continuation<? super R>, Object> block;

      public LockSelect(@Nullable Object axxxx, @NotNull SelectInstance<? super R> ax, @NotNull Function2<? super Mutex, ? super Continuation<? super R>, ? extends Object> axxx) {
         super(axxxx);
         a.select = ax;
         a.block = axxx;
      }

      public boolean tryResumeLockWaiter() {
         return a.take() && a.select.trySelect();
      }

      public void completeResumeLockWaiter() {
         CancellableKt.startCoroutineCancellable(a.block, MutexImpl.this, a.select.getCompletion(), (Function1)(new Function1<Throwable, Unit>() {
            public final void invoke(@NotNull Throwable a1) {
               MutexImpl.this.unlock(a.owner);
            }
         }));
      }

      @NotNull
      public String toString() {
         return "LockSelect[" + a.owner + ", " + a.select + "] for " + MutexImpl.this;
      }
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\r\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005J\u001a\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u00022\b\u0010\t\u001a\u0004\u0018\u00010\nH\u0016J\u0012\u0010\u000b\u001a\u0004\u0018\u00010\n2\u0006\u0010\b\u001a\u00020\u0002H\u0016R\u0010\u0010\u0003\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\f"},
      d2 = {"Lkotlinx/coroutines/sync/MutexImpl$UnlockOp;", "Lkotlinx/coroutines/internal/AtomicOp;", "Lkotlinx/coroutines/sync/MutexImpl;", "queue", "Lkotlinx/coroutines/sync/MutexImpl$LockedQueue;", "(Lkotlinx/coroutines/sync/MutexImpl$LockedQueue;)V", "complete", "", "affected", "failure", "", "prepare", "kotlinx-coroutines-core"}
   )
   private static final class UnlockOp extends AtomicOp<MutexImpl> {
      @JvmField
      @NotNull
      public final MutexImpl.LockedQueue queue;

      public UnlockOp(@NotNull MutexImpl.LockedQueue a) {
         a.queue = a;
      }

      @Nullable
      public Object prepare(@NotNull MutexImpl a1) {
         return a.queue.isEmpty() ? null : MutexKt.access$getUNLOCK_FAIL$p();
      }

      public void complete(@NotNull MutexImpl a, @Nullable Object a) {
         Object a = a == null ? MutexKt.access$getEMPTY_UNLOCKED$p() : a.queue;
         MutexImpl._state$FU.compareAndSet(a, a, a);
      }
   }
}
