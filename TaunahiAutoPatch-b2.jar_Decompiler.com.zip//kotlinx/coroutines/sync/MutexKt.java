package kotlinx.coroutines.sync;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.InlineMarker;
import kotlinx.coroutines.internal.Symbol;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000.\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0010\u0010\u000f\u001a\u00020\u00102\b\b\u0002\u0010\u0011\u001a\u00020\u0012\u001aB\u0010\u0013\u001a\u0002H\u0014\"\u0004\b\u0000\u0010\u0014*\u00020\u00102\n\b\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u00162\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u0002H\u00140\u0018H\u0086Hø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0001¢\u0006\u0002\u0010\u0019\"\u0016\u0010\u0000\u001a\u00020\u00018\u0002X\u0083\u0004¢\u0006\b\n\u0000\u0012\u0004\b\u0002\u0010\u0003\"\u0016\u0010\u0004\u001a\u00020\u00018\u0002X\u0083\u0004¢\u0006\b\n\u0000\u0012\u0004\b\u0005\u0010\u0003\"\u0016\u0010\u0006\u001a\u00020\u00078\u0002X\u0083\u0004¢\u0006\b\n\u0000\u0012\u0004\b\b\u0010\u0003\"\u0016\u0010\t\u001a\u00020\u00078\u0002X\u0083\u0004¢\u0006\b\n\u0000\u0012\u0004\b\n\u0010\u0003\"\u0016\u0010\u000b\u001a\u00020\u00078\u0002X\u0083\u0004¢\u0006\b\n\u0000\u0012\u0004\b\f\u0010\u0003\"\u0016\u0010\r\u001a\u00020\u00078\u0002X\u0083\u0004¢\u0006\b\n\u0000\u0012\u0004\b\u000e\u0010\u0003\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u001a"},
   d2 = {"EMPTY_LOCKED", "Lkotlinx/coroutines/sync/Empty;", "getEMPTY_LOCKED$annotations", "()V", "EMPTY_UNLOCKED", "getEMPTY_UNLOCKED$annotations", "LOCKED", "Lkotlinx/coroutines/internal/Symbol;", "getLOCKED$annotations", "LOCK_FAIL", "getLOCK_FAIL$annotations", "UNLOCKED", "getUNLOCKED$annotations", "UNLOCK_FAIL", "getUNLOCK_FAIL$annotations", "Mutex", "Lkotlinx/coroutines/sync/Mutex;", "locked", "", "withLock", "T", "owner", "", "action", "Lkotlin/Function0;", "(Lkotlinx/coroutines/sync/Mutex;Ljava/lang/Object;Lkotlin/jvm/functions/Function0;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}
)
public final class MutexKt {
   @NotNull
   private static final Symbol LOCK_FAIL = new Symbol("LOCK_FAIL");
   @NotNull
   private static final Symbol UNLOCK_FAIL = new Symbol("UNLOCK_FAIL");
   @NotNull
   private static final Symbol LOCKED = new Symbol("LOCKED");
   @NotNull
   private static final Symbol UNLOCKED = new Symbol("UNLOCKED");
   @NotNull
   private static final Empty EMPTY_LOCKED;
   @NotNull
   private static final Empty EMPTY_UNLOCKED;

   @NotNull
   public static final Mutex Mutex(boolean a) {
      return (Mutex)(new MutexImpl(a));
   }

   // $FF: synthetic method
   public static Mutex Mutex$default(boolean var0, int var1, Object var2) {
      if ((var1 & 1) != 0) {
         var0 = false;
      }

      return Mutex(var0);
   }

   @Nullable
   public static final <T> Object withLock(@NotNull Mutex a, @Nullable Object a, @NotNull Function0<? extends T> a, @NotNull Continuation<? super T> var3) {
      Object a;
      label57: {
         if (var3 instanceof <undefinedtype>) {
            a = (<undefinedtype>)var3;
            if ((((<undefinedtype>)a).label & Integer.MIN_VALUE) != 0) {
               ((<undefinedtype>)a).label -= Integer.MIN_VALUE;
               break label57;
            }
         }

         a = new ContinuationImpl(var3) {
            Object L$0;
            Object L$1;
            Object L$2;
            // $FF: synthetic field
            Object result;
            int label;

            @Nullable
            public final Object invokeSuspend(@NotNull Object ax) {
               a.result = ax;
               a.label |= Integer.MIN_VALUE;
               return MutexKt.withLock((Mutex)null, (Object)null, (Function0)null, (Continuation)a);
            }
         };
      }

      Object a = ((<undefinedtype>)a).result;
      Object var8 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      boolean a;
      switch(((<undefinedtype>)a).label) {
      case 0:
         ResultKt.throwOnFailure(a);
         a = false;
         ((<undefinedtype>)a).L$0 = a;
         ((<undefinedtype>)a).L$1 = a;
         ((<undefinedtype>)a).L$2 = a;
         ((<undefinedtype>)a).label = 1;
         if (a.lock(a, (Continuation)a) == var8) {
            return var8;
         }
         break;
      case 1:
         a = false;
         a = (Function0)((<undefinedtype>)a).L$2;
         a = ((<undefinedtype>)a).L$1;
         a = (Mutex)((<undefinedtype>)a).L$0;
         ResultKt.throwOnFailure(a);
         break;
      default:
         throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }

      Object var5;
      try {
         var5 = a.invoke();
      } finally {
         InlineMarker.finallyStart(1);
         a.unlock(a);
         InlineMarker.finallyEnd(1);
      }

      return var5;
   }

   private static final <T> Object withLock$$forInline(Mutex a, Object a, Function0<? extends T> a, Continuation<? super T> a) {
      int a = false;
      InlineMarker.mark(0);
      a.lock(a, a);
      InlineMarker.mark(1);

      Object var5;
      try {
         var5 = a.invoke();
      } finally {
         InlineMarker.finallyStart(1);
         a.unlock(a);
         InlineMarker.finallyEnd(1);
      }

      return var5;
   }

   // $FF: synthetic method
   public static Object withLock$default(Mutex a, Object a, Function0 a, Continuation a, int var4, Object var5) {
      if ((var4 & 1) != 0) {
         a = null;
      }

      int a = false;
      InlineMarker.mark(0);
      a.lock(a, a);
      InlineMarker.mark(1);

      try {
         var5 = a.invoke();
      } finally {
         InlineMarker.finallyStart(1);
         a.unlock(a);
         InlineMarker.finallyEnd(1);
      }

      return var5;
   }

   /** @deprecated */
   // $FF: synthetic method
   private static void getLOCK_FAIL$annotations() {
   }

   /** @deprecated */
   // $FF: synthetic method
   private static void getUNLOCK_FAIL$annotations() {
   }

   /** @deprecated */
   // $FF: synthetic method
   private static void getLOCKED$annotations() {
   }

   /** @deprecated */
   // $FF: synthetic method
   private static void getUNLOCKED$annotations() {
   }

   /** @deprecated */
   // $FF: synthetic method
   private static void getEMPTY_LOCKED$annotations() {
   }

   /** @deprecated */
   // $FF: synthetic method
   private static void getEMPTY_UNLOCKED$annotations() {
   }

   // $FF: synthetic method
   public static final Empty access$getEMPTY_LOCKED$p() {
      return EMPTY_LOCKED;
   }

   // $FF: synthetic method
   public static final Empty access$getEMPTY_UNLOCKED$p() {
      return EMPTY_UNLOCKED;
   }

   // $FF: synthetic method
   public static final Symbol access$getUNLOCKED$p() {
      return UNLOCKED;
   }

   // $FF: synthetic method
   public static final Symbol access$getLOCK_FAIL$p() {
      return LOCK_FAIL;
   }

   // $FF: synthetic method
   public static final Symbol access$getUNLOCK_FAIL$p() {
      return UNLOCK_FAIL;
   }

   // $FF: synthetic method
   public static final Symbol access$getLOCKED$p() {
      return LOCKED;
   }

   static {
      EMPTY_LOCKED = new Empty(LOCKED);
      EMPTY_UNLOCKED = new Empty(UNLOCKED);
   }
}
