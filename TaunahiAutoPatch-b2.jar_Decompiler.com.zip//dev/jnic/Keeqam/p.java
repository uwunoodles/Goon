package dev.jnic.Keeqam;

final class p extends W {
   // $FF: synthetic field
   final K V;

   private p(K var1) {
      this.V = var1;
   }

   // $FF: synthetic method
   p(K var1, byte var2) {
      this(var1);
   }
}
