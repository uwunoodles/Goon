package dev.jnic.Keeqam;

import java.util.Arrays;

abstract class W {
   final short[] N = new short[768];

   final void c() {
      Arrays.fill(this.N, (short)1024);
   }
}
