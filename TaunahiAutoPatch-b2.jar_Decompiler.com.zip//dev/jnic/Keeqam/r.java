package dev.jnic.Keeqam;

final class r {
   int S;
}
