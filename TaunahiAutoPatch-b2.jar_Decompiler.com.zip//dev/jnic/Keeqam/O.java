package dev.jnic.Keeqam;

final class O extends J {
   // $FF: synthetic field
   private F T;

   private O(F var1) {
      this.T = var1;
      super();
   }

   final int c(int var1) {
      if (this.T.O.a(this.H, 0) == 0) {
         return this.T.O.a(this.I[var1]) + 2;
      } else {
         return this.T.O.a(this.H, 1) == 0 ? this.T.O.a(this.J[var1]) + 2 + 8 : this.T.O.a(this.K) + 2 + 8 + 8;
      }
   }

   // $FF: synthetic method
   O(F var1, byte var2) {
      this(var1);
   }
}
